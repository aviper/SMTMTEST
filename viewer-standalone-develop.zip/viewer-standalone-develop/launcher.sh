#!/bin/bash
# See https://stackoverflow.com/questions/60473727/angular-build-watch-for-multiple-libraries-and-and-serve-to-another-app
# When running development builds inside of the test platform, dependent libraries are not watched and rebuilt.
# This script ensures that all dependent libs are built, and then serves (and watches) the main app.
# It runs within the docker container(s) built by Dockerfile.launcher.synth-vision and Dockerfile.launcher.pulse-zero.
# It accepts two arguments, the name of the project to serve (synth-view or pulse-zero) and the serve path (/viewer or /pulseZero).

rm -rf dist
node update-synth-view-version.js
for lib in worker-compatible-api server-api pulse-zero-api
do
  echo Build and watch $lib
  node node_modules/@angular/cli/bin/ng build $lib --watch &
  while ! [ -e dist/$lib/package.json ]
  do
    sleep 1
  done
done

echo Serve and watch $1
node node_modules/@angular/cli/bin/ng serve $1 --live-reload=true --host=0.0.0.0 --serve-path=$2
