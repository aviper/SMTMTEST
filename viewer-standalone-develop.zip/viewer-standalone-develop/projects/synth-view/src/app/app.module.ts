import { NgModule, isDevMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ServiceWorkerModule } from '@angular/service-worker';

import { environment } from '../environments';
import { SynthViewComponent } from './app.component';
import { ViewerModule } from './viewer/viewer.module';
import { LogRocketService } from './services/logrocket.service';
import { PulseVisionApiModule } from '@pulse-zero-api';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { PerfMonitorService } from './services/perf-monitor.service';

@NgModule({
  declarations: [
    SynthViewComponent,
  ],
  imports: [
    BrowserModule,
    PulseVisionApiModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: !isDevMode(), // set to '!isDevMode()'. Should work only in production builds.
      // Scope must match the base href of the application
      scope: '/viewer/',
      // Register the ServiceWorker as soon as the application is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
    ViewerModule
  ],
  providers: [
    { provide: environment, useValue: environment },
    LogRocketService,
    provideHttpClient(withInterceptorsFromDi()),
    PerfMonitorService
  ],
  bootstrap: [SynthViewComponent]
})
export class AppModule { }
