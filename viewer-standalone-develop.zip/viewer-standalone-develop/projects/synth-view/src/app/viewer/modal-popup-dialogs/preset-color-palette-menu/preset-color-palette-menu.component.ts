import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';

import { PanelBoundDialog } from '../../utils';
import { PresetColorPaletteMenuService } from './preset-color-palette-menu.service';
import { PresetColorPaletteParams } from '../modal-popup.service';
import { MatListOption } from '@angular/material/list';

const MAX_PRESETS = 3;

@Component({
  standalone: false,
  selector: 'app-preset-color-palette-menu',
  templateUrl: './preset-color-palette-menu.component.html',
  styleUrl: './preset-color-palette-menu.component.scss'
})
export class PresetColorPaletteMenuComponent implements AfterViewInit {

  protected readonly presets: string[] = [];
  protected editable = false;
  protected favorites: string[] = [];
  protected selectedPreset: string;

  constructor(
    private matDialogRef: MatDialogRef<PresetColorPaletteMenuComponent, string | null>,
    private elementRef: ElementRef,
    private presetColorPaletteMenuService: PresetColorPaletteMenuService,
    @Inject(MAT_DIALOG_DATA) private data: PresetColorPaletteParams) {

    this.editable = this.data.editable;
    this.selectedPreset = this.data.selectedPreset;
    this.favorites = this.presetColorPaletteMenuService.getPresetFavorites();
    this.presets = this.presetColorPaletteMenuService.getPresets();

    // If user presses ESC or clicks on background return nothing
    matDialogRef.backdropClick()
      .pipe(
        take(1)
      )
      .subscribe(() => {
        // Store the presets if they've changed.
        if (this.editable && this.favorites !== this.presetColorPaletteMenuService.getPresetFavorites()) {
          this.presetColorPaletteMenuService.setPresetFavorites(this.favorites);
        }
        matDialogRef.close(null);
      });
  }

  ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('preset-color-palette-menu', this.elementRef, this.data.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  protected onSelect(preset: string): void {
    // Save the favorites in case they were changed prior to making a selection.
    if (this.editable) {
      this.presetColorPaletteMenuService.setPresetFavorites(this.favorites);
    }
    this.matDialogRef.close(preset);
  }

  protected onSelectionChange(options: MatListOption[]): void {
    // This gives us the list of selections in the order they were selected.
    this.favorites = options.map(o => o.value);
  }

  protected isDisabled(preset: string): boolean {
    // We allow three selections then disable checkboxes.
    // Don't disable selected options. A user needs to be able to de-select.
    if (this.favorites.findIndex(option => option === preset) === -1) {
      return this.favorites.length >= MAX_PRESETS;
    }
    return false;
  }

  protected isFavorite(preset: string): boolean {
    return this.favorites.findIndex(option => option === preset) !== -1;
  }

  protected getTooltip(preset: string): string {
    const index = this.favorites.findIndex(option => option === preset);
    if (index >= 0) {
      return `NumLock+${index + 1}`;
    }
    return '';
  }
}
