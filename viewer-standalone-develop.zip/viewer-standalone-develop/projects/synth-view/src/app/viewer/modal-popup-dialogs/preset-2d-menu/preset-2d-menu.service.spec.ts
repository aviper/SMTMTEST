import { TestBed } from '@angular/core/testing';

import { Preset2dMenuService } from './preset-2d-menu.service';

describe('Preset2DMenuService', () => {
  let service: Preset2dMenuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Preset2dMenuService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
