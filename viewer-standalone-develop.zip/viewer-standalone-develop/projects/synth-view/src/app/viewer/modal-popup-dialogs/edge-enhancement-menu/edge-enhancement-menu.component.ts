import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';
import { PanelBoundDialog } from '../../utils';
import { EdgeEnhancementParams } from '../modal-popup.service';
import { EdgeEnhancementMenuService } from './edge-enhancement-menu.service';
import { ViewerSettingsService } from '../../services';
import {
  EDGE_ENHANCEMENT_LEVEL_TYPE,
  IEdgeEnhancementLevelEntry,
  EdgeEnhancementLevel
} from '../../models';

@Component({
  standalone: false,
  selector: 'app-edge-enhancement-menu',
  templateUrl: './edge-enhancement-menu.component.html',
  styleUrls: ['./edge-enhancement-menu.component.scss']
})
export class EdgeEnhancementMenuComponent implements AfterViewInit {

  /** List of all selectable edge enhancement levels */
  protected readonly edgeEnhancementLevels = [
    EDGE_ENHANCEMENT_LEVEL_TYPE.low,
    EDGE_ENHANCEMENT_LEVEL_TYPE.medium,
    EDGE_ENHANCEMENT_LEVEL_TYPE.high,
    EDGE_ENHANCEMENT_LEVEL_TYPE.none
  ];

  /** Currently selected enum value for UI logic */
  protected selectedLevel: EDGE_ENHANCEMENT_LEVEL_TYPE = EDGE_ENHANCEMENT_LEVEL_TYPE.low;

  constructor(
    private viewerSettingsService: ViewerSettingsService,
    private matDialogRef: MatDialogRef<
      EdgeEnhancementMenuComponent,
      EdgeEnhancementLevel | null
    >,
    private elRef: ElementRef,
    private edgeEnhancementMenuService: EdgeEnhancementMenuService,
    @Inject(MAT_DIALOG_DATA) private data: EdgeEnhancementParams
  ) {
    if (this.data) {
      this.initSelection();
    }

    // Close on backdrop click
    matDialogRef.backdropClick()
      .pipe(take(1))
      .subscribe(() => {
        const currentFavorite = this.edgeEnhancementMenuService.getEdgeEnhancementLevelFavorites();
        if (this.selectedLevel !== currentFavorite?.type) {
          const favorite = new EdgeEnhancementLevel(this.selectedLevel);
          this.edgeEnhancementMenuService.setEdgeEnhancementLevelFavorites(favorite);
        }
        matDialogRef.close(null);
      });
  }

  /** Initialize selected level from service favorite */
  private initSelection(): void {
    const favorite = this.edgeEnhancementMenuService.getEdgeEnhancementLevelFavorites();
    // this.selectedLevel = favorite?.type ?? EDGE_ENHANCEMENT_LEVEL_TYPE.none;
    this.selectedLevel =
      this.data?.selectedLevel ??
      favorite?.type ??
      EDGE_ENHANCEMENT_LEVEL_TYPE.low;
  }
  public onSelect(level: EDGE_ENHANCEMENT_LEVEL_TYPE): void {
    this.selectedLevel = level;

    const selected = new EdgeEnhancementLevel(level);
    this.edgeEnhancementMenuService.setEdgeEnhancementLevelFavorites(selected);

    // Return the EdgeEnhancementLevel object directly
    this.matDialogRef.close(selected);
  }

  /** Highlight the currently selected option */
  protected isSelected(level: EDGE_ENHANCEMENT_LEVEL_TYPE): boolean {
    return this.selectedLevel === level;
  }

  /** Compare function for Angular Material bindings */
  protected compareFunction(o1: string, o2: string): boolean {
    return o1 === o2;
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      const panelBoundDialog = new PanelBoundDialog('edge-enhancement-menu', this.elRef, this.data.panelBounds);
      const position = panelBoundDialog.updatePanelBoundDialogPosition();
      if (position) {
        this.matDialogRef.updatePosition({ top: position.top, left: position.left });
      }
    });
  }
}
