import { Component, Inject } from '@angular/core';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserNotificationParams } from '../modal-popup.service';

@Component({
  standalone: false,
  selector: 'app-user-notification',
  templateUrl: './user-notification.component.html',
  styleUrls: ['./user-notification.component.scss']
})
export class UserNotificationComponent {
  constructor(
    private matDialogRef: MatDialogRef<UserNotificationComponent, string>,
    @Inject(MAT_DIALOG_DATA) private data: UserNotificationParams) {
  }

  public get message(): string {
    return this.data.userMessage;
  }

  public get details(): string[] {
    return this.data.additionalInfo;
  }

  public onOK(): void {
    this.matDialogRef.close();
  }

  protected get showButton(): boolean {
    return this.data.showButton;
  }
}
