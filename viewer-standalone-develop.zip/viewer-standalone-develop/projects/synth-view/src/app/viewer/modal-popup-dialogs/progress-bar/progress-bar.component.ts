import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ProgressBarParams } from '../modal-popup.service';

@Component({
  selector: 'app-progress-bar',
  standalone: false,
  templateUrl: './progress-bar.component.html',
  styleUrl: './progress-bar.component.scss'
})
export class ProgressBarComponent {
  private _isError = false;
  private _message = '';
  private _progressValue = 0;
  private _showOkButton = false;

  constructor(
    private matDialogRef: MatDialogRef<ProgressBarComponent, boolean>,
    @Inject(MAT_DIALOG_DATA) private data: ProgressBarParams
  ) {}

  get progressValue(): number {
    return this._progressValue;
  }

  set progressValue(value: number) {
    this._progressValue = value;
  }

  get title(): string {
    return this.data.title;
  }

  get message(): string {
    return this._message;
  }

  set message(value: string) {
    this._message = value;
  }

  get color(): string {
    return this._isError ? 'warn' : '';
  }

  set showOkButton(value: boolean) {
    this._showOkButton = value;
  }

  get showOkButton(): boolean {
    return this._showOkButton;
  }

  public updateProgress(value: number): void {
    this.progressValue = value;
  }

  public updateMessage(message: string): void {
    this.message = message;
  }

  public updateOkButton(show: boolean): void {
    this.showOkButton = show;
  }

  public setErrorState(): void {
    this._isError = true;
  }

  onOK(): void {
    this.matDialogRef.close();
  }
}
