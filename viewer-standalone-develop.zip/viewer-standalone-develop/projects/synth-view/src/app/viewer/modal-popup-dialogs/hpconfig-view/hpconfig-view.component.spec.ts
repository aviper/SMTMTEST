import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HPConfigViewComponent } from './hpconfig-view.component';

describe('HPConfigViewComponent', () => {
  let component: HPConfigViewComponent;
  let fixture: ComponentFixture<HPConfigViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HPConfigViewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HPConfigViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
