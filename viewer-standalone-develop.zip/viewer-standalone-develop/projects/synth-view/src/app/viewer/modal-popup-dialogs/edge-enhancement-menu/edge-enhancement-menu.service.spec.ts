import { TestBed } from '@angular/core/testing';

import { EdgeEnhancementMenuService } from './edge-enhancement-menu.service';

describe('EdgeEnhancementMenuService', () => {
  let service: EdgeEnhancementMenuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EdgeEnhancementMenuService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
