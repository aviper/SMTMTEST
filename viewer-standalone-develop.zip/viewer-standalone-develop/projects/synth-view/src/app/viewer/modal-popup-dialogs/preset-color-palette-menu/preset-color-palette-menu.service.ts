import { Injectable } from '@angular/core';
import { IManagedService, registerService, ViewerSettingsService } from '../../services';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PresetColorPaletteMenuService implements IManagedService {
  private unsubscribe$$ = new Subject<void>();

  constructor(private viewerSettingsService: ViewerSettingsService) {
    registerService(this);
    this.subscriptions();
  }

  public async stopProcessing(): Promise<void> {
    this.unsubscribe();
  }

  public async reInitData(bComparison: boolean = false): Promise<void> {
  }

  public async reStartSubscriptions(): Promise<void> {
    this.subscriptions();
  }

  public getPresetFavorites(): string[] {
    return this.viewerSettingsService.colorPalettePresetFavorites;
  }

  public getPresets(): string[] {
    return this.viewerSettingsService.presetColorPaletteList;
  }

  public setPresetFavorites(presetFaves: string[]): void {
    this.viewerSettingsService.colorPalettePresetFavorites = presetFaves;
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  private subscriptions(): void {
  }

  public ngOnDestroy(): void {
    this.stopProcessing().then();
  }
}
