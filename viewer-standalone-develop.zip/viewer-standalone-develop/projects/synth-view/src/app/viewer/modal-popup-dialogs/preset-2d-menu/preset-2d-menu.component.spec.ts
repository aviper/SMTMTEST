import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WLPreset2DMenuComponent } from './preset-2d-menu.component';

describe('ContextMenusComponent', () => {
  let component: WLPreset2DMenuComponent;
  let fixture: ComponentFixture<WLPreset2DMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WLPreset2DMenuComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(WLPreset2DMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
