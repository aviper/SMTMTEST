import { TestBed } from '@angular/core/testing';

import { PresetColorPaletteMenuService } from './preset-color-palette-menu.service';

describe('PresetColorPaletteMenuService', () => {
  let service: PresetColorPaletteMenuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PresetColorPaletteMenuService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
