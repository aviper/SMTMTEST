import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DicomTagViewComponent } from './dicom-tag-view.component';

describe('DicomTagViewComponent', () => {
  let component: DicomTagViewComponent;
  let fixture: ComponentFixture<DicomTagViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DicomTagViewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DicomTagViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
