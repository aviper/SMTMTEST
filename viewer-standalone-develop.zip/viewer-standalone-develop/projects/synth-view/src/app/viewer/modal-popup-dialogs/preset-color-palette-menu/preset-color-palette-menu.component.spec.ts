import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PresetColorPaletteMenuComponent } from './preset-color-palette-menu.component';

describe('PresetColorPaletteMenuComponent', () => {
  let component: PresetColorPaletteMenuComponent;
  let fixture: ComponentFixture<PresetColorPaletteMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PresetColorPaletteMenuComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PresetColorPaletteMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
