import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpineLabelSelectionComponent } from './spine-label-selection.component';

describe('SpineLabelSelectionComponent', () => {
  let component: SpineLabelSelectionComponent;
  let fixture: ComponentFixture<SpineLabelSelectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpineLabelSelectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SpineLabelSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
