import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HelpAboutParams } from '../modal-popup.service';
import { PanelBoundDialog } from '../../utils';
import Fovia from 'foviaapi';
import FoviaAPI = Fovia.FoviaAPI;
import { CLIENT_CONFIG } from '../../../../client-config/config';

@Component({
  standalone: false,
  selector: 'app-help-about',
  templateUrl: './help-about.component.html',
  styleUrls: ['./help-about.component.scss']
})
export class HelpAboutComponent implements AfterViewInit {

  public readonly CLIENT_CONFIG = CLIENT_CONFIG;
  public readonly UDI: string;
  public readonly buildVersion: string;
  protected versionInfo: string;
  protected clipboardText = '';

  constructor(
    private matDialogRef: MatDialogRef<HelpAboutComponent, string>,
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) private data: HelpAboutParams) {

    this.UDI = this.data.UDI;
    this.buildVersion = this.data.versionNumber;
    this.versionInfo = this.data.toString() + `\nFovia: ${FoviaAPI.serverVersion}`;
  }

  ngAfterViewInit(): void {
    if (this.data.panelBounds) {
      const panelBoundDialog = new PanelBoundDialog('help-about-window', this.elementRef, this.data.panelBounds);
      const position = panelBoundDialog.centerPanelBoundDialogPosition();
      if (position) {
        this.matDialogRef.updatePosition({ top: position.top, left: position.left });
      }
    }
  }

  protected onMouseUp(): void {
    this.matDialogRef.close();
  }

  public copyToClipboard(): void {
    this.clipboardText = `UDI: ${this.UDI}\n${this.versionInfo}`;
  }
}
