import { Injectable } from '@angular/core';
import { IManagedService, registerService, ViewerSettingsService } from '../../services';
import { Subject } from 'rxjs';
import { PresetEntry, WLPropagateMode } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class Preset2dMenuService implements IManagedService {
  private unsubscribe$$ = new Subject<void>();

  constructor(private viewerSettingsService: ViewerSettingsService) {
    registerService(this);
    this.subscriptions();
  }

  public async stopProcessing(): Promise<void> {
    this.unsubscribe();
  }

  public async reInitData(bComparison: boolean = false): Promise<void> {
  }

  public async reStartSubscriptions(): Promise<void> {
    this.subscriptions();
  }

  public getPresetFavorites(): PresetEntry[] {
    return this.viewerSettingsService.wlPresetFavorites;
  }

  public setPresetFavorites(presetFaves: PresetEntry[]): void {
    this.viewerSettingsService.wlPresetFavorites = presetFaves;
  }

  public getMRWlPropagateModeFavorites(): WLPropagateMode | null {
    return this.viewerSettingsService.mrWlPropagateModeFavorites;
  }
  public setMRWlPropagateModeFavorites(faves: WLPropagateMode | null): void {
    this.viewerSettingsService.mrWlPropagateModeFavorites = faves;
  }
  public getXrayWlPropagateModeFavorites(): WLPropagateMode| null {
    return this.viewerSettingsService.xrayWlPropagateModeFavorites;
  }
  public setXrayWlPropagateModeFavorites(faves: WLPropagateMode | null): void {
    this.viewerSettingsService.xrayWlPropagateModeFavorites = faves;
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  private subscriptions(): void {
  }

  public ngOnDestroy(): void {
    this.stopProcessing().then();
  }
}
