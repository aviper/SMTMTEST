import { AfterViewInit, Component, ElementRef, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HPParams } from '../modal-popup.service';
import { PanelBoundDialog } from '../../utils';

@Component({
  standalone: false,
  selector: 'app-hpconfig-view',
  templateUrl: './hpconfig-view.component.html',
  styleUrl: './hpconfig-view.component.scss'
})
export class HPConfigViewComponent implements AfterViewInit {
  @ViewChild('configTextArea', { static: true }) private textArea: ElementRef;
  protected configText;
  private scrolledOnce = false;
  constructor(
    private matDialogRef: MatDialogRef<HPConfigViewComponent, string>,
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) private data: HPParams) {
    this.configText = JSON.stringify(JSON.parse(JSON.stringify(this.data)), undefined, 4);
    this.textArea = new ElementRef(null);
  }

  ngAfterViewInit(): void {
    if (this.data.panelBounds) {
      const panelBoundDialog = new PanelBoundDialog('hpconfig-view-dialog', this.elementRef, this.data.panelBounds);
      const position = panelBoundDialog.centerPanelBoundDialogPosition();
      if (position) {
        this.matDialogRef.updatePosition({ top: position.top, left: position.left });
      }
    }
  }

  protected onClose(): void {
    this.matDialogRef.close();
  }
}
