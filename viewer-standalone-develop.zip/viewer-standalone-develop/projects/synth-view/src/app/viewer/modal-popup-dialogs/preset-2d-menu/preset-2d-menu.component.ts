import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';

import { WLPresetParams } from '../modal-popup.service';
import { IVOILUTPresetEntry, IPresetEntry, NO_VOI_LUT, PRESET_NOT_SET, PresetEntry, VOILutEntry, WindowLevel, WLInfo, WL_PROPAGATE_MODE, IWLPropagateMode, WLPropagateMode, WL_AUTO_MODE, WLAutoMode, WLResetMode, AUTO_WL_MODALITIES } from '../../models';
import { PanelBoundDialog } from '../../utils';
import { MatListOption } from '@angular/material/list';
import { Preset2dMenuService } from './preset-2d-menu.service';

interface IPresetGroupEntry {
  group: string;
  presets: IPresetEntry[];
  luts: IVOILUTPresetEntry[];
}

const Preset2DList: IPresetGroupEntry[] = [
  {
    group: 'Head and Neck', presets: [
      { title: 'Brain', w: 80, l: 40 },
      { title: 'Subdural 1', w: 300, l: 100 },
      { title: 'Subdural 2', w: 130, l: 50 },
      { title: 'Stroke', w: 40, l: 40 },
      { title: 'Temporal bones', w: 2800, l: 600 },
      { title: 'Soft tissues ', w: 360, l: 50 }],
    luts: []
  },
  {
    group: 'Chest', presets: [
      { title: 'Lungs', w: 1500, l: -600 },
      { title: 'Mediastinum', w: 350, l: 50 }],
    luts: []
  },
  {
    group: 'Abdomen', presets: [
      { title: 'Soft tissues', w: 400, l: 50 },
      { title: 'Liver', w: 150, l: 30 }],
    luts: []
  },
  {
    group: 'Spine and extremities', presets: [
      { title: 'Soft tissues', w: 250, l: 50 },
      { title: `Bone 1`, w: 1800, l: 400 },
      { title: 'Bone 2', w: 4000, l: 700 }],
    luts: []
  },
];

const DEFAULT_INDEX = 0;

@Component({
  standalone: false,
  selector: 'app-preset-2d-menu',
  templateUrl: './preset-2d-menu.component.html',
  styleUrls: ['./preset-2d-menu.component.scss']
})
export class WLPreset2DMenuComponent implements AfterViewInit {

  protected readonly wlPresetList: IPresetGroupEntry[] = [];
  protected readonly otherWLButtons: IPresetGroupEntry = { group: '', presets: [], luts: [] };
  protected readonly dicomPresetList: IPresetGroupEntry = { group: 'Dicom Header', presets: [], luts: [] };
  protected readonly autoWLList: IPresetGroupEntry = { group: 'Auto', presets: [], luts: [] };
  protected readonly propagationList: IPresetGroupEntry = { group: 'Tool action', presets: [], luts: [] };

  protected editable = false;
  protected selectedOptions: PresetEntry[] = [];
  private selectedPreset: IPresetEntry = new PresetEntry({ w: PRESET_NOT_SET, l: PRESET_NOT_SET, title: 'dummy' });
  private selectedDICOMLUT: | IVOILUTPresetEntry = new VOILutEntry({ i: NO_VOI_LUT, title: 'dummyvoi' });
  private isCT = false;
  private isMR = false;
  private usesPropagation = false;

  protected compareLUTFunction(o1: IVOILUTPresetEntry, o2: IVOILUTPresetEntry): boolean {
    return o1.i === o2.i;
  }
  protected compareFunction(o1: IPresetEntry, o2: IPresetEntry): boolean {
    return o1.w === o2.w && o1.l === o2.l;
  }

  private readonly MR_APPLY_TO_OPTIONS = [
    { label: 'Image', value: WL_PROPAGATE_MODE.ManualImage },
    { label: 'All images in the stack', value: WL_PROPAGATE_MODE.ManualSeries },
    { label: 'This image and following image series', value: WL_PROPAGATE_MODE.ManualFollowing },
  ];

  private readonly XRAY_APPLY_TO_OPTIONS = [
    { label: 'Image', value: WL_PROPAGATE_MODE.ManualImage },
    { label: 'All Series', value: WL_PROPAGATE_MODE.ManualSeries },
  ];

  protected applyToOptions: { label: string; value: WL_PROPAGATE_MODE; }[] = [];
  protected selectedPropagationMode: WL_PROPAGATE_MODE = WL_PROPAGATE_MODE.ManualSeries;

  private readonly MR_AUTO_WL_OPTIONS = [
    { label: 'Auto WL Image', value: WL_AUTO_MODE.AutoImage },
    { label: 'Auto WL Series', value: WL_AUTO_MODE.AutoSeries },
    { label: 'Auto WL image and following images', value: WL_AUTO_MODE.AutoFollowing },
  ];

  private readonly XRAY_AUTO_WL_OPTIONS = [
    { label: 'Auto WL Image', value: WL_AUTO_MODE.AutoImage },
    { label: 'Auto WL All Series', value: WL_AUTO_MODE.AutoSeries }
  ];

  protected autoWLOptions: { label: string; value: WL_AUTO_MODE; }[] = [];

  constructor(
    private matDialogRef: MatDialogRef<WLPreset2DMenuComponent, WindowLevel | WLPropagateMode | WLAutoMode | WLResetMode | null>,
    private elementRef: ElementRef,
    private preset2dMenuService: Preset2dMenuService,
    @Inject(MAT_DIALOG_DATA) private data: WLPresetParams) {

    if (this.data == null) {
      console.error(`WLPreset2DMenuComponent unexpected condition, missing data parameter`);
      return;
    }
    console.log(`WLPreset2DMenuComponent`, this.data);
    this.isCT = this.data.examSeries ? this.data.examSeries?.isModalityCT() : false;
    this.isMR = this.data.examSeries ? this.data.examSeries?.isModalityMR() : false;
    const modality = this.data.examSeries?.modality ?? '';
    this.usesPropagation = AUTO_WL_MODALITIES.includes(modality);

    this.wlPresetList = this.isCT ? Preset2DList : [];
    console.log(`PresetList ${this.wlPresetList.length}`, this.wlPresetList);
    // Provide DICOM header presets, if there were any WLs and VOILuts.
    this.dicomPresetList = this.setupDICOMPresetLists();
    // Establish the reset button to support VOI or WL values
    for (const wl of this.data.defaultWL) {
      if (wl.isVOILut) {
        this.otherWLButtons.luts.push({ title: '  Reset LUT', i: wl.voiLutIndex });
      } else {
        this.otherWLButtons.presets.push({ title: '  Reset WL', w: wl.width, l: wl.level });
      }
    }
    this.initSelection();
    this.editable = this.data.editable;
    this.selectedOptions = this.isCT ? this.preset2dMenuService.getPresetFavorites() : [];

    this.initAutoWLOptions();
    this.initApplyToOptions();
    this.initPropagationSelection();

    // If user presses ESC or clicks on background return nothing
    matDialogRef.backdropClick()
      .pipe(
        take(1)
      )
      .subscribe(() => {
        // Store the presets if they've changed.
        if (this.editable && this.selectedOptions !== this.preset2dMenuService.getPresetFavorites()) {
          this.preset2dMenuService.setPresetFavorites(this.selectedOptions);
        }
        matDialogRef.close(null);
      });
  }

  ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('preset-2d-menu', this.elementRef, this.data.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  protected onSelect(preset: IPresetEntry): void {
    // console.log(`user selected ${preset.view} ${preset.w} ${preset.l}`);
    const newWL = new WindowLevel(preset.w, preset.l);

    // Save the favorites in case they were changed prior to making a selection.
    if (this.editable) {
      this.preset2dMenuService.setPresetFavorites(this.selectedOptions);
    }
    this.matDialogRef.close(newWL);
  }

  protected onSelectResetWl(preset: IPresetEntry): void {
    this.matDialogRef.close(new WLResetMode(new WindowLevel(preset.w, preset.l)));
  }

  protected onSelectResetLUT(lut: IVOILUTPresetEntry): void {
    const wli = new WLInfo(lut.i, lut.title);
    this.matDialogRef.close(new WLResetMode(WindowLevel.fromWLInfo(wli)));
  }

  protected onSelectionChange(options: MatListOption[]): void {
    // This gives us the list of selections in the order they were selected.
    this.selectedOptions = options.map(o => o.value);
  }

  protected getItemText(preset: IPresetEntry): string {
    return new PresetEntry(preset).toString();
  }

  protected isDisabled(preset: IPresetEntry): boolean {
    if (this.selectedOptions.findIndex(option => this.compareFunction(option, preset)) === -1) {
      return this.selectedOptions.length > 8;
    }
    return false;
  }

  protected isFavorite(preset: IPresetEntry): boolean {
    return this.selectedOptions.findIndex(option => this.compareFunction(option, preset)) !== -1;
  }

  protected isSelected(preset: IPresetEntry): boolean {
    return this.compareFunction(this.selectedPreset, preset);
  }

  protected getTooltip(preset: IPresetEntry): string {
    const index = this.selectedOptions.findIndex(option => this.compareFunction(option, preset));
    if (index >= 0) {
      return `NumLock+${index + 1}`;
    }
    return '';
  }

  protected isDicomPresetSelected(preset: IPresetEntry): boolean {
    return this.compareFunction(this.selectedPreset, preset);
  }

  protected onSelectDicomPreset(preset: IPresetEntry): void {
    const newWL = new WindowLevel(preset.w, preset.l);
    // console.log(`onSelectDicomPreset user selected ${preset.title} ${preset.w} ${preset.l}`, newWL);
    this.matDialogRef.close(newWL);
  }

  protected getLUTItemText(lut: IVOILUTPresetEntry): string {
    return new VOILutEntry(lut).toString();
  }

  protected isDicomLUTSelected(lut: IVOILUTPresetEntry): boolean {
    return this.compareLUTFunction(this.selectedDICOMLUT, lut);
  }

  protected onSelectDicomLUT(lut: IVOILUTPresetEntry): void {
    const wli = new WLInfo(lut.i, lut.title);
    const newWL = WindowLevel.fromWLInfo(wli);
    // console.log(`onSelectDicomLUT user selected ${lut.title} ${lut.i}`, newWL);

    this.matDialogRef.close(newWL);
  }

  private initSelection(): void {
    if (this.data == null) {
      return;
    }

    if (this.data.currentWL.isVOILut) {
      this.selectedDICOMLUT = { i: this.data.currentWL.voiLutIndex, title: '' };
    } else {
      this.selectedPreset = { w: this.data.currentWL.width, l: this.data.currentWL.level, title: '' };
    }

    let foundIndex = -1;
    let foundLutIndex = -1;
    let foundGroup = -1;

    // Check the CT preset list
    if (this.isCT) {
      for (let group = 0; group < this.wlPresetList.length; group++) {
        foundIndex = this.wlPresetList[group].presets.findIndex((preset: IPresetEntry) => this.compareFunction(preset, this.selectedPreset));
        if (foundIndex > -1) {
          foundGroup = group;
          break;
        }
      }
      if (foundIndex > -1) {
        this.selectedPreset = this.wlPresetList[foundGroup].presets[foundIndex];
      }
    }
    // There might not be any DICOM presets available in the header
    if (this.dicomPresetList.luts.length > 0 || this.dicomPresetList.presets.length > 0) {
      // See if the current WL/VOI lut is from a DICOM preset
      if (foundIndex === -1) {
        foundIndex = this.dicomPresetList.presets.findIndex((preset: IPresetEntry) => this.compareFunction(preset, this.selectedPreset));
        if (foundIndex > -1) {
          this.selectedPreset = this.dicomPresetList.presets[foundIndex];
        }
      }
      if (foundLutIndex === -1) {
        foundLutIndex = this.dicomPresetList.luts.findIndex((lut: IVOILUTPresetEntry) => this.compareLUTFunction(lut, this.selectedDICOMLUT));
        if (foundLutIndex > -1) {
          this.selectedDICOMLUT = this.dicomPresetList.luts[foundLutIndex];
        }
      }
    }
    // Finally must be one of the defaults
    if (foundIndex === -1) {
      foundIndex = this.otherWLButtons.presets.findIndex((preset: IPresetEntry) => this.compareFunction(preset, this.selectedPreset));
      if (foundIndex > -1) {
        this.selectedPreset = this.otherWLButtons.presets[foundIndex];
      }
    }
    if (foundLutIndex === -1) {
      foundLutIndex = this.otherWLButtons.luts.findIndex((lut: IVOILUTPresetEntry) => this.compareLUTFunction(lut, this.selectedDICOMLUT));
      if (foundLutIndex > -1) {
        this.selectedDICOMLUT = this.otherWLButtons.luts[foundLutIndex];
      }
      // console.log(`initSelection()`, this.selectedPreset, this.selectedDICOMLUT);
    }

  }
  private setupDICOMPresetLists(): IPresetGroupEntry {
    // Assemble the DICOM presets to our list?
    for (const wlOption of this.data.wlOptions) {
      if (wlOption.isVOILut) {
        this.dicomPresetList.luts.push({ title: wlOption.getWLInfo().description, i: wlOption.voiLutIndex });
      } else {
        this.dicomPresetList.presets.push({ title: wlOption.getWLInfo().description, w: wlOption.width, l: wlOption.level });
      }
    }
    // console.log(`setupDICOMPresetLists`, presetGroupEntires);
    return this.dicomPresetList;
  }

  protected isPropagateModeSelected(option: string): boolean {
    return this.selectedPropagationMode === option;
  }

  private initPropagationSelection(): void {
    let favoritePropagate: WLPropagateMode | null = null;

    if (this.usesPropagation) {
      if (this.isMR) {
        favoritePropagate = this.preset2dMenuService.getMRWlPropagateModeFavorites();
      } else {
        favoritePropagate = this.preset2dMenuService.getXrayWlPropagateModeFavorites();
      }
    }
    if (favoritePropagate && favoritePropagate.type != null) {
      this.selectedPropagationMode = favoritePropagate.type;
    }
  }

  private initAutoWLOptions(): void {
    if (this.usesPropagation) {
      if (this.isMR) {
        this.autoWLOptions = this.MR_AUTO_WL_OPTIONS;
      } else {
        this.autoWLOptions = this.XRAY_AUTO_WL_OPTIONS;
      }
    }
  }

  private initApplyToOptions(): void {
    if (this.usesPropagation) {
      if (this.isMR) {
        this.applyToOptions = this.MR_APPLY_TO_OPTIONS;
      } else {
        this.applyToOptions = this.XRAY_APPLY_TO_OPTIONS;
      }
    }
  }

  protected onPropagateModeSelect(option: WL_PROPAGATE_MODE): void {
    this.selectedPropagationMode = option;
    const result = new WLPropagateMode(option, true);

    if (this.isMR) {
      this.preset2dMenuService.setMRWlPropagateModeFavorites(new WLPropagateMode(this.selectedPropagationMode));
    } else {
      this.preset2dMenuService.setXrayWlPropagateModeFavorites(new WLPropagateMode(this.selectedPropagationMode));
    }
    this.matDialogRef.close(result);
  }

  protected onAutoModeSelect(option: WL_AUTO_MODE): void {
    this.matDialogRef.close(new WLAutoMode(option));
  }
}
