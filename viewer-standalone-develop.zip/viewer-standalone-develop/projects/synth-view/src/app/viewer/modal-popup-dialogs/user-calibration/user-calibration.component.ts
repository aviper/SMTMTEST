import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserConfirmationComponent } from '../user-confirmation/user-confirmation.component';
import { PanelBoundDialogParams } from '../modal-popup.service';
import { PanelBoundDialog } from '../../utils';

@Component({
  selector: 'app-user-calibration',
  standalone: false,
  templateUrl: './user-calibration.component.html',
  styleUrl: './user-calibration.component.scss'
})
export class UserCalibrationComponent implements AfterViewInit {
  public initialValue = 0;
  public maximum = 9;

  private wholeNumberLineLength = 0;
  private decimalNumberLineLength = 0;

  constructor(private matDialogRef: MatDialogRef<UserConfirmationComponent,  number | null>,
              private elementRef: ElementRef,
              @Inject(MAT_DIALOG_DATA) private dlgData: PanelBoundDialogParams) {
  }

  ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('user-calibration-dialog', this.elementRef, this.dlgData.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  public onWholeNumberChanged(event: number): void {
    this.wholeNumberLineLength = event;
  }

  public onDecimalNumberChanged(event: number): void {
    this.decimalNumberLineLength = event;
  }

  public onCancel(): void {
    this.matDialogRef.close(null);
  }

  public onSave(): void {
    const number = parseFloat(`${this.wholeNumberLineLength}.${this.decimalNumberLineLength}`);
    if (number > 0) {
      this.matDialogRef.close(number);
    } else {
      alert('Length must be greater than 0');
    }
  }
}
