import { Injectable, OnDestroy, ViewContainerRef } from '@angular/core';
import { DialogPosition, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { ComponentType } from '@angular/cdk/portal';

import { WLPreset2DMenuComponent } from './preset-2d-menu/preset-2d-menu.component';
import { EdgeEnhancementLevel, EDGE_ENHANCEMENT_LEVEL_TYPE, ExamSeries, WindowLevel, WL_PROPAGATE_MODE, WLPropagateMode, WL_AUTO_MODE, WLAutoMode, WLResetMode } from '../models';
import { Bounds, Point } from '../utils';
import { IDicomTagDetails, HangingProtocol } from '@server-api';
import {
  SPINE_LABEL_TYPE,
  SpineLabelSelectionComponent
} from './spine-label-selection/spine-label-selection.component';
import { HelpAboutComponent } from './help-about/help-about.component';
import { environment, IEnvironment } from '../../../environments';
import { UserNotificationComponent } from './user-notification/user-notification.component';
import { DicomTagViewComponent } from './dicom-tag-view/dicom-tag-view.component';
import { EdgeEnhancementMenuComponent } from './edge-enhancement-menu/edge-enhancement-menu.component';
import { HPConfigViewComponent } from './hpconfig-view/hpconfig-view.component';
import { TextInputComponent } from '../adaptors/text-input/text-input.component';
import { take } from 'rxjs';
import { IManagedService, registerService, ViewerSettingsService } from '../services';
import { PresetColorPaletteMenuComponent } from './preset-color-palette-menu/preset-color-palette-menu.component';
import { UserConfirmationComponent } from './user-confirmation/user-confirmation.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import { VisionMenuComponent } from './vision-menu/vision-menu.component';
import { ButtonDefinition } from '../tools';
import { UserCalibrationComponent } from './user-calibration/user-calibration.component';

// Provides information is needed to launch the dialog
export class LaunchParams implements IParams {
  public top: number;
  public left: number;
  public panelBounds: Bounds | null;
  public class_selector: string;
  public name: string;
  public disableClose: boolean;

  constructor(upperLeft: Point, panelBounds: Bounds | null = null) {
    this.top = upperLeft.y;
    this.left = upperLeft.x;
    this.panelBounds = panelBounds;
    this.class_selector = '';
    this.name = '';
    this.disableClose = false;
  }
}

export class PanelBoundDialogParams {
  constructor(public panelBounds: Bounds | null) {}
}

// Must derive from BaseParams, this object is passed to the dialog to be opened.
// It is provided through the params field of MatDialogConfig
export class EdgeEnhancementParams {
  constructor(public selectedLevel: EDGE_ENHANCEMENT_LEVEL_TYPE, public panelBounds: Bounds | null) {
  }
}

export class WLPresetParams {
  constructor(public currentWL: WindowLevel, public defaultWL: WindowLevel[], public editable: boolean, public panelBounds: Bounds | null,
              public wlOptions: WindowLevel[], public examSeries: ExamSeries | null = null, public selectedPropagation: WL_PROPAGATE_MODE | null = null) {
  }
}

export class WLPropagateParams {
  constructor(public modality: string | null = null, public selectedPropagation: WL_PROPAGATE_MODE, public panelBounds: Bounds | null,
              ) {
  }
}
export class PresetColorPaletteParams {
  constructor(public editable: boolean, public selectedPreset: string, public panelBounds: Bounds | null) {
  }
}

export class SpineLabelParams {
  constructor(public currentOption: SPINE_LABEL_TYPE, public panelBounds: Bounds | null) {
  }
}

export class HelpAboutParams {
  constructor(private env: IEnvironment, public panelBounds: Bounds | null) {
    // console.log(`HelpAboutParams Environment ${this.toString()}`);
  }

  public get versionNumber(): string {
    return this.env.version;
  }

  public get UDI(): string {
    return this.env.UDI;
  }

  public toString(): string {
    return `Version: ${this.env.version} \nDate: ${this.env.buildDate.slice(0, 10)} \nTime: ${this.env.buildDate.slice(10)}\nHash: ${this.env.commitHash}`;
  }
}

export class UserNotificationParams {
  // Consider making dialog height a property to allow this
  // to accommodate big and small
  constructor(public userMessage: string = '',
              public additionalInfo: string[] = [],
              public showButton: boolean = true) { }
}

export class UserConfirmationParams {
  constructor(public userMessage: string = '',
              public title: string = '',
              public confirmationButtonText: string = 'OK',
              public cancelButtonText: string = 'Cancel') { }
}

export class ProgressBarParams {
  constructor(public title: string = '') {}
}


export class DicomTagViewParams {
  constructor(public entries: IDicomTagDetails[], public panelBounds: Bounds | null = null, public nonImageTags: DicomTagViewParams[] = []) { }
}

export class HPParams {
  constructor(public HP: HangingProtocol, public panelBounds: Bounds | null) { }
}

export class TextInputParams {
  public constructor(public top: number, public left: number, public panelBounds: Bounds | null, public originalText: string = '') { }
}

export class TextOutputParams {
  public constructor(public panelBounds: Bounds | null, public originalText: string = '') { }
}

export class VisionMenuParams {
  public constructor(public panelBounds: Bounds | null) {
  }
}


export class SaveReadingResultsWarning extends UserNotificationParams {
  constructor() {
    super();
    this.userMessage = 'WARNING! The following problems were encountered. Please report this problem to support.';
  }
  public GSPSSaveFailed(): void {
    this.additionalInfo.push('Annotations were NOT saved.');
  }
  public KOSaveFailed(): void {
    this.additionalInfo.push('Key images were NOT saved.');
  }
  public deletionFailed(): void {
    this.additionalInfo.push('Deletion was NOT performed.');
  }
  public hasSomethingForNotification(): boolean {
    return this.additionalInfo.length > 0;
  }
}

export interface IParams {
  // Provide data for dialog position
  top: number;
  left: number;
  // Provide a name to be used for tracking this dialog
  name: string;
  class_selector: string;
  disableClose?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ModalPopupService implements IManagedService, OnDestroy {
  private dialogRef: MatDialogRef<any> | null = null;
  /*
  This service is able to open any modal dialog as long as it meets interface requirements
  1. Open a modal dialog, providing:
    a. an arbitrary data type to assist with initialization as PARAMS. This is passed in the .data field of MatDialogConfig object
    b. an arbitrary component that is to be used as the context menu
    c. an arbitrary class (or any) which will be returned when the dialog is complete
    d. ViewContainerRef is a mechanism by which we may export the context of the parent for use for this context menu
        e.g. any component provided services (as we do with ViewportComponent)
  */

  constructor(private dialog: MatDialog, private viewerSettingsService: ViewerSettingsService) {
    registerService(this);
  }


  // Open a WL 2D Preset Dialog, returns a WL if selected by the user null otherwise
  public openWLPresetDialog(
    wl: WindowLevel,
    defaultWL: WindowLevel[],
    editable: boolean,
    launchParams: LaunchParams,
    dicomWLOptions: WindowLevel[] = [],
    examSeries: ExamSeries | null = null,
    selectedPropagation: WL_PROPAGATE_MODE | null = null,
    viewContainerRef: ViewContainerRef | undefined = undefined): MatDialogRef<WLPreset2DMenuComponent, WindowLevel | WLPropagateMode | WLAutoMode | WLResetMode | null> {

    const dialogWidth = 300;
    const dialogHeight = 373;
    launchParams.left = Math.min(launchParams.left, Math.max(window.innerWidth - dialogWidth, 0));
    launchParams.top = Math.min(launchParams.top, Math.max(window.innerHeight - dialogHeight, 0));

    launchParams.name = 'WL Presets'; // Must be provided, suspect it must be unique among dialog components
    const wlPresetParams: WLPresetParams = new WLPresetParams(wl, defaultWL, editable, launchParams.panelBounds, dicomWLOptions, examSeries, selectedPropagation);
    return this.openModalDialog<WLPreset2DMenuComponent, WLPresetParams, WindowLevel | WLPropagateMode | WLAutoMode | WLResetMode | null>
        (WLPreset2DMenuComponent, launchParams, wlPresetParams, viewContainerRef);
  }

  public openPresetColorPaletteDialog(
    editable: boolean,
    selectedPreset: string,
    launchParams: LaunchParams,
    viewContainerRef: ViewContainerRef | undefined = undefined): MatDialogRef<PresetColorPaletteMenuComponent, string | null> {

    const dialogWidth = 300;
    const dialogHeight = 373;
    launchParams.left = Math.min(launchParams.left, Math.max(window.innerWidth - dialogWidth, 0));
    launchParams.top = Math.min(launchParams.top, Math.max(window.innerHeight - dialogHeight, 0));

    launchParams.name = 'Color Palette Presets'; // Must be provided, suspect it must be unique among dialog components
    const presetColorPaletteParams: PresetColorPaletteParams = new PresetColorPaletteParams(editable, selectedPreset, launchParams.panelBounds);
    return this.openModalDialog<PresetColorPaletteMenuComponent, PresetColorPaletteParams, string | null>
        (PresetColorPaletteMenuComponent, launchParams, presetColorPaletteParams, viewContainerRef);
  }

  public openSpineLabelDialog(selectedType: SPINE_LABEL_TYPE, launchParams: LaunchParams): MatDialogRef<SpineLabelSelectionComponent, SPINE_LABEL_TYPE> {

    const dialogWidth = 200;
    const dialogHeight = 380;
    launchParams.left = Math.min(launchParams.left, Math.max(window.innerWidth - dialogWidth, 0));
    launchParams.top = Math.min(launchParams.top, Math.max(window.innerHeight - dialogHeight, 0));

    launchParams.name = 'Spine Label Options';
    launchParams.class_selector = 'spine-label-selection-menu';
    return this.openModalDialog<SpineLabelSelectionComponent, SpineLabelParams, SPINE_LABEL_TYPE>
        (SpineLabelSelectionComponent, launchParams, new SpineLabelParams(selectedType, launchParams.panelBounds ?? null), undefined);
  }

  public openUserCalibrationDialog(launchParams: LaunchParams): MatDialogRef<UserCalibrationComponent, number> {
    const dialogWidth = 300;
    const dialogHeight = 300;
    launchParams.left = Math.min(launchParams.left, Math.max(window.innerWidth - dialogWidth, 0));
    launchParams.top = Math.min(launchParams.top, Math.max(window.innerHeight - dialogHeight, 0));

    launchParams.name = 'User Calibration';
    launchParams.class_selector = 'user-calibration-dialog';
    return this.openModalDialog<UserCalibrationComponent, PanelBoundDialogParams, number>(UserCalibrationComponent, launchParams, new PanelBoundDialogParams(launchParams.panelBounds), undefined);
  }

  public isUserCalibrationDialogOpen(): boolean {
    const modalRef = this.dialog.getDialogById('User Calibration');
    return modalRef != null;
  }

  // Open a Edge Enhancement Dialog
  public openEdgeEnhancementDialog(
    selectedLevel: EDGE_ENHANCEMENT_LEVEL_TYPE,
    launchParams: LaunchParams,
    viewContainerRef: ViewContainerRef | undefined = undefined): MatDialogRef<EdgeEnhancementMenuComponent, EdgeEnhancementLevel> {

    const dialogWidth = 300;
    const dialogHeight = 373;
    launchParams.left = Math.min(launchParams.left, Math.max(window.innerWidth - dialogWidth, 0));
    launchParams.top = Math.min(launchParams.top, Math.max(window.innerHeight - dialogHeight, 0));

    launchParams.name = 'Edge Enhancement Level'; // Must be provided, suspect it must be unique among dialog components
    const edgeEnhancementParams: EdgeEnhancementParams = new EdgeEnhancementParams(selectedLevel, launchParams.panelBounds);
    return this.openModalDialog<EdgeEnhancementMenuComponent, EdgeEnhancementParams, EdgeEnhancementLevel>
    (EdgeEnhancementMenuComponent, launchParams, edgeEnhancementParams, viewContainerRef);
  }

  public openHelpAboutDialog(panelBounds: Bounds | null): MatDialogRef<HelpAboutComponent, undefined> {
    // Use the optimal size if possible. Limit to the viewer window dimensions if necessary.
    const dialogWidth = Math.min(832, window.innerWidth);
    const dialogHeight = Math.min(890, window.innerHeight);
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'Help About';
    launchParams.class_selector = 'help-about-window';
    return this.openModalDialog<HelpAboutComponent, HelpAboutParams, undefined>
        (HelpAboutComponent, launchParams, new HelpAboutParams(environment, panelBounds), undefined);
  }

  public openUserNotificationDialog(params: UserNotificationParams, forAsync: boolean = false): MatDialogRef<UserNotificationComponent, undefined> {
    const dialogWidth = .25 * window.innerWidth;
    const dialogHeight = .20 * window.innerHeight;
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'User Notification';
    launchParams.class_selector = 'user-notification-dialog';
    return this.openModalDialog<UserNotificationComponent, UserNotificationParams, undefined>
      (UserNotificationComponent, launchParams, params, undefined, forAsync);
  }

  public openUserConfirmationDialog(params: UserConfirmationParams, forAsync: boolean = false): MatDialogRef<UserConfirmationComponent, boolean> {
    const dialogWidth = .25 * window.innerWidth;
    const dialogHeight = .20 * window.innerHeight;
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'User Confirmation';
    launchParams.class_selector = 'user-confirmation-dialog';
    launchParams.disableClose = true;
    return this.openModalDialog<UserConfirmationComponent, UserConfirmationParams, boolean>
      (UserConfirmationComponent, launchParams, params, undefined, forAsync);
  }

  public openProgressBarDialog(params: ProgressBarParams): MatDialogRef<ProgressBarComponent, void> {
    const dialogWidth = .25 * window.innerWidth;
    const dialogHeight = .20 * window.innerHeight;
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'Progress Dialog';
    launchParams.class_selector = 'progress-bar-dialog';
    launchParams.disableClose = true;
    return this.openModalDialog<ProgressBarComponent, ProgressBarParams, void>(ProgressBarComponent, launchParams, params, undefined);
  }

  public openDicomTagDialog(tagParams: DicomTagViewParams): MatDialogRef<DicomTagViewComponent, undefined> {
    // Use the optimal size if possible. Limit to the viewer window dimensions if necessary.
    const dialogWidth = Math.min(1150, window.innerWidth);
    const dialogHeight = Math.min(1360, window.innerHeight);
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'DICOM Tags';
    launchParams.class_selector = 'dicom-tag-view-dialog';
    return this.openModalDialog<DicomTagViewComponent, DicomTagViewParams, undefined>
        (DicomTagViewComponent, launchParams, tagParams, undefined);
  }

  public openHPDialog(params: HPParams): MatDialogRef<HPConfigViewComponent, undefined> {
    // Use the optimal size if possible. Limit to the viewer window dimensions if necessary.
    const dialogWidth = Math.min(700, window.innerWidth);
    const dialogHeight = Math.min(500, window.innerHeight);
    const launchParams: LaunchParams = new LaunchParams(new Point());

    launchParams.left = (window.innerWidth / 2) - (dialogWidth / 2);
    launchParams.top = (window.innerHeight / 2) - (dialogHeight / 2);
    launchParams.name = 'Hanging Protocol';
    launchParams.class_selector = 'hpconfig-view-dialog';
    return this.openModalDialog<HPConfigViewComponent, HPParams, undefined>(HPConfigViewComponent, launchParams, params, undefined);
  }

  public openTextDialog(textParams: TextInputParams): MatDialogRef<TextInputComponent> {
    const launchParams: LaunchParams = new LaunchParams(new Point(textParams.left, textParams.top));
    const textDataParams: TextOutputParams = new TextOutputParams(textParams.panelBounds, textParams.originalText);

    launchParams.name = 'Annotation Text Input';
    launchParams.class_selector = 'text-input-dialog';
    return this.openModalDialog<TextInputComponent, TextOutputParams, string>(TextInputComponent, launchParams, textDataParams, undefined);
  }

  public openVisionMenu(launchParams: LaunchParams, viewContainerRef: ViewContainerRef | undefined = undefined): MatDialogRef<VisionMenuComponent, ButtonDefinition | null> {
    launchParams.name = 'Vision Viewer Menu';
    const visionMenuParams: VisionMenuParams = new VisionMenuParams(launchParams.panelBounds);
    return this.openModalDialog<VisionMenuComponent, VisionMenuParams, ButtonDefinition | null>
        (VisionMenuComponent, launchParams, visionMenuParams, viewContainerRef);
  }

  private openModalDialog<CONTEXT_MENU_COMPONENT, PARAMS, DIALOG_RESULT>(
    component: ComponentType<CONTEXT_MENU_COMPONENT>,
    launchParams: IParams,
    data: PARAMS,
    viewContainerRef: ViewContainerRef | undefined,
    forAsync: boolean = false): MatDialogRef<CONTEXT_MENU_COMPONENT, DIALOG_RESULT> {
    let config: MatDialogConfig<PARAMS> = {};

    if (data) {
      const dlgPosition: DialogPosition = { top: (launchParams.top).toString() + 'px', left: (launchParams.left).toString() + 'px' };
      config = {
        id: launchParams.name,
        disableClose: launchParams.disableClose != null ? launchParams.disableClose : false,
        autoFocus: false,
        panelClass: launchParams.class_selector,
        position: dlgPosition,
        viewContainerRef: viewContainerRef,
        data: data
      };
    }
    const dialogRef = this.dialog.open(component, config);
    // Let the caller handle the close
    if (forAsync) {
      this.dialogRef = dialogRef;
      return dialogRef;
    }
    // Detect when the dialog is opened and keep track until it's closed.
    dialogRef.afterOpened()
      .pipe(
        take(1)
      )
      .subscribe(spineLabelType => {
        // console.log(`Modal popup open activeViewport: '${this.viewerSettingsService.activeViewport}'`);
        this.dialogRef = dialogRef;
      });

    dialogRef.afterClosed()
      .pipe(
        take(1)
      )
      .subscribe(spineLabelType => {
        this.dialogRef = null;
      });

    return dialogRef;
  }

  public get isOpen(): boolean {
    return this.dialogRef !== null;
  }

  // used with async flag on open to rendezvous with the close
  public async waitForClose(): Promise<void> {
    const dialogRef = this.dialogRef;
    if (dialogRef) {
      await dialogRef.afterClosed().toPromise();
      this.dialogRef = null;
    }
  }
  public async reInitData(bComparison: boolean = false): Promise<void> {
  }

  public async reStartSubscriptions(): Promise<void> {
  }

  public async stopProcessing(): Promise<void> {
    if (this.dialogRef) {
      console.error(`Forcing Dialog to close`);
      this.dialogRef.close();
    }
  }
  public ngOnDestroy(): void {
    this.stopProcessing().then();
  }
}
