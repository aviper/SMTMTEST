import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';

import { SpineLabelParams } from '../modal-popup.service';
import { PanelBoundDialog } from '../../utils/';

export enum SPINE_LABEL_TYPE {
  NONE = '',
  V1 = '1', V2 = '2', V3 = '3', V4 = '4', V5 = '5', V6 = '6',
  V7 = '7', V8 = '8', V9 = '9', V10 = '10', V11 = '11', V12 = '12',
  D1_2 = '1/2', D2_3 = '2/3', D3_4 = '3/4', D4_5 = '4/5', D5_6 = '5/6', D6_7 = '6/7',
  D7_1 = '7/1', D7_8 = '7/8', D8_9 = '8/9', D9_10 = '9/10', D10_11 = '10/11', D11_12 = '11/12',
  D12_1 = '12/1', D5_1 = '5/1', D6_1 = '6/1'
}

interface ISpineLabelEntry {
  title: string;
  type: SPINE_LABEL_TYPE;
  selected?: boolean;
}

class PresetEntry implements ISpineLabelEntry {
  public title: string;
  public type: SPINE_LABEL_TYPE;

  constructor(entry: ISpineLabelEntry) {
    this.title = entry.title;
    this.type = entry.type;
  }

  public toString(): string {
    return `Title ${this.title} ${this.type}  `;
  }
}

interface ISpineLabelGroupEntry {
  group: string;
  options: ISpineLabelEntry[];
}

const spineLabelList: ISpineLabelGroupEntry[] = [
  {
    group: ' Vertebrae', options: [
      { title: SPINE_LABEL_TYPE.V1.toString(), type: SPINE_LABEL_TYPE.V1 },
      { title: SPINE_LABEL_TYPE.V2.toString(), type: SPINE_LABEL_TYPE.V2 },
      { title: SPINE_LABEL_TYPE.V3.toString(), type: SPINE_LABEL_TYPE.V3 },
      { title: SPINE_LABEL_TYPE.V4.toString(), type: SPINE_LABEL_TYPE.V4 },
      { title: SPINE_LABEL_TYPE.V5.toString(), type: SPINE_LABEL_TYPE.V5 },
      { title: SPINE_LABEL_TYPE.V6.toString(), type: SPINE_LABEL_TYPE.V6 },
      { title: SPINE_LABEL_TYPE.V7.toString(), type: SPINE_LABEL_TYPE.V7 },
      { title: SPINE_LABEL_TYPE.V8.toString(), type: SPINE_LABEL_TYPE.V8 },
      { title: SPINE_LABEL_TYPE.V9.toString(), type: SPINE_LABEL_TYPE.V9 },
      { title: SPINE_LABEL_TYPE.V10.toString(), type: SPINE_LABEL_TYPE.V10 },
      { title: SPINE_LABEL_TYPE.V11.toString(), type: SPINE_LABEL_TYPE.V11 },
      { title: SPINE_LABEL_TYPE.V12.toString(), type: SPINE_LABEL_TYPE.V12 },
    ]
  },
  {
    group: ' Discs', options: [
      { title: SPINE_LABEL_TYPE.D1_2.toString(), type: SPINE_LABEL_TYPE.D1_2 },
      { title: SPINE_LABEL_TYPE.D2_3.toString(), type: SPINE_LABEL_TYPE.D2_3 },
      { title: SPINE_LABEL_TYPE.D3_4.toString(), type: SPINE_LABEL_TYPE.D3_4 },
      { title: SPINE_LABEL_TYPE.D4_5.toString(), type: SPINE_LABEL_TYPE.D4_5 },
      { title: SPINE_LABEL_TYPE.D5_6.toString(), type: SPINE_LABEL_TYPE.D5_6 },
      { title: SPINE_LABEL_TYPE.D6_7.toString(), type: SPINE_LABEL_TYPE.D6_7 },
      { title: SPINE_LABEL_TYPE.D7_1.toString(), type: SPINE_LABEL_TYPE.D7_1 },
      { title: SPINE_LABEL_TYPE.D7_8.toString(), type: SPINE_LABEL_TYPE.D7_8 },
      { title: SPINE_LABEL_TYPE.D8_9.toString(), type: SPINE_LABEL_TYPE.D8_9 },
      { title: SPINE_LABEL_TYPE.D9_10.toString(), type: SPINE_LABEL_TYPE.D9_10 },
      { title: SPINE_LABEL_TYPE.D10_11.toString(), type: SPINE_LABEL_TYPE.D10_11 },
      { title: SPINE_LABEL_TYPE.D11_12.toString(), type: SPINE_LABEL_TYPE.D11_12 },
      { title: SPINE_LABEL_TYPE.D12_1.toString(), type: SPINE_LABEL_TYPE.D12_1 },
      { title: SPINE_LABEL_TYPE.D5_1.toString(), type: SPINE_LABEL_TYPE.D5_1 },
      { title: SPINE_LABEL_TYPE.D6_1.toString(), type: SPINE_LABEL_TYPE.D6_1 },
    ]
  },
];

@Component({
  standalone: false,
  selector: 'app-spine-label-selection',
  templateUrl: './spine-label-selection.component.html',
  styleUrls: ['./spine-label-selection.component.scss']
})
export class SpineLabelSelectionComponent implements AfterViewInit {
  public readonly spineLabelList: ISpineLabelGroupEntry[];

  constructor(
    private matDialogRef: MatDialogRef<SpineLabelSelectionComponent, SPINE_LABEL_TYPE | null>,
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) private dlgData: SpineLabelParams) {

    this.spineLabelList = spineLabelList;

    if (this.dlgData != null) {
      this.setMatchingSelection(this.dlgData.currentOption, true);
    }

    // If user presses ESC or clicks on background return nothing
    matDialogRef.backdropClick()
      .pipe(
        take(1)
      ).subscribe(() => {
        this.setMatchingSelection(this.dlgData.currentOption, false);
        matDialogRef.close(null);
      });
  }

  ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('spine-label-selection-menu', this.elementRef, this.dlgData.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  public onSelect(option: ISpineLabelEntry): void {
    // Clear our selection
    this.setMatchingSelection(this.dlgData.currentOption, false);
    this.matDialogRef.close(option.type);
  }

  private setMatchingSelection(option: SPINE_LABEL_TYPE, set: boolean): void {
    for (let group = 0; group < this.spineLabelList.length; group++) {
      const index = this.spineLabelList[group].options.findIndex((listItem: ISpineLabelEntry) =>
        listItem.type === option);
      if (index !== -1) {
        this.spineLabelList[group].options[index].selected = (set ? set : undefined);
        break;
      }
    }
  }
}
