import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EdgeEnhancementMenuComponent } from './edge-enhancement-menu.component';

describe('EdgeEnhancementMenuComponent', () => {
  let component: EdgeEnhancementMenuComponent;
  let fixture: ComponentFixture<EdgeEnhancementMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EdgeEnhancementMenuComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EdgeEnhancementMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
