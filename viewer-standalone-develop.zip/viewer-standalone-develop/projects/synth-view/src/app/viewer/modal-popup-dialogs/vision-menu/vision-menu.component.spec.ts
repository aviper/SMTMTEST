import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisionMenuComponent } from './vision-menu.component';

describe('VisionMenuComponent', () => {
  let component: VisionMenuComponent;
  let fixture: ComponentFixture<VisionMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VisionMenuComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VisionMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
