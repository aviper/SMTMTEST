import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCalibrationComponent } from './user-calibration.component';

describe('UserCalibrationComponent', () => {
  let component: UserCalibrationComponent;
  let fixture: ComponentFixture<UserCalibrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserCalibrationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserCalibrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
