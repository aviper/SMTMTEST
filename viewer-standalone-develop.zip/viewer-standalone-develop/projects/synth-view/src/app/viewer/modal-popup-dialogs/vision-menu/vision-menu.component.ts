import { AfterViewInit, Component, ElementRef, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';
import { PanelBoundDialog } from '../../utils';
import { VisionMenuParams } from '../modal-popup.service';
import { ButtonDefinition, GetToolButton, TOOL_TYPE } from '../../tools';

@Component({
  selector: 'app-vision-menu',
  standalone: false,
  templateUrl: './vision-menu.component.html',
  styleUrl: './vision-menu.component.scss'
})
export class VisionMenuComponent implements AfterViewInit {
  protected options: ButtonDefinition[] = [];

  constructor(
    private matDialogRef: MatDialogRef<VisionMenuComponent, ButtonDefinition | null>,
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) private data: VisionMenuParams) {

    this.options.push(GetToolButton(TOOL_TYPE.eReloadExams));
    this.options.push(GetToolButton(TOOL_TYPE.eToggleDICOM));
    this.options.push(GetToolButton(TOOL_TYPE.eToggleThumbnail));
    this.options.push(GetToolButton(TOOL_TYPE.eNavWorklist));

    // If user presses ESC or clicks on background return nothing
    matDialogRef.backdropClick()
      .pipe(
        take(1)
      )
      .subscribe(() => {
        // Store the presets if they've changed.
        matDialogRef.close(null);
      });
  }

  ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('vision-viewer-menu', this.elementRef, this.data.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  protected onSelect(buttonDefinition: ButtonDefinition): void {
    this.matDialogRef.close(buttonDefinition);
  }
}
