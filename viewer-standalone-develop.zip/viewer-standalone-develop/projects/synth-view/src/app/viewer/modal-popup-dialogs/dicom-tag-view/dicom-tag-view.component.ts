import { AfterViewInit, Component, ElementRef, HostListener, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DicomTagViewParams } from '../modal-popup.service';
import { DICOM_ALLTAGS, IDicomTagDetails, SOP_CLASS } from '@server-api';
import { PanelBoundDialog } from '../../utils';


export enum KEY {
  PAGE_DOWN = 'PageDown',
  PAGE_UP = 'PageUp'
};

const CURRENT_IMAGE_TITLE = 'Current Image';
const KO_TITLE = 'Key Object';
const GSPS_TITLE = 'GSPS Object';
const OTHER_TITLE = 'DICOM Document';

const NAV_MESSAGE = '(PageDown/PageUp for next/previous)';
@Component({
  standalone: false,
  selector: 'app-dicom-tag-view',
  templateUrl: './dicom-tag-view.component.html',
  styleUrl: './dicom-tag-view.component.scss'
})
export class DicomTagViewComponent implements AfterViewInit {
  protected clipboardText = '';
  private _titles: string[] = [];

  constructor(
    private matDialogRef: MatDialogRef<DicomTagViewComponent, string>,
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) private data: DicomTagViewParams) {
    this.dicomObjectCount = this.data.nonImageTags.length + 1;
    this.createTitles();
    this.setTitle();
  }
  // We can show several DICOM objects for this study
  // The current image + number of non-image objects in the entire study
  private dicomObjectCount = 0;
  private currentIndex = 0;
  public title = '';
  public navInfo = NAV_MESSAGE;
  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.key == KEY.PAGE_DOWN) {
      // next page
      this.currentIndex = Math.min(this.currentIndex + 1, this.dicomObjectCount - 1);
      console.log(event);
      event.stopPropagation();
      this.setTitle();
    } else if (event.key == KEY.PAGE_UP) {
      // previous page
      this.currentIndex = Math.max(0, this.currentIndex - 1);
      console.log(event);
      event.stopPropagation();
      this.setTitle();
    }
  }

  protected get entries(): IDicomTagDetails[] {
    return this.currentIndex === 0 ? this.data.entries : this.data.nonImageTags[this.currentIndex - 1].entries;
  }

  ngAfterViewInit(): void {
    if (this.data.panelBounds) {
      const panelBoundDialog = new PanelBoundDialog('dicom-tag-view-dialog', this.elementRef, this.data.panelBounds);
      const position = panelBoundDialog.centerPanelBoundDialogPosition();
      if (position) {
        this.matDialogRef.updatePosition({ top: position.top, left: position.left });
      }
    }
  }

  protected onClose(): void {
    this.matDialogRef.close();
  }

  protected copyToClipboard(): void {
    this.clipboardText = '';
    const currentEntries = this.entries;
    const array: string[] = [];
    for (const entry of currentEntries) {
      this.clipboardText += `${entry.key}\t${entry.description}\t\t${entry.value}\n`;
    }
  }

  private setTitle(): void {
    const fullTitle = `${this._titles[this.currentIndex]} ${this.currentIndex + 1}/${this.dicomObjectCount}`;
    this.title = fullTitle;
  }

  private createTitles(): void {
    this._titles.push(CURRENT_IMAGE_TITLE);
    for (const tags of this.data.nonImageTags) {
      const title = this.getTitleFromDocument(tags.entries);
      this._titles.push(title);
    }
  }

  private getTitleFromDocument(entries: IDicomTagDetails[]): string {
    let sopClass = '';
    // Find the SOP class field value
    for (const entry of entries) {
      switch (entry.key) {
        case DICOM_ALLTAGS.MediaStorageSOPClassUID:
        case DICOM_ALLTAGS.SOPClassUID:
          sopClass = entry.value;
          break;
      }
      if (sopClass.length > 0) {
        break;
      }
    }
    // Provide titles for specific kinds of documents
    if (sopClass === SOP_CLASS.GSPS) {
      return GSPS_TITLE;
    } else if (sopClass === SOP_CLASS.KEY) {
      return KO_TITLE;
    }
    return OTHER_TITLE;

  }
}
