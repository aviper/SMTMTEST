import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserConfirmationParams } from '../modal-popup.service';

@Component({
  selector: 'app-user-confirmation',
  standalone: false,
  templateUrl: './user-confirmation.component.html',
  styleUrl: './user-confirmation.component.scss'
})
export class UserConfirmationComponent {
  constructor(
    private matDialogRef: MatDialogRef<UserConfirmationComponent, boolean>,
    @Inject(MAT_DIALOG_DATA) private data: UserConfirmationParams
  ) {
  }

  public get message(): string {
    return this.data.userMessage;
  }

  public onOK(): void {
    this.matDialogRef.close(true);
  }

  public onCancel(): void {
    this.matDialogRef.close(false);
  }

  public get title(): string {
    return this.data.title;
  }

  protected get confirmButtonText(): string {
    return this.data.confirmationButtonText;
  }

  protected get cancelButtonText(): string {
    return this.data.cancelButtonText;
  }
}
