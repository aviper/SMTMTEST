import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { registerService, ViewerSettingsService } from '../../services';
import { EdgeEnhancementLevel } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class EdgeEnhancementMenuService {
  private unsubscribe$$ = new Subject<void>();

  constructor(private viewerSettingsService: ViewerSettingsService) {
    registerService(this);
    this.subscriptions();
  }

  public async stopProcessing(): Promise<void> {
    this.unsubscribe();
  }

  public async reInitData(bComparison: boolean = false): Promise<void> {
  }

  public async reStartSubscriptions(): Promise<void> {
    this.subscriptions();
  }

  public getEdgeEnhancementLevelFavorites(): EdgeEnhancementLevel | null {
    return this.viewerSettingsService.edgeEnhancementLevelFavorites;
  }

  public setEdgeEnhancementLevelFavorites(faves: EdgeEnhancementLevel | null): void {
    this.viewerSettingsService.edgeEnhancementLevelFavorites = faves;
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  private subscriptions(): void {
  }

  public ngOnDestroy(): void {
    this.stopProcessing().then();
  }

}
