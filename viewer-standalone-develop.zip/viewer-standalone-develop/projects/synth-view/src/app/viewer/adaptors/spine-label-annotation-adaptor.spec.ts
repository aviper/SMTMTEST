import { SpineLabelAnnotationAdaptor } from './spine-label-annotation-adaptor';

describe('SpineLabelAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new SpineLabelAnnotationAdaptor()).toBeTruthy();
  });
});
