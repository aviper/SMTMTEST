import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import Fovia from 'foviaapi';
import { CIRCLE_ANNOTATION_LAYER } from './adaptor-constants';
import { firstValueFrom, take } from 'rxjs';
import { ModalPopupService, TextInputParams } from '../modal-popup-dialogs';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';

export class CircleAnnotationAdaptor extends AbstractAnnotationAdaptor {
  protected anchorPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxTopLeftPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxBottomRightPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected startPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);

  constructor(viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    private modalPopupService: ModalPopupService,
    adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, false, adaptorService);
    this.graphicLayer = CIRCLE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.circle;
    this.supportsGenericDicomGraphicType = true;
  }

  /**
   * @description called when the user releases the mouse
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.graphicAnnotation != null) {
      const viewportAdaptor = this.viewport.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);

      const adapter = viewportAdaptor.getCircleAnnotationAdaptor();
      const panelBounds = adapter?.adaptorService?.getPanelBoundsByViewportId(this.viewport.getHtmlElementName()) ?? null;

      // Display the text input dialog approximately at the mouse position.
      const config: TextInputParams = new TextInputParams(event.y, event.x, panelBounds, '');
      const textDialogRef = this.modalPopupService.openTextDialog(config);
      let userText = '';

      // Keep the most current user text in case a user closes the dialog by clicking away from the dialog,
      // which results in 'undefined' being returned by the dialog instead of the text.
      textDialogRef.componentInstance.userTextChange.subscribe((text: string) => {
        userText = text;
      });

      // Detect when the dialog is opened and keep track until it's closed.
      textDialogRef.afterOpened()
        .pipe(
          take(1)
        )
        .subscribe(_ => {
          viewportAdaptor.textEditActive = true;
        });

      let encodedUserText = '';
      let dicomCharSet = this.renderEngine.getDicomCharSet();
      await firstValueFrom(textDialogRef.afterClosed())
        .then(result => {
          if (result === undefined) {
            // If a user closes the dialog by clicking away from the dialog then result is undefined and
            // we'll use what we've been given via the userTextChange observable.
            result = userText;
          }
          if (result !== '') {
            if (dicomCharSet) {
              dicomCharSet = Fovia.Util.getEncodingType(dicomCharSet);
              const data = Fovia.Util.convertFromHexStr(result, dicomCharSet);
              encodedUserText = window.btoa(decodeURI(encodeURIComponent(data)));
            } else {
              encodedUserText = btoa(result);
            }
          }
          viewportAdaptor.textEditActive = false;
        });

      if (encodedUserText !== '') {
        const imageAnchorPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        this.graphicAnnotation.textObjects.push(new Fovia.TextObject(imageAnchorPoint, encodedUserText, false,
          Fovia.HorizontalJustification.left, imageAnchorPoint, imageAnchorPoint,
          Fovia.MeasurementUnits.pixel, Fovia.MeasurementUnits.pixel, dicomCharSet));
        this.graphicAnnotation.showLabel = true;
      }

      this.updateAnnotation(this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel));
      this.graphicAnnotation.updateNoOfGraphicPoints();
    }

    this.reset();

    this.viewport.repaint();
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async down2D(event: any, unusedRenderParams: Fovia.RenderParams2D): Promise<boolean> {
    const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const points = [currentRenderPixel];
    const displayArea = this.renderEngine.getDisplayArea();
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
      this.startPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
      this.anchorPoint = this.startPoint;
      this.boundingBoxTopLeftPoint = new Fovia.Util.Point(this.startPoint);
      this.boundingBoxBottomRightPoint = new Fovia.Util.Point(this.startPoint);
      this.isMeasuring = true;
    }

    const renderParams = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
    this.pixelSpacing = this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber].pixelSpacing;
    this.viewport.repaint();

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const endPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);

      if (this.graphicAnnotation == null) {
        const circleAnnotation = new Fovia.CircleGraphicAnnotation(this.graphicLayer);
        this.graphicAnnotation = circleAnnotation;
        // Add graphic data
        const graphicObjects: Array<Fovia.GraphicObject> = [];
        const graphicData: Array<Fovia.Util.Point> = [];
        graphicData.push(endPoint);
        graphicData.push(endPoint);
        const graphicObject = new Fovia.GraphicObject(graphicData, Fovia.GraphicType.circle, false, 'PIXEL', 2);
        graphicObjects.push(graphicObject);
        this.graphicAnnotation.graphicObjects = graphicObjects;

        this.graphicAnnotation.setFirstBoundPoint(this.boundingBoxTopLeftPoint);
        this.graphicAnnotation.setSecondBoundPoint(this.boundingBoxBottomRightPoint);

        this.addCircleAnnotation(circleAnnotation);
      }

      this.updateAnnotation(endPoint);
    }

    return true;
  }

  /**
   * @description Render the given circle annotation array
   * @param foviaHTMLViewport2D view port instance where the circle annotation to be render
   * @param canvas canvas instance where to be render
   * @param annotationArray selected annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.CircleGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;

          context.strokeStyle = graphicAnnotation.isHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);

          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];

            const centerPoint: Fovia.Util.Point = new Fovia.Util.Point(graphicObject.graphicData[0].x, graphicObject.graphicData[0].y);
            const endPoint: Fovia.Util.Point = new Fovia.Util.Point(graphicObject.graphicData[1].x, graphicObject.graphicData[1].y);

            const renderPixelCenterPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(centerPoint);
            const renderPixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(endPoint);
            const distance: number = renderPixelCenterPoint.calculateDistance(renderPixelEndPoint);

            context.beginPath();
            context.arc(renderPixelCenterPoint.x, renderPixelCenterPoint.y, distance, 0, 2 * Math.PI);
            context.stroke();
            context.closePath();
          }

          // Highlight points
          if (graphicAnnotation.isPointHighlighted()) {
            context.strokeStyle = this.colorHighlight;

            const endPoints = graphicAnnotation.getEndPoints();

            for (const point of endPoints) {
              const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(point);
              context.strokeRect(renderPixel.x - this.grabberSize / 2,
                renderPixel.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
            }
          }

          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation);
          }
        }
      }
    }
  }

  /**
   * @description called when the user is moving the wheeel of the mouse
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async wheel(event: MouseEvent, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  private updateAnnotation(endPointInIC: Fovia.Util.Point): void {
    if (this.graphicAnnotation === null) {
      return;
    }

    const circleAnnotation = this.graphicAnnotation as Fovia.CircleGraphicAnnotation;
    const displayArea = this.renderEngine.getDisplayArea();
    // Get the center point of circle
    const centerX = (endPointInIC.x + this.anchorPoint.x) / 2;
    const centerY = (endPointInIC.y + this.anchorPoint.y) / 2;
    const center = new Fovia.Util.Point(centerX, centerY);
    const radius = this.anchorPoint.calculateDistance(endPointInIC) / 2;
    const firstBoundsPoint = new Fovia.Util.Point(centerX - radius, centerY - radius);
    const secondBoundsPoint = new Fovia.Util.Point(centerX + radius, centerY + radius);
    const reversedRotatedFirstPoint = this.renderEngine.getReverseRotatedImagePoint(firstBoundsPoint);
    const reversedRotatedSecondPoint = this.renderEngine.getReverseRotatedImagePoint(secondBoundsPoint);
    const firstRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedFirstPoint);
    const secondRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedSecondPoint);

    const points = circleAnnotation.getUpdatedEndPoints(firstRenderPixel, secondRenderPixel);
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.boundingBoxTopLeftPoint = firstBoundsPoint;
      this.boundingBoxBottomRightPoint = secondBoundsPoint;
      circleAnnotation.setFirstBoundPoint(this.boundingBoxTopLeftPoint);
      circleAnnotation.setSecondBoundPoint(this.boundingBoxBottomRightPoint);
      circleAnnotation.setPoint(center);
      circleAnnotation.setEndPoint(endPointInIC);

      if (this.graphicAnnotation.textObjects.length !== 0) {
        const previousAnchorPoint = this.graphicAnnotation.textObjects[0].anchorPoint[0];
        const newAnchorPoint = new Fovia.Util.Point((this.boundingBoxTopLeftPoint.x + this.boundingBoxBottomRightPoint.x) / 2, this.boundingBoxBottomRightPoint.y + 5);
        this.graphicAnnotation.textObjects[0].move(newAnchorPoint.x - previousAnchorPoint.x, newAnchorPoint.y - previousAnchorPoint.y);
      }
      this.viewport.repaint();
    }
  }
}
