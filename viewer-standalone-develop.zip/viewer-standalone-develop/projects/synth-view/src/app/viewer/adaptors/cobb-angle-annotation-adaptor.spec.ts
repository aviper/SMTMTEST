import { CobbAngleAnnotationAdaptor } from './cobb-angle-annotation-adaptor';

describe('CobbAngleAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new CobbAngleAnnotationAdaptor('viewport1', new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
