import Fovia from 'foviaapi';
import { PANEL_TYPE, panelTypeIsKO } from '../models';
import {
  Bounds, constructFoviaTextObject,
  foviaColorToCss,
  isCadAIGraphicLayer
} from '../utils';
import { GSPSUtils, makeImageKey, makeImageKeyFromImageTags } from '@server-api';
import { getBottomPoint, SynthContextSettings } from './adaptor-helpers';
import { SynthStyles } from './synth-styles';
import { ANGLE_ANNOTATION_LAYER, ARROW_ANNOTATION_LAYER, isSynthAnnotationLayer, LINE_ANNOTATION_LAYER, ROI_ELLIPSE_ANNOTATION_LAYER, ROI_POLYGON_ANNOTATION_LAYER } from './adaptor-constants';
import { AdaptorsService } from '../services';
//  @description Super class for all annotation adaptor classes, contains methods to update annotations in render engine
// 	it captures and processes the specific mouse and keyboard events over the annotations it holds\

const USER_CALIBRATED_LABEL = 'user-calibrated';

export class AbstractAnnotationAdaptor extends SynthStyles implements Fovia.UI.MouseAdaptorInterface  {

  protected static annotationsEnabled = true;
  protected static cadAIEnabled = false;

  protected static annotationsEnabledOnMontage = true;
  protected static cadAIEnabledOnMontage = false;

  protected static cadTextObjectsAddedByViewer = new WeakSet<Fovia.TextObject>();

  protected graphicAnnotation: Fovia.GraphicAnnotation | null = null;
  protected isMeasuring = false;
  protected renderEngine: Fovia.RenderEngineContext2D;
  protected is2D: boolean;
  protected showAnnotations = true;
  protected sopInstanceUid = ''; // Currently loaded image
  protected frameNumber = -1; // Currently loaded frame
  protected pixelSpacing = '1'; // Pixel spacing to calculate measurements
  protected graphicLayer = '';
  protected graphicType = Fovia.GraphicType.none;
  protected supportsGenericDicomGraphicType = false;  // set true for annotations that are associated with DICOM GraphicType (0070,0023)
  protected isUserCalibrated = false;
  private synthContextSettings: SynthContextSettings;
  constructor(protected viewport: Fovia.UI.HTMLViewport,
              protected volumeDataContext: Fovia.VolumeDataContext | null,
              protected showMeasurement: boolean,
              protected adaptorService: AdaptorsService) {

    super();

    this.renderEngine = this.viewport.getRenderEngine();
    this.is2D = this.viewport instanceof Fovia.UI.HTMLViewport2D;
    this.volumeDataContext = volumeDataContext;
    console.assert(this.is2D || this.viewport instanceof Fovia.UI.HTMLViewport3D);
    this.viewport.addDrawListener(this.render.bind(this));
    this.synthContextSettings = new SynthContextSettings(this.visualAttribute, this.colorNormal, this.colorHighlight);
  }

  public static resetDefaults(): void {
    AbstractAnnotationAdaptor.cadAIEnabled = false; // Our policy is off by default
    AbstractAnnotationAdaptor.annotationsEnabled = true;
    AbstractAnnotationAdaptor.annotationsEnabledOnMontage = true;
    AbstractAnnotationAdaptor.cadAIEnabledOnMontage = false;
  }

  public static enableAnnotations(enable: boolean, panelType: PANEL_TYPE): void {
    if (panelTypeIsKO(panelType)) {
      // console.log(`enableAnnotations:  montage=${enable}`);
      AbstractAnnotationAdaptor.annotationsEnabledOnMontage = enable;
    } else {
      // console.log(`enableAnnotations:  2d=${enable}`);
      AbstractAnnotationAdaptor.annotationsEnabled = enable;
    }
  }

  public static areAnnotationsEnabled(panelType: PANEL_TYPE): boolean {
    return panelTypeIsKO(panelType)
        ? AbstractAnnotationAdaptor.annotationsEnabledOnMontage
        : AbstractAnnotationAdaptor.annotationsEnabled;
  }

  public static toggleAnnotationsEnabled(panelType: PANEL_TYPE): boolean {
    const before = AbstractAnnotationAdaptor.areAnnotationsEnabled(panelType);
    AbstractAnnotationAdaptor.enableAnnotations(!before, panelType);
    // console.log(`toggleAnnotationsEnabled: toggled to ${!before}`);
    return !before;
  }

  public static enableCadAI(enable: boolean, panelType: PANEL_TYPE): void {
    if (panelTypeIsKO(panelType)) {
      // TODO for now we're never showing CAD on KO images.
      AbstractAnnotationAdaptor.cadAIEnabledOnMontage = false; // enable;
    } else {
      AbstractAnnotationAdaptor.cadAIEnabled = enable;
    }
  }

  public static areCadAIEnabled(panelType: PANEL_TYPE): boolean {
    return panelTypeIsKO(panelType)
        ? AbstractAnnotationAdaptor.cadAIEnabledOnMontage
        : AbstractAnnotationAdaptor.cadAIEnabled;
  }

  public static toggleCadAIEnabled(panelType: PANEL_TYPE): boolean {
    const before = AbstractAnnotationAdaptor.areCadAIEnabled(panelType);
    AbstractAnnotationAdaptor.enableCadAI(!before, panelType);
    return !before;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event captured mouse event instance
  * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async down(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    AbstractAnnotationAdaptor.enableAnnotations(true, this.adaptorService.getPanelsContainerService().activePanelType);
    this.displayAnnotations(true);
    this.viewport.displayAnnotations(true);
    if (this.is2D && renderParams instanceof Fovia.RenderParams2D) {
      // Get the instance UID, frame number, and pixel spacing.
      this.updateFromImageTags(this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber]);
      return this.down2D(event, renderParams);
    }
    return false;
  }

  /**
   * @description called when the user releases the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async up(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    throw new Error('Method not implemented. -- AbstractAnnotationAdaptor::up');
  }

  /**
   * @description called when the user is moving or dragging the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async move(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    return this.is2D && renderParams instanceof Fovia.RenderParams2D ? this.move2D(event, renderParams) : true;
  }

  public render(foviaHTMLViewport: any, canvas: HTMLCanvasElement, width: number, height: number, imageTags: any): void {
    if (this.is2D) {
      // Get the instance UID and frame number.
      this.updateFromImageTags(imageTags);
      const key = makeImageKey(this.sopInstanceUid, this.frameNumber);
      if (this.showAnnotations && this.graphicType !== Fovia.GraphicType.none) {
        const annotations = this.renderEngine.getAnnotations(this.graphicType, key, false)
          .filter((annotation) => {
            return this.canRenderAnnotation(annotation);
          });
        this.render2D(foviaHTMLViewport, canvas, annotations);
      }
    }
  }

  protected canRenderAnnotation(annotation: Fovia.GraphicAnnotation): boolean {
    const layer = annotation.graphicLayer.trim();
    const isGenericDicomAnnotation = !isSynthAnnotationLayer(layer) && !isCadAIGraphicLayer(layer);
    const canRenderThisAnnotation = this.graphicLayer === layer || (isGenericDicomAnnotation && this.supportsGenericDicomGraphicType);
    const canRenderThisCadAI = isCadAIGraphicLayer(layer) && this.supportsGenericDicomGraphicType;
    const isOnMontagePanel = this.isViewportOnMontagePanel();
    const annotationsEnabled = isOnMontagePanel
        ? AbstractAnnotationAdaptor.annotationsEnabledOnMontage
        : AbstractAnnotationAdaptor.annotationsEnabled;
    const cadAIEnabled = isOnMontagePanel
        ? AbstractAnnotationAdaptor.cadAIEnabledOnMontage
        : AbstractAnnotationAdaptor.cadAIEnabled;

    return (annotationsEnabled && canRenderThisAnnotation) || (cadAIEnabled && canRenderThisCadAI);
  }

  protected isViewportOnMontagePanel(): boolean {
    return (this.viewport as any)?.isMontageViewport ?? false;
  }

  /**
   * @description called when the user is moving the wheeel of the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
  * @returns true will be returned in success case, or else false will be returned
   */
  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    return false;
  }

  /**
   * @description called after an image is returned from the server; useful during navigation when you need to know when the rendering is complete
   * @param htmlViewport Specifies view port instance
  * @param renderParams render parameters that to be applied
   */
  public postRender(htmlViewport: Fovia.UI.HTMLViewport, renderParams: Fovia.RenderParams): void {
  }

  /**
   * @returns this method returns true by default to indicate the annotation creation is complete.  It is invoked
   * by the mouse handlers to determine if this specific annotation should maintain control and process the mouse events.
   * For example, for angle measurement, there will be multiple up/down operations before rendering is complete, however,
   * for line and most others, it is one operation between mouse down/up
   */
  public isDrawingCompleted(): boolean {
    return true;
  }
  /**
   * @description Set the flag, based on that gsps annotations will be hide or render
   * @param showAnnotations true for render, false for hide
   */
  public displayAnnotations(showAnnotations: boolean = true): void {
    this.showAnnotations = showAnnotations;
  }

  public setShowMeasurement(showMeasurement: boolean): void {
    this.showMeasurement = showMeasurement;
  }

  public async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    throw new Error('Method not implemented. -- AbstractAnnotationAdaptor::down2D');
  }

  public move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    throw new Error('Method not implemented. -- AbstractAnnotationAdaptor::move');
  }

  public render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    throw new Error('Method not implemented. -- AbstractAnnotationAdaptor::render2D');
  }
  /**
   * @description Add the given PointGraphicAnnotation into renderEngine that will be rendered later
   * @param annotation PointGraphicAnnotation to add
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addPointAnnotation(annotation: Fovia.PointGraphicAnnotation): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(true);
    return this.renderEngine.addPointAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  /**
   * @description Add the given LineGraphicAnnotaion into renderEngine that will be rendered later
   * @param annotation Line graphic annotation to add
   * @param isFreeLine
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addLineAnnotation(annotation: Fovia.PolylineGraphicAnnotation, isFreeLine: boolean = false): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(!isFreeLine);
    return this.renderEngine.addLineAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  /**
   * @description Add the given CircleGraphicAnnotation into renderEngine that will be rendered later
   * @param annotation CircleGraphicAnnotation to add
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addCircleAnnotation(annotation: Fovia.CircleGraphicAnnotation): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(true);
    return this.renderEngine.addCircleAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  /**
   * @description Add the given EllipseGraphicAnnotation into renderEngine that will be rendered later
   * @param annotation EllipseGraphicAnnotation to add
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addEllipseAnnotation(annotation: Fovia.EllipseGraphicAnnotation): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(true);
    return this.renderEngine.addEllipseAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  /**
   * @description Add the given TextGraphicAnnotation into renderEngine that will be rendered later
   * @param annotation TextGraphicAnnotation to add
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addTextAnnotation(annotation: Fovia.TextGraphicAnnotation): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(true);
    return this.renderEngine.addTextAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  /**
   * @description Add the given AngleGraphicAnnotation into renderEngine that will be rendered later
   * @param annotation AngleGraphicAnnotation to add
   * @returns true will be returned in success case, false will be returned in failure case
   */
  protected addAngleAnnotation(annotation: Fovia.AngleGraphicAnnotation): boolean {
    annotation.setIsNewFlag(true);
    annotation.setShowLabelFlag(true);
    return this.renderEngine.addAngleAnnotation(annotation, this.sopInstanceUid, this.frameNumber);
  }

  protected deleteAnnotation(graphicType: Fovia.GraphicType): void {
    GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, graphicType, this.sopInstanceUid, this.frameNumber);
    this.reset();
  }

  public reset(): void {
    this.resetDrawingState();
    this.graphicAnnotation = null;
    this.isMeasuring = false;
    this.viewport.repaint();
  }

  public getTextToRender(dicomCharSet: string, unformattedText: string): string {
    let content;
    if (dicomCharSet) {
      content = decodeURIComponent(escape(atob(unformattedText)));
      content = Fovia.Util.convertFromBytes(content, dicomCharSet, 'ST');
      content = content.replace('\u0000', '');
    } else {
      content = atob(unformattedText);
    }
    return content;
  }

  public getNormalColor(annotation: Fovia.GraphicAnnotation): string {
    if (isCadAIGraphicLayer(annotation.graphicLayer)) {
      return this.colorCadNormal;
    } else {
      return (annotation.annotationColor != null && !isSynthAnnotationLayer(annotation.graphicLayer)) ? foviaColorToCss(annotation.annotationColor) : this.colorNormal;
    }
  }

  public getHighlightColor(annotation: Fovia.GraphicAnnotation): string {
    if (isCadAIGraphicLayer(annotation.graphicLayer)) {
      return this.colorCadNormal;
    } else {
      return (annotation.highlightColor != null && !isSynthAnnotationLayer(annotation.graphicLayer)) ? foviaColorToCss(annotation.highlightColor) : this.colorHighlight;
    }
  }

  public getReverseHighlightColor(): string {
    return this.colorTextReverse;
  }

  public getTextFillColor(isSelected: boolean, annotation: Fovia.GraphicAnnotation): string {
    if (isCadAIGraphicLayer(annotation.graphicLayer)) {
      return this.colorCadNormal;
    } else {
      return (isSelected || isSynthAnnotationLayer(annotation.graphicLayer)) ? this.getHighlightColor(annotation) : this.getNormalColor(annotation);
    }
  }

  /**
   * @description Renders the given text objects on the given context
   * @param canvasContext Context object that is fetched from canvas
   * @param annotation Annotation with text objects to be rendered
   * @param isSelected flag that Specifies whether the text annotation is selected currently
   * @param isFreeText flag that specifies whether the text object is a label or free text (false for label, true for free text)
   * @param reverseTextColor flag that specifies if text color should be reversed (white background, black text)
   */
  protected renderTextObjects(canvasContext: CanvasRenderingContext2D, annotation: Fovia.GraphicAnnotation, isSelected: boolean = false, isFreeText: boolean = false, reverseTextColor: boolean = false): void {
    const context = this.getSynthContextSettings(canvasContext);
    if (context == null) {
      return;
    }

    if (this.isCadLabelRequired(annotation) && !this.wasCadLabelAddedByViewer(annotation)) {
      this.addCadLabel(annotation);
    }

    if (annotation.textObjects.length === 0) {
      return;
    }

    if (this.isUserCalibrated && this.isUserCalibratedLabelRequired(annotation)) {
      this.addUserCalibratedLabel(annotation, this.renderEngine.getDicomCharSet());
    }

    const renderEngine = this.viewport.getRenderEngine();
    const textUtil = new Fovia.UI.TextUtil(context, this.synthContextSettings.visualAttribute.font);
    const dicomCharSet = this.renderEngine.getDicomCharSet();

    let textObject: Fovia.TextObject = annotation.textObjects[0];

    // Some ROI annotations have two text objects. One for use when selected and one when not selected.
    // Note that Fovia currently has a problem where only the first text object is loaded from GSPS. So
    // this will work before saving GSPS but will not (since textObjects.length will be === 1) work after
    // loading from GSPS until Fovia fixes their problem.
    if ((annotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER || annotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) &&
        annotation.textObjects.length > 1 && !annotation.isHighlighted() && !annotation.isPointHighlighted()) {
      // If we want short version of ROI info then update from 0 to 1
      textObject = annotation.textObjects[0];
    }

    // Ignore CAD text objects that were generated by Fovia from the SR - the viewer uses its own.
    if (isCadAIGraphicLayer(annotation.graphicLayer) && !AbstractAnnotationAdaptor.cadTextObjectsAddedByViewer.has(textObject)) {
        return;
    }

    const unformattedText = textObject.unformattedTextValue;
    if (unformattedText && unformattedText.length > 0) {
      // console.log(textObject);
      // console.log(this.getTextToRender(dicomCharSet, unformattedText));
      const anchorPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
      const boundingTopLeftPoint = textObject.getTopLeftPoint();
      const boundingBottomRightPoint = textObject.getBottomRightPoint();

      let renderTL = new Fovia.Util.Point(0, 0);
      let renderBR = new Fovia.Util.Point(0, 0);

      if (!boundingTopLeftPoint.empty() && !boundingBottomRightPoint.empty()) {
        renderTL = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(boundingTopLeftPoint);
        renderBR = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(boundingBottomRightPoint);
      }

      let height = 0;
      let width = 0;
      if (!renderTL.empty() && !renderBR.empty()) {
        // Calculate anchor points from bounding box corner points
        anchorPoint.x = boundingTopLeftPoint.x;
        anchorPoint.y = boundingTopLeftPoint.y;

        // calculate the line width
        width = Math.abs(renderTL.x - renderBR.x);
        height = Math.round(Math.abs(renderTL.y - renderBR.y));
      } else if (textObject.anchorPoint && textObject.anchorPoint.length > 0) {
        anchorPoint.x = textObject.anchorPoint[0].x;
        anchorPoint.y = textObject.anchorPoint[0].y;
      }

      let content = this.getTextToRender(dicomCharSet, unformattedText);

      // Line annotations use mm when < 10 mm and cm when >= 10 mm.
      if (annotation.graphicLayer === LINE_ANNOTATION_LAYER) {
        const hasUserCalibratedLabel = content.includes(USER_CALIBRATED_LABEL);
        if (!content.includes('pixels')) {
          let length = parseFloat(content);
          if (length >= 10) {
            length = length / 10; // Convert to centimeters.
            content = `${(Math.round(length * 100) / 100).toFixed(2)} cm`;

            if (hasUserCalibratedLabel) {
              content = `${content} \n${USER_CALIBRATED_LABEL}`;
            }
          }
        }
      }

      const textAlign: CanvasTextAlign = 'start';
      const textBounds = this.getTextBounds(content);

      let point = renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPoint);

      // Adjust the anchor point and text alignment to avoid interference between text and annotation.
      if (annotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) {
        point = this.getEllipseTextAnchorPoint(annotation.graphicObjects[0].graphicData, textBounds.height);
      } else if (annotation.graphicLayer === LINE_ANNOTATION_LAYER || annotation.graphicLayer === ARROW_ANNOTATION_LAYER) {
        if (annotation.graphicObjects[0].graphicData[1].x > annotation.graphicObjects[0].graphicData[0].x) {
          point.x -= textBounds.width;
        } else {
          point.x += (textBounds.width / content.length) / 2;
        }
      } else if (annotation.graphicLayer === ANGLE_ANNOTATION_LAYER) {
        const vertex = annotation.graphicObjects[0].graphicData[0];
        const endPt1 = annotation.graphicObjects[0].graphicData[1];
        const endPt2 = annotation.graphicObjects[0].graphicData[2];
        if (vertex.y < endPt1.y && vertex.y < endPt2.y) {
          point.x -= textBounds.width / 1.75;
          point.y -= textBounds.height;
        } else if (vertex.y > endPt1.y && vertex.y > endPt2.y) {
          point.x -= textBounds.width / 2;
          point.y += textBounds.height * .6;
        } else if (vertex.x < endPt1.x && vertex.x < endPt2.x) {
          point.x -= (textBounds.width + (textBounds.width / content.length));
        } else if (vertex.x > endPt1.x && vertex.x > endPt2.x) {
          point.x += textBounds.width / content.length;
        }
      }

      point = this.keepTextOnImage(point, textBounds.width);
      if (isSelected && !renderTL.empty() && !renderBR.empty()) {
        context.strokeStyle = isSelected ? this.getHighlightColor(annotation) : this.getNormalColor(annotation);
        context.beginPath();
        // This is the rectangle of the border shown to indicate the annotation is selected.
        // Let's inflate it a bit so it's less ugly.
        context.rect(point.x - 4, point.y - 4, textBounds.width + 8, textBounds.height + 8);
        context.stroke();
      }

      if (reverseTextColor && !renderTL.empty() && !renderBR.empty()) {
        context.fillStyle = this.getHighlightColor(annotation);
        context.beginPath();
        // This is the rectangle of the border shown to indicate the annotation is selected.
        // Let's inflate it a bit so it's less ugly.
        context.rect(point.x - 4, point.y - 4, textBounds.width + 8, textBounds.height);
        context.fill();
      }

      if (isFreeText) {
        textUtil.setFont(this.synthContextSettings.visualAttribute.font);
      }
      context.textAlign = textAlign;
      const adjustedPoint = renderEngine.renderImagePixelToDicomImagePixelWithDiff(point);
      textObject.setAdjustedTopLeftPoint(adjustedPoint);
      const adjustedBottomPoint = new Fovia.Util.Point(point.x + textBounds.width, point.y + textBounds.height);
      const adjustedBottomPointImagePixel = renderEngine.renderImagePixelToDicomImagePixelWithDiff(adjustedBottomPoint);
      textObject.setAdjustedBottomRightPoint(adjustedBottomPointImagePixel);
      point.y += Math.abs(this.visualAttribute.font.metric * this.synthContextSettings.visualAttribute.font.size) / 2;

      if (reverseTextColor) {
        context.fillStyle = this.getReverseHighlightColor();
      } else {
        context.strokeStyle = isSelected ? this.getHighlightColor(annotation) : this.getNormalColor(annotation);
        context.fillStyle = this.getTextFillColor(isSelected, annotation);
      }
      textUtil.render(content, point, width, textObject.boundingBoxTextHorizontalJustification);
    }
  }

  protected keepTextOnImage(point: Fovia.Util.Point, width: number): Fovia.Util.Point {
    const pointX = point.x + width;
    const points = [new Fovia.Util.Point(pointX, point.y)];
    const displayArea = this.renderEngine.getDisplayArea();

    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      return point;
    }

    const adjustedPoint = point;

    // Adjust to the left if necessary.
    adjustedPoint.x -= width;
    for (let i = 0; i <= width; i += 5) {
      adjustedPoint.x -= i;
      if (Fovia.PresentationUtil.arePointsWithinImageBounds([adjustedPoint], displayArea, 0, 0)) {
        break;
      }
    }
    return adjustedPoint;
  }
  protected getAnchorPoint(points: Fovia.Util.Point[], boundingRect: Fovia.Util.Rect2D): Fovia.Util.Point {
    const fromPoint = new Fovia.Util.Point(boundingRect.getCenterX(), boundingRect.getCenterY());
    const closestPoint = Fovia.PresentationUtil.getClosestPoint(fromPoint, points);
    let anchorPoint = new Fovia.Util.Point(closestPoint.x, closestPoint.y);
    if (!Fovia.PresentationUtil.arePointsWithinImageBounds([this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPoint)], this.renderEngine.getDisplayArea(), -1, -1)) {
      const index = points.findIndex(point => point.x === anchorPoint.x && point.y === anchorPoint.y);
      anchorPoint = Fovia.PresentationUtil.getOppositePoint(index + 1, points);
    }

    return anchorPoint;
  }

  protected getEllipseTextAnchorPoint(points: Fovia.Util.Point[], textHeight: number): Fovia.Util.Point {
    // first find the lowest point and see if text won't be cut off
    const lowHighPoints = this.getLowestAndHighestPoints(points);
    const lowestPoint = lowHighPoints[0];
    let anchorPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(lowestPoint));
    anchorPoint.y += Math.abs(this.visualAttribute.font.metric * this.synthContextSettings.visualAttribute.font.size) * .7;

    // check if lowest point plus height of text fits on the canvas
    const lowestPointWithText = new Fovia.Util.Point(anchorPoint.x, anchorPoint.y + textHeight); // this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(lowestPoint.x, lowestPoint.y));
    const displayArea = this.renderEngine.getDisplayArea();
    if (!Fovia.PresentationUtil.arePointsWithinImageBounds([lowestPointWithText], displayArea, 0, 0)) {
      // if lowest point cuts off the text, then find the highest point
      const highestPoint = lowHighPoints[1];
      anchorPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(highestPoint.x, highestPoint.y));
      anchorPoint.y -= textHeight;
    }
    return anchorPoint;
  }

  protected getLowestAndHighestPoints(points: Fovia.Util.Point[]): Fovia.Util.Point[] {
    let lowestPoint = points[0];
    let highestPoint = points[0];
    let maxY = -1;
    let minY = highestPoint.y;
    for (const point of points) {
      if (point.y > maxY) {
        maxY = point.y;
        lowestPoint = point;
      }
      if (point.y < minY) {
        minY = point.y;
        highestPoint = point;
      }
    }

    return [lowestPoint, highestPoint];
  }

  protected getSynthContextSettings(context: CanvasRenderingContext2D | null): CanvasRenderingContext2D | null {
    return this.synthContextSettings.getSynthContextSettings(context);
  }
  public getTextBounds(inputText: string): Bounds {
    const bounds = new Bounds(0, 0);
    const canvas = document.createElement('canvas');
    const context = this.getSynthContextSettings(canvas.getContext('2d'));

    if (context) {
      const lines = inputText.split('\n');
      bounds.width = context.measureText(Fovia.Util.findLineWithMaximumLength(context, lines, this.visualAttribute.font)).width;
      bounds.height = this.visualAttribute.font.metric * this.visualAttribute.font.size * lines.length;
    }
    return bounds;
  }
  protected updateFromImageTags(imageTags: any): void {
    const examId = this.viewport.getRenderEngine().seriesDataContext.studyInstanceUID;
    const userCalibratedPixelSpacing = this.adaptorService.getPixelSpacingForImage(examId, makeImageKeyFromImageTags(imageTags));

    if (userCalibratedPixelSpacing != null) {
      this.pixelSpacing = userCalibratedPixelSpacing;
      this.isUserCalibrated = true;
    } else {
      this.pixelSpacing = imageTags.pixelSpacing;
      this.isUserCalibrated = false;
    }
    this.sopInstanceUid = imageTags.sopInstanceUID.trim();
    this.frameNumber = imageTags.frameNumber;
  }

  protected resetDrawingState(): void {
  }

  public getSynthSettings(): SynthContextSettings {
    return this.synthContextSettings;
  }

  protected GetDicomConvertedText(s: string): string {
    if (this.renderEngine.getDicomCharSet()) {
      return Fovia.Util.convertFromHexStr(s, this.renderEngine.getDicomCharSet());
    }
    return s;
  }

  public getCadAIGraphicLayerDescription(graphicLayer: string): string {
    if (graphicLayer === Fovia.Util.Constants.CALCIFICATION_CLUSTER) {
      return 'calc';
    } else if (graphicLayer === Fovia.Util.Constants.MAMMOGRAPHY_BREAST_DENSITY) {
      return 'density';
    }
    return '';
  }

  protected isCadLabelRequired(annotation: Fovia.GraphicAnnotation): boolean {
    if (!isCadAIGraphicLayer(annotation.graphicLayer)) {
      return false;
    }
    return (
        annotation instanceof Fovia.PolylineGraphicAnnotation ||
        annotation instanceof Fovia.CircleGraphicAnnotation ||
        annotation instanceof Fovia.EllipseGraphicAnnotation
    );
  }

  protected wasCadLabelAddedByViewer(annotation: Fovia.GraphicAnnotation): boolean {
    return annotation.textObjects.find(
      (textObj: Fovia.TextObject) => AbstractAnnotationAdaptor.cadTextObjectsAddedByViewer.has(textObj)
    ) != null;
  }

  protected addCadLabel(annotation: Fovia.GraphicAnnotation): void {
    if (!isCadAIGraphicLayer(annotation.graphicLayer)) {
      return;
    }
    const firstBoundPoint = annotation.getFirstBoundsPoint();
    const anchorPointImagePixel = getBottomPoint(annotation) ?? firstBoundPoint;
    const anchorPointRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPointImagePixel);
    const text = this.getCadAIGraphicLayerDescription(annotation.graphicLayer);

    const context = this.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));
    if (context == null) {
      return;
    }
    const textObjectConstructs = {
      anchorPointImagePixel: new Fovia.Util.Point(anchorPointImagePixel.x, anchorPointImagePixel.y + 0.5),
      anchorPointRenderPixel: anchorPointRenderPixel,
      label: text,
      context: context,
      displayArea: this.renderEngine.getDisplayArea(),
      fontHeight: this.synthContextSettings.visualAttribute.font.size * Fovia.Util.Constants.DEFAULT_FONT_METRIC
    };
    const isEllipse = annotation instanceof Fovia.EllipseGraphicAnnotation;
    const cadTextObject = constructFoviaTextObject(textObjectConstructs, isEllipse);
    AbstractAnnotationAdaptor.cadTextObjectsAddedByViewer.add(cadTextObject);
    annotation.textObjects.push(cadTextObject);
    annotation.setShowLabelFlag(true);
  }

  private isUserCalibratedLabelRequired(annotation: Fovia.GraphicAnnotation): boolean {
    return annotation.graphicLayer === LINE_ANNOTATION_LAYER
      || annotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER
      || annotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER;
  }

  private addUserCalibratedLabel(lineAnnotation: Fovia.GraphicAnnotation, dicomCharSet: string): void {
    if (lineAnnotation == null) {
      console.error(`${this.constructor.name}.addUserCalibrationLabel lineAnnotation is null`);
      return;
    }

    if (lineAnnotation.textObjects == null || lineAnnotation.textObjects.length <= 0) {
      console.error(`${this.constructor.name}.addUserCalibrationLabel no textObjects`);
      return;
    }

    const textObject = lineAnnotation.textObjects[0];
    if (textObject.unformattedTextValue) {
      const text = this.getTextToRender(dicomCharSet, textObject.unformattedTextValue);
      if (!text.includes(USER_CALIBRATED_LABEL)) {
        let content = `${text} \n${USER_CALIBRATED_LABEL}`;
        if (dicomCharSet) {
          content = Fovia.Util.convertFromHexStr(content, dicomCharSet);
        }
        lineAnnotation.textObjects[0].unformattedTextValue = btoa(content);
      }
    }
  }
}
