import Fovia from 'foviaapi';

const RESOLUTION_2K = 2211840;
const RESOLUTION_4K = 8294400;
const RESOLUTION_8K = 33177600;

export class SynthStyles {
  protected readonly _colorNormal = '#d5d5d5';
  protected readonly _colorCadNormal = '#FFFFFF';
  protected readonly _colorHighlight = '#FFFFFF';
  protected readonly _colorText = '#CCCCCC';
  protected readonly _colorTextReverse = '#0A0A0A';

  constructor() { }

  public get visualAttribute(): Fovia.Util.VisualAttribute{
    const resolution = screen.width * screen.height;
    const visualAttribute: Fovia.Util.VisualAttribute = new Fovia.Util.VisualAttribute();
    visualAttribute.font.metric = 1.4;

    if (resolution >= RESOLUTION_8K) {
      visualAttribute.font.size = 20;
      visualAttribute.line.width = 5;
    } else if (resolution >= RESOLUTION_4K) {
      visualAttribute.font.size = 18;
      visualAttribute.line.width = 4;
    } else if (resolution >= RESOLUTION_2K) {
      visualAttribute.font.size = 14;
      visualAttribute.line.width = 3;
    } else {
      visualAttribute.font.size = 12;
      visualAttribute.line.width = 2;
    }
    return visualAttribute;
  }

  public get colorNormal(): string {
    return this._colorNormal;
  }

  public get colorCadNormal(): string {
    return this._colorCadNormal;
  }

  public get colorHighlight(): string{
    return this._colorHighlight;
  }

  public get colorText(): string {
    return this._colorText;
  }

  public get colorTextReverse(): string {
    return this._colorTextReverse;
  }

  public get grabberSize(): number {
    const resolution = screen.width * screen.height;

    if (resolution >= RESOLUTION_8K) {
      return 18;
    } else if (resolution >= RESOLUTION_4K) {
      return 14;
    } else if (resolution >= RESOLUTION_2K) {
      return 10;
    }
    return 8;
  }
}
