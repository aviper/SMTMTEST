// Extensions to the AdaptorsService for the Scroll tool.
import { AdaptorsService, SeriesDisplayStoreService, ViewerSettingsService } from '../services';
import { TOOL_TYPE } from '../tools';

export class ScrollAdaptorActions {
  private lastScrollForward: boolean | null = null;
  private lastScrollViewportId  = '';

  constructor(private adaptorsService: AdaptorsService,
              private seriesDisplayStoreService: SeriesDisplayStoreService,
              private viewerSettingsService: ViewerSettingsService) { }

  public async scrollToNextImageOnActiveViewport(forward: boolean, allowAdjacent: boolean = true): Promise<void> {
    return this.scrollToNextImageOnViewport(this.viewerSettingsService.activeViewport, forward, allowAdjacent);
  }

  public async scrollToNextImageOnViewport(viewportId: string, forward: boolean, allowAdjacent: boolean = true): Promise<void> {
    if (!viewportId) {
      console.warn('scrollToNextImageOnActiveViewport: no active viewport');
      return;
    }
    const seriesDisplay = this.seriesDisplayStoreService.getSeriesDisplayStoreItem(viewportId);
    if (!seriesDisplay) {
      console.warn(`scrollToNextImage: no seriesDisplay item for viewport ${viewportId}`);
      return;
    }

    // For the PagePlane tool we need to initialize for synchronization when the direction changes or scrolling happens on a different viewport.
    let needSyncInit = false;
    if (this.viewerSettingsService.activeToolType === TOOL_TYPE.ePagePlane && (this.lastScrollForward !== forward || this.lastScrollViewportId !== viewportId)) {
      needSyncInit = true;
    }

    this.lastScrollForward = forward;
    this.lastScrollViewportId = viewportId;
    if (await seriesDisplay.gotoToNextImageAndRender(this.adaptorsService, forward, this.viewerSettingsService.isAllModeToolActive(), this.viewerSettingsService.showFlicker, this.viewerSettingsService.activeToolType === TOOL_TYPE.ePagePlane, allowAdjacent, needSyncInit)) {
      this.adaptorsService.updateLocalizerLines(viewportId).then();
    }
  }
}
