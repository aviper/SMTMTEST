import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { TextAnnotationAdaptor } from './text-annotation-adaptor';
import { ModalPopupService } from '../modal-popup-dialogs';
import { AdaptorsService } from '../services';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { GSPSUtils } from '@server-api';

export class TextAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  private selectedAnnotation: Fovia.TextGraphicAnnotation | null = null;

  constructor(viewport: Fovia.UI.HTMLViewport,
    private modalPopupService: ModalPopupService,
    adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the selected annotation.
   */
  public reset(): void {
    // Reset the highlight flags
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setHighlight(false);
    }
  }

  /**
   * @description Check with current mouse point and selected Annotation.
   * If the points are equal, set the highlight flag as true, otherwise false
   * @param selectedAnnotation
   * @param currentPoint
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.TextGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    if (selectedAnnotation == null) {
      return false;
    }
    this.selectedAnnotation = selectedAnnotation;
    const wasHighlighted = this.selectedAnnotation.isHighlighted();

    if (this.selectedAnnotation != null) {
      this.updateTextEditMode();
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
      // Set the highlight flag
      this.selectedAnnotation.setHighlight(this.editMode === EDIT_MODE.annotation);
    }

    return wasHighlighted !== this.selectedAnnotation.isHighlighted();
  }

  /**
   * Handle the mouse move events.
   * Highlight the annotation, if the current mouse point is matches with selected annotation.
   * We are able to move text annotation in and around the display area.
   * And also, update the bounding points.
   * @param currentPoint
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point): boolean {
    if (this.selectedAnnotation == null || this.editMode !== EDIT_MODE.annotation) {
      this.selectedAnnotation?.setHighlight(false);
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(currentPoint));
    const displayArea = this.renderEngine.getDisplayArea();
    if (!displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint.x, currentPoint.y);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;

    const firstBoundsPoint = this.selectedAnnotation.getAdjustedTopLeftPoint();
    const secondBoundsPoint = this.selectedAnnotation.getSecondBoundsPoint();
    const reversedRotatedFirstPoint = this.renderEngine.getReverseRotatedImagePoint(firstBoundsPoint);
    const reversedRotatedSecondPoint = this.renderEngine.getReverseRotatedImagePoint(secondBoundsPoint);
    const firstRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedFirstPoint);
    const secondRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedSecondPoint);
    let points = [firstRenderPixel, secondRenderPixel];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, deltaY)) {
      this.selectedAnnotation.move(deltaX, deltaY);
    } else {
      points = [firstRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY);
      }
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }

  public async editText(annotation: Fovia.TextGraphicAnnotation, event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    const adaptors = this.viewport.getHtmlViewportAdaptors();
    let textAnnotationAdaptor: TextAnnotationAdaptor | null = null;

    // Currently our 3D viewports don't use our version of HTMLViewportAdaptors. Make sure of what
    // we have before attempting to use our customizations of HTMLViewportAdaptors.
    if (adaptors instanceof HTMLViewportAdaptors) {
      textAnnotationAdaptor = adaptors.getTextAnnotationAdaptor();
    } else {
      textAnnotationAdaptor = new TextAnnotationAdaptor(this.viewport, null, this.modalPopupService, this.adaptorsService);
    }

    if (textAnnotationAdaptor) {
      textAnnotationAdaptor.setCurrentAnnotation(annotation);
      return textAnnotationAdaptor.up(event, renderParams);
    }
    return false;
  }

  private updateTextEditMode(): void {
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setHighlight(false);
      this.editMode = this.selectedAnnotation.getSelectedPointIndex() >= 0 ? EDIT_MODE.annotation : EDIT_MODE.none;
    }
  }
}
