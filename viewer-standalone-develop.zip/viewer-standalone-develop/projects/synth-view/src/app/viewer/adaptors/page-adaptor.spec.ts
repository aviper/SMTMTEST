import { PageAdaptor } from './page-adaptor';

describe('PageAdaptor', () => {
  it('should create an instance', () => {
    // expect(new PageAdaptor()).toBeTruthy();
  });
});
