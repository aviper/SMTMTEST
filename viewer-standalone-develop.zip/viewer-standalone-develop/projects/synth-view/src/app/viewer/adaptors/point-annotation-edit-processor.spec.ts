import { PointAnnotationEditProcessor } from './point-annotation-edit-processor';

describe('PointAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new PointAnnotationEditProcessor()).toBeTruthy();
  });
});
