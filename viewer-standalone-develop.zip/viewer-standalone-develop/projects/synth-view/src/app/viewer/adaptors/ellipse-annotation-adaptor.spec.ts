import Fovia from 'foviaapi';
import { EllipseAnnotationAdaptor } from './ellipse-annotation-adaptor';

describe('EllipseAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new EllipseAnnotationAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
