import Fovia from 'foviaapi';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { LINE_ANNOTATION_LAYER } from './adaptor-constants';
import { AdaptorsService } from '../services';
export class LineMeasurementAdaptor extends AbstractAnnotationAdaptor {
  protected isFreeline = false;
  protected reversePoints = false;
  protected lineWidth: number | null = null;

  constructor(
    viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    showMeasurement: boolean,
    adaptorsService: AdaptorsService) {
    super(viewport, volumeDataContext, showMeasurement, adaptorsService);
    this.graphicLayer = LINE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.polyline;
    this.supportsGenericDicomGraphicType = true;
  }

  /**
   * @description Toggle the freeline draw variable
   * @param flag Specifies the flag to set
   */
  public toggleFreeline(flag: boolean = false): void {
    this.isFreeline = flag;
  }

  /**
   * @description called when the user releases the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.graphicAnnotation != null) {
      const lineAnnotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const displayArea = this.renderEngine.getDisplayArea();
      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        if (this.isFreeline) {
          // If freeline, set end point as same as start point
          const endPoint = new Fovia.Util.Point(this.graphicAnnotation.getGraphicData(0));
          if (endPoint != null) {
            this.graphicAnnotation.addGraphicData(endPoint);
          }
        } else {
          const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
          lineAnnotation.updateEndPoint(point);
          if (this.showMeasurement) {
            lineAnnotation.updateMeasurementLabel(this.pixelSpacing, this.renderEngine.getDicomCharSet());
          }
        }

        lineAnnotation.updateNoOfGraphicPoints();
      }
    }

    this.reset();
    this.viewport.repaint();
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    return true;
  }

  public deleteInCompleteFreeDrawAnnotation(event: any): void {
    const points: Fovia.Util.Point[] = [new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y)];
    // let displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    // if (!this.renderEngine.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
    if (!this.renderEngine.arePointsWithinImageBounds(points)) {
      this.renderEngine.deleteInCompleteFreeDrawAnnotation(Fovia.GraphicType.polyline, this.sopInstanceUid, this.frameNumber);
    }
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const displayArea = this.renderEngine.getDisplayArea();
    const points = [new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y)];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
      this.isMeasuring = true;
    }

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, this.renderEngine.getDisplayArea(), 0, 0)) {
        const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        let lineAnnotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
        if (lineAnnotation == null) {
          lineAnnotation = new Fovia.PolylineGraphicAnnotation(this.graphicLayer);
          this.graphicAnnotation = lineAnnotation;
          lineAnnotation.setSelectedObjectIndex(0);
          // Add graphic data
          const graphicObjects: Array<Fovia.GraphicObject> = [];
          const graphicData: Array<Fovia.Util.Point> = [];
          // Begin with both start and end points the same.
          graphicData.push(point);
          graphicData.push(point);
          const graphicObject = new Fovia.GraphicObject(graphicData, Fovia.GraphicType.polyline, false, 'PIXEL', 2);
          graphicObjects.push(graphicObject);
          lineAnnotation.graphicObjects = graphicObjects;

          this.addLineAnnotation(lineAnnotation, this.isFreeline);
        }

        if (this.isFreeline) {
          lineAnnotation.addGraphicData(point);
        } else {
          // For some annotations (like arrow) to work the way we want we have to swap the endpoints.
          // Strange, I know, but Fovia insists on associating the start point with the anchor point for any attached
          // text object, so this is what we have to do.
          if (this.reversePoints) {
            lineAnnotation.setStartPoint(point);
          } else {
            lineAnnotation.updateEndPoint(point);
          }
          if (this.showMeasurement) {
            lineAnnotation.updateMeasurementLabel(this.pixelSpacing, this.renderEngine.getDicomCharSet());
          }
        }
      }

      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description Render the Line annotations for the given annotation array
  * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));

    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.PolylineGraphicAnnotation = annotationArray[m];
        // While a user is creating a new object just draw this one. No need to go off and draw everything.
        // the same type being hidden while a new one is being drawn. So for now commenting out and
        // allowing all to be drawn.
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;
          const isFirstPointSelected = graphicAnnotation.isStartPointHighlighted();
          const isEndPointSelected = graphicAnnotation.isEndPointHighlighted();

          context.strokeStyle = graphicAnnotation.isHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);
          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];

            if (graphicObject.graphicData.length >= 2) {
              if (graphicObject.graphicData.length === 2) {
                const startPoint = new Fovia.Util.Point(graphicObject.graphicData[0].x, graphicObject.graphicData[0].y);
                const endPoint = new Fovia.Util.Point(graphicObject.graphicData[1].x, graphicObject.graphicData[1].y);
                const imagePixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(startPoint);
                const imagePixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(endPoint);

                // An override may require an alternate line width.
                if (this.lineWidth) {
                  context.lineWidth = this.lineWidth;
                }

                context.beginPath();
                context.moveTo(imagePixelStartPoint.x, imagePixelStartPoint.y);
                context.lineTo(imagePixelEndPoint.x, imagePixelEndPoint.y);
                context.stroke();

                // Possibly draw something at the start of the line.
                this.drawLineEndpoints(imagePixelStartPoint, imagePixelEndPoint, context);

                if (isFirstPointSelected) {
                  context.strokeRect(imagePixelStartPoint.x - this.grabberSize / 2,
                    imagePixelStartPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }
                if (isEndPointSelected) {
                  context.strokeRect(imagePixelEndPoint.x - this.grabberSize / 2,
                    imagePixelEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }
              } else {
                for (let k = 0; k < graphicObject.graphicData.length - 1; k++) {
                  const startPoint = new Fovia.Util.Point(graphicObject.graphicData[k].x, graphicObject.graphicData[k].y);
                  const endPoint = new Fovia.Util.Point(graphicObject.graphicData[k + 1].x, graphicObject.graphicData[k + 1].y);
                  const imagePixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(startPoint);
                  const imagePixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(endPoint);

                  context.beginPath();
                  context.moveTo(imagePixelStartPoint.x, imagePixelStartPoint.y);
                  context.lineTo(imagePixelEndPoint.x, imagePixelEndPoint.y);
                  context.closePath();
                  context.stroke();

                  if (isFirstPointSelected) {
                    context?.strokeRect(imagePixelStartPoint.x - this.grabberSize / 2,
                      imagePixelStartPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                  }
                  if (isEndPointSelected) {
                    context.strokeRect(imagePixelEndPoint.x - this.grabberSize / 2,
                      imagePixelEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                  }

                }
              }

              // Highlight all hotspots if any one is selected
              if (graphicObject.isHotspotSelected()) {
                const hotSpots = graphicObject.getHotspots();
                for (let index = 0; index < hotSpots.length; index++) {
                  const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(hotSpots[index]);
                  context.strokeRect(renderPixel.x - this.grabberSize / 2,
                    renderPixel.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }
              }
            }
          }

          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation);
          }
        }
      }
    }
  }

  protected drawLineEndpoints(p1: Fovia.Util.Point, p2: Fovia.Util.Point, context: CanvasRenderingContext2D): void {
    // Line measurement has nothing to draw here. Derived classes might.
  }
}
