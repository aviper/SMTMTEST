import { EllipseAnnotationEditProcessor } from './ellipse-annotation-edit-processor';

describe('EllipseAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new EllipseAnnotationEditProcessor()).toBeTruthy();
  });
});
