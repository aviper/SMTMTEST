import { PointAnnotationAdaptor } from './point-annotation-adaptor';

describe('PointAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new PointAnnotationAdaptor()).toBeTruthy();
  });
});
