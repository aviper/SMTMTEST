import { HTMLViewportAdaptors } from './htmlviewport-adaptors';

describe('HTMLViewportAdaptors', () => {
  it('should create an instance', () => {
    expect(new HTMLViewportAdaptors()).toBeTruthy();
  });
});
