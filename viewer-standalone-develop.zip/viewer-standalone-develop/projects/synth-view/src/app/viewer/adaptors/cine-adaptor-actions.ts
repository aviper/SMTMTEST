// Extensions to the AdaptorsService for the Cine tool.
import { SeriesDisplayStoreService, ViewerSettingsService } from '../services';
import { CINE_DIRECTION, CINE_MODE } from '../models';
import { SeriesDisplayStoreItem } from '../stores';

export class CineAdaptorActions {
  constructor(
      private seriesDisplayStoreService: SeriesDisplayStoreService,
      private viewerSettingsService: ViewerSettingsService
  ) {
  }

  public isCineRunningOnActiveViewport(): boolean {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      return seriesDisplay.cineController.isRunning;
    }
    return false;
  }

  public isCinePausedOnActiveViewport(): boolean {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      return seriesDisplay.cineController.isPaused;
    }
    return false;
  }

  public clearCinePausedOnActiveViewport(): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay && seriesDisplay.cineController.isPaused) {
      seriesDisplay.cineController.isPaused = false;
    }
  }

  public toggleCineOnActiveViewport(useOverrides: boolean = false): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.toggleCine(useOverrides);
    }
  }

  public pauseCineOnActiveViewport(): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.pauseCine();
    }
  }

  public resumeCineOnActiveViewport(): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.resumeCine();
    }
  }

  public speedUpCineOnActiveViewport(): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.throttledSpeedUp();
    }
  }

  public slowDownCineOnActiveViewport(): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.throttledSlowDown();
    }
  }

  public setCineDirectionOnActiveViewport(direction: CINE_DIRECTION): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.cineDirection = direction;
    }
  }

  public setCineOverrideDefaultDirectionOnActiveViewport(direction: CINE_DIRECTION): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.overrideDefaultDirection = direction;
    }
  }

  public setCineTargetFrameRate(rate: number, calcDefaultDelay: boolean): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      if (calcDefaultDelay) {
        seriesDisplay.cineController.renderDelayDefault = 1000 / rate;
        // console.log(`setCineTargetFrameRate seriesDisplay.cineController.renderDelayDefault: ${seriesDisplay.cineController.renderDelayDefault}`);
      }
      seriesDisplay.cineController.setTargetFpsNoDampen(rate);
    }
  }

  public setCineOverrideDefaultFrameRate(rate: number, calcDefaultDelay: boolean): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      if (calcDefaultDelay) {
        seriesDisplay.cineController.renderDelayDefault = 1000 / rate;
      }
      seriesDisplay.cineController.overrideDefaultFps = rate;
    }
  }

  public setCineModeOverride(mode: CINE_MODE | null): void {
    const seriesDisplay = this.activeSeriesDisplay;
    if (seriesDisplay) {
      seriesDisplay.cineController.overrideMode = mode;
    }
  }

  public async switchMultiframeImage(next: boolean): Promise<void> {
    const seriesDisplay = this.activeSeriesDisplay;
    const restartCine = this.isCineRunningOnActiveViewport();
    if (seriesDisplay) {
      if (await seriesDisplay.cineController.switchMultiframeImage(next) && restartCine) {
        seriesDisplay.cineController.startCine();
      }
    }
  }

  private get activeSeriesDisplay(): SeriesDisplayStoreItem | null {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn('activeSeriesDisplay: no active viewport');
      return null;
    }
    const seriesDisplay = this.seriesDisplayStoreService.getSeriesDisplayStoreItem(viewportId);
    if (!seriesDisplay) {
      console.warn(`activeSeriesDisplay: no seriesDisplay item for viewport ${viewportId}`);
      return null;
    }
    return seriesDisplay;
  }
}
