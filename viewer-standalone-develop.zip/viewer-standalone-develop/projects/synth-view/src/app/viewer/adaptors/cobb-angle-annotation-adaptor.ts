import Fovia from 'foviaapi';
import { COBB_ANGLE_ANNOTATION_LAYER } from './adaptor-constants';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { convertToRenderPixel } from '../utils';
import { AdaptorsService } from "../services";

enum ANGLE_DRAWING_STATE {
  CREATE_STARTING_POINT,
  DRAGGING_FIRST_END_POINT,
  LOCK_FIRST_END_POINT,
  CREATE_SECOND_START_POINT,
  DRAGGING_SECOND_END_POINT,
  LOCK_SECOND_END_POINT
}

export class CobbAngleAnnotationAdaptor extends AbstractAnnotationAdaptor {
  protected anchorPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxTopLeftPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxBottomRightPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);

  // Screen coordinates of the user line endpoints.
  protected userPoints: Fovia.Util.Point[] = [];

  // The points defining the perpendicular lines. Screen coordinates.
  private perpLinePoints1: Fovia.Util.Point[] = [new Fovia.Util.Point(0, 0), new Fovia.Util.Point(0, 0)];
  private perpLinePoints2: Fovia.Util.Point[] = [new Fovia.Util.Point(0, 0), new Fovia.Util.Point(0, 0)];

  // The point where the two perpendicular lines intersect and form the Cobb angle. Screen coordinates.
  private vertexPoint = new Fovia.Util.Point(0, 0);

  protected drawingState: ANGLE_DRAWING_STATE = ANGLE_DRAWING_STATE.CREATE_STARTING_POINT;
  private cobbAngleRadians = 0;
  private cobbAngleText = '';

  constructor(viewport: Fovia.UI.HTMLViewport, volumeDataContext: Fovia.VolumeDataContext | null, adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, true, adaptorService);
    this.graphicLayer = COBB_ANGLE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.polyline;
  }

  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.graphicAnnotation != null && this.userPoints.length > 0) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const displayArea = this.renderEngine.getDisplayArea();
      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(false);
        const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;

        if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT) {
          // Save with image coords to the annotation and screen coords locally.
          annotation.setEndPoint(imagePixel);
          this.userPoints[1] = currentRenderPixel;
          this.drawingState = ANGLE_DRAWING_STATE.CREATE_SECOND_START_POINT;
        } else if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT) {
          // Save with image coords to the annotation and screen coords locally.
          annotation.setEndPoint(imagePixel);
          this.userPoints[3] = currentRenderPixel;
          // All done
          if (this.calculatePerpendicularLines(annotation.graphicObjects[0].graphicData)) {
            this.calculateCobbAngle();
            this.updateAnnotationText(annotation);
          }
          this.reset();
          this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
        }
      }
    }
    this.viewport.repaint();

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const displayArea = this.renderEngine.getDisplayArea();
    const points = [currentRenderPixel];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);

      if (this.drawingState === ANGLE_DRAWING_STATE.CREATE_STARTING_POINT) {
        this.isMeasuring = true;
        this.drawingState = ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT;

        if (this.graphicAnnotation == null) {
          this.createGraphicAnnotation(currentRenderPixel);
        }
      } else if (this.drawingState === ANGLE_DRAWING_STATE.CREATE_SECOND_START_POINT) {
        if (annotation) {
          const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
          // Add start and end points for the second line (same point until moved).
          // Screen coordinates locally and image coordinates in the annotation.
          this.userPoints.push(currentRenderPixel);
          this.userPoints.push(currentRenderPixel);
          annotation.setPoint(imagePixel);
          annotation.setPoint(imagePixel);
          this.drawingState = ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT;
        }
      } else {
        this.reset();
      }

      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.userPoints.length > 0 && this.graphicAnnotation) {
      const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      if (this.userPoints[0].equals(currentRenderPixel)) {
        return true;
      }

      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, this.renderEngine.getDisplayArea(), 0, 0)) {
        const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT) {
          annotation.setEndPoint(imagePixel);
        } else if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT) {
          annotation.setEndPoint(imagePixel);
          annotation.setSecondBoundPoint(imagePixel);
        }
      }

      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description Render the Line annotations for the given annotation array
   * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.AngleGraphicAnnotation = annotationArray[m];
        // While a user is creating a new object just draw this one. No need to go off and draw everything.
        // TODO Unfortunately this logic stopped behaving as desired, resulting is other annotations of
        // the same type being hidden while a new one is being drawn. So for now commenting out and
        // allowing all to be drawn.
        // if (!this.isMeasuring || this.annotation === graphicAnnotation) {
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;
          const selectedPointIndex = graphicAnnotation.getSelectedPointIndex();

          // There should be exactly one graphic object with either two (while drawing) or four points.
          if (graphicObjects.length === 1) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[0];
            const numPoints = graphicObject.graphicData.length;

            if (numPoints > 1) {
              let imagePixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[0]);
              let imagePixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[1]);

              context.strokeStyle = graphicAnnotation.isHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);

              context.beginPath();
              context.moveTo(imagePixelStartPoint.x, imagePixelStartPoint.y);
              context.lineTo(imagePixelEndPoint.x, imagePixelEndPoint.y);
              context.stroke();
              context.closePath();

              if (selectedPointIndex === 0 || graphicAnnotation.isHighlighted()) {
                context.strokeRect(imagePixelStartPoint.x - this.grabberSize / 2,
                  imagePixelStartPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }

              if (selectedPointIndex === 1 || graphicAnnotation.isHighlighted()) {
                context.strokeRect(imagePixelEndPoint.x - this.grabberSize / 2,
                  imagePixelEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }

              if (numPoints > 3) {
                imagePixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[2]);
                imagePixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[3]);

                context.beginPath();
                context.moveTo(imagePixelStartPoint.x, imagePixelStartPoint.y);
                context.lineTo(imagePixelEndPoint.x, imagePixelEndPoint.y);
                context.stroke();
                context.closePath();

                if (selectedPointIndex === 2 || graphicAnnotation.isHighlighted()) {
                  context.strokeRect(imagePixelStartPoint.x - this.grabberSize / 2,
                    imagePixelStartPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }
                if (selectedPointIndex === 3 || graphicAnnotation.isHighlighted()) {
                  context.strokeRect(imagePixelEndPoint.x - this.grabberSize / 2,
                    imagePixelEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }

                if (!this.isMeasuring && this.calculatePerpendicularLines(graphicObjects[0].graphicData)) {
                  this.calculateCobbAngle();
                  this.updateAnnotationText(graphicAnnotation);

                  // First perpendicular line.
                  context.setLineDash([7, 5]);

                  context.beginPath();
                  context.moveTo(this.perpLinePoints1[0].x, this.perpLinePoints1[0].y);
                  context.lineTo(this.perpLinePoints1[1].x, this.perpLinePoints1[1].y);
                  context.stroke();
                  context.closePath();

                  // Second perpendicular line.
                  context.beginPath();
                  context.moveTo(this.perpLinePoints2[0].x, this.perpLinePoints2[0].y);
                  context.lineTo(this.perpLinePoints2[1].x, this.perpLinePoints2[1].y);
                  context.stroke();
                  context.closePath();

                  // Back to using solid lines.
                  context.setLineDash([]);

                  const dx1 = this.perpLinePoints1[0].x - this.vertexPoint.x;
                  const dy1 = this.perpLinePoints1[0].y - this.vertexPoint.y;
                  const dx2 = this.perpLinePoints2[1].x - this.vertexPoint.x;
                  const dy2 = this.perpLinePoints2[1].y - this.vertexPoint.y;

                  const a1 = Math.atan2(dy1, dx1);
                  const a2 = Math.atan2(dy2, dx2);

                  // Any angles that aren't between 0 and 90 degrees aren't "real world".
                  // Just avoid making a drawing that looks silly.
                  if (a1 < Math.abs(Math.PI / 4) && a2 < Math.abs((Math.PI / 4))) {
                    context.beginPath();
                    context.moveTo(this.vertexPoint.x, this.vertexPoint.y);
                    if (a1 < a2) {
                      context.arc(this.vertexPoint.x, this.vertexPoint.y, 30, a1, a2);
                    } else {
                      context.arc(this.vertexPoint.x, this.vertexPoint.y, 30, a2, a1);
                    }
                    context.stroke();
                    context.closePath();
                  }
                }
              }
            }
          }
        }

        if (graphicAnnotation.showLabel) {
          this.renderTextObjects(context, graphicAnnotation);
        }
        // }
      }
    }
  }

  protected createGraphicAnnotation(clickedPoint: Fovia.Util.Point): void {
    if (this.userPoints.length === 0) {
      const annotation = new Fovia.PolylineGraphicAnnotation(this.graphicLayer);
      const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(clickedPoint);

      // Fire up the two points for the first line. These will get updated by move2D/up.
      this.userPoints = [clickedPoint, clickedPoint];

      // Keep the anchor point in image coordinates.
      this.anchorPoint = imagePixel;

      annotation.setSelectedObjectIndex(0);

      // Add graphic data
      const graphicObjects: Array<Fovia.GraphicObject> = [];
      const graphicData: Array<Fovia.Util.Point> = [];

      // Begin with two points that are the same.
      graphicData.push(imagePixel);
      graphicData.push(imagePixel);
      const graphicObject = new Fovia.GraphicObject(graphicData, Fovia.GraphicType.polyline, false, 'PIXEL', 2);
      graphicObjects.push(graphicObject);
      annotation.graphicObjects = graphicObjects;
      this.graphicAnnotation = annotation;
      this.addLineAnnotation(annotation, false);
    }
  }

  protected updateAnnotationText(graphicAnnotation: Fovia.GraphicAnnotation): void {
    const graphicObject: Fovia.GraphicObject = graphicAnnotation.graphicObjects[0];
    if (graphicObject.graphicData.length === 4) {
      const boundingRect = this.getBoundingBox(convertToRenderPixel(this.renderEngine, graphicObject.graphicData));
      const points = [new Fovia.Util.Point(boundingRect.left, boundingRect.top), new Fovia.Util.Point(boundingRect.right, boundingRect.bottom)];
      const displayArea = this.renderEngine.getDisplayArea();
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea)) {
        if (this.showMeasurement) {
          // Render the label at intersection of the two perpendiculars.
          const anchorPointImagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(new Fovia.Util.Point(this.vertexPoint.x + 10, this.vertexPoint.y - 10));
          const anchorPointRenderPixel = new Fovia.Util.Point(this.vertexPoint.x, this.vertexPoint.y);

          const context = this.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));
          const displayArea = this.renderEngine.getDisplayArea();

          const textObjectConstructs: Fovia.Util.TextObjectConstructs = {
            anchorPointImagePixel: anchorPointImagePixel,
            anchorPointRenderPixel: anchorPointRenderPixel,
            label: this.cobbAngleText,
            context: context,
            displayArea: displayArea,
            fontHeight: this.visualAttribute.font.size * Fovia.Util.Constants.DEFAULT_FONT_METRIC
          };

          const textObject = Fovia.PresentationUtil.getTextObject(textObjectConstructs, false);
          if (graphicAnnotation && graphicAnnotation.textObjects.length === 0) {
            graphicAnnotation.textObjects.push(textObject);
          } else {
            graphicAnnotation.textObjects = [textObject];
          }
        }
      }
    }
  }

  protected override resetDrawingState(): void {
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    this.drawingState = ANGLE_DRAWING_STATE.CREATE_STARTING_POINT;

    this.anchorPoint = new Fovia.Util.Point(0, 0);
    this.boundingBoxTopLeftPoint = new Fovia.Util.Point(0, 0);
    this.boundingBoxBottomRightPoint = new Fovia.Util.Point(0, 0);
    this.userPoints = [];
    this.perpLinePoints1 = [new Fovia.Util.Point(0, 0), new Fovia.Util.Point(0, 0)];
    this.perpLinePoints2 = [new Fovia.Util.Point(0, 0), new Fovia.Util.Point(0, 0)];
    this.vertexPoint = new Fovia.Util.Point(0, 0);
    this.cobbAngleRadians = 0;
    this.cobbAngleText = '';
  }

  private calculateCobbAngle(): void {
    const pixelSpacing = Fovia.PresentationUtil.toVector(this.pixelSpacing);
    if (pixelSpacing.x !== 0 && pixelSpacing.y !== 0) {
      const pnt1 = this.perpLinePoints1[0];
      const pntV = this.vertexPoint;
      const pnt2 = this.perpLinePoints2[1];

      // Adjust for possible non 1:1 aspect ratio.
      if (pixelSpacing.x !== pixelSpacing.y) {
        pnt1.x = pnt1.x / pixelSpacing.x;
        pnt1.y = pnt1.y / pixelSpacing.y;

        pntV.x = pntV.x / pixelSpacing.x;
        pntV.y = pntV.y / pixelSpacing.y;

        pnt2.x = pnt2.x / pixelSpacing.x;
        pnt2.y = pnt2.y / pixelSpacing.y;
      }
      this.cobbAngleRadians = this.calculateAngleFromPoints(pnt1, pntV, pnt2);
      this.cobbAngleText = ((Math.round(this.cobbAngleRadians * 180 / Math.PI) * 10) / 10).toString() + String.fromCharCode(176);
    }
  }

  private calculateAngleFromPoints(pntEnd1: Fovia.Util.Point, pntVertex: Fovia.Util.Point, pntEnd2: Fovia.Util.Point): number {
    if (pntEnd1.equals(pntEnd2) || pntEnd1.equals(pntVertex) || pntEnd2.equals(pntVertex)) {
      return 0.0;
    }

    // Translate origin
    pntEnd1 = pntEnd1.sub(pntVertex);
    pntEnd2 = pntEnd2.sub(pntVertex);

    // The cosine of the angle = (dot product of vectors) / (product of vector magnitudes).
    const dInnerE1E2 = this.calculateInnerProduct(pntEnd1, pntEnd2);
    const dInnerE1 = this.calculateInnerProduct(pntEnd1, pntEnd1);
    const dInnerE2 = this.calculateInnerProduct(pntEnd2, pntEnd2);
    const dCos = dInnerE1E2 / (Math.sqrt(dInnerE1) * Math.sqrt(dInnerE2));

    // Calculate radians.
    let angleRadians = Math.acos(dCos);

    // We always want an angle less than or equal to 180 degrees.
    if (angleRadians > Math.PI) {
      angleRadians = Math.PI - angleRadians;
    }
    return angleRadians;
  }

  private calculateInnerProduct(point1: Fovia.Util.Point, point2: Fovia.Util.Point): number {
    return (point1.x * point2.x) + (point1.y * point2.y);
  }

  private calculatePerpendicularLines(points: Fovia.Util.Point[]): boolean {
    let rtnVal = false;
    if (points.length === 4) {
      const point1 = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(points[0]);
      const point2 = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(points[1]);
      const point3 = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(points[2]);
      const point4 = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(points[3]);

      // The vertex will be the average of the four user points
      this.vertexPoint.x = Math.round(point1.x + point2.x + point3.x + point4.x) / 4.0;
      this.vertexPoint.y = Math.round(point1.y + point2.y + point3.y + point4.y) / 4.0;

      // Define a perpendicular line orthogonal to the first user-drawn line passing through the vertex.
      let deltaX = point2.x - point1.x;
      let deltaY = point2.y - point1.y;
      this.perpLinePoints1[0] = this.vertexPoint;
      this.perpLinePoints1[1].x = this.vertexPoint.x - deltaY;
      this.perpLinePoints1[1].y = this.vertexPoint.y + deltaX;

      // Adjust this perpendicular line to intersect with both of the user input segments.
      this.perpLinePoints1[0] = this.intersectLines(this.perpLinePoints1[0], this.perpLinePoints1[1], point1, point2);
      this.perpLinePoints1[1] = this.intersectLines(this.perpLinePoints1[0], this.perpLinePoints1[1], point3, point4);

      // Define a perpendicular line orthogonal to the second user line passing through the vertex.
      deltaX = point4.x - point3.x;
      deltaY = point4.y - point3.y;
      this.perpLinePoints2[0] = this.vertexPoint;
      this.perpLinePoints2[1].x = this.vertexPoint.x - deltaY;
      this.perpLinePoints2[1].y = this.vertexPoint.y + deltaX;

      // Adjust this perpendicular line to intersect with both of the user input segments.
      this.perpLinePoints2[0] = this.intersectLines(this.perpLinePoints2[0], this.perpLinePoints2[1], point3, point4);
      this.perpLinePoints2[1] = this.intersectLines(this.perpLinePoints2[0], this.perpLinePoints2[1], point1, point2);

      rtnVal = true;
    }

    return rtnVal;
  }

  private intersectLines(point1Segment1: Fovia.Util.Point,
    point2Segment1: Fovia.Util.Point,
    point1Segment2: Fovia.Util.Point,
    point2Segment2: Fovia.Util.Point): Fovia.Util.Point {

    let intersectPoint = new Fovia.Util.Point(0, 0);
    // Check for invalid input
    const bSeg1Vert = (point2Segment1.x === point1Segment1.x);
    const bSeg2Vert = (point2Segment2.x === point1Segment2.x);

    if (!point1Segment1.equals(point2Segment1) && !point1Segment2.equals(point2Segment2) && !(bSeg1Vert && bSeg2Vert)) {
      let slope1 = 0.0;
      let yIntercept1 = 0.0;
      if (!bSeg1Vert) {
        slope1 = (point2Segment1.y - point1Segment1.y) / (point2Segment1.x - point1Segment1.x);
        yIntercept1 = point1Segment1.y - (slope1 * point1Segment1.x);
      }

      let slope2 = 0.0;
      let yIntercept2 = 0.0;
      if (!bSeg2Vert) {
        slope2 = (point2Segment2.y - point1Segment2.y) / (point2Segment2.x - point1Segment2.x);
        yIntercept2 = point1Segment2.y - (slope2 * point1Segment2.x);
      }
      intersectPoint = this.intersectLinesSlopeIntercept(point1Segment1, slope1, yIntercept1, bSeg1Vert, point1Segment2, slope2, yIntercept2, bSeg2Vert);
    }
    return intersectPoint;
  }
  private intersectLinesSlopeIntercept(point1: Fovia.Util.Point,
    slope1: number,
    yIntercept1: number,
    line1Vertical: boolean,
    point2: Fovia.Util.Point,
    slope2: number,
    yIntercept2: number,
    line2Vertical: boolean): Fovia.Util.Point {

    const intersectPoint = new Fovia.Util.Point(0, 0);
    if (!line1Vertical && !line2Vertical) {
      if (Math.abs(slope1 - slope2) < 0.0000001) {
        // Lines are parallel. Return empty point.
        return intersectPoint;
      }
      const x = (yIntercept2 - yIntercept1) / (slope1 - slope2);
      intersectPoint.x = Math.round(x);
      intersectPoint.y = Math.round((slope1 * x) + yIntercept1);
    } else if (line1Vertical) {
      intersectPoint.x = point1.x;
      intersectPoint.y = Math.round((slope2 * point1.x) + yIntercept2);
    } else if (line2Vertical) {
      intersectPoint.x = point2.x;
      intersectPoint.y = Math.round((slope1 * point2.x) + yIntercept1);
    }

    return intersectPoint;
  }

  private getBoundingBox(points: Fovia.Util.Point[]): Fovia.Util.Rect {
    const rect: Fovia.Util.Rect = new Fovia.Util.Rect(Number.MIN_VALUE, Number.MAX_VALUE, Number.MIN_VALUE, Number.MAX_VALUE);

    for (let i = 0; i < points.length; i++) {
      rect.top = Math.min(points[i].y, rect.top);
      rect.left = Math.min(points[i].x, rect.left);
      rect.bottom = Math.max(points[i].y, rect.bottom);
      rect.right = Math.max(points[i].x, rect.right);
    }

    return rect;
  }
}
