import Fovia from 'foviaapi';
import HTMLViewport = Fovia.UI.HTMLViewport;
import HTMLViewport3D = Fovia.UI.HTMLViewport3D;
import FoviaPoint = Fovia.Util.Point;
import RayStopInfo = Fovia.RayStopInfo;
import RETURN_CODE = Fovia.ReturnCode;
import { AdaptorsService } from '../services';
import { MOUSE_BUTTONS } from '../directives/input.directive';
import { Point } from '../utils';

class MouseEventEx extends MouseEvent {
  viewportAdjusted: FoviaPoint = new FoviaPoint(); // See fovia computation for this vp relative point
}

// 3D Only adaptor to support MPR/3D synchronization of
// Cross-hair rotation and scrolling
export class ObliqueAdaptor implements Fovia.UI.MouseAdaptorInterface {

  private lastAngle: number;
  private origin: Point;

  constructor(
    private readonly htmlViewport: HTMLViewport3D,
    private adaptorsService: AdaptorsService) {
    this.lastAngle = 0;
    this.origin = new Point();
    this.onShootRayCallback.bind(this);
  }
  public down(event: MouseEventEx, renderParams: Fovia.RenderParams): Promise<boolean> {
    const localX = event.viewportAdjusted.x;
    const localY = event.viewportAdjusted.y;

    if (event.buttons === MOUSE_BUTTONS.eLeft) {
      // Rotate
      this.lastAngle = Math.atan2((localY - this.origin.y), (localX - this.origin.x));
    }
    if (event.buttons === MOUSE_BUTTONS.eMiddle) {
      // scrolling
      this.lastAngle = Math.atan2((localY - this.origin.y), (localX - this.origin.x));
    }
    if (event.buttons === MOUSE_BUTTONS.eRight) {
      // Sync point for viewports
      this.htmlViewport.getRenderEngine().shootRay([new FoviaPoint(localX, localY)], this.onShootRayCallback);
    }
    return Promise.resolve(false);
  }

  public up(event: MouseEventEx, renderParams: Fovia.RenderParams): Promise<boolean> {
    return Promise.resolve(false);
  }

  public move(event: MouseEventEx, renderParams: Fovia.RenderParams): Promise<boolean> {
    return Promise.resolve(false);
  }

  public wheel(event: WheelEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    return Promise.resolve(false);
  }

  public postRender(htmlViewport: any, renderParams: any): any {
    return;
  }
  protected onShootRayCallback(err: RETURN_CODE, rayStopInfoList: Array<RayStopInfo>): void {
    if (err === RETURN_CODE.ok) {
      // TO DO:
      // 1. update cameraposition to rayStopInfoList[0].volCoordinate and render for each vp.
    }
  }

}
