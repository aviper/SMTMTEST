import { CircleAnnotationEditProcessor } from './circle-annotation-edit-processor';

describe('CircleAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new CircleAnnotationEditProcessor()).toBeTruthy();
  });
});
