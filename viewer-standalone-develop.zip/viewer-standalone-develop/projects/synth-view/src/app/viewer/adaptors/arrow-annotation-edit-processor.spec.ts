import { LineMeasurementEditProcessor } from './line-measurement-edit-processor';

describe('LineMeasurementEditProcessor', () => {
  it('should create an instance', () => {
    expect(new LineMeasurementEditProcessor(null)).toBeTruthy();
  });
});
