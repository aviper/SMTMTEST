import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import Fovia from 'foviaapi';
import { ANGLE_ANNOTATION_LAYER } from './adaptor-constants';
import AngleGraphicAnnotation = Fovia.AngleGraphicAnnotation;
import { AdaptorsService } from "../services";

enum ANGLE_DRAWING_STATE {
  CREATE_STARTING_POINT,
  DRAGGING_FIRST_END_POINT,
  LOCK_FIRST_END_POINT,
  DRAGGING_SECOND_END_POINT,
  LOCK_SECOND_END_POINT
}

export class AngleAnnotationAdaptor extends AbstractAnnotationAdaptor {
  protected startingPoint: Fovia.Util.Point | null = new Fovia.Util.Point(0, 0);
  protected drawingState: ANGLE_DRAWING_STATE = ANGLE_DRAWING_STATE.CREATE_STARTING_POINT;
  protected boundingBoxTopLeftPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxBottomRightPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected anchorPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected angle = '';

  constructor(viewport: Fovia.UI.HTMLViewport, volumeDataContext: Fovia.VolumeDataContext | null, adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, true, adaptorService);
    this.graphicLayer = ANGLE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.angle;
  }

  /**
   * @description called when the user releases the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.graphicAnnotation != null && this.startingPoint != null) {
      if (this.drawingState === ANGLE_DRAWING_STATE.LOCK_FIRST_END_POINT) {
        this.drawingState = ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT;
      } else if (this.drawingState === ANGLE_DRAWING_STATE.LOCK_SECOND_END_POINT) {
        this.reset();
        this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
      }
    }

    this.viewport.repaint();

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const displayArea = this.renderEngine.getDisplayArea();
    const points = [currentRenderPixel];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
      const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
      if (this.drawingState === ANGLE_DRAWING_STATE.CREATE_STARTING_POINT) {
        this.startingPoint = imagePixel;
        this.isMeasuring = true;
        this.drawingState = ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT;

        if (this.graphicAnnotation == null) {
          this.createGraphicAnnotation();
          this.anchorPoint = this.startingPoint;
        }
      } else if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT) {
        // draw first end point
        if (this.graphicAnnotation) {
          this.graphicAnnotation.setFirstBoundPoint(imagePixel);
          this.drawingState = ANGLE_DRAWING_STATE.LOCK_FIRST_END_POINT;
        }
      } else if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT) {
        // draw second end point
        if (this.graphicAnnotation) {
          this.graphicAnnotation.setSecondBoundPoint(imagePixel);
          this.updateMeasurementLabel();
          this.drawingState = ANGLE_DRAWING_STATE.LOCK_SECOND_END_POINT;
        }
      }

      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      if (this.startingPoint == null || this.startingPoint.equals(currentRenderPixel)) {
        return true;
      }

      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, this.renderEngine.getDisplayArea(), 0, 0)) {
        const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_FIRST_END_POINT) {
          if (this.graphicAnnotation) {
            this.graphicAnnotation.setFirstBoundPoint(point);
          }
        } else if (this.drawingState === ANGLE_DRAWING_STATE.DRAGGING_SECOND_END_POINT) {
          if (this.graphicAnnotation) {
            this.graphicAnnotation.setSecondBoundPoint(point);
            this.updateMeasurementLabel();
          }
          this.updateAnnotation();
        }
      }

      this.viewport.repaint();
    }

    return true;
  }

  protected createGraphicAnnotation(): void {
    if (this.startingPoint) {
      const annotation = new Fovia.AngleGraphicAnnotation(this.graphicLayer);
      annotation.addGraphicObject();
      annotation.setSelectedObjectIndex(0);
      annotation.setVertexPoint(this.startingPoint);
      annotation.setFirstBoundPoint(this.startingPoint);
      annotation.setSecondBoundPoint(this.startingPoint);
      this.graphicAnnotation = annotation;
      this.addAngleAnnotation(annotation);
    }
  }
  protected updateMeasurementLabel(): void {
    const annotation = this.graphicAnnotation as AngleGraphicAnnotation;
    this.angle = annotation.updateMeasurementLabel(this.renderEngine.getDicomCharSet());
  }

  /**
   * @description Render the Line annotations for the given annotation array
   * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.AngleGraphicAnnotation = annotationArray[m];
        // While a user is creating a new object just draw this one. No need to go off and draw everything.
        // TODO Unfortunately this logic stopped behaving as desired, resulting is other annotations of
        // the same type being hidden while a new one is being drawn. So for now commenting out and
        // allowing all to be drawn.
        // if (!this.isMeasuring || this.annotation === graphicAnnotation) {
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;

          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];

            if (graphicObject.graphicData.length === 3) {
              const imagePixelVertexPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[0]);
              const imagePixelFirstEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[1]);
              const imagePixelSecondEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[2]);

              context.strokeStyle = graphicAnnotation.isHighlighted() ? this.colorHighlight : this.colorNormal;

              context.beginPath();
              context.moveTo(imagePixelFirstEndPoint.x, imagePixelFirstEndPoint.y);
              context.lineTo(imagePixelVertexPoint.x, imagePixelVertexPoint.y);
              context.lineTo(imagePixelSecondEndPoint.x, imagePixelSecondEndPoint.y);
              context.stroke();
              context.closePath();

              if (graphicAnnotation.isVertexPointHighlighted()) {
                context.strokeRect(imagePixelVertexPoint.x - this.grabberSize / 2,
                  imagePixelVertexPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }

              if (graphicAnnotation.isStartPointHighlighted()) {
                context.strokeRect(imagePixelFirstEndPoint.x - this.grabberSize / 2,
                  imagePixelFirstEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }

              if (graphicAnnotation.isEndPointHighlighted()) {
                context.strokeRect(imagePixelSecondEndPoint.x - this.grabberSize / 2,
                  imagePixelSecondEndPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }
            }
          }

          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation);
          }
        }
        // }
      }
    }
  }

  public override isDrawingCompleted(): boolean {
    return (this.drawingState === ANGLE_DRAWING_STATE.CREATE_STARTING_POINT);
  }

  protected updateAnnotation(): void {
    if (this.startingPoint) {
      const distance = this.startingPoint.calculateDistance(this.anchorPoint);
      this.boundingBoxTopLeftPoint = new Fovia.Util.Point(this.anchorPoint.x - distance, this.anchorPoint.y - distance);
      this.boundingBoxBottomRightPoint = new Fovia.Util.Point(this.anchorPoint.x + distance, this.anchorPoint.y + distance);
      const boundingBoxTopLeftPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(this.boundingBoxTopLeftPoint);
      const boundingBoxBottomRightPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(this.boundingBoxBottomRightPoint);

      const points = [boundingBoxTopLeftPoint, boundingBoxBottomRightPoint];
      const displayArea = this.renderEngine.getDisplayArea();
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        if (this.showMeasurement) {
          // Render the label at the vertex point.
          const anchorPointImagePixel = new Fovia.Util.Point((this.boundingBoxTopLeftPoint.x + this.boundingBoxBottomRightPoint.x) / 2, this.boundingBoxBottomRightPoint.y);
          const anchorPointRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPointImagePixel);
          const context = this.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));
          const displayArea = this.renderEngine.getDisplayArea();

          const textObjectConstructs: Fovia.Util.TextObjectConstructs = {
            anchorPointImagePixel: anchorPointImagePixel,
            anchorPointRenderPixel: anchorPointRenderPixel,
            label: this.angle,
            context: context,
            displayArea: displayArea,
            fontHeight: this.visualAttribute.font.size * Fovia.Util.Constants.DEFAULT_FONT_METRIC
          };

          const textObject = Fovia.PresentationUtil.getTextObject(textObjectConstructs, false);
          if (this.graphicAnnotation && this.graphicAnnotation.textObjects.length === 0) {
            this.graphicAnnotation.textObjects.push(textObject);
          } else if (this.graphicAnnotation) {
            this.graphicAnnotation.textObjects = [textObject];
          }
        }
      }
    }
  }

  protected override resetDrawingState(): void {
    this.drawingState = ANGLE_DRAWING_STATE.CREATE_STARTING_POINT;
  }
}
