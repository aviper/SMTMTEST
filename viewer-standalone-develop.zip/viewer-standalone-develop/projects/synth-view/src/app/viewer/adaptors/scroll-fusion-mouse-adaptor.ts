import Fovia from 'foviaapi';
import ScrollAdaptorData = Fovia.UI.ScrollAdaptorData;
import { getPendingRenderParamsFusion } from '@server-api';
import { AdaptorsService } from '../services';
import { SeriesDisplayStoreItem3D } from '../stores';

export class ScrollFusionMouseAdaptor implements Fovia.UI.MouseAdaptorInterface {
  public renderEngine: Fovia.BlendedRenderEngineContext3D;
  public htmlViewportFusion: Fovia.UI.HTMLFusionViewportMPR;
  private scrollDataList: ScrollAdaptorData[];
  private scrollAdaptorList: ScrollFusionAdaptor[];
  private lastMouseX = 0;
  private lastMouseY = 0;
  private mouseDown = false;
  private inProcessofScrolling = false;
  private needsRenderFinal = false;
  private scrollListener: any;

  constructor(htmlViewportFusion: Fovia.UI.HTMLFusionViewportMPR, increment: number, private adaptorsService: AdaptorsService, mprScrollListener?: any) {
    this.htmlViewportFusion = htmlViewportFusion;
    this.renderEngine = this.htmlViewportFusion.getRenderEngine();
    this.scrollDataList = [
      new Fovia.UI.ScrollAdaptorData(this.renderEngine.getRenderEngine(0).getVolumeDataContext(), increment),
      new Fovia.UI.ScrollAdaptorData(this.renderEngine.getRenderEngine(1).getVolumeDataContext(), increment)
    ];
    this.scrollAdaptorList = [
      new ScrollFusionAdaptor(this.htmlViewportFusion, this.scrollDataList[0]),
      new ScrollFusionAdaptor(this.htmlViewportFusion, this.scrollDataList[1])
    ];
    if (mprScrollListener) {
      this.addScrollListener(mprScrollListener);
    }
  }

  /**
   * Add observer for scrolling
   * @param listener
   */
  public addScrollListener(listener: any): void {
    if (listener == null || typeof (listener) !== 'function') {
      throw new Fovia.APIError('addScrollListener, invalid callback ', listener);
    }
    this.scrollListener = listener;
  }

  public async down(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    if (this.renderEngine == null) {
      console.error('ScrollFusionMouseAdaptor down failed. renderEngine is null');
      return false;
    }
    this.lastMouseX = event.viewportAdjusted.x;
    this.lastMouseY = event.viewportAdjusted.y;
    this.mouseDown = true;
    const rps = getPendingRenderParamsFusion(this.htmlViewportFusion);
    this.scrollAdaptorList[0].init(rps[0]);
    this.scrollAdaptorList[1].init(rps[1]);
    this.inProcessofScrolling = false;
    this.needsRenderFinal = false;
    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (!this.mouseDown || event.buttons === 0) {
      return false;
    }
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();;
    if (seriesDisplayItem == null) {
      console.error('ScrollFusionMouseAdaptor move failed. seriesDisplayItem3D is null');
      return false;
    }
    // short circuit this method when viewport is busy
    if (this.adaptorsService.pauseTool || this.inProcessofScrolling || seriesDisplayItem?.isRendering()) {
      return false;
    }
    if (this.renderEngine == null) {
      console.error('ScrollFusionMouseAdaptor move failed. renderEngine is null');
      return false;
    }

    this.inProcessofScrolling = true;
    const delta = (this.lastMouseY - event.viewportAdjusted.y);
    const rps = getPendingRenderParamsFusion(this.htmlViewportFusion);
    const distanceLimits0 = Math.round(this.computeDistancetoScroll(delta, rps[0].imageHeight, this.scrollAdaptorList[0].datasetextentsindirection));
    const distanceLimits1 = Math.round(this.computeDistancetoScroll(delta, rps[1].imageHeight, this.scrollAdaptorList[1].datasetextentsindirection));
    const rp0 = this.scrollAdaptorList[0].scroll(distanceLimits0);
    const rp1 = this.scrollAdaptorList[1].scroll(distanceLimits1);

    if (rp0 !== null && rp1 != null) {
      if (this.scrollListener) {  // if we have a observer, inform now
        this.scrollListener([rp0, rp1]);
      }

      const blendedRenderEngine = this.renderEngine;
      await blendedRenderEngine.setRenderParams(0, rp0);
      await blendedRenderEngine.setRenderParams(1, rp1);

      this.lastMouseX = event.viewportAdjusted.x;
      this.lastMouseY = event.viewportAdjusted.y;
    } else {
      this.lastMouseY = event.viewportAdjusted.y;
    }
    await seriesDisplayItem.renderFoviaFinal();
    this.inProcessofScrolling = false;

    return true;
  }

  // triggers the final render
  public async up(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (this.renderEngine == null) {
      console.error('ScrollFusionMouseAdaptor up failed. renderEngine is null');
      return false;
    }
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplayItem == null) {
      console.error('ScrollFusionMouseAdaptor up failed. seriesDisplayItem3D is null');
      return false;
    }
    if (this.mouseDown) {
      await seriesDisplayItem.renderFoviaFinal();
    }
    this.mouseDown = false;
    return true;
  }

  public async wheel(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (this.mouseDown) {
      return false;
    }
    if (this.inProcessofScrolling) {
      return false;
    }
    if (this.renderEngine == null) {
      console.error('ScrollFusionMouseAdaptor wheel failed. renderEngine is null');
      return false;
    }
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplayItem == null) {
      console.error('ScrollFusionMouseAdaptor wheel failed. seriesDisplayItem3D is null');
      return false;
    }

    this.inProcessofScrolling = true;
    const e = event;
    const delta = e.detail < 0 || e.wheelDelta > 0 ? 1 : -1;

    // @ts-ignore
    const rps = getPendingRenderParamsFusion(this.htmlViewportFusion);
    this.scrollAdaptorList[0].init(rps[0]);
    // @ts-ignore
    this.scrollAdaptorList[1].init(rps[1]);
    const rp0 = this.scrollAdaptorList[0].scroll(delta);
    const rp1 = this.scrollAdaptorList[1].scroll(delta);

    if (rp0 != null && rp1 != null) {
      if (this.scrollListener) {
        this.scrollListener([rp0, rp1]);
      }
      const blendedRenderEngine = this.renderEngine;
      await blendedRenderEngine.setRenderParams(0, rp0);
      await blendedRenderEngine.setRenderParams(1, rp1);
      await seriesDisplayItem.renderFoviaFinal();
    }
    this.inProcessofScrolling = false;
    return true;
  }

  public postRender(htmlViewport: any, renderParams: any): any {
    return;
  }

  // simple proportion, distance in pixels over total image height is proportional distance in dataset over total number of slices
  // number of slices and not distance in z direction is intentional, we want to scroll only along slices, supports viewing slices as they are, no interpolation
  // the math above does not take into consideration the zoom value, dataset could be bigger or smaller extents than image height
  private computeDistancetoScroll(distance: number, imageY: number, totalDistance: number): number {
    if (distance < 0) {
      return Math.floor(distance * totalDistance / imageY);
    } else {
      return Math.ceil(distance * totalDistance / imageY);
    }
  }
}

/**
 * Class to perform computations for scrolling, called up by external interfaces
 */
export class ScrollFusionAdaptor {
  public htmlViewportFusion: Fovia.UI.HTMLFusionViewportMPR;
  private scrollData: ScrollAdaptorData;
  private renderParams: Fovia.RenderParams3D | null = null;
  public datasetextentsindirection = 0.0;
  private zVectorindirection: Fovia.Util.Vector | null = null;

  constructor(htmlViewportFusion: Fovia.UI.HTMLFusionViewportMPR, scrollData: ScrollAdaptorData) {
    this.htmlViewportFusion = htmlViewportFusion;
    this.scrollData = scrollData;
  }
  /**
   * Call this function to initialize the adaptor
   * called during mouse down and computes certain values like spacing in arbitrary direction, total number of slices
   */
  public init(renderParams: Fovia.RenderParams3D): void {
    if (renderParams == null) {
      throw new Fovia.APIError(`ScrollFusionAdaptor init() failed, invalid render parameters`);
    }
    this.renderParams = renderParams;
    const viewplane: Fovia.Util.Plane = Fovia.Util.getPlaneEquationT(renderParams.transform);
    const zVector: Fovia.Util.Vector = renderParams.transform.getZVector();
    if (!this.scrollData.useSpecifiedSpacing) {
      this.scrollData.spacinginDirection = this.computeSpacing(zVector, this.scrollData.vdc.spacing);
    }
    const totaldiscomputation = this.maxminPointOnPlaneDistance(viewplane, this.scrollData.volumeBoxPoints, zVector);
    this.datasetextentsindirection = Math.abs(totaldiscomputation.maxDistance - totaldiscomputation.minDistance);
    this.zVectorindirection = zVector;
  }

  /**
   * Call this function to perform the scroll put in the distance value
   * If scaling is required for distance, input function should scale it
   */
  public scroll(distance: number): Fovia.RenderParams3D | null {
    let rpToRet: Fovia.RenderParams3D | null = null;
    const rp: Fovia.RenderParams3D | null = this.renderParams;

    if (this.zVectorindirection == null) {
      console.error('ScrollFusionAdaptor scroll failed. zVectorindirection is null');
      return null;
    }

    if (rp != null) {
      const zVector: Fovia.Util.Vector = rp.transform.getZVector();
      const offSetVector: Fovia.Util.Vector = rp.transform.getOffsetVector();
      const scaledistance = this.scrollData.spacinginDirection * distance; // compute offset from distance value

      const originPt: Fovia.Util.Vector = rp.transform.getOffsetVector();
      // compute the final by adding the computed offset to original offset
      const finalOffset: Fovia.Util.Vector = originPt.add(this.zVectorindirection.scale(scaledistance));

      rpToRet = new Fovia.RenderParams3D();
      rpToRet.transform = rp.transform;
      rpToRet.transform.setOffsetVector(finalOffset);
    }

    return rpToRet;
  }

  // Compute the spacing in arbitrary direction by taking in contributions from spacing in all directions project on current view (z) vector
  private computeSpacing(zVectorFromTransform: Fovia.Util.Vector, spacing: Fovia.Util.Vector): number {
    const lengthZVector = zVectorFromTransform.length();
    const tempVector: Fovia.Util.Vector = new Fovia.Util.Vector((spacing.x * zVectorFromTransform.x / lengthZVector), (spacing.y * zVectorFromTransform.y / lengthZVector), (spacing.z * zVectorFromTransform.z / lengthZVector));
    return tempVector.length();
  }

  private maxminPointOnPlaneDistance(viewplane: Fovia.Util.Plane, volumeBoxPoints: Fovia.Util.Vector[], zVector: Fovia.Util.Vector): PointOnPlaneDistance {
    let maxDistance = Number.MIN_VALUE;
    let minDistance = Number.MAX_VALUE;
    for (let count = 0; count < volumeBoxPoints.length; count++) {
      const dist1 = Fovia.Util.getsignedDistancePointandPlane(volumeBoxPoints[count], viewplane);
      if (dist1 > maxDistance) {
        maxDistance = dist1;
      }
      if (dist1 < minDistance) {
        minDistance = dist1;
      }
    }

    const distance: PointOnPlaneDistance = {
      maxDistance: maxDistance, // max allowed distance in negative direction before we will go out of dataset
      minDistance: minDistance, // max allowed distance in positive direction before we will go out of dataset
    };

    return distance;
  }
}

interface PointOnPlaneDistance {
  maxDistance: number;
  minDistance: number;
}
