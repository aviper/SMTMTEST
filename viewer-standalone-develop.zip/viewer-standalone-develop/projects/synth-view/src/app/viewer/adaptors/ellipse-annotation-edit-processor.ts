import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class EllipseAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  // Selected annotations to edit
  protected selectedAnnotation: Fovia.EllipseGraphicAnnotation | null = null;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the Ellipse annotation to be edit to null
   */
  public reset(): void {
    this.editMode = EDIT_MODE.none;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setPointHighlight(false);
      this.selectedAnnotation.setHighlight(false);
    }
  }

  /**
   * @description Set the given selected ellipse annotation to edit mode
   * @param selectedAnnotation ellipse annotation to be edited
   * @param currentPoint current mouse point
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.EllipseGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateEllipseEditMode();
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
      this.selectedAnnotation.setPointHighlight(true);

      if (this.editMode > EDIT_MODE.annotation) {
        this.selectedAnnotation.setHighlight(false);
      }

      if (this.editMode === EDIT_MODE.annotation) {
        this.selectedAnnotation.setHighlight(true);
      }
    }

    return this.editMode !== previousEditMode;
  }

  /**
   * @description update the circle edit mode from the selected annotation
   */

  private updateEllipseEditMode(): void {
    this.editMode = EDIT_MODE.none;

    if (this.selectedAnnotation == null) {
      return;
    }

    // Reset highlight flag
    this.selectedAnnotation.setPointHighlight(false);
    this.selectedAnnotation.setHighlight(false);
    const pointIndex = this.selectedAnnotation.getSelectedPointIndex();

    if (pointIndex === 0) {
      this.editMode = EDIT_MODE.annotation;
    } else {
      this.editMode = this.mapPointToMode(pointIndex - 1);
    }
  }

  /**
   * @description move the ellipse annotation to given current point
   * @param currentPoint current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point, currentImageData: Fovia.DICOMImageTags): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(currentPoint));
    const displayArea = this.renderEngine.getDisplayArea();
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint.x, currentPoint.y);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;
    this.selectedAnnotation.setPointHighlight(true);
    this.selectedAnnotation.setHighlight(false);
    this.selectedAnnotation.setShowLabelFlag(false);
    this.selectedAnnotation.resetTextObjects();

    const firstBoundsPoint = this.selectedAnnotation.getFirstBoundsPoint();
    const secondBoundsPoint = this.selectedAnnotation.getSecondBoundsPoint();
    const reversedRotatedFirstPoint = this.renderEngine.getReverseRotatedImagePoint(firstBoundsPoint);
    const reversedRotatedSecondPoint = this.renderEngine.getReverseRotatedImagePoint(secondBoundsPoint);
    const firstRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedFirstPoint);
    const secondRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(reversedRotatedSecondPoint);
    const isReversed = this.isReversed();

    switch (this.editMode) {
      case EDIT_MODE.annotation: {
        this.selectedAnnotation.setPointHighlight(false);
        this.selectedAnnotation.setHighlight(true);
        const points = [firstRenderPixel, secondRenderPixel];
        if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, deltaY)) {
          this.selectedAnnotation.move(deltaX, deltaY);
          this.selectedAnnotation.adjustLabel(deltaX, deltaY);
        } else {
          return false;
        }
      }
        break;
      case EDIT_MODE.top: {
        const points = [firstRenderPixel];
        if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, deltaY)) {
          if (isReversed) {
            this.selectedAnnotation.updateSecondBoundsPoint(0, deltaY);
          } else {
            this.selectedAnnotation.updateFirstBoundsPoint(0, deltaY);
          }
        } else {
          return false;
        }
      }
        break;
      case EDIT_MODE.right: {
        const points = [secondRenderPixel];
        if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, 0)) {
          if (isReversed) {
            this.selectedAnnotation.updateFirstBoundsPoint(deltaX, 0);
          } else {
            this.selectedAnnotation.updateSecondBoundsPoint(deltaX, 0);
          }
        } else {
          return false;
        }
      }
        break;
      case EDIT_MODE.bottom: {
        const points = [secondRenderPixel];
        if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, deltaY)) {
          if (isReversed) {
            this.selectedAnnotation.updateFirstBoundsPoint(0, deltaY);
          } else {
            this.selectedAnnotation.updateSecondBoundsPoint(0, deltaY);
          }
        } else {
          return false;
        }
      }
        break;
      case EDIT_MODE.left: {
        const points = [firstRenderPixel];
        if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, 0)) {
          if (isReversed) {
            this.selectedAnnotation.updateSecondBoundsPoint(deltaX, 0);
          } else {
            this.selectedAnnotation.updateFirstBoundsPoint(deltaX, 0);
          }
        } else {
          return false;
        }
      }
        break;
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }

  private mapPointToMode(pointIndex: number): EDIT_MODE {
    let mode = EDIT_MODE.none;

    const points = this.selectedAnnotation?.getEndPoints() ?? [];
    if (points.length === 4 && pointIndex >= 0 && pointIndex <= 4 && this.selectedAnnotation != null) {
      const point = points[pointIndex];

      if (point.x === Math.min(points[0].x, points[1].x, points[2].x, points[3].x)) {
        mode = EDIT_MODE.left;
      } else if (point.x === Math.max(points[0].x, points[1].x, points[2].x, points[3].x)) {
        mode = EDIT_MODE.right;
      } else if (point.y === Math.min(points[0].y, points[1].y, points[2].y, points[3].y)) {
        mode = EDIT_MODE.top;
      } else if (point.y === Math.max(points[0].y, points[1].y, points[2].y, points[3].y)) {
        mode = EDIT_MODE.bottom;
      }
    }
    return mode;
  }

  private isReversed(): boolean {
    return false;
    // if (this.selectedAnnotation == null) {
    //   return false;
    // }
    // const boundTL = this.selectedAnnotation.getFirstBoundsPoint();
    // const boundBR = this.selectedAnnotation.getFirstBoundsPoint();
    //
    // return boundTL.x > boundBR.x || boundTL.y < boundBR.y;
  }
}
