import { CircleAnnotationAdaptor } from './circle-annotation-adaptor';

describe('CircleAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new CircleAnnotationAdaptor()).toBeTruthy();
  });
});
