import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class CircleAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  // Selected annotations to edit
  private selectedAnnotation: Fovia.CircleGraphicAnnotation | null = null;
  private selectedPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  private referencePoint: Fovia.Util.Point | undefined;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the Line annotation to be edit to null
   */
  public reset(): void {
    this.editMode = EDIT_MODE.none;
    this.referencePoint = undefined;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setPointHighlight(false);
      this.selectedAnnotation.setHighlight(false);
    }
  }

  /**
   * @description Updates the Circle annotation to edit process if the current point is selected from Line annotation
   * @param selectedAnnotation Specifies the reference to Circle Annotation to edit
   * @param currentPoint Specifies the current mouse point location
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.CircleGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateEditMode();
      this.selectedPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
      this.selectedAnnotation.setPointHighlight(true);
      if (this.editMode > EDIT_MODE.annotation) {
        this.selectedAnnotation.setHighlight(false);
      }

      if (this.editMode === EDIT_MODE.annotation) {
        this.selectedAnnotation.setHighlight(true);
      }
    }

    return previousEditMode !== this.editMode;
  }

  /**
   * @description update the circle edit mode from the selected annotation
   */
  private updateEditMode(): void {

    if (this.selectedAnnotation == null) {
      return;
    }

    // Reset highlight flag
    this.selectedAnnotation.setPointHighlight(false);
    this.selectedAnnotation.setHighlight(false);

    switch (this.selectedAnnotation.getSelectedPointIndex()) {
      case 0:
        this.editMode = EDIT_MODE.annotation;
        break;
      case 1:
        this.editMode = EDIT_MODE.top;
        break;
      case 2:
        this.editMode = EDIT_MODE.right;
        break;
      case 3:
        this.editMode = EDIT_MODE.bottom;
        break;
      case 4:
        this.editMode = EDIT_MODE.left;
        break;
      default:
        this.editMode = EDIT_MODE.none;
        break;
    }
  }

  private editModeToPointIndex(): number {
    switch (this.editMode) {
      case EDIT_MODE.top:
        return 1;
      case EDIT_MODE.right:
        return 2;
      case EDIT_MODE.bottom:
        return 3;
      case EDIT_MODE.left:
        return 4;
      default:
        return -1;
    }
  }

  /**
   * @description move the annotation to given current point
   * @param currentPoint current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point, currentImageData: Fovia.DICOMImageTags): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(currentPoint));
    const displayArea = this.renderEngine.getDisplayArea();
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    const mousePoint = new Fovia.Util.Point(currentPoint.x, currentPoint.y);
    const previousTopLeft = this.renderEngine.getReverseRotatedImagePoint(this.selectedAnnotation.getFirstBoundsPoint());
    const previousBottomRight = this.renderEngine.getReverseRotatedImagePoint(this.selectedAnnotation.getSecondBoundsPoint());
    let topLeftRender = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(previousTopLeft);
    let bottomRightRender = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(previousBottomRight);
    const deltaX = mousePoint.x - this.selectedPoint.x;
    const deltaY = mousePoint.y - this.selectedPoint.y;

    if (this.editMode === EDIT_MODE.annotation) {
      const points = this.selectedAnnotation.getUpdatedEndPoints(topLeftRender, bottomRightRender);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.setPointHighlight(false);
        this.selectedAnnotation.move(deltaX, deltaY);
        this.selectedAnnotation.adjustLabel(deltaX, deltaY);
      } else {
        return false;
      }
    } else {
      // Move one of the points.
      this.selectedAnnotation.setPointHighlight(true);
      this.selectedAnnotation.setHighlight(false);

      // Get the center point of circle
      if (!this.referencePoint) {
        this.referencePoint = Fovia.PresentationUtil.getOppositePoint(this.editModeToPointIndex(), this.selectedAnnotation.getEndPoints());
      }

      const centerX = (mousePoint.x + this.referencePoint.x) / 2;
      const centerY = (mousePoint.y + this.referencePoint.y) / 2;
      const centerPoint = new Fovia.Util.Point(centerX, centerY);
      const radius = Math.round(centerPoint.calculateDistance(mousePoint));
      const newTopLeft = this.renderEngine.getReverseRotatedImagePoint(new Fovia.Util.Point(centerX - radius, centerY - radius));
      const newBottomRight = this.renderEngine.getReverseRotatedImagePoint(new Fovia.Util.Point(centerX + radius, centerY + radius));

      topLeftRender = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(newTopLeft);
      bottomRightRender = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(newBottomRight);

      const points = this.selectedAnnotation.getUpdatedEndPoints(topLeftRender, bottomRightRender);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        this.selectedAnnotation.setFirstBoundPoint(newTopLeft);
        this.selectedAnnotation.setSecondBoundPoint(newBottomRight);
        this.selectedAnnotation.setPoint(centerPoint);
        this.selectedAnnotation.setEndPoint(mousePoint);

        if (this.selectedAnnotation.textObjects.length !== 0) {
          const deltaX = centerPoint.x - ((previousTopLeft.x + previousBottomRight.x) / 2);
          const deltaY = newBottomRight.y - previousBottomRight.y;
          this.selectedAnnotation.adjustLabel(deltaX, deltaY);
        }
      } else {
        return false;
      }
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.selectedPoint = currentPoint;
    return true;
  }
}
