import Fovia from 'foviaapi';

import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { POINT_ANNOTATION_LAYER } from './adaptor-constants';
import { AdaptorsService } from '../services';


export class PointAnnotationAdaptor extends AbstractAnnotationAdaptor {

  protected pointAnnotation: Fovia.PointGraphicAnnotation | null = null;

  constructor(viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    adaptorService: AdaptorsService,
    showMeasurement: boolean = true) {
    super(viewport, volumeDataContext, showMeasurement, adaptorService);
    this.graphicLayer = POINT_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.point;
    this.supportsGenericDicomGraphicType = true;
  }

  /**
   * @description called when the user releases the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   *
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.renderEngine.getSeriesDataContext()) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      Fovia.PresentationUtil.validatePoints(currentRenderPixel, this.renderEngine.getDisplayArea());
      if (this.pointAnnotation === null) {
        this.pointAnnotation = new Fovia.PointGraphicAnnotation(this.graphicLayer);
        this.pointAnnotation.setSelectedObjectIndex(0);
      }

      // Add graphic data
      const graphicObjects: Array<Fovia.GraphicObject> = [];
      const graphicData: Array<Fovia.Util.Point> = [];
      const graphicObject = new Fovia.GraphicObject(graphicData, Fovia.GraphicType.point, false, 'PIXEL', 2);
      graphicObjects.push(graphicObject);
      this.pointAnnotation.graphicObjects = graphicObjects;

      this.updateAnnotationText(this.pointAnnotation, currentRenderPixel);

      this.pointAnnotation.updateNoOfGraphicPoints();

      this.addPointAnnotation(this.pointAnnotation);
      this.pointAnnotation = null;

      this.viewport.repaint();
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);

    }
    this.isMeasuring = false;
    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   *
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    this.isMeasuring = true;
    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   *
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.pointAnnotation) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      this.updateAnnotationText(this.pointAnnotation, currentRenderPixel);
      this.viewport.repaint();

      this.isMeasuring = true;
    } else {
      this.isMeasuring = false;
    }

    return true;
  }

  /**
   * @description Render the point annotations for the given annotation array
   *
   * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.PointGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;
          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];
            const point: Fovia.Util.Point = new Fovia.Util.Point(graphicObject.graphicData[0].x, graphicObject.graphicData[0].y);
            const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(point);

            context.fillStyle = graphicAnnotation.isPointHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);
            context.strokeRect(renderPixel.x - this.grabberSize / 2,
              renderPixel.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
          }
          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation);
          }
        }
      }
    }
  }
  /**
  * @description Provide hook to trigger updating of dynamic annotation values after movements
  *    or shape changes
  * @param selectedAnnotation current annotation
  */
  protected updateAnnotationText(selectedAnnotation: Fovia.PointGraphicAnnotation, screenPoint: Fovia.Util.Point): void {
    const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(screenPoint);
    selectedAnnotation.setPoint(point, this.renderEngine.getDicomCharSet());
  }
}
