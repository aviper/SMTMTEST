import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { convertToRenderPixel } from '../utils';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class AngleAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  // Selected annotations to edit
  private selectedAnnotation: Fovia.AngleGraphicAnnotation | null = null;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the angle annotation to null
   */
  public reset(): void {
    this.editMode = EDIT_MODE.none;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setStartPointHighlight(false);
      this.selectedAnnotation.setEndPointHighlight(false);
      this.selectedAnnotation.setVertexPointHighlight(false);
      this.selectedAnnotation.setHighlight(false);
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      this.selectedAnnotation.setSelectedObjectIndex(-1);
    }
  }

  /**
   * @description Updates the angle annotation to edit process if the current point is selected from angle annotation
   * @param selectedAnnotation Specifies the reference to angle Annotation to edit
   * @param currentPoint Specifies the current mouse point location
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.AngleGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateAngleEditMode(currentPoint);
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
    }

    return previousEditMode !== this.editMode;
  }

  /**
   * @description Set the flag based on whether the whole angle selected or any end points selected
   * @param currentPoint Specifies the current mouse point location
   */
  protected updateAngleEditMode(currentPoint: Fovia.Util.Point): void {
    if (this.selectedAnnotation == null || this.selectedAnnotation.graphicLayerIndex !== -1) {
      return;
    }
    this.selectedAnnotation.setStartPointHighlight(false);
    this.selectedAnnotation.setEndPointHighlight(false);
    this.selectedAnnotation.setVertexPointHighlight(false);

    const startPoint = this.selectedAnnotation.getFirstBoundPoint();
    const endPoint = this.selectedAnnotation.getSecondBoundPoint();
    const vertexPoint = this.selectedAnnotation.getVertexPoint();

    const renderPixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(startPoint.x, startPoint.y));
    const renderPixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(endPoint.x, endPoint.y));
    const renderPixelVertexPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(vertexPoint.x, vertexPoint.y));
    if (this.selectedAnnotation.isPointSelected(currentPoint, renderPixelStartPoint)) {
      this.editMode = EDIT_MODE.start;
      this.selectedAnnotation.setStartPointHighlight(true);
    } else if (this.selectedAnnotation.isPointSelected(currentPoint, renderPixelEndPoint)) {
      this.editMode = EDIT_MODE.end;
      this.selectedAnnotation.setEndPointHighlight(true);
    } else if (this.selectedAnnotation.isPointSelected(currentPoint, renderPixelVertexPoint)) {
      this.editMode = EDIT_MODE.vertex;
      this.selectedAnnotation.setVertexPointHighlight(true);
    } else {
      this.editMode = EDIT_MODE.annotation;
      this.selectedAnnotation.setStartPointHighlight(true);
      this.selectedAnnotation.setEndPointHighlight(true);
      this.selectedAnnotation.setVertexPointHighlight(true);
      this.selectedAnnotation.setHighlight(true);
    }
  }

  /**
   * @description Move the angle annoation to the current mouse point
   * @param currentPoint Specifies current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(currentPoint);
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();

    // Only the current point needs to be within the bounds if dragging a point. We'll check the bounds for
    // moving the entire annotation separately.
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;

    this.selectedAnnotation.setStartPointHighlight(false);
    this.selectedAnnotation.setEndPointHighlight(false);
    this.selectedAnnotation.setVertexPointHighlight(false);
    this.selectedAnnotation.setHighlight(false);

    if (this.editMode === EDIT_MODE.start) {
      this.selectedAnnotation.setStartPoint(currentPoint);
    } else if (this.editMode === EDIT_MODE.end) {
      this.selectedAnnotation.setEndPoint(currentPoint);
    } else if (this.editMode === EDIT_MODE.vertex) {
      this.selectedAnnotation.setVertexPoint(currentPoint);
    } else {
      // When started to move annotation, disable hotspot highlight
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      const graphicData = this.selectedAnnotation.graphicObjects[0].graphicData;
      const renderPixelData = convertToRenderPixel(this.renderEngine, graphicData);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(renderPixelData, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY, displayArea);
      } else {
        return false;
      }
    }

    this.selectedAnnotation.updateMeasurementLabel(this.renderEngine.getDicomCharSet());
    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }
}
