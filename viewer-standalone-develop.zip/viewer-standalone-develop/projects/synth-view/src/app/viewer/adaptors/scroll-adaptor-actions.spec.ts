import { ScrollAdaptorActions } from './scroll-adaptor-actions';

describe('ScrollAdaptorActions', () => {
  it('should create an instance', () => {
    expect(new ScrollAdaptorActions()).toBeTruthy();
  });
});
