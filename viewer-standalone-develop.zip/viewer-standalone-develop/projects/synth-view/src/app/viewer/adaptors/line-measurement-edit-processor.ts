import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { convertToRenderPixel } from '../utils';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';


export class LineMeasurementEditProcessor extends BaseAnnotationEditProcessor {
  // Selected annotations to edit
  protected selectedAnnotation: Fovia.PolylineGraphicAnnotation | null = null;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the Line annotation to null
   */
  public reset(): void {
    this.editMode = EDIT_MODE.none;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setStartPointHighlight(false);
      this.selectedAnnotation.setEndPointHighlight(false);
      this.selectedAnnotation.setHighlight(false);
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      this.selectedAnnotation.setSelectedObjectIndex(-1);
      this.isFreeLine = false;
    }
  }

  /**
   * @description Updates the Line annotation to edit process if the current point is selected from Line annotation
   * @param selectedAnnotation Specifies the reference to Line Annotation to edit
   * @param currentPoint Specifies the current mouse point location
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.PolylineGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateEditMode(currentPoint);
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
    }

    return previousEditMode !== this.editMode;
  }

  /**
   * @description Set the flag based on whether the whole line selected or any end points selected
   * @param currentPoint Specifies the current mouse point location
   */
  protected updateEditMode(currentPoint: Fovia.Util.Point): void {
    if (this.selectedAnnotation == null || this.selectedAnnotation.graphicLayerIndex !== -1) {
      return;
    }

    this.isFreeLine = this.selectedAnnotation.isFreeLine();
    if (this.selectedAnnotation.isHotspotSelected()) {
      this.editMode = EDIT_MODE.hotspots;
      return;
    }

    this.selectedAnnotation.setStartPointHighlight(false);
    this.selectedAnnotation.setEndPointHighlight(false);

    // If larger object, allow to move whole object
    if (this.selectedAnnotation.isLargerObject()) {
      this.editMode = EDIT_MODE.annotation;
      this.selectedAnnotation.setHighlight(true);
      return;
    }

    const startPoint = this.selectedAnnotation.getStartPoint();
    const endPoint = this.selectedAnnotation.getEndPoint();

    const renderPixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(startPoint.x, startPoint.y));
    const renderPixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(endPoint.x, endPoint.y));
    if (this.selectedAnnotation.isPointSelected(currentPoint, renderPixelStartPoint)) {
      this.editMode = EDIT_MODE.start;
      this.selectedAnnotation.setStartPointHighlight(true);
    } else if (this.selectedAnnotation.isPointSelected(currentPoint, renderPixelEndPoint)) {
      this.editMode = EDIT_MODE.end;
      this.selectedAnnotation.setEndPointHighlight(true);
    } else {
      this.editMode = EDIT_MODE.annotation;
      this.selectedAnnotation.setStartPointHighlight(true);
      this.selectedAnnotation.setEndPointHighlight(true);
      this.selectedAnnotation.setHighlight(true);
    }
  }

  /**
   * @description Move the line annotation to the current mouse point
   * @param currentPoint Specifies current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(currentPoint);
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;

    this.selectedAnnotation.setStartPointHighlight(false);
    this.selectedAnnotation.setEndPointHighlight(false);
    this.selectedAnnotation.setHighlight(false);

    if (this.editMode === EDIT_MODE.start) {
      this.selectedAnnotation.setStartPoint(currentPoint);
      if (this.isFreeLine) {
        this.selectedAnnotation.setEndPoint(currentPoint);
      }
    } else if (this.editMode === EDIT_MODE.end) {
      this.selectedAnnotation.setEndPoint(currentPoint);
      if (this.isFreeLine) {
        this.selectedAnnotation.setStartPoint(currentPoint);
      }
    } else if (this.editMode === EDIT_MODE.hotspots) {
      this.selectedAnnotation.moveHotspot(currentPoint);
    } else {
      // When started to move annotation, disable hotspot highlight
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      const graphicData = this.selectedAnnotation.graphicObjects[0].graphicData;
      const renderPixelData = convertToRenderPixel(this.renderEngine, graphicData);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(renderPixelData, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY, displayArea);
      } else {
        return false;
      }
    }

    GSPSUtils.getInstance().annotationModified = true;
    const pixelSpacing = this.getPixelSpacing();
    this.selectedAnnotation.updateMeasurementLabel(pixelSpacing, this.renderEngine.getDicomCharSet());
    this.fromPoint = currentPoint;
    return true;
  }
}
