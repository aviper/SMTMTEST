import { PolygonAnnotationEditProcessor } from './polygon-annotation-edit-processor';

describe('PolygonAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new PolygonAnnotationEditProcessor(new Fovia.UI.HTMLViewport2D('', 1, 1))).toBeTruthy();
  });
});
