import Fovia from 'foviaapi';
import { SynthContextSettings } from './adaptor-helpers';
import { SlopeIntercept } from '../models';
import { CM2, PIXELS, PX2, ROIBase } from './roibase';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';

interface IGetEllipseROIResponse {
  areaMM3: number;
  avg: number;
  stdDev: number;
  min: number;
  max: number;
}

const IS_ELLIPSE = true;

// ROI for Ellipse
export class GetEllipseROI extends ROIBase {
  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService) {
    super(viewportId, viewport, adaptorService);
  }

  public async updateROITextObject(selectedAnnotation: Fovia.EllipseGraphicAnnotation, pixelSpacing: string, synthContext: SynthContextSettings): Promise<void> {
    const context = synthContext.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));

    if (context == null) {
      console.error(`GetEllipseROI:updateROITextObject context may not be null.`);
      return;
    }
    // contents of viewport may have changed so always get slope/intercept to match
    // the currently displayed image
    const si: SlopeIntercept = this.getSlopeIntercept();
    this.getPixelSpacingMM(pixelSpacing);

    this.getROI(selectedAnnotation, pixelSpacing, si).then((labelText: string[]) => {
      // console.log(`getROI returned ${labelText}`);
      const firstBoundPoint = selectedAnnotation.getFirstBoundsPoint();
      const secondBoundPoint = selectedAnnotation.getSecondBoundsPoint();
      const anchorPointImagePixel = new Fovia.Util.Point((firstBoundPoint.x + secondBoundPoint.x) / 2, secondBoundPoint.y);
      const anchorPointRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPointImagePixel);
      const dicomCharSet = this.renderEngine.getDicomCharSet();
      let fullText = labelText[0];
      let limitedText = labelText[1];

      if (dicomCharSet) {
        fullText = Fovia.Util.convertFromHexStr(fullText, dicomCharSet);
        limitedText = Fovia.Util.convertFromHexStr(limitedText, dicomCharSet);
      }

      // Keep both the full text and limited text. We'll show limited text unless the ellipse is highlighted,
      // in which case we'll show full ROI text.
      const textObjectConstructs = {
        anchorPointImagePixel: anchorPointImagePixel,
        anchorPointRenderPixel: anchorPointRenderPixel,
        label: fullText,
        context: context,
        displayArea: this.renderEngine.getDisplayArea(),
        fontHeight: synthContext.visualAttribute.font.size * Fovia.Util.Constants.DEFAULT_FONT_METRIC
      };
      const textObjects: Fovia.TextObject[] = [];
      textObjects.push(Fovia.PresentationUtil.getTextObject(textObjectConstructs, IS_ELLIPSE));
      textObjectConstructs.label = limitedText;
      textObjects.push(Fovia.PresentationUtil.getTextObject(textObjectConstructs, IS_ELLIPSE));

      // For the ellipse ROI we use two text objects. One for displaying text when selected and one for when not selected.
      selectedAnnotation.textObjects = textObjects;
      selectedAnnotation.setShowLabelFlag(true);
    });
  }

  private async getROI(selectedAnnotation: Fovia.EllipseGraphicAnnotation, pixelSpacing: string, si: SlopeIntercept): Promise<string[]> {
    return new Promise((resolve, reject) => {

      const endPoints = selectedAnnotation.getEndPoints();

      // Returned measurement is in pixels or mm
      const majorAxis = Fovia.PresentationUtil.getMeasurement(pixelSpacing, endPoints[2], endPoints[3]); // Top/Bottom
      const minorAxis = Fovia.PresentationUtil.getMeasurement(pixelSpacing, endPoints[0], endPoints[1]); // Left/Right

      // From here on, result units intended to be pixels or cm i.e. not mm
      const clientArea = majorAxis.getUnit() === PIXELS ?
        this.getEllipseArea(majorAxis.getValue(), minorAxis.getValue()).toFixed(2) :
        (this.getEllipseArea(majorAxis.getValue(), minorAxis.getValue()) / 100).toFixed(2);

      const perimeter = majorAxis.getUnit() === PIXELS ?
        this.getEllipsePerimeter(majorAxis.getValue(), minorAxis.getValue()).toFixed(2) :
        (this.getEllipsePerimeter(majorAxis.getValue(), minorAxis.getValue()) / 10).toFixed(2);

      const height = majorAxis.getUnit() === PIXELS ? majorAxis.getValue().toFixed(2) : (majorAxis.getValue() / 10).toFixed(2);
      const length = majorAxis.getUnit() === PIXELS ? minorAxis.getValue().toFixed(2) : (minorAxis.getValue() / 10).toFixed(2);

      const rp = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
      const renderEngineID = this.renderEngine.getRenderEngineID();

      const firstBoundPoint = selectedAnnotation.getFirstBoundsPoint();
      const secondBoundPoint = selectedAnnotation.getSecondBoundsPoint();

      const input = {
        'startPointX': firstBoundPoint.x,
        'startPointY': firstBoundPoint.y,
        'endPointX': secondBoundPoint.x,
        'endPointY': secondBoundPoint.y,
      };

      this.getStatisticsInEllipse2D(renderEngineID, input, rp, pixelSpacing).then((roi: IGetEllipseROIResponse) => {
        // Use Rescale Slope/Intercept to convert these pixel values to display units
        let min = si.getModalityPixelValue(roi.min);
        let max = si.getModalityPixelValue(roi.max);
        let mean = si.getModalityPixelValue(roi.avg);
        let stdDev = (roi.stdDev * si.slope);

        // For 2D, computation returns mm² convert to cm²
        const roiArea = pixelSpacing === '' ? roi.areaMM3.toFixed(2) : (roi.areaMM3 / 100).toFixed(2);
        const area = roi.areaMM3 > 0 ? roiArea : clientArea;
        const roiInfo: string[] = [];

        let suvScaleFactor = -1;
        if (this.suvInfo !== null) {
          suvScaleFactor = this.determineSuvScaleFactor();
        }

        const linear = !this.hasPixelSpacing ?
          `Area: ${area} ${PX2} \nPerimeter: ${perimeter} \nLength: ${length} \nHeight: ${height}` :
          `Area: ${area} ${CM2} \nPerimeter: ${perimeter} cm\nLength: ${length} cm \nHeight: ${height} cm`;

        if (suvScaleFactor > 0) {
          min *= suvScaleFactor;
          max *= suvScaleFactor;
          mean *= suvScaleFactor;
          stdDev *= suvScaleFactor;

          // Full ROI text is first in the returned array.
          roiInfo.push(`SUVmax: ${max.toFixed(2)}\nSUVmin: ${min.toFixed(2)}\nSUVaverage: ${mean.toFixed(2)}\nStd Deviation: ${stdDev.toFixed(2)}\n` + linear);

          // Limited ROI text is second in the returned array.
          roiInfo.push(`SUVmax: ${max.toFixed(2)}`);
        } else {
          // Full ROI text is first in the returned array.
          roiInfo.push(si.units === '' ?
            linear + `\nAverage: ${mean.toFixed(2)}\nMin: ${min.toFixed(2)}\nMax: ${max.toFixed(2)}\nStd Deviation: ${stdDev.toFixed(2)}` :
            linear + `\n${si.units} Average: ${mean.toFixed(2)}\n${si.units} Min: ${min.toFixed(2)}\n${si.units} Max: ${max.toFixed(2)}\nStd Deviation: ${stdDev.toFixed(2)}`);

          // Limited ROI text is second in the returned array.
          roiInfo.push(si.units === '' ?
            `Average: ${mean.toFixed(2)}` :
            `${si.units} Average: ${mean.toFixed(2)}`);
        }
        resolve(roiInfo);
      }).catch((errMsg) => {
        console.error(errMsg);
        Fovia.Logger.warn('Error in getStatisticsInEllipse2D: ' + errMsg);
        reject(errMsg);
      });
    });
  }

  private async getStatisticsInEllipse2D(renderEngineID: any, input: any, rp: Fovia.RenderParams2D, pixelSpacing: string): Promise<IGetEllipseROIResponse> {
    try {
      const imageNum = rp.imageNumber ?? 0;
      const imageTags = this.sdc.imageTags[imageNum];
      const imageData = await this.getCachedImage(imageNum);

      // Null check for imageData and PixelData
      if (!imageData?.PixelData) {
        Fovia.Logger.warn('GetEllipseROI - imageData or PixelData is null, falling back to empty result.');
        return { areaMM3: 0, avg: 0, stdDev: 0, min: 0, max: 0 };
      }
      const cols = imageTags.cols ?? 0;
      const rows = imageTags.rows ?? 0;

      // Compute ellipse parameters
      const startX = Math.min(input.startPointX, input.endPointX);
      const endX = Math.max(input.startPointX, input.endPointX);
      const startY = Math.min(input.startPointY, input.endPointY);
      const endY = Math.max(input.startPointY, input.endPointY);

      const a = (endX - startX) / 2; // horizontal radius
      const b = (endY - startY) / 2; // vertical radius
      const cx = startX + a;
      const cy = startY + b;

      const bounds = {
        px: Math.max(0, Math.floor(startX)),
        py: Math.max(0, Math.floor(startY)),
        qx: Math.min(cols - 1, Math.ceil(endX)),
        qy: Math.min(rows - 1, Math.ceil(endY)),
      };

      const stats = this.computeEllipseStats(imageData.PixelData as number[], cols, rows, { cx, cy, a, b }, bounds);
      if (stats.count === 0) {
        return { areaMM3: 0, avg: 0, stdDev: 0, min: 0, max: 0 };
      }
      const avg = stats.sum / stats.count;
      const variance = stats.sumSq / stats.count - avg * avg;
      const stdDev = Math.sqrt(Math.max(0, variance));
      const spacingVec = this.getPixelSpacingMM(pixelSpacing ?? '');
      const areaMM2 = stats.count * (spacingVec.x ?? 1) * (spacingVec.y ?? 1);
      return {
        areaMM3: areaMM2,
        avg,
        stdDev,
        min: stats.min,
        max: stats.max,
      };
    } catch (err) {
      Fovia.Logger.warn('GetEllipseROI - cache based stats failed, falling back to server: ' + String(err));
      return  { areaMM3: 0, avg: 0, stdDev: 0, min: 0, max: 0 };
    }
  }
  private computeEllipseStats(
    pixelData: number[],
    cols: number,
    rows: number,
    ellipse: { cx: number; cy: number; a: number; b: number },
    bounds: { px: number; py: number; qx: number; qy: number }
  ): { count: number; sum: number; sumSq: number; min: number; max: number } {
    let count = 0, sum = 0, sumSq = 0, min = Infinity, max = -Infinity;
    const { cx, cy, a, b } = ellipse;
    const { px, py, qx, qy } = bounds;

    for (let y = py; y <= qy; y++) {
      const dy2 = ((y - cy) ** 2) / (b * b || 1);
      for (let x = px; x <= qx; x++) {
        const eq = ((x - cx) ** 2) / (a * a || 1) + dy2;
        if (eq <= 1.0) {
          const v = pixelData[y * cols + x];
          if (v == null) { continue; }
          count++;
          sum += v;
          sumSq += v * v;
          if (v < min) { min = v; }
          if (v > max) { max = v; }
        }
      }
    }
    return { count, sum, sumSq, min, max };
  }
  private getEllipsePerimeter(majorAxisMM: number, minorAxisMM: number): number {
    // Perimeter approximation #1 using 2PI*r approximation
    // a = 1/2 major axis
    // b = 1/2 minor axis
    // n = 2*PI((a + b)/2)
    //
    // OR (more precise)
    // Ramanujan's approximation = PI*[3*(a+b)- sqrt((3a+b)*(a+3b))]
    const a = majorAxisMM / 2;
    const b = minorAxisMM / 2;
    return Math.PI * (3 * (a + b)) - Math.sqrt(((3 * a) + b) * (a + (3 * b)));
  }
  // There's a bug in the Fovia ellipse area, so we'll calculate it here.
  private getEllipseArea(majorAxisA_mm: number, minorAxisB_mm: number): number {
    return Math.PI * (majorAxisA_mm / 2) * (minorAxisB_mm / 2);
  }

}
