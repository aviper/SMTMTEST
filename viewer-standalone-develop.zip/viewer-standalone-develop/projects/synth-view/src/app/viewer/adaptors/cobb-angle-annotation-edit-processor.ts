import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { convertToRenderPixel } from '../utils';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class CobbAngleAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  private selectedAnnotation: Fovia.PolylineGraphicAnnotation | null = null;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the angle annotation to null
   */
  public reset(): void {
    this.editMode = EDIT_MODE.none;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setSelectedPointIndex(-1);
      this.selectedAnnotation.setHighlight(false);
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      this.selectedAnnotation.setSelectedObjectIndex(-1);
    }
  }

  /**
   * @description Updates the angle annotation to edit process if the current point is selected from angle annotation
   * @param selectedAnnotation Specifies the reference to the annotation to edit
   * @param currentPoint Specifies the current mouse point location
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.PolylineGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateEditMode(currentPoint);
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
    }

    return previousEditMode !== this.editMode;
  }

  /**
   * @description Set the flag based on whether the whole angle selected or any end points selected
   * @param currentPoint Specifies the current mouse point location
   */
  protected updateEditMode(currentPoint: Fovia.Util.Point): void {
    if (this.selectedAnnotation == null || this.selectedAnnotation.graphicLayerIndex !== -1) {
      return;
    }

    const graphicObject: Fovia.GraphicObject = this.selectedAnnotation.getGraphicObject(0);
    const numPoints = graphicObject.graphicData.length;
    let selectedPointIndex = -1;

    if (numPoints === 4) {
      for (let i = 0; i < numPoints; i++) {
        if (this.selectedAnnotation.isPointSelected(currentPoint, this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[i]))) {
          this.selectedAnnotation.setSelectedPointIndex(i);
          selectedPointIndex = i;
          break;
        }
      }

      if (selectedPointIndex === -1) {
        this.editMode = EDIT_MODE.annotation;
        this.selectedAnnotation.setHighlight(true);
      } else {
        switch (selectedPointIndex) {
          case 0:
            this.editMode = EDIT_MODE.start;
            break;
          case 1:
            this.editMode = EDIT_MODE.end;
            break;
          case 2:
            this.editMode = EDIT_MODE.start2;
            break;
          case 3:
            this.editMode = EDIT_MODE.end2;
            break;
        }
      }
    }
  }

  /**
   * @description Move the angle annotation to the current mouse point
   * @param currentPoint Specifies current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(currentPoint);
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    const selectedPointIndex = this.selectedAnnotation.getSelectedPointIndex();

    // Only the current point needs to be within the bounds if dragging a point. We'll check the bounds for
    // moving the entire annotation separately.
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;
    this.selectedAnnotation.setHighlight(false);

    if (this.editMode === EDIT_MODE.start || this.editMode === EDIT_MODE.end ||
        this.editMode === EDIT_MODE.start2 || this.editMode === EDIT_MODE.end2) {
      this.selectedAnnotation.graphicObjects[0].graphicData[selectedPointIndex] = currentPoint;
    } else {
      const renderPoints = convertToRenderPixel(this.renderEngine, this.selectedAnnotation.graphicObjects[0].graphicData);
      // Disable hotspot highlight
      this.selectedAnnotation.setSelectedHotspotIndex(-1);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(renderPoints, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY, displayArea);
      } else {
        return false;
      }
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }
}
