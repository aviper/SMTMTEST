import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { convertToRenderPixel } from '../utils';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class PolygonAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  protected selectedAnnotation: Fovia.PolylineGraphicAnnotation | null = null;

  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  public reset(): void {
    this.editMode = EDIT_MODE.none;
    // this.referencePoint = undefined;
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setPointHighlight(false);
      this.selectedAnnotation.setHighlight(false);
    }
  }

  /**
   * @description Updates the angle annotation to edit process if the current point is selected from angle annotation
   * @param selectedAnnotation Specifies the reference to the annotation to edit
   * @param currentPoint Specifies the current mouse point location
   * @returns Returns true if a change was made to highlighting
   */
  public processSelection(selectedAnnotation: Fovia.PolylineGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const previousEditMode = this.editMode;

    if (this.selectedAnnotation != null) {
      this.updateEditMode(currentPoint);
      this.fromPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);

      if (this.editMode === EDIT_MODE.vertex) {
        this.selectedAnnotation.setHighlight(true);
        this.selectedAnnotation.setPointHighlight(true);

      } else if (this.editMode === EDIT_MODE.annotation) {
        this.selectedAnnotation.setHighlight(true);
        this.selectedAnnotation.setPointHighlight(true);
      }
    }

    return previousEditMode !== this.editMode;
  }

  public checkSelection(annotation: Fovia.PolylineGraphicAnnotation, currentPoint: Fovia.Util.Point): boolean {
    // This behaves sort of as an extension of Fovia's annotation selection detection. Fovia only checks points,
    // line segments, and ellipse area. We're adding "point in polygon" detection to make it easier for a user
    // to select a polygon to move. This function gets called only if the Fovia detection doesn't find anything.
    const vectorArray: Fovia.Util.Vector[] = [];
    const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
    const vector = new Fovia.Util.Vector(imagePixel.x, imagePixel.y, 0);
    for (const item of annotation.graphicObjects[0].graphicData) {
      vectorArray.push(new Fovia.Util.Vector(item.x, item.y, 0));
    }
    // Add the starting point a second time to close the polygon.
    vectorArray.push(vectorArray[0]);
    if (Fovia.Util.pointInPolygon(vectorArray, vectorArray.length, vector)) {
      this.editMode = EDIT_MODE.annotation;
      return true;
    }
    return false;
  }

  /**
   * @description Set the flag based on whether the whole angle selected or any end points selected
   * @param currentPoint Specifies the current mouse point location
   */
  protected updateEditMode(currentPoint: Fovia.Util.Point): void {
    if (this.selectedAnnotation == null || this.selectedAnnotation.graphicLayerIndex !== -1) {
      return;
    }

    const graphicObject: Fovia.GraphicObject = this.selectedAnnotation.getGraphicObject(0);
    const numPoints = graphicObject.graphicData.length;
    let selectedPointIndex = -1;

    for (let i = 0; i < numPoints; i++) {
      if (this.selectedAnnotation.isPointSelected(currentPoint, this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[i]))) {
        this.selectedAnnotation.setSelectedPointIndex(i);
        selectedPointIndex = i;
        break;
      }
    }
    this.editMode = (selectedPointIndex === -1) ? EDIT_MODE.annotation : EDIT_MODE.vertex;
  }

  /**
   * @description Move the angle annotation to the current mouse point
   * @param currentPoint Specifies current mouse point
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point, currentImageData: Fovia.DICOMImageTags | null = null): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(currentPoint);
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    const selectedPointIndex = this.selectedAnnotation.getSelectedPointIndex();
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    // Hide the ROI information until we recalculate it after the change is done.
    this.selectedAnnotation.setShowLabelFlag(false);

    this.toPoint = new Fovia.Util.Point(currentPoint);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;

    if (this.editMode === EDIT_MODE.vertex) {
      this.selectedAnnotation.graphicObjects[0].graphicData[selectedPointIndex] = currentPoint;
    } else if (this.editMode === EDIT_MODE.annotation) {
      const renderPoints = convertToRenderPixel(this.renderEngine, this.selectedAnnotation.graphicObjects[0].graphicData);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(renderPoints, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY, displayArea);
        this.selectedAnnotation.adjustLabel(deltaX, deltaY);
      } else {
        return false;
      }
    } else {
      return false;
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }
}
