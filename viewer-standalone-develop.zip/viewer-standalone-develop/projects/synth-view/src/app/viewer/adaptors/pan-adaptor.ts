import Fovia from 'foviaapi';
import { AdaptorsService } from '../services';
import { ADJACENT_VIEWPORT_TOOL_MODE, getAdjacentViewportToolMode } from '../models';
import { Bounds } from '../utils';

export class PanAdaptor implements Fovia.UI.MouseAdaptorInterface {
  private isMouseDown = false;
  private lastX = 0;
  private lastY = 0;
  private adjacentToolMode = ADJACENT_VIEWPORT_TOOL_MODE.off;

  constructor(
    private viewportID: string,
    private readonly htmlViewport: Fovia.UI.HTMLViewport,
    private adaptorsService: AdaptorsService
  ) {
    this.htmlViewport = htmlViewport;
    this.isMouseDown = false;
  }

  public async down(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    event.preventDefault();
    this.lastX = event.viewportAdjusted.x;
    this.lastY = event.viewportAdjusted.y;

    const canvasBounds = new Bounds(this.htmlViewport.getHTMLElement().width, this.htmlViewport.getHTMLElement().height);
    this.adjacentToolMode = getAdjacentViewportToolMode(event, canvasBounds);
    return true;
  }

  public async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    event.preventDefault();
    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    event.preventDefault();
    // ** short circuit this method when adaptor service is waiting for renders to complete **
    if (this.adaptorsService.pauseTool) {
      return true;
    }
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplay == null) {
      console.warn(`panAdaptor move: seriesDisplay undefined for active viewport`);
      return true;
    }
    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;
    const deltaX = x - this.lastX;
    const deltaY = y - this.lastY;
    const panned = await seriesDisplay.applyPanToCurrentImage(deltaX, deltaY);
    if (panned && seriesDisplay.series?.isModalityMG()) {
      await this.adaptorsService.toolSyncActions.sync2DMirroredPanOperation(deltaX, deltaY, this.adjacentToolMode);
    }
    this.lastX = x;
    this.lastY = y;
    return true;
  }

  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return false;
  }

  // called after an image is returned from the server; useful during navigation when you need to know when the rendering is complete
  public postRender(htmlViewport: any, renderParams: any): void {
  }

  public canMirroredPan(adjacentMode: ADJACENT_VIEWPORT_TOOL_MODE): boolean {
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplay == null || seriesDisplay.viewportId == null || seriesDisplay.series == null) {
      console.error(`PanAdaptor.canMirroredPan: seriesDisplay undefined for active viewport`);
      return false;
    }
    return seriesDisplay.series.isModalityMG() &&
      this.adaptorsService.getAdjacentLeftOrRightMammoViewportIds(seriesDisplay.viewportId, adjacentMode).length > 0;
  }
}
