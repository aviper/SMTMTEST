import { ExtendablePointAdapter } from './extendable-point-adapter';

describe('ExtendablePointAdapter', () => {
  it('should create an instance', () => {
    // expect(new ExtendablePointAdapter()).toBeTruthy();
  });
});
