import { AcceleratedWlAdaptor } from './accelerated-wl-adaptor';

describe('WLAdaptor', () => {
  it('should create an instance', () => {
    expect(new AcceleratedWlAdaptor()).toBeTruthy();
  });
});
