import Fovia from 'foviaapi';
import { TextAnnotationAdaptor } from './text-annotation-adaptor';

describe('TextAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new TextAnnotationAdaptor('viewport1', new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
