import { ZoomAroundPointAdaptor } from './zoom-around-point-adaptor';

describe('ZoomAroundPointAdaptor', () => {
  it('should create an instance', () => {
    expect(new ZoomAroundPointAdaptor()).toBeTruthy();
  });
});
