import Fovia from 'foviaapi';

import { PointAnnotationAdaptor } from './point-annotation-adaptor';
import { EXTENDED_ANNOTATIONS, ROI_POINT_ANNOTATION_LAYER, SHOW_MEASUREMENT } from './adaptor-constants';
import { GetPixelValueROI } from './get-pixel-value-roi';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { AdaptorsService } from "../services";

// Using custom function to get the ROI Point from the server with specific presentation
export class ROIPointAdaptor extends PointAnnotationAdaptor {

  // the Fovia point PointGraphicAnnotation has it's own rendering for the text associated
  // with the point. So we'll use a teeny poly line, of just two points for our ROIPoint to accommodate
  // the custommization we need to support something that shows the pixel value and it's location.

  // Intended UserInteraction
  // 1. User drops a point and a label appears
  // 2. User grabs the point and moves it around - the label gets updated as it moves

  // Class to access a particular Pixels Value from the serverl
  protected pixelValueROI: GetPixelValueROI;

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, volumeDataContext: Fovia.VolumeDataContext | null, adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, adaptorService, SHOW_MEASUREMENT);
    this.supportsGenericDicomGraphicType = false;
    this.graphicLayer = ROI_POINT_ANNOTATION_LAYER;
    this.pixelValueROI = new GetPixelValueROI(viewportId, viewport, adaptorService);
  }

  public static getInstance(vp: Fovia.UI.HTMLViewport): ROIPointAdaptor | null   {
    const vpAdaptors = vp.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
    const extendableAdaptor = vpAdaptors.getExtendablePointAdaptor();
    const adaptor = extendableAdaptor?.getAnnotationAdaptor(EXTENDED_ANNOTATIONS.roiPoint) ?? null;
    return (adaptor == null) ? null : adaptor as ROIPointAdaptor;
  }

  public async getPixelValue(screenPoint: Fovia.Util.Point): Promise<string | null> {
    const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(screenPoint);
    return this.pixelValueROI.getPixelValueByPoint(point);
  }

  /**
    * @description Provide hook to trigger updating of dynamic annotation values after movements
    *    or shape changes
    * @param selectedAnnotation current annotation
    */
  protected override updateAnnotationText(selectedAnnotation: Fovia.PointGraphicAnnotation, screenPoint: Fovia.Util.Point): void {
    super.updateAnnotationText(selectedAnnotation, screenPoint);
    selectedAnnotation.textObjects[0].unformattedTextValue = ' ';
    if (this.showMeasurement) {
      // Update the current graphic object with the ROI annotation
      this.pixelValueROI.updateROITextObject(selectedAnnotation);
    }
  }
}
