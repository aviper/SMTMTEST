import { AngleAnnotationEditProcessor } from './angle-annotation-edit-processor';

describe('AngleAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new AngleAnnotationEditProcessor(null)).toBeTruthy();
  });
});
