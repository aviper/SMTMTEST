import { SPINE_LABEL_TYPE } from '../modal-popup-dialogs';

const ANNOTATION_PREFIX = 'Synth_';
export const ARROW_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ARROW';
export const ANGLE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ANGLE';
export const CIRCLE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'CIRCLE';
export const COBB_ANGLE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'COBB_ANGLE';
export const ELLIPSE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ELLIPSE';
export const LINE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'POLYLINE';
export const POINT_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'POINT';
export const POLYGON_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'POLYGON';
export const TEXT_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'TEXT';
export const ROI_ELLIPSE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ROI_ELLIPSE';
export const ROI_POLYGON_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ROI_POLYGON';
export const ROI_POINT_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'ROI_POINT';
export const SPINE_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'SPINE';
export const CALIBRATION_ANNOTATION_LAYER = ANNOTATION_PREFIX + 'CALIBRATE';

export function isSynthAnnotationLayer(layer: string): boolean {
  return layer.startsWith(ANNOTATION_PREFIX);
}

export const SPINE_CERVICAL_PREFIX = 'C';
export const SPINE_THORACIC_PREFIX = 'T';
export const SPINE_LUMBAR_PREFIX = 'L';
export const SPINE_CERVICAL_LABELS = '1 2 3 4 5 6 7';
export const SPINE_CERVICAL_DISK_LABELS = '2/3 3/4 4/5 5/6 6/7 7/T1';
export const SPINE_THORACIC_LABELS =  '1 2 3 4 5 6 7 8 9 10 11 12';
export const SPINE_THORACIC_DISK_LABELS = '1/2 2/3 3/4 4/5 5/6 6/7 7/8 8/9 9/10 10/11 11/12 12/L1';
export const SPINE_LUMBAR_LABELS =  '1 2 3 4 5 6';
export const SPINE_LUMBAR_DISK_LABELS = '1/2 2/3 3/4 4/5 5/S1 5/6';

export const SHOW_MEASUREMENT = true;

export enum MOUSE_ADAPTORS {
  rotate = 0,
  zoom = 1,
  pan = 2,
  page = 3,
  windowLevel = 4,
  autoNavigate = 5,
  slabThickness = 6,
  scroll = 7,
  manualNavigate = 8,
  voxelValue = 9,
  surfaceRotate = 10,
  panZoom = 11,
  flip = 12,
  spin = 13,
  zoomAroundPoint = 21,
  none = 100,
  userDefined = 100,

  // application defined mouse modes
  point = 101,
  polyline = 102,
  circle = 103,
  ellipse = 104,
  text = 105,
  angle = 106,
}
export enum EXTENDED_ANNOTATIONS {
  none = -1,
  polyline = 0,
  arrow = 1,
  cobbAngle,
  polygon,
  ellipse,
  point,
  roiEllipse,
  roiPoint,
  roiPolygon,
  spineLabel,
  calibrateLine
}

export enum EDIT_MODE {
  none = -1,
  annotation = 1,
  start,
  hotspots,
  end,
  top,
  right,
  bottom,
  left,
  vertex,
  start2,
  end2
}
