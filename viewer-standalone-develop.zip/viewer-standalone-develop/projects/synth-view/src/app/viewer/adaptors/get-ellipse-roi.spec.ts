import { GetEllipseROI } from './get-ellipse-roi';

describe('GetEllipseROI', () => {
  it('should create an instance', () => {
    expect(new GetEllipseROI()).toBeTruthy();
  });
});
