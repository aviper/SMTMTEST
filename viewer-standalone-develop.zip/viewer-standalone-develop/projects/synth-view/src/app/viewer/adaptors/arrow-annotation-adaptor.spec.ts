import { ArrowAnnotationAdaptor } from './arrow-annotation-adaptor';

describe('ArrowAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new ArrowAnnotationAdaptor('viewport1', new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
