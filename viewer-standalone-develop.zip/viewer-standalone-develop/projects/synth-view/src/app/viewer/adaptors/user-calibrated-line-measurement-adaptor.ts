import Fovia from 'foviaapi';
import { AdaptorsService } from '../services';
import { CALIBRATION_ANNOTATION_LAYER } from './adaptor-constants';
import { LineMeasurementAdaptor } from './line-measurement-adaptor';

export class UserCalibratedLineMeasurementAdaptor extends LineMeasurementAdaptor {
  constructor(viewport: Fovia.UI.HTMLViewport,
              volumeDataContext: Fovia.VolumeDataContext | null,
              showMeasurement: boolean,
              adaptorsService: AdaptorsService) {
    super(viewport, volumeDataContext, showMeasurement, adaptorsService);
    this.graphicLayer = CALIBRATION_ANNOTATION_LAYER;
  }

  protected override updateFromImageTags(imageTags: any): void {
    super.updateFromImageTags(imageTags);

    // when using the calibration, don't supply a pixelSpacing value because measurement should be done in pixels
    this.pixelSpacing = '';
    this.isUserCalibrated = false;
  }
}
