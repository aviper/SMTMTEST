import { ROIPolygonAdaptor } from './roi-polygon-adaptor';

describe('RoiPolygonAdaptor', () => {
  it('should create an instance', () => {
    expect(new ROIPolygonAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
