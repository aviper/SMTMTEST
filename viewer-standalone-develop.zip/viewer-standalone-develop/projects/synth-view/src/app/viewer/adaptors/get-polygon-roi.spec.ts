import { GetPolygonROI } from './get-polygon-roi';

describe('GetPolygonROI', () => {
  it('should create an instance', () => {
    expect(new GetPolygonROI()).toBeTruthy();
  });
});
