import Fovia from 'foviaapi';

import { EllipseAnnotationAdaptor } from './ellipse-annotation-adaptor';
import { EXTENDED_ANNOTATIONS, ROI_ELLIPSE_ANNOTATION_LAYER, SHOW_MEASUREMENT } from './adaptor-constants';
import { GetEllipseROI } from './get-ellipse-roi';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';

export class ROIEllipseAdaptor extends EllipseAnnotationAdaptor {
  private ellipseROIRequester: GetEllipseROI;

  constructor(private viewportId: string,
    viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, adaptorService, SHOW_MEASUREMENT);
    this.supportsGenericDicomGraphicType = false;
    this.graphicLayer = ROI_ELLIPSE_ANNOTATION_LAYER;
    this.ellipseROIRequester = new GetEllipseROI(viewportId, viewport, adaptorService);
  }

  public static getInstance(vp: Fovia.UI.HTMLViewport): ROIEllipseAdaptor | null {
    const vpAdaptors = vp.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
    const extendableEllipseAdaptor = vpAdaptors?.getEllipseAnnotationAdaptor();
    const adaptor = extendableEllipseAdaptor?.getAnnotationAdaptor(EXTENDED_ANNOTATIONS.roiEllipse) ?? null;
    return adaptor == null ? null : adaptor as ROIEllipseAdaptor;
  }

  /**
  * @description Provide hook to trigger updating of dynamic annotation values after movements
  *    or shape changes
  * @param selectedAnnotation current annotation
  */
  protected override updateAnnotationText(selectedAnnotation: Fovia.EllipseGraphicAnnotation): void {
    if (this.showMeasurement) {
      const renderParams = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
      if (!renderParams || !this.renderEngine.isPresentationDataAvailable() ||
        this.ellipseIsTooSmall(selectedAnnotation.getFirstBoundsPoint(), selectedAnnotation.getSecondBoundsPoint())) {
        return;
      }

      const currentImageData = this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber];
      this.updateFromImageTags(currentImageData);
      this.ellipseROIRequester.updateROITextObject(selectedAnnotation, this.pixelSpacing, this.getSynthSettings()).then();
    }
  }
  private ellipseIsTooSmall(pt1: Fovia.Util.Point, pt2: Fovia.Util.Point): boolean {
    const margin = 1;
    return (Math.abs(pt1.x - pt2.x) <= margin && Math.abs(pt1.y - pt2.y) <= margin);
  }
}
