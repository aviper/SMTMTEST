import Fovia from 'foviaapi';
import { AdaptorsService } from '../services';
import { getCurrentWLValue } from '../models';

export class AcceleratedWlAdaptor implements Fovia.UI.MouseAdaptorInterface {

  private lastCursorPoint = new Fovia.Util.Point(0, 0);
  private window = 1;
  private level = 0;
  private htmlViewport3D;
  private readonly renderEngine: Fovia.RenderEngineContext;


  constructor(private readonly htmlViewport: Fovia.UI.HTMLViewport, private adaptorsService: AdaptorsService) {
    this.renderEngine = htmlViewport.getRenderEngine();
    this.htmlViewport3D = this.htmlViewport as Fovia.UI.HTMLViewport3D;
  }

  public async down(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    this.lastCursorPoint.x = event.viewportAdjusted.x;
    this.lastCursorPoint.y = event.viewportAdjusted.y;
    const wl = getCurrentWLValue(this.htmlViewport, 'W/L');
    if (wl) {
      this.window = wl.width;
      this.level = wl.level;
    }
    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    let rtnVal = false;
    if (seriesDisplayItem) {
      this.window += ((event.viewportAdjusted.x - this.lastCursorPoint.x) * 100);
      this.level += ((event.viewportAdjusted.y - this.lastCursorPoint.y) * 100);
      
      // window should never be less than 1
      if (this.window < 1) {
        this.window = 1;
      }

      // console.log(`AcceleratedWlAdaptor move setting RenderParams  WL ${this.window}/${this.level}`);
      const rpNew = renderParams ? renderParams : new Fovia.RenderParams2D();
      rpNew.voiLUTIndex = -1; // Disable a VOI lut when W/Ling
      rpNew.setWindowLevel(this.window, this.level);
      await seriesDisplayItem.setRenderParams2D(rpNew, Fovia.RenderRequest.renderFinal);
      rtnVal = true;
    }
    this.lastCursorPoint.x = event.viewportAdjusted.x;
    this.lastCursorPoint.y = event.viewportAdjusted.y;
    return rtnVal;
  }
  public async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  public async wheel(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return false;
  }

  public postRender(htmlViewport: any, renderParams: any): void {
  }
}
