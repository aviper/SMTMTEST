import Fovia from 'foviaapi';
import { firstValueFrom, take } from 'rxjs';
import { LineMeasurementAdaptor } from './line-measurement-adaptor';
import { ARROW_ANNOTATION_LAYER, EXTENDED_ANNOTATIONS } from './adaptor-constants';
import { ModalPopupService, TextInputParams } from '../modal-popup-dialogs';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { AdaptorsService } from '../services';

export class ArrowAnnotationAdaptor extends LineMeasurementAdaptor {
  constructor(viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    private modalPopupService: ModalPopupService,
    adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, false, adaptorService);
    this.graphicLayer = ARROW_ANNOTATION_LAYER;
    this.reversePoints = true;
    this.supportsGenericDicomGraphicType = false;
    this.lineWidth = this.visualAttribute.line.width;
  }

  /**
   * @description Toggle the freeline draw variable
   * @param flag Specifies the flag to set
   */
  public override toggleFreeline(flag: boolean = false): void {
    // Ignore in this override.
  }

  /**
   * @description called when the user releases the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.graphicAnnotation != null) {
      const viewportAdaptor = this.viewport.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
      const arrowAnnotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const displayArea = this.renderEngine.getDisplayArea();
      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);

        // Display the text input dialog approximately at the mouse position.
        // const adapter = this.getInstance(this.viewport);
        // const panelBounds = adapter?.adaptorService?.getPanelBoundsByViewportId(this.viewport.getHtmlElementName()) ?? null;
        // const config: TextInputParams = new TextInputParams(event.y, event.x, panelBounds, '');
        // const textDialogRef = this.modalPopupService.openTextDialog(config);
        // let userText = '';
        //
        // // Keep the most current user text in case a user closes the dialog by clicking away from the dialog,
        // // which results in 'undefined' being returned by the dialog instead of the text.
        // textDialogRef.componentInstance.userTextChange.subscribe((text: string) => {
        //   userText = text;
        // });
        //
        // // Detect when the dialog is opened and keep track until it's closed.
        // textDialogRef.afterOpened()
        //   .pipe(
        //     take(1)
        //   )
        //   .subscribe(_ => {
        //     viewportAdaptor.textEditActive = true;
        //   });
        //
        // let encodedUserText = '';
        // let dicomCharSet = this.renderEngine.getDicomCharSet();
        // await firstValueFrom(textDialogRef.afterClosed())
        //   .then(result => {
        //     if (result === undefined) {
        //       // If a user closes the dialog by clicking away from the dialog then result is undefined and
        //       // we'll use what we've been given via the userTextChange observable.
        //       result = userText;
        //     }
        //     if (result !== '') {
        //       if (dicomCharSet) {
        //         dicomCharSet = Fovia.Util.getEncodingType(dicomCharSet);
        //         const data = Fovia.Util.convertFromHexStr(result, dicomCharSet);
        //         encodedUserText = window.btoa(decodeURI(encodeURIComponent(data)));
        //       } else {
        //         encodedUserText = btoa(result);
        //       }
        //     }
        //     viewportAdaptor.textEditActive = false;
        //   });

        // Start and end points are reversed since Fovia code assumes the start point is the anchor point
        // for the text object.
        arrowAnnotation.setStartPoint(point);
        // if (encodedUserText !== '') {
        //   arrowAnnotation.textObjects.push(new Fovia.TextObject(point, encodedUserText, false,
        //     Fovia.HorizontalJustification.left, point, point,
        //     Fovia.MeasurementUnits.pixel, Fovia.MeasurementUnits.pixel, dicomCharSet));
        //   arrowAnnotation.showLabel = true;
        // }
      } else {
        arrowAnnotation.showLabel = false;
      }
      arrowAnnotation.updateNoOfGraphicPoints();
    }

    this.reset();

    this.viewport.repaint();
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    return true;
  }

  protected override drawLineEndpoints(p1: Fovia.Util.Point, p2: Fovia.Util.Point, context: CanvasRenderingContext2D): void {
    const headLength = this.visualAttribute.line.width * 2;
    context.beginPath();

    // Here p2 is actually the start point (has arrowhead) and p1 is the end point (anchor for the text object).
    const lineAngle = Math.atan2(p1.y - p2.y, p1.x - p2.x);
    const delta = Math.PI / 6;
    context.moveTo(p2.x, p2.y);
    context.lineTo(p2.x + headLength * Math.cos(lineAngle + delta), p2.y + headLength * Math.sin(lineAngle + delta));
    context.lineTo(p2.x + headLength * Math.cos(lineAngle - delta), p2.y + headLength * Math.sin(lineAngle - delta));
    context.closePath();
    context.fill();
    context.stroke();
  }

  private getInstance(vp: Fovia.UI.HTMLViewport): ArrowAnnotationAdaptor | null {
    const vpAdaptors = vp.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
    const extendableAdaptor = vpAdaptors.getExtendableAnnotationAdaptor();
    const adaptor = extendableAdaptor?.getAnnotationAdaptor(EXTENDED_ANNOTATIONS.arrow) ?? null;
    return (adaptor == null) ? null : adaptor as ArrowAnnotationAdaptor;
  }
}
