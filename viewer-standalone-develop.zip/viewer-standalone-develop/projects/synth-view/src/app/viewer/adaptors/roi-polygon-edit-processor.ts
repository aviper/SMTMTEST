import Fovia from 'foviaapi';
import { PolygonAnnotationEditProcessor } from './polygon-annotation-edit-processor';
import { GetPolygonROI } from './get-polygon-roi';
import { AdaptorsService } from '../services';

export class ROIPolygonEditProcessor extends PolygonAnnotationEditProcessor {

  private polygonROIRequestor: GetPolygonROI;

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService, private showMeasurement: boolean = true) {
    super(viewport, adaptorService);

    this.polygonROIRequestor = new GetPolygonROI(viewportId, viewport, adaptorService);
  }

  /**
   * @description Move the polygon annotation to the current mouse point.
   * @param currentPoint Specifies current mouse point
   * @param currentImageData DICOM tags associated with an image
   */
  public override moveAnnotation(currentPoint: Fovia.Util.Point, currentImageData: Fovia.DICOMImageTags | null = null): boolean {
    if (!super.moveAnnotation(currentPoint) || this.selectedAnnotation == null || currentImageData == null) {
      return false;
    }

    return true;
  }

  public doneMoving(): void {
    const pixelSpacing = this.getPixelSpacing();
    if (this.showMeasurement && this.selectedAnnotation !== null) {
      this.polygonROIRequestor.updateROITextObject(this.selectedAnnotation, pixelSpacing, this.getSynthSettings()).then();
    }
  }
}
