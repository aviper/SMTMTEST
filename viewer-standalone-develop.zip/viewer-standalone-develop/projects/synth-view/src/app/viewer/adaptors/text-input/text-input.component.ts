import {
  AfterViewChecked, AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  Output,
  ViewChild
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ModalPopupService, TextInputParams } from '../../modal-popup-dialogs';
import { PanelBoundDialog } from '../../utils';

@Component({
  standalone: false,
  selector: 'app-text-input',
  templateUrl: './text-input.component.html',
  styleUrls: ['./text-input.component.scss']
})
export class TextInputComponent implements AfterViewInit, AfterViewChecked {
  @ViewChild('userTextArea') private readonly userTextField: ElementRef;
  @Output() userTextChange = new EventEmitter<string>(true);

  protected userInput: string;
  constructor(private matDialogRef: MatDialogRef<TextInputComponent>,
    @Inject(MAT_DIALOG_DATA) private params: TextInputParams,
    private elementRef: ElementRef) {
    this.userTextField = new ElementRef(null);
    this.userInput = params.originalText;
  }

  public ngAfterViewInit(): void {
    const panelBoundDialog = new PanelBoundDialog('text-input-dialog', this.elementRef, this.params.panelBounds);
    const position = panelBoundDialog.updatePanelBoundDialogPosition();
    if (position) {
      this.matDialogRef.updatePosition({ top: position.top, left: position.left });
    }
  }

  public ngAfterViewChecked(): void {
    if (this.userTextField && this.userTextField.nativeElement) {
      this.userTextField.nativeElement.focus();
    }
  }

  protected onUserInput(event: Event): void {
    const maxLines = 3;
    const oldText = this.userInput;
    const newText = this.userTextField.nativeElement.value;
    const lines = newText.split('\n');

    // Trying to limit a user to three lines of text. This only works when a user ends a line with <enter>.
    // If a line breaks due to spilling over in the textarea control then no line break is inserted. That text
    // will become a single line when rendered on an image.
    if (lines.length > maxLines) {
      this.userTextField.nativeElement.value = oldText;
    }

    this.userInput = this.userTextField.nativeElement.value;

    // Subscribe to this to get user text as it's typed. This can then be used if this dialog
    // is closed by clicking away from the dialog.
    this.userTextChange.emit(this.userInput);
  }

  protected saveClicked(): void {
    this.matDialogRef.close(this.userInput);
  }
  protected cancelClicked(): void {
    this.matDialogRef.close('');
  }
  private needScroll(): boolean {
    return this.userTextField.nativeElement.scrollWidth > this.userTextField.nativeElement.clientWidth;
  }
}
