import Fovia from 'foviaapi';
import { PointAnnotationEditProcessor } from './point-annotation-edit-processor';
import { GetPixelValueROI } from './get-pixel-value-roi';
import { AdaptorsService } from '../services';

export class ROIPointEditProcessor extends PointAnnotationEditProcessor {

  protected pixelValueROI: GetPixelValueROI;
  /**
   * @description Constructs a new object. This constructor should only be called internal to the API.
   * @param viewportId a string that uniquely identifies a viewport
   * @param viewport Specifies the view port instance
   * @param adaptorService utility service for use with adaptors
   * @param showMeasurement indicate whether to show measurement info
   * @returns This is a synchronous method that returns the newly created instance <a href="fovia.ui.pointAnnotationEditProcessor.html"> <i>PointAnnotationEditProcessor</i> </a>
   */

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService, private showMeasurement: boolean = true) {
    super(viewport, adaptorService);
    this.pixelValueROI = new GetPixelValueROI(viewportId, viewport, adaptorService);
  }

  protected override updateAnnotationText(selectedAnnotation: Fovia.PointGraphicAnnotation, screenPoint: Fovia.Util.Point): void {
    super.updateAnnotationText(selectedAnnotation, screenPoint);
    selectedAnnotation.textObjects[0].unformattedTextValue = ' ';
    if (this.showMeasurement) {
      // Update the current graphic object with the ROI annotation
      this.pixelValueROI.updateROITextObject(selectedAnnotation).then();
    }
  }
}
