import Fovia from 'foviaapi';

import { AdaptorsService } from '../services';
import { getPendingRenderParams3D } from '@server-api';

import RenderEngineContext2D = Fovia.RenderEngineContext2D;
import RenderEngineContext3D = Fovia.RenderEngineContext3D;
import { is2DViewport, isFusedViewport } from '../utils';
export class ThreeDCursorModel {
  private threeDCursorVector: Fovia.Util.Vector | null = null;

  public setData(threeDCursorVector: Fovia.Util.Vector | null): void {
    this.threeDCursorVector = threeDCursorVector;
  }
  public getData(): Fovia.Util.Vector | null {
    return this.threeDCursorVector;
  }

}

export class ThreeDCursorAdaptor implements Fovia.UI.MouseAdaptorInterface {

  private isMouseDown = false;
  private readonly is2D: boolean;
  private readonly isFused: boolean;
  private readonly renderEngine: Fovia.RenderEngineContext;
  private image = new Image();
  private static activeViewportId = '';
  public renderFunc: any = null;

  constructor(
    private viewportID: string,
    private readonly htmlViewport: Fovia.UI.HTMLViewport,
    private adaptorsService: AdaptorsService,
    public threeDCursorData: ThreeDCursorModel) {

    // ThreeDCursorAdaptor requires a common ThreeDCursorModel shared across viewports
    if (!threeDCursorData || !(threeDCursorData instanceof ThreeDCursorModel)) {
      throw new Fovia.APIError('ThreeDCursorAdaptor, invalid ThreeDCursorData in constructor');
    }
    this.image.src = '/viewer/assets/icons/viewer/sv-target-annotation.svg';

    this.htmlViewport = htmlViewport;
    this.threeDCursorData = threeDCursorData;
    this.renderEngine = htmlViewport.getRenderEngine();
    this.isMouseDown = false;
    this.renderFunc = this.render.bind(this);
    this.htmlViewport.addDrawListener(this.renderFunc);
    this.is2D = is2DViewport(this.htmlViewport);
    this.isFused = isFusedViewport(this.htmlViewport);
  }

  public static resetDefaults(): void {
    ThreeDCursorAdaptor.activeViewportId = '';
  }

  // called when the user pressed the mouse down
  public async down(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    event.preventDefault();
    ThreeDCursorAdaptor.activeViewportId = this.viewportID;
    this.threeDCursorData.setData(null);
    if (this.is2D) {
      return this.down2D(event, renderParams);
    } else if (!this.isFused) {
      return this.down3D(event, renderParams);
    }
    return false;
  }

  // called when the user is moving or dragging the mouse
  public async move(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    event.preventDefault();

    // ** short circuit this method when panel service is waiting for renders to complete **
    if (this.adaptorsService.pauseTool) {
      return true;
    }

    if (this.isMouseDown) {
      if (this.is2D) {
        return this.move2D(event, renderParams);
      } else {
        return this.move3D(event, renderParams);
      }
    }
    return true;
  }

  // called when the user releases the mouse
  public async up(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    event.preventDefault();
    this.isMouseDown = false;
    this.threeDCursorData.setData(null);
    ThreeDCursorAdaptor.activeViewportId = '';
    await this.adaptorsService.syncThreeDCursorViewports(this.viewportID, this.threeDCursorData.getData());
    return true;
  }

  public render(foviaHTMLViewport: Fovia.UI.HTMLViewport, canvas: HTMLCanvasElement, width: number, height: number, imageTags: any): void {
    if (ThreeDCursorAdaptor.activeViewportId !== this.viewportID) {
      if (this.is2D) {
        return this.render2D(foviaHTMLViewport, canvas, width, height, imageTags);
      } else {
        return this.render3D(foviaHTMLViewport, canvas, width, height, imageTags);
      }
    }
  }

  // called when the user pressed the mouse down
  private async down2D(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {

    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;

    const renderEngine = this.renderEngine as RenderEngineContext2D;
    const sdc = renderEngine.getSeriesDataContext();
    this.threeDCursorData.setData(sdc.mapPointToFrameOfReference(renderEngine.renderImagePixelToDicomImagePixel(new Fovia.Util.Point(x, y)), renderEngine));
    this.htmlViewport.repaint();
    this.isMouseDown = true;

    // ** Signal other viewports to update **
    await this.adaptorsService.syncThreeDCursorViewports(this.viewportID, this.threeDCursorData.getData());

    return true;
  }

  // called when the user is moving or dragging the mouse
  private async move2D(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;
    // console.log('3D Cursor X: Y' + x.toString() + ':' + y.toString());
    const viewPort = this.htmlViewport.getHTMLElement();
    if (x > viewPort.width || y > viewPort.height) {
      return true;
    }
    if (x < 0 || y < 0) {
      return true;
    }

    const renderEngine = this.renderEngine as RenderEngineContext2D;
    const sdc = renderEngine.getSeriesDataContext();
    this.threeDCursorData.setData(sdc.mapPointToFrameOfReference(renderEngine.renderImagePixelToDicomImagePixel(new Fovia.Util.Point(x, y)), renderEngine));

    // ** Signal other viewports to update **
    await this.adaptorsService.syncThreeDCursorViewports(this.viewportID, this.threeDCursorData.getData());

    return true;
  }

  private render2D(foviaHTMLViewport: Fovia.UI.HTMLViewport, canvas: HTMLCanvasElement, width: number, height: number, imageTags: { imageNumber: number; }): void {
    if (this.threeDCursorData == null || this.threeDCursorData.getData() == null) {
      return;
    }
    const context = canvas.getContext('2d');
    if (!context) {
      return;
    }
    const threeDVector: Fovia.Util.Vector | null = this.threeDCursorData.getData();
    const renderEngine = this.renderEngine as RenderEngineContext2D;
    const sdc = renderEngine.getSeriesDataContext();
    if (threeDVector != null) {
      const mapped3DCursorPoint = sdc.mapPointFromFrameOfReference(threeDVector);
      const imagePixel3DCursor = renderEngine.dicomImagePixelToRenderImagePixel(mapped3DCursorPoint.imagePixel);

      // check if the cursor is "close" this image (perpDist).
      const dist = (mapped3DCursorPoint.sliceNumber - (imageTags.imageNumber - 1));
      if (this.checkMinDistance2D(dist) || this.checkMaxDistance2D(dist)) {
        context.drawImage(this.image, imagePixel3DCursor.x - 32, imagePixel3DCursor.y - 32, 64, 64);
      }
    }
  }

  // called when the user pressed the mouse down
  private async down3D(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {

    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;

    const renderEngine = this.renderEngine as RenderEngineContext3D;
    const rayStopInfoList = await renderEngine.shootRay([new Fovia.Util.Point(x, y)]);
    const rayStopInfo = new Fovia.RayStopInfo(rayStopInfoList[0]);
    if (rayStopInfo.voxelValue !== -1) {
      const vdc = renderEngine.getVolumeDataContext();
      const currentMPRPoint_VolumeUnits = new Fovia.Util.Vector(rayStopInfo.volCoodinate);
      this.threeDCursorData.setData(vdc.mapFovia3DToFrameOfReference(currentMPRPoint_VolumeUnits));
      this.htmlViewport.repaint();

      // ** Signal other viewports to update **
      await this.adaptorsService.syncThreeDCursorViewports(this.viewportID, this.threeDCursorData.getData());
    } else {
      console.error(`ThreeDCursorAdaptor down3D RayStopInfo error ${rayStopInfo.voxelValue}`);
    }
    this.isMouseDown = true;
    return true;
  }

  // called when the user is moving or dragging the mouse
  private async move3D(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {

    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;

    // console.log(`3DCursor move3D ${x} ${y}`);
    const viewPort = this.htmlViewport.getHTMLElement();
    if (x > viewPort.width || y > viewPort.height) {
      return true;
    }
    if (x < 0 || y < 0) {
      return true;
    }
    // console.log(`3DCursor move3D ${x} ${y}`);
    const renderEngine = this.renderEngine as RenderEngineContext3D;
    const rayStopInfoList = await renderEngine.shootRay([new Fovia.Util.Point(x, y)]);
    const rayStopInfo = new Fovia.RayStopInfo(rayStopInfoList[0]);
    if (rayStopInfo.voxelValue !== -1) {
      const vdc = renderEngine.getVolumeDataContext();
      const currentMPRPoint_VolumeUnits = new Fovia.Util.Vector(rayStopInfo.volCoodinate);
      this.threeDCursorData.setData(vdc.mapFovia3DToFrameOfReference(currentMPRPoint_VolumeUnits));

      // ** Signal other viewports to update **
      await this.adaptorsService.syncThreeDCursorViewports(this.viewportID, this.threeDCursorData.getData());
    } else {
      console.error(`ThreeDCursorAdaptor move3D RayStopInfo error ${rayStopInfo.voxelValue}`);
    }
    return true;
  }
  private render3D(foviaHTMLViewport: Fovia.UI.HTMLViewport, canvas: HTMLCanvasElement, width: number, height: number, imageTags: any): void {
    if (this.threeDCursorData == null || this.threeDCursorData.getData() == null) {
      return;
    }

    const inputVector = this.threeDCursorData.getData();
    if (inputVector == null) {
      return;
    }

    const context = canvas.getContext('2d');
    if (!context) {
      return;
    }

    const renderEngine = this.renderEngine as RenderEngineContext3D;

    const currentMPRPoint_VolumeUnits = renderEngine.getVolumeDataContext().mapFovia3DFromFrameOfReference(inputVector);
    const vdc = renderEngine.getVolumeDataContext();
    const rp = getPendingRenderParams3D(foviaHTMLViewport as Fovia.UI.HTMLViewport3D);

    // get the coordinates of lookatPoint from g_currentMPRPoint_VolumeUnits, note that the zoom value and transform is specific for this viewport
    const imagePixel3DCursor = Fovia.Util.volume2ProjectionPlaneParallel(currentMPRPoint_VolumeUnits, rp.zoom, vdc.spacing.x, rp.transform, new Fovia.Util.Size(width, height));

    if (this.checkMinDistance3D(imagePixel3DCursor.z) || this.checkMaxDistance3D(imagePixel3DCursor.z)) {
      context.drawImage(this.image, imagePixel3DCursor.x - 32, imagePixel3DCursor.y - 32, 64, 64);
    }
  }

  // called when the user is moving the wheel of the mouse
  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    return false;
  }

  // called after an image is returned from the server; useful during navigation when you need to know when the rendering is complete
  public postRender(htmlViewport: any, renderParams: any): void {
  }

  private checkMinDistance2D(dist: number): boolean {
    const minDist = 5;
    const result = (-minDist < dist && dist < minDist);
    return result;
  }

  private checkMaxDistance2D(dist: number): boolean {
    const maxDist = 40;
    const result = (dist >= -maxDist && dist <= maxDist);
    return result;
  }

  private checkMinDistance3D(dist: number): boolean {
    const minDist = 5;
    const result = (-minDist < dist && dist < minDist);
    return result;
  }

  private checkMaxDistance3D(dist: number): boolean {
    const maxDist = 80;
    const result = (dist >= -maxDist && dist <= maxDist);
    return result;
  }
}
