import Fovia from 'foviaapi';
import { EDIT_MODE } from './adaptor-constants';
import { SynthContextSettings } from './adaptor-helpers';
import { SynthStyles } from './synth-styles';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D, makeImageKeyFromImageTags } from '@server-api';

export class BaseAnnotationEditProcessor extends SynthStyles {
  protected viewport: Fovia.UI.HTMLViewport;
  protected renderEngine;

  protected fromPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected toPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);

  protected editMode: EDIT_MODE = EDIT_MODE.none;
  protected isFreeLine = false;
  private synthContextSettings: SynthContextSettings;
  constructor(viewport: Fovia.UI.HTMLViewport, protected adaptorsService: AdaptorsService) {
    super();

    this.viewport = viewport;
    this.renderEngine = this.viewport.getRenderEngine();
    this.synthContextSettings = new SynthContextSettings(this.visualAttribute, this.colorNormal, this.colorHighlight);
  }

  protected getSynthSettings(): SynthContextSettings {
    return this.synthContextSettings;
  }

  protected getPixelSpacing(): string {
    const imageNumber = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D).imageNumber;
    const imageTags = this.renderEngine.getSeriesDataContext().imageTags[imageNumber];
    const examId = this.renderEngine.seriesDataContext.studyInstanceUID;
    const userCalibratedPixelSpacing = this.adaptorsService.getPixelSpacingForImage(examId, makeImageKeyFromImageTags(imageTags));

    if (userCalibratedPixelSpacing != null) {
      return userCalibratedPixelSpacing;
    } else {
      return imageTags.pixelSpacing;
    }
  }
}
