import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';

describe('AbstractAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new AbstractAnnotationAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null, false)).toBeTruthy();
  });
});
