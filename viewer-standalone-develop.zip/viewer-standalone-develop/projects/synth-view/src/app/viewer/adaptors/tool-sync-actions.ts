import Fovia from 'foviaapi';
import Vector = Fovia.Util.Vector;
import RenderParams3D = Fovia.RenderParams3D;
import HTMLViewport3D = Fovia.UI.HTMLViewport3D;
import VIEW_TYPE = Fovia.ViewType;
import MouseAdaptorInterface = Fovia.UI.MouseAdaptorInterface;
import VolumeDataContext = Fovia.VolumeDataContext;
import RenderEngineContext3D = Fovia.RenderEngineContext3D;

// Extensions to the AdaptorsService to support synchronizing
// tool operations among viewports. Initially used for MPR viewport sync
import { AdaptorsService, ToolSyncData, ViewerSettingsService } from '../services';
import { ADJACENT_VIEWPORT_TOOL_MODE, HTMLDoubleBufferViewportMPRFused, HTMLDoubleBufferViewportMPRFusion, WindowLevel } from '../models';
import { isFusedViewport, isMPRViewport } from '../utils';
import { ScrollFusionAdaptor, ScrollFusionMouseAdaptor } from './scroll-fusion-mouse-adaptor';

export class ToolSyncActions {
  constructor(private adaptorsService: AdaptorsService,
    private viewerSettingsService: ViewerSettingsService) {
  }

  public applyWLOperation(viewportId: string, wl: WindowLevel): void {
    const toolData: ToolSyncData = { wl: wl };
    this.adaptorsService.updateActiveViewport(viewportId, toolData);
  }

  public syncWLOperation(wl: WindowLevel): void {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncWLOperation: no active viewport`);
      return;
    }
    const toolData: ToolSyncData = { wl: wl };
    this.adaptorsService.syncThreeDToolViewports(viewportId, toolData);
  }

  public applyColorPalette(viewportId: string, paletteName: string): void {
    const toolData: ToolSyncData = { colorPalette: paletteName };
    this.adaptorsService.updateActiveViewport(viewportId, toolData);
  }

  public syncRotateOperation(cameraPosition: Vector): void {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncRotateOperation: no active viewport`);
      return;
    }
    this.syncCameraPosition(viewportId, cameraPosition);
  }

  public syncPanOperation(cameraPosition: Vector): void {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncRotateOperation: no active viewport`);
      return;
    }
    this.syncCameraPosition(viewportId, cameraPosition);
  }

  public async sync2DMirroredPanOperation(deltaOffsetX: number, deltaOffsetY: number, adjacentMode: ADJACENT_VIEWPORT_TOOL_MODE): Promise<void> {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncRotateOperation: no active viewport`);
      return;
    }
    const toolData: ToolSyncData = { deltaOffsetX: deltaOffsetX, deltaOffsetY: deltaOffsetY };
    await this.adaptorsService.syncMirroredPanViewport(viewportId, adjacentMode, toolData);

  }

  public syncZoomOperation(zoom: number): void {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncZoomOperation: no active viewport`);
      return;
    }
    const toolData: ToolSyncData = { zoom: zoom };
    this.adaptorsService.syncThreeDToolViewports(viewportId, toolData);
  }

  public syncFusedOperation(renderParams3dList: Fovia.RenderParams3D[]): void {
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncZoomOperation: no active viewport`);
      return;
    }
    const toolData: ToolSyncData = { renderParams3dList: renderParams3dList };
    this.adaptorsService.syncThreeDToolViewports(viewportId, toolData);
  }

  public createFusedScrollAdaptor(foviaVP: HTMLDoubleBufferViewportMPRFused, increment: number): MouseAdaptorInterface | null {
    const re = foviaVP.getRenderEngine();
    const vdc = re.getRenderEngine(0).getVolumeDataContext();
    const scrollData = new Fovia.UI.ScrollAdaptorData(vdc, increment);
    return new ScrollFusionMouseAdaptor(foviaVP, increment, this.adaptorsService, this.fusedScrollListener.bind(this));
  }

  public createMPRFusionScrollAdaptor(vp: HTMLDoubleBufferViewportMPRFusion, viewType: VIEW_TYPE, increment: number): MouseAdaptorInterface | null {
    const re = vp.getRenderEngine();
    const vdc = re.getVolumeDataContext();
    const coronalScrollData = new Fovia.UI.ScrollAdaptorData(vdc);
    const scrolladaptor = new Fovia.UI.ScrollMouseAdaptor(re, coronalScrollData);
    scrolladaptor.addMPRScrollListener(this.fusionMPRScrollListener.bind(this));
    return scrolladaptor;
  }

  public createMPRScrollAdaptor(foviaVP: HTMLViewport3D, viewType: VIEW_TYPE, increment: number): MouseAdaptorInterface | null {
    const isMPR = isMPRViewport(foviaVP);
    let adaptor: MouseAdaptorInterface | null = null;
    const re = foviaVP.getRenderEngine();
    const vdc = re.getVolumeDataContext();
    // 3D Viewport get's it's own listener w/o regard to view_type
    if (!isMPR) {
      const scrollData = new Fovia.UI.ScrollAdaptorData(vdc, increment);
      const scrolladaptor = new Fovia.UI.ScrollMouseAdaptor(re, scrollData);
      scrolladaptor.addMPRScrollListener(this.threeDScrollListener.bind(this));
      adaptor = scrolladaptor;
      return adaptor;
    }
    // Create the appropraite kind of scroll adapter based on the viewType of the viewport
    const volumeIsOrthogonal = this.volumVectorsAreOrthoganal(vdc);
    switch (viewType) {
      case VIEW_TYPE.axial:
      case VIEW_TYPE.antiAxial: {

        const axialScrollData = volumeIsOrthogonal ? new Fovia.UI.ScrollAdaptorDataAxial(vdc) : new Fovia.UI.ScrollAdaptorData(vdc);
        // axialScrollData.spacing = increment;
        const scrolladaptor = volumeIsOrthogonal ? new Fovia.UI.ScrollMouseAdaptorAxial(re, axialScrollData as Fovia.UI.ScrollAdaptorDataAxial) :
          new Fovia.UI.ScrollMouseAdaptor(re, axialScrollData as Fovia.UI.ScrollAdaptorData);
        scrolladaptor.addMPRScrollListener(this.axialScrollListener.bind(this));
        adaptor = scrolladaptor;
      }
        break;
      case VIEW_TYPE.sagittal:
      case VIEW_TYPE.antiSagittal: {
        const sagittalScrollData = volumeIsOrthogonal ? new Fovia.UI.ScrollAdaptorDataSagittal(vdc) : new Fovia.UI.ScrollAdaptorData(vdc);
        // sagittalScrollData.spacing = increment;
        const scrolladaptor = volumeIsOrthogonal ? new Fovia.UI.ScrollMouseAdaptorSagittal(re, sagittalScrollData as Fovia.UI.ScrollAdaptorDataSagittal) :
          new Fovia.UI.ScrollMouseAdaptor(re, sagittalScrollData as Fovia.UI.ScrollAdaptorData);
        scrolladaptor.addMPRScrollListener(this.sagittalScrollListener.bind(this));
        adaptor = scrolladaptor;
      }
        break;
      case VIEW_TYPE.coronal:
      case VIEW_TYPE.antiCoronal: {
        const coronalScrollData = volumeIsOrthogonal ? new Fovia.UI.ScrollAdaptorDataCoronal(vdc) : new Fovia.UI.ScrollAdaptorData(vdc);
        // coronalScrollData.spacing = increment;
        const scrolladaptor = volumeIsOrthogonal ? new Fovia.UI.ScrollMouseAdaptorCoronal(re, coronalScrollData as Fovia.UI.ScrollAdaptorDataCoronal) :
          new Fovia.UI.ScrollMouseAdaptor(re, coronalScrollData as Fovia.UI.ScrollAdaptorData);
        scrolladaptor.addMPRScrollListener(this.coronalScrollListener.bind(this));
        adaptor = scrolladaptor;
      }
        break;
      default:
        if (viewType == null) {
          console.error(`${this.constructor.name} Unexpected createMPRScrollAdaptor viewType is null`);
        } else {
          console.error(`${this.constructor.name} Unexpected createMPRScrollAdaptor viewType ${VIEW_TYPE[viewType]}`);
        }
    }

    return adaptor;
  }
  // Listen for scroll tool operations from the active viewport
  public axialScrollListener(rp: RenderParams3D): void {
    this.syncScrollOffsetVector(rp);
  }

  public coronalScrollListener(rp: RenderParams3D): void {
    this.syncScrollOffsetVector(rp);
  }

  public sagittalScrollListener(rp: RenderParams3D): void {
    this.syncScrollOffsetVector(rp);
  }

  public threeDScrollListener(rp: RenderParams3D): void {
    this.syncScrollOffsetVector(rp);
  }

  public fusedScrollListener(renderParams3dList: Fovia.RenderParams3D[]): void {
    this.syncFusedOperation(renderParams3dList)
  }

  public fusionMPRScrollListener(rp: RenderParams3D): void {
    this.syncScrollOffsetVector(rp);
  }

  private volumVectorsAreOrthoganal(vdc: VolumeDataContext): boolean {
    const isOrthogonal: boolean =
      !(vdc.volumeOrientationXVector.dot(vdc.volumeOrientationYVector) != 0 ||
        vdc.volumeOrientationXVector.dot(vdc.volumeOrientationZVector) != 0 ||
        vdc.volumeOrientationYVector.dot(vdc.volumeOrientationZVector) != 0);
    return isOrthogonal;
  }

  private syncScrollOffsetVector(rp: RenderParams3D): void {
    if (rp == null) {
      console.error(`${this.constructor.name} syncScrollOfsetVector RenderParams are not defined.`);
      return;
    }
    const cameraPosition: Vector = rp.transform.getOffsetVector();
    const viewportId = this.viewerSettingsService.activeViewport;
    if (!viewportId) {
      console.warn(`${this.constructor.name} syncScrollOffsetVector: no active viewport`);
      return;
    }
    this.syncCameraPosition(viewportId, cameraPosition);
  }

  private syncCameraPosition(viewportId: string, offsetVector: Vector): void {
    const toolData: ToolSyncData = { cameraPosition: offsetVector };
    this.adaptorsService.syncThreeDToolViewports(viewportId, toolData);
  }
}
