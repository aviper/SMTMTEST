import Fovia from 'foviaapi';

import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { ELLIPSE_ANNOTATION_LAYER } from './adaptor-constants';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';

export class EllipseAnnotationAdaptor extends AbstractAnnotationAdaptor {

  protected ellipseAnnotation: Fovia.EllipseGraphicAnnotation | null = null;
  protected startPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);

  constructor(
      viewport: Fovia.UI.HTMLViewport,
      volumeDataContext: Fovia.VolumeDataContext | null,
      adaptorService: AdaptorsService,
      showMeasurement: boolean = true) {
    super(viewport, volumeDataContext, showMeasurement, adaptorService);
    this.graphicLayer = ELLIPSE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.ellipse;
    this.supportsGenericDicomGraphicType = true;
  }

  /**
   * @description called when the user releases the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring && this.ellipseAnnotation != null) {
      this.ellipseAnnotation.calculateBoundingPoints();
      this.viewport.repaint();
      this.updateAnnotationText(this.ellipseAnnotation);
    }
    this.isMeasuring = false;
    this.ellipseAnnotation = null;
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, unusedRenderParams: Fovia.RenderParams2D): Promise<boolean> {
    const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const points = [currentRenderPixel];
    const displayArea = this.renderEngine.getDisplayArea();
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
      this.startPoint = currentRenderPixel;
      this.isMeasuring = true;
    }

    const renderParams = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
    this.pixelSpacing = this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber].pixelSpacing;

    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);

      const anchorPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
      if (this.ellipseAnnotation == null) {
        this.ellipseAnnotation = new Fovia.EllipseGraphicAnnotation(this.graphicLayer);
        this.ellipseAnnotation.setFirstBoundPoint(anchorPoint);
        this.ellipseAnnotation.setSecondBoundPoint(anchorPoint);

        this.addEllipseAnnotation(this.ellipseAnnotation);
      }

      const firstBoundPoint = this.ellipseAnnotation.getFirstBoundsPoint();
      const renderPixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(firstBoundPoint.x, firstBoundPoint.y));
      const displayArea = this.renderEngine.getDisplayArea();
      const points = [renderPixelStartPoint, currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
        const endPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        this.ellipseAnnotation.setSecondBoundPoint(endPoint);
        this.ellipseAnnotation.updateAnnotation();
      }

      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description Render the ellipse annotations for the given annotation array
   *
   * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.EllipseGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;

          context.strokeStyle = graphicAnnotation.isHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);
          let endPoints: Fovia.Util.Point[] = [];

          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];
            context.strokeStyle = graphicObject.getIsSelected() ? this.colorHighlight : this.colorNormal;

            const startPoint = graphicAnnotation.getFirstBoundsPoint();
            const endPoint = graphicAnnotation.getSecondBoundsPoint();
            const renderPixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(startPoint);
            const renderPixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(endPoint);
            endPoints = this.drawEllipse(context, renderPixelStartPoint, renderPixelEndPoint);

            if (graphicAnnotation.isPointHighlighted()) {
              context.strokeStyle = this.colorHighlight;
              for (const point of endPoints) {
                context.strokeRect(point.x - this.grabberSize / 2, point.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
              }
            }
          }

          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation);
          }
        }
      }
    }
  }
  /**
   * @description Provide hook to trigger updating of dynamic annotation values after movements
   *    or shape changes for ROI derived classes
   * @param selectedAnnotation current annotation
   */
  protected updateAnnotationText(selectedAnnotation: Fovia.EllipseGraphicAnnotation): void {
  }

  /**
   * @description Draw the ellipse on the context from the given arguments
   * @param context context fetched from canvas
   * @param startPoint start point of the ellipse
   * @param endPoint end point of the ellipse
   */
  protected drawEllipse(context: CanvasRenderingContext2D, startPoint: Fovia.Util.Point, endPoint: Fovia.Util.Point): Fovia.Util.Point[] {
    const kappa = 0.5522848;
    const width = endPoint.x - startPoint.x;
    const height = endPoint.y - startPoint.y;
    const offsetX = (width / 2) * kappa; 			// control point offset horizontal
    const offsetY = (height / 2) * kappa; 		// control point offset vertical
    const centerX = startPoint.x + width / 2;     // x-middle
    const centerY = startPoint.y + height / 2;    // y-middle
    const boundPoints = [];

    context.beginPath();
    context.moveTo(startPoint.x, centerY);
    context.bezierCurveTo(startPoint.x, centerY - offsetY, centerX - offsetX, startPoint.y, centerX, startPoint.y);
    context.bezierCurveTo(centerX + offsetX, startPoint.y, endPoint.x, centerY - offsetY, endPoint.x, centerY);
    context.bezierCurveTo(endPoint.x, centerY + offsetY, centerX + offsetX, endPoint.y, centerX, endPoint.y);
    context.bezierCurveTo(centerX - offsetX, endPoint.y, startPoint.x, centerY + offsetY, startPoint.x, centerY);
    context.closePath();
    context.stroke();

    boundPoints.push(new Fovia.Util.Point(startPoint.x, centerY));
    boundPoints.push(new Fovia.Util.Point(centerX, startPoint.y));
    boundPoints.push(new Fovia.Util.Point(endPoint.x, centerY));
    boundPoints.push(new Fovia.Util.Point(centerX, endPoint.y));
    return boundPoints;
  }
}
