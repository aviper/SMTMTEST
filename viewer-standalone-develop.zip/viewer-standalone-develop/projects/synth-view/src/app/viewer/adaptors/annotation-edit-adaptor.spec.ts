import { AnnotationEditAdaptor } from './annotation-edit-adaptor';

describe('MyAnnotationEditAdaptor', () => {
  it('should create an instance', () => {
    expect(new AnnotationEditAdaptor()).toBeTruthy();
  });
});
