import Fovia from 'foviaapi';
import ScrollAdaptorData = Fovia.UI.ScrollAdaptorData;
import { HTMLDoubleBufferViewportMPRFused } from "../models";
import { getPendingRenderParamsFusion } from '@server-api';
import { AdaptorsService } from '../services';
import { SeriesDisplayStoreItem3D } from '../stores';

export class PanFusionAdaptor implements Fovia.UI.MouseAdaptorInterface {
  public renderEngine: Fovia.BlendedRenderEngineContext3D;
  public htmlViewportFusion: HTMLDoubleBufferViewportMPRFused;
  private lastMouseX = 0;
  private lastMouseY = 0;
  private mouseDown = false;
  private inProcessOfPanning = false;
  private volumeDataList: Array<Fovia.VolumeDataContext | null> = [null, null];
  private volumeData1: Fovia.VolumeDataContext | null = null;
  private currentMatrixList = [new Fovia.Util.Matrix(), new Fovia.Util.Matrix()];
  private distPerPixelList = [1.0, 1.0];
  private pixelsPerMillimeterList = [1.0, 1.0];

  constructor(htmlViewportFusion: HTMLDoubleBufferViewportMPRFused, private adaptorsService: AdaptorsService, mprZoomListener?: any)  {
    this.htmlViewportFusion = htmlViewportFusion;
    this.renderEngine = this.htmlViewportFusion.getRenderEngine();
    if (this.htmlViewportFusion.volDataInfoArray.length >= 2) {
      this.volumeDataList[0] = this.htmlViewportFusion.volDataInfoArray[0];
      this.volumeDataList[1] = this.htmlViewportFusion.volDataInfoArray[1];
      this.pixelsPerMillimeterList[0] = 1.0 / this.volumeDataList[0].spacing.x;
      this.pixelsPerMillimeterList[1] = 1.0 / this.volumeDataList[1].spacing.x;
    } else {
      console.error(`PanFusionAdaptor: viewport does not have 2 Fovia.VolumeDataContext objects`);
    }
  }

  protected getRenderParams(index: number): Fovia.RenderParams3D | null {
    const rps = getPendingRenderParamsFusion(this.htmlViewportFusion);
    if (Array.isArray(rps) && (rps as Array<Fovia.RenderParams3D>).length === 2 && index >= 0 && index < 2) {
      return (rps as Array<Fovia.RenderParams3D>)[index];
    } else {
      return null;
    }
  }

  public async down(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    this.lastMouseX = event.viewportAdjusted.x;
    this.lastMouseY = event.viewportAdjusted.y;
    const rp0 = this.getRenderParams(0);
    const rp1 = this.getRenderParams(1);
    if (rp0 == null || rp1 == null) {
      return false;
    }
    this.mouseDown = true;
    this.currentMatrixList[0] = new Fovia.Util.Matrix(rp0.transform);
    this.currentMatrixList[1] = new Fovia.Util.Matrix(rp1.transform);
    this.distPerPixelList[0] = 1.0 / rp0.zoom;
    this.distPerPixelList[1] = 1.0 / rp1.zoom;
    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (!this.mouseDown) {
      return false;
    }
    if (this.renderEngine == null) {
      console.error('ScrollFusionMouseAdaptor move failed. renderEngine is null');
      return false;
    }
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport() as SeriesDisplayStoreItem3D;
    if (seriesDisplayItem == null) {
      console.error('PanFusionMouseAdaptor move failed. seriesDisplayItem3D is null');
      return false;
    }
    // short circuit this method when viewport is busy
    if (this.adaptorsService.pauseTool || this.inProcessOfPanning || seriesDisplayItem?.isRendering()) {
      return false;
    }

    this.inProcessOfPanning = true;
    this.calcPan((event.viewportAdjusted.x - this.lastMouseX) / 2, (event.viewportAdjusted.y - this.lastMouseY) / 2, 0);
    this.calcPan((event.viewportAdjusted.x - this.lastMouseX) / 2, (event.viewportAdjusted.y - this.lastMouseY) / 2, 1);
    const rp0 = new Fovia.RenderParams3D();
    const rp1 = new Fovia.RenderParams3D();
    rp0.setTransform(this.currentMatrixList[0]);
    rp1.setTransform(this.currentMatrixList[1]);

    await this.htmlViewportFusion.getRenderEngine().setRenderParams([rp0, rp1]);
    await seriesDisplayItem.renderFoviaFinal();
    this.lastMouseX = event.viewportAdjusted.x;
    this.lastMouseY = event.viewportAdjusted.y;
    this.inProcessOfPanning = false;

    return true;
  }

  // triggers the final render
  public async up(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport() as SeriesDisplayStoreItem3D;
    if (seriesDisplayItem == null) {
      console.error('PanFusionMouseAdaptor up failed. seriesDisplayItem3D is null');
      return false;
    }
    this.inProcessOfPanning = false;
    await seriesDisplayItem.renderFoviaFinal();
    await this.htmlViewportFusion.renderFinal();
    this.mouseDown = false;
    return true;
  }

  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    return false;
  }

  public calcPan(xDist: number, yDist: number, volIndex: number): void {
    const rp = this.getRenderParams(volIndex);
    if (rp == null) {
      return;
    }
    this.distPerPixelList[volIndex] = 1.0 / rp.zoom;
    const diffX = -xDist / (this.pixelsPerMillimeterList[volIndex] / 2.0);
    const diffY = -yDist / (this.pixelsPerMillimeterList[volIndex] / 2.0);


    const mat = new Fovia.Util.Matrix(this.currentMatrixList[volIndex]);

    // these vectors are assumed to be normalized
    let screenX = new Fovia.Util.Vector(mat.m11, mat.m21, mat.m31);
    screenX = screenX.scale(diffX * this.distPerPixelList[volIndex]);

    let screenY = new Fovia.Util.Vector(mat.m12, mat.m22, mat.m32);
    screenY = screenY.scale(diffY * this.distPerPixelList[volIndex]);

    let offset = new Fovia.Util.Vector(mat.m14, mat.m24, mat.m34);

    // we want to translate the view location along the plane described by the screen vectors.
    // this is easily accomplished by scaling the screen orientation vectors by the mouse offset
    // then adding it to the eye location.
    offset = offset.add(screenX);
    offset = offset.add(screenY);
    this.currentMatrixList[volIndex].setOffsetVector(offset);
  }

  public postRender(htmlViewport: any, renderParams: any): any {
    return;
  }

}
