import { AngleAnnotationEditProcessor } from './angle-annotation-edit-processor';

describe('AngleAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new AngleAnnotationEditProcessor(new Fovia.UI.HTMLViewport2D('', 1, 1))).toBeTruthy();
  });
});
