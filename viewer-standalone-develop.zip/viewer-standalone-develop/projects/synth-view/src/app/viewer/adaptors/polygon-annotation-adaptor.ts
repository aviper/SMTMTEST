import Fovia from 'foviaapi';
import { POLYGON_ANNOTATION_LAYER } from './adaptor-constants';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { convertToRenderPixel } from '../utils';
import { AdaptorsService } from "../services";

enum POLYGON_DRAWING_STATE {
  CREATE_STARTING_POINT,
  ADDING_POINTS,
}

export class PolygonAnnotationAdaptor extends AbstractAnnotationAdaptor {
  protected startPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxTopLeftPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected boundingBoxBottomRightPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);

  // Screen coordinates of the user line endpoints.
  protected userPoints: Fovia.Util.Point[] = [];

  protected drawingState: POLYGON_DRAWING_STATE = POLYGON_DRAWING_STATE.CREATE_STARTING_POINT;
  private labelText = '';

  constructor(viewport: Fovia.UI.HTMLViewport, volumeDataContext: Fovia.VolumeDataContext | null, adaptorService: AdaptorsService, showMeasurement: boolean = true) {
    super(viewport, volumeDataContext, showMeasurement, adaptorService);
    this.graphicLayer = POLYGON_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.polyline;
  }

  public override async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const displayArea = this.renderEngine.getDisplayArea();
    const points = [currentRenderPixel];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);

      const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
      if (this.drawingState === POLYGON_DRAWING_STATE.CREATE_STARTING_POINT) {
        // Start the process of creating the polygon, but don't commit to creating the annotation
        // That happens later if the user starts dragging the mouse
        this.startPoint = imagePixel;
        this.isMeasuring = true;
        this.drawingState = POLYGON_DRAWING_STATE.ADDING_POINTS;
        this.createGraphicAnnotation(currentRenderPixel);
        this.graphicAnnotation?.setShowLabelFlag(false);
      } else {
        const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        if (this.userPoints.length === 0) {
          if (this.pointsAreClose(this.startPoint, imagePixel)) {
            // The user simply clicked the mouse button without moving the mouse.  Cancel the tool.
            this.reset();
          }
        } else if (this.graphicAnnotation != null) {
          const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;

          // Add another point
          this.userPoints.push(currentRenderPixel);

          if (this.userPoints.length > 3) {
            if (this.pointsAreClose(this.userPoints[this.userPoints.length - 2], this.userPoints[this.userPoints.length - 1])) {
              // All done.  Complete the polygon when there are at least 3 points and the user clicks the same spot twice in a row
              this.removeInteractiveEndPoint();

              // Officially add the annotation to the render engine now that it's done.
              this.addLineAnnotation(annotation, false);

              // Clean up so we're ready to start another.
              this.reset();

              // Calculate the ROI and add the text to the annotation.
              this.updateAnnotationText(annotation);
            } else {
              // Add this point and continue.
              annotation.setPoint(imagePixel);
            }
          } else {
            // Add this point and continue.
            annotation.setPoint(imagePixel);
          }
        }
        this.viewport.repaint();
      }
    }
    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  /**
   * @description called when the user moves the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.isMeasuring) {
      const currentRenderPixel = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
      const points = [currentRenderPixel];
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, this.renderEngine.getDisplayArea(), 0, 0)) {
        const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentRenderPixel);
        if (this.drawingState === POLYGON_DRAWING_STATE.ADDING_POINTS && this.isMeasuring && this.graphicAnnotation != null) {
          const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
          annotation.setEndPoint(imagePixel);
        }
      }
      this.viewport.repaint();
    } else {
      this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    }
    return true;
  }

  /**
   * @description Render the Line annotations for the given annotation array
   * @param foviaHTMLViewport2D Specifies view port
   * @param canvas Specifies the canvas instance where to render
   * @param annotationArray Specifies the annotation array to be rendered
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    if (this.graphicAnnotation) {
      this.doDrawing(foviaHTMLViewport2D, canvas, [this.graphicAnnotation as Fovia.PolylineGraphicAnnotation]);
    }
    this.doDrawing(foviaHTMLViewport2D, canvas, annotationArray);
  }

  private doDrawing(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: Fovia.PolylineGraphicAnnotation[]): void {
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.PolylineGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0) {
          const graphicObjects: Array<Fovia.GraphicObject> = graphicAnnotation.graphicObjects;

          context.strokeStyle = graphicAnnotation.isHighlighted() ? this.getHighlightColor(graphicAnnotation) : this.getNormalColor(graphicAnnotation);

          for (let j = 0; j < graphicObjects.length; j++) {
            const graphicObject: Fovia.GraphicObject = graphicObjects[j];

            if (graphicObject.graphicData.length >= 2) {
              for (let k = 0; k < graphicObject.graphicData.length; k++) {
                if (k < graphicObject.graphicData.length - 1) {
                  this.drawSegment(context, graphicObject.graphicData[k], graphicObject.graphicData[k + 1]);
                } else {
                  // close the polygon
                  this.drawSegment(context, graphicObject.graphicData[k], graphicObject.graphicData[0]);
                }

                if (graphicAnnotation.isPointHighlighted()) {
                  context.strokeStyle = this.colorHighlight;
                  const renderPixelPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicObject.graphicData[k]);
                  context.strokeRect(renderPixelPoint.x - this.grabberSize / 2,
                    renderPixelPoint.y - this.grabberSize / 2, this.grabberSize, this.grabberSize);
                }
              }
              if (graphicAnnotation.showLabel && graphicAnnotation.textObjects.length > 0 && graphicAnnotation.textObjects[0].unformattedTextValue !== '') {
                this.renderTextObjects(context, graphicAnnotation);
              }
            }
          }
        }
      }
    }
  }

  protected drawSegment(context: CanvasRenderingContext2D, startPoint: Fovia.Util.Point, endPoint: Fovia.Util.Point): void {
    const imagePixelStartPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(startPoint);
    const imagePixelEndPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(endPoint);

    context.beginPath();
    context.moveTo(imagePixelStartPoint.x, imagePixelStartPoint.y);
    context.lineTo(imagePixelEndPoint.x, imagePixelEndPoint.y);
    context.stroke();
    context.closePath();
  }

  protected createGraphicAnnotation(clickedPoint: Fovia.Util.Point): void {
    if (this.userPoints.length === 0) {
      const annotation = new Fovia.PolylineGraphicAnnotation(this.graphicLayer);
      const imagePixel = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(clickedPoint);

      this.userPoints = [clickedPoint];

      annotation.setSelectedObjectIndex(0);

      // Add graphic data
      const graphicObjects: Array<Fovia.GraphicObject> = [];
      const graphicData: Array<Fovia.Util.Point> = [];

      // Begin with two points that are the same.
      graphicData.push(imagePixel);  // first vertex in the polygon
      graphicData.push(imagePixel);  // first interactive endpoint displayed during polygon construction
      const graphicObject = new Fovia.GraphicObject(graphicData, Fovia.GraphicType.polyline, false, 'PIXEL', 2);
      graphicObjects.push(graphicObject);
      annotation.graphicObjects = graphicObjects;
      // annotation.setStartPoint(imagePixel);
      this.graphicAnnotation = annotation;
    }
  }

  protected updateAnnotationText(graphicAnnotation: Fovia.PolylineGraphicAnnotation): void {
  }

  protected getNumPolygonPoints(): number {
    const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
    if (annotation != null) {
      const graphicObject: Fovia.GraphicObject = annotation.getGraphicObject(0);
      return graphicObject?.graphicData.length ?? 0;
    }
    return 0;
  }

  protected removeInteractiveEndPoint(): void {
    const annotation = this.graphicAnnotation as Fovia.PolylineGraphicAnnotation;
    if (annotation != null) {
      const graphicObject: Fovia.GraphicObject = annotation.getGraphicObject(0);
      if (graphicObject.graphicData.length > 0) {
        graphicObject.graphicData.pop();
      }
    }
  }

  protected override resetDrawingState(): void {
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
    this.drawingState = POLYGON_DRAWING_STATE.CREATE_STARTING_POINT;
    this.boundingBoxTopLeftPoint = new Fovia.Util.Point(0, 0);
    this.boundingBoxBottomRightPoint = new Fovia.Util.Point(0, 0);
    this.userPoints = [];
  }

  public override isDrawingCompleted(): boolean {
    return (this.drawingState === POLYGON_DRAWING_STATE.CREATE_STARTING_POINT);
  }

  private pointsAreClose(pt1: Fovia.Util.Point, pt2: Fovia.Util.Point): boolean {
    const margin = 5;
    return (Math.abs(pt1.x - pt2.x) <= margin && Math.abs(pt1.y - pt2.y) <= margin);
  }

}
