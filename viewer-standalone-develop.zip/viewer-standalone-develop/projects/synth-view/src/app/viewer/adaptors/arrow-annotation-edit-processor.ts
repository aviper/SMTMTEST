import Fovia from 'foviaapi';
import { LineMeasurementEditProcessor } from './line-measurement-edit-processor';
import { EDIT_MODE } from './adaptor-constants';
import { convertToRenderPixel } from '../utils';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class ArrowAnnotationEditProcessor extends LineMeasurementEditProcessor {

  /**
   * @description Constructs a new object. This constructor should only called internal to the API.
   * @param viewport Specifies the view port instance
   * @returns This is a synchronous method that returns the newly created instance <a href="fovia.ui.lineAnnotationEditProcessor.html"> <i>LineAnnotationEditProcessor</i> </a>
   */
  constructor(viewport: any, adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Move the line annotation to the current mouse point
   * @param currentPoint Specifies current mouse point
   */
  public override moveAnnotation(currentPoint: Fovia.Util.Point): boolean {
    if (this.selectedAnnotation == null || this.editMode === EDIT_MODE.none) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(currentPoint);
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    if (this.editMode > EDIT_MODE.annotation && !displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.toPoint = new Fovia.Util.Point(currentPoint);
    const deltaX = this.toPoint.x - this.fromPoint.x;
    const deltaY = this.toPoint.y - this.fromPoint.y;

    this.selectedAnnotation.setStartPointHighlight(false);
    this.selectedAnnotation.setEndPointHighlight(false);
    this.selectedAnnotation.setHighlight(false);

    if (this.editMode === EDIT_MODE.start) {
      this.selectedAnnotation.setStartPointHighlight(true);
      this.selectedAnnotation.setStartPoint(currentPoint);
    } else if (this.editMode === EDIT_MODE.end) {
      this.selectedAnnotation.setEndPointHighlight(true);
      this.selectedAnnotation.setEndPoint(currentPoint);
    } else {
      this.selectedAnnotation.setHighlight(true);
      const graphicData = this.selectedAnnotation.graphicObjects[0].graphicData;
      const renderPixelData = convertToRenderPixel(this.renderEngine, graphicData);
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(renderPixelData, displayArea, deltaX, deltaY)) {
        this.selectedAnnotation.move(deltaX, deltaY, displayArea);
        if (this.selectedAnnotation.textObjects && this.selectedAnnotation.textObjects.length > 0) {
          this.selectedAnnotation.textObjects[0].setTopLeftPoint(this.selectedAnnotation.getStartPoint());
          this.selectedAnnotation.textObjects[0].setBottomRightPoint(this.selectedAnnotation.getStartPoint());
        }
      } else {
        return false;
      }
    }

    GSPSUtils.getInstance().annotationModified = true;
    this.fromPoint = currentPoint;
    return true;
  }
}
