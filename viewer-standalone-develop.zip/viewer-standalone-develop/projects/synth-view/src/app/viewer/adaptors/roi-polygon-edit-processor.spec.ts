import { ROIPolygonEditProcessor } from './roi-polygon-edit-processor';

describe('RoiPolygonEditAdaptor', () => {
  it('should create an instance', () => {
    expect(new ROIPolygonEditProcessor(new Fovia.UI.HTMLViewport2D('', 1, 1))).toBeTruthy();
  });
});
