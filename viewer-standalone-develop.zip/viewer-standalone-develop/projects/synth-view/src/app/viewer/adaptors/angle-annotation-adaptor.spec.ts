import Fovia from 'foviaapi';
import { AngleAnnotationAdaptor } from './angle-annotation-adaptor';

describe('AngleAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new AngleAnnotationAdaptor( new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
