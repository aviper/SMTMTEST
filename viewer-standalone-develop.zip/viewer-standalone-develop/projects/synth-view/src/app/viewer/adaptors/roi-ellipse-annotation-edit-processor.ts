import Fovia from 'foviaapi';

import { EllipseAnnotationEditProcessor } from './ellipse-annotation-edit-processor';
import { GetEllipseROI } from './get-ellipse-roi';
import { AdaptorsService } from '../services';

export class ROIEllipseEditProcessor extends EllipseAnnotationEditProcessor {
  private ellipseROIRequestor: GetEllipseROI;

  /**
   * @description Constructs a new object. This constructor should only be called internal to the API.
   * @param viewportId a string that uniquely identifies a viewport
   * @param viewport Specifies the view port instance
   * @param adaptorService utility service for use with adaptors
   * @param showMeasurement indicate whether to show measurement info
   * @returns This is a synchronous method that returns the newly created instance <a href="fovia.ui.ellipseAnnotationEditProcessor.html"> <i>EllipseAnnotationEditProcessor</i> </a>
   */
  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService, private showMeasurement: boolean = true) {
    super(viewport, adaptorService);
    this.ellipseROIRequestor = new GetEllipseROI(viewportId, this.viewport, adaptorService);
  }

  /**
   * @description move the ellipse annotation to given current point
   * @param currentPoint current mouse point
   */
  public override moveAnnotation(currentPoint: Fovia.Util.Point, currentImageData: Fovia.DICOMImageTags): boolean {

    if (!super.moveAnnotation(currentPoint, currentImageData) || this.selectedAnnotation == null) {
      return false;
    }

    return true;
  }
  public doneMoving(): void {
    const pixelSpacing = this.getPixelSpacing();
    if (this.showMeasurement && this.selectedAnnotation !== null) {
      this.ellipseROIRequestor.updateROITextObject(this.selectedAnnotation, pixelSpacing, this.getSynthSettings()).then();
    }
  }


}
