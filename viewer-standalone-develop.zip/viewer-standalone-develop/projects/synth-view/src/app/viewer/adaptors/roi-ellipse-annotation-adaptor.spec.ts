import Fovia from 'foviaapi';

import { ROIEllipseAdaptor } from './roi-ellipse-annotation-adaptor.js';

describe('RoiAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new ROIEllipseAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
