import { ROIBase } from './roibase';

describe('ROIBase', () => {
  it('should create an instance', () => {
    expect(new ROIBase()).toBeTruthy();
  });
});
