import Fovia from 'foviaapi';
import { getBottomPoint, getBoundingBox, getGraphicAnnotationPoints, SynthContextSettings } from './adaptor-helpers';
import { SlopeIntercept } from '../models';
import { CM2, IPoint, PX2, ROIBase } from './roibase';
import { convertToRenderPixel } from '../utils';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';

interface IGetPolygonROIRequest {
  functionID: string;
  imageNum: number;
  numPoints: number;
  points: IPoint[];
}

interface IGetPolygonROIResponse {
  status: string;
  areaMM3: number;
  mean: number;
  stdDev: number;
  min: number;
  max: number;
}

// ROI for Polygons
export class GetPolygonROI extends ROIBase {

  private boundingBox: Fovia.Util.Rect;
  private bottomPoint: Fovia.Util.Point;
  private countP: number;
  private inProcessingOp: boolean;
  private readonly NOT_SET_BOUNDING_BOX: Fovia.Util.Rect;
  private readonly NOT_SET_BOTTOM_POINT: Fovia.Util.Point;

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService) {
    super(viewportId, viewport, adaptorService);

    this.countP = 0;
    this.inProcessingOp = false;
    this.boundingBox = new Fovia.Util.Rect(Number.MIN_VALUE, Number.MAX_VALUE, Number.MIN_VALUE, Number.MAX_VALUE);
    this.NOT_SET_BOUNDING_BOX = new Fovia.Util.Rect(Number.MIN_VALUE, Number.MAX_VALUE, Number.MIN_VALUE, Number.MAX_VALUE);
    this.bottomPoint = new Fovia.Util.Point(Number.MIN_VALUE, Number.MAX_VALUE);
    this.NOT_SET_BOTTOM_POINT = new Fovia.Util.Point(Number.MIN_VALUE, Number.MAX_VALUE);
  }

  public async updateROITextObject(selectedAnnotation: Fovia.GraphicAnnotation, pixelSpacing: string, synthContext: SynthContextSettings): Promise<void> {
    if (selectedAnnotation == null || selectedAnnotation.graphicObjects[0].graphicData.length <= 2) {
      return;
    }
    const context = synthContext.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));

    if (context == null) {
      console.error(`GetPolygonROI:updateROITextObject context may not be null.`);
      return;
    }

    const bottomPoint = this.getBottomPoint(selectedAnnotation);
    const graphicObject: Fovia.GraphicObject = selectedAnnotation.graphicObjects[0];
    const pointCount = selectedAnnotation.getGraphicObject(0)?.graphicData.length ?? 0;
    if (pointCount >= 3 && bottomPoint != null) {
      const boundingRect = this.getBoundingBox(convertToRenderPixel(this.renderEngine, graphicObject.graphicData));
      const pointsBound = [new Fovia.Util.Point(boundingRect.left, boundingRect.top), new Fovia.Util.Point(boundingRect.right, boundingRect.bottom)];
      const displayArea = this.renderEngine.getDisplayArea();
      if (Fovia.PresentationUtil.arePointsWithinImageBounds(pointsBound, displayArea)) {
        // Render the label at intersection of the two perpendiculars.
        const anchorPointImagePixel = new Fovia.Util.Point(bottomPoint.x + 10, bottomPoint.y - 10);
        const anchorPointRenderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPointImagePixel);

        const context = synthContext.getSynthContextSettings(this.viewport.getHTMLElement().getContext('2d'));
        const points = getGraphicAnnotationPoints(selectedAnnotation);

        if (!this.validate(points, context, selectedAnnotation)) {
          return;
        }

        // contents of viewport may have changed so always get slope/intercept to match
        // the currently displayed image
        const si: SlopeIntercept = this.getSlopeIntercept();

        this.getROI(points, selectedAnnotation, pixelSpacing, si).then((labelText: string[]) => {
          // console.log(`GetPolygonROI:getROI returned ${roiText}`);
          const dicomCharSet = this.renderEngine.getDicomCharSet();
          let fullText = labelText[0];
          let limitedText = labelText[1];

          if (dicomCharSet) {
            fullText = Fovia.Util.convertFromHexStr(fullText, dicomCharSet);
            limitedText = Fovia.Util.convertFromHexStr(limitedText, dicomCharSet);
          }

          // Keep both the full text and limited text. We'll show limited text unless the ellipse is highlighted,
          // in which case we'll show full ROI text.
          const textObjectConstructs: Fovia.Util.TextObjectConstructs = {
            anchorPointImagePixel: anchorPointImagePixel,
            anchorPointRenderPixel: anchorPointRenderPixel,
            label: fullText,
            context: context,
            displayArea: this.renderEngine.getDisplayArea(),
            fontHeight: synthContext.visualAttribute.font.size * Fovia.Util.Constants.DEFAULT_FONT_METRIC
          };

          const textObjects: Fovia.TextObject[] = [];
          textObjects.push(Fovia.PresentationUtil.getTextObject(textObjectConstructs, false));
          textObjectConstructs.label = limitedText;
          textObjects.push(Fovia.PresentationUtil.getTextObject(textObjectConstructs, false));

          // For the polygon ROI we use two text objects. One for displaying text when selected and one for when not selected.
          selectedAnnotation.textObjects = textObjects;
          // selectedAnnotation.setMeasurementLabel(label);
          selectedAnnotation.setShowLabelFlag(true);
          this.viewport.repaint();
        });
      }
    }
  }

  private getBoundingBox(points: Fovia.Util.Point[]): Fovia.Util.Rect {
    const rect: Fovia.Util.Rect = new Fovia.Util.Rect(Number.MIN_VALUE, Number.MAX_VALUE, Number.MIN_VALUE, Number.MAX_VALUE);

    for (let i = 0; i < points.length; i++) {
      rect.top = Math.min(points[i].y, rect.top);
      rect.left = Math.min(points[i].x, rect.left);
      rect.bottom = Math.max(points[i].y, rect.bottom);
      rect.right = Math.max(points[i].x, rect.right);
    }

    return rect;
  }

  private getBottomPoint(annotation: Fovia.GraphicAnnotation): Fovia.Util.Point | null {
    let bottomPoint: Fovia.Util.Point | null = null;
    const graphicObject = annotation.getGraphicObject(0);
    if (graphicObject != null) {
      graphicObject.graphicData.forEach(point => {
        if (bottomPoint == null || point.y > bottomPoint.y) {
          bottomPoint = point;
        }
      });
    }
    return bottomPoint;
  }

  private async getROI(points: Fovia.Util.Point[], selectedAnnotation: Fovia.GraphicAnnotation, pixelSpacing: string, si: SlopeIntercept): Promise<string[]> {
    return new Promise((resolve, reject) => {
      this.inProcessingOp = true;
      const pixelSpacingMM = this.getPixelSpacingMM(pixelSpacing);

      const clientArea = this.hasPixelSpacing ? (this.getPolygonArea(points, pixelSpacingMM) / 100).toFixed(2) : this.getPolygonArea(points, pixelSpacingMM).toFixed(2);
      const perimeter = this.hasPixelSpacing ? (this.getPolygonPerimeter(points, pixelSpacing) / 10).toFixed(2) : this.getPolygonPerimeter(points, pixelSpacing).toFixed(2);
      const height = this.hasPixelSpacing ? (Math.abs(this.boundingBox.top - this.boundingBox.bottom) * pixelSpacingMM.y / 10).toFixed(2) : Math.abs(this.boundingBox.top - this.boundingBox.bottom).toFixed(2);
      const length = this.hasPixelSpacing ? (Math.abs(this.boundingBox.left - this.boundingBox.right) * pixelSpacingMM.x / 10).toFixed(2) : Math.abs(this.boundingBox.left - this.boundingBox.right).toFixed(2);

      const imageNum = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D).imageNumber;
      const jsonRequest = this.getJson(imageNum, points);

      this.getStatisticsInPolygon2D(jsonRequest).then((roi: IGetPolygonROIResponse) => {
        // console.log('getStatisticsInPolygon2D returned ${JSON.stringify(roi)}`);

        // Use Rescale Slope/Intercept Convert these pixel values to display units eg. HU/SUV etc.
        const min = si.getModalityPixelValue(roi.min).toFixed(2);
        const max = si.getModalityPixelValue(roi.max).toFixed(2);
        const mean = si.getModalityPixelValue(roi.mean).toFixed(2);
        const stdDev = (si.slope * roi.stdDev).toFixed(2);
        const areaMM3 = this.hasPixelSpacing ? (roi.areaMM3 / 100).toFixed(2) : roi.areaMM3.toFixed(2);
        const area = roi.areaMM3 > 0 ? areaMM3 : clientArea;

        const roiInfo: string[] = [];
        // Full ROI text is first in the returned array.
        const linear = !this.hasPixelSpacing ?
          `Area: ${area} ${PX2} \nPerimeter: ${perimeter} \nLength: ${length} \nHeight: ${height}` :
          `Area: ${area} ${CM2} \nPerimeter: ${perimeter} cm\nLength: ${length} cm \nHeight: ${height} cm`;

        roiInfo.push(si.units === '' ?
          linear + `\nAverage: ${mean}\nMin: ${min}\nMax: ${max}\nStd Deviation: ${stdDev}` :
          linear + `\n${si.units} Average: ${mean}\n${si.units} Min: ${min}\n${si.units} Max: ${max}\nStd Deviation: ${stdDev}`);

        roiInfo.push(si.units === '' ?
          `Average: ${mean}` :
          `${si.units} Average: ${mean}`);

        this.inProcessingOp = false;
        resolve(roiInfo);
      })
        .catch((errMsg) => {
          this.inProcessingOp = false;
          console.error(errMsg);
          Fovia.Logger.warn('Error in getStatisticsInPolygon2D: ' + errMsg);
          reject(errMsg);
        });
    });
  }

  private async getStatisticsInPolygon2D(jsonRequest: any): Promise<IGetPolygonROIResponse> {
    this.countP++;
    // console.log(`getStatisticsInPolygon2D jsonRequest ${JSON.stringify(jsonRequest)}`);

    return Fovia.ServerContext.callCustomFunction2D([this.sdc], [], jsonRequest, [this.renderEngine]).then() as Promise<IGetPolygonROIResponse>;
  }

  private getJson(imageNumber: number, points: Fovia.Util.Point[]): any {
    const request: IGetPolygonROIRequest = {
      functionID: 'GetPolygonROI',
      imageNum: imageNumber,
      numPoints: points.length,
      points: []
    };

    for (let i = 0; i < points.length; i++) {
      const pt: IPoint = { x: points[i].x, y: points[i].y };
      request.points.push(pt);
    }

    return request;
  }

  private getPolygonArea(points: Fovia.Util.Point[], pixelSpacing: Fovia.Util.Vector): number {
    const closedPoints: Fovia.Util.Point[] = [...points];
    closedPoints.push(new Fovia.Util.Point(points[0]));
    closedPoints.push(new Fovia.Util.Point(points[1]));

    let area = 0;
    for (let i = 1; i <= points.length; i++) {
      area += (closedPoints[i].x * pixelSpacing.x) * ((closedPoints[i + 1].y - closedPoints[i - 1].y) * pixelSpacing.y);
    }
    area /= 2;
    return Math.abs(area);
  }

  private getPolygonPerimeter(points: Fovia.Util.Point[], pixelSpacing: string): number {
    let perimeterMM = 0;
    for (let i = 1; i < points.length; i++) {
      const pt1 = points[i - 1];
      const pt2 = points[i];
      perimeterMM += Fovia.PresentationUtil.getMeasurement(pixelSpacing, pt1, pt2).getValue();
    }
    return perimeterMM;
  }

  private validate(points: Fovia.Util.Point[], context: CanvasRenderingContext2D | null, selectedAnnotation: Fovia.GraphicAnnotation): boolean {
    if (points.length === 0) {
      console.error(`GetPolygonROI:updateROITextObject no points in polygon.`);
      return false;
    }

    if (context == null) {
      console.error(`GetPolygonROI:updateROITextObject context may not be null.`);
      return false;
    }
    if (this.inProcessingOp) {
      console.error(`GetPolygonROI:updateROITextObject busy with another request.`);
      return false;
    }
    this.boundingBox = getBoundingBox(points);
    if (this.boundingBox === this.NOT_SET_BOUNDING_BOX) {
      console.error(`GetPolygonROI:updateROITextObject boundingBox for Polygon must be set for each request.`);
      return false;
    }
    const bottomPt = getBottomPoint(selectedAnnotation);
    this.bottomPoint = bottomPt != null ? bottomPt : this.NOT_SET_BOTTOM_POINT;
    if (this.bottomPoint === this.NOT_SET_BOTTOM_POINT) {
      console.error(`GetPolygonROI:updateROITextObject bottomPoint for Polygon must be set for each request.`);
      return false;
    }
    return true;
  }

}
