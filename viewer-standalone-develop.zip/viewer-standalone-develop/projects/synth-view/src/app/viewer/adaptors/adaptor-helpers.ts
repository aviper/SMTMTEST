import Fovia from 'foviaapi';
import HTMLViewpport2D = Fovia.UI.HTMLViewport2D;
import HTMLViewport3D = Fovia.UI.HTMLViewport3D;
import HTMLViewportMPR = Fovia.UI.HTMLViewportMPR;

import VIEW_TYPE = Fovia.ViewType;
import MouseAdaptorInterface = Fovia.UI.MouseAdaptorInterface;
import RenderParams3D = Fovia.RenderParams3D;
import Point = Fovia.Util.Point;

import { ToolSyncActions } from './tool-sync-actions';
import {HTMLDoubleBufferViewportMPRFused, HTMLDoubleBufferViewportMPRFusion} from '../models';

// Helper class used to expose useful protected information from Fovia
class ViewportInfo3D extends HTMLViewport3D {

  constructor(private foviaVP: HTMLViewport3D) {
    super(foviaVP.getHtmlElementName(), foviaVP.getWidth(), foviaVP.getHeight());
  }

  // Accessors for protected data
  public getViewType(): VIEW_TYPE {
    return this.foviaVP['viewType'];
  }
}

function getViewType(foviaVP: HTMLViewport3D): VIEW_TYPE {
  const vpInfo = new ViewportInfo3D(foviaVP);
  return vpInfo.getViewType();
}

export function getMPRScrollAdaptor(foviaVP: HTMLViewport3D, increment: number, toolSyncActions: ToolSyncActions): MouseAdaptorInterface | null {
  // Create the appropriate kind of scroll adapter based on the viewType of the viewport
  return toolSyncActions.createMPRScrollAdaptor(foviaVP, getViewType(foviaVP), increment);
}

export function getFusedScrollAdaptor(foviaVP: HTMLDoubleBufferViewportMPRFused, increment: number, toolSyncActions: ToolSyncActions): MouseAdaptorInterface | null {
  // Create the appropriate kind of scroll adapter based on the viewType of the viewport
  return toolSyncActions.createFusedScrollAdaptor(foviaVP, increment);
}

export function getFusionMPRScrollAdaptor(foviaVP: HTMLDoubleBufferViewportMPRFusion, increment: number, toolSyncActions: ToolSyncActions): MouseAdaptorInterface | null {
  // Create the appropriate kind of scroll adapter based on the viewType of the viewport
  return toolSyncActions.createMPRFusionScrollAdaptor(foviaVP, getViewType(foviaVP), increment);
}


export class SynthContextSettings {

  constructor(public readonly visualAttribute: Fovia.Util.VisualAttribute,
    public readonly colorNormal: string,
    public readonly colorHighlight: string) {

  }

  public getSynthContextSettings(context: CanvasRenderingContext2D | null): CanvasRenderingContext2D | null {
    if (context == null) {
      return null;
    }
    const synthContext = context;
    synthContext.lineWidth = this.visualAttribute.line.width;
    synthContext.strokeStyle = this.colorNormal;
    synthContext.fillStyle = this.colorHighlight;
    synthContext.shadowColor = '#000000';
    synthContext.shadowBlur = 2;
    synthContext.font = this.visualAttribute.font.size.toString() + 'px ' + 'Inter';
    return synthContext;
  }
}

export function getBoundingBox(points: Fovia.Util.Point[]): Fovia.Util.Rect {
  const rect: Fovia.Util.Rect = new Fovia.Util.Rect(Number.MIN_VALUE, Number.MAX_VALUE, Number.MIN_VALUE, Number.MAX_VALUE);

  for (let i = 0; i < points.length; i++) {
    rect.top = Math.min(points[i].y, rect.top);
    rect.left = Math.min(points[i].x, rect.left);
    rect.bottom = Math.max(points[i].y, rect.bottom);
    rect.right = Math.max(points[i].x, rect.right);
  }

  return rect;
}

export function getBottomPoint(annotation: Fovia.GraphicAnnotation): Fovia.Util.Point | null {
  let bottomPoint: Fovia.Util.Point | null = null;
  const graphicObject = annotation.getGraphicObject(0);
  if (graphicObject != null) {
    graphicObject.graphicData.forEach(point => {
      if (bottomPoint == null || point.y > bottomPoint.y) {
        bottomPoint = point;
      }
    });
  }
  return (bottomPoint != null) ? new Fovia.Util.Point(bottomPoint) : null;
}

export function getGraphicAnnotationPoints(annotation: Fovia.GraphicAnnotation): Fovia.Util.Point[] {
  const points: Fovia.Util.Point[] = [];
  const graphicObject = annotation.getGraphicObject(0);
  if (graphicObject != null) {
    graphicObject.graphicData.forEach(point => {
      points.push(new Fovia.Util.Point(point));
    });
  }
  return points;
}
