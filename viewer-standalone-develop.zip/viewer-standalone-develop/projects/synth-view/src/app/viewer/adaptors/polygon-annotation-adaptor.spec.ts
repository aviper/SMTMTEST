import { PolygonAnnotationAdaptor } from './polygon-annotation-adaptor';

describe('PolygonAnnotationAdaptor', () => {
  it('should create an instance', () => {
    expect(new PolygonAnnotationAdaptor('viewport1', new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
