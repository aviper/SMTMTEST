import { ToolSyncActions } from './tool-sync-actions';

describe('ToolSyncActions', () => {
  it('should create an instance', () => {
    expect(new ToolSyncActions()).toBeTruthy();
  });
});
