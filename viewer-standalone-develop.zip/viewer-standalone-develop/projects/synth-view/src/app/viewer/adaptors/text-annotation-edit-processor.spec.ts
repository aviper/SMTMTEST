import { TextAnnotationEditProcessor } from './text-annotation-edit-processor';

describe('TextAnnotationEditProcessor', () => {
  it('should create an instance', () => {
    expect(new TextAnnotationEditProcessor()).toBeTruthy();
  });
});
