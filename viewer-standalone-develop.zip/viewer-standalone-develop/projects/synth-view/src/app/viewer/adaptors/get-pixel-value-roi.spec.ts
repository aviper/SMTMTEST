import { GetPixelValueROI } from './get-pixel-value-roi';

describe('GetPixelValueROI', () => {
  it('should create an instance', () => {
    expect(new GetPixelValueROI()).toBeTruthy();
  });
});
