import { TestBed } from '@angular/core/testing';

import Fovia from 'foviaapi';

import { ObliqueAdaptor } from './oblique-adaptor';
import { AdaptorsService } from '../services';

describe('ObliqueAdaptor', () => {
  let service: AdaptorsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdaptorsService);
  });

  it('should create an instance', () => {
    expect(new ObliqueAdaptor( new Fovia.UI.HTMLViewport3D('', 16, 16), service)).toBeTruthy();
  });
});
