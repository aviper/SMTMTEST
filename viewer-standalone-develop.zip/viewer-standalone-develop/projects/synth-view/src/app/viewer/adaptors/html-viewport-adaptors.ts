import Fovia from 'foviaapi';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { AnnotationEditAdaptor } from './annotation-edit-adaptor';
import { ZoomAroundPointAdaptor } from './zoom-around-point-adaptor';
import { ExtendableAnnotationAdaptor } from './extendable-annotation-adaptor';
import { EXTENDED_ANNOTATIONS } from './adaptor-constants';
import { LineMeasurementAdaptor } from './line-measurement-adaptor';
import { ExtendableEllipseAdaptor } from './extendable-ellipse-adaptor';
import { ExtendablePointAdapter } from './extendable-point-adapter';
import { ModalPopupService } from '../modal-popup-dialogs';
import { AdaptorsService } from '../services';
import { TextAnnotationAdaptor } from './text-annotation-adaptor';
import { CircleAnnotationAdaptor } from './circle-annotation-adaptor';
import { TOOL_TYPE } from '../tools';
import KeyboardModifier = Fovia.UI.KeyboardModifier;
import { getFoviaViewport3D, getFoviaViewportMPR, isBlankViewport, is3DViewport, isMPRViewport, getPendingRenderParams } from '../utils';

export class HTMLViewportAdaptors extends Fovia.UI.HTMLViewportAdaptors {
  public override getClassName(): string {
    return 'HTMLViewportAdaptors';
  }
  public textEditActive = false;
  public activeTool: TOOL_TYPE = TOOL_TYPE.eNone;
  private _synthZoomAroundPointAdaptor: ZoomAroundPointAdaptor |  null = null;
  private _momentaryAdaptor: Fovia.UI.MouseAdaptorInterface | null = null;
  private toolAdaptorMap: Map<TOOL_TYPE, any> = new Map<TOOL_TYPE, any>;

  constructor(private viewportId: string,
              htmlViewport: Fovia.UI.HTMLViewport,
              private adaptorsService: AdaptorsService,
              private modalPopupService?: ModalPopupService) {
    super(htmlViewport);
    this.htmlViewport = htmlViewport;
    this.enableGlobalMouseEvents(false);
  }

  private registerAdaptor(toolType: TOOL_TYPE, adaptor: any): void {
    this.toolAdaptorMap.set(toolType, adaptor);
  }

  public override setHTMLViewport(htmlViewport: Fovia.UI.HTMLViewport): void {
    Fovia.Logger.debug('overriding Fovia.UI.HTMLViewportAdaptors parent with supplied HTMLViewport class');
    this.htmlViewport = htmlViewport;
  }

  public set synthZoomAroundPointAdaptor(adaptor: ZoomAroundPointAdaptor | null) {
    this._synthZoomAroundPointAdaptor = adaptor;
  }
  public get synthZoomAroundPointAdaptor(): ZoomAroundPointAdaptor | null {
    return this._synthZoomAroundPointAdaptor;
  }

  public getScroll2DAdaptor(): Fovia.UI.NativeAdaptor2D {
      return this.scroll2DAdaptor;
  }

  public override setActiveAnnotationAdaptor(type: Fovia.GraphicType, mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.none): void {
    console.warn('selectCustomMouseAdaptor called but not implemented');
  }

  /**
   * By default, JavaScript windows only see mouse events within its Canvas element, which means when the mouse moves outside the
   * element, they are no longer tracked.  By enabling this option, mouse events outside the HTML element are passed to this adaptor.
   * By default, this is off (to adhere to standard javaScript behavior).    In all cases, when a mouseUp occurs outside the active
   * viewport, that event will be passed to the adaptor.
   */
  public override enableGlobalMouseEvents(globalMouseHandlerActive: boolean): void {
    this.globalMouseHandlerActive = globalMouseHandlerActive;
  }

  public set momentaryAdaptor(temp: Fovia.UI.MouseAdaptorInterface | null) {
    this._momentaryAdaptor = temp;
  }

  public getPage2DAadaptor(): Fovia.UI.NativeAdaptor2D {
    return this.page2DAdaptor;
  }

  /**
   * sets default mouse  adaptors
   */
  public override setDefaultAdaptors(renderType: Fovia.RenderType): void {
    if (this.htmlViewport instanceof Fovia.UI.HTMLFusionViewport3D || this.htmlViewport instanceof Fovia.UI.HTMLFusionViewportMPR) {
      return;
    }

    const renderEngine = this.htmlViewport.getRenderEngine();
    if (renderType === Fovia.RenderType.dicomPipeline) {
      const renderEngine2D = renderEngine;
      this.windowLevel2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.windowLevel, renderEngine2D);
      this.pan2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.pan, renderEngine2D);
      this.zoom2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.zoom, renderEngine2D);
      this.page2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.page, renderEngine2D);
      this.scroll2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.scroll, renderEngine2D);
      this.flip2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.flip, renderEngine2D, true);
      this.rotate2DAdaptor = new Fovia.UI.NativeAdaptor2D(Fovia.UI.MouseAdaptors.rotate, renderEngine2D, true);
      this.page2DTouchAdaptor = new Fovia.UI.NativeAdaptorTouch2D(Fovia.UI.MouseAdaptors.page, renderEngine2D);
      this.panZoom2DTouchAdaptor = new Fovia.UI.PanZoomNativeAdaptorTouch2D(Fovia.UI.MouseAdaptors.panZoom, renderEngine2D);
      this.windowLevel2DTouchAdaptor = new Fovia.UI.NativeAdaptorTouch2D(Fovia.UI.MouseAdaptors.windowLevel, renderEngine2D);
      this.currentSingleFingerTouchAdaptor = this.page2DTouchAdaptor;
      this.currentTwoFingerTouchAdaptor = this.panZoom2DTouchAdaptor;
      this.currentThreeFingerTouchAdaptor = this.windowLevel2DTouchAdaptor;
      return;
    }
    if (this.use2DAdaptors()) {
      // All the 2D adaptors were dealt with above, so we shouldn't have gotten here for 2D viewports.
      throw new Fovia.APIError('HTMLViewportAdaptor:  invalid render mode in setDefaultAdaptors');
    }

    const htmlViewport3D: Fovia.UI.HTMLViewport3D | null = is3DViewport(this.htmlViewport) ? getFoviaViewport3D(this.htmlViewport) : null;
    const htmlViewportMPR: Fovia.UI.HTMLViewportMPR | null = isMPRViewport(this.htmlViewport) ? getFoviaViewportMPR(this.htmlViewport) : null;
    // console.warn(`configuring 3D adaptors 3D: ${htmlViewport3D} MPR:${htmlViewportMPR}`,this.htmlViewport, renderEngine);
    if (!this.scrollTouchAdaptor && htmlViewport3D) {
      this.scrollTouchAdaptor = new Fovia.UI.ScrollTouchAdaptor(renderEngine, htmlViewport3D.scrollData);
    }
    if (!this.scrollTouchAdaptorAxial && htmlViewportMPR) {
      this.scrollTouchAdaptorAxial = new Fovia.UI.ScrollTouchAdaptorAxial(renderEngine, htmlViewportMPR.scrollDataAxial);
    }
    if (!this.scrollTouchAdaptorCoronal && htmlViewportMPR) {
      this.scrollTouchAdaptorCoronal = new Fovia.UI.ScrollTouchAdaptorCoronal(renderEngine, htmlViewportMPR.scrollDataCoronal);
    }
    if (!this.scrollTouchAdaptorSagittal && htmlViewportMPR) {
      this.scrollTouchAdaptorSagittal = new Fovia.UI.ScrollTouchAdaptorSagittal(renderEngine, htmlViewportMPR.scrollDataSagittal);
    }
    // set default touch adaptors, so it works without requiring the user to specify anyting
    if (renderType === Fovia.RenderType.parallel) {
      if (!this.rotateTouchAdaptor) {
        this.rotateTouchAdaptor = new Fovia.UI.RotateTouchAdaptor(renderEngine);
      }
      this.currentSingleFingerTouchAdaptor = this.rotateTouchAdaptor;
      if (!this.zoomPanTouchAdaptor) {
        this.zoomPanTouchAdaptor = new Fovia.UI.ZoomPanTouchAdaptor(renderEngine, renderEngine.getVolumeDataContext());
      }
      this.currentTwoFingerTouchAdaptor = this.zoomPanTouchAdaptor;
      if (!this.windowLevelTouchAdaptor && htmlViewport3D) {
        this.windowLevelTouchAdaptor = new Fovia.UI.WindowLevelTouchAdaptor(renderEngine, htmlViewport3D.wlData);
      }
      this.currentThreeFingerTouchAdaptor = this.windowLevelTouchAdaptor;
    }
    else if (renderType === Fovia.RenderType.perspective) {
      if (!this.autoNavigateAdaptor) {
        this.autoNavigateAdaptor = new Fovia.UI.AutoNavigateAdaptor(renderEngine);
      }
      this.currentSingleFingerTouchAdaptor = this.autoNavigateAdaptor;
    }
    else {
      this.currentSingleFingerTouchAdaptor = this.scrollTouchAdaptor;
      if (!this.zoomPanTouchAdaptor) {
        this.zoomPanTouchAdaptor = new Fovia.UI.ZoomPanTouchAdaptor(renderEngine, renderEngine.getVolumeDataContext());
      }
      this.currentTwoFingerTouchAdaptor = this.zoomPanTouchAdaptor;
      if (!this.windowLevelTouchAdaptor && htmlViewport3D) {
        this.windowLevelTouchAdaptor = new Fovia.UI.WindowLevelTouchAdaptor(renderEngine, htmlViewport3D.wlData);
      }
      this.currentThreeFingerTouchAdaptor = this.windowLevelTouchAdaptor;
    }
    if (!this.rotateMouseAdaptor) {
      this.rotateMouseAdaptor = new Fovia.UI.RotateMouseAdaptor(renderEngine);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.none)] = this.rotateMouseAdaptor;
    if (!this.nativePanAdaptor) {
      this.nativePanAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.pan, renderEngine);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(MouseButton.left, KeyboardModifier.shift)] = this.rotateMouseAdaptor;
    if (!this.nativeZoomAdaptor) {
      this.nativeZoomAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.zoom, renderEngine);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.right, Fovia.UI.KeyboardModifier.shift)] = this.nativeZoomAdaptor;
    if (!this.nativePanAdaptor) {
      this.nativePanAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.pan, renderEngine);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.right, Fovia.UI.KeyboardModifier.none)] = this.nativePanAdaptor;
    if (!this.scrollAdaptor && htmlViewport3D) {
      this.scrollAdaptor = new Fovia.UI.ScrollMouseAdaptor(renderEngine, htmlViewport3D.scrollData);
    }
    if (!this.scrollAdaptorAxial && htmlViewportMPR) {
      this.scrollAdaptorAxial = new Fovia.UI.ScrollMouseAdaptorAxial(renderEngine, htmlViewportMPR.scrollDataAxial);
    }
    if (!this.scrollAdaptorCoronal && htmlViewportMPR) {
      this.scrollAdaptorCoronal = new Fovia.UI.ScrollMouseAdaptorCoronal(renderEngine, htmlViewportMPR.scrollDataCoronal);
    }
    if (!this.scrollAdaptorSagittal && htmlViewportMPR) {
      this.scrollAdaptorSagittal = new Fovia.UI.ScrollMouseAdaptorSagittal(renderEngine, htmlViewportMPR.scrollDataSagittal);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.wheel, Fovia.UI.KeyboardModifier.none)] = this.scrollAdaptor;
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.middle, Fovia.UI.KeyboardModifier.none)] = this.scrollAdaptor;
    if (!this.surfaceRotateMouseAdaptor) {
      this.surfaceRotateMouseAdaptor = new Fovia.UI.SurfaceRotateMouseAdaptor(renderEngine);
    }
    // // @ts-ignore
    // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.shift)] = this.surfaceRotateMouseAdaptor;
    if (renderType === Fovia.RenderType.perspective) {
      if (!this.manualNavigateAdaptor) {
        this.manualNavigateAdaptor = new Fovia.UI.ManualNavigateAdaptor(renderEngine);
      }
      // // @ts-ignore
      // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.none)] = this.manualNavigateAdaptor;
      if (!this.autoNavigateAdaptor) {
        this.autoNavigateAdaptor = new Fovia.UI.AutoNavigateAdaptor(renderEngine);
      }
      // // @ts-ignore
      // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.ctrl)] = this.autoNavigateAdaptor;
      // // @ts-ignore
      // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.right, Fovia.UI.KeyboardModifier.shift)] = this.scrollAdaptor;
    }
    if (renderType !== Fovia.RenderType.perspective && renderType !== Fovia.RenderType.parallel) {
      if (!this.windowLevelAdaptor && htmlViewport3D) {
        this.windowLevelAdaptor = new Fovia.UI.WindowLevelAdaptor(renderEngine, htmlViewport3D.wlData);
      }
      // // @ts-ignore
      // this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.none)] = this.windowLevelAdaptor;
    }
  }

  public override addHTMLEventListeners(): void {
    const htmlViewportAdaptors = this;
    const htmlElement = this.htmlViewport.getHTMLElement();

    this.globalMouseMoveListener = htmlViewportAdaptors.globalMouseMoveHandler.bind(htmlViewportAdaptors);
    this.globalMouseUpListener = htmlViewportAdaptors.globalMouseReleaseHandler.bind(htmlViewportAdaptors);
    this.mouseEnterListener = htmlViewportAdaptors.globalMouseEnterHandler.bind(htmlViewportAdaptors);
    this.mouseLeaveListener = htmlViewportAdaptors.globalMouseLeaveHandler.bind(htmlViewportAdaptors);

    // add a global function for mouseup, we listen to mousedown and drag only on the canvas but mouseup anywhere should cancel the event
    document.body.addEventListener('mousemove', this.globalMouseMoveListener, false); // listen to mouseup everywhere else, and cancel the event
    document.body.addEventListener('mouseup', this.globalMouseUpListener, false);     // listen to mouseup everywhere else, and cancel the event

    // monitor global enter/leave events
    // document.body.addEventListener("mouseenter", this.mouseEnterListener, false);
    // document.body.addEventListener("mouseleave", this.mouseLeaveListener, false);
  }

  public override removeHTMLEventListener(): void {
  }

  /**
   * mouseDownHandler -- dispatches to the correct mouseDown handler.  Note, this
   * comes in on an HTML thread, so the HTMLViewport3D reference resides in the
   * private HTML element.
   */
  public override async mouseDownHandler(event: MouseEvent): Promise<void> {
    // do not allow the system to handle default events
    event.preventDefault();

    if (!this.allowViewportEvents) {
      return;
    }

    let rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    if (rp == null) {
      return;
    }
    // if this flag is set, that indicates that the previous call to the adaptor failed to return, and we are in a very bad state
    if (this.processingMouseAdaptor) {
      return;
    }
    // Blended render params may contain an array
    rp = Array.isArray(rp) ? rp[0] : rp;
    // So global handlers can access this object
    HTMLViewportAdaptors.staticHTMLViewportAdaptor = this;

    const adjustedEvent = this.viewportAdjusted(event);
    // console.log("client x/y = " + event.clientX + "/" + event.clientY + "adj client x/y = " + adjustedEvent.clientX + "/" + adjustedEvent.clientY);
    // check that the method is defined before we call it

    if (this._momentaryAdaptor) {
      this.currentMouseAdaptor = this._momentaryAdaptor;
    } else {
      const modifier = event.shiftKey ? Fovia.UI.KeyboardModifier.shift : 0;
      const mouseButtons = event.buttons;

      // This is a little clunky, but Fovia's idea of using a keyboard modifier or multiple mouse buttons
      // doesn't play well with our idea of using tools with attached adaptors.
      // Only the W/L tool and the W?L  can be modified with the shift key.
      if (this.activeTool !== TOOL_TYPE.eNone) {
        this.currentMouseAdaptor = this.toolAdaptorMap.get(this.activeTool);
      } else {
        // @ts-ignore
        this.currentMouseAdaptor = this.mouseMapping[this.createMouseKey(event.buttons, 0)];
      }

      if (Fovia.UI.MouseButton.left === mouseButtons && (this.annotationEditAdaptor && this.annotationEditAdaptor.getSelectedAnnotation() != null)) {
        this.currentMouseAdaptor = this.annotationEditAdaptor;
      }

      if (!this.currentMouseAdaptor && this.isAnnotationEdit) {
        this.currentMouseAdaptor = this.annotationEditAdaptor;
      }

      // @ts-ignore
      this.currentMouseMoveAdaptorOverride = this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.none, modifier)];
    }

    // reset the counter so the first reported time is consistent
    this.htmlViewport.resetFPSTime();

    if (Fovia.UI.HTMLViewport3D.g_ForceRecalculationOfWindowOffsetForAngular) {
      let currElement = this.htmlViewport.getHTMLElement();
      this.htmlViewport.offsetX = 0;
      this.htmlViewport.offsetY = 0;
      while (currElement != null) {
        this.htmlViewport.offsetX += currElement.offsetLeft;
        this.htmlViewport.offsetY += currElement.offsetTop;
        currElement = currElement.offsetParent;
      }
    }

    if (this.currentMouseAdaptor && this.currentMouseAdaptor.down) {
      adjustedEvent['foviaHtmlViewport'] = this.htmlViewport;
      this.processingMouseAdaptor = true;
      await this.currentMouseAdaptor.down(adjustedEvent, rp);
      this.processingMouseAdaptor = false;
    }

    // set the flag so a drag and a move can be distinguished
    this.mouseDown = true;

    // dispose the summary Div
    // this.disposeSummaryDiv();
  }

  /**
   * mouseMoveHandler -- dispatches to the correct mouseMove handler.  Note, this
   * comes in on an HTML thread, so the HTMLViewport3D reference resides in the
   * private HTML element.
   */
  public override async mouseMoveHandler(event: MouseEvent): Promise<void> {
    event.preventDefault();

    // If the processingMouseAdaptor flag is set, that indicates that the previous call to the adaptor failed to return, and we are in a very bad state
    if (this.processingMouseAdaptor) {
      return;
    }


    const rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    if (rp == null) {
      console.error(`${this.constructor.name} render params are null`);
      return;
    }
    // Check for override adaptors.
    if (Object.keys(this.overrideMouseMapping).length > 0) {
      let modifier = 0;
      modifier += event.shiftKey ? Fovia.UI.KeyboardModifier.shift : 0;
      modifier += event.altKey ? Fovia.UI.KeyboardModifier.alt : 0;
      modifier += event.ctrlKey ? Fovia.UI.KeyboardModifier.ctrl : 0;
      modifier += event.metaKey ? Fovia.UI.KeyboardModifier.meta : 0;

      // Check with modifier mapping with mouse button as none option
      // @ts-ignore
      this.overrideMouseAdaptor = this.overrideMouseMapping[this.createOverrideMouseKey(Fovia.UI.MouseButton.none, modifier, this.overrideKeyCharacter)];
      if (!this.overrideMouseAdaptor) {
        // Check with none options if overrideMouseAdaptor is null or undefined
        // @ts-ignore
        this.overrideMouseAdaptor = this.overrideMouseMapping[this.createOverrideMouseKey(Fovia.UI.MouseButton.none, Fovia.UI.KeyboardModifier.none)];
      }

      if (this.overrideMouseAdaptor && this.overrideMouseAdaptor.move) {
        const adjustedEvent = this.viewportAdjusted(Event);
        this.processingMouseAdaptor = true;
        await this.overrideMouseAdaptor.move(adjustedEvent, rp);
        this.processingMouseAdaptor = false;
        return;
      }
    }

    // We allow roll over selection of annotations anytime except when creating an annotation.
    if (!this.mouseDown && this.annotationEditAdaptor !== null) {
      this.currentMouseAdaptor = this.annotationEditAdaptor;
    }

    if (this.currentMouseAdaptor && this.currentMouseAdaptor instanceof AbstractAnnotationAdaptor && !this.currentMouseAdaptor.isDrawingCompleted()) {
      // handle the mouseMove operation
      const adjustedEvent = this.viewportAdjusted(event);
      this.processingMouseAdaptor = true;
      await this.currentMouseAdaptor.move(adjustedEvent, rp);
      this.processingMouseAdaptor = false;
      return;
    }
    else if (this.annotationEditAdaptor == null) {
      if (!this.currentMouseMoveAdaptorOverride) {
        // @ts-ignore
        this.currentMouseMoveAdaptorOverride = this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.none, Fovia.UI.KeyboardModifier.none)];
      }
      if (this.currentMouseMoveAdaptorOverride && this.currentMouseMoveAdaptorOverride.move) {
        // adjust event based on screen coordinates and invoke the "up" event for the current mouse adaptor
        const adjustedEvent = this.viewportAdjusted(event);
        this.processingMouseAdaptor = true;
        await this.currentMouseMoveAdaptorOverride.move(adjustedEvent, rp);
        this.processingMouseAdaptor = false;
      }
      else if (this.overrideMouseAdaptor) {
        await this.processMouseMove(event);
      }
      return;
    }

    // handle the mouseMove operation
    await this.processMouseMove(event); // <<JJS>> added await
  }
  public override globalMouseLeaveHandler(event: MouseEvent): void {
  }

  public override globalMouseEnterHandler(event: MouseEvent): void {

    // this could occur when there is no active viewport, or when the user enters the browser
    // with the mouse down
    if (HTMLViewportAdaptors.staticHTMLViewportAdaptor == null) {
      return;
    }

    // if (!HTMLViewportAdaptors.staticHTMLViewportAdaptor.initComplete) { Fovia.Logger.warn("HTMLViewport3D -- globalMouseEnterHandler called before initialization complete"); }

    // if no mouse buttons are down upon reentry, we pass a mouseUp to the active viewport (if one exists)
    if (event.buttons === 0) {
      HTMLViewportAdaptors.staticHTMLViewportAdaptor.processMouseReleased(event);
      return;
    }

    // if we are not handling global mouse events, then ignore the movement, and wait for the user to re-enter the viewport
    if (!HTMLViewportAdaptors.staticHTMLViewportAdaptor.globalMouseHandlerActive) {
      return;
    }

    // process the event
    HTMLViewportAdaptors.staticHTMLViewportAdaptor.processMouseMove(event);
  }

  /**
   * globalMouseMoveHandler -- dispatches to the correct mouseMove handler across the entire document
   */
  public override globalMouseMoveHandler(event: MouseEvent): void {

    // this could occur when there is no active viewport, or when the user enters the browser
    // with the mouse down
    if (HTMLViewportAdaptors.staticHTMLViewportAdaptor == null) {
      return;
    }
    // We don't track movement across viewport boundaries unless a user is dragging.
    if (event.buttons === 0) {
      return;
    }

    // if (!thisHTMLViewportAdaptor.initComplete) { Fovia.Logger.warn("HTMLViewport3D -- globalMouseMoveHandler called before initialization complete"); }

    // if we are not handling global mouse events, then ignore the global move event
    if (!HTMLViewportAdaptors.staticHTMLViewportAdaptor.globalMouseHandlerActive) {
      return;
    }

    // process the move event
    HTMLViewportAdaptors.staticHTMLViewportAdaptor.processMouseMove(event);
  }

  /**
   * mouseReleaseHandler -- dispatches to the correct mouseRelease handler.  Note, this
   * comes in on an HTML thread, so the HTMLViewport3D reference resides in the
   * private HTML element.
   */
  public override mouseReleaseHandler(event: MouseEvent): void {
    this.mouseDown = false;

    // this could occur when there is no active viewport, or when the user enters the browser
    // with the mouse down
    if (HTMLViewportAdaptors.staticHTMLViewportAdaptor === null) {
      console.warn('mouseReleaseHandler -- HTMLViewportAdaptors.staticHTMLViewportAdaptor is null ');
      return;
    }

    // this could occur if the mouseUp occurs in a non-active viewport.  The mouseUp for the
    // active viewport will be handled by one of the global handlers
    // note, on FireFox, event.srcElement is null when down event did not occur in this window.
    // it could also occur
    if (event.target === null || event.currentTarget !== HTMLViewportAdaptors.staticHTMLViewportAdaptor.htmlViewport.getHTMLElement()) {
      // console.warn('mouseReleaseHandler -- event.srcElement == null || event.srcElement != HTMLViewportAdaptors.staticHTMLViewportAdaptor.htmlViewport.getHTMLElement() ');
      return;
    }

    // if this flag is set, that indicates that the previous call to the adaptor failed to return, and we are in a very bad state
    if (this.processingMouseAdaptor) {
      return;
    }

    this.processMouseReleased(event).then();
  }

  /**
   * globalMouseReleaseHandler -- dispatches to the correct mouseUp handler across the entire document
   */
  public override globalMouseReleaseHandler(event: MouseEvent): void {
    // this could occur when there is no active viewport, or when the user enters the browser
    // with the mouse down
    if (HTMLViewportAdaptors.staticHTMLViewportAdaptor == null) {
      return;
    }

    // if a mouseUp happens outside the active viewport, we will ALWAYS pass it along so the activeViewport
    // can finish its operation
    // note, on FireFox, event.srcElement is null when down event did not occur in this window
    if (event.target == null || event.target !== HTMLViewportAdaptors.staticHTMLViewportAdaptor.htmlViewport.getHTMLElement()) {
      HTMLViewportAdaptors.staticHTMLViewportAdaptor.processMouseReleased(event);
    }
  }
  /**
   * mouseDragHandler -- dispatches to the correct mouseMove handler.  Note, this
   * comes in on an HTML thread, so the HTMLViewport3D reference resides in the
   * private HTML element.
   */
  public async mouseDragHandler(event: MouseEvent): Promise<void> {
    event.preventDefault();

    // Mouse movement without a button down is handled by mouseMoveHandler
    if (!this.mouseDown) {
      return;
    }
    const rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    if (rp == null) {
      console.error(`${this.constructor.name} unable to getPendingRenderParams render params are null`);
      return;
    }
    // if this flag is set, that indicates that the previous call to the adaptor failed to return, and we are in a very bad state
    if (this.processingMouseAdaptor) {
      return;
    }

    // Reset the mouse adaptor, case:  the previous mouse adaptor is AbstractAnnotationAdaptor and released the shift key
    if ((!event.shiftKey && Fovia.UI.MouseButton.left === event.buttons) && !this.isAnnotationEdit
      && this.isAnnotationAdaptorActive()) {
      const adjustedEvent = this.viewportAdjusted(event);
      await this.currentMouseAdaptor.up(adjustedEvent, rp);
      this.toggleAnnotationEdit(true);
    }

    // handle the mouseMove operation
    await this.processMouseMove(event); // <<JJS>> added await
  }

  /**
   * internal method called to handling any mouseUp events (either directly, or from another handler)
   */
  protected override async processMouseReleased(event: MouseEvent): Promise<void> {
    event.preventDefault();
    const rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    if (rp == null) {
      return;
    }
    // clear the activeViewport field
    HTMLViewportAdaptors.staticHTMLViewportAdaptor = null;

    if (this._momentaryAdaptor) {
      this.currentMouseAdaptor = this._momentaryAdaptor;
      this._momentaryAdaptor = null;
    } else {
      // if client is overriding, then bypass our handler and let them do it
      if (this.overrideMouseAdaptor && this.overrideMouseAdaptor.up) {
        const processNextEvent = <any>await this.overrideMouseAdaptor.up(event, rp);
        if (!processNextEvent) {
          // reset the state flags
          this.mouseDown = false;
          this.currentMouseAdaptor = undefined;
          return;
        }
      }
    }

    // adjust event based on screen coordinates and invoke the "up" event for the current mouse adaptor
    const adjustedEvent = this.viewportAdjusted(event);
    if (this.currentMouseAdaptor && this.currentMouseAdaptor.up) {
      adjustedEvent['foviaHtmlViewport'] = this.htmlViewport;

      await this.currentMouseAdaptor.up(adjustedEvent, rp);
      if (this.currentMouseAdaptor instanceof AbstractAnnotationAdaptor || this.currentMouseAdaptor instanceof AnnotationEditAdaptor) {
        this.processingAnnotationAdaptor = false;
      }

      // we want existing operation to continue, the user released and clicked, and we must continue the previous operations
      if (this.currentMouseAdaptor instanceof AbstractAnnotationAdaptor && !this.currentMouseAdaptor.isDrawingCompleted()) {
        this.mouseDown = true;
        return;
      }
    }

    // Enable the edit annotation mode
    if (Fovia.UI.MouseButton.left === event.buttons && !this.isAnnotationEdit
        && this.isAnnotationAdaptorActive()) {
      this.toggleAnnotationEdit(true);
    }
    // reset the state flags
    this.mouseDown = false;
    this.currentMouseAdaptor = undefined;
    this.processingMouseAdaptor = false;
  }

  /**
   * mouseMoveHandler -- dispatches to the correct mouseMove handler.  Note, this
   * comes in on an HTML thread, so the HTMLViewport3D reference resides in the
   * private HTML element.
   */
  public override async mouseWheelHandler(event: MouseEvent): Promise<void> {
    event.preventDefault();

    if (!this.allowViewportEvents) {
      return;
    }

    const rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    if (rp == null) {
      console.error(`${this.constructor.name} render params are null`);
      return;
    }
    event = this.viewportAdjusted(event);

    let handled = false;

    // Our Page tools handle the wheel, but all the others use the scroll adaptor.
    if (this.activeTool === TOOL_TYPE.ePage || this.activeTool === TOOL_TYPE.ePageAll || this.activeTool === TOOL_TYPE.ePagePlane) {
      this.currentMouseAdaptor = this.toolAdaptorMap.get(this.activeTool);
      handled = await this.currentMouseAdaptor.wheel(event, rp);
    }

    if (!handled) {
      // @ts-ignore
      const mouseAdaptor = this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.wheel, 0)];
      if (mouseAdaptor && mouseAdaptor.wheel) {
        await mouseAdaptor.wheel(event, rp);
      }
    }

    // dispose the summary Div (JJS -- what does this even mean? do we need this?
    this.disposeSummaryDiv();
  }

  /**
   *  creates a unique hash key for the specified mouse adaptor to mouse event mapping
   */
  protected override createMouseKey(mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier): string {
    return mouseButton + '_' + modifier;
  }

  /**
   *  creates a unique hash key for annotation adaptor based on type
   */
  protected override createAnnotationKey(modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.shift): string {
    return this.annotationType + '_' + modifier;
  }

  /**
   * Install a mouse adaptor that is involved unconditionally for all mouse events.  This
   * allows the application to peek at the event, process it, and stop the propagation.
   *
   * This is useful when the application is detecting a mouse over event of an annotation or
   * cross-reference lines, and handle that opposed to the current mouse adaptor that
   * would otherwise be triggered.
   */
  public override setOverrideMouseAdaptor(overrideMouseAdaptor: Fovia.UI.MouseAdaptorInterface): void {
    this.overrideMouseAdaptor = overrideMouseAdaptor;
  }

  /**
   *  creates a unique hash key for the specified override mouse adaptor to mouse event mapping
   */
  protected override createOverrideMouseKey(mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier, character: string | null = null): string {
    let key = mouseButton + '_' + modifier;
    if (character) {
      key = key + '_' + character;
    }

    return key;
  }

  /**
   * Install a mouse adaptor that is involved unconditionally for all mouse events.  This
   * allows the application to peek at the event, process it, and stop the propagation.
   *
   * This is useful when the application is detecting a mouse over event of an annotation or
   * cross-reference lines, and handle that opposed to the current mouse adaptor that
   * would otherwise be triggered.
   */
  public override initOverrideMouseAdaptor(overrideMouseAdaptor: Fovia.UI.MouseAdaptorInterface, mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.none, character: string): void {
    if (overrideMouseAdaptor == null) {
      this.overrideMouseMapping = {};
      this.overrideMouseAdaptor = overrideMouseAdaptor;
    }
    else {
      // @ts-ignore
      this.overrideMouseMapping[this.createOverrideMouseKey(mouseButton, modifier, character)] = overrideMouseAdaptor;
    }
  }

  /**
   * Set the key character for override mouse adaptor
   */
  public override setOverrideKeyCharacter(character: any): void {
    this.overrideKeyCharacter = character;
  }

  /**
   * Create a mapping between a mouse event and the specified adaptor
   */
  public selectMouseAdaptor(toolType: TOOL_TYPE, mouseAdaptorID: Fovia.UI.MouseAdaptors, mouseButton: Fovia.UI.MouseButton, orientation: Fovia.ViewType = Fovia.ViewType.oblique): void {

    if (typeof mouseAdaptorID !== 'number' || typeof mouseButton !== 'number') {
      throw new Fovia.APIError('Invalid argument list selectMouseAdaptor(enum, enum, enum) ');
    }

    const renderEngine = this.htmlViewport.getRenderEngine();

    let mouseAdaptor;
    if (this.use2DAdaptors()) {
      switch (mouseAdaptorID) {
        case Fovia.UI.MouseAdaptors.zoom:
          mouseAdaptor = this.zoom2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.pan:
          mouseAdaptor = this.pan2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.windowLevel:
          mouseAdaptor = this.windowLevel2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.page:
          mouseAdaptor = this.page2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.flip:
          mouseAdaptor = this.flip2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.rotate:
          mouseAdaptor = this.rotate2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.scroll:
          mouseAdaptor = this.scroll2DAdaptor;
          break;
        case Fovia.UI.MouseAdaptors.none:
          if (!this.emptyAdaptor) {
            this.emptyAdaptor2d = new Fovia.UI.EmptyAdaptor2D();
          }
          mouseAdaptor = new Fovia.UI.EmptyAdaptor2D();
          break;
        default:
          Fovia.Logger.debug('selectMouseAdaptor: invalid mouse mode ' + mouseAdaptorID);
          return;
      }
      // @ts-ignore
      this.mouseMapping[this.createMouseKey(mouseButton, KeyboardModifier.none)] = mouseAdaptor;
      this.registerAdaptor(toolType, mouseAdaptor);
      return;
    }

    // force this to be an htmlViewport3D, so we can get the scrollData and w;Dat
    const htmlViewport3D: any = this.htmlViewport;

    switch (mouseAdaptorID) {
      case Fovia.UI.MouseAdaptors.rotate:
        if (!this.rotateMouseAdaptor) {
          this.rotateMouseAdaptor = new Fovia.UI.RotateMouseAdaptor(renderEngine);
        }
        mouseAdaptor = this.rotateMouseAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.surfaceRotate:
        if (!this.surfaceRotateMouseAdaptor) {
          this.surfaceRotateMouseAdaptor = new Fovia.UI.SurfaceRotateMouseAdaptor(renderEngine);
        }
        mouseAdaptor = this.surfaceRotateMouseAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.zoom:
        if (!this.nativeZoomAdaptor) {
          this.nativeZoomAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.zoom, renderEngine);
        }
        mouseAdaptor = this.nativeZoomAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.zoomAroundPoint:
        if (!this.nativeZoomAroundPointAdaptor) {
          this.nativeZoomAroundPointAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.zoomAroundPoint, renderEngine);
        }
        mouseAdaptor = this.nativeZoomAroundPointAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.windowLevel:
        if (!this.windowLevelAdaptor) {
          this.windowLevelAdaptor = new Fovia.UI.WindowLevelAdaptor(renderEngine, htmlViewport3D.wlData);
        }
        mouseAdaptor = this.windowLevelAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.scroll:
        if (orientation === Fovia.ViewType.axial || orientation === Fovia.ViewType.antiAxial) {
          mouseAdaptor = this.scrollAdaptorAxial;
        }
        else if (orientation === Fovia.ViewType.coronal || orientation === Fovia.ViewType.antiCoronal) {
          mouseAdaptor = this.scrollAdaptorCoronal;
        }
        else if (orientation === Fovia.ViewType.sagittal || orientation === Fovia.ViewType.antiSagittal) {
          mouseAdaptor = this.scrollAdaptorSagittal;
        }
        else {
          mouseAdaptor = this.scrollAdaptor;
        }
        break;
      case Fovia.UI.MouseAdaptors.autoNavigate:
        if (!this.autoNavigateAdaptor) {
          this.autoNavigateAdaptor = new Fovia.UI.AutoNavigateAdaptor(renderEngine);
        }
        mouseAdaptor = this.autoNavigateAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.manualNavigate:
        if (!this.manualNavigateAdaptor) {
          this.manualNavigateAdaptor = new Fovia.UI.ManualNavigateAdaptor(renderEngine);
        }
        mouseAdaptor = this.manualNavigateAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.voxelValue:
        if (!this.voxelValueAdaptor) {
          this.voxelValueAdaptor = new Fovia.UI.VoxelValueAdaptor(renderEngine, renderEngine.getVolumeDataContext().rescaleIntercept, renderEngine.getVolumeDataContext().rescaleSlope);
        }
        mouseAdaptor = this.voxelValueAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.pan:
        if (!this.nativePanAdaptor) {
          this.nativePanAdaptor = new Fovia.UI.NativeAdaptor(Fovia.UI.MouseAdaptors.pan, renderEngine);
        }
        mouseAdaptor = this.nativePanAdaptor;
        break;
      case Fovia.UI.MouseAdaptors.none:
        if (!this.emptyAdaptor) {
          this.emptyAdaptor = new Fovia.UI.EmptyAdaptor(renderEngine);
        }
        mouseAdaptor = new Fovia.UI.EmptyAdaptor(renderEngine);
        break;
      default:
        Fovia.Logger.debug('selectMouseAdaptor: invalid mouse mode ' + mouseAdaptorID);
        return;
    }
    // @ts-ignore
    this.mouseMapping[this.createMouseKey(mouseButton, KeyboardModifier.none)] = mouseAdaptor;
    this.registerAdaptor(toolType, mouseAdaptor);
  }

  public override setMouseAdaptor(mouseAdaptorID: Fovia.UI.MouseAdaptors, mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.none, orientation: Fovia.ViewType = Fovia.ViewType.oblique): void {
    console.error('Use selectMouseAdaptor instead.');
  }

  public setBaseWheelAdaptor(mouseAdaptorInterface: any): void {
    // @ts-ignore
    this.mouseMapping[this.createMouseKey(Fovia.UI.MouseButton.wheel, 0)] = mouseAdaptorInterface;
  }

  public selectCustomMouseAdaptor(toolType: TOOL_TYPE, mouseAdaptorInterface: any, mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.none): void {
    // We generally use just one adaptor for the wheel, and that's the scroll adaptor.
    // Any of our tools that want to use wheel events will be noted via our registerAdaptor
    // but not mouseMapping, because it can only deal with one wheel adaptor.
    if (mouseButton !== Fovia.UI.MouseButton.wheel) {
      // @ts-ignore
      this.mouseMapping[this.createMouseKey(mouseButton, modifier)] = mouseAdaptorInterface;
    }
    this.registerAdaptor(toolType, mouseAdaptorInterface);
  }

  /**
   * Associate a custom mouse adaptor with a given mouse button and keyboard modifier
   */
  override setCustomMouseAdaptor(mouseAdaptorInterface: any, mouseButton: Fovia.UI.MouseButton, modifier: Fovia.UI.KeyboardModifier = Fovia.UI.KeyboardModifier.none): void {
    console.error('Use selectCustomMouseAdaptor instead.');
  }

  override displayAnnotations(flag: boolean): void {
    if (this.pointAdaptor) {
      this.pointAdaptor.displayAnnotations(flag);
    }
    if (this.lineAdaptor) {
      this.lineAdaptor.displayAnnotations(flag);
    }
    if (this.circleAdaptor) {
      this.circleAdaptor.displayAnnotations(flag);
    }
    if (this.ellipseAdaptor) {
      this.ellipseAdaptor.displayAnnotations(flag);
    }
    if (this.textAdaptor) {
      this.textAdaptor.displayAnnotations(flag);
    }
    if (this.angleAdaptor) {
      this.angleAdaptor.displayAnnotations(flag);
    }
  }

  override displayCadMarkings(flag: boolean): void {
    if (this.pointAdaptor) {
      this.pointAdaptor.displayCadMarkings(flag);
    }
    if (this.lineAdaptor) {
      this.lineAdaptor.displayCadMarkings(flag);
    }
    if (this.circleAdaptor) {
      this.circleAdaptor.displayCadMarkings(flag);
    }
    if (this.ellipseAdaptor) {
      this.ellipseAdaptor.displayCadMarkings(flag);
    }
    if (this.textAdaptor) {
      this.textAdaptor.displayCadMarkings(flag);
    }
    if (this.angleAdaptor) {
      this.angleAdaptor.displayCadMarkings(flag);
    }

  }

  override setAnnotationAdaptor(type: Fovia.GraphicType, adaptorInterface: any): void {
    if (adaptorInterface !== null) {
      switch (type) {
        case Fovia.GraphicType.point:
          this.pointAdaptor = adaptorInterface;
          break;
        case Fovia.GraphicType.polyline:
          this.lineAdaptor = adaptorInterface;
          break;
        case Fovia.GraphicType.text:
          this.textAdaptor = adaptorInterface;
          break;
        case Fovia.GraphicType.circle:
          this.circleAdaptor = adaptorInterface;
          break;
        case Fovia.GraphicType.ellipse:
          this.ellipseAdaptor = adaptorInterface;
          break;
        case Fovia.GraphicType.angle:
          this.angleAdaptor = adaptorInterface;
          break;
        default:
          Fovia.Logger.info('Invalid annotation adaptor type ' + type);
          break;
      }

      this.annotationType = type;
      // Set to mouse mapping
      // @ts-ignore
      this.annotationMapping[this.createAnnotationKey()] = adaptorInterface;
    }
    else {
      Fovia.Logger.error('Invalid annotation adaptor is passed');
    }
  }

  protected override getAnnotationAdaptor(type: Fovia.GraphicType): any {
    let adaptor = null;
    switch (type) {
      case Fovia.GraphicType.point:
        adaptor = this.pointAdaptor;
        break;
      case Fovia.GraphicType.polyline:
        adaptor = this.lineAdaptor;
        break;
      case Fovia.GraphicType.text:
        adaptor = this.textAdaptor;
        break;
      case Fovia.GraphicType.circle:
        adaptor = this.circleAdaptor;
        break;
      case Fovia.GraphicType.ellipse:
        adaptor = this.ellipseAdaptor;
        break;
      case Fovia.GraphicType.angle:
        adaptor = this.angleAdaptor;
        break;
      default:
        Fovia.Logger.info('Invalid annotation adaptor type ' + type);
        break;
    }

    return adaptor;
  }

  public getExtendableAnnotationAdaptor(): ExtendableAnnotationAdaptor | null {
    return this.getAnnotationAdaptor(Fovia.GraphicType.polyline);
  }

  public getExtendablePointAdaptor(): ExtendableAnnotationAdaptor | null {
    return this.getAnnotationAdaptor(Fovia.GraphicType.point);
  }

  public getTextAnnotationAdaptor(): TextAnnotationAdaptor | null {
    return this.getAnnotationAdaptor(Fovia.GraphicType.text);
  }

  public getCircleAnnotationAdaptor(): CircleAnnotationAdaptor | null {
    return this.getAnnotationAdaptor(Fovia.GraphicType.circle);
  }

  public getEllipseAnnotationAdaptor(): ExtendableEllipseAdaptor | null {
    return this.getAnnotationAdaptor(Fovia.GraphicType.ellipse);
  }

  public override activateAnnotation(type: Fovia.GraphicType, isFreeline: boolean = false, extendedAnnotation: EXTENDED_ANNOTATIONS = EXTENDED_ANNOTATIONS.none): void {
    // This code was moved to the previously unused activateAnnotationAdaptor so we can return the chosen adaptor.
    console.error('Use activateAnnotationAdaptor instead.');
  }

  public activateAnnotationAdaptor(toolType: TOOL_TYPE, type: Fovia.GraphicType, isFreeline: boolean = false, extendedAnnotation: EXTENDED_ANNOTATIONS = EXTENDED_ANNOTATIONS.none): void {
    let adaptor = this.getAnnotationAdaptor(type);
    if (adaptor !== null) {
      this.currentMouseAdaptor = adaptor;
      this.annotationType = type;

      // If this is one of the extendable adaptors we need to figure out which type it is and then
      // set it as a custom mouse adaptor. Otherwise we already know the adaptor type and can
      // immediately set it as a custom mouse adaptor.
      if (this.currentMouseAdaptor instanceof ExtendableAnnotationAdaptor ||
        this.currentMouseAdaptor instanceof ExtendableEllipseAdaptor ||
        this.currentMouseAdaptor instanceof ExtendablePointAdapter) {
        this.currentMouseAdaptor.activateAnnotationAdaptor(extendedAnnotation);
        adaptor = this.currentMouseAdaptor.getAnnotationAdaptor(extendedAnnotation);
        if (adaptor) {
          this.selectCustomMouseAdaptor(toolType, adaptor, Fovia.UI.MouseButton.left, Fovia.UI.KeyboardModifier.none);
          if (adaptor instanceof LineMeasurementAdaptor) {
            this.currentMouseAdaptor.toggleFreeline(isFreeline);
          }
        }
      } else {
        this.selectCustomMouseAdaptor(toolType, adaptor, Fovia.UI.MouseButton.left);
      }
    }
  }

  public override toggleAnnotationEdit(flag: boolean): void {
    this.isAnnotationEdit = flag;
    if (this.isAnnotationEdit && this.modalPopupService && this.adaptorsService) {
      this.annotationEditAdaptor = new AnnotationEditAdaptor(this.viewportId, this.htmlViewport, this.modalPopupService, this.adaptorsService);
    } else {
      if (this.annotationEditAdaptor != null) {
        this.annotationEditAdaptor.reset();
      }

      this.resetAnnotationEdit();
    }

    this.mouseDown = false;
  }

  protected override resetAnnotationEdit(): void {
    // this.currentMouseAdaptor = undefined; @@@ is this needed, it killed us
    this.mouseDown = false;
    this.isAnnotationEdit = false;
  }

  /**
   * Return true if annotation adaptor is active,
   * Else false
   * @returns boolean
   */
  public override isAnnotationAdaptorActive(): boolean {
    return (this.currentMouseAdaptor &&
      this.currentMouseAdaptor instanceof AbstractAnnotationAdaptor);

  }

  public isAnnotationSelectionActive(): boolean {
    return (this.currentMouseAdaptor && this.currentMouseAdaptor instanceof AnnotationEditAdaptor);
  }

  public override isTextAdaptorActive(): boolean {
    // We don't have any concern about the text annotation adaptor like what's in their SDK.
    return false;
  }

  public override setTextAdaptorActive(): void {
    // While annotation editing if mouse clicked on text annotation, enable editing
    // if (this.isAnnotationEdit && this.annotationEditAdaptor !== null && !this.processingAnnotationAdaptor) {
    //   this.resetAnnotationEdit();
    //   this.currentMouseAdaptor = this.textAdaptor;
    // }
  }

  protected getAnnotationTool(type: Fovia.GraphicType): TOOL_TYPE {
    let toolType = TOOL_TYPE.eNone;
    switch (type) {
      case Fovia.GraphicType.point:
        toolType = TOOL_TYPE.eROIPoint;
        break;
      case Fovia.GraphicType.polyline:
        toolType = TOOL_TYPE.eMeasureLinear;
        break;
      case Fovia.GraphicType.text:
        toolType = TOOL_TYPE.eAnnotateText;
        break;
      case Fovia.GraphicType.circle:
        toolType = TOOL_TYPE.eAnnotateCircle;
        break;
      case Fovia.GraphicType.ellipse:
        toolType = TOOL_TYPE.eROIEllipseArea;
        break;
      case Fovia.GraphicType.angle:
        toolType = TOOL_TYPE.eMeasureAngle;
        break;
      default:
        Fovia.Logger.info('Invalid annotation adaptor type ' + type);
        break;
    }

    return toolType;
  }

  /**
   * Set flag to state whether mouse/key events are allowed to perform on the viewport
   *
   * @param flag (true/false)
   */
  public override allowEventsOnViewport(flag: boolean): void {
    this.allowViewportEvents = flag;
  }

  public override viewportAdjusted(event: any): any {
    const localizedPoint = Fovia.Util.localizeEvent(event, this.htmlViewport.offsetX, this.htmlViewport.offsetY);
    event['viewportAdjusted'] = { x: localizedPoint.clientX, y: localizedPoint.clientY };
    return event;
  }

  /**
   * keyUpHandler -- dispatches to the correct keyUp handler.
   */
  public handleKeyUp(event: KeyboardEvent): boolean {
    if (event.key === 'Escape') {
      if (this.currentMouseAdaptor instanceof AbstractAnnotationAdaptor) {
        this.currentMouseAdaptor.reset();
      }
      return true;
    }

    if (!this.currentMouseAdaptor || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) {
      return false;
    }

    // TODO figure out if we're dealing with the active viewport
    // if (this.viewportID !== this.viewerSettingsService.activeViewport) {
    //   return false;
    // }
    let rtnVal = false;
    if (this.annotationEditAdaptor !== null &&
        this.annotationEditAdaptor.getSelectedAnnotation() !== null &&
        this.currentMouseAdaptor instanceof AnnotationEditAdaptor) {

      rtnVal = this.annotationEditAdaptor.keyUp(event);
    }

    if (rtnVal) {
      this.toggleAnnotationEdit(true);
    }

    this.processingKeyboardAdaptor = false;
    this.processingMouseAdaptor = false;
    return rtnVal;
  }

  public get haveSelectedAnnotation(): boolean {
    return this.annotationEditAdaptor !== null &&
      this.annotationEditAdaptor.getSelectedAnnotation() !== null &&
      this.currentMouseAdaptor instanceof AnnotationEditAdaptor;
  }

  /**
   * internal method called to handle any mouseMove operations (this is the same code as its parent, but added here in case it needs to be changed)
   */
  protected override async processMouseMove(event: MouseEvent): Promise<void> {

    event.preventDefault();
    const rp = isBlankViewport(this.htmlViewport) ? null : getPendingRenderParams(this.htmlViewport);
    // if this flag is set, that indicates that the previous call to the adaptor failed to return, and we are in a very bad state
    if (this.processingMouseAdaptor) {
      return;
    }
    if (rp == null) {
      return;
    }
    const adjustedEvent = this.viewportAdjusted(event);

    // if client is overriding, then bypass our handler and let them do it
    if (this.overrideMouseAdaptor && this.overrideMouseAdaptor.move) {
      this.processingMouseAdaptor = true;
      const processNextEvent = <any>await this.overrideMouseAdaptor.move(adjustedEvent, rp);
      this.processingMouseAdaptor = false;
      if (!processNextEvent) {
        return;
      }
    }

    // adjust event based on screen coordinates and invoke the "up" event for the current mouse adaptor
    if (this.mouseDown || this.isAnnotationEdit) {
      if ((this.mouseDown || this.annotationEditAdaptor !== null) && this.currentMouseAdaptor && this.currentMouseAdaptor.move) {
        adjustedEvent['foviaHtmlViewport'] = this.htmlViewport;
        // If ctrl key is pressed when annotation editing is done, do not allow to proceed
        if (this.mouseDown && this.annotationEditAdaptor !== null && event.ctrlKey
          && this.currentMouseAdaptor instanceof AnnotationEditAdaptor) {
          return;
        }

        this.processingMouseAdaptor = true;
        await this.currentMouseAdaptor.move(adjustedEvent, rp);
        this.processingMouseAdaptor = false;
      }
    } else { // doing an independent mouse move (not preceded by a mouseDown, and thus no mouse adaptor is defined)
      // find the correct adaptor, based on the various keyboard modifiers
      let modifier = 0;
      modifier += event.shiftKey ? Fovia.UI.KeyboardModifier.shift : 0;
      modifier += event.altKey ? Fovia.UI.KeyboardModifier.alt : 0;
      modifier += event.ctrlKey ? Fovia.UI.KeyboardModifier.ctrl : 0;
      modifier += event.metaKey ? Fovia.UI.KeyboardModifier.meta : 0;

      // @ts-ignore
      const mouseAdaptor = this.mouseMapping[this.createMouseKey(event.buttons, modifier)];
      if (mouseAdaptor && mouseAdaptor.move) {
        this.processingMouseAdaptor = true;
        await mouseAdaptor.move(adjustedEvent, rp);
        this.processingMouseAdaptor = false;
      }
    }
  }
}
