import Fovia from 'foviaapi';
import ScrollAdaptorData = Fovia.UI.ScrollAdaptorData;
import { HTMLDoubleBufferViewportMPRFused } from "../models";
import { getPendingRenderParamsFusion } from '@server-api';
import { AdaptorsService } from '../services';

export class ZoomFusionMouseAdaptor implements Fovia.UI.MouseAdaptorInterface {
  public renderEngine: Fovia.BlendedRenderEngineContext3D;
  public htmlViewportFusion: HTMLDoubleBufferViewportMPRFused;
  private lastMouseX = 0;
  private lastMouseY = 0;
  private mouseDown = false;
  private inProcessOfZooming = false;
  private zoom0: number = 1.0;
  private zoom1: number = 1.0;

  constructor(htmlViewportFusion: HTMLDoubleBufferViewportMPRFused, private adaptorsService: AdaptorsService, mprPanListener?: any) {
    this.htmlViewportFusion = htmlViewportFusion;
    this.renderEngine = this.htmlViewportFusion.getRenderEngine();
  }

  private getRenderParams(index: number): Fovia.RenderParams3D | null {
    const rps = getPendingRenderParamsFusion(this.htmlViewportFusion);
    if (Array.isArray(rps) && (rps as Array<Fovia.RenderParams3D>).length === 2 && index >= 0 && index < 2) {
      return (rps as Array<Fovia.RenderParams3D>)[index];
    } else {
      return null;
    }
  }

  public async down(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    this.lastMouseX = event.viewportAdjusted.x;
    this.lastMouseY = event.viewportAdjusted.y;
    const rp0 = this.getRenderParams(0);
    const rp1 = this.getRenderParams(1);
    if (rp0 == null || rp1 == null) {
      return false;
    }
    this.mouseDown = true;
    this.zoom0 = rp0.zoom;
    this.zoom1 = rp1.zoom;

    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (!this.mouseDown) {
      return false;
    }
    // short circuit this method when viewport is busy
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (this.adaptorsService.pauseTool || this.inProcessOfZooming || seriesDisplayItem?.isRendering()) {
      return false;
    }
    if (this.renderEngine == null) {
      console.error('ZoomFusionMouseAdaptor move failed. renderEngine is null');
      return false;
    }
    this.inProcessOfZooming = true;
    const delta = (this.lastMouseY - event.viewportAdjusted.y);
    await this.applyZoom(delta);

    this.lastMouseX = event.viewportAdjusted.x;
    this.lastMouseY = event.viewportAdjusted.y;
    this.inProcessOfZooming = false;

    return true;
  }

  // triggers the final render
  public async up(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    this.inProcessOfZooming = false;
    this.mouseDown = false;
    return true;
  }

  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    return false;
  }

  public async applyZoom(delta: number) {
    const zoomFactor = 1.0 + (delta * 0.005);
    this.zoom0 *= zoomFactor;
    this.zoom1 *= zoomFactor;
    const rp0 = new Fovia.RenderParams3D();
    const rp1 = new Fovia.RenderParams3D();
    rp0.setZoom(this.zoom0);
    rp1.setZoom(this.zoom1);
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplayItem == null) {
      console.error('ZoomFusionMouseAdaptor applyZoom failed. seriesDisplayItem3D is null');
      return;
    }
    await this.htmlViewportFusion.getRenderEngine().setRenderParams([rp0, rp1]);
    await seriesDisplayItem.renderFoviaFinal();
  }

  public postRender(htmlViewport: any, renderParams: any): any {
    return;
  }
}
