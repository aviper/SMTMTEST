import Fovia from 'foviaapi';
import { AdaptorsService } from '../services';
import { MOUSE_BUTTONS } from '../directives/input.directive';
import { ADJACENT_VIEWPORT_TOOL_MODE, CINE_DIRECTION, CINE_MODE } from '../models';
import { PAGE_TOOL_TYPE, TOOL_TYPE } from '../tools';

const FLICKER_MOVE_TOLERANCE = 10; // Number of pixels moved with the page tool before Flicker goes to the next set.
const PAGE_SPEEDS = [2, 5, 10, 15, 60];

// With virtual series, the current Fovia viewport (and it's associated adaptors) changes as the user pages through a series.
// So, PageAdaptor instances can't manage any tool state.  Mostly, PageAdaptor instances just forward events to PageController.
export class PageAdaptor implements Fovia.UI.MouseAdaptorInterface {
  private mouseLastY = 0;
  private scrollSpeedIndex = 0;
  private scrollDirection: CINE_DIRECTION = CINE_DIRECTION.forward;
  private lastWheelViewportId = '';

  constructor(private viewportID: string, private adaptorsService: AdaptorsService, private pageToolType: PAGE_TOOL_TYPE) { }

  public async down(event: any, _renderParams: Fovia.RenderParams): Promise<boolean> {
    await this.initScrolling(event);
    return true;
  }

  public async up(event: any, _renderParams: Fovia.RenderParams): Promise<boolean> {
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (!seriesDisplay) {
      console.log(`PageAdaptor.up: seriesDisplay undefined for active viewport`);
      return true;
    }

    await seriesDisplay.pageController.end(event, this.adaptorsService);

    return true;
  }

  public async move(event: any, _renderParams: Fovia.RenderParams): Promise<boolean> {
    return this.mouseMove(event);
  }

  public async mouseMove(event: MouseEvent): Promise<boolean> {
    // ** short circuit this method when adaptor service is waiting for renders to complete **
    if (this.adaptorsService.pauseTool) {
      return true;
    }

    if (event.buttons !== MOUSE_BUTTONS.eLeft) {
      return false;
    }

    // If the Power Wheel is in use and we paused cine, clear that state so if the wheel
    // gets used again it will start fresh rather than starting where it left off. This is
    // because otherwise there may be a jump from where dragging stops to where Power Wheel
    // starts again.
    if (this.adaptorsService.viewportCanUsePowerWheel(this.viewportID)) {
      this.adaptorsService.cineActions.clearCinePausedOnActiveViewport();
    }

    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (!seriesDisplay) {
      console.error(`PageAdaptor.down: seriesDisplay undefined for active viewport`);
      return true;
    }

    if (this.adaptorsService.getViewerSettingsService().showFlicker) {
      if (Math.abs(this.mouseLastY - event.y) > FLICKER_MOVE_TOLERANCE) {
        await this.adaptorsService.scrollActions.scrollToNextImageOnActiveViewport((this.mouseLastY - event.y) < 0);
        this.mouseLastY = event.y;
      }
    } else {
      // console.log(`PageAdaptor move event!`, this.mapEventToFractionalImagePositionInSeries(event));
      await seriesDisplay.pageController.move(event, this.adaptorsService);
    }

    return true;
  }

  public async wheel(event: WheelEvent, _renderParams: Fovia.RenderParams): Promise<boolean> {
    // Revert to base behavior unless Power Wheel is enabled and Flicker is not active.
    let sameDirection = false;
    if ((event.deltaY > 0 && this.scrollDirection === CINE_DIRECTION.forward) ||
      (event.deltaY < 0 && this.scrollDirection === CINE_DIRECTION.reverse)) {
      sameDirection = true;
    }
    const sameViewPortId = this.lastWheelViewportId === this.adaptorsService.activeViewport;

    this.scrollDirection = event.deltaY > 0 ? CINE_DIRECTION.forward : CINE_DIRECTION.reverse;
    this.lastWheelViewportId = this.adaptorsService.activeViewport;

    if (this.adaptorsService.viewportCanUsePowerWheel(this.viewportID)) {
      event.stopPropagation();
      const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
      if (!seriesDisplay) {
        console.log(`PageAdaptor.wheel: seriesDisplay undefined for active viewport`);
        return false;
      }
      if (this.adaptorsService.cineActions.isCineRunningOnActiveViewport()) {
        // Speed up if the wheel is turned the same direction again. Stop on a direction change.
        if (sameDirection) {
          if (this.scrollSpeedIndex < PAGE_SPEEDS.length - 1) {
            this.scrollSpeedIndex++;
            this.adaptorsService.cineActions.setCineTargetFrameRate(PAGE_SPEEDS[this.scrollSpeedIndex], true);
          }
        } else {
          this.scrollSpeedIndex = 0;
          this.adaptorsService.cineActions.pauseCineOnActiveViewport();
          await this.adaptorsService.clearLocalizerLines(this.adaptorsService.activeViewport);
        }
      } else {
        await seriesDisplay.pageController.start(event, this.adaptorsService, this.pageToolType);
        seriesDisplay.pageController.initPageAllStartingPoint();

        this.scrollSpeedIndex = 0;
        if (this.adaptorsService.cineActions.isCinePausedOnActiveViewport()) {
          this.adaptorsService.cineActions.setCineTargetFrameRate(PAGE_SPEEDS[this.scrollSpeedIndex], true);
          this.adaptorsService.cineActions.setCineDirectionOnActiveViewport(this.scrollDirection);
          this.adaptorsService.cineActions.resumeCineOnActiveViewport();
        } else {
          this.adaptorsService.cineActions.setCineOverrideDefaultFrameRate(PAGE_SPEEDS[this.scrollSpeedIndex], true);
          this.adaptorsService.cineActions.setCineOverrideDefaultDirectionOnActiveViewport(this.scrollDirection);
          this.adaptorsService.cineActions.setCineModeOverride(CINE_MODE.stop);
          this.adaptorsService.cineActions.toggleCineOnActiveViewport(true);
        }
      }
      return true;
    } else if (!this.adaptorsService.getViewerSettingsService().showFlicker) {
      // For the PagePlane and PageAll tools we need to initialize for synchronization when the direction changes or scrolling happens on a different viewport.
      if ((this.adaptorsService.getViewerSettingsService().activeToolType === TOOL_TYPE.ePagePlane || this.adaptorsService.getViewerSettingsService().activeToolType === TOOL_TYPE.ePageAll) &&
        (!sameDirection || !sameViewPortId)) {
        await this.initScrolling(event);
      }

      // Return false since we didn't really handle the wheel action. We just set up for the wheel action.
      return false;
    }
    return false;
  }

  public postRender(_htmlViewport: any, _renderParams: any): any {
    return;
  }

  public canBeAdjacentlyScrolled(): boolean {
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (!seriesDisplay) {
      console.error(`PageAdaptor.canBeAdjacentlyScrolled: seriesDisplay undefined for active viewport`);
      return false;
    }
    return seriesDisplay.virtualSeries.currentImageRef.imageSet.isBlank || (seriesDisplay.virtualSeries.currentExamSeries != null && seriesDisplay.virtualSeries.currentExamSeries.canBeAdjacentlyScrolled);
  }

  public onToolModeChanged(toolMode: ADJACENT_VIEWPORT_TOOL_MODE): void {
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (!seriesDisplay) {
      console.error(`PageAdaptor.onToolModeChanged: seriesDisplay undefined for active viewport`);
      return;
    }
    seriesDisplay.pageController.initAdjacentModeForWheel(toolMode, this.adaptorsService);
  }

  private async initScrolling(event: any): Promise<void> {
    const seriesDisplay = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (!seriesDisplay) {
      console.error(`PageAdaptor.initScrolling: seriesDisplay undefined for active viewport`);
    } else {
      this.mouseLastY = event.y;

      if (this.adaptorsService.cineActions.isCineRunningOnActiveViewport()) {
        this.adaptorsService.cineActions.pauseCineOnActiveViewport();
      } else {
        await seriesDisplay.pageController.start(event, this.adaptorsService, this.pageToolType);
      }
    }
  }
}
