import Fovia from 'foviaapi';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { LineMeasurementAdaptor } from './line-measurement-adaptor';
import { ArrowAnnotationAdaptor } from './arrow-annotation-adaptor';
import { EXTENDED_ANNOTATIONS } from './adaptor-constants';
import { CobbAngleAnnotationAdaptor } from './cobb-angle-annotation-adaptor';
import { PolygonAnnotationAdaptor } from './polygon-annotation-adaptor';
import { ROIPolygonAdaptor } from './roi-polygon-adaptor';
import { SpineLabelAnnotationAdaptor } from './spine-label-annotation-adaptor';

import { AdaptorsService } from '../services';
import { HTMLDoubleBufferViewport2DGSPS } from '../models';
import { ModalPopupService } from '../modal-popup-dialogs';
import { UserCalibratedLineMeasurementAdaptor } from './user-calibrated-line-measurement-adaptor';

//  @description Super class for all annotation adaptor class, contains methods to update annotations in render engine
// 	it captures and processes the specific mouse and keyboard events over the annotations it holds

export class ExtendableAnnotationAdaptor extends AbstractAnnotationAdaptor {

  protected annotationMap: Map<EXTENDED_ANNOTATIONS, AbstractAnnotationAdaptor> = new Map<EXTENDED_ANNOTATIONS, AbstractAnnotationAdaptor>();
  protected activeAdaptor: AbstractAnnotationAdaptor | undefined;

  constructor(viewportId: string,
    viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    modalPopupService: ModalPopupService,
    adaptorService: AdaptorsService,
    showMeasurement: boolean) {
    super(viewport, volumeDataContext, showMeasurement, adaptorService);
    this.annotationMap.set(EXTENDED_ANNOTATIONS.polyline, new LineMeasurementAdaptor(viewport, volumeDataContext, showMeasurement, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.arrow, new ArrowAnnotationAdaptor(viewport, volumeDataContext, modalPopupService, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.cobbAngle, new CobbAngleAnnotationAdaptor(viewport, volumeDataContext, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.polygon, new PolygonAnnotationAdaptor(viewport, volumeDataContext, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.roiPolygon, new ROIPolygonAdaptor(viewportId, viewport, volumeDataContext, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.spineLabel, new SpineLabelAnnotationAdaptor(viewport, adaptorService));
    this.annotationMap.set(EXTENDED_ANNOTATIONS.calibrateLine, new UserCalibratedLineMeasurementAdaptor(viewport, volumeDataContext, showMeasurement, adaptorService));
  }

  public activateAnnotationAdaptor(type: EXTENDED_ANNOTATIONS): void {
    this.activeAdaptor = this.annotationMap.get(type);
  }

  public getAnnotationAdaptor(type: EXTENDED_ANNOTATIONS): AbstractAnnotationAdaptor | null {
    const adaptor = this.annotationMap.get(type);
    return adaptor ? adaptor : null;
  }

  public toggleFreeline(flag: boolean = false): void {
    if (this.activeAdaptor instanceof LineMeasurementAdaptor) {
      this.activeAdaptor.toggleFreeline(flag);
    }
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async down2D(event: MouseEvent, renderParams: any): Promise<boolean> {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.down2D(event, renderParams);
    }
    return false;
  }

  /**
   * @description called when the user releases the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async up(event: MouseEvent, renderParams: any): Promise<boolean> {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.up(event, renderParams);
    }
    return false;
  }

  /**
   * @description called when the user is moving or dragging the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.move2D(event, renderParams);
    }
    return false;
  }

  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.render2D(foviaHTMLViewport2D, canvas, annotationArray);
    }
  }

  /**
   * @description called when the user is moving the wheel of the mouse
   * @param event captured mouse event instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public override async wheel(event: MouseEvent, renderParams: any): Promise<boolean> {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.wheel(event, renderParams);
    }
    return false;
  }

  public override render(foviaHTMLViewport: HTMLDoubleBufferViewport2DGSPS, canvas: HTMLCanvasElement, width: number, height: number, imageTags: any): void {
    if (this.activeAdaptor != null) {
      return this.activeAdaptor.render(foviaHTMLViewport, canvas, width, height, imageTags);
    }
  }

  /**
   * @description called after an image is returned from the server; useful during navigation when you need to know when the rendering is complete
   * @param htmlViewport Specifies view port instance
   * @param renderParams render parameters that to be applied
   */
  public override postRender(htmlViewport: any, renderParams: any): void {
    if (this.activeAdaptor != null) {
      this.activeAdaptor.postRender(htmlViewport, renderParams);
    }
  }
}
