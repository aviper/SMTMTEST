import Fovia from 'foviaapi';

import { EXTENDED_ANNOTATIONS, SPINE_ANNOTATION_LAYER } from './adaptor-constants';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { AdaptorsService } from '../services';
import { SPINE_LABEL_TYPE } from '../modal-popup-dialogs';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { makeImageKey } from '@server-api';

export class SpineLabelAnnotationAdaptor extends AbstractAnnotationAdaptor {
  protected textAnnotation: Fovia.TextGraphicAnnotation | null = null;
  public static selectedSpineLabelType: SPINE_LABEL_TYPE = SPINE_LABEL_TYPE.NONE;

  constructor(viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService) {
    super(viewport, null, false, adaptorService);
    this.graphicLayer = SPINE_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.text;
  }

  public static override resetDefaults(): void {
    SpineLabelAnnotationAdaptor.selectedSpineLabelType = SPINE_LABEL_TYPE.V1;
  }

  public static getInstance(vp: Fovia.UI.HTMLViewport): SpineLabelAnnotationAdaptor | null {
    const vpAdaptors = vp.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
    const extendableAdaptor = vpAdaptors.getExtendableAnnotationAdaptor();
    const adaptor = extendableAdaptor?.getAnnotationAdaptor(EXTENDED_ANNOTATIONS.spineLabel) ?? null;
    return (adaptor == null) ? null : adaptor as SpineLabelAnnotationAdaptor;
  }

  public get haveSelection(): boolean {
    const key = makeImageKey(this.sopInstanceUid, this.frameNumber);
    const annotations = this.renderEngine.getAnnotations(Fovia.GraphicType.text, key, false)
      .filter((annotation) => {
        return annotation.graphicLayer === SPINE_ANNOTATION_LAYER;
      });
    if (annotations.length > 0) {
      for (const annotation of annotations) {
        if (annotation.isHighlighted()) {
          return true;
        }
      }
    }
    return false;
  }

  // Create a spine label.  This gets called on the current viewport after the spine label dialog is displayed,
  // and then from other viewports that are sync'ed to the current viewport.
  public createSpineLabelAnnotation(labelText: string, renderImagePixel: Fovia.Util.Point): boolean {

    // Figure out the location and bounds of the text.
    const textBounds = this.getTextBounds(labelText);
    const renderImageTextTopLeft = new Fovia.Util.Point(renderImagePixel.x, renderImagePixel.y);
    const renderImageTextBottomRight = new Fovia.Util.Point(
      renderImageTextTopLeft.x + textBounds.width,
      renderImageTextTopLeft.y + textBounds.height
    );

    const points = [renderImageTextTopLeft, renderImageTextBottomRight];
    const displayArea = this.renderEngine.getDisplayArea();
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      const dicomImageTextTopLeft = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(renderImageTextTopLeft);
      const dicomImageTextBottomRight = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(renderImageTextBottomRight);

      if (this.textAnnotation == null) {
        this.textAnnotation = new Fovia.TextGraphicAnnotation(this.graphicLayer);
        this.addTextAnnotation(this.textAnnotation);
      } else {
        // Remove the existing text object.
        this.textAnnotation.textObjects = [];
      }
      const encodedUserText = this.encodeUserText(this.renderEngine, labelText);
      this.textAnnotation.textObjects.push(new Fovia.TextObject(dicomImageTextTopLeft, encodedUserText, false,
        Fovia.HorizontalJustification.left, dicomImageTextTopLeft, dicomImageTextBottomRight,
        Fovia.MeasurementUnits.pixel, Fovia.MeasurementUnits.pixel, dicomCharSet));

      this.textAnnotation.setFirstBoundPoint(dicomImageTextTopLeft);
      this.textAnnotation.setSecondBoundPoint(dicomImageTextBottomRight);
    }
    const ret = this.textAnnotation != null;
    this.resetEdit();
    return ret;
  }

  public onSpineLabelDialogSelection(userText: string, renderImagePixel: Fovia.Util.Point, viewportId: string): void {
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(false);
    if (this.createSpineLabelAnnotation(userText, renderImagePixel)) {
      const threeDCursorVector = this.viewport.getSeriesDataContext().mapPointToFrameOfReference(
        this.viewport.getRenderEngine().renderImagePixelToDicomImagePixelWithDiff(renderImagePixel),
        this.viewport.getRenderEngine()
      );
      this.adaptorService.addSpineLabelsToOtherViewports(viewportId, threeDCursorVector, userText).then();
    }
    this.viewport.getHtmlViewportAdaptors().toggleAnnotationEdit(true);
  }

  public encodeUserText(renderEngine: Fovia.RenderEngineContext2D, userText: string): string {
    let dicomCharSet = renderEngine.getDicomCharSet();
    let encodedUserText = '';
    if (dicomCharSet) {
      dicomCharSet = Fovia.Util.getEncodingType(dicomCharSet);
      const data = Fovia.Util.convertFromHexStr(userText, dicomCharSet);
      encodedUserText = window.btoa(decodeURI(encodeURIComponent(data)));
    } else {
      encodedUserText = btoa(userText);
    }
    return encodedUserText;
  }

  public get nextLabel(): SPINE_LABEL_TYPE {
    switch (SpineLabelAnnotationAdaptor.selectedSpineLabelType) {
      case SPINE_LABEL_TYPE.NONE:
        return SPINE_LABEL_TYPE.V1;
      case SPINE_LABEL_TYPE.V1:
        return SPINE_LABEL_TYPE.V2;
      case SPINE_LABEL_TYPE.V2:
        return SPINE_LABEL_TYPE.V3;
      case SPINE_LABEL_TYPE.V3:
        return SPINE_LABEL_TYPE.V4;
      case SPINE_LABEL_TYPE.V4:
        return SPINE_LABEL_TYPE.V5;
      case SPINE_LABEL_TYPE.V5:
        return SPINE_LABEL_TYPE.V6;
      case SPINE_LABEL_TYPE.V6:
        return SPINE_LABEL_TYPE.V7;
      case SPINE_LABEL_TYPE.V7:
        return SPINE_LABEL_TYPE.V8;
      case SPINE_LABEL_TYPE.V8:
        return SPINE_LABEL_TYPE.V9;
      case SPINE_LABEL_TYPE.V9:
        return SPINE_LABEL_TYPE.V10;
      case SPINE_LABEL_TYPE.V10:
        return SPINE_LABEL_TYPE.V11;
      case SPINE_LABEL_TYPE.V11:
        return SPINE_LABEL_TYPE.V12;
      case SPINE_LABEL_TYPE.V12:
        return SPINE_LABEL_TYPE.V1;
      case SPINE_LABEL_TYPE.D1_2:
        return SPINE_LABEL_TYPE.D2_3;
      case SPINE_LABEL_TYPE.D2_3:
        return SPINE_LABEL_TYPE.D3_4;
      case SPINE_LABEL_TYPE.D3_4:
        return SPINE_LABEL_TYPE.D4_5;
      case SPINE_LABEL_TYPE.D4_5:
        return SPINE_LABEL_TYPE.D5_1;
      case SPINE_LABEL_TYPE.D5_1:
        return SPINE_LABEL_TYPE.D5_6;
      case SPINE_LABEL_TYPE.D5_6:
        return SPINE_LABEL_TYPE.D6_1;
      case SPINE_LABEL_TYPE.D6_1:
        return SPINE_LABEL_TYPE.D6_7;
      case SPINE_LABEL_TYPE.D6_7:
        return SPINE_LABEL_TYPE.D7_1;
      case SPINE_LABEL_TYPE.D7_1:
        return SPINE_LABEL_TYPE.D7_8;
      case SPINE_LABEL_TYPE.D7_8:
        return SPINE_LABEL_TYPE.D8_9;
      case SPINE_LABEL_TYPE.D8_9:
        return SPINE_LABEL_TYPE.D9_10;
      case SPINE_LABEL_TYPE.D9_10:
        return SPINE_LABEL_TYPE.D10_11;
      case SPINE_LABEL_TYPE.D10_11:
        return SPINE_LABEL_TYPE.D11_12;
      case SPINE_LABEL_TYPE.D11_12:
        return SPINE_LABEL_TYPE.D12_1;
      case SPINE_LABEL_TYPE.D12_1:
        return SPINE_LABEL_TYPE.D1_2;
    }
  }

  public resetEdit(): void {
    if (this.textAnnotation != null) {
      this.textAnnotation.setEditMode(false);
      this.textAnnotation.setHighlight(false);
      this.textAnnotation = null;
    }
    this.viewport.repaint();
  }

  /**
   * @description called when the user releases the mouse
   * Shift + Mouse Release - Create the new text element, if the text annotation is
   * not in edit mode
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */


  public override async up(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    return true;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  /**
   * @description called when the user is moving or dragging the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns the value return by move2D method call
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  /**
   * @description Render given text annotations on the given canvas
   * @param foviaHTMLViewport2D view port instance
   * @param canvas canvas instance fetched from view port
   * @param annotationArray
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.TextGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0 && graphicAnnotation.textObjects.length > 0) {
          if (graphicAnnotation.showLabel) {
            const isHighlighted = graphicAnnotation.isHighlighted();
            this.renderTextObjects(context, graphicAnnotation, graphicAnnotation.isHighlighted(), true);

            // Just keep the anchor point at the top left of the text box
            graphicAnnotation.textObjects[0].anchorPoint[0] = graphicAnnotation.textObjects[0].getAdjustedTopLeftPoint();
          }
        }
      }
    }
  }
}
