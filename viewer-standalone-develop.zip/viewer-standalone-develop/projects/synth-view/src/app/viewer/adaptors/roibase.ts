import Fovia from 'foviaapi';
import { SlopeIntercept, SUVInfo } from '../models';
import { getSlopeInterceptFromViewport } from '../utils';
import { MemoryCacheService } from '../services';
import { AdaptorsService } from '../services';
import { compareDicomDateAndTime, deltaTimeInSeconds, makeImageKeyFromImageTags } from '@server-api';

export const CM2 = 'cm²';
export const PX2 = 'px²';
export const PIXELS = 'pixels';

export interface IPoint {
  x: number;
  y: number;
}

export class ROIBase {
  protected sdc: Fovia.SeriesDataContext;
  protected renderEngine: Fovia.RenderEngineContext2D;
  protected hasPixelSpacing: boolean;
  protected suvInfo: SUVInfo | null = null;
  protected memoryCacheService: MemoryCacheService | null = null;

  constructor(viewportId: string, protected viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService) {
    this.sdc = viewport.getSeriesDataContext();
    this.renderEngine = viewport.getRenderEngine();
    this.hasPixelSpacing = false;

    const seriesDisplayItem = adaptorService.getSeriesDisplayForViewport(viewportId);
    if (seriesDisplayItem) {
      this.memoryCacheService = seriesDisplayItem.memoryCacheService ?? null;
    }
    if (seriesDisplayItem && seriesDisplayItem.series && seriesDisplayItem.series.isModalityPT()) {
      this.suvInfo = seriesDisplayItem.series.getSuvInfo(seriesDisplayItem.virtualSeries.currentSopInstanceUID);

      // This is the oldest acquisition time in the series of images. It is only needed when series time
      // is after acquisition time.
      this.suvInfo.earliestAcquisitionTime = seriesDisplayItem.series.getEarliestAcquisitionTime();
    }
  }
  protected getPixelSpacingMM(pixelSpacing: string): Fovia.Util.Vector {
    this.hasPixelSpacing = pixelSpacing !== '';
    return this.hasPixelSpacing ? Fovia.PresentationUtil.toVector(pixelSpacing) : new Fovia.Util.Vector(1, 1, 1);
  }
  protected getSlopeIntercept(): SlopeIntercept {
    return  getSlopeInterceptFromViewport(this.viewport);
  }

  protected determineSuvScaleFactor(): number {
    // SUV cannot be calculated	if any of the specified DICOM attributes are missing or empty or zero
    if (this.suvInfo === null) {
      console.warn('SUV - not all required DICOM tags are available.');
      return -1;
    }

    if (this.suvInfo.correctedImage === null || this.suvInfo.correctedImage === '') {
      console.warn('SUV - correctedImage is null');
      return -1;
    }

    if (this.suvInfo.decayCorrection === null || this.suvInfo.decayCorrection === '') {
      console.warn('SUV - decayCorrection is null');
      return -1;
    }

    if (this.suvInfo.seriesDate === null || this.suvInfo.seriesTime === null ||
        this.suvInfo.seriesDate === '' || this.suvInfo.seriesTime === '') {
      console.warn('SUV - seriesDate or suvInfo.seriesTime is null');
      return -1;
    }

    if (this.suvInfo.acquisitionDate === null || this.suvInfo.acquisitionTime === null ||
      this.suvInfo.acquisitionDate === '' || this.suvInfo.acquisitionTime === '') {
      console.warn('SUV - acquisitionDate or suvInfo.acquisitionTime is null');
      return -1;
    }

    if (this.suvInfo.radionuclideTotalDose === null || this.suvInfo.radionuclideTotalDose === 0) {
      console.warn('SUV - radionuclideTotalDose is null');
      return -1;
    }

    if (this.suvInfo.radionuclideHalfLife === null || this.suvInfo.radionuclideHalfLife === 0) {
      console.warn('SUV - radionuclideHalfLife is null');
      return -1;
    }

    // Either radiopharmaceuticalStartDatetime or radiopharmaceuticalStartTime has to be present.
    if	((this.suvInfo.radiopharmaceuticalStartDatetime === null || this.suvInfo.radiopharmaceuticalStartDatetime === '') &&
        (this.suvInfo.radiopharmaceuticalStartTime === null || this.suvInfo.radiopharmaceuticalStartTime === '')) {
      console.warn('SUV - radiopharmaceuticalStartDatetime and suvInfo.radiopharmaceuticalStartTime are null');
      return -1;
    }

    if (this.suvInfo.patientWeight === null || this.suvInfo.patientWeight === 0) {
      console.warn('SUV - patientWeight is null');
      return -1;
    }

    // Corrected Image (0x0028,0x0051) must contain 'ATTN' and 'DECY.
    if (!this.suvInfo.correctedImage.toUpperCase().includes('ATTN') || !this.suvInfo.correctedImage.toUpperCase().includes('DECY')) {
      console.warn('SUV - decayCorrection is not ATTN or DECY');
      return -1;
    }

    // Decay Correction	(0x0054,0x1102)	has to be 'START'.
    if (this.suvInfo.decayCorrection.toUpperCase() !== 'START') {
      console.warn('SUV - decayCorrection is not START');
      return -1;
    }

    let suvScaleFactor = 1;
    if (this.suvInfo.units ===	'BQML') {
      let scanTime: string | null = '';
      let startTime = '';
      if (compareDicomDateAndTime(this.suvInfo.seriesDate, this.suvInfo.seriesTime, this.suvInfo.acquisitionDate, this.suvInfo.acquisitionTime) <= 0) {
        scanTime = this.suvInfo.seriesTime;
      } else {
        // The algorithm gives options here. We choose to use the	earliest	acquisition time of	all	images	in	the series.
        // Note that this is apparently not appropriate for PETsyngo	3.x	multi-injection, whatever that is.
        scanTime = this.suvInfo.earliestAcquisitionTime;
        // May	be	post-processed	series in	which	Series	Date	and	Time	are	date	of	series	creation	unrelated	to	acquisition.
        if (this.suvInfo.gePrivateScanDateTime !== null) {
          // Use GE date and time private tag.
          scanTime = this.suvInfo.gePrivateScanDateTime.substring(8);
        } else {
          // else	may	be	Siemens	series with	altered	Series	Date	and	Time
          // // either	check	earliest	of	all	images	in	series	(for	all	bed	positions) (wrong	for	case	of	PETsyngo	3.x	multi-injection)
          //             scan Date	and	Time	= earliest	Acquisition	Date	(0x0008,0x0022)	and	Time	(0x0008,0x0032)		in	all	images	of	series
          //             or
          // //	back	compute	from	center	(average	count	rate	)	of	time	window	for	bed	position	(frame)	in	series (reliable	in	all	cases)
          // //	Acquisition	Date	(0x0008,0x0022)	and	Time	(0x0008,0x0032) are	the	start	of	the	bed	position	(frame)
          // //	Frame	Reference	Time	(0x0054,0x1300) is	the	offset	(ms)	from	the	scan	Date	and	Time we	want	to	the	average	count	rate	time
          //             if		(Frame	Reference	Time	(0x0054,0x1300) >	0	&&	Actual	Frame	Duration (0018,1242) >	0)	{
          //               frame	duration	=	Actual	Frame	Duration (0018,1242) /	1000 //	DICOM	is	in	ms;	want	seconds
          //               decay	constant	=	ln(2)	/		half	life
          //               decay	during	frame	=	decay	constant	*	frame	duration
          //               average	count	rate	time	within	frame =	1/decay	constant *	ln(decay	during	frame	/	(1	– exp(-decay	during	frame)))
          //               scan	Date	and	Time =	Acquisition	Date	(0x0008,0x0022)	and	Time	(0x0008,0x0032)
          //               - Frame	Reference	Time (0x0054,0x1300) /1000	+	average	count	rate	time	within	frame
          //             }
        }
        if (scanTime === null || scanTime === '') {
          console.warn('SUV - EarliestAcquisitionTime and PrivateScanDateTime and FrameReferenceTime are null');
          return -1;
        }
      }

      if (this.suvInfo.radiopharmaceuticalStartDatetime !== null) {
        // Note: we already checked above to make sure either radiopharmaceuticalStartDatetime or radiopharmaceuticalStartTime is present.
        startTime = this.suvInfo.radiopharmaceuticalStartDatetime.substring(8);
      } else if (this.suvInfo.radiopharmaceuticalStartTime !== null) {
        startTime = this.suvInfo.radiopharmaceuticalStartTime;
      }

      // Radionuclide Total Dose is NOT	corrected for residual dose in syringe,	which is ignored here.
      const decayTime = deltaTimeInSeconds(startTime, scanTime);
      const decayedDose = this.suvInfo.radionuclideTotalDose * Math.pow(2, -decayTime / this.suvInfo.radionuclideHalfLife);
      suvScaleFactor = (this.suvInfo.patientWeight * 1000 / decayedDose);
    } else if (this.suvInfo.units === 'CNTS') {
      if (this.suvInfo.philipsPrivateScaleFactor !== null) {
        // suvScaleFactor = this.suvInfo.philipsPrivateScaleFactor;
        console.warn('SUV - Philips Scale Factor is provided, but it is not implemented.');
        return -1;
      } else if (this.suvInfo.philipsAltPrivateScaleFactor !== null && this.suvInfo.rescaleSlope !== null) {
        // Scales	pixels	to	Bq/ml,	and	proceed	as	if	Units	are	BQML.
        // suvScaleFactor = this.suvInfo.philipsAltPrivateScaleFactor * this.suvInfo.rescaleSlope;
        console.warn('SUV - Philips Scale ALTERNATE Factor is provided, but it is not implemented.');
        return -1;
      } else {
        console.warn('SUV - CNTS units, but no Scale Factor provided.');
        return -1;
      }
    } else if (this.suvInfo.units === 'GML') {
      // Assumes that GML indicates SUVbw instead of SUVlbm.
      suvScaleFactor = 1;
    }
    return suvScaleFactor;
  }
  protected async getCachedImage(imageNum: number): Promise<Fovia.ImageData | null> {
    const key =  makeImageKeyFromImageTags(this.sdc.imageTags[imageNum]);
    const fcm = this.memoryCacheService?.foviaCacheManager;
    if (!fcm) { return null; }
    return fcm.get(key) ?? (typeof fcm.getAsync === 'function' ? await fcm.getAsync(key) : null);
  }
}
