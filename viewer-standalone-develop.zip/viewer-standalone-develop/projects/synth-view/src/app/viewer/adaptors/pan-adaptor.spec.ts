import { PageAdaptor } from './page-adaptor';

describe('PanAdaptor', () => {
  it('should create an instance', () => {
    // expect(new PageAdaptor()).toBeTruthy();
  });
});
