import { ROIPointEditProcessor } from './roi-point-edit-processor';

describe('RoiPointEditAdaptor', () => {
  it('should create an instance', () => {
    expect(new ROIPointEditProcessor(new Fovia.UI.HTMLViewport2D('', 1, 1))).toBeTruthy();
  });
});
