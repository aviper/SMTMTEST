import { ScrollAdaptor } from './scroll-adaptor';

describe('ScrollAdaptor', () => {
  it('should create an instance', () => {
    expect(new ScrollAdaptor()).toBeTruthy();
  });
});
