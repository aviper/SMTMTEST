import { ROIPointAdaptor } from './roi-point-adaptor';

describe('RoiPointAdaptor', () => {
  it('should create an instance', () => {
    expect(new ROIPointAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null)).toBeTruthy();
  });
});
