import Fovia from 'foviaapi';
import { AbstractAnnotationAdaptor } from './abstract-annotation-adaptor';
import { TEXT_ANNOTATION_LAYER } from './adaptor-constants';
import { firstValueFrom, take } from 'rxjs';
import { MatDialogRef } from '@angular/material/dialog';
import { TextInputComponent } from './text-input/text-input.component';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { ModalPopupService, TextInputParams } from '../modal-popup-dialogs';
import { AdaptorsService } from '../services';
import { GSPSUtils } from '@server-api';

export class TextAnnotationAdaptor extends AbstractAnnotationAdaptor {
  public reverseTextColor = false;
  protected anchorPoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  protected textAnnotation: Fovia.TextGraphicAnnotation | null = null;

  constructor(viewport: Fovia.UI.HTMLViewport,
    volumeDataContext: Fovia.VolumeDataContext | null,
    private modalPopupService: ModalPopupService,
    adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, false, adaptorService);
    this.graphicLayer = TEXT_ANNOTATION_LAYER;
    this.graphicType = Fovia.GraphicType.text;
    this.supportsGenericDicomGraphicType = true;
  }

  /**
   * @description called when the user releases the mouse
   * Shift + Mouse Release - Create the new text element, if the text annotation is
   * not in edit mode
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async up(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    const viewportAdaptor = this.viewport.getHtmlViewportAdaptors() as HTMLViewportAdaptors;
    event.preventDefault();
    this.isMeasuring = false;

    this.anchorPoint = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    const displayArea = this.renderEngine.getDisplayArea();
    let dicomCharSet = this.renderEngine.getDicomCharSet();
    let originalText = '';
    let textTopLeft: Fovia.Util.Point = this.anchorPoint;

    viewportAdaptor.toggleAnnotationEdit(false);

    // If editing an existing annotation we need to get the current text and position.
    if (this.textAnnotation && this.textAnnotation.textObjects.length > 0) {
      originalText = this.textAnnotation.getUnformattedText();
      if (originalText && originalText.length > 0) {
        if (dicomCharSet) {
          originalText = atob(originalText);
          originalText = Fovia.Util.convertFromBytes(originalText, dicomCharSet, 'ST');
          originalText = originalText.replace('\u0000', '');
        } else {
          originalText = atob(originalText);
        }
      }
      this.anchorPoint = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(this.textAnnotation.textObjects[0].anchorPoint[0]);
      textTopLeft = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(this.textAnnotation.textObjects[0].getAdjustedTopLeftPoint());
    }

    const points = [this.anchorPoint];
    if (Fovia.PresentationUtil.arePointsWithinImageBounds(points, displayArea, 0, 0)) {
      const point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(this.anchorPoint);

      // Display the text input dialog approximately at the mouse position.
      const adapter = viewportAdaptor.getTextAnnotationAdaptor();
      const panelBounds = adapter?.adaptorService?.getPanelBoundsByViewportId(this.viewport.getHtmlElementName()) ?? null;
      const config: TextInputParams = new TextInputParams(event.y, event.x, panelBounds, originalText);
      const textDialogRef: MatDialogRef<TextInputComponent> = this.modalPopupService.openTextDialog(config);

      let observedUserText = '';
      let backdropClicked = false;

      // Keep the most current user text in case a user closes the dialog by clicking away from the dialog,
      // which results in 'undefined' being returned by the dialog instead of the text.
      textDialogRef.componentInstance.userTextChange.subscribe((text: string) => {
        observedUserText = text;
      });

      textDialogRef.backdropClick()
        .pipe(
          take(1)
        )
        .subscribe(_ => {
          backdropClicked = true;
        });

      // Detect when the dialog is opened and keep track until it's closed.
      textDialogRef.afterOpened()
        .pipe(
          take(1)
        )
        .subscribe(_ => {
          viewportAdaptor.textEditActive = true;
        });

      let userText = '';
      await firstValueFrom(textDialogRef.afterClosed())
        .then(result => {
          if (result === undefined) {
            // If a user closes the dialog by clicking away from the dialog or pressing Escape then 'result' is undefined.
            // We'll use what we've been given via the userTextChange observable for the click-away, but scrap
            // user changes for Escape.
            result = backdropClicked ? observedUserText : '';
          }
          userText = result;
          viewportAdaptor.textEditActive = false;
        });

      if (userText !== '') {
        let encodedUserText = '';

        if (dicomCharSet) {
          dicomCharSet = Fovia.Util.getEncodingType(dicomCharSet);
          const data = Fovia.Util.convertFromHexStr(userText, dicomCharSet);
          encodedUserText = window.btoa(decodeURI(encodeURIComponent(data)));
        } else {
          encodedUserText = btoa(userText);
        }

        // Figure out the location and bounds of the text.
        // We have to provide the bounds of the graphic annotation even though we don't really have a graphic.
        // Providing bounds facilitates detection for edit/move/delete since the detection in the Fovia SDK
        // only searches for graphic annotations, not associated text objects.
        const textBounds = this.getTextBounds(userText);
        const x = this.anchorPoint.x + textBounds.width;
        let y = this.anchorPoint.y + textBounds.height;
        const displayArea = this.viewport.getRenderEngine().getDisplayArea();
        if (y > displayArea.height) {
          y -= (y - displayArea.height);
          y -= 2;
        }
        const firstPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(textTopLeft);
        const secondPoint = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(new Fovia.Util.Point(x, y));

        if (this.textAnnotation == null) {
          this.textAnnotation = new Fovia.TextGraphicAnnotation(this.graphicLayer);
          this.addTextAnnotation(this.textAnnotation);
        } else {
          // Remove the existing text object.
          this.textAnnotation.textObjects = [];
        }
        this.textAnnotation.textObjects.push(new Fovia.TextObject(point, encodedUserText, false,
          Fovia.HorizontalJustification.left, firstPoint, secondPoint,
          Fovia.MeasurementUnits.pixel, Fovia.MeasurementUnits.pixel, dicomCharSet));

        this.textAnnotation.setFirstBoundPoint(firstPoint);
        this.textAnnotation.setSecondBoundPoint(secondPoint);
      }
      viewportAdaptor.toggleAnnotationEdit(true);
    }
    GSPSUtils.getInstance().annotationModified = true;
    this.resetEdit();
    return true;
  }

  public resetEdit(): void {
    if (this.textAnnotation != null) {
      this.textAnnotation.setEditMode(false);
      this.textAnnotation.setHighlight(false);
      this.textAnnotation = null;
    }
    this.viewport.repaint();
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns true in success case false will be returned in failure case
   */
  public override async down2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  /**
   * @description called when the user is moving or dragging the mouse
   * @param event Specifies MouseEvent instance
   * @param renderParams Specifies the RenderParam Instance
   * @returns Returns the value return by move2D method call
   */
  public override async move2D(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  /**
   * @description Render given text annotations on the given canvas
   * @param foviaHTMLViewport2D view port instance
   * @param canvas canvas instance fetched from view port
   * @param annotationArray
   */
  public override render2D(foviaHTMLViewport2D: Fovia.UI.HTMLViewport2D, canvas: HTMLCanvasElement, annotationArray: any[]): void {
    // Start with the line width, line color, shadow, etc. that we use everywhere.
    const context = this.getSynthContextSettings(canvas.getContext('2d'));
    if (context && annotationArray.length > 0) {
      for (let m = 0; m < annotationArray.length; m++) {
        const graphicAnnotation: Fovia.TextGraphicAnnotation = annotationArray[m];
        if (graphicAnnotation && graphicAnnotation.state === 0 && graphicAnnotation.textObjects.length > 0) {
          if (graphicAnnotation.showLabel) {
            this.renderTextObjects(context, graphicAnnotation, graphicAnnotation.isHighlighted(), true, this.reverseTextColor);

            // Draw a line from the anchor point to the text if it has moved.
            const anchorPoint = graphicAnnotation.textObjects[0].anchorPoint[0] ?? null;
            const imagePixelAnchor = (anchorPoint != null) ? this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(anchorPoint) : null;
            const rectTL = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicAnnotation.textObjects[0].getAdjustedTopLeftPoint());
            const rectBR = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(graphicAnnotation.textObjects[0].getAdjustedBottomRightPoint());

            const points: Fovia.Util.Point[] = [];
            points.push(rectTL);
            points.push(rectBR);
            points.push(new Fovia.Util.Point(rectBR.x, rectTL.y));
            points.push(new Fovia.Util.Point(rectTL.x, rectBR.y));

            if (imagePixelAnchor != null) {
              const corner = Fovia.PresentationUtil.getClosestPoint(imagePixelAnchor, points);

              // Draw a line connecting the anchor point to the text if the text is far enough away.
              if (imagePixelAnchor.calculateDistance(corner) > 5) {
                context.beginPath();
                context.moveTo(imagePixelAnchor.x, imagePixelAnchor.y);
                context.lineTo(corner.x, corner.y);
                context.stroke();
                context.closePath();
              }
            }
          }
        }
      }
    }
  }

  /**
   * @description Set the annotation.
   * @param annotation
   */
  public setCurrentAnnotation(annotation: Fovia.GraphicAnnotation): void {
    this.textAnnotation = (annotation as Fovia.TextGraphicAnnotation);
  }
}
