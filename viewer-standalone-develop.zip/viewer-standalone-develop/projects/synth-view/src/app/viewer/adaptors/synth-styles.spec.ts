import { SynthStyles } from './synth-styles';

describe('SynthStyles', () => {
  it('should create an instance', () => {
    expect(new SynthStyles()).toBeTruthy();
  });
});
