import { ROIEllipseEditProcessor } from './roi-ellipse-annotation-edit-processor';

describe('ROIEllipseEditProcessor', () => {
  it('should create an instance', () => {
    expect(new ROIEllipseEditProcessor(new Fovia.UI.HTMLViewport2D('', 1, 1))).toBeTruthy();
  });
});
