import Fovia from 'foviaapi';

import { AdaptorsService } from '../services';
import { Bounds, getFoviaViewportExtensions, ZoomModeHelper } from '../utils';
import { getRenderEngineActive, setRenderEngineActive } from '@server-api';

import { MIN_USER_ZOOM_FACTOR } from '../utils';
import { IMAGE_DISPLAY_ALIGNMENT } from '../models';

export class ZoomAroundPointAdaptor implements Fovia.UI.MouseAdaptorInterface {

  private screenPoint = new Fovia.Util.Point(0, 0);
  private imagePoint: Fovia.Util.Point = new Fovia.Util.Point(0, 0);
  private fullResolution = false;
  private userZoom = MIN_USER_ZOOM_FACTOR;
  private lastMouseY = 0;
  private cacheRP: any;

  constructor(private viewportID: string,
    private readonly htmlFoviaViewport: Fovia.UI.HTMLViewport,
    private adaptorsService: AdaptorsService) {
    this.userZoom = getFoviaViewportExtensions(htmlFoviaViewport).userZoom;
    this.fullResolution = this.adaptorsService.getViewerSettingsService().fullImageResolution;
    // console.log(`New ZoomAroundPointAdaptor userZoom=${this.userZoom} fitToViewport=${this.fitToViewport}`, htmlFoviaViewport);
  }

  public async down(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    this.userZoom = getFoviaViewportExtensions(this.htmlFoviaViewport).userZoom;

    const x = event.viewportAdjusted.x;
    const y = event.viewportAdjusted.y;

    this.lastMouseY = y;

    // get the points we are zooming around (at the initial click point)
    this.screenPoint.x = x;
    this.screenPoint.y = y;
    this.imagePoint = this.htmlFoviaViewport.getRenderEngine().renderImagePixelToDicomImagePixel(this.screenPoint);
    this.imagePoint = this.htmlFoviaViewport.getRenderEngine().getRotatedDicomPoint(this.imagePoint);

    return true;
  }

  public async move(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    const seriesDisplayItem = this.adaptorsService.getSeriesDisplayForActiveViewport();
    if (seriesDisplayItem == null) {
      return false;
    }
    const y = event.viewportAdjusted.y;

    const renderEngine = this.htmlFoviaViewport.getRenderEngine();
    const canvasBounds = this.adaptorsService.getLastRenderCanvasBounds(this.viewportID);
    const imageBounds = new Bounds(renderEngine.dicomImgWidth, renderEngine.dicomImgHeight);

    this.imagePoint = renderEngine.renderImagePixelToDicomImagePixel(this.screenPoint);
    this.imagePoint = renderEngine.getRotatedDicomPoint(this.imagePoint);

    // User Mag is a separate concept from any scale-to-fit plus magnification. Let the user zoom
    // 1...n, no minification.
    this.userZoom = Math.max(MIN_USER_ZOOM_FACTOR, this.userZoom * (1.0 + ((this.lastMouseY - y) * 0.006)));

    const zh = new ZoomModeHelper(!this.fullResolution, imageBounds, canvasBounds, this.userZoom);

    const newZoom = zh.getZoomFactor();

    const rpNew = renderParams ? renderParams : new Fovia.RenderParams2D();

    const sdc = renderEngine.getSeriesDataContext();

    // Set the appropriate offset to keep the zoom point at the initial click point
    const offsetX = (this.screenPoint.x - canvasBounds.width / 2) - ((this.imagePoint.x - sdc.imageWidth / 2) * newZoom);
    const offsetY = (this.screenPoint.y - canvasBounds.height / 2) - ((this.imagePoint.y - sdc.imageHeight / 2) * newZoom);
    if (renderEngine.isValidPan(offsetX, offsetY, this.htmlFoviaViewport.getWidth(), this.htmlFoviaViewport.getHeight(), newZoom)) {
      rpNew.offsetX = offsetX;
      rpNew.offsetY = offsetY;
    }
    rpNew.zoom = newZoom;

    this.lastMouseY = y;
    this.cacheRP = rpNew;

    // Save the current userZoom factor so we can guard against losing this info when adaptors
    // are torn down during viewport canvas reassignment.
    const vpProps = getFoviaViewportExtensions(this.htmlFoviaViewport);
    vpProps.userZoom = this.userZoom;

    // Render the image with new zoom and offsets
    await seriesDisplayItem.setRenderParams2D(rpNew, Fovia.RenderRequest.renderFinal); // no pause?

    // Mammo images need to stay chest wall justified. Okay to push past the alignment side but not okay to pull away from it.
    if (seriesDisplayItem.virtualSeries.currentImageRef.imageSet.imageAlignment !== IMAGE_DISPLAY_ALIGNMENT.none) {
      await seriesDisplayItem.applyPanToCurrentImage(0, 0);
    }

    return true;
  }

  public async up(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return true;
  }

  public async wheel(event: any, renderParams: Fovia.RenderParams2D): Promise<boolean> {
    return false;
  }

  public postRender(htmlViewport: any, renderParams: any): void {
  }

  public fullResolutionInit(fullResolution: boolean): void {
    this.fullResolution = fullResolution;
  }

}
