import { CineAdaptorActions } from './cine-adaptor-actions';

describe('CineAdaptorActions', () => {
  it('should create an instance', () => {
    expect(new CineAdaptorActions()).toBeTruthy();
  });
});
