import Fovia from 'foviaapi';
import { AdaptorsService } from '../services';

export class ScrollAdaptor implements Fovia.UI.MouseAdaptorInterface {

  constructor(private adaptorsService: AdaptorsService) {
  }

  public down(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    // console.log(`ScrollAdaptor down event!`);
    return Promise.resolve(false);
  }

  public up(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    return Promise.resolve(false);
  }

  public move(event: MouseEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    return Promise.resolve(false);
  }

  public wheel(event: WheelEvent, renderParams: Fovia.RenderParams): Promise<boolean> {
    this.adaptorsService.scrollActions.scrollToNextImageOnActiveViewport((event?.deltaY > 0)).then();
    return Promise.resolve(true);
  }

  public postRender(htmlViewport: any, renderParams: any): any {
    return;
  }
}
