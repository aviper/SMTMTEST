
describe('AdaptorHelpers', () => {
  it('should create an instance', () => {
    // expect(new AdaptorHelpers()).toBeTruthy();
  });
});
