import Fovia from 'foviaapi';

import { AngleAnnotationEditProcessor } from './angle-annotation-edit-processor';
import { ArrowAnnotationEditProcessor } from './arrow-annotation-edit-processor';
import { CircleAnnotationEditProcessor } from './circle-annotation-edit-processor';
import { CobbAngleAnnotationEditProcessor } from './cobb-angle-annotation-edit-processor';
import { EllipseAnnotationEditProcessor } from './ellipse-annotation-edit-processor';
import { LineMeasurementEditProcessor } from './line-measurement-edit-processor';
import { PointAnnotationEditProcessor } from './point-annotation-edit-processor';
import { PolygonAnnotationEditProcessor } from './polygon-annotation-edit-processor';
import { ROIEllipseEditProcessor } from './roi-ellipse-annotation-edit-processor';
import { ROIPointEditProcessor } from './roi-point-edit-processor';
import { ROIPolygonEditProcessor } from './roi-polygon-edit-processor';
import { TextAnnotationEditProcessor } from './text-annotation-edit-processor';
import {
  ARROW_ANNOTATION_LAYER,
  COBB_ANGLE_ANNOTATION_LAYER,
  POLYGON_ANNOTATION_LAYER,
  ROI_POLYGON_ANNOTATION_LAYER,
  ROI_POINT_ANNOTATION_LAYER,
  ROI_ELLIPSE_ANNOTATION_LAYER,
  isSynthAnnotationLayer
} from './adaptor-constants';
import { ModalPopupService } from '../modal-popup-dialogs';
import { AdaptorsService } from '../services';
import { HTMLViewportAdaptors } from './html-viewport-adaptors';
import { GSPSUtils, getPendingRenderParams2D } from '@server-api';

/**
*@description Edits the selected annotation,
*Captures and processing the specific mouse and keyboard events over the annotations,
*hold all edit annotation adapters to process further,
 *contains selected annotation reference to edit
 */
export class AnnotationEditAdaptor implements Fovia.UI.AnnotationEditInterface {
  public state: Fovia.Util.GSPSSelectionMode = Fovia.Util.GSPSSelectionMode.REJECT;

  protected isMeasuring = false;
  protected viewport: Fovia.UI.HTMLViewport;
  protected renderEngine;
  protected is2D: boolean;

  // Selected annotations to edit
  private sopInstanceUid = ''; // Currently loaded image
  private frameNumber = 1; // Currently loaded frame
  private selectedAnnotation: Fovia.GraphicAnnotation | null = null;
  protected selectedAnnotationCopy: Fovia.GraphicAnnotation | null = null;
  private pointAnnotationEditProcessor: PointAnnotationEditProcessor;
  private lineAnnotationEditProcessor: LineMeasurementEditProcessor;
  private arrowAnnotationEditProcessor: ArrowAnnotationEditProcessor;
  private angleAnnotationEditProcessor: AngleAnnotationEditProcessor;
  private cobbAngleAnnotationEditProcessor: CobbAngleAnnotationEditProcessor;
  private circleAnnotationEditProcessor: CircleAnnotationEditProcessor;
  private ellipseAnnotationEditProcessor: EllipseAnnotationEditProcessor;
  private polygonAnnotationEditProcessor: PolygonAnnotationEditProcessor;
  private roiEllipseEditProcessor: ROIEllipseEditProcessor;
  private roiPointEditProcessor: ROIPointEditProcessor;
  private roiPolygonEditProcessor: ROIPolygonEditProcessor;
  private textAnnotationEditProcessor: TextAnnotationEditProcessor;

  private currentImageData: Fovia.DICOMImageTags | null = null; // Currently loaded image tags
  private annotationType = '';
  private manufacturer = '';
  private lastMouseDownPos = new Fovia.Util.Point(-1, -1);

  constructor(viewportId: string,
    viewport: Fovia.UI.HTMLViewport,
    private modalPopupService: ModalPopupService,
    private adaptorsService: AdaptorsService) {
    this.viewport = viewport;
    this.renderEngine = this.viewport.getRenderEngine();
    this.is2D = this.viewport instanceof Fovia.UI.HTMLViewport2D;
    console.assert(this.is2D || this.viewport instanceof Fovia.UI.HTMLViewport3D);

    // Initialize edit annotation processors
    this.pointAnnotationEditProcessor = new PointAnnotationEditProcessor(this.viewport, adaptorsService);
    this.lineAnnotationEditProcessor = new LineMeasurementEditProcessor(this.viewport, adaptorsService);
    this.arrowAnnotationEditProcessor = new ArrowAnnotationEditProcessor(this.viewport, adaptorsService);
    this.angleAnnotationEditProcessor = new AngleAnnotationEditProcessor(this.viewport, adaptorsService);
    this.cobbAngleAnnotationEditProcessor = new CobbAngleAnnotationEditProcessor(this.viewport, adaptorsService);
    this.circleAnnotationEditProcessor = new CircleAnnotationEditProcessor(this.viewport, adaptorsService);
    this.ellipseAnnotationEditProcessor = new EllipseAnnotationEditProcessor(this.viewport, adaptorsService);
    this.polygonAnnotationEditProcessor = new PolygonAnnotationEditProcessor(this.viewport, adaptorsService);
    this.roiEllipseEditProcessor = new ROIEllipseEditProcessor(viewportId, this.viewport, adaptorsService, true);
    this.roiPointEditProcessor = new ROIPointEditProcessor(viewportId, viewport, adaptorsService);
    this.roiPolygonEditProcessor = new ROIPolygonEditProcessor(viewportId, viewport, adaptorsService);
    this.textAnnotationEditProcessor = new TextAnnotationEditProcessor(viewport, modalPopupService, adaptorsService);
  }

  /**
   * @description set annotation Type
   * @param annotationType annotation type for ROI or Ellipse
   */
  public setAnnotationType(annotationType: string): void {
    this.annotationType = annotationType;
  }

  /**
   * @description called when the user pressed the mouse down
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async down(event: any, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    if (this.selectedAnnotation != null) {
      this.isMeasuring = true;
      // Remember where the mouse went down so we can test for whether the mouse moved while it was down.
      this.lastMouseDownPos.x = event.x;
      this.lastMouseDownPos.y = event.y;
    }

    return true;
  }

  /**
   * @description called when the user releases the mouse
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async up(event: any, renderParams: Fovia.RenderParams): Promise<boolean> {
    // Detect a click without movement, or at least minimal movement.
    // This is the action for bringing up the edit text dialog.
    if (Math.abs(event.x - this.lastMouseDownPos.x) < 3 &&
      Math.abs(event.y - this.lastMouseDownPos.y) < 3 &&
      this.selectedAnnotation instanceof Fovia.TextGraphicAnnotation) {
      const adaptors = this.viewport.getHtmlViewportAdaptors();

      // Currently our 3D viewports don't use our version of HTMLViewportAdaptors. Make sure of what
      // we have before attempting to use our customizations of HTMLViewportAdaptors.
      if (adaptors instanceof HTMLViewportAdaptors) {
        adaptors.textEditActive = true;
      }
      await this.textAnnotationEditProcessor.editText(this.selectedAnnotation, event, renderParams);
    } else if (this.selectedAnnotation instanceof Fovia.PolylineGraphicAnnotation && this.selectedAnnotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER) {
      this.roiPolygonEditProcessor.doneMoving();
    } else if (this.selectedAnnotation instanceof Fovia.EllipseGraphicAnnotation && this.selectedAnnotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) {
      this.roiEllipseEditProcessor.doneMoving();
    }

    this.reset();
    return true;
  }

  /**
   * @description called when the user is moving or dragging the mouse,
   *  If measuring is still active, the currently selected annotation will be moved.
   * Else, detect annotation based on mouse points
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async move(event: any, unusedRenderParams: Fovia.RenderParams3D): Promise<boolean> {
    event.preventDefault();

    const renderParams = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
    if (!renderParams || !this.renderEngine.isPresentationDataAvailable()) {
      return false;
    }

    this.currentImageData = this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber];
    if (this.currentImageData == null) {
      return false;
    }
    this.sopInstanceUid = '';
    if (this.currentImageData.sopInstanceUID) {
      this.sopInstanceUid = this.currentImageData.sopInstanceUID.trim();
    }
    this.frameNumber = this.currentImageData.frameNumber;

    const currentPoint = new Fovia.Util.Point(event.viewportAdjusted.x, event.viewportAdjusted.y);
    if (this.isMeasuring && this.selectedAnnotation != null) {
      let returnFlag: boolean;
      document.body.style.cursor = 'pointer';
      this.selectedAnnotation.setIsNewFlag(true);
      const dicomPixelPoint: Fovia.Util.Point = this.renderEngine.renderImagePixelToDicomImagePixelWithDiff(currentPoint);
      if (this.selectedAnnotation instanceof Fovia.PointGraphicAnnotation) {
        if (this.selectedAnnotation.graphicLayer === ROI_POINT_ANNOTATION_LAYER) {
          returnFlag = this.roiPointEditProcessor.moveAnnotation(dicomPixelPoint);
        } else {
          returnFlag = this.pointAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
        }
      } else if (this.selectedAnnotation instanceof Fovia.PolylineGraphicAnnotation) {
        if (this.selectedAnnotation.graphicLayer === ARROW_ANNOTATION_LAYER) {
          returnFlag = this.arrowAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
        } else if (this.selectedAnnotation.graphicLayer === COBB_ANGLE_ANNOTATION_LAYER) {
          returnFlag = this.cobbAngleAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
        } else if (this.selectedAnnotation.graphicLayer === POLYGON_ANNOTATION_LAYER) {
          returnFlag = this.polygonAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
        } else if (this.selectedAnnotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER) {
          returnFlag = this.roiPolygonEditProcessor.moveAnnotation(dicomPixelPoint, this.currentImageData);
        } else {
          returnFlag = this.lineAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
        }
      } else if (this.selectedAnnotation instanceof Fovia.AngleGraphicAnnotation) {
        returnFlag = this.angleAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
      } else if (this.selectedAnnotation instanceof Fovia.CircleGraphicAnnotation) {
        returnFlag = this.circleAnnotationEditProcessor.moveAnnotation(dicomPixelPoint, this.currentImageData);
      } else if (this.selectedAnnotation instanceof Fovia.EllipseGraphicAnnotation) {
        if (this.selectedAnnotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) {
          returnFlag = this.roiEllipseEditProcessor.moveAnnotation(dicomPixelPoint, this.currentImageData);
        } else {
          returnFlag = this.ellipseAnnotationEditProcessor.moveAnnotation(dicomPixelPoint, this.currentImageData);
        }
      } else if (this.selectedAnnotation instanceof Fovia.TextGraphicAnnotation) {
        returnFlag = this.textAnnotationEditProcessor.moveAnnotation(dicomPixelPoint);
      }

      this.viewport.repaint();

      // @ts-ignore
      return returnFlag ?? false;
    }
    const hadSelection: boolean = this.selectedAnnotation !== null;
    const highlightChanged = this.processSelection(currentPoint);
    const haveSelection: boolean = this.selectedAnnotation !== null;
    if (highlightChanged || hadSelection !== haveSelection) {
      this.viewport.repaint();
    }

    return true;
  }

  /**
   * @description selects annotations on the current mouse point, and process them using their
   * corresponding edit adaptor
   * @param currentPoint current mouse point location
   * @returns true will be returned in success case, or else false will be returned
   */
  private processSelection(currentPoint: Fovia.Util.Point): boolean {

    // Reset cursor position and annotations
    this.reset();
    let highlightChanged = false;

    if (this.renderEngine.canShowAnnotations()) {
      const allAnnotations = this.renderEngine.getAnnotations(Fovia.GraphicType.polyline, this.sopInstanceUid + `_${this.frameNumber}`) as Fovia.GraphicAnnotation[];
      const selectedAnnotationContext = this.renderEngine.selectAnnotation(currentPoint, this.sopInstanceUid, this.frameNumber);

      if (selectedAnnotationContext.selectedAnnotaton === null) {
        const polygons = allAnnotations.filter((annotation) => annotation.graphicLayer === POLYGON_ANNOTATION_LAYER || annotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER);

        for (const polygon of polygons) {
          if (polygon instanceof Fovia.PolylineGraphicAnnotation && this.polygonAnnotationEditProcessor.checkSelection(polygon, currentPoint)) {
            selectedAnnotationContext.selectedAnnotaton = polygon;
            selectedAnnotationContext.presentationDataContext = this.renderEngine.presentationSeriesDataContext;
            break;
          }
        }
      }
      if (selectedAnnotationContext.selectedAnnotaton != null && this.canEditAnnotation(selectedAnnotationContext.selectedAnnotaton)) {
        this.selectedAnnotation = selectedAnnotationContext.selectedAnnotaton;
        this.selectedAnnotationCopy = selectedAnnotationContext.selectedAnnotaton.clone();

        if (this.selectedAnnotationCopy && this.selectedAnnotation) {
          this.selectedAnnotationCopy.blockIdentifier = this.selectedAnnotation.blockIdentifier;
          this.manufacturer = selectedAnnotationContext.presentationDataContext.contentLabel;
          document.body.style.cursor = 'pointer';
          if (this.selectedAnnotation instanceof Fovia.PointGraphicAnnotation) {
            if (this.selectedAnnotation.graphicLayer === ROI_POINT_ANNOTATION_LAYER) {
              highlightChanged = this.roiPointEditProcessor.processSelection(this.selectedAnnotation);
            } else {
              highlightChanged = this.pointAnnotationEditProcessor.processSelection(this.selectedAnnotation);
            }
          } else if (this.selectedAnnotation instanceof Fovia.PolylineGraphicAnnotation) {
            if (this.selectedAnnotation.graphicLayer === ARROW_ANNOTATION_LAYER) {
              highlightChanged = this.arrowAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            } else if (this.selectedAnnotation.graphicLayer === COBB_ANGLE_ANNOTATION_LAYER) {
              highlightChanged = this.cobbAngleAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            } else if (this.selectedAnnotation.graphicLayer === POLYGON_ANNOTATION_LAYER) {
              highlightChanged = this.polygonAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            } else if (this.selectedAnnotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER) {
              highlightChanged = this.roiPolygonEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            } else {
              highlightChanged = this.lineAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            }
          } else if (this.selectedAnnotation instanceof Fovia.AngleGraphicAnnotation) {
            highlightChanged = this.angleAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
          } else if (this.selectedAnnotation instanceof Fovia.CircleGraphicAnnotation) {
            highlightChanged = this.circleAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
          } else if (this.selectedAnnotation instanceof Fovia.EllipseGraphicAnnotation) {
            if (this.selectedAnnotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) {
              highlightChanged = this.roiEllipseEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            } else {
              // check isROIAnnotation()? for GSPS round trip?
              highlightChanged = this.ellipseAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
            }
          } else if (this.selectedAnnotation instanceof Fovia.TextGraphicAnnotation) {
            highlightChanged = highlightChanged = this.textAnnotationEditProcessor.processSelection(this.selectedAnnotation, currentPoint);
          }
        } else {
          this.state = Fovia.Util.GSPSSelectionMode.REJECT;
        }
      } else {
        this.state = Fovia.Util.GSPSSelectionMode.REJECT;
      }
    }

    return highlightChanged;
  }

  /**
   * @description called when user release the key
   * @param event captured keyboard event's instance
   * @returns true will be returned in success case, or else false will be returned
   */
  public press(event: KeyboardEvent): boolean {
    event.preventDefault();
    return true;
  }

  /**
   * @description Handle key up events.
   * Delete key to delete the selected annotation
   * @param event captured keyboard event's instance
   * @returns true will be returned in success case, or else false will be returned
   */
  public keyUp(event: KeyboardEvent): boolean {
    if (this.is2D && (event.key === 'Delete' || event.key === 'Backspace')) {
      this.deleteAnnotation(this.sopInstanceUid, this.frameNumber);
    }

    return false;
  }

  /**
   * @description Reset all the edit adapters to initial state
   */
  public reset(): void {
    this.pointAnnotationEditProcessor.reset();
    this.lineAnnotationEditProcessor.reset();
    this.arrowAnnotationEditProcessor.reset();
    this.angleAnnotationEditProcessor.reset();
    this.cobbAngleAnnotationEditProcessor.reset();
    this.circleAnnotationEditProcessor.reset();
    this.ellipseAnnotationEditProcessor.reset();
    this.polygonAnnotationEditProcessor.reset();
    this.roiEllipseEditProcessor.reset();
    this.roiPointEditProcessor.reset();
    this.roiPolygonEditProcessor.reset();
    this.textAnnotationEditProcessor.reset();
    this.selectedAnnotation = null;
    this.isMeasuring = false;
  }

  /**
   * @description called when the user is moving the wheeel of the mouse
   * @param event captured mouse event's instance
   * @param renderParams render parameters that to be applied
   * @returns true will be returned in success case, or else false will be returned
   */
  public async wheel(event: MouseEvent, renderParams: Fovia.RenderParams3D): Promise<boolean> {
    return true;
  }

  /**
   * @description called after an image is returned from the server; useful during navigation when you need to know when the rendering is complete
   * @param htmlViewport Specifies view port instance
   * @param renderParams render parameters that to be applied
   */
  public postRender(htmlViewport: any, renderParams: any): void {
  }

  /**
   * @description Get the selected annotation for edit purpose
   * @returns Returns the selected graphic annotation
   */
  public getSelectedAnnotation(): Fovia.GraphicAnnotation {
    return <Fovia.GraphicAnnotation>this.selectedAnnotation;
  }

  public deleteAnnotation(sopInstanceUid: any, frameNumber: any): boolean {
    if (this.is2D) {
      if (this.selectedAnnotation != null) { // handle delete
        if (this.selectedAnnotation instanceof Fovia.PointGraphicAnnotation) {
          if (this.selectedAnnotation.graphicLayer === ROI_POINT_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.point, sopInstanceUid, frameNumber);
          } else {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.point, sopInstanceUid, frameNumber);
          }
        } else if (this.selectedAnnotation instanceof Fovia.PolylineGraphicAnnotation) {
          if (this.selectedAnnotation.graphicLayer === ARROW_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.polyline, sopInstanceUid, frameNumber);
          } else if (this.selectedAnnotation.graphicLayer === COBB_ANGLE_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.polyline, sopInstanceUid, frameNumber);
          } else if (this.selectedAnnotation.graphicLayer === POLYGON_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.polyline, sopInstanceUid, frameNumber);
          } else if (this.selectedAnnotation.graphicLayer === ROI_POLYGON_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.polyline, sopInstanceUid, frameNumber);
          } else {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.polyline, sopInstanceUid, frameNumber);
          }
        } else if (this.selectedAnnotation instanceof Fovia.AngleGraphicAnnotation) {
          GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.angle, sopInstanceUid, frameNumber);
        } else if (this.selectedAnnotation instanceof Fovia.CircleGraphicAnnotation) {
          GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.circle, sopInstanceUid, frameNumber);
        } else if (this.selectedAnnotation instanceof Fovia.EllipseGraphicAnnotation) {
          if (this.selectedAnnotation.graphicLayer === ROI_ELLIPSE_ANNOTATION_LAYER) {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.ellipse, sopInstanceUid, frameNumber);
          } else {
            GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.ellipse, sopInstanceUid, frameNumber);
          }
        } else if (this.selectedAnnotation instanceof Fovia.TextGraphicAnnotation) {
          GSPSUtils.getInstance().deleteAnnotation(this.renderEngine, Fovia.GraphicType.text, sopInstanceUid, frameNumber);
        }
      }

      this.viewport.repaint();
      return true;
    }

    return false;
  }

  // Delete based on blockIdentifier
  public deleteAnnotations(data: any[]): void {
    // data.forEach((datum) => {
    //   datum.annotations.forEach((annotation: { blockIdentifier: any; }) => {
    //     if (annotation instanceof Fovia.PointGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.point, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     } else if (annotation instanceof Fovia.PolylineGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.polyline, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     } else if (annotation instanceof ArrowGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.polyline, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);    // TODO need Fovia to add to the enum
    //     } else if (annotation instanceof Fovia.AngleGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.angle, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     } else if (annotation instanceof CobbAngleGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.angle, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);       // TODO need Fovia to add to the enum
    //     } else if (annotation instanceof Fovia.CircleGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.circle, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     } else if (annotation instanceof Fovia.EllipseGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.ellipse, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     } else if (annotation instanceof Fovia.TextGraphicAnnotation) {
    //       this.renderEngine.deleteAnnotaionAllSlice(Fovia.GraphicType.text, datum.sopId, datum.frameNumber, true, annotation.blockIdentifier);
    //     }
    //   });
    // });
    // this.viewport.repaint();
  }

  public isROIAnnotation(): boolean {
    return !!(this.manufacturer === 'Synthesis Health' && this.selectedAnnotation && this.selectedAnnotation.textObjects.length > 0);
  }

  public setSelectedAnnotation(annotation: Fovia.GraphicAnnotation): void {
    this.selectedAnnotation = annotation;
  }

  protected canEditAnnotation(annotation: Fovia.GraphicAnnotation): boolean {
    return isSynthAnnotationLayer(annotation.graphicLayer);
  }
}
