import Fovia from 'foviaapi';
import { LineMeasurementAdaptor } from './line-measurement-adaptor';

describe('LineMeasurementAdaptor', () => {
  it('should create an instance', () => {
    expect(new LineMeasurementAdaptor(new Fovia.UI.HTMLViewport2D('', 1, 1), null, true)).toBeTruthy();
  });
});
