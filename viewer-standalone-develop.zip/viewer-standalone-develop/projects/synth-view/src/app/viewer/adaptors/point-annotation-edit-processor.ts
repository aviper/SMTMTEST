import Fovia from 'foviaapi';
import { BaseAnnotationEditProcessor } from './base-anotation-edit-processor';
import { GSPSUtils } from '@server-api';
import { AdaptorsService } from '../services';

export class PointAnnotationEditProcessor extends BaseAnnotationEditProcessor {
  // Selected annotations to edit
  protected selectedAnnotation: Fovia.PointGraphicAnnotation | null = null;

  /**
   * @description Constructs a new object. This constructor should only be called internal to the API.
   * @param viewport Specifies the view port instance
   * @returns This is a synchronous method that returns the newly created instance <a href="fovia.ui.pointAnnotationEditProcessor.html"> <i>PointAnnotationEditProcessor</i> </a>
   */
  constructor(viewport: any,
              adaptorsService: AdaptorsService) {
    super(viewport, adaptorsService);
  }

  /**
   * @description Reset the Point annotation to null
   */
  public reset(): void {
    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setPointHighlight(false);
    }
  }

  /**
   * @description Set the point annotation to edit
   * @param selectedAnnotation Specifies reference to Point annotation to edit
   */
  public processSelection(selectedAnnotation: Fovia.PointGraphicAnnotation): boolean {
    this.selectedAnnotation = selectedAnnotation;
    const wasHighlighted = this.selectedAnnotation.isPointHighlighted();

    if (this.selectedAnnotation != null) {
      this.selectedAnnotation.setPointHighlight(true);
    }

    return wasHighlighted !== this.selectedAnnotation.isPointHighlighted();
  }

  /**
   * @description Move the point annotation to given point
   * @param currentPoint Specifies the point where to move the point annotation
   */
  public moveAnnotation(currentPoint: Fovia.Util.Point): boolean {

    if (this.selectedAnnotation == null) {
      return false;
    }

    const renderPixel = this.renderEngine.dicomImagePixelToRenderImagePixelWithDiff(new Fovia.Util.Point(currentPoint));
    const displayArea: Fovia.Util.Rect2D = this.renderEngine.getDisplayArea();
    if (!displayArea.contains(renderPixel.x, renderPixel.y)) {
      return false;
    }

    this.updateAnnotationText(this.selectedAnnotation, currentPoint);
    this.selectedAnnotation.setPointHighlight(true);

    GSPSUtils.getInstance().annotationModified = true;
    return true;
  }

  protected updateAnnotationText(selectedAnnotation: Fovia.PointGraphicAnnotation, currentPoint: Fovia.Util.Point): void {
    selectedAnnotation.setPoint(currentPoint, this.renderEngine.getDicomCharSet());
  }
}
