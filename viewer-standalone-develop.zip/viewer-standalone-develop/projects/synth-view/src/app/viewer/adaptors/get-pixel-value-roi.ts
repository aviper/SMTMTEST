import Fovia from 'foviaapi';
import { getGraphicAnnotationPoints } from './adaptor-helpers';
import { SlopeIntercept } from '../models';
import { IPoint, ROIBase } from './roibase';
import { AdaptorsService } from '../services';
import { makeImageKeyFromImageTags, getPendingRenderParams2D  } from '@server-api';

interface IGetPointROIRequest {
  functionID: string;
  imageNum: number;
  dicomPoint: IPoint;
}

interface IPixelValueResponse {
  PixelValue: number;
  Result: string;
}

// ROI for Point
export class GetPixelValueROI extends ROIBase {
  private countP: number;
  private getROIprocessingOp: boolean;

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, adaptorService: AdaptorsService) {
    super(viewportId, viewport, adaptorService);
    this.countP = 0;
    this.getROIprocessingOp = false;
  }

  public async updateROITextObject(selectedAnnotation: Fovia.GraphicAnnotation): Promise<void> {

    const dicomPoints = getGraphicAnnotationPoints(selectedAnnotation);

    if (!this.validate(dicomPoints)) {
      return;
    }
    // contents of viewport may have changed so always get slope/intercept to match
    // the currently displayed image
    const si: SlopeIntercept = this.getSlopeIntercept();
    this.getROI(dicomPoints[0], si).then((roiText: string) => {

      // console.log(`GetPixelValueROI:getROI for x=${dicomPoints[0].x} y=${dicomPoints[0].y} returned ${roiText}`);

      const dicomCharSet = this.renderEngine.getDicomCharSet();
      if (dicomCharSet) {
        roiText = Fovia.Util.convertFromHexStr(roiText, dicomCharSet);
      }
      const label = btoa(roiText);
      selectedAnnotation.textObjects[0].unformattedTextValue = label;
      selectedAnnotation.setMeasurementLabel(label);
      selectedAnnotation.setShowLabelFlag(true);
    });
  }

  public async getPixelValueByPoint(point: Fovia.Util.Point): Promise<string | null> {
    return new Promise(async (resolve, reject) => {

      if (!this.validate([point])) {
        resolve(null);
        return;
      }

      const si: SlopeIntercept = this.getSlopeIntercept();
      this.getROI(point, si).then((roiText: string) => {
        resolve(roiText);
      }).catch(error => {
        reject(error);
      });
    });
  }

  private async getROI(dicomPoint: Fovia.Util.Point, si: SlopeIntercept): Promise<string> {
    return new Promise((resolve, reject) => {
      this.getROIprocessingOp = true;
      const imageNum = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D).imageNumber;
      const jsonRequest = this.getJson(imageNum, dicomPoint);

      this.getPixelValue2D(jsonRequest).then((result: IPixelValueResponse) => {
        // console.log(`getPixelValue2D jsonResponse PixelValue: ${JSON.stringify(result)} ${result.PixelValue} Result: ${result.Result}`);

        // Use Rescale Slope/Intercept Convert these pixel values to display units eg. HU/SUV etc.
        const pixelValue = si.getModalityPixelValue(result.PixelValue);
        let roiInfo = si.units === '' ? `[${pixelValue.toFixed(0)}]` : `[${si.units} ${pixelValue.toFixed(0)}]`;

        let suvScaleFactor = -1;
        if (this.suvInfo !== null) {
          suvScaleFactor = this.determineSuvScaleFactor();
          if (suvScaleFactor > 0) {
            const suvValue = pixelValue * suvScaleFactor;
            roiInfo = `[SUV ${suvValue.toFixed(2)}]`;
          }
        }

        // console.log(`getROI returning ${roiInfo}`);
        this.getROIprocessingOp = false;
        resolve(roiInfo);
      })
        .catch((errMsg) => {
          this.getROIprocessingOp = false;
          console.error('Error in getPixelValue2D: ');
          Fovia.Logger.warn('Error in getPixelValue2D: ' + errMsg);
          reject(errMsg);
        });
    });
  }

  private async getPixelValue2D(jsonRequest: IGetPointROIRequest): Promise<IPixelValueResponse> {
    this.countP++;
    try {
      const { imageNum, dicomPoint } = jsonRequest;
      const imageTags = this.sdc.imageTags[imageNum];

      const cachedImage = await this.getCachedImage(imageNum);

      if (!cachedImage?.PixelData) {
        return { PixelValue: 0, Result: 'CacheMiss' };
      }
      try {
        return this.extractPixelValue(cachedImage, imageTags, dicomPoint);
      } catch (err: any) {
        if (String(err).includes('out of image bounds')) {
          return { PixelValue: 0, Result: 'OutOfBounds' };
        }
        return { PixelValue: 0, Result: 'PixelValueError' };
      }
    }
    catch (err) {
      Fovia.Logger.warn('GetPixelValueROI: error during cache lookup. ' + String(err));
      return { PixelValue: 0, Result: 'Error' };
    }
  }

  private extractPixelValue( imageData: Fovia.ImageData, imageTags: any, dicomPoint: IPoint): IPixelValueResponse {
    const cols = imageTags.cols ?? 0;
    const rows = imageTags.rows ?? 0;
    const x = Math.round(dicomPoint.x);
    const y = Math.round(dicomPoint.y);

    if (x < 0 || y < 0 || x >= cols || y >= rows) {
      return { PixelValue: 0, Result: 'OK' };
    }
    const index = y * cols + x;
    const pixelValue = (imageData.PixelData as any)[index];
    return { PixelValue: pixelValue, Result: 'OK' };
  }
  private validate(points: Fovia.Util.Point[]): boolean {
    if (points.length === 0) {
      console.error(`GetPixelValueROI:validate no points defined.`);
      return false;
    }

    if (this.getROIprocessingOp) {
      console.warn(`GetPixelValueROI:validate is busy with another request.`);
      return false;
    }
    return true;
  }

  private getJson(imageNumber: number, point: Fovia.Util.Point): IGetPointROIRequest {
    const pt: IPoint = {
      x: point.x,
      y: point.y
    };
    return { functionID: 'PixelValue', imageNum: imageNumber, dicomPoint: pt };
  }
}
