
import Fovia from 'foviaapi';

import { ROI_POLYGON_ANNOTATION_LAYER, SHOW_MEASUREMENT } from './adaptor-constants';
import { PolygonAnnotationAdaptor } from './polygon-annotation-adaptor';
import { GetPolygonROI } from './get-polygon-roi';
import { convertToRenderPixel } from '../utils';
import { AdaptorsService } from '../services';
import { getPendingRenderParams2D } from '@server-api';
export class ROIPolygonAdaptor extends PolygonAnnotationAdaptor {

  private polygonROIRequestor: GetPolygonROI;

  constructor(viewportId: string, viewport: Fovia.UI.HTMLViewport, volumeDataContext: Fovia.VolumeDataContext | null, adaptorService: AdaptorsService) {
    super(viewport, volumeDataContext, adaptorService, SHOW_MEASUREMENT);
    this.supportsGenericDicomGraphicType = false;
    this.graphicLayer = ROI_POLYGON_ANNOTATION_LAYER;
    this.polygonROIRequestor = new GetPolygonROI(viewportId, viewport, adaptorService);
  }

  /**
   * @description Update any measurements annotations for the given annotation
   * @param graphicAnnotation Specifies the particular annotation
   */
  protected override updateAnnotationText(graphicAnnotation: Fovia.PolylineGraphicAnnotation): void {

    if (this.showMeasurement) {
      const renderParams = getPendingRenderParams2D(this.viewport as Fovia.UI.HTMLViewport2D);
      if (renderParams == null || !this.renderEngine.isPresentationDataAvailable()) {
        return;
      }
      const currentImageData = this.renderEngine.getSeriesDataContext().imageTags[renderParams.imageNumber];
      this.updateFromImageTags(currentImageData);
      this.polygonROIRequestor.updateROITextObject(graphicAnnotation, this.pixelSpacing, this.getSynthSettings()).then();
    }
  }
}
