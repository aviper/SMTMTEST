import { DestroyRef, Directive, ElementRef, EventEmitter, HostListener, Inject, OnInit, Output } from '@angular/core';
import { DOCUMENT } from '@angular/common';

import { EVENT_INFO, UserInputEvent } from '../models';
import { BehaviorSubject, debounceTime } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

export const enum MOUSE_BUTTONS {
  eNone = 0,        // no button
  eLeft = 1,        // usually left button
  eRight = 2,       // usually right button
  eLeftRight = 3,   // left & right buttons
  eMiddle = 4,      // mouse wheel or middle button
  eMiddleLeft = 5,  // middle and left buttons
  eMiddleRight = 6, // middle and right buttons
  eBack = 8,        // browser back button
  eForward = 16     // browser forward button
}

// This type is accessible from NodeJS.Timeout, but I get errors that the compiler can't find
// the `NodeJS` namespace, so this was easier.
type Timeout = ReturnType<typeof setTimeout>;

type KeyState = {
  finished: true;
} | {
  finished: false;
  timeout: Timeout;
};

/*
 This directive can be used to decorate ANY element, in order to handle input events related to that element.

 This directive is intended as a very general mechanism to intercept user input events that occur for the element that it decorates so that
 the desired behavior can be invoked for any particular user input related to that element. The behavior is provided by the associated
 dispatcher.

 It is not intended to capture document or window related events.

 Note: click and dblclick are difficult to distinguish from mouse moves at this level, since
 mousedown + mouseup are emitted prior to a click being emitted (as an example). It is up to the
 handler to provide the desired behavior and to stop propagation when appropriate.

*/
@Directive({
  standalone: false,
  selector: '[appInput]'
})
export class InputDirective implements OnInit {
  readonly MOUSE_MOVE_TIME_DELTA_MS = 200;
  readonly MOUSE_DRAG_TIME_DELTA_MS = 15;
  readonly BUTTON_HOLD_TIMEOUT_MS: number = 350;
  readonly KEY_HOLD_TIMOUT_MS = 1000;
  readonly NO_MOUSE_MOVE_TIME_MS = 250;
  readonly holdableKeys = ['S', 's'];
  readonly ignoreKeys = ['Control', 'Alt', 'Shift'];
  private lastMouseMoveTime = new Date().getTime();
  private lastIgnoreKeyUp = new Date().getTime();
  private timerRightButtonDownId: Timeout | null = null;
  private timerLeftButtonDownId: Timeout | null = null;
  private timerKeyDownMap: Record<string, KeyState> = {};
  private lastDownButtons: MOUSE_BUTTONS = MOUSE_BUTTONS.eNone;
  private ignoreNextKeyUp = false;
  readonly MOUSE_NO_MOVE_DELTA = 2;
  readonly MOUSE_HOLD_MOVE_DELTA = 5;
  private mouseDownX = 0;
  private mouseDownY = 0;
  private leftButtonHoldActive = false;
  private mouseMove$: BehaviorSubject<MouseEvent | null> = new BehaviorSubject<MouseEvent | null>(null);

  public constructor(
    @Inject(DOCUMENT) private document: Document,
    private elementRef: ElementRef,
    private destroyRef: DestroyRef) {}

  public ngOnInit(): void {
    this.mouseMove$
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        debounceTime(this.NO_MOUSE_MOVE_TIME_MS))
      .subscribe(mouseEvent => {
        this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseMoveStopped, this.elementRef, this.document, mouseEvent, null, null));
      });
  }

  // Wheel Events --------
  @HostListener('wheel', ['$event'])
  private onMouseWheel(event: WheelEvent): void {
    // No longer holding the right button down w/o moving.
    this.clearButtonHoldTimeouts();
    // Only  send wheel events when the wheel is turned. Not when the wheel is pushed left or right.
    if (event.deltaY !== 0) {
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eWheel, this.elementRef, this.document, null, null, event));
    }
  }
  // Mouse Events --------
  @HostListener('click', ['$event'])
  private onClick(event: MouseEvent): void {
    this.clearButtonHoldTimeouts();
    // Click event only happens for the "primary" button, which is generally the left button.
    // Don't emit if the mouse has moved more than just a twitch.
    if (Math.abs(this.mouseDownX - event.clientX) < this.MOUSE_NO_MOVE_DELTA
        && Math.abs(this.mouseDownY - event.clientY) < this.MOUSE_NO_MOVE_DELTA) {
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eClick, this.elementRef, this.document, event, null, null));
    }
  }

  @HostListener('auxclick', ['$event'])
  private onAuxClick(event: MouseEvent): void {
    this.clearButtonHoldTimeouts();
    // auxClick tool doesn't tell you which button was clicked so we take the button info from the mouseDown event.
    // Currently we only deal with the middle button downstream, so only emit for the middle button.
    // Also don't emit if the mouse has moved more than just a twitch.

    if (this.lastDownButtons === MOUSE_BUTTONS.eRight) {
      const inputEvent = new UserInputEvent(EVENT_INFO.eContextMenu, this.elementRef, this.document, event, null, null);
      // Now we allow dragging with the right mouse button, so let's not take every right mouse button up
      // as a context menu action.
      if (Math.abs(this.mouseDownX - event.clientX) === 0 && Math.abs(this.mouseDownY - event.clientY) === 0) {
        this.userInput.emit(inputEvent);
      }
      return;
    }

    if (Math.abs(this.mouseDownX - event.clientX) < this.MOUSE_NO_MOVE_DELTA
        && Math.abs(this.mouseDownY - event.clientY) < this.MOUSE_NO_MOVE_DELTA
        && this.lastDownButtons === MOUSE_BUTTONS.eMiddle) {
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eMiddleClick, this.elementRef, this.document, event, null, null));
    }
  }

  @HostListener('dblclick', ['$event'])
  private onDoubleClick(event: MouseEvent): void {
    // No longer holding the right button down w/o moving.
    this.clearButtonHoldTimeouts();

    this.userInput.emit(new UserInputEvent(EVENT_INFO.eDoubleClick, this.elementRef, this.document, event, null, null));
  }
  @HostListener('mousedown', ['$event'])
  private onMouseDown(event: MouseEvent): void {
    this.lastDownButtons = event.buttons;
    this.mouseDownX = event.clientX;
    this.mouseDownY = event.clientY;
    this.clearButtonHoldTimeouts();
    // filter out buttons we don't need to handle ... yet, when we do, we'll need to move this filtering
    // down to the tool event handler
    if (event.buttons !== MOUSE_BUTTONS.eLeft &&
        event.buttons !== MOUSE_BUTTONS.eLeftRight &&
        event.buttons !== MOUSE_BUTTONS.eMiddle) {
      // We treat the act of holding the right button down for 100 milliseconds as a special case.
      if (event.buttons === MOUSE_BUTTONS.eRight) {
        const inputEvent = new UserInputEvent(EVENT_INFO.eRightDownHold, this.elementRef, this.document, event, null, null);
        this.timerRightButtonDownId = setTimeout(() => { this.onRightButtonHold(inputEvent); }, this.BUTTON_HOLD_TIMEOUT_MS);
      }
      event.preventDefault();
    } // else {
      if (event.buttons === MOUSE_BUTTONS.eLeft) {
        const inputEvent = new UserInputEvent(EVENT_INFO.eLeftDownHold, this.elementRef, this.document, event, null, null);
        this.timerLeftButtonDownId = setTimeout(() => { this.onLeftButtonHold(inputEvent); }, this.BUTTON_HOLD_TIMEOUT_MS * 2);
      }
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseDown, this.elementRef, this.document, event, null, null));
    // }
  }

  @HostListener('mouseenter', ['$event'])
  private onMouseEnter(event: MouseEvent): void {
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseEnter, this.elementRef, this.document, event, null, null));
  }
  @HostListener('mouseleave', ['$event'])
  private onMouseLeave(event: MouseEvent): void {
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseLeave, this.elementRef, this.document, event, null, null));
  }
  @HostListener('mousemove', ['$event'])
  private onMouseMove(event: MouseEvent): void {
    this.clearButtonHoldTimeouts();

    // If were dragging with left+right but one button or the other has been released, pretend as if both buttons
    // have been released. This lets the move through but avoids continuing use of left+right.
    if (this.lastDownButtons === MOUSE_BUTTONS.eLeftRight && event.buttons !== MOUSE_BUTTONS.eLeftRight) {
      const fakeEvent: MouseEvent = new MouseEvent('mousemove', {
        screenX: event.screenX,
        screenY: event.screenY,
        clientX: event.clientX,
        clientY: event.clientY,
        ctrlKey: event.ctrlKey,
        shiftKey: event.shiftKey,
        altKey: event.altKey,
        metaKey: event.metaKey,
        button: event.button,
        buttons: MOUSE_BUTTONS.eNone
      });
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseMove, this.elementRef, this.document, fakeEvent, null, null));
      this.mouseMove$.next(event);
    } else {
      const now = new Date().getTime();
      const delay = event.buttons === MOUSE_BUTTONS.eNone ? this.MOUSE_MOVE_TIME_DELTA_MS : this.MOUSE_DRAG_TIME_DELTA_MS;
      // Don't blast out too many mouse messages -- we just don't need them
      if (now - this.lastMouseMoveTime < delay) {
        return;
      }
      this.lastMouseMoveTime = now;
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseMove, this.elementRef, this.document, event, null, null));
      this.mouseMove$.next(event);
    }
  }
  @HostListener('mouseout', ['$event'])
  private onMouseOut(event: MouseEvent): void {
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseOut, this.elementRef, this.document, event, null, null));
  }
  @HostListener('mouseover', ['$event'])
  private onMouseover(event: MouseEvent): void {
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseOver, this.elementRef, this.document, event, null, null));
  }
  @HostListener('mouseup', ['$event'])
  private onMouseUp(event: MouseEvent): void {
    // No longer holding the right button down w/o moving.
    this.clearButtonHoldTimeouts();

    // With button chording, ensure both buttons are released before we pass it along
    if (event.buttons !== MOUSE_BUTTONS.eNone) {
      if (this.lastDownButtons === MOUSE_BUTTONS.eLeftRight) {
        const inputEvent = new UserInputEvent(EVENT_INFO.eMultiFirstRelease, this.elementRef, this.document, event, null, null);
        this.userInput.emit(inputEvent);
      }
      event.preventDefault();
   } else {
      if (this.leftButtonHoldActive) {
        this.leftButtonHoldActive = false;
        this.userInput.emit(new UserInputEvent(EVENT_INFO.eLeftDownRelease, this.elementRef, this.document, event, null, null));
      } else  {
        this.userInput.emit(new UserInputEvent(EVENT_INFO.eMouseUp, this.elementRef, this.document, event, null, null));
      }
    }
  }

  // Keyboard events -- only arrive at the document, only "active" components should "listen"
  @HostListener('document:keydown', ['$event'])
  private onKeyDown(event: KeyboardEvent): void {
    this.clearButtonHoldTimeouts();

    // We don't emit when Ctrl, Alt, or Shift are down with no other key.
    // There aren't any keyboard shortcuts for just Ctrl, Shift, or Alt.
    if (this.ignoreKeys.includes(event.key)) {
      return;
    }

    if (this.holdableKeys.includes(event.key)) {
      const holdKey = event.key;
      const keyStatus = this.timerKeyDownMap[holdKey];
      if (!keyStatus) {
        const keyHoldEvent = new UserInputEvent(EVENT_INFO.eKeyHold, this.elementRef, this.document, null, event, null);
        this.timerKeyDownMap[holdKey] = {
          finished: false,
          timeout: setTimeout(() => {
            this.onKeyHold(keyHoldEvent);
            // Prevents a new hold event from triggering until key-up clears the entry from the map
            this.timerKeyDownMap[holdKey] = { finished: true };
          }, this.KEY_HOLD_TIMOUT_MS),
        };
      }
    }
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eKeyDown, this.elementRef, this.document, null, event, null));
  }
  @HostListener('document:keypress', ['$event'])
  private onKeyPress(event: KeyboardEvent): void {
    this.clearButtonHoldTimeouts();
    this.clearKeyHoldTimeout(event.key);
    this.userInput.emit(new UserInputEvent(EVENT_INFO.eKeyPress, this.elementRef, this.document, null, event, null));
  }
  @HostListener('document:keyup', ['$event'])
  private onKeyUp(event: KeyboardEvent): void {
    this.clearButtonHoldTimeouts();
    // We don't emit when Ctrl, Alt, or Shift are released.
    if (this.ignoreKeys.includes(event.key)) {
      this.lastIgnoreKeyUp = new Date().getTime();
      this.ignoreNextKeyUp = true;
      return;
    }

    // We don't emit when Ctrl, Alt, or Shift are down.
    // This is because shortcuts that include those keys operate on key-down.
    if (event.ctrlKey || event.altKey || event.shiftKey) {
      return;
    }

    // We also skip the next key-up after one of the ignored keys is released, unless one of those keys is still down
    // or it's been half a second since we decided we should skip the next key-up.
    // This is so we don't, for example, emit both Ctrl+R and R, but also don't accidentally throw away good stuff.
    const now = new Date().getTime();
    if (this.ignoreNextKeyUp && now - this.lastIgnoreKeyUp < 500) {
      this.ignoreNextKeyUp = false;
      return;
    }

    // We only emit a Key-Up event if we didn't already emit a Key-Hold. It's one or the other.
    if (!this.holdableKeys.includes(event.key) || this.clearKeyHoldTimeout(event.key)) {
      this.userInput.emit(new UserInputEvent(EVENT_INFO.eKeyUp, this.elementRef, this.document, null, event, null));
    }
  }

  private onLeftButtonHold(inputEvent: UserInputEvent): void {
    // A user has held the left button down with no other activity for 350 milliseconds.
    this.leftButtonHoldActive = true;
    this.userInput.emit(inputEvent);
  }

  private onRightButtonHold(inputEvent: UserInputEvent): void {
    // A user has held the right button down with no other activity for 350 milliseconds.
    this.userInput.emit(inputEvent);
  }

  private onKeyHold(inputEvent: UserInputEvent): void {
    this.userInput.emit(inputEvent);
  }

  private clearButtonHoldTimeouts(): void {
    this.clearLeftButtonHoldTimeout();
    this.clearRightButtonHoldTimeout();
  }

  private clearLeftButtonHoldTimeout(): void {
    if (this.timerLeftButtonDownId) {
      clearTimeout(this.timerLeftButtonDownId);
    }
  }

  private clearRightButtonHoldTimeout(): void {
    if (this.timerRightButtonDownId) {
      clearTimeout(this.timerRightButtonDownId);
    }
  }

  // Returns true if the timeout exists (meaning the hold never finished)
  // otherwise returns false. This differentiates a key-up that follows a
  // hold vs one that doesn't
  private clearKeyHoldTimeout(key: string): boolean {
    const keyState = this.timerKeyDownMap[key];

    if (keyState) {
      if (!keyState.finished) {
        clearTimeout(keyState.timeout);
      }
      delete this.timerKeyDownMap[key];
      return !keyState.finished;
    }
    return false;
  }

  @Output() public userInput: EventEmitter<UserInputEvent> = new EventEmitter<UserInputEvent>();
}
