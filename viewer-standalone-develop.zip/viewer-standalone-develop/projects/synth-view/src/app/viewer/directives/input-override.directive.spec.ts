import { InputOverrideDirective } from './input-override.directive';

describe('KeyboardDirective', () => {
  it('should create an instance', () => {

    const directive = new InputOverrideDirective();
    expect(directive).toBeTruthy();
  });
});
