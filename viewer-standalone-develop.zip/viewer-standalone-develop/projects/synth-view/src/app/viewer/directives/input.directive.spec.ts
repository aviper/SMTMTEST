import { InputDirective } from './input.directive';

describe('InputDirective', () => {
  it('should create an instance', () => {
    const directive = new InputDirective();
    expect(directive).toBeTruthy();
  });
});
