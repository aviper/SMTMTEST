import { Directive, HostListener, Input } from '@angular/core';

// Provide a general mechanism by which we can route keyboard input
// to a particular component, while it has focus

@Directive({
  standalone: false,
  selector: '[appInputOverride]'
})
export class InputOverrideDirective {
@Input() blockKeyboard = true;
@Input() blockMouseButton = true;

  public constructor() {
  }

  @HostListener('keydown', ['$event'])
  @HostListener('keypress', ['$event'])
  @HostListener('keyup', ['$event'])
  public onKeyEvent(event: KeyboardEvent): void {
    if (!this.blockKeyboard) {
      return;
    }
    // As long as the directive element has focus, keyboard events
    // are routed here. If we need to be less greedy/more selective about
    // the events we consume, we should consider using a regex expression
    // to determine which keyboard events are filtered for the caller.
    event.stopPropagation();
    this.handleKeyboardEvents(event);
  }
  protected handleKeyboardEvents(event: KeyboardEvent): void {
    // Override to handle the event
    console.info(`handleKeyboardEvents must be overridden by derived class`);
  }
  @HostListener('click', ['$event'])
  @HostListener('dblclick', ['$event'])
  @HostListener('mousedown', ['$event'])
  @HostListener('mouseup', ['$event'])
  public onMouseEvent(event: MouseEvent): void {
    if (!this.blockMouseButton) {
      return;
    }
    event.stopPropagation();
  }
  protected handleMouseEvents(event: KeyboardEvent): void {
    // Override to handle the event

  }

}
