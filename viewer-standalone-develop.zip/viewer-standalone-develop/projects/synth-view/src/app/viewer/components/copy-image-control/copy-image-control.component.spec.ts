import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyImageControlComponent } from './copy-image-control.component';

describe('CopyImageControlComponent', () => {
  let component: CopyImageControlComponent;
  let fixture: ComponentFixture<CopyImageControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CopyImageControlComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CopyImageControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
