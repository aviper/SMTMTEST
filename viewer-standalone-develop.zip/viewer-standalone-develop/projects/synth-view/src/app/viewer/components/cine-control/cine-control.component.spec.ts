import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CineControlComponent } from './cine-control.component';

describe('CineControlComponent', () => {
  let component: CineControlComponent;
  let fixture: ComponentFixture<CineControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CineControlComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CineControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
