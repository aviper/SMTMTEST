import { Injectable } from '@angular/core';
import { MammoPresentationService, PanelsContainerService, SeriesDisplayStoreService, ViewerSettingsService } from '../../services';
import { BehaviorSubject, filter, Observable, Subject, switchMap, takeUntil } from 'rxjs';
import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { SeriesDisplayStoreItem } from '../../stores';
import { BUTTON_SCOPE, MAMMO_VIEW_TYPE, MammoInfo, panelTypeIs2D } from '../../models';

class ToggleTomoButton implements IMiniBarButton {
  constructor(public buttonId: TOOL_TYPE,
    public isDisabled: boolean = false,
    public isSelected: boolean = false) { }
}

@Injectable()
export class ToggleTomoService {
  private tomoOnButton$$: BehaviorSubject<IMiniBarButton>;
  private tomoOffButton$$: BehaviorSubject<IMiniBarButton>;
  private showTomoOnButton$$: BehaviorSubject<boolean>;
  private showTomoOffButton$$: BehaviorSubject<boolean>;
  private unsubscribe$$ = new Subject<void>();
  private viewportId$$: BehaviorSubject<string>;
  private foviaHtmlViewport$: Observable<Fovia.UI.HTMLViewport | null>;
  private seriesDisplayStoreItem$: Observable<SeriesDisplayStoreItem | null>;
  private currentSeriesDisplayStoreItem: SeriesDisplayStoreItem | null = null;
  private previousToolSelection = TOOL_TYPE.eNone;

  constructor(public panelsContainerService: PanelsContainerService,
              private seriesDisplayStoreService: SeriesDisplayStoreService,
              private viewerSettingsService: ViewerSettingsService,
              private mammoPresentationService: MammoPresentationService) {
    this.tomoOnButton$$ = new BehaviorSubject<IMiniBarButton>(new ToggleTomoButton(TOOL_TYPE.eShowTomo));
    this.tomoOffButton$$ = new BehaviorSubject<IMiniBarButton>(new ToggleTomoButton(TOOL_TYPE.eHideTomo));
    this.showTomoOnButton$$ = new BehaviorSubject<boolean>(false);
    this.showTomoOffButton$$ = new BehaviorSubject<boolean>(false);
    this.viewportId$$ = new BehaviorSubject<string>('');

    this.seriesDisplayStoreItem$ = this.viewportId$$
      .pipe(
        filter(id => (id != null)),
        switchMap((viewportId: string | null) => {
          return (viewportId == null)
            ? new BehaviorSubject<SeriesDisplayStoreItem | null>(null)
            : this.seriesDisplayStoreService.getSeriesDisplayStoreItem$(viewportId);
        })
      );

    this.foviaHtmlViewport$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<Fovia.UI.HTMLViewport | null>(null)
            : storeItem.foviaHtmlViewport$;
        })
      );

    this.subscriptions();
  }

  public get tomoOnButton$(): Observable<IMiniBarButton> {
    return this.tomoOnButton$$.asObservable();
  }
  public get tomoOffButton$(): Observable<IMiniBarButton> {
    return this.tomoOffButton$$.asObservable();
  }

  public get showTomoOnButton$(): Observable<boolean> {
    return this.showTomoOnButton$$.asObservable();
  }
  public get showTomoOffButton$(): Observable<boolean> {
    return this.showTomoOffButton$$.asObservable();
  }

  public set viewportID(id: string) {
    this.viewportId$$.next(id);
    this.updateButtonScope(id);
  }
  public get viewportID(): string {
    return this.viewportId$$.value;
  }

  public wasClicked(): void {
    if (this.currentSeriesDisplayStoreItem && this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries) {

      if (this.mammoInfo) {
        const replacementSeries = this.mammoPresentationService.getStack(this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries.isPrimaryExam,
            this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries.parentExam.studyInstanceUID, this.getSwapImageType(this.mammoInfo.viewType));

        // Trigger the image swap.
        if (replacementSeries) {
          // Switching to tomo
          if (replacementSeries.currentImageRef.imageSet.sourceSeries?.isMultiframeImage(replacementSeries.currentImageRef.imageSet.firstImageIndex)) {
            this.previousToolSelection = this.viewerSettingsService.activeToolType;
          }
          this.viewerSettingsService.mammoTomoSwap = { viewportId: this.viewportId$$.value, series: replacementSeries, preCineTool: this.previousToolSelection };
        }
      }
    }
  }

  private get mammoInfo(): MammoInfo | undefined {
    if (this.currentSeriesDisplayStoreItem && this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries) {
      return this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries.getMammoInfo(this.currentSeriesDisplayStoreItem.virtualSeries.currentSopInstanceUID);
    }
    return undefined;
  }

  private getSwapImageType(imageType: MAMMO_VIEW_TYPE): MAMMO_VIEW_TYPE {
    switch (imageType) {
      case MAMMO_VIEW_TYPE.RCC_TOMO:
        return MAMMO_VIEW_TYPE.RCC;
      case MAMMO_VIEW_TYPE.LCC_TOMO:
        return MAMMO_VIEW_TYPE.LCC;
      case MAMMO_VIEW_TYPE.RMLO_TOMO:
        return MAMMO_VIEW_TYPE.RMLO;
      case MAMMO_VIEW_TYPE.LMLO_TOMO:
        return MAMMO_VIEW_TYPE.LMLO;
      case MAMMO_VIEW_TYPE.RCC:
        return MAMMO_VIEW_TYPE.RCC_TOMO;
      case MAMMO_VIEW_TYPE.LCC:
        return MAMMO_VIEW_TYPE.LCC_TOMO;
      case MAMMO_VIEW_TYPE.LMLO:
        return MAMMO_VIEW_TYPE.LMLO_TOMO;
      case MAMMO_VIEW_TYPE.RMLO:
        return MAMMO_VIEW_TYPE.RMLO_TOMO;
    }
    return MAMMO_VIEW_TYPE.UNKNOWN;
  }

  private subscriptions(): void {
    // Stay up-to-date on the current display store item
    this.seriesDisplayStoreItem$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (item: SeriesDisplayStoreItem | null) => {
        this.currentSeriesDisplayStoreItem = item;
        this.initialize();
      });

    this.foviaHtmlViewport$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: Fovia.UI.HTMLViewport | null) => {
        this.initialize();
      });

    this.viewerSettingsService.toggleTomoHotkey$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: string) => {
        if (this.viewportID === vp) {
          this.wasClicked();
        }
      });
  }

  private initialize(): void {
    if (!this.panelsContainerService.flickerActive) {
      const panelId = this.panelsContainerService.getCurrentPanelIdWhere(item => {
        return (item.viewportIdGrid.flat().findIndex(vpId => vpId === this.viewportID) !== -1);
      });
      const panelItem = this.panelsContainerService.getPanelStoreItem(panelId);
      if (panelItem) {
        const scope = panelTypeIs2D(panelItem.panelType) ? BUTTON_SCOPE.e2D : BUTTON_SCOPE.eNone;

        if (this.mammoPresentationService.isAvailable && this.mammoInfo) { // && !this.viewerSettingsService.showFlicker) {
          if (this.currentSeriesDisplayStoreItem != null &&
            this.currentSeriesDisplayStoreItem.virtualSeries &&
            this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries && scope === BUTTON_SCOPE.e2D) {

            const replacementSeries = this.mammoPresentationService.getStack(this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries.isPrimaryExam,
              this.currentSeriesDisplayStoreItem.virtualSeries.currentExamSeries.parentExam.studyInstanceUID, this.getSwapImageType(this.mammoInfo.viewType));
            const replacementAvailable = replacementSeries != null && replacementSeries.imageSets.length > 0;
            // Only enable a button if we have the swap image (i.e. we have the RCC tomo for the TCC).
            this.showTomoOnButton$$.next(replacementAvailable && !this.mammoInfo.tomosynthesis);
            this.showTomoOffButton$$.next(replacementAvailable && this.mammoInfo.tomosynthesis);
            return;
          }
        }
      }
    }

    // Only show one of the buttons for mammo images on the 2D panel.
    this.showTomoOnButton$$.next(false);
    this.showTomoOffButton$$.next(false);
  }

  private updateButtonScope(viewportId: string): void {
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public onDestroy(): void {
    this.unsubscribe();
  }
}
