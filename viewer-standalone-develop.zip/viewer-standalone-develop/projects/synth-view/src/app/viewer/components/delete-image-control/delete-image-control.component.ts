import { Component, effect, input, InputSignal, OnDestroy, signal, Signal} from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';

import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { CopyDeleteImageControlService } from '../../services';

class DeleteImageButton implements IMiniBarButton {
  public buttonId: TOOL_TYPE;
  public isDisabled: boolean;
  public isSelected: boolean;

  constructor() {
    this.buttonId = TOOL_TYPE.eDeleteKOImage;
    this.isDisabled = false;
    this.isSelected = false;
  }
}

@Component({
  standalone: false,
  selector: 'app-delete-image-control',
  templateUrl: './delete-image-control.component.html',
  styleUrl: './delete-image-control.component.scss',
  providers: [CopyDeleteImageControlService]
})
export class DeleteImageControlComponent implements OnDestroy {
  public readonly viewportId: InputSignal<string> = input<string>('');

  constructor(private copyDeleteImageControlService: CopyDeleteImageControlService) {
    effect(() => {
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.copyDeleteImageControlService.viewportId = vpId;
      }
    });
  }

  public deleteImageButton: Signal<DeleteImageButton> = signal<DeleteImageButton>(new DeleteImageButton());

  public showDeleteImageButton = toSignal<boolean>(this.copyDeleteImageControlService.showDeleteImageButton$);

  public onMouseUp(): void {
    this.copyDeleteImageControlService.removeImage();
  }

  public ngOnDestroy(): void {
    this.copyDeleteImageControlService.onDestroy();
  }
}
