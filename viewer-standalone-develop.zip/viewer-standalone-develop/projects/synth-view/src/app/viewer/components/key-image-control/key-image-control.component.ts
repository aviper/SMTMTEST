import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';

import { KeyImageControlService } from './key-image-control.service';
import { IMiniBarButton } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-key-image-control',
  templateUrl: './key-image-control.component.html',
  styleUrls: ['./key-image-control.component.scss'],
  providers: [KeyImageControlService]
})
export class KeyImageControlComponent implements OnDestroy {

  public readonly viewportId: InputSignal<string> = input<string>('');

  public constructor(private keyImageControlService: KeyImageControlService) {

    effect(() => {
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.keyImageControlService.viewportID = vpId;
      }
    });
  }

  public keyImageButton = toSignal<IMiniBarButton>(this.keyImageControlService.keyImageButton$);
  public showKeyImageButton = toSignal<boolean>(this.keyImageControlService.showKeyImageButton$);

  public onMouseUp(): void {
    this.keyImageControlService.wasClicked();
  }

  public ngOnDestroy(): void {
    this.keyImageControlService.onDestroy();
  }

}
