import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeImageSetControlComponent } from './change-image-set-control.component';

describe('ChangeImageSetControlComponent', () => {
  let component: ChangeImageSetControlComponent;
  let fixture: ComponentFixture<ChangeImageSetControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangeImageSetControlComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ChangeImageSetControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
