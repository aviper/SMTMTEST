import { Injectable } from '@angular/core';
import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { BehaviorSubject, filter, Observable, Subject, switchMap, takeUntil } from 'rxjs';
import { AdaptorsService, SeriesDisplayStoreService, ViewerSettingsService } from '../../services';
import Fovia from 'foviaapi';
import { SeriesDisplayStoreItem } from '../../stores';
import HTMLViewport = Fovia.UI.HTMLViewport;
import { debugSleep } from '../../utils';

class CineButton implements IMiniBarButton {
  public buttonId = TOOL_TYPE.eCineOneShot;
  public isDisabled = false;
  public isSelected = false;

  constructor() { }
}

@Injectable()
export class CineControlService {

  private seriesDisplayStoreItem$: Observable<SeriesDisplayStoreItem | null>;
  private foviaHtmlViewport$: Observable<HTMLViewport | null>;
  private cineButton$$: BehaviorSubject<IMiniBarButton>;
  private showCineButton$$: BehaviorSubject<boolean>;
  private unsubscribe$$ = new Subject<void>();
  private viewportId$$: BehaviorSubject<string>;
  private currentSeriesDisplayStoreItem: SeriesDisplayStoreItem | null = null;
  private previousToolSelection = TOOL_TYPE.eNone;
  private foviaHtmlViewport: HTMLViewport | null = null;

  public constructor( private viewerSettingsService: ViewerSettingsService,
                      private seriesDisplayStoreService: SeriesDisplayStoreService,
                      private adaptorService: AdaptorsService) {

    this.cineButton$$ = new BehaviorSubject<IMiniBarButton>(new CineButton());
    this.showCineButton$$ = new BehaviorSubject<boolean>(false);
    this.viewportId$$ = new BehaviorSubject<string>('');

    this.seriesDisplayStoreItem$ = this.viewportId$$
      .pipe(
        filter(id => (id != null)),
        switchMap((viewportId: string | null) => {
          return (viewportId == null)
            ? new BehaviorSubject<SeriesDisplayStoreItem | null>(null)
            : this.seriesDisplayStoreService.getSeriesDisplayStoreItem$(viewportId);
        })
      );

    this.foviaHtmlViewport$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<HTMLViewport | null>(null)
            : storeItem.foviaHtmlViewport$;
        })
      );

    this.subscriptions();
  }

  public get cineButton$(): Observable<IMiniBarButton> {
    return this.cineButton$$.asObservable();
  }

  public get showCineButton$(): Observable<boolean> {
    return this.showCineButton$$.asObservable();
  }

  public set viewportID(value: string) {
    this.viewportId$$.next(value);
  }

  public async onButtonClicked(event: MouseEvent): Promise<void> {
    // That's we only really have a toggle OFF and no toggle ON.
    this.viewerSettingsService.activeViewport = this.viewportId$$.value;
    if (this.viewerSettingsService.activeToolType !== TOOL_TYPE.eCine) {
      // Note that selecting the Cine tool will automatically start cine.
      this.viewerSettingsService.selectTool(TOOL_TYPE.eCine);
    } else if (this.adaptorService.cineActions.isCinePausedOnActiveViewport()) {
      this.adaptorService.cineActions.resumeCineOnActiveViewport();
    } else if (this.adaptorService.cineActions.isCineRunningOnActiveViewport()) {
      if (this.previousToolSelection !== TOOL_TYPE.eNone) {
        // Note that de-selecting the Cine tool will automatically stop cine.
        this.viewerSettingsService.selectTool(this.previousToolSelection);
      } else {
        this.adaptorService.cineActions.pauseCineOnActiveViewport();
      }
    }
  }

  private subscriptions(): void {
    // Stay up-to-date on the current display store item
    this.seriesDisplayStoreItem$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (item: SeriesDisplayStoreItem | null) => {
        this.currentSeriesDisplayStoreItem = item;
        this.initialize();
      });

    // Stay up-to-date on the current viewport
    this.foviaHtmlViewport$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: HTMLViewport | null) => {
        this.foviaHtmlViewport = vp;
      });

    this.viewerSettingsService.activeToolType$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((tt: TOOL_TYPE) => {
        if (tt !== TOOL_TYPE.eCine) {
          this.previousToolSelection = tt;
        }
      });
  }

  private initialize(): void {
    // Don't show the control button on blank, or 3D panels.
    if (this.currentSeriesDisplayStoreItem == null || this.currentSeriesDisplayStoreItem.is3DOrMPR) {
      this.showCineButton$$.next(false);
    } else {
      const series = this.currentSeriesDisplayStoreItem.series;
      this.showCineButton$$.next(series != null &&
          series.isMultiframeImage(this.currentSeriesDisplayStoreItem.virtualSeries.currentImageRef.imageIndex) &&
          this.currentSeriesDisplayStoreItem.is2D);
    }
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public onDestroy(): void {
    this.unsubscribe();
  }
}
