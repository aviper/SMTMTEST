import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrl: './slider.component.scss'
})
export class SliderComponent {
  private _value: number | null = 0;

  @Input() minValue = 0;
  @Input() maxValue = 100;
  @Input() step = 1;
  @Input() tooltip = '';
  @Output() valueChanged = new EventEmitter<number>();
  @Output() dragEndValue = new EventEmitter<number>();


  @Input()
  set value(value: number | null) {
    if (value !== null && value !== this._value) {
      this._value = value;
      this.valueChanged.emit(value);
    }
  }
  get value(): number | null {
    return this._value;
  }

  onDragEnd(value: number | null): void {
    if (value != null) {
      this.dragEndValue.emit(value);
    }
  }
}
