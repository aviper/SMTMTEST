import { TestBed } from '@angular/core/testing';

import { PresetColorPaletteService } from './preset-color-palette.service';

describe('PresetColorPaletteService', () => {
  let service: PresetColorPaletteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PresetColorPaletteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
