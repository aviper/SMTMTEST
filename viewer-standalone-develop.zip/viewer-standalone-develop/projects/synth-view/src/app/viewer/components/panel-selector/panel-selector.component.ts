import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import Fovia from 'foviaapi';

import { IPanelButton, PanelSelectorService } from '../../services';
import { TOOL_TYPE } from '../../tools';
import { PANEL_SET } from '../../models';

@Component({
  standalone: false,
  selector: 'app-panel-selector',
  templateUrl: './panel-selector.component.html',
  styleUrls: ['./panel-selector.component.scss'],
  providers: [PanelSelectorService]
})
export class PanelSelectorComponent implements OnDestroy {
  public readonly panelSet: InputSignal<PANEL_SET> = input<PANEL_SET>(PANEL_SET.eUnknown);

  public panelButtons = toSignal<IPanelButton[]>(this.panelSelectorService.currentPanelSet$);
  public previousPanelPage = toSignal<IPanelButton | null>(this.panelSelectorService.previousPanelPage$);
  public nextPanelPage = toSignal<IPanelButton | null>(this.panelSelectorService.nextPanelPage$);
  public pageSeriesLabel = toSignal<string | null>(this.panelSelectorService.seriesLabel$);
  public resetPanelButton = toSignal<IPanelButton | null>(this.panelSelectorService.resetPanelButton$);
  public hasPlaneDropdown = toSignal<boolean>(this.panelSelectorService.planeDropdown$);
  public currentPanelPlaneSelection = toSignal<Fovia.ViewType | null>(this.panelSelectorService.currentPanelPlaneSelection$);

  public constructor(private panelSelectorService: PanelSelectorService) {
    effect(() => {
      if ((this.panelSet() !== PANEL_SET.eUnknown)) {
        // console.log(`panelset ${PANEL_SET[this.panelSet]}`);
        this.panelSelectorService.setPanelsToControl(this.panelSet());
      }
    });
  }

  public onMouseUp(panelButton: IPanelButton): void {
    if (!panelButton.isDisabled) {
      switch (panelButton.buttonid) {
        case TOOL_TYPE.ePreviousPage:
          this.panelSelectorService.previousPanelPage();
          break;
        case TOOL_TYPE.eNextPage:
          this.panelSelectorService.nextPanelPage();
          break;
        case TOOL_TYPE.eReset:
          this.panelSelectorService.resetPanel();
          break;
        default:
          this.panelSelectorService.activatePanel(panelButton.buttonid);
      }
    }
  }

  public onPlaneChanging(value: Fovia.ViewType): void {
    this.panelSelectorService.currentPanelPlaneSelection = value;
    // console.log('plane changed value', value);
  }

  public ngOnDestroy(): void {
    this.panelSelectorService.onDestroy();
  }

}
