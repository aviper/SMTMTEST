import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyImageControlComponent } from './key-image-control.component';

describe('KeyImageControlComponent', () => {
  let component: KeyImageControlComponent;
  let fixture: ComponentFixture<KeyImageControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeyImageControlComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KeyImageControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
