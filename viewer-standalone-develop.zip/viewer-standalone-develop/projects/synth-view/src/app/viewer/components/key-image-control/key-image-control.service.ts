import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest, filter, map, Observable, Subject, switchMap, takeUntil } from 'rxjs';

import Fovia from 'foviaapi';
import HTMLViewport = Fovia.UI.HTMLViewport;
import RenderParams = Fovia.RenderParams;
import RenderParams2D = Fovia.RenderParams2D;

import {
  ExamService,
  ImageFrameSelection,
  PanelsContainerService,
  SeriesDisplayStoreService, UserInformationService,
  ViewerSettingsService
} from '../../services';

import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { is2DGSPSViewport, is2DRenderParams } from '../../utils';
import { panelTypeIs2D, VirtualSeries } from '../../models';
import { ModalPopupService, UserNotificationParams } from '../../modal-popup-dialogs';
import { PanelStoreItem, SeriesDisplayStoreItem } from '../../stores';
import { HTMLViewport2DGSPS, makeImageKey } from '@server-api';


/*
 0. There is at most 1 "live" key Image panel
 1. KI button is shown only on Primary 2D Viewports
 2. Initially, Key Image button is shown but not selected for each viewport
 3. Key Image button shows hover text with K hot key
 4. User Clicks Key Image button for a viewport
    a. A single Key Image is added to the Primary exam's KeyImageSeries
       StudyInstance, SopInstance UID, ImageNumber, FrameNumber
    b. A new KeyImageSeriesDisplayItem2D is created. It tracks:
      ii. it is held in the SeriesDisplayStoreItemMap
      iii. KISeriesDisplayItems are a virtual series of a single image
    c. A KI thumbnail is added to the Key Image panel and the panel layout is adjusted
       so that it is the KeyImageDisplayStoreItems
    d. KI button shows as selected
  5. When the user switches to the KIP, they will see each of the KISeriesDisplayItems as thumbnails
  6. Layout of KIP may also be manually controlled for now
  7. If a KI button is selected, and the user presses it again
    a. Image is removed fro KI Series for the exam
    b. KI Display Store item is deleted
    c. KI Thumbnail is removed and panel layout adjusted
    c. KI button shows as not selected
  8. KI Panel Toolbox -- just another 2D Panel...?
  9. Switching between panels or changing 2D Panel layout, KIP button on each viewport
     shows whether "this" viewport has a KI on the panel.
  10. Key Image operations:
     a. AddKeyImage
     b. RemoveKeyImage
     c. HasKeyImage
  11. Key Image button does not appear on
      a. prior panels
      b. ko panels
      c. 3D panels
*/

class KeyImageButton implements IMiniBarButton {
  public buttonId: TOOL_TYPE;
  public isDisabled: boolean;
  public isSelected: boolean;

  constructor() {
    this.buttonId = TOOL_TYPE.eToggleAsKeyImage;
    this.isDisabled = false;
    this.isSelected = false;
  }

}

const KEY_IMAGE_SOUND_FILE = '/viewer/assets/sounds/Viewer/key-image.mp3';

@Injectable()
export class KeyImageControlService {

  static readonly KeyImageSound = new Audio(KEY_IMAGE_SOUND_FILE);

  private foviaRenderParams$: Observable<RenderParams | null>;
  private foviaHtmlViewport$: Observable<HTMLViewport | null>;
  private panelStoreItem$: Observable<PanelStoreItem | null>;
  private seriesDisplayStoreItem$: Observable<SeriesDisplayStoreItem | null>;

  private currentImageFrame$$: BehaviorSubject<ImageFrameSelection | null>;
  private keyImageButton$$: BehaviorSubject<IMiniBarButton>;
  private showKeyImageButton$$: BehaviorSubject<boolean>;
  private unsubscribe$$ = new Subject<void>();
  private viewportId$$: BehaviorSubject<string>;

  private currentSeriesDisplayStoreItem: SeriesDisplayStoreItem | null = null;
  private foviaHtmlViewport: HTMLViewport | null = null;

  public constructor(
    private examService: ExamService,
    private panelsContainersService: PanelsContainerService,
    private seriesDisplayStoreService: SeriesDisplayStoreService,
    private viewerSettingsService: ViewerSettingsService,
    private modalPopupService: ModalPopupService,
    private userInfoService: UserInformationService) {

    this.currentImageFrame$$ = new BehaviorSubject<ImageFrameSelection | null>(null);
    this.keyImageButton$$ = new BehaviorSubject<IMiniBarButton>(new KeyImageButton());
    this.showKeyImageButton$$ = new BehaviorSubject<boolean>(false);
    this.viewportId$$ = new BehaviorSubject<string>('');

    this.seriesDisplayStoreItem$ = this.viewportId$$
      .pipe(
        filter(id => (id != null)),
        switchMap((viewportId: string | null) => {
          return (viewportId == null)
            ? new BehaviorSubject<SeriesDisplayStoreItem | null>(null)
            : this.seriesDisplayStoreService.getSeriesDisplayStoreItem$(viewportId);
        })
      );

    this.foviaRenderParams$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<RenderParams | null>(null)
            : storeItem.foviaRenderParams$;
        })
      );

    this.foviaHtmlViewport$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<HTMLViewport | null>(null)
            : storeItem.foviaHtmlViewport$;
        })
      );

    this.panelStoreItem$ = this.viewportId$$
      .pipe(filter(id => (id != null)),
        map((viewportId: string | null) => {
          const panelId = this.panelsContainersService.getCurrentPanelIdWhere(item => {
            return (item.viewportIdGrid.flat().findIndex(vpId => vpId === viewportId) !== -1);
          });

          return this.panelsContainersService.getPanelStoreItem(panelId);
        }));

    this.subscriptions();
  }

  public get keyImageButton$(): Observable<IMiniBarButton> {
    return this.keyImageButton$$.asObservable();
  }

  public get showKeyImageButton$(): Observable<boolean> {
    return this.showKeyImageButton$$.asObservable();
  }

  public set viewportID(value: string) {
    this.viewportId$$.next(value);
  }

  public wasClicked(): void {
    this.addOrRemove().then();
  }

  private get keyImageButton(): KeyImageButton {
    return this.keyImageButton$$.getValue();
  }

  private get currentImageFrame(): ImageFrameSelection | null {
    return this.currentImageFrame$$.getValue();
  }

  private async addOrRemove(): Promise<void> {
    const primaryExam = this.examService.getPrimaryExam();
    if (this.currentSeriesDisplayStoreItem == null || this.currentImageFrame == null) {
      return;
    }
    if (this.currentSeriesDisplayStoreItem.series == null || primaryExam == null) {
      return;
    }

    if (!this.userInfoService.canSaveEdits) {
      this.modalPopupService.openUserNotificationDialog(new UserNotificationParams(`You don't have sufficient rights to modify and save a Key Object.`, [], false));
      return;
    }
    // button selected indicates a key image exists
    if (this.keyImageButton.isSelected) {
      this.removeKeyImage();
    } else {
      this.addKeyImage();
    }
  }

  private addKeyImage(): void {
    const keyImage = this.createKeyImage();
    if (keyImage == null) {
      return;
    }
    this.panelsContainersService.onAddNewKeyImageToPrimary(keyImage);
    KeyImageControlService.KeyImageSound.play().then();
  }

  private removeKeyImage(): void {
    if (this.currentImageFrame !== null) {
      this.panelsContainersService.onRemoveKeyImageFromPrimary(this.currentImageFrame.sopInstanceUID, this.currentImageFrame.frameNumber);
    }
  }

  private hasKeyImage(): boolean {
    if (this.currentImageFrame !== null) {
      return this.examService.hasKeyImage(this.currentImageFrame.sopInstanceUID, this.currentImageFrame.frameNumber);
    }
    return false;
  }

  private createKeyImage(): VirtualSeries | null {
    if (this.currentImageFrame == null) {
      console.error(`createKeyImage currentImageFrame is null`);
      return null;
    }
    const keyImageSeries = this.currentSeriesDisplayStoreItem!.virtualSeries;
    const keyImageInfo = this.currentImageFrame;
    const keyImageAnnotations = this.cloneAnnotationsFromCurrentImage();
    const keyImage = this.examService.createKeyImage(keyImageSeries, keyImageInfo, keyImageAnnotations);
    if (keyImage == null) {
      console.error(`createKeyImage key image not created from ${keyImageSeries.ImageSeriesIndex}`);
    }
    return keyImage;
  }

  private cloneAnnotationsFromCurrentImage(): Fovia.GraphicAnnotation[] {
    if (!is2DGSPSViewport(this.foviaHtmlViewport)) {
      console.log('cloneAnnotationsFromCurrentImage: operation only supported for 2D viewports');
      return [];
    }
    if (this.currentImageFrame == null) {
      console.log('cloneAnnotationsFromCurrentImage: no current image frame selected');
      return [];
    }

    const fv = this.foviaHtmlViewport as HTMLViewport2DGSPS;
    return fv.cloneAnnotationsFromImage(makeImageKey(this.currentImageFrame.sopInstanceUID, this.currentImageFrame.frameNumber));
  }

  private subscriptions(): void {
    // Stay up-to-date on the current display store item
    this.seriesDisplayStoreItem$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (item: SeriesDisplayStoreItem | null) => {
        this.currentSeriesDisplayStoreItem = item;
      });

    // Stay up-to-date on the current viewport
    this.foviaHtmlViewport$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: HTMLViewport | null) => {
        this.foviaHtmlViewport = vp;
      });

    // Updated for every render -- so we can track which image is on the screen
    this.foviaRenderParams$
      .pipe(
        filter((rp) => this.foviaHtmlViewport != null && is2DRenderParams(rp) && this.currentSeriesDisplayStoreItem != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (rp: RenderParams | null) => {
        const rp2D = rp as RenderParams2D;
        if (rp2D != null && this.currentSeriesDisplayStoreItem != null && this.currentSeriesDisplayStoreItem.virtualSeries.currentSeriesDataContext != null) {
          // getting SopInstance from render params does not work...
          const imageFrameSelection = new ImageFrameSelection(
            rp2D.imageNumber,
            this.currentSeriesDisplayStoreItem.virtualSeries.currentSeriesDataContext.studyInstanceUID,
            this.currentSeriesDisplayStoreItem.virtualSeries.currentSeriesDataContext.seriesInstanceUID,
            this.currentSeriesDisplayStoreItem.virtualSeries.imageTags(rp2D.imageNumber)?.sopInstanceUID ?? '',
            this.currentSeriesDisplayStoreItem.virtualSeries.imageTags(rp2D.imageNumber)?.frameNumber ?? 0);

          // console.log(`KeyImageButton for Frame:  ${imageFrameSelection.toString()}`);
          this.currentImageFrame$$.next(imageFrameSelection);
        }
      });

    combineLatest(([this.currentImageFrame$$.asObservable(), this.panelStoreItem$]))
      .pipe(
        filter((cif) => cif != null),
        takeUntil(this.unsubscribe$$),
      )
      .subscribe(([cif, panelStoreItem]) => {
        if (cif != null) {
          this.initialize(panelStoreItem);
        }
      });

    // HotKey handling
    this.viewerSettingsService.toggleKeyImage$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((_: boolean) => {
        if (this.viewerSettingsService.activeViewport === this.viewportId$$.value) {
          // Hot key only adds Key Images for viewports that are showing the keyImage button
          if (this.showKeyImageButton$$.getValue()) {
            this.addOrRemove().then();
          }
        }
      });

    this.examService.keyImageSeriesUpdated$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        if (this.currentImageFrame != null) {
          this.isSelected = this.hasKeyImage();
        }
      });

  }

  private initialize(panelStoreItem: PanelStoreItem | null): void {
    // Don't show KeyImage control button on blank, 3D panels or KO panels.
    if (this.currentSeriesDisplayStoreItem == null || this.currentImageFrame == null ||
      this.currentSeriesDisplayStoreItem.is3DOrMPR || !this.userInfoService.canSaveEdits) {
      this.showKeyImageButton$$.next(false);
    } else {
      const sdi = this.currentSeriesDisplayStoreItem;
      // Key Image control on 2D images, toggle on/off will add/remove them from KO panel
      // Key Image control is on 2D panel
      // For 3D, we'll need to create a secondary capture image and add it to the exam ... or add 3D volume object to KO?
      if (sdi.series == null) {
        this.showKeyImageButton$$.next(false);
        return;
      }

      const is2DPanel = panelStoreItem !== null ? panelTypeIs2D(panelStoreItem.panelType) : false;

      this.showKeyImageButton$$.next(sdi.is2D && is2DPanel);
      this.isSelected = this.hasKeyImage();
    }
  }

  private set isSelected(haskeyImage: boolean) {
    this.keyImageButton.isSelected = haskeyImage;
    this.keyImageButton$$.next(this.keyImageButton);
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public onDestroy(): void {
    this.unsubscribe();
  }
}
