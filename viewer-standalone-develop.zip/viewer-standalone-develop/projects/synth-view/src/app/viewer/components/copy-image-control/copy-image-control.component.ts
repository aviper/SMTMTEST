import { Component, effect, input, InputSignal, OnDestroy, signal, Signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { CopyDeleteImageControlService } from '../../services';

class CopyImageButton implements IMiniBarButton {
  public buttonId: TOOL_TYPE;
  public isDisabled: boolean;
  public isSelected: boolean;

  constructor() {
    this.buttonId = TOOL_TYPE.eCopyKOImage;
    this.isDisabled = false;
    this.isSelected = false;
  }
}

@Component({
  standalone: false,
  selector: 'app-copy-image-control',
  templateUrl: './copy-image-control.component.html',
  styleUrl: './copy-image-control.component.scss',
  providers: [CopyDeleteImageControlService]
})
export class CopyImageControlComponent implements OnDestroy {
  public readonly viewportId: InputSignal<string> = input<string>('');

  constructor(private copyDeleteImageControlService: CopyDeleteImageControlService) {
    effect(()=>{
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.copyDeleteImageControlService.viewportId = vpId;
      }
    });
  }

  public copyImageButton: Signal<CopyImageButton> = signal<CopyImageButton>(new CopyImageButton());

  public showCopyImageButton = toSignal<boolean>(this.copyDeleteImageControlService.showCopyImageButton$);

  public onMouseUp(): void {
    this.copyDeleteImageControlService.copyImage();
  }

  public ngOnDestroy(): void {
    this.copyDeleteImageControlService.onDestroy();
  }
}
