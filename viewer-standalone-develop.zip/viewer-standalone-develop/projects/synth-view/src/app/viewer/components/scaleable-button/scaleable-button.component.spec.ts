import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScaleableButtonComponent } from './scaleable-button.component';

describe('ScaleableButtonComponent', () => {
  let component: ScaleableButtonComponent;
  let fixture: ComponentFixture<ScaleableButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScaleableButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScaleableButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
