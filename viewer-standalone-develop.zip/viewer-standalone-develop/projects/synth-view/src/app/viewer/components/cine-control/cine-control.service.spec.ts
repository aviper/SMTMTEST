import { TestBed } from '@angular/core/testing';

import { CineControlService } from './cine-control.service';

describe('CineControlService', () => {
  let service: CineControlService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CineControlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
