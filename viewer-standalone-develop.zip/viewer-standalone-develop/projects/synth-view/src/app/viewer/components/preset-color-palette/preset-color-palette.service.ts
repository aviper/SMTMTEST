import { Injectable } from '@angular/core';
import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { BehaviorSubject, filter, Observable, Subject, switchMap, take, takeUntil } from 'rxjs';
import { AdaptorsService, SeriesDisplayStoreService } from '../../services';
import { Point } from '../../utils';
import Fovia from 'foviaapi';
import HTMLViewport = Fovia.UI.HTMLViewport;
import { LaunchParams, ModalPopupService } from '../../modal-popup-dialogs';
import { SeriesDisplayStoreItem } from '../../stores';

class PresetColorPaletteButton implements IMiniBarButton {
  public buttonId = TOOL_TYPE.eColorPaletteAccess;
  public isDisabled = false;
  public isSelected = false;

  constructor() { }
}

@Injectable()
export class PresetColorPaletteService {

  private seriesDisplayStoreItem$: Observable<SeriesDisplayStoreItem | null>;
  private foviaHtmlViewport$: Observable<HTMLViewport | null>;
  private presetColorPaletteButton$$: BehaviorSubject<IMiniBarButton>;
  private showPresetColorPaletteButton$$: BehaviorSubject<boolean>;
  private unsubscribe$$ = new Subject<void>();
  private viewportId$$: BehaviorSubject<string>;
  private currentSeriesDisplayStoreItem: SeriesDisplayStoreItem | null = null;
  private foviaHtmlViewport: HTMLViewport | null = null;

  public constructor(private seriesDisplayStoreService: SeriesDisplayStoreService,
                     private adaptorsService: AdaptorsService,
                     private contextMenuService: ModalPopupService) {
    this.presetColorPaletteButton$$ = new BehaviorSubject<IMiniBarButton>(new PresetColorPaletteButton());
    this.showPresetColorPaletteButton$$ = new BehaviorSubject<boolean>(false);
    this.viewportId$$ = new BehaviorSubject<string>('');

    this.seriesDisplayStoreItem$ = this.viewportId$$
      .pipe(
        filter(id => (id != null)),
        switchMap((viewportId: string | null) => {
          return (viewportId == null)
            ? new BehaviorSubject<SeriesDisplayStoreItem | null>(null)
            : this.seriesDisplayStoreService.getSeriesDisplayStoreItem$(viewportId);
        })
      );

    this.foviaHtmlViewport$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<HTMLViewport | null>(null)
            : storeItem.foviaHtmlViewport$;
        })
      );

    this.subscriptions();
  }

  public get presetColorPaletteButton$(): Observable<IMiniBarButton> {
    return this.presetColorPaletteButton$$.asObservable();
  }

  public get showPresetColorPaletteButton$(): Observable<boolean> {
    return this.showPresetColorPaletteButton$$.asObservable();
  }

  public set viewportID(value: string) {
    this.viewportId$$.next(value);
  }
  public get viewportID(): string {
    return this.viewportId$$.value;
  }
  public onChangePreset(): void {
    const faves = this.adaptorsService.getViewerSettingsService().colorPalettePresetFavorites;
    if (faves.length > 0 && this.currentSeriesDisplayStoreItem != null && this.foviaHtmlViewport != null) {
      this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite++;
      if (this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite >= faves.length) {
        this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite = -1;
        this.currentSeriesDisplayStoreItem.selectedColorPalettePreset = '';
        this.adaptorsService.toolSyncActions.applyColorPalette(this.viewportID, '');
      } else {
        this.adaptorsService.toolSyncActions.applyColorPalette(this.viewportID, faves[this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite]);
      }
    }
  }

  // Show the preset menu
  public onShowPresetMenu(event: MouseEvent): void {
    if (this.foviaHtmlViewport) {
      const launchParams = new LaunchParams(new Point(event.x, event.y));
      launchParams.class_selector = 'color-palette-favorites-dialog';

      let selectedPreset = '';
      if (this.currentSeriesDisplayStoreItem) {
        const faves = this.adaptorsService.getViewerSettingsService().colorPalettePresetFavorites;
        if (this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite >= 0) {
          selectedPreset = this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite < faves.length ? faves[this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite] : '';
        } else {
          selectedPreset  = this.currentSeriesDisplayStoreItem.selectedColorPalettePreset;
        }
      }

      this.contextMenuService.openPresetColorPaletteDialog(true, selectedPreset, launchParams)
        .afterClosed()
        .pipe(
          take(1)
        )
        .subscribe(newPaletteName => {
          if (newPaletteName != null) {
            if (this.currentSeriesDisplayStoreItem) {
              this.currentSeriesDisplayStoreItem.selectedColorPalettePreset = newPaletteName;
              this.currentSeriesDisplayStoreItem.selectedColorPalettePresetFavorite = -1;
            }
            this.adaptorsService.toolSyncActions.applyColorPalette(this.viewportID, newPaletteName);
          }
        });
    }
  }

  private get presetColorPaletteButton(): PresetColorPaletteButton {
    return this.presetColorPaletteButton$$.getValue();
  }

  private subscriptions(): void {
    // Stay up-to-date on the current display store item
    this.seriesDisplayStoreItem$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (item: SeriesDisplayStoreItem | null) => {
        this.currentSeriesDisplayStoreItem = item;
        this.initialize();
      });

    // Stay up-to-date on the current viewport
    this.foviaHtmlViewport$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: HTMLViewport | null) => {
        this.foviaHtmlViewport = vp;
      });
  }

  private initialize(): void {
    // Don't show the control button on blank, or 3D panels.
    if (this.currentSeriesDisplayStoreItem == null || this.currentSeriesDisplayStoreItem.is3DOrMPR) {
      this.showPresetColorPaletteButton$$.next(false);
    } else {
      const series = this.currentSeriesDisplayStoreItem.series;
      this.showPresetColorPaletteButton$$.next(series != null && (series.isModalityPT() || series.isModalityNM()) && this.currentSeriesDisplayStoreItem.is2D);
    }
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public onDestroy(): void {
    this.unsubscribe();
  }
}
