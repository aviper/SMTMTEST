import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PresetWlControlComponent } from './preset-wl-control.component';

describe('PresetWLControlComponent', () => {
  let component: PresetWlControlComponent;
  let fixture: ComponentFixture<PresetWlControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PresetWlControlComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PresetWlControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
