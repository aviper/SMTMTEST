import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';

import { PresetColorPaletteService } from './preset-color-palette.service';
import { IMiniBarButton } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-preset-color-palette',
  templateUrl: './preset-color-palette.component.html',
  styleUrl: './preset-color-palette.component.scss',
  providers: [PresetColorPaletteService]
})
export class PresetColorPaletteComponent implements OnDestroy {
  public readonly viewportId: InputSignal<string> = input<string>('');

  public showPresetColorPaletteButton = toSignal<boolean>(this.presetColorPaletteService.showPresetColorPaletteButton$);
  public presetColorPaletteButton = toSignal<IMiniBarButton>(this.presetColorPaletteService.presetColorPaletteButton$);

  public constructor(protected presetColorPaletteService: PresetColorPaletteService) {
    effect(()=> {
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.presetColorPaletteService.viewportID = vpId;
      }
    })
  }

  public ngOnDestroy(): void {
    this.presetColorPaletteService.onDestroy();
  }

}
