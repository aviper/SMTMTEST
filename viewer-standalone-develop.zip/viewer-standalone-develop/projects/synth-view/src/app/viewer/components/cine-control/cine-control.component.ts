import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';

import { CineControlService } from './cine-control.service';
import { IMiniBarButton } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-cine-control',
  templateUrl: './cine-control.component.html',
  styleUrl: './cine-control.component.scss',
  providers: [CineControlService]
})
export class CineControlComponent implements OnDestroy {
  public readonly viewportId: InputSignal<string> = input<string>('');

  public constructor(private cineControlService: CineControlService) {
    effect(() => {
      const vpId = this.viewportId()
      if (vpId !== '') {
        this.cineControlService.viewportID = vpId;
      }
    });
  }

  public cineButton = toSignal<IMiniBarButton>(this.cineControlService.cineButton$);
  public showCineButton = toSignal<boolean>(this.cineControlService.showCineButton$);

  public onMouseUp(event: MouseEvent): void {
    this.cineControlService.onButtonClicked(event);
  }

  public ngOnDestroy(): void {
    this.cineControlService.onDestroy();
  }

}
