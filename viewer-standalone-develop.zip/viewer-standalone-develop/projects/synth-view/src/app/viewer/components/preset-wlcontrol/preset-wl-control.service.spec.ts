import { TestBed } from '@angular/core/testing';

import { PresetWlControlService } from './preset-wl-control.service';

describe('PresetWLControlService', () => {
  let service: PresetWlControlService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PresetWlControlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
