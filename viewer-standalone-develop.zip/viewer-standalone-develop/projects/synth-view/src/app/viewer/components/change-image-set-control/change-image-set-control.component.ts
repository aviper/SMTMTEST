import { Component, computed, effect, input, InputSignal, Signal } from '@angular/core';
import { ChangeImageSetControlService } from './change-image-set-control.service';
import { TOOL_TYPE } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-change-image-set-control',
  templateUrl: './change-image-set-control.component.html',
  styleUrl: './change-image-set-control.component.scss',
  providers: [ChangeImageSetControlService]

})
export class ChangeImageSetControlComponent {
  public readonly next: InputSignal<boolean> = input<boolean>(true);
  public readonly viewportId: InputSignal<string> = input<string>('');

  public buttonId: Signal<TOOL_TYPE> = computed<TOOL_TYPE>(() => this.next() ? TOOL_TYPE.eImageSetNext : TOOL_TYPE.eImageSetPrevious);

  public constructor(protected changeImageSetControlService: ChangeImageSetControlService) {
    effect(() => {
      const vpId = this.viewportId()
      if (vpId !== '') {
        this.changeImageSetControlService.viewportID = vpId;
      }
    });
  }

}
