import { TestBed } from '@angular/core/testing';

import { KeyImageControlService } from './key-image-control.service';

describe('KeyImageControlService', () => {
  let service: KeyImageControlService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeyImageControlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
