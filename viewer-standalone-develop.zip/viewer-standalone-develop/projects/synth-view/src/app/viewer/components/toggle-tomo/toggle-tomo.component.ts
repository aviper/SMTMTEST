import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ToggleTomoService } from './toggle-tomo.service';
import { IMiniBarButton } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-toggle-tomo',
  templateUrl: './toggle-tomo.component.html',
  styleUrl: './toggle-tomo.component.scss',
  providers: [ToggleTomoService]
})
export class ToggleTomoComponent implements OnDestroy {
  readonly viewportId: InputSignal<string> = input<string>('');

  public showTomoOnButton = toSignal<boolean>(this.toggleTomoService.showTomoOnButton$);
  public showTomoOffButton = toSignal<boolean>(this.toggleTomoService.showTomoOffButton$);
  public tomoOnButton = toSignal<IMiniBarButton>(this.toggleTomoService.tomoOnButton$);
  public tomoOffButton = toSignal<IMiniBarButton>(this.toggleTomoService.tomoOffButton$);

  public constructor(protected toggleTomoService: ToggleTomoService) {
    effect(()=> {
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.toggleTomoService.viewportID = vpId;
      }
    });
  }

  public ngOnDestroy(): void {
    this.toggleTomoService.onDestroy();
  }
}
