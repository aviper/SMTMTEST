import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteImageControlComponent } from './delete-image-control.component';

describe('DeleteImageControlComponent', () => {
  let component: DeleteImageControlComponent;
  let fixture: ComponentFixture<DeleteImageControlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DeleteImageControlComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeleteImageControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
