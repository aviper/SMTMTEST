import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PresetColorPaletteComponent } from './preset-color-palette.component';

describe('PresetColorPaletteComponent', () => {
  let component: PresetColorPaletteComponent;
  let fixture: ComponentFixture<PresetColorPaletteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PresetColorPaletteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PresetColorPaletteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
