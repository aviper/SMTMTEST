import { Component, computed, input, InputSignal, Signal } from '@angular/core';
import { ButtonDefinition, GetToolButton, NO_BUTTON, TOOL_TYPE } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-scaleable-button',
  templateUrl: './scaleable-button.component.html',
  styleUrls: ['./scaleable-button.component.scss'],
})
export class ScaleableButtonComponent {

  public readonly reducedSize: InputSignal<boolean> = input<boolean>(false);

  public readonly buttonId: InputSignal<TOOL_TYPE> = input<TOOL_TYPE>(TOOL_TYPE.eNone);

  public readonly isDisabled: InputSignal<boolean> = input<boolean>(false);

  // Signal when a button should indicated as selected
  // This is shown as a colored border
  public readonly isSelected: InputSignal<boolean> = input<boolean>(false);

  // Signal when a button should indicated as active -
  // this is shown as a background change
  public readonly isActive: InputSignal<boolean> = input<boolean>(false);

  public selected: Signal<boolean> = computed(()=> this.isSelected());
  public active: Signal<boolean> =  computed(() => this.isActive());

  public button: Signal<ButtonDefinition> =
  computed(() => {
    if (this.buttonId() === TOOL_TYPE.eNone) {
      return NO_BUTTON;
    } else {
      return GetToolButton(this.buttonId());
    }
  });

  public isSVG: Signal<boolean> = computed(() => this.button().icon.includes('.svg'));

  public constructor() {
  }

}
