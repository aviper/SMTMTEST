import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { InputOverrideDirective } from '../../directives/input-override.directive';
@Component({
  standalone: false,
  selector: 'app-input-number',
  templateUrl: './input-number.component.html',
  styleUrls: ['./input-number.component.scss']
})
export class InputNumberComponent extends InputOverrideDirective implements OnInit {

  @ViewChild('numericField') private numericField: ElementRef;

  @Input() public label = '';
  @Input() public minimum = 0;
  @Input() public maximum = 200;
  @Input() public increment = 'any';
  @Input() public editValue = NaN;
  @Input() public units = '';
  @Output() public editedValue = new EventEmitter<number>();

  public get placeholderMessage(): string {
    return this._placeHolderMessage;
  }

  public get hint(): string {
    return this._hint;
  }

  protected _placeHolderMessage = '';
  protected _hint = '';

  constructor() {
    super();
    this.numericField = new ElementRef(null);
  }

  public ngOnInit(): void {
    if (this.minimum !== null && this.maximum !== null) {
      this._placeHolderMessage = `${this.minimum}-${this.maximum}`;
      this._hint = 'Valid values: ' + this.placeholderMessage;
    }
  }

  // Update our value if it is valid
  public updateValue(value: string): void {
    const parsedValue = Number(parseFloat(value).toFixed(1));
    if (!this.isValid(parsedValue)) {
      return;
    }
    this.editValue = parsedValue;
    this.editedValue.emit(this.editValue);
    this.onEnterPressed(this.numericField.nativeElement);
  }

   public onMouseLeave(element: HTMLInputElement): void {
     element.blur();
   }

  // Provide callback from directive to handle particular keyboard
  // actions, stopPropagation was called by directive
  protected override handleKeyboardEvents(event: KeyboardEvent): void {
    if (event == null) {
      return;
    }

    if (event.key === 'Enter') {
      this.onEnterPressed(this.numericField.nativeElement);
    }
  }

  // Drop focus
  private onEnterPressed(element: HTMLElement): void {
    element.blur();
  }



  private isValid(input: number): boolean {
    return (input >= this.minimum || input <= this.maximum);
  }

}
