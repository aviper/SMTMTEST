import { Injectable } from '@angular/core';
import { TOOL_TYPE } from '../../tools';
import { AdaptorsService, SeriesDisplayStoreService } from '../../services';

@Injectable()
export class ChangeImageSetControlService {
  private _viewportID = '';

  constructor(private seriesDisplayStoreService: SeriesDisplayStoreService, private adaptorService: AdaptorsService) { }

  public onButtonClicked(buttonId: TOOL_TYPE): void {
    const seriesDisplayItem = this.seriesDisplayStoreService.getSeriesDisplayStoreItem(this.viewportID);

    if (seriesDisplayItem !== null && seriesDisplayItem.series !== null) {
      if (seriesDisplayItem.series.isMultiframe) {
        this.adaptorService.cineActions.switchMultiframeImage(buttonId === TOOL_TYPE.eImageSetNext).then();
      } else {
        this.adaptorService.scrollActions.scrollToNextImageOnViewport(this.viewportID, buttonId === TOOL_TYPE.eImageSetNext, false).then();
      }
    }
  }

  public set viewportID(value: string) {
    this._viewportID = value;
  }

  public get viewportID(): string {
    return this._viewportID;
  }
}
