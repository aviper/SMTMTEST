import { Component, effect, input, InputSignal, OnDestroy } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { PresetWlControlService } from './preset-wl-control.service';
import { IMiniBarButton } from '../../tools';

@Component({
  standalone: false,
  selector: 'app-preset-wl-control',
  templateUrl: './preset-wl-control.component.html',
  styleUrl: './preset-wl-control.component.scss',
  providers: [PresetWlControlService]
})
export class PresetWlControlComponent implements OnDestroy {

  public viewportId: InputSignal<string> = input<string>('');

  public constructor(protected presetWLControlService: PresetWlControlService) {
    effect(()=>{
      const vpId = this.viewportId();
      if (vpId !== '') {
        this.presetWLControlService.viewportID = vpId;
      }
    });
  }

  public presetWLButton = toSignal<IMiniBarButton>(this.presetWLControlService.presetWLButton$);
  public showPresetWLButton = toSignal<boolean>(this.presetWLControlService.showPresetWLButton$);

  public ngOnDestroy(): void {
    this.presetWLControlService.onDestroy();
  }

}
