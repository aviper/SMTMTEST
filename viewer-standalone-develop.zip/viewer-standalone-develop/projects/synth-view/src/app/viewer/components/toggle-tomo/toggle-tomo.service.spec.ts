import { TestBed } from '@angular/core/testing';

import { ToggleTomoService } from './toggle-tomo.service';

describe('ToggleTomoService', () => {
  let service: ToggleTomoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ToggleTomoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
