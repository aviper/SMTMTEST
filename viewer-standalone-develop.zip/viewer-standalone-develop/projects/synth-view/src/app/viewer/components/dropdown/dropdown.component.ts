import { AfterViewInit, Component, EventEmitter, Input, Output, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import Fovia from 'foviaapi';
import { JSONParseSafe } from '@server-api';

export interface IDropdownItem {
  value: number;      // Value returned for selection
  viewValue: string;  // Value displayed in dropdown
}
@Component({
  standalone: false,
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements AfterViewInit, OnChanges, OnInit {

  @Input() public set jsonItems(value: string) {
    // console.log(`${value}`)
    const items = JSONParseSafe(value);
    this.items = items == null ? [] : items;
  }
  @Input() public title = '';
  @Input() public currentSelection = -1;  // value field of current selection or -1 for no initial selection;
  @Input() public showSelection = false; // update the control UI to reflect the currently selected item
  @Output() public newSelection: EventEmitter<number> = new EventEmitter();

  private _initialSelection = '';

  public items: IDropdownItem[] = [];

  public get initialSelection(): string {
    return this._initialSelection;
  }

  public constructor() {
  }

  public ngAfterViewInit(): void {
    this.initialize();
  }

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes['currentSelection'] && this.currentSelection !== -1) {
      this.initialize();
    }
  }

  public ngOnInit(): void {
    this.initialize();
  }
  public get showTitle(): boolean {
    return this.title !== '';
  }

  public selected(event: Event): void {
    const value: number = parseInt((event.target as HTMLSelectElement).value);
    // console.log(`item ${value} selected for dropdown` )
    this.newSelection.emit(value);
  }

  private initialize(): void {
    this.setInitialSelection();
  }

  private setInitialSelection(): void {
    const foundItem = this.items.find((item: IDropdownItem) => item.value === this.currentSelection);
    if (foundItem) {
      this._initialSelection = foundItem.viewValue;
    }
  }
}
