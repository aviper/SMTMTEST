import { Injectable } from '@angular/core';
import { IMiniBarButton, TOOL_TYPE } from '../../tools';
import { BehaviorSubject, filter, Observable, Subject, switchMap, take, takeUntil } from 'rxjs';
import { AdaptorsService, SeriesDisplayStoreService } from '../../services';
import { WindowLevel, WindowLevelHelper } from '../../models';
import { getDefaultWindowLevelsFromViewport, getRenderParams2D, getSlopeInterceptFromViewport, Point } from '../../utils';
import Fovia from 'foviaapi';
import HTMLViewport = Fovia.UI.HTMLViewport;
import { LaunchParams, ModalPopupService } from '../../modal-popup-dialogs';
import { SeriesDisplayStoreItem } from '../../stores';

class PresetWLButton implements IMiniBarButton {
  public buttonId = TOOL_TYPE.eWindowLevelPresetAccess;
  public isDisabled = false;
  public isSelected = false;

  constructor() { }
}

@Injectable()
export class PresetWlControlService {

  private seriesDisplayStoreItem$: Observable<SeriesDisplayStoreItem | null>;
  private foviaHtmlViewport$: Observable<HTMLViewport | null>;
  private presetWLButton$$: BehaviorSubject<IMiniBarButton>;
  private showPresetWLButton$$: BehaviorSubject<boolean>;
  private unsubscribe$$ = new Subject<void>();
  private viewportId$$: BehaviorSubject<string>;
  private currentSeriesDisplayStoreItem: SeriesDisplayStoreItem | null = null;
  private foviaHtmlViewport: HTMLViewport | null = null;

  public constructor(private seriesDisplayStoreService: SeriesDisplayStoreService,
                      private adaptorsService: AdaptorsService,
                      private contextMenuService: ModalPopupService) {
    this.presetWLButton$$ = new BehaviorSubject<IMiniBarButton>(new PresetWLButton());
    this.showPresetWLButton$$ = new BehaviorSubject<boolean>(false);
    this.viewportId$$ = new BehaviorSubject<string>('');

    this.seriesDisplayStoreItem$ = this.viewportId$$
      .pipe(
        filter(id => (id != null)),
        switchMap((viewportId: string | null) => {
          return (viewportId == null)
            ? new BehaviorSubject<SeriesDisplayStoreItem | null>(null)
            : this.seriesDisplayStoreService.getSeriesDisplayStoreItem$(viewportId);
        })
      );

    this.foviaHtmlViewport$ = this.seriesDisplayStoreItem$
      .pipe(
        switchMap((storeItem: SeriesDisplayStoreItem | null) => {
          return (storeItem == null)
            ? new BehaviorSubject<HTMLViewport | null>(null)
            : storeItem.foviaHtmlViewport$;
        })
      );

    this.subscriptions();
  }

  public get presetWLButton$(): Observable<IMiniBarButton> {
    return this.presetWLButton$$.asObservable();
  }

  public get showPresetWLButton$(): Observable<boolean> {
    return this.showPresetWLButton$$.asObservable();
  }

  public set viewportID(value: string) {
    this.viewportId$$.next(value);
  }
  public get viewportID(): string {
    return this.viewportId$$.value;
  }
  public onChangePreset(): void {
    const faves = this.adaptorsService.getViewerSettingsService().wlPresetFavorites;
    if (faves.length > 0 && this.currentSeriesDisplayStoreItem !== null) {
      const currentPreset = this.currentSeriesDisplayStoreItem.selectedWLPresetFavorite;

      // Make sure ViewerSettingsService is aware that our viewport should be active. It loses
      // track when the mouse cursor goes over the button.
      this.adaptorsService.getViewerSettingsService().activeViewport = this.viewportID;
      if (currentPreset + 1 < faves.length) {
        this.adaptorsService.getViewerSettingsService().applyPresetFavorite = currentPreset + 1;
      } else {
        // This is "reset" or set to default.
        this.adaptorsService.getViewerSettingsService().applyPresetFavorite = -1;
      }
    }
  }

  // Show the preset menu
  public onShowPresetMenu(event: MouseEvent): void {
    const wl: WindowLevel | null = this.getCurrentWLValue();
    if (wl != null && this.foviaHtmlViewport) {
      const si = getSlopeInterceptFromViewport(this.foviaHtmlViewport);
      const defaultWL = getDefaultWindowLevelsFromViewport(this.foviaHtmlViewport);
      const displayedWLHelper = new WindowLevelHelper(wl, si);
      const launchParams = new LaunchParams(new Point(event.x, event.y));

      launchParams.class_selector = 'preset-2d-favorites-dialog';

      this.contextMenuService.openWLPresetDialog(displayedWLHelper.displayedWL, defaultWL, /*editable*/true, launchParams,
                                                  /*wlOptions*/[], this.currentSeriesDisplayStoreItem?.series)
        .afterClosed()
        .pipe(
          take(1)
        )
        .subscribe(newWL => {
          if (newWL != null && newWL instanceof WindowLevel) {
            // console.log(`${this.constructor.name} contextMenu selected WL:${newWL.toString()}`, newWL);
            const storedWLHelper = new WindowLevelHelper(newWL, si);
            // console.log(`new WL ${newWL.toString()} stored is ${storedWLHelper.storedWL}`);
            this.adaptorsService.toolSyncActions.applyWLOperation(this.viewportID, storedWLHelper.storedWL);
          }
        });
    }
  }

  private getCurrentWLValue(): WindowLevel | null {
    if (this.currentSeriesDisplayStoreItem != null && this.foviaHtmlViewport != null) {
      if (this.currentSeriesDisplayStoreItem.is2D) {
        const rp = getRenderParams2D(this.foviaHtmlViewport);
        if (rp != null) {
          return WindowLevel.fromRenderParams(rp);
        }
      }
    }
    return null;
  }

  private get presetWLButton(): PresetWLButton {
    return this.presetWLButton$$.getValue();
  }

  private subscriptions(): void {
    // Stay up-to-date on the current display store item
    this.seriesDisplayStoreItem$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (item: SeriesDisplayStoreItem | null) => {
        this.currentSeriesDisplayStoreItem = item;
        this.initialize();
      });

    // Stay up-to-date on the current viewport
    this.foviaHtmlViewport$
      .pipe(
        filter((vp) => vp != null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((vp: HTMLViewport | null) => {
        this.foviaHtmlViewport = vp;
      });
  }

  private initialize(): void {
    // Don't show the control button on blank, or 3D panels.
    if (this.currentSeriesDisplayStoreItem == null || this.currentSeriesDisplayStoreItem.is3DOrMPR) {
      this.showPresetWLButton$$.next(false);
    } else {
      const series = this.currentSeriesDisplayStoreItem.series;
      this.showPresetWLButton$$.next(series != null && series.isModalityCT() && this.currentSeriesDisplayStoreItem.is2D);
    }
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public onDestroy(): void {
    this.unsubscribe();
  }
}
