import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleTomoComponent } from './toggle-tomo.component';

describe('ToggleTomoComponent', () => {
  let component: ToggleTomoComponent;
  let fixture: ComponentFixture<ToggleTomoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ToggleTomoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ToggleTomoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
