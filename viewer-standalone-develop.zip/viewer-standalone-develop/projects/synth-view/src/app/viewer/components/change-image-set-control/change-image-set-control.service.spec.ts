import { TestBed } from '@angular/core/testing';

import { ChangeImageSetControlService } from './change-image-set-control.service';

describe('ChangeImageSetControlService', () => {
  let service: ChangeImageSetControlService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChangeImageSetControlService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
