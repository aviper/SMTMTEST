import { ChangeDetectionStrategy, Component, input, InputSignal } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-splash-screen',
  templateUrl: './splash-screen.component.html',
  styleUrls: ['./splash-screen.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.loading]': 'loading()',
  }
})
export class SplashScreenComponent {
  readonly loading: InputSignal<boolean | null> = input<boolean | null>(false);
  readonly status: InputSignal<string | null> = input<string | null>('Loading...');
}
