import { Component, DestroyRef, inject, Input, OnInit, ViewChildren, QueryList } from '@angular/core';
import { PanelsContainerService } from '../services';
import { PanelStoreItem, ThumbnailCompareLayoutStoreService } from '../stores';
import { CompareModePanelService } from './compare-mode-panel.service';
import { SeriesSelection } from '../models';
import { ThumbnailBarComponent } from '../thumbnail-bar/thumbnail-bar.component';
import { ThumbnailBarService } from '../thumbnail-bar/thumbnail-bar.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-compare-mode-panel',
  standalone: false,
  templateUrl: './compare-mode-panel.component.html',
  styleUrl: './compare-mode-panel.component.scss',
  providers: [CompareModePanelService, ThumbnailBarService]
})
export class CompareModePanelComponent implements OnInit {
  @Input() panelId = '';
  public examPanelStoreItems: PanelStoreItem[] = [];

  @ViewChildren(ThumbnailBarComponent)
  private barQuery!: QueryList<ThumbnailBarComponent>;
  protected readonly layout = this.layoutService.layout;
  private destroyRef = inject(DestroyRef);
  constructor(
    private panelsContainerService: PanelsContainerService,
    private compareModePanelService: CompareModePanelService,
    private layoutService: ThumbnailCompareLayoutStoreService
  ) {}

  public ngOnInit(): void {
    // Only subscribe to panel store items if still Observable
    this.panelsContainerService.currentCompareModePanelStoreItems$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(items => {
      this.examPanelStoreItems = items;
      this.compareModePanelService.initializeThumbnailBarMatrix(this.examPanelStoreItems, this.layout().firstVisibleColumn);
    });
  }

  public onThumbnailBarScrolled(event: { rowIndex: number; firstVisibleColumn: number }): void {
    this.compareModePanelService.updateFirstVisibleColumn(event.rowIndex, event.firstVisibleColumn);
  }

  public onThumbnailBarDblClicked(selection: SeriesSelection): void {
    this.compareModePanelService.alignSeriesFromThumbnailBars(selection);
  }

  public scrollGlobalRowsLeft(): void {
    const layout = this.layout();
    if (!layout) { return; }
    this.scrollGlobalRows(-layout.stride);
  }

  public scrollGlobalRowsRight(): void {
    const layout = this.layout();
    if (!layout) { return; }
    this.scrollGlobalRows(layout.stride);
  }

  private get bars(): ThumbnailBarComponent[] {
    return this.barQuery?.toArray() ?? [];
  }

  private scrollGlobalRows(delta: number): void {
    const layout = this.layout();
    if (!layout) { return; }

    const { stride, viewportRemainder } = layout;

    this.bars.forEach(bar => {
      const normalizedCurrent = bar.getScrollLeft() - viewportRemainder;
      let target = Math.round((normalizedCurrent + delta) / stride) * stride;
      target += viewportRemainder;
      const maxScroll = bar.getScrollWidth() - bar.getClientWidth();
      target = Math.max(0, Math.min(target, maxScroll));
      bar.scrollTo(target, 'smooth');
    });
  }
}
