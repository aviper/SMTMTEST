import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompareModePanelComponent } from './compare-mode-panel.component';

describe('CompareModePanelComponent', () => {
  let component: CompareModePanelComponent;
  let fixture: ComponentFixture<CompareModePanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CompareModePanelComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompareModePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
