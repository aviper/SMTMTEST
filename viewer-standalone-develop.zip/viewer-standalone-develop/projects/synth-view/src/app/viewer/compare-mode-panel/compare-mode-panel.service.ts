import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CompareModeExamInfo, SeriesSelection, AlignedSeriesInfo } from '../models';
import { ViewerSettingsService } from '../services';

@Injectable()
export class CompareModePanelService implements OnDestroy {
  private compareModeMatrix: CompareModeExamInfo[] = [];

  constructor(private viewerSettingsService: ViewerSettingsService) {
  }


  initializeThumbnailBarMatrix(
    items: { thumbnailStoreItemIds: string[] }[],
    firstVisibleColumn: number
  ): void {
    const oldCompareModeMatrix = this.compareModeMatrix;

    this.compareModeMatrix = items.map((item, index) => {
      const firstThumbnailId = item.thumbnailStoreItemIds[0];

      const oldRow = oldCompareModeMatrix.find(
        row => row.thumbnailIds?.[0] === firstThumbnailId
      );

      return {
        examId: index,
        rowIndex: index,
        thumbnailIds: item.thumbnailStoreItemIds,
        firstVisibleColumn: oldRow?.firstVisibleColumn ?? firstVisibleColumn - 1,
      };
    });
  }


  public updateFirstVisibleColumn(
    rowIndex: number,
    firstVisibleColumn: number
  ): void {
    const row = this.compareModeMatrix.find(r => r.rowIndex === rowIndex);
    if (row) {
      row.firstVisibleColumn = firstVisibleColumn;
    }
  }

  public alignSeriesFromThumbnailBars(selection: SeriesSelection): void {
    const currRowIndex = selection.rowIndex;
    const currThumbnailVIdx = selection.visibleColumnIndex;

    if (currThumbnailVIdx == null) {
      return;
    }

    const clickedRow = this.compareModeMatrix
      .find(row => row.rowIndex === currRowIndex);

    if (!clickedRow) {
      return;
    }

    const aligned = this.buildAlignedThumbnails(
      this.compareModeMatrix,
      clickedRow,
      currThumbnailVIdx
    );
    this.viewerSettingsService.showCompareModeViewPorts = aligned;
  }

  private buildAlignedThumbnails(
    matrix: CompareModeExamInfo[],
    clickedRow: CompareModeExamInfo,
    currThumbnailVIdx: number
  ): AlignedSeriesInfo[] {
    return matrix.map(row => {
      const idx = Math.ceil(row.firstVisibleColumn - currThumbnailVIdx);
      const maxIdx = row.thumbnailIds.length - 1;

      return {
        rowIndex: row.rowIndex,
        thumbnailId:
          idx >= 0 && idx <= maxIdx ? row.thumbnailIds[idx] ?? null : null
      };
    });
  }

  private unsubscribe(): void {
  }

  public ngOnDestroy(): void {
    this.unsubscribe();
  }
}

