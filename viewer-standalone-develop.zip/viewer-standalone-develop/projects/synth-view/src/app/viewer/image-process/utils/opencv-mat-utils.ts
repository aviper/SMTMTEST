// viewer/utils/opencv-mat-utils.ts
import { OpenCV } from '../service';
import { OpencvMatInfo } from '../models';
import Fovia from 'foviaapi';

/**
 * Returns MatInfo given bit depth, signedness and channels.
 * Throws if configuration is unsupported.
 */
export function getMatInfo(cv: OpenCV, bitsAllocated: number, isSigned: boolean, channels: number = 1): OpencvMatInfo {
  if (bitsAllocated !== 8 && bitsAllocated !== 16) {
    throw new Error(`Unsupported bitsAllocated: ${bitsAllocated}`);
  }
  // 8-bit
  if (bitsAllocated === 8) {
    if (isSigned) {
      if (channels === 1) { return { matType: cv.CV_8SC1, TypedArrayConstructor: Int8Array, bytesPerElement: 1, channels }; }
      if (channels === 3) { return { matType: cv.CV_8SC3, TypedArrayConstructor: Int8Array, bytesPerElement: 1, channels }; }
    } else {
      if (channels === 1) { return { matType: cv.CV_8UC1, TypedArrayConstructor: Uint8Array, bytesPerElement: 1, channels }; }
      if (channels === 3) { return { matType: cv.CV_8UC3, TypedArrayConstructor: Uint8Array, bytesPerElement: 1, channels }; }
    }
  }
  // 16-bit
  if (bitsAllocated === 16) {
    if (isSigned) {
      if (channels === 1) { return { matType: cv.CV_16SC1, TypedArrayConstructor: Int16Array, bytesPerElement: 2, channels }; }
      if (channels === 3) { return { matType: cv.CV_16SC3, TypedArrayConstructor: Int16Array, bytesPerElement: 2, channels }; }
    } else {
      if (channels === 1) { return { matType: cv.CV_16UC1, TypedArrayConstructor: Uint16Array, bytesPerElement: 2, channels }; }
      if (channels === 3) { return { matType: cv.CV_16UC3, TypedArrayConstructor: Uint16Array, bytesPerElement: 2, channels }; }
    }
  }
  throw new Error(`Unsupported combination: bits=${bitsAllocated}, signed=${isSigned}, channels=${channels}`);
}

/**
 * Create an OpenCV Mat from Fovia ImageData pixel buffer
 */
export function createMatFromImageData(
  cv: OpenCV,
  width: number,
  height: number,
  matType: number,
  pixelData: ArrayBufferView
): any {
  // matFromArray expects rows (height), cols (width), type, and typed array
  return cv.matFromArray(height, width, matType, pixelData as any);
}

/**
 * Convert a cv.Mat.data (Uint8Array view) into a typed array matching matType.
 * Returns a typed-array .
 */
export function typedArrayFromMat(cv: OpenCV, mat: any, matType: number): ArrayBufferView {
  // mat.data is a Uint8Array view on WASM heap
  const u8 = mat.data as Uint8Array;
  const buffer = u8.buffer;
  const byteOffset = u8.byteOffset;
  const byteLength = u8.byteLength;

  switch (matType) {
    case cv.CV_8UC1:
    case cv.CV_8UC3:
      return new Uint8Array(buffer, byteOffset, byteLength);

    case cv.CV_8SC1:
    case cv.CV_8SC3:
      return new Int8Array(buffer, byteOffset, byteLength);

    case cv.CV_16UC1:
    case cv.CV_16UC3:
      return new Uint16Array(buffer, byteOffset, byteLength / 2);

    case cv.CV_16SC1:
    case cv.CV_16SC3:
      return new Int16Array(buffer, byteOffset, byteLength / 2);

    default:
      throw new Error(`typedArrayFromMat: unsupported matType ${matType}`);
  }
}

export function createPixelArray(matInfo: OpencvMatInfo, totalPx: number, existing?: any): any {
  if (existing?.PixelData && existing.PixelData.length === totalPx) {
    return existing; // reuse
  }

  const newData = Object.assign({}, existing || {});
  newData.PixelData = new matInfo.TypedArrayConstructor(totalPx);
  return newData;
}

/**
 * Write Mat content into given Fovia.ImageData (replaces PixelData)
 * This will set dst.PixelData to a typed-array view on the WASM heap buffer.
 */
export function writeBackToImageData(
  cv: OpenCV,
  mat: any,
  imageData: Fovia.ImageData,
  matType: number,
  signed: boolean
): void {
  if (!mat || !mat.data) {
    throw new Error('writeBackToImageData(): Mat has no data');
  }

  let TypedArray: any;

  // 8-bit depth
  if (
    matType === cv.CV_8UC1 ||
    matType === cv.CV_8UC3
  ) {
    TypedArray = Uint8Array;
  }
  else if (
    matType === cv.CV_8SC1 ||
    matType === cv.CV_8SC3
  ) {
    TypedArray = Int8Array;
  }
  // 16-bit depth
  else if (
    matType === cv.CV_16UC1 ||
    matType === cv.CV_16UC3
  ) {
    TypedArray = Uint16Array;
  }
  else if (
    matType === cv.CV_16SC1 ||
    matType === cv.CV_16SC3
  ) {
    TypedArray = Int16Array;
  }
  else {
    throw new Error(`Unsupported matType in writeBackToImageData: ${matType}`);
  }

  // Copy WASM → JS memory
  const jsOwned = new TypedArray(
    mat.data.buffer.slice(
      mat.data.byteOffset,
      mat.data.byteOffset + mat.data.byteLength
    )
  );

  imageData.PixelData = jsOwned;
}
