// viewer/utils/unsharp-mask.ts
import { OpenCV } from '../service/open-cv.service';
import { IUnsharpMaskParams, IUnsharpMaskRequest } from '../models/unsharp-mask';
import { EDGE_ENHANCEMENT_LEVEL_TYPE } from '../../models/edge-enhancement-level';
import {
  createMatFromImageData, writeBackToImageData, } from '../utils';
import { ImageProcessingDicomInfo } from '../models';

/**
 * Apply unsharp mask (edge enhancement) to src -> dst.
 * @param cv - OpenCV instance
 * @param width - image width (cols)
 * @param height - image height (rows)
 * @param src - source Fovia.ImageData (PixelData must be an appropriate typed array)
 * @param dst - destination Fovia.ImageData (will be overwritten with a JS-owned typed array)
 * @param params - unsharp mask parameters
 * @param matType - OpenCV mat type (e.g. cv.CV_16UC1, cv.CV_16SC1, cv.CV_8UC3, ...)
 *
 * @returns true on success, false on failure
 */
export function unsharpMaskFilter(
  imgInfo: ImageProcessingDicomInfo,
 request: IUnsharpMaskRequest,
 cv: OpenCV
): boolean {
  let srcMat: any = null;
  let dstMat: any = null;
  let srcFloat: any = null;
  let dstFloat: any = null;
  let blur: any = null;

  try {
    const width = imgInfo.width;
    const height = imgInfo.height;
    if (!request || !request.src || !request.src.PixelData || !width || !height || !request.matInfo) {
      console.error('unsharpMaskFilter: source data info missing');
      return false;
    }

    // Create mats from the provided typed arrays
    const matType = request.matInfo.matType;
    srcMat = createMatFromImageData(cv, width, height, matType, request.src.PixelData as any);
    dstMat = createMatFromImageData(cv, width, height, matType, request.dst.PixelData as any);

    // Convert source to float for processing
    srcFloat = new cv.Mat();
    srcMat.convertTo(srcFloat, cv.CV_32F);

    // Prepare float destination and intermediate blur mat
    dstFloat = new cv.Mat(height, width, cv.CV_32F);
    blur = new cv.Mat();

    const ksize = new cv.Size(request.params.kernelSize, request.params.kernelSize);

    // Gaussian blur + addWeighted (unsharp mask)
    cv.GaussianBlur(srcFloat, blur, ksize, request.params.sigma, request.params.sigma, cv.BORDER_DEFAULT);
    cv.addWeighted(srcFloat, 1 + request.params.amount, blur, -request.params.amount, 0, dstFloat);

    // Convert float result back to the requested matType
    dstFloat.convertTo(dstMat, matType);

    // Derive signedness from matType (we need that for writeBackToImageData)
    const isSigned =
      matType === cv.CV_8SC1 ||
      matType === cv.CV_8SC3 ||
      matType === cv.CV_16SC1 ||
      matType === cv.CV_16SC3;

    // Write JS-owned copy back to dst.PixelData
    writeBackToImageData(cv, dstMat, request.dst, matType, isSigned);

    return true;
  } catch (err) {
    console.error('unsharpMaskFilter() failed:', err);
    return false;
  } finally {
    // Free mats if they exist
    try { srcMat?.delete(); } catch (e) {}
    try { dstMat?.delete(); } catch (e) {}
    try { srcFloat?.delete(); } catch (e) {}
    try { dstFloat?.delete(); } catch (e) {}
    try { blur?.delete(); } catch (e) {}
  }
}
export function computeDynamicUnsharpParams(
  level: EDGE_ENHANCEMENT_LEVEL_TYPE,
  pixelSpacing: number[],
): IUnsharpMaskParams {
  const REF_SPACING = 0.14; // calibrated spacing
  const methodName = 'computeDynamicUnsharpParams';
  let pixelSpacingAvg = 0.2;
  if (!pixelSpacing || pixelSpacing[0] > 0) { pixelSpacingAvg = (pixelSpacing[0] + pixelSpacing[1]) / 2; }
  if (level === EDGE_ENHANCEMENT_LEVEL_TYPE.none || pixelSpacingAvg <= 0) {
    return { amount: 0.0, kernelSize: 3, sigma: 0.0 };
  }

  // Physical sigma values from calibrated presets (0.14 mm spacing)
  const sigmaMMTable: Record<EDGE_ENHANCEMENT_LEVEL_TYPE, number> = {
    [EDGE_ENHANCEMENT_LEVEL_TYPE.low]: 3.92,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.medium]: 7.61,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.high]: 14.2,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.none]: 0.0
  };

  const baseAmountTable: Record<EDGE_ENHANCEMENT_LEVEL_TYPE, number> = {
    [EDGE_ENHANCEMENT_LEVEL_TYPE.low]: 1.5,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.medium]: 1.8,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.high]: 2.94,
    [EDGE_ENHANCEMENT_LEVEL_TYPE.none]: 0.0
  };

  const sigmaMM = sigmaMMTable[level];
  const amount = baseAmountTable[level];
  let pspaceRatio = 1;

  // Temporarily adjust sharpening strength according to pixel spacing to mitigate halo artifacts on hand/knee images.
  // Reference chest X-ray images are more enhanced, so we apply a compensation factor.
  pspaceRatio = Math.pow(pixelSpacingAvg / REF_SPACING, 2.0);
  pspaceRatio = Math.max(0.5, Math.min(pspaceRatio, 1.0));

  // Compute sigma in pixels
  const sigma = Math.min(sigmaMM * pspaceRatio, sigmaMMTable[level]);

  // Kernel covering ±3σ, odd integer
  const k = Math.max(1, Math.ceil(3 * sigma));
  const kernelSize = 2 * k + 1;

  console.debug(`${methodName}: level=${level}, pixelSpacing=${pixelSpacing}, amount=${amount.toFixed(2)}, kernelSize=${kernelSize}, sigma=${sigma.toFixed(2)}`);

  return { amount, kernelSize, sigma };
}

