import { IUnsharpMaskParams, IUnsharpMaskRequest } from '../models/unsharp-mask';
import { unsharpMaskFilter } from './unsharp-mask';
import Fovia from 'foviaapi';
import { OpenCvService } from '../service/open-cv.service';
import { OpencvMatInfo } from '../models';

describe('image-filter: unsharpMaskFilter', () => {
  let cv: any;

  const width = 5;
  const height = 5;
  const pixelCount = width * height;

  const generateImageData = (fill: number): Fovia.ImageData => {
    return new Fovia.ImageData(
      new Uint16Array(Array(pixelCount).fill(fill)),
      null,
      [],
      false
    );
  };

  beforeAll(async () => {
    const openCvService = new OpenCvService();
    cv = await openCvService.waitForReady();
    expect(cv).toBeTruthy();
  });

  function buildRequest(src: Fovia.ImageData, dst: Fovia.ImageData, params: IUnsharpMaskParams): IUnsharpMaskRequest {
    const matInfo: OpencvMatInfo = {
      matType: cv.CV_16UC1,              // typical type for 16‑bit single channel
      TypedArrayConstructor: Uint16Array,
      bytesPerElement: 2,                // Uint16Array → 2 bytes per element
      channels: 1
    };
    return {
      src,
      dst,
      width,
      height,
      params,
      matInfo
    };
  }

  it('should enhance edges using unsharp mask', () => {
    const src = generateImageData(1000);
    const dst = generateImageData(0);

    const params: IUnsharpMaskParams = {
      amount: 0.5,
      kernelSize: 3,
      sigma: 1.0,
    };

    const request = buildRequest(src, dst, params);
    const ok = unsharpMaskFilter(request, cv);

    expect(ok).toBeTruthy();
    expect(dst.PixelData.length).toBe(pixelCount);

    const uniqueValues = [...new Set(dst.PixelData)];
    expect(uniqueValues.length).toBe(1);
    expect(uniqueValues[0]).toBe(1000);
  });

  it('should process a simple gradient image without errors', () => {
    const gradientData = new Uint16Array(pixelCount);
    for (let i = 0; i < pixelCount; i++) {
      gradientData[i] = i * 100;
    }

    const src = new Fovia.ImageData(gradientData, null, [], false);
    const dst = generateImageData(0);

    const params: IUnsharpMaskParams = {
      amount: 1.0,
      kernelSize: 5,
      sigma: 1.5,
    };

    const request = buildRequest(src, dst, params);
    const ok = unsharpMaskFilter(request, cv);

    expect(ok).toBeTruthy();
    expect(dst.PixelData.length).toBe(pixelCount);
    expect(dst.PixelData[10]).not.toBe(src.PixelData[10]);
  });

  it('should fail gracefully with invalid parameters', () => {
    const src = generateImageData(500);
    const dst = generateImageData(0);

    const invalidParams: IUnsharpMaskParams = {
      amount: -1,
      kernelSize: 0,
      sigma: -5,
    };

    const request = buildRequest(src, dst, invalidParams);
    const ok = unsharpMaskFilter(request, cv);

    expect(ok).toBeFalsy();
  });
});
