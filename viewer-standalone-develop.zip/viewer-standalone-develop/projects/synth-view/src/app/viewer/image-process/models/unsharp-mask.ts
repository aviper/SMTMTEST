import { OpencvMatInfo } from './opencv-mat-info';
import { ImageProcessingDicomInfo } from './image-meta-info';
import { EDGE_ENHANCEMENT_LEVEL_TYPE } from '../../models';

export const Unsharp_Algo_Params: Record<EDGE_ENHANCEMENT_LEVEL_TYPE, { amount: number; kernelSize: number; sigma: number }> = {
  [EDGE_ENHANCEMENT_LEVEL_TYPE.low]: { amount: 1.5, kernelSize: 7, sigma: 1.92 },
  [EDGE_ENHANCEMENT_LEVEL_TYPE.medium]: { amount: 1.8, kernelSize: 17, sigma: 3.61 },
  [EDGE_ENHANCEMENT_LEVEL_TYPE.high]: { amount: 2.94, kernelSize: 51, sigma: 7.2 },
  [EDGE_ENHANCEMENT_LEVEL_TYPE.none]: { amount: 0.0, kernelSize: 3, sigma: 0.0 },
};

export interface IUnsharpMaskParams {
  amount: number;
  kernelSize: number;
  sigma: number;
}
export interface IUnsharpMaskRequest {
  imgInfo: ImageProcessingDicomInfo;
  src: Fovia.ImageData;                   // Source pixel data
  dst: Fovia.ImageData;
  params: IUnsharpMaskParams;
  matInfo: OpencvMatInfo;
}
