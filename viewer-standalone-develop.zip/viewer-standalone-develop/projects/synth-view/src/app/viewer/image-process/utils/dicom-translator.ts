import { SeriesDisplayStoreItem } from '../../stores';
import { getImageAttributes } from '../../utils';
import { ImageProcessingDicomInfo } from '../models';
import Fovia from 'foviaapi';

export function dicomTagsToImageInfo(imageTags: Fovia.DICOMImageTags): ImageProcessingDicomInfo | null {
  if (!imageTags?.sopInstanceUID) {
    return null;
  }

  return {
    sopInstanceUID: imageTags.sopInstanceUID,
    frameNo: imageTags.frameNumber ?? 0,
    width: imageTags.cols,
    height: imageTags.rows,
    channelCount: imageTags.samplesPerPixel ?? 1,
    bitsAllocated: imageTags.bitsAllocated,
    highBit: imageTags.highBit,
    isSigned: imageTags.pixelRepresentation === 1,
    pixelSpacing: imageTags.pixelSpacing?.split('\\').map(Number),
    pixelPaddingValue: imageTags.pixelPaddingValue,
    rescaleSlope: imageTags.rescaleSlope ?? 1,
    rescaleIntercept: imageTags.rescaleIntercept ?? 0,
    window: imageTags.windowWidth?.split('\\').map(Number),
    level: imageTags.windowCenter?.split('\\').map(Number)
  };
}

/**
 * Extract DICOM image info from a series store item
 */
export function extractDicomImageInfo(seriesStoreItem: SeriesDisplayStoreItem): ImageProcessingDicomInfo | null {
  if (!seriesStoreItem.foviaHtmlViewport || !seriesStoreItem.series) {
    console.warn('DicomTranslator: invalid series store item for image processing info');
    return null;
  }

  const sopInstanceUID = seriesStoreItem.virtualSeries.currentSopInstanceUID;
  if (!sopInstanceUID) {
    console.warn('DicomTranslator: missing SOP Instance UID');
    return null;
  }

  const viewport = seriesStoreItem.foviaHtmlViewport;
  const rp = viewport.getCachedRenderParams() as Fovia.RenderParams2D;
  const imageNum = rp.imageNumber;
  const sdc = viewport.getSeriesDataContext();

  if (!sdc || !sdc.imageTags || imageNum >= sdc.imageTags.length) {
    console.warn('DicomTranslator: invalid series data context or image number');
    return null;
  }

  const imageTags = sdc.imageTags[imageNum];
  const currContext = seriesStoreItem.virtualSeries.currentSeriesDataContext;
  if (!currContext) {
    console.warn('DicomTranslator: no current series data context available');
    return null;
  }

  // Merge channels from getImageAttributes if available
  const dicomTags = seriesStoreItem.series.parentExam.getTagsForInstance(sopInstanceUID);
  const imageAttributes = getImageAttributes(dicomTags, seriesStoreItem.virtualSeries.currentSeriesDataContext,
      seriesStoreItem.virtualSeries.currentImageRef.imageIndex, rp, viewport);

  if (!imageAttributes) {
    console.warn('DicomTranslator: could not get image attributes');
    return null;
  }

  // Override channels from imageAttributes if present
  const info = dicomTagsToImageInfo(imageTags);
  if (info) {
    info.channelCount = imageAttributes.channels;
  }

  return info;
}
