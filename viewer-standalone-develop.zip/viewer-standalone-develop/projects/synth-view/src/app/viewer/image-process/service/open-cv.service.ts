import { Injectable, NgZone } from '@angular/core';
import { IManagedService } from '../../services';
import { Subject } from 'rxjs';

declare global {
  interface Window {
    cv?: any;
    Module?: any;
  }
}

export type OpenCV = any;

@Injectable({
  providedIn: 'root',
})
export class OpenCvService implements IManagedService {
  private unsubscribe$$ = new Subject<void>();

  private isReady = false;
  private cv?: OpenCV;
  private cvReadyPromise?: Promise<OpenCV>;

  private readonly opencvJsUrl = '/viewer/assets/opencv/opencv.js';
  private readonly wasmFileName = 'opencv_js.wasm';

  constructor(private ngZone: NgZone) {}

  public async waitForReady(): Promise<OpenCV> {
    if (this.isReady && this.cv) {
      console.info(`${this.constructor.name}.waitForReady already initialized`);
      return this.cv;
    }

    if (!this.cvReadyPromise) {
      console.info(`${this.constructor.name}.waitForReady loading OpenCV...`);
      this.cvReadyPromise = this.loadOpenCv();
    }

    return this.cvReadyPromise;
  }

  public async reInitData(): Promise<void> {
    this.unsubscribe();
    console.debug(`${this.constructor.name}.reInitData complete`);
  }

  public async reStartSubscriptions(): Promise<void> {
    console.debug(`${this.constructor.name}.reStartSubscriptions`);
    // no recurring subscriptions yet — future CV events can go here
  }

  public async stopProcessing(): Promise<void> {
    this.unsubscribe();
    console.debug(`${this.constructor.name}.stopProcessing`);
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  private loadOpenCv(): Promise<OpenCV> {
    return new Promise((resolve, reject) => {
      // Already loaded?
      if (window.cv) {
        console.info(`${this.constructor.name}.loadOpenCv window.cv already present`);
        this.initCv(window.cv).then(resolve).catch(reject);
        return;
      }

      console.info(`${this.constructor.name}.loadOpenCv loading script ${this.opencvJsUrl}`);

      // Configure WASM loader BEFORE loading script
      window.Module = {
        locateFile: (file: string) =>
          file.endsWith('.wasm')
            ? `/viewer/assets/opencv/${this.wasmFileName}`
            : file,

        onRuntimeInitialized: () => {
          console.log(`${this.constructor.name}.loadOpenCv runtime initialized`);

          if (!window.cv) {
            reject('OpenCV runtime loaded but window.cv missing');
            return;
          }

          this.initCv(window.cv).then(resolve).catch(reject);
        },
      };

      // Inject script
      const script = document.createElement('script');
      script.src = this.opencvJsUrl;
      script.async = true;
      script.defer = true;
      script.onerror = (err) => {
        console.error(`${this.constructor.name}.loadOpenCv failed`, err);
        reject(err);
      };

      document.body.appendChild(script);
    });
  }

  private async initCv(cv: OpenCV): Promise<OpenCV> {
    console.info(`${this.constructor.name}.initCv initializing`);

    this.cv = cv;
    this.isReady = true;

    console.info(`${this.constructor.name}.initCv OpenCV ready`);
    return this.cv;
  }
}
