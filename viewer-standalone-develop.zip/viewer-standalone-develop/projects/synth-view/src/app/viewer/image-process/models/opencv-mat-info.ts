
export interface OpencvMatInfo {
  matType: number;
  TypedArrayConstructor: any; // e.g. Uint8Array, Int16Array
  bytesPerElement: number; // 1 or 2
  channels: number;
}
