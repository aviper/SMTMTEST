export interface ImageProcessingDicomInfo {
  modality?: string;
  sopInstanceUID: string;
  frameNo: number;
  width: number;
  height: number;
  channelCount: number;
  bitsAllocated: number;
  highBit: number;
  isSigned: boolean;
  pixelSpacing: number[];
  pixelPaddingValue?: number;
  rescaleSlope?: number;
  rescaleIntercept?: number;
  window?: number[];
  level?: number[];
}
