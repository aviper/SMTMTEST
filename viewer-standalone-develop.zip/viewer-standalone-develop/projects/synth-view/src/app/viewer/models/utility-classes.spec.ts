import { UtilityClasses } from './utility-classes';

describe('UtilityClasses', () => {
  it('should create an instance', () => {
    expect(new UtilityClasses()).toBeTruthy();
  });
});
