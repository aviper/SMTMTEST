import { VirtualSeries } from './virtual-series';

describe('VirtualSeries', () => {
  it('should create an instance', () => {
    expect(new VirtualSeries()).toBeTruthy();
  });
});
