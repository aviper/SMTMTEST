import { BehaviorSubject, filter, firstValueFrom } from 'rxjs';


// --------------------------------------------------------
// Provide mechanism to detect and protect a resource from simultaneous
// access -- this is required for some Fovia requests
// for example: Some viewport startup scenarios can result in overlapping fovia
// viewport creation requests -- which ultimately results
// in viewport misbehavior - i.e. blank/stuck rendering.
// Provide a common mechanism to mange the init problem
//

export class ResourceGuard {
  private inUse$$ = new BehaviorSubject<boolean>(false);

  // May be called to determine if an await is necessary (optional)
  public get isInUse(): boolean {
    return this.inUse$$.value;
  }

  // Allow caller to await while a resource is in use.
  public async whileInProgress(): Promise<boolean> {
    return firstValueFrom(this.inUse$$.pipe(filter(inUse => !inUse)));
  }

  // Called when guarding is required
  public start(): void {
    this.updateGuard(true);
  }

  // Called when guarding is no longer required
  public finish(): void {
    this.updateGuard(false);
  }

  private updateGuard(inUse: boolean): void {
    this.inUse$$.next(inUse);
    return;
  }

}
