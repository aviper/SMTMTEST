import Fovia from 'foviaapi';

import { PerfMeasure } from '@worker-compatible-api';
import { Bounds, getCurrentZoomFactor } from '../utils';
import { addAnnotationsToRenderEngine, HTMLViewport2DGSPS, makeImageKeyFromImageTags, setRenderEngineActive } from '@server-api';
import { IMAGE_DISPLAY_ALIGNMENT } from './utility-classes';
import { FoviaService } from '../services';
import { getPendingRenderParams2D } from '@server-api';

export const DONT_LET_FOVIA_FIT_TO_VIEWPORT = false;
const LET_FOVIA_FIT_TO_VIEWPORT = true;
export const ALWAYS_FORCE_MIN = false; // reading of Fovia code suggests they don't use this. Choose a consistent policy until we know better.
const MAX_FOVIA_WINDOW_SIZE = 4096;

export class HTMLDoubleBufferViewport2DGSPS extends HTMLViewport2DGSPS {
  private _lastRenderBounds = new Bounds(0, 0);
  private lastRenderCanvasParent: Element | null = null;
  private _clonedAnnotations = new Map<string, Fovia.GraphicAnnotation[]>();
  public lastViewportIdForRender: string | null = null;
  public isMontageViewport = false;

  constructor(
    htmlElementName: string,
    width: number,
    height: number,
    repaintable: boolean = false,
    usePNG: boolean = false,
    renderEngineType: Fovia.RenderLocation = Fovia.RenderLocation.Server,
    isThumbnail: boolean = false) {

    super(htmlElementName, width, height, repaintable, usePNG, renderEngineType, isThumbnail);
    this.doubleBufferInit();
  }

  public canvasIdToViewportId(): string {
    return this.getHTMLElement().id;  // currently, the canvasId and viewportId are identical
  }

  public get lastRenderBounds(): Bounds {
    return this._lastRenderBounds;
  }

  // Annotations to be added to images when first rendered.  This supports adding images to the montage.
  public set clonedAnnotations(annotations: Map<string, Fovia.GraphicAnnotation[]>) {
    this._clonedAnnotations = annotations;
  }

  public alignImageInViewport(imageIndex: number, align: IMAGE_DISPLAY_ALIGNMENT, fitToViewport: boolean, newCanvasBounds?: Bounds, currentOffsetX?: number): number | null {
    if (align === IMAGE_DISPLAY_ALIGNMENT.none) {
      return null;
    }
    const canvas = newCanvasBounds ?? new Bounds(this.getHTMLElement().width, this.getHTMLElement().height);
    const ratio = getCurrentZoomFactor(fitToViewport, this, canvas);
    
    const renderEngine = this.getRenderEngine();
    const { rotate } = renderEngine.getPendingRenderParams();
    const appliedImageWidth = rotate % 2 == 0 ? renderEngine.DicomImageWidth : renderEngine.DicomImageHeight;

    const renderedWidth = appliedImageWidth * ratio;
    const renderedX = (canvas.width - renderedWidth) / 2;
    const targetX = (align === IMAGE_DISPLAY_ALIGNMENT.left) ? 0 : canvas.width - renderedWidth;
    const offsetX = targetX - renderedX;
    if (currentOffsetX) {
      if (align === IMAGE_DISPLAY_ALIGNMENT.left) {
        if (currentOffsetX < offsetX) {
          return currentOffsetX;
        }
      } else if (align === IMAGE_DISPLAY_ALIGNMENT.right) {
        if (currentOffsetX > offsetX) {
          return currentOffsetX;
        }
      }
    }
    return offsetX;
    // console.log(`alignImageInViewport - canvas=${canvas.toString()} image=${image.toString()} ratio=${ratio.toFixed(2)} renderedWidth=${renderedWidth.toFixed(0)} renderedX=${renderedX.toFixed(0)} targetX=${targetX.toFixed(0)} offsetX=${offsetX.toFixed(0)}`);
  }

  public async renderFinalToCanvasBounds(rp: Fovia.RenderParams2D, fitViewport: boolean, newCanvasBounds?: Bounds): Promise<void> {
    const perf = new PerfMeasure('renderFinalToCanvasBounds');
    perf.start();
    const canvasBounds = newCanvasBounds ?? new Bounds(this.htmlElement.width, this.htmlElement.height);
    const canvasParent: Element = this.getHTMLElement().parentElement;

    const tags = this.seriesDataContext.imageTags[rp.imageNumber];
    const imageKey = makeImageKeyFromImageTags(tags);
    const clonedImageAnnotations = this._clonedAnnotations.get(imageKey) ?? [];

    if (this._lastRenderBounds.isEqualTo(canvasBounds) && this.lastRenderCanvasParent === canvasParent && clonedImageAnnotations.length === 0) {
      setRenderEngineActive(this, false);
      await this.getRenderEngine().setRenderParams(rp, Fovia.RenderRequest.renderFinal);
      perf.end({ detail: 'setRenderParams w/ renderfinal' });

    } else {
      addAnnotationsToRenderEngine(clonedImageAnnotations, tags.sopInstanceUID, tags.frameNumber, this);
      this._clonedAnnotations.delete(imageKey);

      if (this.isThumbnail) {
        // Thumbnails don't abide by our true size settings so it's best to let fovia fit-to-viewport
        await this.resizeWindow(canvasBounds.width, canvasBounds.height, true, ALWAYS_FORCE_MIN);
      } else {
        await this.resizeWindow(canvasBounds.width, canvasBounds.height, fitViewport, ALWAYS_FORCE_MIN);
      }
      perf.end({ detail: 'setRenderParams plus resizeWindow' });
    }
    this._lastRenderBounds = canvasBounds;
    this.lastViewportIdForRender = this.canvasIdToViewportId();
    this.lastRenderCanvasParent = canvasParent;
  }

  public override async resizeWindow(width: number, height: number, fitViewport: boolean, useMax: boolean = ALWAYS_FORCE_MIN): Promise<void> {
    try {
      setRenderEngineActive(this, false);
      // Fovia's resizeWindow() will convert height and width to modulo of 16. We don't want that because for MG, images won't be stretch to the viewport boundary.
      // So do not call fovia's resizeWindow().
      // super.resizeWindow(this.limitToFoviaMaxSize(width), this.limitToFoviaMaxSize(height), DONT_LET_FOVIA_FIT_TO_VIEWPORT, ALWAYS_FORCE_MIN);

      const _width = this.limitToFoviaMaxSize(width);
      const _height = this.limitToFoviaMaxSize(height);
      if (!Fovia.Util.isNumber(_width) || !Fovia.Util.isNumber(_height) || _width < 16 || _height < 16 || _width > 4096 || _height > 4096) {
        console.error('Invalid resizeWindow width/height ' + _width + '//' + _height);
        return;
      }
      const canvasBounds = new Bounds(_width, _height);
      const dontCare = true;
      this.resizeCanvas(_width, _height, dontCare, dontCare);
      const rp = getPendingRenderParams2D(this);
      rp.imageWidth = _width;
      rp.imageHeight = _height;
      rp.zoom = getCurrentZoomFactor(fitViewport, this, canvasBounds);
      // console.log(`resizeWindow: ${this.getHTMLElement().id}  zoom:${rp?.zoom} adjustZoom ${adjustZoom} useMax ${useMax}`, rp, canvasBounds);
      await this.getRenderEngine().setRenderParams(rp, Fovia.RenderRequest.renderFinal);
      this._lastRenderBounds = new Bounds(_width, _height);
      this.lastViewportIdForRender = this.canvasIdToViewportId();
      this.lastRenderCanvasParent = this.getHTMLElement().parentElement;
    } catch (err) {
      console.error(`Fovia viewport resize window failed. ${this.canvasIdToViewportId()}`);
    }
  }

  public override renderFinal(): any {
    setRenderEngineActive(this, false);
    const ret = super.renderFinal();
    this.lastViewportIdForRender = this.canvasIdToViewportId();
    this.lastRenderCanvasParent = this.getHTMLElement().parentElement;
    return ret;
  }
  private limitToFoviaMaxSize(size: number): number {
    return size <= MAX_FOVIA_WINDOW_SIZE ? size : MAX_FOVIA_WINDOW_SIZE; // this could cause an image to lose it's aspect ratio on screen.. probably
  }

  // Overriding resizeCanvas in order to address viewport flash when scrolling through virtual series after it has been assigned to
  // a Viewport Component.  A canvas element is cleared whenever its size is updated, even if it's just set back to its current size.
  // The code below only updates the canvas size if the new size is different from its existing size.
  public override resizeCanvas(width: number, height: number, _: boolean, __: boolean): void {
    // This if condition is not in the base version of this method
    if (this.htmlElement.width !== width || this.htmlElement.height !== height) {
      this.htmlElement.width = width;
      this.htmlElement.height = height;
    }

    if ((this as any).doubleBuffer) {
      (this as any).canvas2.width = width;
      (this as any).canvas2.height = height;
    }
    let currElement = this.htmlElement;
    this.offsetX = 0;
    this.offsetY = 0;
    while (currElement != null) {
      this.offsetX += currElement.offsetLeft;
      this.offsetY += currElement.offsetTop;
      currElement = currElement.offsetParent;
    }
  }

  public override renderNoCachedImages(data: any): void {
    if (this.htmlElementName === FoviaService.undisplayedViewportCanvasName) {
      return;
    }
    setTimeout(() => {
      const context = this.htmlElement.getContext('2d');
      context.clearRect(0, 0, this.htmlElement.width, this.htmlElement.height);
      context.font = (this.isThumbnail ? '1rem' : '1.25rem') + ' Inter,san-serif';
      context.textAlign = 'center';
      context.fillStyle = 'white';
      let loadingLabel;
      if (!Fovia.FoviaAPI.FoviaPrivate.nodeServer.isServerOnline()
        && this.renderEngine.getRenderEngineLocation() === Fovia.RenderLocation.Server) {
        loadingLabel = ' Image is not available since server is offline';
      } else if (this.renderEngine.getRenderEngineLocation() === Fovia.RenderLocation.Client) {
        // loadingLabel = " Image " + (data.renderParams.imageNumber + 1) + " is not yet cached.";
        loadingLabel = `Missing Image`;
      } else {
        // loadingLabel = " Image " + (data.renderParams.imageNumber + 1) + " not available in the server.";
        loadingLabel = `Missing Image`;
      }
      context.fillText(loadingLabel, this.htmlElement.width / 2, this.htmlElement.height / 2);

    }, 0);
  }
}
