import Fovia from 'foviaapi';
import { SynthPoint } from './utility-classes';

export enum RULER_TYPE {
  NONE = 0,
  FIVE_CM,
  TEN_CM
}

export function drawRuler(canvas: HTMLCanvasElement, zoom: number, pixelSpacing: string): void {
  new RulerConfig(canvas, zoom, pixelSpacing).draw();
}

export class RulerConfig {
  constructor(
    private canvas: HTMLCanvasElement,
    private zoom: number,
    private pixelSpacing: string,
    readonly imagePixelSpacing: number | null = null,
    private width: number = 0,
    private type: RULER_TYPE = RULER_TYPE.NONE) {

    const tmp = this.pixelSpacing.split('\\');
    if (tmp.length === 2) {
      const dicomPixelSpacing = new SynthPoint(parseFloat(tmp[0]), parseFloat(tmp[1]));
      this.imagePixelSpacing = dicomPixelSpacing.x / this.zoom;
      this.calculate();
    }
  }

  public draw(): void {
    if (this.type !== RULER_TYPE.NONE && this.width > 30) {
      const context: CanvasRenderingContext2D | null = this.canvas.getContext('2d');

      if (context != null) {
        const y: number = this.canvas.height - (this.canvas.height > 200 ? this.canvas.height / 100 : 4);
        const startPoint: Fovia.Util.Point = new Fovia.Util.Point(Math.floor((this.canvas.width / 2) - (this.width / 2)), y);
        const endPoint: Fovia.Util.Point = new Fovia.Util.Point(startPoint.x + this.width, y);

        context.lineWidth = 2;
        context.fillStyle = '#a8a8a8';
        context.strokeStyle = '#a8a8a8';
        context.shadowColor = '#a8a8a8';

        context.beginPath();
        context.moveTo(startPoint.x, startPoint.y - 7);
        context.lineTo(startPoint.x, startPoint.y);
        context.moveTo(endPoint.x, endPoint.y - 7);
        context.lineTo(endPoint.x, endPoint.y);
        context.stroke();

        context.shadowColor = '#000000';
        context.beginPath();
        context.moveTo(startPoint.x, startPoint.y);
        context.lineTo(endPoint.x, endPoint.y);
        context.stroke();

        context.beginPath();
        const numTicks: number = this.type === RULER_TYPE.TEN_CM ? 10 : 5;
        for (let tick = 1; tick < numTicks; tick++) {
          const x = this.width / numTicks * tick;
          context.moveTo(startPoint.x + x, startPoint.y - 4);
          context.lineTo(startPoint.x + x, startPoint.y);
        }
        context.stroke();

        context.font = '12px inter';
        context.fillStyle = '#FFFFFF';
        context.strokeStyle = '#FFFFFF';
        context.shadowColor = '#000000';
        context.shadowOffsetX = 1;
        context.shadowOffsetY = 1;
        context.textAlign = 'center';

        context.fillText(this.labelFromType(), startPoint.x + ((endPoint.x - startPoint.x) / 2), startPoint.y - 10);
      }
    }
  }

  private labelFromType(): string {
    switch (this.type) {
      case RULER_TYPE.NONE: {
        return '';
      }
      case RULER_TYPE.FIVE_CM: {
        return '5cm';
      }
      case RULER_TYPE.TEN_CM: {
        return  '10cm';
      }
    }
  }

  private calculate(): void {
    if (this.imagePixelSpacing != null) {

      let maxRulerLength: number = (this.canvas.width * 0.6) * this.imagePixelSpacing;

      if (maxRulerLength >= 100) {
        // use the 10cm marker
        this.type = RULER_TYPE.TEN_CM;
        maxRulerLength = 100;
      } else if (maxRulerLength >= 50) {
        // use the 5cm marker
        this.type = RULER_TYPE.FIVE_CM;
        maxRulerLength = 50;
      } else {
        this.type = RULER_TYPE.NONE;
        return;
      }
      this.labelFromType();

      let currentDecimalPlace = 1;
      while ((Number((maxRulerLength / currentDecimalPlace).toFixed(0)) > 10)) {
        currentDecimalPlace *= 10;
      }

      this.width = (Number((maxRulerLength / currentDecimalPlace).toFixed(0)) * currentDecimalPlace) / this.imagePixelSpacing;
    }
  }
}
