export interface CompareModeExamInfo {
  examId: number;
  rowIndex: number;
  thumbnailIds: string[];
  firstVisibleColumn: number;
}
export interface SeriesSelection {
  thumbnailId: string;
  rowIndex: number;
  columnIndex: number;
  visibleColumnIndex?: number;
}
export interface AlignedSeriesInfo {
  rowIndex: number;
  thumbnailId: string | null;
}

export interface ThumbnailScrollLayout {
  stride: number;
  viewportRemainder: number;
  spacerCount: number;
  firstVisibleColumn: number;
}

