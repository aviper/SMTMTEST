import { UserInputEvent } from './user-input-event';

describe('UserInputEvent', () => {
  it('should create an instance', () => {
    expect(new UserInputEvent()).toBeTruthy();
  });
});
