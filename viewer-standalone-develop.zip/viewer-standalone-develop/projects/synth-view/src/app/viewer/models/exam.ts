import { VirtualSeries } from './virtual-series';
import { MAMMO_VIEW_TYPE, MammoInfo } from './mammo-info';
import { DICOMWindowLevelInfo } from './window-level-info';

enum DICOM_AI_DESCRIPTION {
  XRChestViewPosition = "SynthAI XR Chest View Position",
  XRLumbarSpineViewPosition = "SynthAI XR Lumbar Spine View Position",
  MGBreastLabelling = "SynthAI MG Breast Labelling",
}

import Fovia from 'foviaapi';
import {
  CineSpeedOptions,
  DICOM_TAGS, ExamLoadContext, getTagValueAsNumber, getTagValueAsString, GSPSUtils, HangingProtocol,
  HangingProtocolDoNotDisplaySeriesRules, IDicomInstance, IFoviaStudySRData, makeImageKey, makeImageKeyFromImageTags,
  makeCopiedImageKey, PresentationInfo,
  SOP_CLASS, DicomTags,
  DICOM_ALLTAGS,
  CURRENT_AI_SERIES_DESC,
  AIDescriptionNameMapper,
} from '@server-api';
import { ChestFlickerService, ImageFrameSelection, MAMMO_PRESENTATION_STACK, MammoPresentationService } from '../services';
import { MammoFlickerService } from '../services';
import dayjs from 'dayjs';
import { FLICKER_STACK, FlickerExamInfo } from './flicker-exam-info';
import { ExamSeries } from './exam-series';
import { sortImageSetForMammo, VirtualSeriesImageSet } from './virtual-series-image-set';
import { ExamSource } from './exam-source';
import SeriesDataContext = Fovia.SeriesDataContext;
import { BoundingBox, SynthAiInferences } from './synth-ai-inferences';
import { patchFoviaImageTag, validateBreastLabelingInference, validateViewPositionInference } from '../utils';
import { SUVInfo } from './suv-info';
import { FusionSeriesSet } from './fusion-series-set';
import { WLInfo } from './window-level';
import { MammoCADSrInfo } from './mammocadsr-info';

export type DicomTagMap = Map<string, DicomTags>;
export type UIDMap = Map<CURRENT_AI_SERIES_DESC, Array<string>>;

export class Exam {
  private readonly _originalImageSeries: Array<ExamSeries>;
  private readonly virtualImageSeries: Array<VirtualSeries> = [];
  private readonly _imageSeries3D: Array<VirtualSeries> = [];
  private readonly _storedKeyImageSeries: Array<VirtualSeries> = []; // Key images that are already part of study if any
  private readonly _keyImageSeries: Array<VirtualSeries> = [];       // Current key image series list, may have been edited
  private readonly _nonImageSeries: Array<string> = []; // List of sop instances

  private readonly _studyInstanceUID: string;
  // Maps a Dicom SOP instance ID to its set of related tags returned by Fovia.
  private _dicomTagsMap: DicomTagMap = new Map();
  private _mammoInfoMap: Map<string, MammoInfo> = new Map();
  private _suvInfoMap: Map<string, SUVInfo> = new Map();
  private _windowLevelInfoMap: Map<string, DICOMWindowLevelInfo> = new Map();
  private displayStudyDate = '';
  private _timeExamDisplayed: number | null = null;
  private _fusionSeriesSet: FusionSeriesSet | null = null;  // just track one per exam for now

  private aiSrMap: UIDMap;
  private synthAiData: SynthAiInferences;

  // tracks CAD findings
  private cadFindingsBySopInstance: Map<string, Array<Fovia.CADFindingsInfo>> = new Map<string, Fovia.CADFindingsInfo[]>;
  private cadPresentations: Map<string, any> = new Map<string, any>;
  private _totalCadFindings: number | null = null;

  // track viewed images. Map is <imageKey, seriesUID>
  private _viewedImages: Map<string, string> = new Map<string, string>();

  // track deleted images
  private deletedImages: Set<string> = new Set<string>();
  private deletedSeries: Set<string> = new Set<string>();

  // track user calibrated images. Map is <imageKey, user calibrated pixel spacing in mm>
  private _userCalibratedImages: Map<string, number> = new Map<string, number>;

  // track referenced sop instance uids by <instanceuid, referenceduid>
  private referencedSopInstanceUIDS: Map<string, string> = new Map<string, string>();

  // track referenceSopInstanceUIDS from MG CAD SR
  private mammoCADSrRefSopInstanceUIDS: Set<string> = new Set<string>();

  constructor(
    private _source: ExamSource,
    private _foviaExam: Fovia.ScanDirSeriesResults[],
    allDicomTags: any[] | undefined,
    private hangingProtocol: HangingProtocol,
    private mammoPresentationService: MammoPresentationService,
    private chestFlickerService: ChestFlickerService,
    private mammoFlickerService: MammoFlickerService,
    private _isPrimary: boolean,
    private _isViewerSplitMode: boolean,
    private _examLoadContext: ExamLoadContext
  ) {
    this.synthAiData = new SynthAiInferences();

    this._studyInstanceUID = _source.instanceId as string;

    if (this._isPrimary) {
      GSPSUtils.getInstance().primaryStudyInstanceUID = this._studyInstanceUID;
    }

    // todo: sanity check - should exam creation be stopped if this fails?
    this.sanityCheck(_foviaExam);

    // this.logFoviaSeriesInfo(foviaExam);

    this._originalImageSeries = this.constructOriginalExamSeries(_foviaExam);
    this._nonImageSeries = GSPSUtils.getInstance().getAllNonImageSeriesDataList();
    // This call uses this.originalImageSeries, so it must come after that is initialized.
    if (allDicomTags != null) {
      this.initializeDicomTagMaps(allDicomTags);
      // this.validateSDCWLValues(_foviaExam);
      // this.validateSDCSlopeInterceptValues(_foviaExam);
    }
    this.aiSrMap = this.calculateAiSrMap();

    this.virtualImageSeries = this.constructVirtualImageSeries(this.originalImageSeries, this.hangingProtocol);
    this._imageSeries3D = this.construct3dExamSeries(_foviaExam);
    // Holds dynamically created KIs by the user and KIs identified by DICOM KO if any
    this._keyImageSeries = this.constructKeySeries(this.originalImageSeries);
    this._storedKeyImageSeries = [...this._keyImageSeries];
  }

  public reinitForDisplay(): void {
    // This should be done when an exam gets loaded, removed, then reloaded.
    // The constructor doesn't get called the second time so this is an alternate
    // trigger for building the mammo presentations.
    if (this.isMG()) {
      this.constructVirtualSeries_Mammo(this.originalImageSeries);
    }
    this._fusionSeriesSet = null;
  }

  public get foviaExam(): Fovia.ScanDirSeriesResults[] {
    return this._foviaExam;
  }

  public get dicomTagsMap(): DicomTagMap {
    return this._dicomTagsMap;
  }
  public get mammoInfoMap(): Map<string, MammoInfo> {
    return this._mammoInfoMap;
  }

  public get suvInfoMap(): Map<string, SUVInfo> {
    return this._suvInfoMap;
  }

  public get windowLevelInfoMap(): Map<string, DICOMWindowLevelInfo> {
    return this._windowLevelInfoMap;
  }

  public get examLoadContext(): ExamLoadContext {
    return this._examLoadContext;
  }

  public get fusionSeriesSet(): FusionSeriesSet {
    if (this._fusionSeriesSet == null) {
      this._fusionSeriesSet = new FusionSeriesSet();
    }
    return this._fusionSeriesSet;
  }

  public set fusionSeriesSet(set: FusionSeriesSet | null) {
    this. _fusionSeriesSet = set;
  }

  public isMG(): boolean {
    for (let i = 0; i < this.originalImageSeries.length; i++) {
      if (this.originalImageSeries[i].isModalityMG()) {
        return true;
      }
    }
    return false;
  }

  public isPT(): boolean {
    for (let i = 0; i < this.originalImageSeries.length; i++) {
      if (this.originalImageSeries[i].isModalityPT()) {
        return true;
      }
    }
    return false;
  }

  public get originalImageSeries(): ExamSeries[] {
    return this._originalImageSeries;
  }

  public get nonImageSeries(): string[] {
    return this._nonImageSeries;
  }

  public get enabledVirtualImageSeries(): Array<VirtualSeries> {
    return this.virtualImageSeries.filter(series => series.displayByDefault);
  }

  public get allVirtualImageSeries(): Array<VirtualSeries> {
    return this.virtualImageSeries;
  }

  public get allFlickerVirtualSeries(): Array<VirtualSeries> {
    if (this.mammoFlickerService.isActive) {
      return this.mammoFlickerService.getAllStacks(this.isPrimary);
    }
    return this.chestFlickerService.getAllStacks(this.isPrimary);
  }

  public get keyImageSeries(): Array<VirtualSeries> {
    return this._keyImageSeries;
  }

  public get imageSeries3D(): Array<VirtualSeries> {
    return this._imageSeries3D;
  }

  public get totalCadFindings(): number | null {
    return this._totalCadFindings;
  }

  public getCadFindingsByKey(key: string): number | null {
    const cadFindings = this.cadFindingsBySopInstance.get(key);
    if (cadFindings) {
      return cadFindings.length;
    }
    return null;
  }

  // User's who have the right to edit a saved KO panel may do so as part of the 'addendum workflow'
  // We save a copy of the KO image series when the exam is loaded and are assuming This is the
  // only place where KI deletions are detected. These will only be deleted if the user has enough rights to
  // perform the deletion
  public get deletedSopInstances(): Array<IDicomInstance> {
    const deletedSopInstances: Array<IDicomInstance> = [];
    const deletedKeys: string[] = [];
    if (!this.isPrimary) {
      // We don't allow deletion of key images from non-primary exams
      return deletedSopInstances;
    }
    if (!this.hasSavedKeyObjectSeriesChanges) {
      return deletedSopInstances;
    }
    for (const keyItem of this._storedKeyImageSeries) {
      if (keyItem.koImageKey == null) {
        console.error(`${this.constructor.name}.deletedSopInstances unexpected condition koImageKey may not be null for a saved Key image ${keyItem.toString()}`);
        continue;
      }
      const index = this.keyImageSeries.findIndex((entry) => entry.koImageKey === keyItem.koImageKey);
      if (index === -1) {
        // Not found, this keyItem must have been removed
        // ensure this item is not already in our list and qualifies to be deleted
        // This use-case occurs if we're processing a KO object which is referring to the images within an exam
        // (as we did for Synthesis KO 1.0-1.3). Two KO images could refer to the same sop-instance in separate
        // 'frames' of the KO object.
        const deletedIndex = deletedKeys.findIndex(item => item === keyItem.koImageKey);
        if (deletedIndex > -1) {
          console.info(`${this.constructor.name}.deletedSopInstances skipping duplicate sopinstance for ${keyItem.toString()}`);
          continue;
        }
        if (keyItem.currentSeriesDataContext == null) {
          console.error(`${this.constructor.name}.deletedSopInstances unable to delete key image ${keyItem.toString()} sdc is null`);
          continue;
        }
        // Ensure it meets the criteria for being deleted non-Synthesis KO's and Synthesis 1.0 KO's refer to original series images,
        // so we need to be careful that these are not deleted.
        // For now, do not allow deletion of a Unity Montage.
        if (!keyItem.currentExamSeries?.isSynthesisMontage) {
          console.info(`${this.constructor.name}.deletedSopInstances unable to delete key image ${keyItem.toString()} series is not a synthesis montage image`);
          continue;
        }
        // we're certain this deletion is OK if it's also a SC image, don't want to delete the original exam images by accident!
        if (keyItem.currentSopClassUID !== SOP_CLASS.SC) {
          console.info(`${this.constructor.name}.deletedSopInstances only 'SC' sop class images may be deleted as key image ${keyItem.toString()} sop class is ${keyItem.currentSopClassUID}`);
          continue;
        }
        // This image is part of a stored Key Image, and will be deleted if the user has rights
        const instance: IDicomInstance = {
          studyInstanceUID: this.studyInstanceUID,
          seriesInstanceUID: keyItem.currentSeriesDataContext.seriesInstanceUID,
          sopInstanceUID: keyItem.currentSopInstanceUID
        };
        deletedSopInstances.push(instance);
        deletedKeys.push(keyItem.koImageKey);
      }
    }
    // Finally, add the old KO object which must also be removed -- we remove this anytime there are
    // changes to a KO, even when Key images are not removed.
    const koInstance = GSPSUtils.getInstance().getMostRecentKOInstanceUID(this.studyInstanceUID);
    if (koInstance != null) {
      deletedSopInstances.push(koInstance);
    } else {
      console.error(`${this.constructor.name}.getDeletedSopInstances no KO found to associate with KO modifications for ${this.studyInstanceUID} no KO deletion will be performed`);
    }
    console.log(`deleting sopinstances from ${this.studyInstanceUID}`, deletedSopInstances);
    return deletedSopInstances;
  }

  public static doesModalityNeedTags(_m: string): boolean {
    // We don't absolutely need tags for all exam types, but ultimately it would be nice for this to be the only
    // source for DICOM information, period. Currently we still use what's in the SDC for quite a bit of stuff.
    // const modality = m.toUpperCase();
    // return Exam.isMammo(modality) || Exam.isModalityXR(modality) || modality === 'US' || modality === 'XA';
    return true;
  }

  public static isModalityXR(m: string): boolean {
    const modality = m.toUpperCase();
    return ['CR', 'DR', 'DX', 'XR'].includes(modality);
  }

  public static isCrossSectionalModality(m: string): boolean {
    const modality = m.toUpperCase();
    return modality === 'CT' || modality === 'MR' || modality === 'PT' || modality === 'NM';
  }

  public static isMammo(modality: string): boolean {
    return modality.toUpperCase() === 'MG';
  }

  public get source(): ExamSource {
    return this._source;
  }

  public get studyInstanceUID(): string {
    return this._studyInstanceUID;
  }

  public get studyDate(): string {
    // let studyDate = '';
    // if (this.dicomTagsMap.has(this.originalImageSeries[0].getImageInstanceUID(0))) {
    //   studyDate = this.originalImageSeries[0].getTagValueAsString(this.originalImageSeries[0].getImageInstanceUID(0), DICOM_TAGS.STUDY_DATE) ?? '';
    // } else {
    //   studyDate = this.foviaExam[0].dicomSeries.studyDate;
    // }

    this.displayStudyDate = this.foviaExam[0].dicomSeries.studyDate;
    // return studyDate;
    return this._foviaExam[0].dicomSeries.studyDate;
  }

  public get studyTime(): string {
    return this.foviaExam[0].dicomSeries.studyTime;
  }

  public get isPrimary(): boolean {
    return this._isPrimary;
  }

  public get is3DableStudy(): boolean {
    return this._imageSeries3D.length > 0;
  }

  // TODO this is temporary until it gets added to hanging protocol config
  public get isPowereWheelableStudy(): boolean {
    return this.isCrossSectionalModalityExam(this.originalImageSeries);
  }

  public getTimeExamDisplayed(): number | null {
    return this._timeExamDisplayed;
  }

  public neverDisplayed(): boolean {
    return this._timeExamDisplayed == null;
  }

  public markDisplayed(): void {
    this._timeExamDisplayed = Date.now();
  }

  public get hasKeyObjectSeriesChanges(): boolean {
    // 1. Study has a stored KO
    if (this.hasStoredKeyObject) {
      return this.hasSavedKeyObjectSeriesChanges;
    }
    // 2. User made a new KO series, which didn't previously exist
    return this._keyImageSeries.length > 0;
  }

  // Are we modifying a saved key object?
  public get hasSavedKeyObjectSeriesChanges(): boolean {
    // 1. Study has a stored KO
    if (!this.hasStoredKeyObject) {
      return false;
    }
    // 2. The our stored key images have been modified
    return !(this._storedKeyImageSeries.length === this._keyImageSeries.length &&
        this._storedKeyImageSeries.every((value, index) => value.hasSameImageRefs(this._keyImageSeries[index])));
  }

  /*
  1.2.0 - Our original implementation of Key Images
    * Simply created a KO panel which referred to other images that were in the primary exam.
    * References to comparison exams images was not supported.
    * Third Party KO panels could be presented. They too prevent creation of a new KO Panel
    * Single images of a Multi frame images could be added to the KO Panel
    * The KO series thumbnails was displayed at the bottom of the panel
    * Images at the bottom of the panel were kept in the same order as the images in the panel itself 1..n
    * Users could drag/drop/swap images on the KO panel and they would change location in the thumbnail panel
    * The user could add any number of KO images
    * a maximum of 12 KO images could be shown on a single panel
    * Once a primary study had saved a KO panel, it was no longer editable
  1.3.0 - We added the ability to show a DR Systems Unity Montage image as the KO image for a study
  2.0.0 - We expanded on a users ability to create and edit a KO panel:
    * Primary single and multi frame images that are added to the KO panel are saved back to the primary study as
        single frame Secondary capture RGB images.
    * GSPS Annotations are burned into the image.
    * Comparison images could be added to the KO panel, and they too are saved to the primary study as SC RGB images
    * All KO images are held in the same series instance uid.
    * The KO is assigned the same series instance uid.
    * Only a saved Synthesis KO panel can be 'edited' by a user with sufficient rights
      * Images may be added to the existing KO
      * Some or all images may be removed from the existing KO
      * Addition of annotations to an existing KO image is not supported - the image must be removed and re-added.
      * Because DICOM doesn't make provision to truly edit a sop instance:
        * Editing results in a new KO being created
        * Editing results in the old KO being deleted from the DICOM store
        * Newly added images are added to the existing KO series and are assembled into a single SC Montage saved to the DICOM store.
        * The user must explicitly delete the old montage if they don't want it included in the new montage.
        * User's may not delete single images from a Saved Montage w/o recreating an entire montage.
    * A saved 3rd Party KO panel may not be edited.
    * Deletion of original study images is not part of this capability - although the core capability that we've added
        to the system can be used for this purpose.
  */

  public createKeyImage(series: VirtualSeries, keyImageInfo: ImageFrameSelection, keyImageAnnotations: Fovia.GraphicAnnotation[]): VirtualSeries | null {
    // We need a distinct Virtual image series for each keyImage.
    const newSeries = this.constructVirtualSeries_KeyObject(series, keyImageInfo.imageNumber, keyImageAnnotations);
    if (newSeries == null) {
      console.error(`createKeyImage failed to create a new KeyImage`);
      return newSeries;
    }
    // console.log(`createKeyImage request: ${keyImageInfo.toString()}`);
    // console.log(`createKeyImage  result: ${newSeries.toString()}`);
    return newSeries;
  }

  public hasKeyImage(sopInstanceUID: string, frameNumber: number): boolean {
    return this.keyImageExists(makeImageKey(sopInstanceUID, frameNumber));
  }

  public hasColorKeyImage(): boolean {
    return this._keyImageSeries.find(vSeries => {
        const tags = vSeries.currentImageRef.sdcTags;
        return (tags != null && !tags.photometricInterpretation.startsWith('MONOCHROME'));
      }
    ) != null;
  }

  // Returns true if the keyImage was added
  public addKeyImage(keyImage: VirtualSeries): boolean {
    if (this.keyImageExists(makeImageKey(keyImage.currentSopInstanceUID, keyImage.currentFrameNumber))) {
      let copyNumber = 1;
      let foundCopyNumber = false;
      while (!foundCopyNumber) {
        const copyImageKey = makeCopiedImageKey(keyImage.currentSopInstanceUID, keyImage.currentFrameNumber, copyNumber);
        if (!this.keyImageExists(copyImageKey)) {
          foundCopyNumber = true;
          keyImage.koImageKey = copyImageKey;
        } else {
          copyNumber++;
        }
      }
    }
    this._keyImageSeries.push(keyImage);
    // console.log(`${this.constructor.name}.addKeyImage ${keyImage.toString()}`);
    return true;
  }

  // Returns the keyImage that was removed
  public removeKeyImage(sopInstanceUID: string, frameNumber: number): VirtualSeries | null {
    const imageKey = makeImageKey(sopInstanceUID, frameNumber);
    return this.removeKeyImageByImageKey(imageKey);
  }

  public removeKeyImageByImageKey(imageKey: string): VirtualSeries | null {
    const index = this.findKeyImageIndex(imageKey);
    if (index !== -1) {
      const keyImage = this._keyImageSeries[index];
      this._keyImageSeries.splice(index, 1);
      return keyImage;
    }
    return null;
  }

  public deleteImage(imageKey: string): void {
    this.deletedImages.add(imageKey);
  }

  public isImageDeleted(imageKey: string): boolean {
    return this.deletedImages.has(imageKey);
  }

  public deleteSeries(seriesUID: string): void {
    this.deletedSeries.add(seriesUID);
  }

  public isSeriesDeleted(seriesUID: string): boolean {
    return this.deletedSeries.has(seriesUID);
  }

  public swapKeyImages(keyImage1: VirtualSeries, keyImage2: VirtualSeries | null): boolean {
    if (keyImage1.koImageKey === null) {
      console.error(`${this.constructor.name}.swapKeyImages failed keyImage1 ${keyImage1.toString()} koImageKey is null`);
      return false;
    }

    if (keyImage2 !== null && keyImage2.koImageKey === null) {
      console.error(`${this.constructor.name}.swapKeyImages failed keyImage2 ${keyImage2.toString()} koImageKey is null`);
      return false;
    }

    const ki1 = keyImage1.koImageKey;
    const index1 = this._keyImageSeries.findIndex((entry: VirtualSeries) => entry.koImageKey === ki1);

    if (index1 === -1) {
      console.warn(`${this.constructor.name}.swapKeyImages failed keyImage1 ${ki1} not found in keyImageSeries for exam `);
      return false;
    }

    if (keyImage2 == null) {
      // move ki1 to the end
      const keyImage = this._keyImageSeries[index1];
      this._keyImageSeries.splice(index1, 1);
      this._keyImageSeries.push(keyImage);
      // console.log(`${this.constructor.name}.swapKeyImages destination is null, append ${ki1} to the end`, this._keyImageSeries);
      return true;
    }

    const ki2 = keyImage2.koImageKey;
    const index2 = this._keyImageSeries.findIndex((entry: VirtualSeries) => entry.koImageKey === ki2);
    if (index2 === -1) {
      console.warn(`${this.constructor.name}.swapKeyImages failed keyImage2 ${keyImage2.toString()} not found in keyImageSeries for exam`);
      return false;
    }

    this._keyImageSeries[index1] = keyImage2;
    this._keyImageSeries[index2] = keyImage1;
    // console.log(`${this.constructor.name}.swapKeyImages ${ki1} and ${ki2}`, this._keyImageSeries);
    return true;
  }

  // Debug helper. The index doesn't change and is easier to read than a UID
  public getImageSeriesIndex(targetSeries: VirtualSeries): number {
    return this.virtualImageSeries.findIndex(series => (targetSeries === series));
  }

  public compareDateTime(exam: Exam): number {
    if (exam.studyDate === this.studyDate && exam.studyTime === this.studyTime) {
      return 0;
    } else if (exam.studyDate !== this.studyDate) {
      if (dayjs(exam.studyDate).isBefore(this.studyDate)) {
        return -1;
      } else {
        return 1;
      }
    } else {
      if (dayjs(exam.studyTime).isBefore(this.studyTime)) {
        return -1;
      } else {
        return 1;
      }
    }
  }

  public getTagValueAsString(instanceUID: string, tagID: string): string | null {
    const tags = this.dicomTagsMap.get(instanceUID);
    if (tags) {
      return getTagValueAsString(tags, tagID);
    }
    return null;
  }

  public getTagsForInstance(instanceUID: string): DicomTags | undefined {
    return this.dicomTagsMap.get(instanceUID);
  }

  public broadcastImageTagsUpdateAcrossSubSeries(
      studyUID: string,
      seriesUID: string,
      sopInstanceUID: string,
      sourceSubSeriesID: number,
      seriesImageTags: Fovia.DICOMImageTags[],
      imageIndex: number,
      fieldNames: string[],
      fieldValues: any): void {
    if (this.studyInstanceUID !== studyUID) {
      console.warn(`Incorrect W/L may be observed; mismatched studyInstanceUID ${this.studyInstanceUID} => ${studyUID}; not broadcasting tag update for ${sopInstanceUID}`, fieldNames);
      return;
    }
    const examSeries = this.originalImageSeries.find(examSeries => (examSeries.seriesInstanceUID === seriesUID));
    if (examSeries == null) {
      console.warn(`Incorrect W/L may be observed; cannot find study ${studyUID} series ${seriesUID}; not broadcasting tag update for ${sopInstanceUID}`, fieldNames);
      return;
    }
    if (!examSeries.foviaSeries) {
      console.warn(`Incorrect W/L may be observed; exam ${studyUID} series ${seriesUID} has no foviaSeries`, fieldNames);
      return;
    }
    if (!seriesImageTags) {
      console.warn(`Incorrect W/L may be observed; `);
    }
    if (imageIndex < 0 || imageIndex >= seriesImageTags.length) {
      console.warn(`Incorrect W/L may be observed; invalid image index ${imageIndex} (upper bound ${seriesImageTags.length})`);
      return;
    }
    if (!examSeries.foviaSeries.containsSubSeries || examSeries.foviaSeries.subSeries == null) {
      return; // No subseries to broadcast to
    }
    const subSeriesCount = examSeries.foviaSeries.subSeries.length;
    const sourceImageTag = seriesImageTags[imageIndex];
    const sourceFrameNbr = sourceImageTag.frameNumber;
    if (sourceImageTag.sopInstanceUID !== sopInstanceUID) {
      console.warn(`Incorrect W/L may be observed; not broadcasting tag update for ${sopInstanceUID} due to image index ${imageIndex} mismatch`);
      return;
    }
    // At this point, there are sub-series, and tag values need to be propagated out.
    for (let subSeriesIndex = 0; subSeriesIndex < subSeriesCount; ++subSeriesIndex) {
      const subSeriesTags = examSeries.foviaSeries.subSeries[subSeriesIndex].imageTags;
      for (const candidateTag of subSeriesTags) {
        if (candidateTag.sopInstanceUID === sopInstanceUID && candidateTag.frameNumber === sourceFrameNbr) {
          // The SOP instance UID and frame number match. Patch the candidateTag.
          patchFoviaImageTag(candidateTag, fieldNames, fieldValues);
          // ASSUMPTION: There's only one occurrence of a particular SOP instance UID + frameNumber
          // pair within a Fovia-defined subseries (we do not assume this is true for a virtual series).
          break;
        }
      }
    }
  }

  public getBoundingBox(instanceUid: string): BoundingBox | null {
    return this.synthAiData.getBoundingBox(instanceUid) || null;
  }

  public addImageToViewedTracker(imageKey: string, seriesUID: string): void {
    this._viewedImages.set(imageKey, seriesUID);
  }

  public updateViewedImage(imageKey: string): void {
    if (this._viewedImages.has(imageKey)) {
      this._viewedImages.delete(imageKey);
    }
  }

  public getSeriesOfUnviewedImages(): string[] {
    const seriesUIDs = [...this._viewedImages.entries()].map(kv => kv[1]);
    const processedUIDs: string[] = [];
    const seriesDescriptions: string[] = [];
    for (const seriesUID of seriesUIDs) {
      if (!processedUIDs.some(processedUID => processedUID === seriesUID)) {
        const series = this.originalImageSeries.find(series => series.seriesInstanceUID === seriesUID);
        if (series) {
          const description = !!series.seriesDescription ? series.seriesDescription : `Series# ${series.foviaSeriesDataContext.seriesNumber}`;
          seriesDescriptions.push(description);
        }
        processedUIDs.push(seriesUID);
      }
    }
    return seriesDescriptions;
  }

  public addImageUserCalibration(imageKey: string, length: number, pixels: number): void {
    if (imageKey == null) {
      console.error(`${this.constructor.name}.addImageUserCalibration imageKey is null.`);
      return;
    }

    if (length == null || length <= 0) {
      console.error(`${this.constructor.name}.addImageUserCalibration length of ${length} is not valid.`);
      return;
    }

    if (pixels == null || pixels < 0) {
      console.error(`${this.constructor.name}.addImageUserCalibration pixels of value ${pixels} is not valid.`);
      return;
    }

    // convert to mm
    const lengthmm = length * 10;

    const pixelSpacing = lengthmm / pixels;
    this._userCalibratedImages.set(imageKey, pixelSpacing);
  }

  public getImagePixelSpacing(imageKey: string): string | null {
    if (this._userCalibratedImages.has(imageKey)) {
      const pixelSpacing = this._userCalibratedImages.get(imageKey);
      if (pixelSpacing) {
        return `${pixelSpacing}\\${pixelSpacing}`;
      }
    }
    return null;
  }

  public isInstanceCADProcessed(instanceUID: string): boolean {
    if (instanceUID == null) {
      console.error(`${this.constructor.name}.isInstanceCADProcessed instanceUID is null`);
      return false;
    }

    let referenceUID = null;
    if (this.referencedSopInstanceUIDS.has(instanceUID)) {
      referenceUID = this.referencedSopInstanceUIDS.get(instanceUID);
    }

    if (referenceUID != null && this.mammoCADSrRefSopInstanceUIDS.has(referenceUID)) {
      return true;
    }

    if (this.mammoCADSrRefSopInstanceUIDS.has(instanceUID)) {
      return true;
    }

    return false;
  }

  private get hasStoredKeyObject(): boolean {
    return GSPSUtils.getInstance().hasKeyImages(this.studyInstanceUID) || this._storedKeyImageSeries.length > 0;
  }

  private keyImageExists(koImageKey: string): boolean {
    return this.findKeyImageIndex(koImageKey) !== -1;
  }

  public keyImageExistsIncludingCopies(sopInstanceUID: string, frameNumber: number): boolean {
    return this._keyImageSeries.findIndex((entry: VirtualSeries) => {
      return entry.hasKeyObjectIncludingCopies(sopInstanceUID, frameNumber);
    }) >= 0;
  }

  private findKeyImageIndex(koImageKey: string): number {
    return this._keyImageSeries.findIndex((entry: VirtualSeries) => {
      return entry.hasKeyObject(koImageKey);
    });
  }

  private findKeyImage(koImageKey: string): VirtualSeries | null {
    const index = this.findKeyImageIndex(koImageKey);
    if (index !== -1) {
      return this._keyImageSeries[index];
    }
    return null;
  }

  private hasMultiframeImage(series: ExamSeries[]): boolean {
    for (let i = 0; i < series.length; i++) {
      if (series[i].hasMultiframeImage()) {
        return true;
      }
    }
    return false;
  }

  private isXRayExam(series: ExamSeries[]): boolean {
    for (let i = 0; i < series.length; i++) {
      if (series[i].isModalityXR()) {
        return true;
      }
    }
    return false;
  }

  private isCrossSectionalModalityExam(series: ExamSeries[]): boolean {
    for (let i = 0; i < series.length; i++) {
      if (series[i].isCrossSectionalModality()) {
        return true;
      }
    }
    return false;
  }

  private isMammoExam(series: ExamSeries[]): boolean {
    for (let i = 0; i < series.length; i++) {
      if (series[i].isModalityMG()) {
        return true;
      }
    }
    return false;
  }

  private isUltrasoundExam(series: ExamSeries[]): boolean {
    for (let i = 0; i < series.length; i++) {
      if (series[i].isModalityUS()) {
        return true;
      }
    }
    return false;
  }

  private sanityCheck(foviaExam: Fovia.ScanDirSeriesResults[]): void {
    foviaExam.forEach(series => {
      // console.log(`series ${series.dicomSeries.seriesDescription} total images ${series.dicomSeries.imageCount}`);
      const seriesStudyUID = series.dicomSeries?.studyInstanceUID ?? null;
      if (seriesStudyUID == null) {
        console.warn(`series with seriesInstanceUID ${series.dicomSeries?.seriesInstanceUID} has undefined studyInstanceUid.  exam's studyInstanceUid is '${this._studyInstanceUID}' `);
      } else if (seriesStudyUID !== this._studyInstanceUID) {
        console.error(`mismatch between exam study uid '${this._studyInstanceUID}' and series study uid '${seriesStudyUID}'`);
      }
      const studyDate = series.dicomSeries?.studyDate ?? null;
      if (studyDate == null || studyDate === '') {
        console.warn(`study ${series.dicomSeries?.studyInstanceUID} has undefined studyDate.`);
      }
    });
  }

  private logFoviaSeriesInfo(foviaExam: Fovia.ScanDirSeriesResults[]): void {
    // test-test-test
    console.log(`----------------- Study Series Info for ${this.isPrimary ? 'Primary' : 'Comparison'} Exam ${this._studyInstanceUID} ------------------------`);
    foviaExam.forEach(series => {
      const seriesStudyUID = series.dicomSeries?.studyInstanceUID ?? null;
      if (seriesStudyUID == null) {
        console.warn(`series with seriesInstanceUID ${series.dicomSeries?.seriesInstanceUID} has undefined studyInstanceUid.  exam's studyInstanceUid is '${this._studyInstanceUID}' `);
      } else if (seriesStudyUID !== this._studyInstanceUID) {
        console.error(`mismatch between exam study uid '${this._studyInstanceUID}' and series study uid '${seriesStudyUID}'`);
      }
      if (series.containsSubSeries) {
        console.info(`Exam has sub-series: seriesDesc: ${series.dicomSeries.seriesDescription} subSeriesID: ${series.dicomSeries.subSeriesID} is3Dable: ${series.dicomSeries.is3DableSeries} subseries-count:${series.subSeries.length}`);
        series.subSeries.forEach((sdc: Fovia.SeriesDataContext, index) => {
          console.log(`  - ${index} subSeriesID: ${sdc.subSeriesID} is3Dable: ${sdc.is3DableSeries} #images: ${sdc.getNumImages()}`);
        });
      } else {
        console.info(`Exam Series: seriesDesc: ${series.dicomSeries.seriesDescription} subSeriesID: ${series.dicomSeries.subSeriesID} is3Dable: ${series.dicomSeries.is3DableSeries}  #images: ${series.dicomSeries.getNumImages()}`);
      }
    });
    // test-test-test
    console.log(`------------------------------------------------------------`);
  }
  private initializeDicomTagMaps(allDicomTags: any[]): void {
    for (const json of allDicomTags) {
      const instanceUID = getTagValueAsString(json, DICOM_TAGS.SOP_INSTANCE_UID);
      if (instanceUID != null) {
        this.dicomTagsMap.set(instanceUID, json);
        if (this.isMG()) {
          this._mammoInfoMap.set(instanceUID, new MammoInfo(json, instanceUID));
          this.getReferenceSopInstanceUIDs(instanceUID, json);
        } else if (this.isPT()) {
          this._suvInfoMap.set(instanceUID, new SUVInfo(json, instanceUID));
        }
        this._windowLevelInfoMap.set(instanceUID, new DICOMWindowLevelInfo(json, instanceUID));
        // console.log(`setting windowLevelInfoMap for ${instanceUID}`, json, this._windowLevelInfoMap.get(instanceUID));
        this.updateImageTags(instanceUID, json);
      } else {
        console.error(`Unable to parse SOP Instance UID tag for study ${this._studyInstanceUID}`);
      }
    }
    // Alert if non-image sop instances are not in the map
    let count = 0;
    for (const uid of this.nonImageSeries) {
      if (this.dicomTagsMap.has(uid)) {
        if (this.isMG()) {
          const tags = this.dicomTagsMap.get(uid);
          if (tags) {
            const sopClassUID = getTagValueAsString(tags, DICOM_TAGS.SOP_CLASS_UID);
            if (sopClassUID === SOP_CLASS.MG_CAD_SR) {
              const cadInfo = new MammoCADSrInfo(tags, uid);
              cadInfo.referencedSopInstanceUIDs.forEach(instanceUID => this.mammoCADSrRefSopInstanceUIDS.add(instanceUID));
            }
          }
        }
        count++;
      }
    }
    console.info(`Study ${this.studyInstanceUID} has ${count}/${this.nonImageSeries.length} dicom tags for non-imageseries`);
  }

  private validateSDCWLValues(foviaExam: Fovia.ScanDirSeriesResults[]): void {
    let sdcWLMatch = true;
    for (const series of foviaExam) {
      for (let i = 0; i < series.dicomSeries.imageTags.length; i++) {
        const image = series.dicomSeries.imageTags[i];
        // Fovia runtime only uses the first ww/wc in the list
        const wc = image.windowCenter.split(`\\`);
        const ww = image.windowWidth.split(`\\`);
        const fovia_center: number | null = wc.length > 0 ? Number(wc[0]) : null;
        const fovia_width = ww.length > 0 ? Number(ww[0]) : null;
        const wlInfo: DICOMWindowLevelInfo | undefined = this.windowLevelInfoMap.get(image.sopInstanceUID);
        if (wlInfo != null) {
          const wl: WLInfo[] | null = wlInfo.getImageWLInfo(0); // just get the first entry
          // It's legitimate to have no w/l for a dicom file -- fovia should auto wl these image instances.
          if (wl != null && wl.length > 0 && fovia_center != null && fovia_width != null) {
            const matches = fovia_center === wl[0].level && fovia_width === wl[0].width;
            sdcWLMatch = sdcWLMatch && matches;
            if (!sdcWLMatch) {
              console.error(`${this.studyInstanceUID} ${series.dicomSeries.seriesDescription} ${series.dicomSeries.modality}- Image[${i}] WL mismatch - fovia SDC against dicom tags`, image, wl, fovia_center, fovia_width);
              // break;
            }
          }
        }
      }
    }
  }

  private validateSDCSlopeInterceptValues(foviaExam: Fovia.ScanDirSeriesResults[]): void {
    for (const series of foviaExam) {
      for (let i = 0; i < series.dicomSeries.imageTags.length; i++) {
        const image = series.dicomSeries.imageTags[i];
        // Fovia runtime only uses the first ww/wc in the list
        const tags = this.dicomTagsMap.get(image.sopInstanceUID);
        if (tags) {
          // Since fovia converts all image to unsigned, the intercept changes for pixel data that
          // came in as signed. So don't evaluate signed image's intercept.
          const pixelRep = getTagValueAsNumber(tags, DICOM_ALLTAGS.PixelRepresentation); // 0 = unsigned
          const tag_ri = getTagValueAsNumber(tags, DICOM_ALLTAGS.RescaleIntercept) ?? 0;
          const tag_rs = getTagValueAsNumber(tags, DICOM_ALLTAGS.RescaleSlope) ?? 1;
          if ((tag_ri !== image.rescaleIntercept) || tag_rs !== image.rescaleSlope) {
            const pixel_rep = `pixelRep: tag: ${pixelRep} v. sdc: ${image.pixelRepresentation}`;
            const slope_info = `slope: tag: ${tag_rs} v. sdc: ${image.rescaleSlope}`;
            const intercept_info = `intercept: tag: ${tag_ri} v. sdc: ${image.rescaleIntercept}`;
            console.error(`${this.studyInstanceUID} ${series.dicomSeries.seriesDescription} ${series.dicomSeries.modality}- Image[${i}] mismatch ${pixel_rep} ${slope_info} ${intercept_info}`);
            break;
          }
        }

      }
    }
  }
  /**
   * This can be used to change the Fovia imageTags to what we are able to parse from the DICOM
   * header. In some cases imageTags doesn't accurately reflect the real header contents, such
   * as when a value might be found in a sequence rather than the root. Fovia tends to only
   * look from the root and not parse sequences.
   */
  private updateImageTags(instanceUID: string, tags: any): void {
    const examSeries = this.originalImageSeries.find(examSeries => (examSeries.getImageIndex(instanceUID) !== -1));

    if (examSeries) {
      // Double check to make sure we're really dealing with the right image.
      const tagValue: string | null = getTagValueAsString(tags, DICOM_TAGS.SOP_INSTANCE_UID, true);
      if (tagValue === null || tagValue !== instanceUID.toUpperCase()) {
        console.error(`Tags mismatch for  image ${instanceUID}`);
        return;
      }
      // See if we can get the calibration from our DICOM tags map if Fovia's imageTags doesn't have it.
      if (examSeries.foviaSeriesDataContext.imageTags[examSeries.getImageIndex(instanceUID)].pixelSpacing === '') {
        this.updatePixelSpacing(examSeries, instanceUID, tags);
      }
    }
  }

  /**
   * If we find the calibration in the sequence of ultrasound regions in our DICOM tags map, then
   * put it in Fovia's imageTags so things like line measurements will use it.
   * @param examSeries - the series containing the image we're dealing with
   * @param instanceUID - the instance UID of the image
   * @param tags - the DICOM tags for the image, from our DICOM tags map
   * @private
   */
  private updatePixelSpacing(examSeries: ExamSeries, instanceUID: string, tags: any): void {
    if (tags != null) {
      const sequenceItem = tags[DICOM_TAGS.US_REGIONS_SEQUENCE] ? tags[DICOM_TAGS.US_REGIONS_SEQUENCE]['Value'] : null;
      // TODO: Will there always only be 1 sequence item???
      if (sequenceItem && sequenceItem.length === 1) {
        // Only deal with image measurements, which is centimeters (3).
        if (getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.PHYSICAL_UNITS_X_DIRECTION) === 3 && getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.PHYSICAL_UNITS_Y_DIRECTION) === 3) {
          const pixelsPerCmX = getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.PHYSICAL_DELTA_X);
          const pixelsPerCmY = getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.PHYSICAL_DELTA_Y);
          if (pixelsPerCmX !== null && pixelsPerCmY !== null) {
            // Multiply by ten because Fovia expects pixels per mm.
            // All the images with this instance UID get the same calibration.
            for (const tag of examSeries.foviaSeriesDataContext.imageTags.filter(value => value.sopInstanceUID === instanceUID)) {
              tag.pixelSpacing = `${pixelsPerCmX * 10}\\${pixelsPerCmY * 10}`;
            }
          }
        }
      }
    }
  }

  private getReferenceSopInstanceUIDs(instanceUID: string, tags: any): void {
    const sourceImageSequence = tags[DICOM_TAGS.SOURCE_IMAGE_SEQUENCE] ? tags[DICOM_TAGS.SOURCE_IMAGE_SEQUENCE]['Value'] : null;
    if (sourceImageSequence) {
      const sequence  = sourceImageSequence[0];
      const referenceSopInstanceUID = sequence[DICOM_TAGS.REFERENCED_SOP_INSTANCE_UID] ? sequence[DICOM_TAGS.REFERENCED_SOP_INSTANCE_UID]['Value'] : null;
      if (referenceSopInstanceUID) {
        this.referencedSopInstanceUIDS.set(instanceUID, referenceSopInstanceUID[0]);
      }
    }
  }

  private addImagesToBeTracked(examSeries: ExamSeries): void {
    // add image key to viewed images tracker
    if (!examSeries.isMontage) {
      let imageNumber = 0;
      while (imageNumber < examSeries.numImages) {
        const totalFrames = examSeries.getImageFrameCount(imageNumber);
        const sopInstanceUID = examSeries.getImageInstanceUID(imageNumber);
        let frameNumber = 1;
        while (frameNumber <= totalFrames) {
          const imageKey = makeImageKey(sopInstanceUID, frameNumber);
          this.addImageToViewedTracker(imageKey, examSeries.seriesInstanceUID);
          frameNumber++;
        }
        imageNumber++;
      }
    }
  }

  /**
   * Identify any 3D capable series from the 2D series list - these 3D series may have
   * sub-series -- which may also be 3d-able. Code has been tested with an exam which has 3D sub-series.
   * @param foviaExam - the Fovia results from load study
   * @private
   */
  private construct3dExamSeries(foviaExam: Fovia.ScanDirSeriesResults[]): VirtualSeries[] {
    const seriesList = foviaExam
      .filter(foviaSeries => !foviaSeries.isNonImageSeries)
      .flatMap((foviaSeries) => {
        const seriesList: Array<VirtualSeries> = [];
        if (foviaSeries.containsSubSeries) {
          // Locate any 3D-able subseries, and create ExamSeries for each of them
          // so we can represent them in the UI as thumbnails, and load them as volumes
          foviaSeries.subSeries.forEach((sdc: SeriesDataContext, index) => {
            if (!sdc.is3DableSeries) {
              return;
            }
            const newSeries = VirtualSeries.createSimpleVirtualSeries(this, foviaSeries, sdc);
            console.log(`-- ${index} 3D Sub series added subseries ${sdc.subSeriesID} is3DableSeries ${sdc.is3DableSeries} ${sdc.seriesDescription} #${sdc.getNumImages()}`);
            seriesList.push(newSeries);
          });
        } else {
          // Don't let tomosynthesis images be included as 3D-able.
          if (foviaSeries.dicomSeries.is3DableSeries && foviaSeries.dicomSeries.modality !== 'MG') {
            seriesList.push(VirtualSeries.createSimpleVirtualSeries(this, foviaSeries, foviaSeries.dicomSeries));
          }
        }
        return seriesList;
      });
    // Finally, sort these series by our volume quality metric, smaller numbers are better quality
    seriesList.sort((s1, s2): number => {
      if (s1.currentExamSeries && s2.currentExamSeries) {
        const delta = s1.currentExamSeries.volumeQuality - s2.currentExamSeries.volumeQuality;
        return delta === 0 ? 0 : delta < 0 ? -1 : 1;
      } else {
        return 0;
      }
    });
    for (const series of seriesList) {
      const current = series.currentExamSeries;
      console.log(`3D Series quality ${current?.seriesDescription} ${current?.volumeQuality.toPrecision(2)} ${current?.pixelSpacing.x} ${current?.sliceThickness}`);
    }
    return seriesList;
  }

  private constructOriginalExamSeries(foviaExam: Fovia.ScanDirSeriesResults[]): ExamSeries[] {
    return foviaExam
      .filter(foviaSeries => !foviaSeries.isNonImageSeries)
      .map((foviaSeries) => {
        const examSeries = new ExamSeries(this, foviaSeries, this._isPrimary, foviaSeries.dicomSeries);

        this.addImagesToBeTracked(examSeries);
        return examSeries;
      });
  }

  // Construct virtual series for the exam depending on exam characteristics.
  private constructVirtualImageSeries(origSeries: ExamSeries[], hangingProtocol: HangingProtocol): VirtualSeries[] {
    let vSeries: VirtualSeries[];
    const dndRules = new HangingProtocolDoNotDisplaySeriesRules(hangingProtocol.doNotDisplay);
    const cineSpeedOptions = new CineSpeedOptions(hangingProtocol);

    if (this.isCrossSectionalModalityExam(origSeries) || this._isViewerSplitMode) {
      vSeries = this.constructVirtualSeries_Default(origSeries);
    } else if (this.isMammoExam(origSeries)) {
      // No fancy layouts if we don't have the DICOM tags.
      if (this.dicomTagsMap.size > 0) {
        const mammoLabellingUIDs = this.aiSrMap.get(CURRENT_AI_SERIES_DESC.MGBreastLabelling);
        if (mammoLabellingUIDs) {
          this.registerMammoBoundingBox(this.dicomTagsMap, mammoLabellingUIDs[0]);
        }
        vSeries = this.constructVirtualSeries_Mammo(origSeries);
      } else {
        vSeries = this.constructVirtualSeries_Default(origSeries);
      }
    } else if (this.isXRayExam(origSeries)) {
      const lumbarSpineXRViewPosUIDs = this.aiSrMap.get(CURRENT_AI_SERIES_DESC.XRLumbarSpineViewPosition);
      if (lumbarSpineXRViewPosUIDs) {
        this.mapPositionSRToImageTags(this.dicomTagsMap, lumbarSpineXRViewPosUIDs[0]);
      }

      let sortedSeries: VirtualSeries | null = null;
      const chestXRViewPosUIDs = this.aiSrMap.get(CURRENT_AI_SERIES_DESC.XRChestViewPosition);
      if (chestXRViewPosUIDs) {
        this.mapPositionSRToImageTags(this.dicomTagsMap, chestXRViewPosUIDs[0]);
        sortedSeries = this.constructVirtualSeries_ChestFlicker(origSeries);
      }

      // Assemble into a single series if specified in the HP config.
      if (hangingProtocol.groupSingleFrame) {
        if (sortedSeries) {
          vSeries = [sortedSeries];
        } else {
          vSeries = this.constructVirtualSeries_SingleFrameStack(origSeries, dndRules);
        }
      } else {
        vSeries = this.constructVirtualSeries_SplitXRay(sortedSeries, origSeries);
      }
    } else if (this.isUltrasoundExam(origSeries) || this.hasMultiframeImage(origSeries)) {
      vSeries = this.constructVirtualSeries_Multiframe(origSeries, hangingProtocol.groupSingleFrame);
    } else {
      vSeries = this.constructVirtualSeries_Default(origSeries);
    }

    // Apply HP 'do not display', 'cine playback' and 'center slice first' rules
    vSeries.filter(series => series.imageSets.length > 0)
      .forEach(series => {
        if (series.currentExamSeries) {
          console.log(`series:${series.currentExamSeries.seriesDescription}, thickness:${series.currentExamSeries.sliceThickness}`);
          series.displayByDefault = !dndRules.applyRules(series.currentExamSeries.seriesDescription, series.currentExamSeries.sliceThickness);

          // Initialize cinePlayback characteristics for this series
          series.cinePlayback.init(cineSpeedOptions, this.dicomTagsMap.get(series.currentSopInstanceUID));

          series.applyCenterImageFirstHpRule(hangingProtocol);
        } else {
          console.error(`Exam series does not exist. Unable to apply HP rules.`);
        }
      });

    // Sort series according to hanging protocols
    if (this.hangingProtocol.seriesSortComparatorFn != null) {
      vSeries.sort(this.hangingProtocol.seriesSortComparatorFn);
    }

    // sort series that are not displayed by default to the end of the exam
    vSeries.sort((s1, s2): number => {
      return (s1.displayByDefault === s2.displayByDefault)
        ? 0
        : (!s1.displayByDefault && s2.displayByDefault)
          ? 1
          : -1;
    });
    return vSeries;
  }

  private constructKeySeries(origSeries: ExamSeries[]): VirtualSeries[] {
    const vSeries: VirtualSeries[] = [];

    // If we have a KO, identify the Key Image references for this study
    if (this.hasStoredKeyObject) {
      // The images from each series are identified and used
      // to show the Key Images to the user.

      const sdcs = origSeries.map(series => series.foviaSeriesDataContext);
      const keyImagesByInstanceUID = this.getKeyImages(sdcs);
      for (const keyImageSopInstance of keyImagesByInstanceUID.keys()) {
        const seriesUID = keyImagesByInstanceUID.get(keyImageSopInstance);
        const series = origSeries.find(series => series.seriesInstanceUID === seriesUID);
        if (series != null && keyImageSopInstance.sopInstanceUid != null && keyImageSopInstance.frameNumber != null) {
          const imageNumber = series.getImageIndexBySopInstanceUID(keyImageSopInstance.sopInstanceUid, keyImageSopInstance.frameNumber);
          if (imageNumber === -1) {
            console.warn(`constructKeySeries - skipping Key image because imageNumber is -1 for keyImageSopInstance ${keyImageSopInstance.sopInstanceUid} ${keyImageSopInstance.frameNumber} in DICOM KeyObject for ${this.studyInstanceUID} hasStoredKeyObject ${this.hasStoredKeyObject}`);
            continue;
          }
          // Assemble the virtualExamSeries for each Key Image
          const sourceExamSeries = series;
          const examSeries = new ExamSeries(this, sourceExamSeries.foviaSeries, this.isPrimary, sourceExamSeries.foviaSeriesDataContext);
          const imageSet = new VirtualSeriesImageSet(examSeries, imageNumber, imageNumber);
          const keyImage = new VirtualSeries([imageSet]);
          keyImage.koImageKey = makeImageKey(keyImage.currentSopInstanceUID, keyImage.currentFrameNumber);
          keyImage.isStoredKoImage = true;
          vSeries.push(keyImage);
        }
      }
      if (vSeries.length === 0) {
        console.warn(`No key images detected in DICOM KeyObject for ${this.studyInstanceUID} hasStoredKeyObject ${this.hasStoredKeyObject}`);
      }
    } else {
      const montageSeries = origSeries.filter((series) => series.isMontage);
      if (montageSeries.length > 0) {
        for (const sourceExamSeries of montageSeries) {
          const examSeries = new ExamSeries(this, sourceExamSeries.foviaSeries, this.isPrimary, sourceExamSeries.foviaSeriesDataContext);
          const imageSet = new VirtualSeriesImageSet(examSeries, 0, 0);
          const keyImage = new VirtualSeries([imageSet]);
          keyImage.koImageKey = makeImageKey(keyImage.currentSopInstanceUID, keyImage.currentFrameNumber);
          keyImage.isStoredKoImage = true;
          vSeries.push(keyImage);
        }
      }
    }

    return vSeries;
  }

  private constructVirtualSeries_Default(origSeries: ExamSeries[]): VirtualSeries[] {
    return origSeries.map(sourceSeries => {
      return VirtualSeries.createSimpleVirtualSeries(this, sourceSeries.foviaSeries, sourceSeries.foviaSeriesDataContext);
    });
  }

  // We are not relying on the subSeries data contexts from fovia for this, because they were incorrect.
  private constructVirtualSeries_Multiframe(origSeries: ExamSeries[], groupSingleFrames: boolean): VirtualSeries[] {
    const singleImageImageSets: VirtualSeriesImageSet[] = [];
    const finalResults = origSeries.flatMap(sourceSeries => {
      const resultSeries: VirtualSeries[] = [];
      if (!sourceSeries.hasMultiframeImage() && groupSingleFrames) {
        // a typical non-multiframe series
        resultSeries.push(VirtualSeries.createSimpleVirtualSeries(this, sourceSeries.foviaSeries, sourceSeries.foviaSeriesDataContext));
      } else {
        // series contains multiframe images - break it up into multiple virtual series
        let firstImageSetIndex = 0;
        while (firstImageSetIndex < sourceSeries.foviaSeriesDataContext.imageCount) {
          let frameCount = sourceSeries.getImageFrameCount(firstImageSetIndex);
          if (frameCount <= 0) {
            const imageKey = makeImageKeyFromImageTags(sourceSeries.getDicomImageTags(firstImageSetIndex));
            console.error(`constructVirtualSeries_Multiframe: invalid DICOM frameCount detected.  Marking image as failed. seriesUID=${sourceSeries.seriesInstanceUID}, imageKey=${imageKey}, imageIndex=${firstImageSetIndex}`);
            // this._examLoadContext.markImageFrameAsInvalid(imageKey);  -- this is already handled when the exam is loaded
            frameCount = 1;
          }
          const lastImageImageSetIndex = firstImageSetIndex + frameCount - 1;
          const imageSet = new VirtualSeriesImageSet(sourceSeries, firstImageSetIndex, lastImageImageSetIndex);
          if (frameCount === 1) {
            // it's a single frame image - save it for later
            // todo: if groupSingleFrame is FALSE, should this be put at the end of the exam, or left adjacent to the series's multiframe?  Should single images from same series be stacked?
            singleImageImageSets.push(imageSet);
          } else {
            // It's a multiframe - give it it's own virtual series
            resultSeries.push(new VirtualSeries([imageSet]));
          }
          firstImageSetIndex = lastImageImageSetIndex + 1;
        }
      }
      return resultSeries;
    });

    // deal with the single frame images
    if (singleImageImageSets.length > 0) {
      if (groupSingleFrames) {
        // Insert the single-frame images first in the array.
        finalResults.splice(0, 0, new VirtualSeries(singleImageImageSets));
      } else {
        singleImageImageSets.forEach(imageSet => {
          finalResults.push(new VirtualSeries([imageSet]));
        });
      }
    }
    return finalResults;
  }

  private constructVirtualSeries_Mammo(origSeries: ExamSeries[]): VirtualSeries[] {
    const rccImageSet: VirtualSeriesImageSet[] = [];
    const lccImageSet: VirtualSeriesImageSet[] = [];
    const rmloImageSet: VirtualSeriesImageSet[] = [];
    const lmloImageSet: VirtualSeriesImageSet[] = [];
    const rccTomoImageSet: VirtualSeriesImageSet[] = [];
    const lccTomoImageSet: VirtualSeriesImageSet[] = [];
    const rmloTomoImageSet: VirtualSeriesImageSet[] = [];
    const lmloTomoImageSet: VirtualSeriesImageSet[] = [];
    const otherImageSet: VirtualSeriesImageSet[] = [];

    // Put each mammo image into its own image set
    for (const sourceSeries of origSeries) {
      let firstImageSetIndex = 0;
      while (firstImageSetIndex < sourceSeries.foviaSeriesDataContext.imageCount) {
        const frameCount = sourceSeries.getImageFrameCount(firstImageSetIndex);
        const lastImageImageSetIndex = firstImageSetIndex + frameCount - 1;
        const mammoInfo = sourceSeries.getMammoInfo(sourceSeries.getImageInstanceUID(firstImageSetIndex));
        const type = mammoInfo.viewType;

        const imageSet = new VirtualSeriesImageSet(sourceSeries, firstImageSetIndex,
          lastImageImageSetIndex, mammoInfo.imageAlignment, mammoInfo.flipHorizontal, mammoInfo.rotate180);

        switch (type) {
          case MAMMO_VIEW_TYPE.RCC:
            rccImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.LCC:
            lccImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.LMLO:
            lmloImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.RMLO:
            rmloImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.RCC_TOMO:
            rccTomoImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.LCC_TOMO:
            lccTomoImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.RMLO_TOMO:
            rmloTomoImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.LMLO_TOMO:
            lmloTomoImageSet.push(imageSet);
            break;
          case MAMMO_VIEW_TYPE.UNKNOWN:
            otherImageSet.push(imageSet);
            break;
        }

        firstImageSetIndex = lastImageImageSetIndex + 1;
      }
    }

    // This is primarily used to keep from showing implants first, but generally keeps the
    // standard (no view modifiers) images in front.
    sortImageSetForMammo(lccImageSet);
    sortImageSetForMammo(rccImageSet);
    sortImageSetForMammo(lmloImageSet);
    sortImageSetForMammo(rmloImageSet);

    // While we're at it we'll set up the flicker service for mammo.
    const flickerExamInfo: FlickerExamInfo = new FlickerExamInfo(this.dicomTagsMap, origSeries);
    flickerExamInfo.addImageSet(FLICKER_STACK.LCC, this.getFlickerImageSet(lccImageSet));
    flickerExamInfo.addImageSet(FLICKER_STACK.RCC, this.getFlickerImageSet(rccImageSet));
    flickerExamInfo.addImageSet(FLICKER_STACK.LMLO, this.getFlickerImageSet(lmloImageSet));
    flickerExamInfo.addImageSet(FLICKER_STACK.RMlO, this.getFlickerImageSet(rmloImageSet));
    this.mammoFlickerService.addExam(this.isPrimary, this.dicomTagsMap, origSeries, flickerExamInfo);

    // Assemble all our image stacks by MAMMO_VIEW_TYPE.
    this.mammoPresentationService.addExam(this.isPrimary);
    // Make sure that views that have a tomo but no xray still show up.
    if (rccImageSet.length === 0 && rccTomoImageSet.length > 0) {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RCC_PRIMARY : MAMMO_PRESENTATION_STACK.RCC_COMPARISON, new VirtualSeries(rccTomoImageSet));
    } else {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RCC_PRIMARY : MAMMO_PRESENTATION_STACK.RCC_COMPARISON, new VirtualSeries(rccImageSet));
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RCC_TOMO_PRIMARY : MAMMO_PRESENTATION_STACK.RCC_TOMO_COMPARISON, new VirtualSeries(rccTomoImageSet));
    }

    if (lccImageSet.length === 0 && lccTomoImageSet.length > 0) {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LCC_PRIMARY : MAMMO_PRESENTATION_STACK.LCC_COMPARISON, new VirtualSeries(lccTomoImageSet));
    } else {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LCC_PRIMARY : MAMMO_PRESENTATION_STACK.LCC_COMPARISON, new VirtualSeries(lccImageSet));
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LCC_TOMO_PRIMARY : MAMMO_PRESENTATION_STACK.LCC_TOMO_COMPARISON, new VirtualSeries(lccTomoImageSet));
    }

    if (rmloImageSet.length === 0 && rmloTomoImageSet.length > 0) {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RMLO_PRIMARY : MAMMO_PRESENTATION_STACK.RMLO_COMPARISON, new VirtualSeries(rmloTomoImageSet));
    } else {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RMLO_PRIMARY : MAMMO_PRESENTATION_STACK.RMLO_COMPARISON, new VirtualSeries(rmloImageSet));
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.RMLO_TOMO_PRIMARY : MAMMO_PRESENTATION_STACK.RMLO_TOMO_COMPARISON, new VirtualSeries(rmloTomoImageSet));
    }

    if (lmloImageSet.length === 0 && lmloTomoImageSet.length > 0) {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LMLO_PRIMARY : MAMMO_PRESENTATION_STACK.LMLO_COMPARISON, new VirtualSeries(lmloTomoImageSet));
    } else {
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LMLO_PRIMARY : MAMMO_PRESENTATION_STACK.LMLO_COMPARISON, new VirtualSeries(lmloImageSet));
      this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.LMLO_TOMO_PRIMARY : MAMMO_PRESENTATION_STACK.LMLO_TOMO_COMPARISON, new VirtualSeries(lmloTomoImageSet));
    }

    this.mammoPresentationService.setStack(this.studyInstanceUID, this.isPrimary ? MAMMO_PRESENTATION_STACK.OTHER_PRIMARY : MAMMO_PRESENTATION_STACK.OTHER_COMPARISON, new VirtualSeries(otherImageSet));

    return this.mammoPresentationService.getAllStacks(this._isPrimary, false, this.studyInstanceUID);
  }

  private getFlickerImageSet(sourceSet: VirtualSeriesImageSet[]): VirtualSeriesImageSet[] {
    const set: VirtualSeriesImageSet[] = [];
    if (sourceSet.length > 0) {
      set.push(sourceSet[0]);
    }
    return set;
    // lccImageSet.slice(1, lccImageSet.length - 1)
  }

  private constructVirtualSeries_ChestFlicker(origSeries: ExamSeries[]): VirtualSeries | null {
    // Assemble all our image stacks by view.
    this.chestFlickerService.addExam(this.isPrimary, this.dicomTagsMap, origSeries);
    return this.chestFlickerService.getExamVirtualSeries(this._studyInstanceUID);
  }

  // Create a copy of virtual series image for KO
  private constructVirtualSeries_KeyObject(imageSeries: VirtualSeries, _imageNumber: number, keyImageAnnotations: Fovia.GraphicAnnotation[]): VirtualSeries | null {
    const virtualSeries = imageSeries.duplicate();
    virtualSeries.koImageKey = makeImageKey(imageSeries.currentSopInstanceUID, imageSeries.currentFrameNumber);
    virtualSeries.currentImageRefIndex = imageSeries.currentImageRefIndex;
    for (const annotation of keyImageAnnotations) {
      virtualSeries.currentImageRef.imageSet.addClonedAnnotation(virtualSeries.currentImageRef.imageIndex, annotation);
    }
    return virtualSeries;
  }

  // Create one virtual series for the whole exam, with every image in its own series set.
  // This allows for each image to have its own fovia viewport/renderEngine/renderParams
  private constructVirtualSeries_SingleFrameStack(origSeries: ExamSeries[], dndRules: HangingProtocolDoNotDisplaySeriesRules): VirtualSeries[] {
    if (origSeries.length === 0) {
      return [];
    }
    const resultSeries: VirtualSeries[] = [];
    let allImageSets: VirtualSeriesImageSet[] = [];
    let allExcludedImageSets: VirtualSeriesImageSet[] = [];
    for (const series of origSeries) {
      const myImageSets: VirtualSeriesImageSet[] = [];
      for (let i = 0; i < series.foviaSeriesDataContext.imageCount; i++) {
        const imageSet = new VirtualSeriesImageSet(series, i, i);
        myImageSets.push(imageSet);
      }
      // Check if this series should not be displayed. If it's on the DND list, then add it to its own image set.
      // If it's added to the allImageSets, then the VirtualSeries that allImageSets belongs to is at risk of not being displayed
      if (dndRules.applyRules(series.seriesDescription, series.sliceThickness)) {
        allExcludedImageSets = allExcludedImageSets.concat(myImageSets);
      } else {
        allImageSets = allImageSets.concat(myImageSets);
      }
    }
    resultSeries.push(new VirtualSeries(allImageSets));
    resultSeries.push(new VirtualSeries(allExcludedImageSets));
    return resultSeries;
  }

  // As necessary, split series such that all images get their own series.
  private constructVirtualSeries_SplitXRay(sortedSeries: VirtualSeries | null, origSeries: ExamSeries[]): VirtualSeries[] {
    // Put each image in its own series.
    const resultSeries: VirtualSeries[] = [];

    if (sortedSeries) {
      for (const imageSet of sortedSeries.imageSets) {
        resultSeries.push(new VirtualSeries([imageSet]));
      }
    } else {
      for (const series of origSeries) {
        for (let i = 0; i < series.foviaSeriesDataContext.imageCount; i++) {
          const imageSet = new VirtualSeriesImageSet(series, i, i);
          resultSeries.push(new VirtualSeries([imageSet]));
        }
      }
    }

    return resultSeries;
  }

  // Useful for regression testing of virtual series functionality.
  // Builds different flavors of virtual series for the exam.
  private constructViewableSeries_XR_ForTesting(origSeries: ExamSeries[]): VirtualSeries[] {
    if (origSeries.length === 0) {
      return [];
    }

    // First just add all of the original series
    const resultSeries = this.constructVirtualSeries_Default(origSeries);

    // next, one series with all original series stacked
    const imageSets: VirtualSeriesImageSet[] = origSeries.reduce((accum: VirtualSeriesImageSet[], series: ExamSeries) => {
      accum.push(new VirtualSeriesImageSet(series, 0, series.foviaSeriesDataContext.imageCount - 1));
      return accum;
    }, []);
    resultSeries.push(new VirtualSeries(imageSets));

    // next, one series with imageSets from all series, reversed
    const allImageSets = origSeries.flatMap(series => {
      const myImageSets: VirtualSeriesImageSet[] = [];
      for (let i = 0; i < series.foviaSeriesDataContext.imageCount; i++) {
        const imageSet = new VirtualSeriesImageSet(series, i, i);
        myImageSets.push(imageSet);
      }
      return myImageSets;
    });

    resultSeries.push(new VirtualSeries(allImageSets.reverse()));

    // next each image from the first series in its own series
    for (let i = 0; i < origSeries[0].foviaSeriesDataContext.imageCount; i++) {
      const imageSet = new VirtualSeriesImageSet(origSeries[0], i, i);
      resultSeries.push(new VirtualSeries([imageSet]));
    }

    return resultSeries;
  }

  private constructViewableSeries_XR_ManySeries_forTesting(origSeries: ExamSeries[]): VirtualSeries[] {
    if (origSeries.length === 0) {
      return [];
    }

    const resultSeries: VirtualSeries[] = [];



    for (let i = 0; i < 10; i++) {
      origSeries.forEach(sourceSeries => {
        resultSeries.push(VirtualSeries.createSimpleVirtualSeries(this, sourceSeries.foviaSeries, sourceSeries.foviaSeriesDataContext));
      });
    }

    return resultSeries;
  }

  private calculateAiSrMap(): UIDMap {
    const unsorted_map: Map<CURRENT_AI_SERIES_DESC, Array<[string, string]>> = new Map();
    for (const tags of this.dicomTagsMap.values()) {
      if (tags) {
        const uid = getTagValueAsString(tags, DICOM_TAGS.SOP_INSTANCE_UID);
        const seriesDescription = getTagValueAsString(tags, DICOM_TAGS.SERIES_DESCRIPTION) || "";
        const aiDescription = AIDescriptionNameMapper[seriesDescription];
        if (uid && aiDescription) {
          // The tuple is used in the next step to sort the AI DSRs by descending date per type
          let date = getTagValueAsString(tags, DICOM_ALLTAGS.InstanceCreationDate) || "00000000";
          let time = getTagValueAsString(tags, DICOM_ALLTAGS.InstanceCreationTime) || "000000";
          let dateTime = `${date}${time}`;
          const new_uids: Array<[string, string]> = [...(unsorted_map.get(aiDescription) || []), [dateTime, uid]];
          unsorted_map.set(aiDescription, new_uids);
        }
      }
    }

    try {
      return Array.from(unsorted_map.entries()).reduce((uidMap, [desc, uidTimes]) => {
        uidTimes.sort((a, b) => (a[0] > b[0] ? -1 : 1));
        uidMap.set(
          desc,
          uidTimes.map(([_, uid]) => uid)
        );
        return uidMap;
      }, new Map());
    } catch (_) {
      return new Map();
    }
  }

  private synthAIInference(dicomTagsMap: DicomTagMap, srInstanceUid: string): Record<string, unknown> | null {
    const srTags = dicomTagsMap.get(srInstanceUid);
    if (!srTags) {
      return null;
    }

    try {
      const tagValue = getTagValueAsString(srTags, DICOM_TAGS.SYNTH_AI_SR_TAG);
      if (tagValue) {
        const json = JSON.parse(tagValue);
        if (json) {
          return json;
        }
      }
    } catch (err) {
      console.error(`${this.constructor.name}.synthAIInference failed to parse inference ${srInstanceUid}`);
    }

    return null;
  }

  private mapPositionSRToImageTags(dicomTagsMap: DicomTagMap, srInstanceUid: string): void {
    try {
      const instanceUIDs: Set<string> = new Set();

      // Get all the image instance UIDs. The SR matches UID to view position, so we need the UIDs
      // for correlation with the SR information.
      for (const tags of dicomTagsMap.values()) {
        if (tags !== null) {
          const uid = getTagValueAsString(tags, DICOM_TAGS.SOP_INSTANCE_UID);
          if (uid) {
            instanceUIDs.add(uid);
          }
        }
      }

      const json = this.synthAIInference(dicomTagsMap, srInstanceUid);
      const inference = validateViewPositionInference(json);

      if (inference) {
        for (const uid of instanceUIDs) {
          const inferredViewPosition = inference.ViewPosition[uid];
          const tagMap = dicomTagsMap.get(uid);
          if (inferredViewPosition && tagMap) {
            tagMap[DICOM_TAGS.VIEW_POSITION] = { vr: 'CS', Value: [inferredViewPosition] };
          }
        }
      }
    } catch (err) {
      console.error(`${this.constructor.name}.mapPositionSRToImageTags failed to extract inference:`, err);
    }
  }

  private registerMammoBoundingBox(dicomTagsMap: DicomTagMap, srInstanceUID: string): void {
    try {
      const srTags = dicomTagsMap.get(srInstanceUID);
      if (!srTags) {
        return;
      }

      const json = this.synthAIInference(dicomTagsMap, srInstanceUID);
      const inference = validateBreastLabelingInference(json);
      if (inference) {
        this.synthAiData.setBoundingBoxes(inference);
      }
    } catch (err) {
      console.error(`${this.constructor.name}.registerMammoBoundingBox failed to extract inference:`, err);
    }
  }

  // Synthesis method for processing KO.
  private getKeyImages(sdcs: Fovia.SeriesDataContext[]): Map<Fovia.Util.SopInstance, string> {
    const keyImageSequences = new Fovia.Util.SopInstanceSequence();
    const keyImageSeriesDataList: Fovia.NonImageSeriesDataContext[] | null = GSPSUtils.getInstance().getNonImageSeriesDataList(Fovia.SupportedNonImageModelType.key_object);
    const sortedKeyInfoList = new Array<PresentationInfo>();
    if (keyImageSeriesDataList != null) {
      keyImageSeriesDataList.forEach(keyDataContext => {
        if (keyDataContext) {
          sortedKeyInfoList.push(new PresentationInfo(keyDataContext, 'KO'));
        }
      });

      sortedKeyInfoList.sort((info1, info2) => {
        return info1.compareContentCreationTime(info2);
      });
    }

    const referenceImageUIDToSeriesUIDMap = new Map<Fovia.Util.SopInstance, string>();

    if (keyImageSeriesDataList != null) {
      for (let i = 0; i < sortedKeyInfoList.length; i++) {
        const keyImageSeriesData = sortedKeyInfoList[i].getPRInstance();
        // KO models
        const nonImageDataList = keyImageSeriesData.nonImageDataList;
        // console.log(`nonImageDataList ${i}/${sortedKeyInfoList.length} ${nonImageDataList.length} key images`, nonImageDataList);
        for (let j = 0; j < nonImageDataList.length; j++) {
          // Set key object related information
          const nonImageData = nonImageDataList[j];
          const referencedImageSequence = nonImageData.contentSequence.referencedImageSequence;

          // Get order of images. Preserve order from KO
          for (let index = 0; index < referencedImageSequence.length; index++) {
            const referencedImage = referencedImageSequence[index];
            const referencedFrameNumbers = referencedImage.referencedFrameNumbers;
            // If no frame number is mentioned, assume it is 1
            if (referencedFrameNumbers.length === 0) {
              referencedFrameNumbers.push(1);
            }
            for (let index2 = 0; index2 < referencedFrameNumbers.length; index2++) {
              const keyImageContext: Fovia.Util.SopInstance = {
                sopInstanceUid: referencedImage.referencedSopInstanceUid,
                frameNumber: referencedFrameNumbers[index2]
              };
              // ensure we don't produce duplicate key images from the various referencedImageSequences
              if (keyImageContext.sopInstanceUid != null &&
                keyImageContext.frameNumber != null &&
                !keyImageSequences.exists(keyImageContext.sopInstanceUid, referencedFrameNumbers)) {
                // console.log(`adding key image ${index2}/${referencedFrameNumbers.length} ${keyImageContext.sopInstanceUid} ${keyImageContext.frameNumber} key image to list`);
                keyImageSequences.add(referencedImage.referencedSopInstanceUid, referencedFrameNumbers[index2]);
              }
            }
          }

          // Find series each image belongs to
          const referencedSeriesSequence = nonImageData.currentRequestedProcedureEvidenceSequence.referencedSeriesSequence;
          for (let index = 0; index < referencedSeriesSequence.length; index++) {
            const referenceSeriesUID = referencedSeriesSequence[index].referencedSeriesInstanceUid;
            const referenceImages = referencedSeriesSequence[index].referencedImageSequence;
            const sdcSeries = sdcs.find(series => series.seriesInstanceUID === referenceSeriesUID);
            const imageNumbers = [];
            for (let index2 = 0; index2 < referenceImages.length; index2++) {
              const referencedImage = referenceImages[index2];
              const referencedFrameNumbers = referencedImage.referencedFrameNumbers;
              // If no frame number is mentioned, assume it is 1
              if (referencedFrameNumbers.length === 0) {
                referencedFrameNumbers.push(1);
              }

              for (let index3 = 0; index3 < referencedFrameNumbers.length; index3++) {
                const referenceFrameNumber = referencedFrameNumbers[index3];
                if (keyImageSequences.exists(referencedImage.referencedSopInstanceUid, [referenceFrameNumber])) {
                  const keyImageSequence = keyImageSequences.get(referencedImage.referencedSopInstanceUid, [referenceFrameNumber]);
                  if (keyImageSequence != null && keyImageSequence.sopInstanceUid != null && keyImageSequence.frameNumber != null) {
                    referenceImageUIDToSeriesUIDMap.set(keyImageSequence, referenceSeriesUID);
                    const imageNumber = sdcSeries?.getImageIndexBySopInstanceUid(keyImageSequence.sopInstanceUid, keyImageSequence.frameNumber);
                    if (imageNumber != null) {
                      imageNumbers.push(imageNumber);
                    }
                  }
                }
              }
            }
            if (sdcSeries != null && imageNumbers.length > 0) {
              sdcSeries.keyImages = imageNumbers;
            }
          }
        }
      }
    }
    return referenceImageUIDToSeriesUIDMap;
  }

  public canLoadFromOpfsCache(): boolean {
    // Exam is not locally cached on the client:
    // - If the exam is cached on the client, but is out-of-date
    // - If the exam contains out-of-date SR data
    // - If there were errors caching any of the SR data
    const clientMetadataHash = this.examLoadContext.clientMetadataHash;
    const serverMetadataHash = this.examLoadContext.serverMetadataHash;
    const canUseClientSRData = this.examLoadContext.canUseClientExamSRData;
    if (!clientMetadataHash || !serverMetadataHash) {
      return false; // Exam not cached
    }
    if (clientMetadataHash !== serverMetadataHash) {
      return false; // Cached exam is out-of-date
    }
    if (!canUseClientSRData) {
      return false; // SR data incomplete or out-of-date
    }
    return true;
  }

  public getCachedSRData(): IFoviaStudySRData | undefined {
    if (!this.examLoadContext.canUseClientExamSRData) {
      return undefined;
    }
    return this.examLoadContext.clientExamSRData;
  }

}

const AIDescriptions: string[] = [
  DICOM_AI_DESCRIPTION.XRChestViewPosition,
  DICOM_AI_DESCRIPTION.XRLumbarSpineViewPosition,
  DICOM_AI_DESCRIPTION.MGBreastLabelling,
];
