import { BaseEventHandler } from './base-event-handler';
import { UserInputDispatcher } from './user-input-dispatcher';

describe('KeyboardMouseDispatcher', () => {
  it('should create an instance', () => {
    let h = new BaseEventHandler();
    expect(new UserInputDispatcher(h)).toBeTruthy();
  });
});
