import Fovia from 'foviaapi';
import VIEWPORT_TYPE = Fovia.ViewportType;
import VIEW_TYPE = Fovia.ViewType;
import RENDER_TYPE = Fovia.RenderType;

import { PANEL_FORMAT } from './panel-support';
import { Bounds, CT_BONE } from '../utils';

// Define that MPR/3D related panels that are supported
// These are fixed layouts, that identify key characteristics of the panels,
// and their viewports that are to be created.
export class Color {
  public static get BLACK(): string { return '#000000'; }
  public static get BLUE(): string { return '#0000ff'; }
  public static get CYAN(): string { return '#00ffff'; }
  public static get RED(): string { return '#ff0000'; }
  public static get YELLOW(): string { return '#ffff00'; }
}

export enum PANEL_TEMPLATE_TYPE { eNone, eMPR, eFusion }

export enum VIEWPORT_ROLE {
  eUndefined,
  eMPRAxial,
  eMPRSagittal,
  eMPRCoronal,
  eMPRResult,
  e3DVolume,
  eMPRFusionBase,
  eMPRFusionOverlay,
  eMPRFusionAdditional,
  eFusionFused }

export enum VIEWPORT_CONTROL { eNone = 0, eRenderType = 1, eThickness = 3, eIncrement = 4, e3DPresets = 5, eCrossHairs = 6, eOpacitySlider = 7 }

// VIEWPORT_ROLE Titles, indexed by Role, if you add roles, please add corresponding titles
const ViewportTitles = [
  '-#1', '-#2', '-#3', '-#4', , '-#4', // MPR Titles
  '-#1', '-#2', '-#3', '-#4'           // Fusion Titles
];

// Sets of controls which are targeted for a particular viewport
const MPR_Controls: VIEWPORT_CONTROL[] = [VIEWPORT_CONTROL.eThickness, VIEWPORT_CONTROL.eIncrement, VIEWPORT_CONTROL.eCrossHairs];
const RenderType_Control: VIEWPORT_CONTROL[] = [VIEWPORT_CONTROL.eRenderType];
const _3D_Controls: VIEWPORT_CONTROL[] = [VIEWPORT_CONTROL.e3DPresets, VIEWPORT_CONTROL.eThickness];
const Fusion_Overlay_Controls: VIEWPORT_CONTROL[] = [];
const Fusion_Base_Controls: VIEWPORT_CONTROL[] = [VIEWPORT_CONTROL.eThickness, VIEWPORT_CONTROL.eIncrement];
const Fused_Controls: VIEWPORT_CONTROL[] = [VIEWPORT_CONTROL.eOpacitySlider];

export interface IPanelTemplate {
  readonly panelTemplateType: PANEL_TEMPLATE_TYPE;
  readonly panelFormat: PANEL_FORMAT;
  // The following settings correspond 1:1 to one-another
  // specifying the type of viewport, the role of each viewport and
  // the fovia types associated with creation of the viewport.
  readonly viewportInfo: Viewport3DInfo[];
}

// Provide the information needed for the specific panel
export function getPanelTemplate(panelTemplateType: PANEL_TEMPLATE_TYPE, seriesIndex: number): IPanelTemplate | null {
  switch (panelTemplateType) {
    case PANEL_TEMPLATE_TYPE.eMPR: return new MPRPanelTemplate(seriesIndex);
    case PANEL_TEMPLATE_TYPE.eFusion: return new FusionPanelTemplate();
    default: return null;
  }
}

export function isFusionRole(role: VIEWPORT_ROLE): boolean {
  return (role === VIEWPORT_ROLE.eMPRFusionBase || role === VIEWPORT_ROLE.eMPRFusionOverlay || role === VIEWPORT_ROLE.eFusionFused)
}

export class CrossHairs {
  public x = 0;
  public y = 0;
  public rotate = 0;
  public bounds: Bounds;

  constructor(public readonly hAxisColor: string, public readonly vAxisColor: string) {
    this.bounds = new Bounds();
  }
}
export class Viewport3DInfo {
  public readonly viewportTitle: string;
  public readonly viewportKey: string;
  public readonly viewportControls: VIEWPORT_CONTROL[] = [];
  public readonly isMPR: boolean;
  public readonly is3D: boolean;
  public readonly isFusion: boolean;
  public readonly id: number;
  public readonly borderColor: string;
  public readonly crossHairs: CrossHairs | null = null;
  private static idCounter = 0;

  public constructor(
    public readonly viewportRole: VIEWPORT_ROLE,
    public readonly viewportType: VIEWPORT_TYPE,
    public viewType: VIEW_TYPE,
    public thickness: number,
    public layoutName: string,
    public viewportRenderType: RENDER_TYPE,
    public defaultPreset: string = '',
    public viewportPrompt: string = ''
  ) {
    this.id = Viewport3DInfo.idCounter++;
    this.isMPR = viewportRole !== VIEWPORT_ROLE.e3DVolume && !isFusionRole(viewportRole);
    this.is3D = viewportRole === VIEWPORT_ROLE.e3DVolume;
    this.isFusion = isFusionRole(viewportRole);

    this.viewportTitle = ViewportTitles[viewportRole] ?? 'Oops title not defined';
    this.viewportKey = `${ViewportTitles[viewportRole]}-${layoutName}`;
    // console.log(`Viewport3DInfo  ${this.viewportTitle} ${this.viewportKey} ${this.viewportControls.length} controls ${this.id} ${viewportRole} ${viewportType} ${viewType} ${thickness} '${this.defaultPreset}'`, this);
    this.crossHairs = null;
    this.borderColor = Color.BLACK;
    // To keep viewports from seeming too cluttered, the 3 MPR viewports respond to a single
    // set of controls, which may be placed on any viewport
    switch (this.viewportRole) {
      case VIEWPORT_ROLE.eMPRAxial:
        this.viewportControls = RenderType_Control;
        this.borderColor = Color.RED;
        this.crossHairs = new CrossHairs(Color.YELLOW, Color.BLUE);
        break;
      case VIEWPORT_ROLE.eMPRCoronal:
        this.viewportControls = MPR_Controls;
        this.borderColor = Color.YELLOW;
        this.crossHairs = new CrossHairs(Color.RED, Color.BLUE);
        break;
      case VIEWPORT_ROLE.eMPRSagittal:
        this.borderColor = Color.BLUE;
        this.crossHairs = new CrossHairs(Color.RED, Color.YELLOW);
        break;
      // The 3D specific controls are assigned to the 3D viewport only
      case VIEWPORT_ROLE.e3DVolume:
        this.viewportControls = _3D_Controls;
        break;
      case VIEWPORT_ROLE.eFusionFused:
        this.viewportControls = Fused_Controls;
        break;
      case VIEWPORT_ROLE.eMPRFusionBase:
        this.viewportControls = Fusion_Base_Controls;
        break;
      case VIEWPORT_ROLE.eMPRFusionOverlay:
        this.viewportControls = Fusion_Overlay_Controls;
        break;
      case VIEWPORT_ROLE.eMPRFusionAdditional:
        this.viewportControls = [];
        break;
    }
  }

  public toString(): string {
    if (this.viewportRole === VIEWPORT_ROLE.e3DVolume) {
      return `${VIEWPORT_ROLE[this.viewportRole]} ${this.viewportType} ${VIEW_TYPE[this.viewType]} ${this.borderColor}`;
    } else {
      return `${VIEWPORT_ROLE[this.viewportRole]} ${this.viewportType} ${VIEW_TYPE[this.viewType]} ${this.thickness} ${this.borderColor}`;
    }
  }
}

class PanelTemplate implements IPanelTemplate {

  protected constructor(
    public readonly panelTemplateType: PANEL_TEMPLATE_TYPE,
    public readonly panelFormat: PANEL_FORMAT,
    public readonly viewportInfo: Viewport3DInfo[],
    public readonly name: string,
  ) {
  }
}

const DEFAULT_THICKNESS = 0; // 0-slice thickness from DICOM header is the same as a native slice
// Create our MPR panel
class MPRPanelTemplate extends PanelTemplate {
  // Index is used to make unique names for the 3D viewports
  // associated with a single exam series
  // TO DO: incorporate index into our map code
   public constructor(index: number) {
    const viewport3DInfo: Viewport3DInfo[] = [];
    // Each 3D series is associated with only 1 instance of each kind of panel. The viewports in panels may be the same kind, but will have different
    // render engines for that panel layout
     viewport3DInfo.push(new Viewport3DInfo(VIEWPORT_ROLE.eMPRAxial, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.axial, DEFAULT_THICKNESS, MPRPanelTemplate.name, RENDER_TYPE.thinAverage));
     viewport3DInfo.push(new Viewport3DInfo(VIEWPORT_ROLE.eMPRSagittal, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.sagittal, DEFAULT_THICKNESS, MPRPanelTemplate.name, RENDER_TYPE.thinAverage));
     viewport3DInfo.push(new Viewport3DInfo(VIEWPORT_ROLE.eMPRCoronal, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.coronal, DEFAULT_THICKNESS, MPRPanelTemplate.name, RENDER_TYPE.thinAverage));
     viewport3DInfo.push(new Viewport3DInfo(VIEWPORT_ROLE.e3DVolume, VIEWPORT_TYPE.DOUBLE_BUFFER_3D, VIEW_TYPE.coronal, DEFAULT_THICKNESS, MPRPanelTemplate.name, RENDER_TYPE.parallel, CT_BONE, ));
    super(PANEL_TEMPLATE_TYPE.eMPR, PANEL_FORMAT.four_up, viewport3DInfo, 'MPR Panel');
  }
}
export class FusionPanelTemplate extends PanelTemplate {
  public static readonly overlayViewportPosition = 0;
  public static readonly baseViewportPosition = 1;
  public static readonly additionalViewportPosition = 2;
  public static readonly fusedViewportPosition = 3;

  protected static readonly overlayPrompt = 'Drag an overlay series here';
  protected static readonly basePrompt = 'Drag a primary series here';
  protected static readonly additionalPrompt = 'Drag an additional series here';
  protected static readonly fusedPrompt = 'Fusion series will appear here';
  public constructor() {
    const viewport3DInfo = new Array<Viewport3DInfo>(4);
    viewport3DInfo[FusionPanelTemplate.overlayViewportPosition] =
        new Viewport3DInfo(VIEWPORT_ROLE.eMPRFusionOverlay, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.coronal, DEFAULT_THICKNESS, FusionPanelTemplate.name, RENDER_TYPE.parallel, '', FusionPanelTemplate.overlayPrompt);

    viewport3DInfo[FusionPanelTemplate.baseViewportPosition] =
        new Viewport3DInfo(VIEWPORT_ROLE.eMPRFusionBase, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.coronal, DEFAULT_THICKNESS, FusionPanelTemplate.name, RENDER_TYPE.thinAverage, '', FusionPanelTemplate.basePrompt);

    viewport3DInfo[FusionPanelTemplate.additionalViewportPosition] =
        new Viewport3DInfo(VIEWPORT_ROLE.eMPRFusionAdditional, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.coronal, DEFAULT_THICKNESS, FusionPanelTemplate.name, RENDER_TYPE.thinAverage, '', FusionPanelTemplate.additionalPrompt);

    viewport3DInfo[FusionPanelTemplate.fusedViewportPosition] =
        new Viewport3DInfo(VIEWPORT_ROLE.eFusionFused, VIEWPORT_TYPE.DOUBLE_BUFFER_MPR, VIEW_TYPE.coronal, DEFAULT_THICKNESS, FusionPanelTemplate.name, RENDER_TYPE.parallel, '', FusionPanelTemplate.fusedPrompt);

    super(PANEL_TEMPLATE_TYPE.eFusion, PANEL_FORMAT.four_up, viewport3DInfo, 'Fusion');
  }

  public getViewportPrompts(): string[] {
    return this.viewportInfo.map(info => info.viewportPrompt);
  }
}
