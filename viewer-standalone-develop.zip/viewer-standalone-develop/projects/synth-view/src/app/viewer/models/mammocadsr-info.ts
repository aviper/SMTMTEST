import { DICOM_TAGS, parseTagAsString } from '@server-api';

export class MammoCADSrInfo {
  public readonly instanceUID: string | null = null;
  public readonly referencedSopInstanceUIDs: string[] = [];

  constructor(tags: any, instanceUID: string) {
    if (instanceUID != null) {
      this.instanceUID = instanceUID;
    }

    if (tags != null) {
      const contentSequences = tags[DICOM_TAGS.CONTENT_SEQUENCE] ? tags[DICOM_TAGS.CONTENT_SEQUENCE]['Value'] : null;

      // check if content sequence contains the image library
      let imageInfo = null;
      if (contentSequences) {
        for (const contentSequence of contentSequences) {
          const conceptNameCodeSequence = contentSequence[DICOM_TAGS.CONCEPT_NAME_CODE_SEQUENCE] ? contentSequence[DICOM_TAGS.CONCEPT_NAME_CODE_SEQUENCE]['Value'] : null;
          if (conceptNameCodeSequence && conceptNameCodeSequence.length > 0) {
            const codeValue = parseTagAsString(conceptNameCodeSequence[0][DICOM_TAGS.CODE_VALUE]);
            // '111028' is code value for Image Library
            if (codeValue && codeValue === '111028') {
              imageInfo = contentSequence[DICOM_TAGS.CONTENT_SEQUENCE] ? contentSequence[DICOM_TAGS.CONTENT_SEQUENCE]['Value'] : null;
              break;
            }
          }
        }
      }

      if (imageInfo) {
        for (const image of imageInfo) {
          const valueType = parseTagAsString(image[DICOM_TAGS.VALUE_TYPE]);
          if (valueType && valueType === 'IMAGE') {
            const referencedSopSequence = image[DICOM_TAGS.REFERENCE_SOP_SEQUENCE] ? image[DICOM_TAGS.REFERENCE_SOP_SEQUENCE]['Value'] : null;
            if (referencedSopSequence && referencedSopSequence.length > 0) {
              const referencedSopInstanceUID = parseTagAsString(referencedSopSequence[0][DICOM_TAGS.REFERENCED_SOP_INSTANCE_UID]);

              if (referencedSopInstanceUID) {
                this.referencedSopInstanceUIDs.push(referencedSopInstanceUID);
              }
            }
          }
        }
      }
    }
  }
}
