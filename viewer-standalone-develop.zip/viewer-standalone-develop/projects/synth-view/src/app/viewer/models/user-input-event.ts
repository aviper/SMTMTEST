import { ElementRef } from '@angular/core';
import { EVENT_INFO } from './base-event-handler';

export class UserInputEvent {

  public elementRef: ElementRef;
  public document: Document;
  public eventInfo: EVENT_INFO = EVENT_INFO.eNone;
  public mouseEvent: MouseEvent | null = null;
  public keyboardEvent: KeyboardEvent | null = null;
  public wheelEvent: WheelEvent | null = null;
  public mouseLeftButtonHoldEvent: MouseEvent | null = null;

  private _targetViewportId: string | null = null;

  constructor(info: EVENT_INFO, elementRef: ElementRef, document: Document, mouse: MouseEvent | null, keyboard: KeyboardEvent | null, wheel: WheelEvent | null) {
    this.eventInfo = info;
    this.mouseEvent = mouse;
    this.keyboardEvent = keyboard;
    this.wheelEvent = wheel;
    this.elementRef = elementRef;
    this.document = document;
    if (info === EVENT_INFO.eLeftDownHold || info === EVENT_INFO.eLeftDownRelease) {
      this.mouseLeftButtonHoldEvent = mouse;
    }
  }

  // We use this when we forward an input event from a component that knows the active viewport.
  // This allows us to direct the event to that specific viewport.
  public set targetViewportId(id: string) {
    this._targetViewportId = id;
  }
  public get targetViewportId(): string | null {
    return this._targetViewportId;
  }
}
