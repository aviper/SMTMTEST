import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import Fovia from 'foviaapi';

import {
  getFoviaViewport2DGSPS,
  getFoviaViewport3D,
  getFoviaViewportFused,
  getFoviaViewportMPR,
  getImageAttributes,
  getSlopeIntercept,
  ImageAttributes,
  is2DGSPSViewport,
  is2DRenderParams,
  is3DRenderParams,
  is3DViewport,
  isFusedViewport,
  isMPRViewport,
  isBlendedRenderParams, getStudyAgeString,
} from '../utils';
import { DICOM_OVERLAY_STYLE } from './viewer-settings-info';
import { ExamSeries, IMAGE_LATERALITY, IMAGE_VIEW_POSITION, IMAGE_VIEW_POSITION_MODIFIER, MammoInfo, VirtualSeriesImageRef } from '../models';
import { HTMLViewport2DGSPS, makeImageKey } from '@server-api';
import { WindowLevelHelper } from './window-level';

import {
  BaseDicomOverlayItems2D,
  CrDxDicomOverlayItems2D,
  CtPtDicomOverlayItems2D,
  CtPtDicomOverlayItems3D,
  DICOM_OVERLAY_ITEM,
  FusedDicomOverlayItems3D,
  IDicomOverlayItems,
  MgDicomOverlayItems2D,
  MrDicomOverlayItems2D,
  MrDicomOverlayItems3D,
  NmDicomOverlayItems2D,
  NmDicomOverlayItems3D,
  ThumbnailOverlaylItems,
  UsDicomOverlayItems2D,
  XaDicomOverlayItems2D
} from './dicom-overlay-items';
import { VirtualSeries } from './virtual-series';
import HTMLFusionViewportMPR = Fovia.UI.HTMLFusionViewportMPR;
import HTMLViewport = Fovia.UI.HTMLViewport;
import HTMLViewportMPR = Fovia.UI.HTMLViewportMPR;
import HTMLViewport3D = Fovia.UI.HTMLViewport3D;
import RenderParams = Fovia.RenderParams;
import RenderParams2D = Fovia.RenderParams2D;
import RenderParams3D = Fovia.RenderParams3D;
import RENDER_TYPE = Fovia.RenderType;
import Vector = Fovia.Util.Vector;
import VolumeDataContext = Fovia.VolumeDataContext;
import { DICOM_TAGS, getTagValueAsNumber, getTagValueAsString } from '@server-api/*';

export class AdditionalOverlayInfo {

  public imageNumber: number | null = null;

  public sopInstanceUID = '';
  public viewportTitleSuffix = '';
  public viewPosition: Vector | null = null;
  public viewportId = '';

  public is2D = true;
  public is3D = false;
  public isFused = false;
  public imageAttributes: ImageAttributes | undefined = undefined;
  public volumeDataContext: VolumeDataContext | null = null;
  public renderParams3D: RenderParams3D | null = null;
  public renderParams2D: RenderParams2D | null = null;
  public foviaViewportMPR: HTMLViewportMPR | null = null;
  public foviaViewport3D: HTMLViewport3D | null = null;
  public foviaViewport2DGSPS: HTMLViewport2DGSPS | null = null;
  public foviaViewportFused: HTMLFusionViewportMPR | null = null;
  public isThumbnail = false;
  public isPrimaryExam = true;
  public examDate: string | null = null;
  public examTime: string | null = null;
  public showCad = false;
  private _examSeries: ExamSeries | null = null;
  private _virtualExamSeries: VirtualSeries | null = null;
  private _viewportNumber: number | null = null;

  public constructor() { }

  public set viewportNumber(value: number | null) {
    this._viewportNumber = value;
  }

  public get viewportNumber(): number | null {
    return this._viewportNumber;
  }

  public get htmlViewport(): HTMLViewport | null {
    const vp = this.foviaViewport2DGSPS ?? this.foviaViewportMPR ?? this.foviaViewport3D ?? this.foviaViewportFused ?? null;
    return vp;
  }

  public set htmlViewport(vp: HTMLViewport | null) {
    this.foviaViewportMPR = isMPRViewport(vp) ? getFoviaViewportMPR(vp) : null;
    this.foviaViewport3D = is3DViewport(vp) ? getFoviaViewport3D(vp) : null;
    this.foviaViewport2DGSPS = is2DGSPSViewport(vp) ? getFoviaViewport2DGSPS(vp) : null;
    this.foviaViewportFused = isFusedViewport(vp) ? getFoviaViewportFused(vp) : null;
  }

  public set virtualExamSeries(series: VirtualSeries | null) {
    this._virtualExamSeries = series;
    this.examSeries = series ? series.currentExamSeries : null;
  }
  public get virtualExamSeries(): VirtualSeries | null {
    return this._virtualExamSeries;
  }

  public get examSeries(): ExamSeries | null {
    return this._examSeries;
  }
  private set examSeries(series: ExamSeries | null) {
    this._examSeries = series;
    if (series && series.hasImages) {
      let imageIndex: number;
      if (this.imageNumber != null) {
        imageIndex = this.imageNumber;
      } else {
        imageIndex = 0;
      }

      const dicomTags = series.parentExam.getTagsForInstance(this.sopInstanceUID);
      this.imageAttributes = getImageAttributes(dicomTags, series.foviaSeriesDataContext, imageIndex, this.renderParams, this.htmlViewport);
    } else {
      this.imageAttributes = undefined;
    }
  }

  public get renderParams(): RenderParams | null {
    return this.renderParams2D ?? this.renderParams3D;
  }
  public set renderParams(rp: RenderParams | null) {
    // Blended renderparams are returned as an array
    const isRenderParamArray = Array.isArray(rp);
    if (rp != null) {
      if (is2DRenderParams(rp)) {
        this.is2D = true;
        this.is3D = false;
        this.renderParams2D = rp as RenderParams2D;
        this.imageNumber = this.renderParams2D.imageNumber;
        this.sopInstanceUID = this.renderParams2D.sopInstanceUID;
      } else if (is3DRenderParams(rp) || isBlendedRenderParams(rp)) { // assumes only 3D RenderParams can be arrive as an array.

        if (isRenderParamArray) {
          this.renderParams3D = rp[0] as RenderParams3D;
        } else {
          this.renderParams3D = rp as RenderParams3D;
        }
        if (this.foviaViewportFused != null) {
          this.is2D = false;
          this.is3D = false;
          this.isFused = true;
        } else {
          this.is2D = false;
          this.is3D = true;
          this.isFused = false;
        }
        // Assuming that image-tag parameters of interest for a volume are all the same for a volume
        // so we'll just use the middle image

        this.imageNumber = this.examSeries ? this.examSeries.middleImage : null;
        this.viewPosition = this.renderParams3D.transform.getOffsetVector();
        this.volumeDataContext = this.foviaViewportMPR ? this.foviaViewportMPR.getRenderEngine().getVolumeDataContext() : this.foviaViewport3D != null ? this.foviaViewport3D.getRenderEngine().getVolumeDataContext() : null;
      } else {
        const typeName = (rp as any)['name'] as string;
        throw new Error(`Unsupported RenderParams subtype ${typeName}`);
      }
    } else {
      this.is2D = true;
      this.is3D = false;
      this.isFused = false;
      this.renderParams2D = null;
      this.renderParams3D = null;
    }
  }
}


interface ISliceInfo {
  currentSlice: number;
  totalSlices: number;
}

export class DicomOverlayLine {
  constructor(public text: string, public mainItem: boolean) { }
}

export class DicomOverlayElement {
  constructor(public text: string, public forComparison: boolean, public alternateLines: DicomOverlayLine[] = []) { }
}

export class DicomOverlayContents {
  private _topCenter: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _topLeft: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _topRight: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _middleLeft: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _middleRight: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _bottomCenter: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _bottomLeft: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;
  private _bottomRight: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;

  private readonly examSeries: ExamSeries | null;
  private readonly is2D: boolean = true;
  private readonly imageNumber: number | null;

  constructor(private aoi: AdditionalOverlayInfo, private overlayStyle: DICOM_OVERLAY_STYLE) {
    this.examSeries = aoi.examSeries;
    this.is2D = aoi.is2D;
    this.imageNumber = aoi.imageNumber;

    if (this.examSeries != null) {
      let items: IDicomOverlayItems | null = null;
      if (!this.aoi.isThumbnail) {
        if (this.aoi.isFused) {
          items = new FusedDicomOverlayItems3D(this.examSeries, this.overlayStyle);
        } else {
          switch (this.examSeries.modality) {
            case 'CR':
              items = new CrDxDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle);
              break;
            case 'CT':
              items = this.is2D ?
                new CtPtDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle) :
                new CtPtDicomOverlayItems3D(this.examSeries, this.overlayStyle);
              break;
            case 'DX':
              items = new CrDxDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle);
              break;
            case 'MR':
              items = this.is2D ?
                new MrDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle) :
                new MrDicomOverlayItems3D(this.examSeries, this.overlayStyle);
              break;
            case 'MG':
              items = new MgDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle, aoi.virtualExamSeries);
              break;
            case 'NM':
              items = this.is2D ?
                new NmDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle) :
                new NmDicomOverlayItems3D(this.examSeries, this.overlayStyle);
              break;
            case 'PT':
              items = this.is2D ?
                new CtPtDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle) :
                new CtPtDicomOverlayItems3D(this.examSeries, this.overlayStyle);
              break;
            case 'US':
              items = new UsDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle);
              break;
            case 'XA':
              items = new XaDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle);
              break;
            // case 'OT' 'SC' 'RG' 'RF':
            default:
              items = new BaseDicomOverlayItems2D(this.examSeries, this.imageNumber, this.overlayStyle);
              break;
          }
        }
      } else {
        items = new ThumbnailOverlaylItems(this.examSeries, this.overlayStyle);
      }
      if (items) {
        this._topCenter = this.fillArray(items.topCenterItems);
        this._topLeft = this.fillArray(items.topLeftItems);
        this._topRight = this.fillArray(items.topRightItems);
        this._middleLeft = this.fillArray(items.middleLeftItems);
        this._middleRight = this.fillArray(items.middleRightItems);
        this._bottomCenter = this.fillArray(items.bottomCenterItems);
        this._bottomLeft = this.fillArray(items.bottomLeftItems);
        this._bottomRight = this.fillArray(items.bottomRightItems);
      }
    }
  }
  public get topLeft(): Array<DicomOverlayElement> {
    return this._topLeft;
  }
  public get topCenter(): Array<DicomOverlayElement> {
    return this._topCenter;
  }
  public get topRight(): Array<DicomOverlayElement> {
    return this._topRight;
  }
  public get middleLeft(): Array<DicomOverlayElement> {
    return this._middleLeft;
  }
  public get middleRight(): Array<DicomOverlayElement> {
    return this._middleRight;
  }
  public get bottomLeft(): Array<DicomOverlayElement> {
    return this._bottomLeft;
  }
  public get bottomCenter(): Array<DicomOverlayElement> {
    return this._bottomCenter;
  }
  public get bottomRight(): Array<DicomOverlayElement> {
    return this._bottomRight;
  }

  private fillArray(items: Array<DICOM_OVERLAY_ITEM>): Array<DicomOverlayElement> {
    const elementArray: Array<DicomOverlayElement> = new Array<DicomOverlayElement>;

    items.forEach(item => {
      const element: DicomOverlayElement | null = this.getItemElement(item);
      if (element && element.text != null) {
        elementArray.push(element);
      }
    });
    return elementArray;
  }
  private getItemElement(item: DICOM_OVERLAY_ITEM): DicomOverlayElement {
    const result: DicomOverlayElement = new DicomOverlayElement('', false);
    if (this.examSeries != null && this.aoi != null && this.aoi.htmlViewport != null) {
      let sdc: Fovia.SeriesDataContext | undefined | null = this.aoi.htmlViewport.getSeriesDataContext();
      let imageTags: Fovia.DICOMImageTags | undefined = (this.imageNumber != null) ? sdc?.getDicomTagByIndex(this.imageNumber) : undefined;
      let mammoImageInfo: MammoInfo | null = null;
      if (this.examSeries.haveMammoInfo(this.aoi.sopInstanceUID)) {
        mammoImageInfo = this.examSeries.getMammoInfo(this.aoi.sopInstanceUID);
      }

      if (this.aoi.virtualExamSeries) {
        const imageRef: VirtualSeriesImageRef = this.aoi.virtualExamSeries.currentImageRef;
        sdc = imageRef.imageSet.seriesDataContext;
        if (sdc) {
          imageTags = sdc.imageTags[imageRef.imageIndex];
        }
      }

      if (sdc) {
        switch (item) {
          case DICOM_OVERLAY_ITEM.PATIENT_NAME: {
            // Format as LN, FN, MI including the commas
            const tmp: string[] = sdc.patientName.split('^');
            const last: string = tmp[0] != null && tmp[0].length > 0 ? tmp[0] : 'NA';
            const first: string = tmp[1] != null && tmp[1].length > 0 ? tmp[1] : 'NA';
            const middle: string = tmp[2] != null && tmp[2].length > 0 ? ', ' + tmp[2].charAt(0) : '';

            // The comma for middle initial is conditionally included above.
            result.text = `${last}, ${first}${middle}`;
            break;
          }
          case DICOM_OVERLAY_ITEM.PATIENT_BIRTHDAY: {
            const examDate = sdc.studyDate.trim();
            const birthDate = sdc.patientBirthDate.trim();
            let ageString: string | undefined;
            if (examDate && birthDate) {
              try {
                const examMoment = dayjs(examDate, 'YYYYMMDD', true);
                const birthMoment = dayjs(birthDate, 'YYYYMMDD', true);
                const ageAtTimeOfExamDays = examMoment.diff(birthMoment, 'days');
                if (ageAtTimeOfExamDays >= 0 && ageAtTimeOfExamDays <= 28) {
                  const suffix = ageAtTimeOfExamDays === 1 ? 'day' : 'days';
                  ageString = `${ageAtTimeOfExamDays} ${suffix}`;
                } else if (ageAtTimeOfExamDays > 28 && ageAtTimeOfExamDays <= 112) {
                  const ageAtTimeOfExamWeeks = examMoment.diff(birthMoment, 'weeks');
                  const suffix = ageAtTimeOfExamWeeks === 1 ? 'week' : 'weeks';
                  ageString = `${ageAtTimeOfExamWeeks} ${suffix}`;
                } else if (ageAtTimeOfExamDays > 112 && ageAtTimeOfExamDays < 365) {
                  const ageAtTimeOfExamMonths = examMoment.diff(birthMoment, 'month', true);
                  const wholeMonths = Math.floor(ageAtTimeOfExamMonths);
                  const wholeWeeks = Math.floor((ageAtTimeOfExamMonths - wholeMonths) * 4);
                  if (wholeWeeks > 0) {
                    const suffixWeeks = wholeWeeks === 1 ? 'week' : 'weeks';
                    const suffixMonths = wholeMonths === 1 ? 'month' : 'months';
                    ageString = `${wholeMonths} ${suffixMonths} ${wholeWeeks} ${suffixWeeks}`;
                  } else {
                    const suffixMonths = wholeMonths === 1 ? 'month' : 'months';
                    ageString = `${wholeMonths} ${suffixMonths}`;
                  }
                } else if (ageAtTimeOfExamDays >= 365) {
                  const ageAtTimeOfExamYears = examMoment.diff(birthMoment, 'years');
                  const ageAtTimeOfExamMonths = examMoment.diff(birthMoment, 'month');
                  const suffixYears = ageAtTimeOfExamYears === 1 ? 'year' : 'years';
                  if (ageAtTimeOfExamYears > 0 && ageAtTimeOfExamYears < 18) {
                    const wholeMonths = ageAtTimeOfExamMonths - (ageAtTimeOfExamYears * 12);
                    const suffixMonths = wholeMonths === 1 ? 'month' : 'months';
                    if (wholeMonths > 0) {
                      ageString = `${ageAtTimeOfExamYears} ${suffixYears} ${wholeMonths} ${suffixMonths}`;
                    } else {
                      ageString = `${ageAtTimeOfExamYears} ${suffixYears}`;
                    }
                  } else if (ageAtTimeOfExamYears >= 18) {
                    ageString = `${ageAtTimeOfExamYears} ${suffixYears}`;
                  } else { // Leap year and patient was 365 days old.
                    const suffixMonths = ageAtTimeOfExamMonths === 1 ? 'month' : 'months';
                    ageString = `${ageAtTimeOfExamMonths} ${suffixMonths}`;
                  }
                } else { // birth date after exam date??
                  ageString = undefined;
                }
              } catch (err) {
                ageString = undefined;
              }
            }
            if (birthDate) {
              try { // Date parsing
                const birthMoment = dayjs(birthDate, 'YYYYMMDD', true);
                const birthDateDisplay = birthMoment.format('DD-MMM-YYYY');
                if (ageString) {
                  result.text = `DOB (Age): ${birthDateDisplay} (${ageString})`;
                } else {
                  result.text = `DOB: ${birthDateDisplay}`;
                }
              } catch (err) {
                result.text = `DOB: ${birthDate}`;
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.PATIENT_MRN: {
            result.text = `Patient ID (MRN): ${sdc.patientID}`;
            break;
          }
          case DICOM_OVERLAY_ITEM.PATIENT_SEX: {
            const input = sdc.patientSex;
            // Male, Female or Other
            result.text = (input.includes('M') || input.includes('F') || input.includes('O')) ? `Sex: ${input}` : `Sex: O`;
            break;
          }
          case DICOM_OVERLAY_ITEM.SERIES_NUMBER: {
            result.text = `Series# ${sdc.seriesNumber}`;
            break;
          }
          case DICOM_OVERLAY_ITEM.SERIES_NAME: {
            result.text = this.aoi.examSeries?.getSeriesDescription(this.aoi.sopInstanceUID) ?? sdc.seriesDescription;
            break;
          }
          case DICOM_OVERLAY_ITEM.VIEWPORT_TITLE: {
            result.text = sdc.seriesDescription + this.aoi.viewportTitleSuffix;
            break;
          }
          case DICOM_OVERLAY_ITEM.IMAGE_NUMBER: {
            // Image# (#/#)
            if (this.imageNumber != null) {
              if (this.examSeries.isMultiframeImage(this.imageNumber)) {
                if (imageTags) {
                  result.text = `Frame ${imageTags.frameNumber}/${imageTags.totalFrames}`;
                } else {
                  result.text = `Frame ${this.imageNumber + 1}/${sdc.getNumImages()}`;
                }
              } else {
                result.text = `Image# (${this.imageNumber + 1} / ${sdc.getNumImages()})`;
              }
              if (this.examSeries.isModalityMG()) {
                // At the very least we add TOMO to multi-frame images for mammo.
                if (this.examSeries.isMultiframeImage(this.imageNumber)) {
                  result.text += 'TOMO';
                }
              }
              // Special handling for stacked images, either single frame or multi-frame.
              if (this.aoi.virtualExamSeries && this.aoi.virtualExamSeries.isStacked) {
                if (this.examSeries.isMultiframeImage(this.imageNumber)) {
                  result.text = `Image# ${this.aoi.virtualExamSeries.currentSetIndex + 1}/${this.aoi.virtualExamSeries.imageSets.length} : Frame ${this.imageNumber + 1}/${sdc.getNumImages()} TOMO`;
                } else {
                  // For single-frame images, just display the image number relative to the number of images in the stack
                  result.text = `Image# ${this.aoi.virtualExamSeries.currentImageRefIndex + 1}/${this.aoi.virtualExamSeries.imageCount}`;
                }
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.STACK_LOCATION: {
            if (this.aoi.viewportNumber) {
              result.text = `Viewport #${this.aoi.viewportNumber}: `;
            }
            if (this.aoi.virtualExamSeries) {
              result.text += `Image ${this.aoi.virtualExamSeries.currentSetIndex + 1}/${this.aoi.virtualExamSeries.imageSets.length}`;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.INSTITUTION_NAME: {
            result.text = sdc.institutionName;
            break;
          }
          case DICOM_OVERLAY_ITEM.INSTITUTION_ADDRESS: {
            result.text = mammoImageInfo && mammoImageInfo.institutionAddress !== '' ? mammoImageInfo.institutionAddress : 'Unknown address';
            break;
          }
          case DICOM_OVERLAY_ITEM.STATION_NAME: {
            result.text = `Station ${mammoImageInfo && mammoImageInfo.stationName !== '' ? mammoImageInfo.stationName : 'Unknown'}`;
            break;
          }
          case DICOM_OVERLAY_ITEM.CASSETTE_ID: {
            if (mammoImageInfo && mammoImageInfo.cassetteId !== '') {
              result.text = `Cassette ${mammoImageInfo.cassetteId}`;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.OPERATORS_NAME: {
            result.text = `Operator ${mammoImageInfo && mammoImageInfo.operatorsName !== '' ? mammoImageInfo.operatorsName : 'Unknown'}`;
            break;
          }
          case DICOM_OVERLAY_ITEM.STUDY_DESCRIPTION: {
            result.text = sdc.studyDescription;
            break;
          }
          case DICOM_OVERLAY_ITEM.STUDY_DATE_TIME: {
            const sourceDate = this.aoi.examDate ?? sdc.studyDate;
            const sourceTime = this.aoi.examTime ?? sdc.studyTime;
            const date: string = dayjs(sourceDate, 'YYYYMMDD').format('DD-MMM-YYYY');
            dayjs.extend(customParseFormat);
            const time: string = dayjs(sourceTime, 'hhmmss').format('hh:mm A');
            if (this.aoi.virtualExamSeries && this.aoi.virtualExamSeries.isStacked) {
              result.text = this.aoi.isPrimaryExam ? `${date}, ${time}` : `COMPARISON ${date}`;
              result.forComparison = !this.aoi.isPrimaryExam || this.aoi.virtualExamSeries.isStoredMontageComparisonImage;
            } else {
              result.text = this.examSeries.isPrimaryExam ? `${date}, ${time}` : `COMPARISON ${date}`;
              result.forComparison = !this.examSeries.isPrimaryExam || (this.aoi.virtualExamSeries?.isStoredMontageComparisonImage ?? false);
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.ACQUISITION_DATE_TIME: {
            if (this.aoi.imageAttributes) {
              if (this.aoi.isPrimaryExam) {
                const date: string = dayjs(this.aoi.imageAttributes.acquisitionDate, 'YYYYMMDD').format('DD-MMM-YYYY');
                dayjs.extend(customParseFormat);
                const time: string = dayjs(this.aoi.imageAttributes.acquisitionTime, 'hhmmss').format('hh:mm A');
                // TODO I gave up waiting for Deepak's input on this. I think we're better off with just acquisition time, although this
                // isn't 100% accurate when an exam spans midnight.
                // result.text = `Acquisition ${date}, ${time}`;
                result.text = `Acquisition ${time}`;
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.STUDY_AGE: {
            let isComparison = false;
            if (this.aoi.virtualExamSeries && this.aoi.virtualExamSeries.isStacked) {
              isComparison = !this.aoi.isPrimaryExam;
            } else {
              isComparison = !this.examSeries.isPrimaryExam;
            }

            // We only show the study age for comparison exams.
            if (isComparison) {
              result.forComparison = true;
              // 0 hours ago, 1 hour ago, 1 week ago, 1 month ago, 1 year ago, 1 year, 1 month ago
              result.text = getStudyAgeString(this.aoi.examDate ?? sdc.studyDate, this.aoi.examTime ?? sdc.studyTime);
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.FUSION: {
            const date: string = dayjs().format('DD-MMM-YYYY');
            dayjs.extend(customParseFormat);

            if (date) {
              result.text = `Fused Series ${date}`;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.ACCESSION_NUMBER: {
            const input = sdc.studyAccessionNumber.trim();
            result.text = input.length > 0 ? `Accession # ${input}` : input;
            break;
          }
          case DICOM_OVERLAY_ITEM.WINDOW_LEVEL:
          case DICOM_OVERLAY_ITEM.WL_FIELD_ECHO: {
            const rp = this.aoi.renderParams2D ? this.aoi.renderParams2D : this.aoi.renderParams3D;

            if (rp != null) {
              // Use S/I to convert W/L for Display
              const slopeIntercept = getSlopeIntercept(imageTags, sdc, this.aoi.volumeDataContext);
              const wlHelper = WindowLevelHelper.fromRenderParams(rp, slopeIntercept);
              const windowLevel = wlHelper.displayedWL;
              const wlinfo = windowLevel.toString();
              if (wlinfo.length > 0) {
                result.text = wlinfo;
              }
            }
            if (item === DICOM_OVERLAY_ITEM.WL_FIELD_ECHO && this.aoi.imageAttributes) {
              if (this.aoi.imageAttributes.fieldStrength !== null) {
                result.text += `, ${this.aoi.imageAttributes.fieldStrength.toFixed(1)} T`;
              }
              if (this.aoi.imageAttributes.echoTrainLength !== null) {
                // typical values
                // - FSE T1: 2–6
                // - FSE T2: 8–32+
                if (this.aoi.imageAttributes.echoTrainLength >= 2 && this.aoi.imageAttributes.echoTrainLength <= 6) {
                  result.text += `, ${this.aoi.imageAttributes.echoTrainLength.toFixed(0)} (FSE T1)`;
                } else if (this.aoi.imageAttributes.echoTrainLength >= 8) {
                  result.text += `, ${this.aoi.imageAttributes.echoTrainLength.toFixed(0)} (FSE T2)`;
                } else {
                  result.text += `, ETL: ${this.aoi.imageAttributes.echoTrainLength.toFixed(0)}`;
                }
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.SCALE_COMPRESSION: {
            if (this.aoi.imageAttributes) {
              const attrib = this.aoi.imageAttributes;
              const scaleFactor = attrib.scaleFactor;
              const lossyCompressed = attrib.lossyCompressedForDisplay || attrib.lossyCompressedForStorage;

              if (lossyCompressed) {
                if (attrib.lossyCompressionRatioNumerator > 1) {
                  result.text = `${scaleFactor.toFixed(2)}X (Lossy ${attrib.lossyCompressionRatioNumerator}:${attrib.lossyCompressionRatioDenominator})`;
                } else {
                  result.text = `${scaleFactor.toFixed(2)}X (Lossy)`;
                }
              } else {
                result.text = `${scaleFactor.toFixed(2)}X (Lossless)`;
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.RENDER_TYPE:
            if (this.aoi.renderParams3D) {
              const rt = RENDER_TYPE[this.aoi.renderParams3D.renderType];
              result.text = `Render Type: ${rt}`;
            }
            break;
          case DICOM_OVERLAY_ITEM.SLICE_THICKNESS:
            if (imageTags != null && imageTags.sliceThickness != null && imageTags.sliceThickness !== 0) {
              result.text = `Slice thickness: ${imageTags.sliceThickness.toFixed(1)} mm`;
            }
            break;
          case DICOM_OVERLAY_ITEM.SLICE_THICKNESS_LOCATION:
            if (imageTags != null && imageTags.sliceThickness != null && imageTags.sliceThickness !== 0) {
              result.text = `Thickness: ${imageTags.sliceThickness.toFixed(1)} mm`;
            }
            if (imageTags != null && imageTags.sliceLocation != null && imageTags.sliceLocation !== 0) {
              result.text += `, Location: ${imageTags.sliceLocation.toFixed(1)} mm`;
            }
            break;
          case DICOM_OVERLAY_ITEM.VIEW_POSITION:
            if (this.aoi.renderParams3D && this.aoi.viewPosition) {
              const pos = this.aoi.viewPosition;
              result.text = `Loc: ${pos.x.toFixed(1)},${pos.y.toFixed(1)},${pos.z.toFixed(1)} mm`;
            }
            break;
          // Values are dynamic for MPR
          case DICOM_OVERLAY_ITEM.SLICE_LOCATION:
            if (this.aoi.renderParams3D && this.aoi.foviaViewportMPR) {
              const viewType = this.aoi.foviaViewportMPR['viewType'];
              const sliceInfo: ISliceInfo = this.aoi.foviaViewportMPR.getHtmlViewportAdaptors().getSliceInfofromAxisAlignedScrollAdaptors(viewType, this.aoi.renderParams3D);
              result.text = `Slice: ${sliceInfo.currentSlice}/${sliceInfo.totalSlices}`;
            }
            break;
          case DICOM_OVERLAY_ITEM.SLAB_THICKNESS:
            if (this.aoi.renderParams3D) {
              const slab_thickness = this.aoi.renderParams3D.slabThickness.toFixed(1);
              result.text = `Slab Thickness: ${slab_thickness}`;
            }
            break;
          case DICOM_OVERLAY_ITEM.CONTRAST: {
            const contrastRoute = this.examSeries.getContrastBolusRoute(this.aoi.sopInstanceUID);
            if (contrastRoute && contrastRoute.indexOf('IV') !== -1) {
              result.text = 'Contrast';
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.IMAGE_LATERALITY: {
            if (this.aoi.virtualExamSeries) {
              result.alternateLines.push(new DicomOverlayLine(`${this.aoi.virtualExamSeries.currentSetIndex + 1}/${this.aoi.virtualExamSeries.imageSets.length}`, false));
              result.forComparison = !this.aoi.isPrimaryExam;
              for (const [index, value] of this.aoi.virtualExamSeries.imageSets.entries()) {
                const mammoInfo = value.sourceSeries?.getMammoInfo(value.sourceSeries?.getImageInstanceUID(value.firstImageIndex));
                if (mammoInfo) {
                  result.alternateLines.push(new DicomOverlayLine(this.buildViewPositionLabel(mammoInfo), index === this.aoi.virtualExamSeries.currentSetIndex));
                }
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.CAD: {
            const instanceUID = imageTags?.sopInstanceUID;
            const frameNumber = imageTags?.frameNumber;
            if (instanceUID != null && frameNumber != null
                && this.aoi.virtualExamSeries?.currentImageRef?.imageSet.sourceSeries?.parentExam?.isInstanceCADProcessed(instanceUID)) {
              if (this.aoi.showCad) {
                const key = makeImageKey(instanceUID, frameNumber);
                const cadFindingInfo = sdc.cadFindingsInfo.filter(info => info.sopInstanceUID === key);
                const cadAnnotations = cadFindingInfo.reduce((acc, curr) => curr.numOfClusterFindings + curr.numOfDensityFindings + acc, 0);
                result.text += `CAD this image ${cadAnnotations}`;
              }
              else {
                result.text += 'Processed by CAD';
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.FIELD_OF_VIEW:
          case DICOM_OVERLAY_ITEM.TR_TE_FOV: {
            if (this.aoi.imageAttributes) {
              if (item === DICOM_OVERLAY_ITEM.TR_TE_FOV) {
                if (this.aoi.imageAttributes.echoTime !== null) {
                  result.text = `TE: ${this.aoi.imageAttributes.echoTime.toFixed(0)} ms, `;
                }
                if (this.aoi.imageAttributes.repetitionTime !== null) {
                  result.text += `TR: ${this.aoi.imageAttributes.repetitionTime.toFixed(0)} ms, `;
                }
              }
              let fov: number;
              if (this.aoi.imageAttributes.storedFieldOfViewDiameter !== undefined) {
                fov = this.aoi.imageAttributes.storedFieldOfViewDiameter;
              } else if (this.aoi.imageAttributes.storedFieldOfViewX !== undefined) {
                fov = this.aoi.imageAttributes.storedFieldOfViewX;
              } else { // No stored field of view
                fov = this.aoi.imageAttributes.physicalSizeX;
              }
              fov = fov / 10.0; // Convert stored millimeters to display centimeters.
              result.text += `FOV: ${fov.toFixed(2)}cm`;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.CROP: {
            if (this.aoi.imageAttributes) {
              if (this.aoi.imageAttributes.cropped) {
                result.text = 'Cropped';
              } else {
                result.text = 'Uncropped';
              }
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.TE_TR: {
            // This is referenced in some design images but not in the card for this feature
            // result = sdc.getDicomTagByIndex(this.renderParams2D.imageNumber).<fovia to provide>;
            break;
          }
          case DICOM_OVERLAY_ITEM.PULSE_SEQUENCE: {
            // this is referenced in some design images but not in the card for this feature
            // result = sdc.getDicomTagByIndex(this.renderParams2D.imageNumber).<fovia to provide>;
            break;
          }
          case DICOM_OVERLAY_ITEM.IMAGE_COUNT: {
            if (this.aoi.virtualExamSeries) {
              let count = 0;
              for (const imageSet of this.aoi.virtualExamSeries.imageSets) {
                count += imageSet.numImages;
              }
              result.text = `${count}`;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.SERIES_NAME_SUBSERIES: {
            if (this.is2D) {
              result.text = this.aoi.virtualExamSeries?.currentImageRef.imageSet?.seriesDataContext?.seriesDescription ?? '';
            } else {
              result.text = this.examSeries.seriesNameForSubSeries;
            }
            break;
          }
          case DICOM_OVERLAY_ITEM.DUPLICATE: {
            result.text = this.aoi.virtualExamSeries?.currentImageRef.imageSet.isDuplicate ? 'DUPLICATE' : '';
          }
        }
      }
    }
    return result;
  }
  private buildViewPositionLabel(mammoInfo: MammoInfo): string {
    let result = '';
    if (mammoInfo && mammoInfo.laterality !== IMAGE_LATERALITY.UNKNOWN && mammoInfo.viewPosition !== IMAGE_VIEW_POSITION.UNKNOWN) {
      result = mammoInfo.laterality === IMAGE_LATERALITY.LEFT ? 'L' : 'R';
      result += IMAGE_VIEW_POSITION[mammoInfo.viewPosition];

      switch (mammoInfo.viewPosModifier) {
        case IMAGE_VIEW_POSITION_MODIFIER.IMPLANT_DISPLACED:
          result += ' ID';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.CLEAVAGE:
          // Replace, not append.
          result = 'CV';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.ANTERIOR_COMPRESSION:
          result += ' AC';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.MAGNIFICATION:
          result += ' M';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.INFRA_MAMMARY_FOLD:
          result += ' IF';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.ROLLED_INFERIOR:
          result += ' RI';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.ROLLED_LATERAL:
          result += ' RL';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.ROLLED_MEDIAL:
          result += ' RM';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.ROLLED_SUPERIOR:
          result += ' RS';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.SPOT_COMPRESSION:
          result += ' SC';
          break;
        case IMAGE_VIEW_POSITION_MODIFIER.TANGENTIAL:
          result += ' T';
          break;
      }
    }
    return result;
  }
}
