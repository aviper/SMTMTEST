import { PanelSetInfo } from './panel-set';

describe('PanelSet', () => {
  it('should create an instance', () => {
    expect(new PanelSetInfo()).toBeTruthy();
  });
});
