import { PRESET_PATH } from '../services';
import { get3DPresetTFList, CT_BONE } from '../utils';

export class Presets3D {


  readonly DEFAULT_PRESET: string = CT_BONE;

  private _presetList: string[] = [];
  private _menuItemList: string[] = [];

  public currentPresetSelection: number;
  public defaultPresetSelection: number;

  constructor(defaulPreset: string) {
    this.DEFAULT_PRESET = defaulPreset;
    this.defaultPresetSelection = 0;
    this.currentPresetSelection = this.defaultPresetSelection;
  }

  public set presetList(value: string[]) {
    this._presetList = value;
    this._menuItemList = value;

    const index = this._menuItemList.findIndex((entry) => entry === this.DEFAULT_PRESET);
    if (index >= 0) {
      this.currentPresetSelection = this.defaultPresetSelection = index;
    }
  }

  public get presetList(): string[] {
    return this._presetList;
  }

  public get menuList(): string[] {
    return this._menuItemList;
  }

  public getFullPresetName(index: number): string {
    const fullPresetName = '';
    if (index >= this.presetList.length) {
      return fullPresetName;
    }
    return `${this.presetList[index]}`;
  }

  public reset(): void {
    this.currentPresetSelection = this.defaultPresetSelection;
  }

}
