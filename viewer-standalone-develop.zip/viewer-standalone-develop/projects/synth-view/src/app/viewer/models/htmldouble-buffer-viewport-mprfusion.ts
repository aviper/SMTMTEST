import Fovia from 'foviaapi';

export enum FUSION_VIEWPORT_TYPE {
  BASE,
  OVERLAY,
  FUSED,
  ADDITIONAL
}

// This class only exists so we can differentiate between regular MPR viewports and fusion MPR viewports
export class HTMLDoubleBufferViewportMPRFusion extends Fovia.UI.HTMLDoubleBufferViewportMPR {
  constructor(public type: FUSION_VIEWPORT_TYPE,
              htmlElementName: string,
              width: number,
              height: number,
              repaintable?: boolean,
              usePNG?: boolean,
              renderEngineLocation?: Fovia.RenderLocation) {
    super(htmlElementName, width, height, repaintable, usePNG, renderEngineLocation);
  }
}
