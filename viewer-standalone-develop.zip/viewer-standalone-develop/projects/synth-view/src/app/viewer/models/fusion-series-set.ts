import Fovia from 'foviaapi';
import { VirtualSeries } from './virtual-series';
import { Viewport3DInfo } from './panel-template';
import { SeriesDisplayStoreItem3dFused, SeriesDisplayStoreItem3DMPR } from '../stores';
import { IMAGE_PLANE } from '../utils';
import { FUSION_VIEWPORT_TYPE } from './htmldouble-buffer-viewport-mprfusion';

export class FusionSeries {
     constructor(public vSeries: VirtualSeries,
    public viewport3DInfo: Viewport3DInfo,
              public displayStoreItem: SeriesDisplayStoreItem3DMPR
  ) {}
}

export class FusionSeriesSet {
  public fusedViewport3DInfo: Viewport3DInfo | null = null;
  public fusedDisplayStoreItem: SeriesDisplayStoreItem3dFused | null = null;
  public _viewType: Fovia.ViewType | null = null;
  public initialViewType: Fovia.ViewType | null = null;

  constructor(protected _baseSeries: FusionSeries | null = null,
              protected _overlaySeries: FusionSeries | null = null,
              protected _additionalSeries: FusionSeries | null = null) {
  }

  public duplicate(): FusionSeriesSet {
    const fusionSeriesSet =  new FusionSeriesSet(this._baseSeries, this._overlaySeries, this._additionalSeries);
    fusionSeriesSet.fusedViewport3DInfo = this.fusedViewport3DInfo;
    fusionSeriesSet._viewType = this._viewType;
    fusionSeriesSet.initialViewType = this.initialViewType;
    return fusionSeriesSet;
  }

  public set viewType(value: Fovia.ViewType | null) {
    this._viewType = value;
  }

  public get viewType(): Fovia.ViewType | null {
    return this._viewType;
  }

  public get baseSeries(): FusionSeries | null {
    return this._baseSeries;
  }

  public set baseSeries(fusionSeries) {
    this._baseSeries = fusionSeries;
  }

  public get overlaySeries(): FusionSeries | null {
    return this._overlaySeries;
  }

  public set overlaySeries(fusionSeries) {
    this._overlaySeries = fusionSeries;
  }

  public get additionalSeries(): FusionSeries | null {
    return this._additionalSeries;
  }

  public set additionalSeries(fusionSeries) {
    this._additionalSeries = fusionSeries;
  }

  public addFusionSeries(vSeries: VirtualSeries, viewport3DInfo: Viewport3DInfo, displayStoreItem: SeriesDisplayStoreItem3DMPR, viewportType: FUSION_VIEWPORT_TYPE): void {
    if (viewportType === FUSION_VIEWPORT_TYPE.FUSED) {
      console.error(`addFusionSeries: fused series type not handled by this method`);
      return;
    }
    if (this.viewType == null) {
      this.viewType = this.getViewTypeFromSeries(vSeries);
    }
    viewport3DInfo.viewType = this.viewType;

    const newSeries = new FusionSeries(vSeries, viewport3DInfo, displayStoreItem);
    switch (viewportType) {
      case FUSION_VIEWPORT_TYPE.ADDITIONAL:
        this.additionalSeries = newSeries;
        break;
      case FUSION_VIEWPORT_TYPE.BASE:
        this.baseSeries = newSeries;
        break;
      case FUSION_VIEWPORT_TYPE.OVERLAY:
        this.overlaySeries = newSeries;
        break;
    }
  }

  protected getViewTypeFromSeries(vSeries: VirtualSeries): Fovia.ViewType {
    let viewType: Fovia.ViewType = Fovia.ViewType.axial;
    const series = vSeries.currentExamSeries;
    if (series != null) {
      switch (series.plane) {
        case IMAGE_PLANE.UNKNOWN:
        case IMAGE_PLANE.AXIAL:
          viewType = Fovia.ViewType.axial;
          break;
        case IMAGE_PLANE.CORONAL:
          viewType = Fovia.ViewType.coronal;
          break;
        case IMAGE_PLANE.SAGITTAL:
          viewType = Fovia.ViewType.sagittal;
          break;
      }
    }
    return viewType;
  }
}
