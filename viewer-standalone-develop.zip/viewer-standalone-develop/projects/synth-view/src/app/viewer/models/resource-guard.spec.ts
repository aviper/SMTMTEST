import { ResourceGuard } from './resource-guard';

describe('ResourceGuard', () => {
  it('should create an instance', () => {
    expect(new ResourceGuard()).toBeTruthy();
  });
});
