export enum PANEL_ORIENTATION { unknown = 0, landscape, portrait }
export enum PANEL_FORMAT {
  one_up,
  two_up,
  four_up,
  six_up,
  eight_up,
  twelve_up,
  mg_six_up,
  mg_eight_up,
  mg_twelve_up,
  customFixed
}
