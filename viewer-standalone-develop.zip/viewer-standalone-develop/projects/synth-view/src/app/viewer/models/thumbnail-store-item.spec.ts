import { ThumbnailStoreItem } from './thumbnail-store-item';

describe('ThumbnailStoreItem', () => {
  it('should create an instance', () => {
    expect(new ThumbnailStoreItem()).toBeTruthy();
  });
});
