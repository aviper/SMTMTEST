import { EDGE_ENHANCEMENT_LEVEL_TYPE, EdgeEnhancementLevel } from './edge-enhancement-level';

describe('EdgeEnhancementLevel', () => {
  it('should create an instance', () => {
    expect(new EdgeEnhancementLevel(EDGE_ENHANCEMENT_LEVEL_TYPE.low)).toBeTruthy();
  });
});
