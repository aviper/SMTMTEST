import { calcImagePlane, calcSeriesPlane, IMAGE_PLANE, Point } from '../utils';
import { calcMiddleImage, compareDicomTime, DICOM_TAGS, MONTAGE_SERIES_DESCRIPTION, SYNTH_CONTENT_DESC_MONTAGE, SYNTH_CONTENT_DESC_MONTAGE_PRIORS } from '@server-api';
import { getPanelTemplate, IPanelTemplate, PANEL_TEMPLATE_TYPE } from './panel-template';
import Fovia from 'foviaapi';
import { MammoInfo } from './mammo-info';
import { Exam } from './exam';
import VolumeDataContext = Fovia.VolumeDataContext;
import SeriesDataContext = Fovia.SeriesDataContext;
import { SUVInfo } from './suv-info';

export class ExamSeries {
  private _plane: IMAGE_PLANE = IMAGE_PLANE.UNKNOWN;
  private _numImages = 0;
  private _middleImage = 0;
  private readonly _isUnityMontage;
  private readonly _isSynthesisMontage;

  private _volumeDataContext: VolumeDataContext | null = null;
  private _3DseriesLayout: IPanelTemplate | null = null;

  constructor(public parentExam: Exam, private _foviaSeries: Fovia.ScanDirSeriesResults, private _isPrimary: boolean, private seriesDataContext: SeriesDataContext) {
    this._numImages = this._foviaSeries.dicomSeries.getNumImages();
    this._middleImage = calcMiddleImage(this.seriesDataContext);
    this._plane = calcSeriesPlane(this);
    this._isUnityMontage = this.foviaSeriesDataContext.seriesDescription.toUpperCase() === MONTAGE_SERIES_DESCRIPTION;
    this._isSynthesisMontage = this.foviaSeriesDataContext.seriesDescription.toUpperCase().includes(SYNTH_CONTENT_DESC_MONTAGE.toUpperCase())
      || this.foviaSeriesDataContext.seriesDescription.toUpperCase().includes(SYNTH_CONTENT_DESC_MONTAGE_PRIORS.toUpperCase());
  }

  public get numImages(): number {
    return this._numImages;
  }

  public get studyInstanceUID(): string {
    return this.seriesDataContext.studyInstanceUID;
  }

  public get seriesInstanceUID(): string {
    return this.seriesDataContext.seriesInstanceUID;
  }

  public get frameOfReferenceUID(): string | null {
    return (this.seriesDataContext.imageTags.length > 0)
      ? this.seriesDataContext.imageTags[this.middleImage].frameOfReferenceUID
      : null;
  }

  public getImageFrameOfReferenceUID(sopInstanceUID: string): string | null {
    const imageIndex = this.getImageIndex(sopInstanceUID);
    return (imageIndex >= 0 && imageIndex < this.seriesDataContext.imageTags.length)
      ? this.seriesDataContext.imageTags[imageIndex].frameOfReferenceUID
      : null;
  }


  public get isUnityMontage(): boolean {
    return this._isUnityMontage;
  }
  public get isSynthesisMontage(): boolean {
    return this._isSynthesisMontage;
  }
  public get isMontage(): boolean {
    return this.isUnityMontage || this.isSynthesisMontage;
  }
  public getImageInstanceUID(imageNumber: number): string {
    return this.foviaSeriesDataContext.getDicomTagByIndex(imageNumber).sopInstanceUID;
  }

  public getDicomImageTags(imageNumber: number): Fovia.DICOMImageTags {
    return this.foviaSeriesDataContext.imageTags[imageNumber];
  }

  public getImageIndex(imageInstanceUID: string): number {
    for (let i = 0; i < this.seriesDataContext.imageCount; i++) {
      if (this.foviaSeriesDataContext.getDicomTagByIndex(i).sopInstanceUID === imageInstanceUID) {
        return i;
      }
    }
    return -1;
  }

  public getImageIndexBySopInstanceUID(sopInstanceUID: string, frameNumber: number): number {
    return this.foviaSeriesDataContext.getImageIndexBySopInstanceUid(sopInstanceUID, frameNumber);
  }

  // This assumes that the series is just one multiframe
  public get isMultiframe(): boolean {
    return this.isMultiframeImage(0);
  }

  public get seriesDescription(): string {
    return this.seriesDataContext.seriesDescription;
  }

  public get sliceThickness(): number {
    return this.seriesDataContext.imageTags[this.middleImage]?.sliceThickness ?? 0;
  }

  public get pixelSpacing(): Point {
    const pixelSpacing = this.seriesDataContext.imageTags[this.middleImage]?.pixelSpacing;
    const tmp = pixelSpacing.split('\\');
    const dicomPixelSpacing = tmp.length === 2 ? new Point(parseFloat(tmp[0]), parseFloat(tmp[1])) : new Point(0, 0);
    return dicomPixelSpacing;
  }
  public isMultiframeImage(imageIndex: number): boolean {
    const totalFrames = this.getImageFrameCount(imageIndex);
    return (totalFrames > 1);
  }

  public getImageFrameCount(imageIndex: number): number {
    return this.seriesDataContext.imageTags[imageIndex]?.totalFrames ?? 1;
  }

  public hasMultiframeImage(): boolean {
    for (let imageIndex = 0; imageIndex < this.seriesDataContext.imageCount; imageIndex++) {
      if (this.isMultiframeImage(imageIndex)) {
        return true;
      }
    }
    return false;
  }

  public get middleImage(): number {
    return this._middleImage;
  }

  public get plane(): IMAGE_PLANE {
    return this._plane;
  }

  public getImagePlane(sopInstanceUID: string): IMAGE_PLANE {
    return calcImagePlane(this, this.getImageIndex(sopInstanceUID));
  }

  public get seriesOrientation(): string {
    return this.getImageOrientation(this.middleImage);
  }

  public getImageOrientation(imageIndex: number): string {
    return this.foviaSeriesDataContext.getDicomTagByIndex(imageIndex)?.imageOrientationPatient ?? '';
  }

  public getImagePositionPatient(imageIndex: number): string {
    return this.foviaSeriesDataContext.getDicomTagByIndex(imageIndex)?.imagePositionPatient ?? '';
  }

  public get modality(): string | null {
    return this.seriesDataContext.modality;
  }

  public get canBeAdjacentlyScrolled(): boolean {
    return this.modality === 'CT' || this.modality === 'MR' || this.modality === 'PT';
  }

  public isModalityXR(): boolean {
    return Exam.isModalityXR(this.modality ?? '');
  }

  public isCrossSectionalModality(): boolean {
    return Exam.isCrossSectionalModality(this.modality ?? '');
  }

  public isModalityCT(): boolean {
    return this.modality === 'CT';
  }

  public isModalityMR(): boolean {
    return this.modality === 'MR';
  }

  public isModalityPT(): boolean {
    return this.modality === 'PT';
  }

  public isModalityNM(): boolean {
    return this.modality === 'NM';
  }

  public isModalityMG(): boolean {
    return this.modality === 'MG';
  }

  public isModalityUS(): boolean {
    return this.modality === 'US';
  }

  public get foviaSeriesDataContext(): SeriesDataContext {
    return this.seriesDataContext;
  }

  public get hasImages(): boolean {
    return !this._foviaSeries.isNonImageSeries;
  }

  public get foviaSeries(): Fovia.ScanDirSeriesResults {
    return this._foviaSeries;
  }

  public get isPrimaryExam(): boolean {
    return this._isPrimary;
  }

  public get is3DableSeries(): boolean {
    return this.foviaSeriesDataContext.is3DableSeries;
  }

  public get seriesId3D(): number {
    return this.foviaSeriesDataContext.subSeriesID;
  }

  public get volumeDataContext(): VolumeDataContext | null {
    return this._volumeDataContext;
  }

  public set volumeDataContext(value: VolumeDataContext | null) {
    this._volumeDataContext = value;
   }
  // Fovia 3D-able series are determined by the following image criteria:
  // 1. Same frame of reference
  // 2. Parallel to within some tolerance
  // 3. Same pixel spacing to within some tolerance
  // 4. Same slice spacing to within some tolerance.
  //
  // We have found that this criteria doesn't always yield a good rendered result.
  // In particular, if the ratio of slice spacing:pixel spacing is > 2 then the
  // volume becomes anisotropic, and less usable.
  // Provide this ratio as a means by which we can sort 3D series from "best to worst"
  // for the user.
  public get volumeQuality(): number {
    return (this.sliceThickness / Math.max(this.pixelSpacing.x, this.pixelSpacing.y));
  }

  public get seriesNameForSubSeries(): string {
    return this.foviaSeries.dicomSeries.seriesDescription ?
      `${this.foviaSeries.dicomSeries.seriesDescription}-(${this.seriesId3D})` :
      `(${this.seriesId3D})`
      ;
  }

  public get seriesUIDForSubSeries(): string {
    return this.foviaSeries.dicomSeries.seriesInstanceUID ?
      `${this.foviaSeries.dicomSeries.seriesInstanceUID}-(${this.seriesId3D})` :
      `(${this.seriesId3D})`
      ;
  }

  public set3DSeriesLayout(panelLayoutType: PANEL_TEMPLATE_TYPE): void {
    // Identify the series/sub-series id associated with this layout so
    // we can tie a display item, which is unique for each 3D/MPR layout to this exam
    // series
    this._3DseriesLayout = getPanelTemplate(panelLayoutType, this.seriesId3D);
  }

  public get3DSeriesLayout(): IPanelTemplate | null {
    return this._3DseriesLayout;
  }

  public get totalCadFindings(): number {
    return this.seriesDataContext.totalClusterFindings + this.seriesDataContext.totalDensityFindings;
  }

  public haveMammoInfo(sopInstanceUID: string): boolean {
    return this.parentExam.mammoInfoMap.get(sopInstanceUID) !== undefined;
  }

  public getMammoInfo(sopInstanceUID: string): MammoInfo {
    const mammoInfo = this.parentExam.mammoInfoMap.get(sopInstanceUID);
    return mammoInfo ? mammoInfo : new MammoInfo(null, sopInstanceUID);
  }

  public getSuvInfo(sopInstanceUID: string): SUVInfo {
    const suvInfo = this.parentExam.suvInfoMap.get(sopInstanceUID);
    return suvInfo ? suvInfo : new SUVInfo(null, sopInstanceUID);
  }

  public getDicomCineFrameRate(): number | null {
    let frameRate: number | null = null;
    if (this.isMultiframe) {
      frameRate = this.getTagValueAsNumber(0, DICOM_TAGS.RECOMMENDED_DISPLAY_FRAME_RATE);
      if (frameRate == null) {
        frameRate = this.getTagValueAsNumber(0, DICOM_TAGS.CINE_RATE);
      }
    }
    return frameRate;
  }

  public getEarliestAcquisitionTime(): string | null {
    let earliestAcquisitionTime = this.getTagValueAsString(0, DICOM_TAGS.ACQUISITION_TIME);
    if (earliestAcquisitionTime !== null) {
      for (let i = 0; i < this.numImages; i++) {
        const time = this.getTagValueAsString(i, DICOM_TAGS.ACQUISITION_TIME);
        if (time) {
          if (compareDicomTime(earliestAcquisitionTime, time) > 0) {
            earliestAcquisitionTime = time;
          }
        }
      }
      return earliestAcquisitionTime;
    }
    return null;
  }

  public getViewPosition(imageNumber: number): string | null {
    return this.getTagValueAsString(imageNumber, DICOM_TAGS.VIEW_POSITION);
  }

  public getSeriesDescription(sopInstanceUID: string): string | null {
    return this.getTagValueAsString(sopInstanceUID, DICOM_TAGS.SERIES_DESCRIPTION);
  }

  public getContrastBolusAgent(sopInstanceUID: string): string | null {
    return this.getTagValueAsString(sopInstanceUID, DICOM_TAGS.CONTRAST_BOLUS_AGENT);
  }
  public getContrastBolusRoute(sopInstanceUID: string): string | null {
    return this.getTagValueAsString(sopInstanceUID, DICOM_TAGS.CONTRAST_BOLUS_ROUTE);
  }

  public haveTagsForImage(id: number | string): boolean {
    const uid = typeof id === 'string' ? id : this.getImageInstanceUID(id);
    return this.parentExam.dicomTagsMap.get(uid) != null;
  }

  public getTagValueAsString(id: number | string, tagID: string): string | null {
    const uid = typeof id === 'string' ? id : this.getImageInstanceUID(id);
    return this.parentExam.getTagValueAsString(uid, tagID);
  }

  private getTagValueAsNumber(imageNumber: number, tagID: string): number | null {
    const valueStr = this.getTagValueAsString(imageNumber, tagID);
    if (valueStr) {
      const value: number | null = Number(valueStr);
      if (isNaN(value)) {
        console.error(`getTagValueAsNumber: invalid value - ${valueStr}`);
        return null;
      }
      return value;
    }
    return null;
  }

}
