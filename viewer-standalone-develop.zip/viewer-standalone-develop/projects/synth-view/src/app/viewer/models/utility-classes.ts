import { Bounds } from '../utils';
import { PANEL_FORMAT } from './panel-support';

export enum PANEL_OPERATION { unknown, eNewPanel, eAddSeries, eRemoveSeries, eSwapSeries, eInsertSeries };

export enum CINE_MODE { loop, bounce, stop };
export enum CINE_DIRECTION { forward, reverse };
export enum HOT_KEY_COMMAND {
  helpAbout,
  newerComparison,
  nextPanelPage,
  olderComparison,
  presetFavorite1,
  presetFavorite2,
  presetFavorite3,
  presetFavorite4,
  presetFavorite5,
  presetFavorite6,
  presetFavorite7,
  presetFavorite8,
  presetFavorite9,
  prevPanelPage,
  reloadExams,
  resetWL,
  reverseSeries,
  showDicomTags,
  showHangingProtocol,
  showToolbox,
  swapAdjacentOn,
  swapAdjacentOff,
  toggleAnnotations,
  toggleCadAI,
  toggleCompareMode,
  toggleCrop,
  toggleFullResolution,
  toggleDICOMOverlay,
  toggleFlicker,
  toggleKeyImage,
  toggleUsePowerWheel,
  toggleTomo,
  eToggleLocalizerLines,
  eToggleThumbnail,
  eNavWorklist,
  eNavMarkReadNext,
  eNavSkipToNextExam,
  eNavMarkReadExit,
  eUserCalibration
}

export enum HOT_KEY_TYPE { down, up, hold, holdUp }

export enum IMAGE_DISPLAY_ALIGNMENT { none, left, right }

export enum IMAGE_RES_RULE { unknown, scaled, fullResolution }
export enum IMAGE_CROP_RULE { unknown, uncropped, autoCropped }

export enum ADJACENT_VIEWPORT_TOOL_MODE {
  topLeft,      topMiddle,     topRight,
  leftMiddle,   off,           rightMiddle,
  bottomLeft,   bottomMiddle,  bottomRight,
  all
}

const ADJACENT_MARGIN_PERCENT = 0.2;

export function getAdjacentViewportToolMode(viewportAdjustedEvent: any, canvasBounds: Bounds): ADJACENT_VIEWPORT_TOOL_MODE {
  if (!viewportAdjustedEvent.viewportAdjusted) {
    console.error('getAdjacentViewportToolMode:  event not viewport adjusted');
    return ADJACENT_VIEWPORT_TOOL_MODE.off;
  }

  const vertMargin = canvasBounds.height * ADJACENT_MARGIN_PERCENT,
      horizMargin = canvasBounds.width * ADJACENT_MARGIN_PERCENT,
      inTopMargin =  viewportAdjustedEvent.viewportAdjusted.y <= vertMargin,
      inBottomMargin = viewportAdjustedEvent.viewportAdjusted.y >= (canvasBounds.height - vertMargin),
      inLeftMargin = viewportAdjustedEvent.viewportAdjusted.x <= horizMargin,
      inRightMargin = viewportAdjustedEvent.viewportAdjusted.x >= (canvasBounds.width - horizMargin);

  let mode = ADJACENT_VIEWPORT_TOOL_MODE.off;
  if (inTopMargin && inLeftMargin)            { mode = ADJACENT_VIEWPORT_TOOL_MODE.topLeft; }
  else if (inTopMargin && inRightMargin)      { mode = ADJACENT_VIEWPORT_TOOL_MODE.topRight; }
  else if (inBottomMargin && inLeftMargin)    { mode = ADJACENT_VIEWPORT_TOOL_MODE.bottomLeft; }
  else if (inBottomMargin && inRightMargin)   { mode = ADJACENT_VIEWPORT_TOOL_MODE.bottomRight; }
  else if (inTopMargin)                       { mode = ADJACENT_VIEWPORT_TOOL_MODE.topMiddle; }
  else if (inBottomMargin)                    { mode = ADJACENT_VIEWPORT_TOOL_MODE.bottomMiddle; }
  else if (inLeftMargin)                      { mode = ADJACENT_VIEWPORT_TOOL_MODE.leftMiddle; }
  else if (inRightMargin)                     { mode = ADJACENT_VIEWPORT_TOOL_MODE.rightMiddle; }

  // console.log(`getAdjacentViewportToolMode returns`, mode);
  return mode;
}


export class PanelLayout {
  public cells: number;
  public constructor(public rows: number = 1, public cols: number = 1) {
    this.cells = rows * cols;
  }
  public swap(): void {
    const temp = this.rows;
    this.rows = this.cols;
    this.cols = temp;
  }
}

export class PanelCell {
  constructor(public rowIndex: number = 0, public colIndex: number = 0) {
  }
  public adjacent(rowOffset: number, colOffset: number): PanelCell {
    return new PanelCell(this.rowIndex + rowOffset, this.colIndex + colOffset);
  }
}

export class SynthSize {
  constructor(public width: number = 1, public height: number = 1) {
  }
}

export class SynthPoint {
  constructor(public x: number = 1, public y: number = 1) {
  }
}

export class AdjacentViewportIds {
  public topLeft?: string;
  public top?: string;
  public topRight?: string;
  public left?: string;
  public right?: string;
  public bottomLeft?: string;
  public bottom?: string;
  public bottomRight?: string;

  public applyAdjacentToolMode(mode: ADJACENT_VIEWPORT_TOOL_MODE): AdjacentViewportIds {
    const newItem = new AdjacentViewportIds();
    const all = mode === ADJACENT_VIEWPORT_TOOL_MODE.all;

    newItem.topLeft =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.topLeft) ? this.topLeft : undefined;

    newItem.top =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.topLeft  ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.topMiddle ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.topRight) ? this.top : undefined;

    newItem.topRight =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.topRight) ? this.topRight : undefined;

    newItem.left =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.topLeft  ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.leftMiddle ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomLeft) ? this.left : undefined;


    newItem.right =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.topRight  ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.rightMiddle ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomRight) ? this.right : undefined;

    newItem.bottomLeft =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomLeft) ? this.bottomLeft : undefined;

    newItem.bottom =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomLeft  ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomMiddle ||
         mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomRight) ? this.bottom : undefined;

    newItem.bottomRight =
        (all || mode === ADJACENT_VIEWPORT_TOOL_MODE.bottomRight) ? this.bottomRight : undefined;

    return newItem;
  }

  public keepLeftAndRightViewportsOnly(): AdjacentViewportIds {
    const newItem = new AdjacentViewportIds();
    newItem.right = this.right;
    newItem.left = this.left;
    return newItem;
  }

  public ignoreCornerViewports(): AdjacentViewportIds {
    const newItem = new AdjacentViewportIds();
    newItem.right = this.right;
    newItem.left = this.left;
    newItem.top = this.top;
    newItem.bottom = this.bottom;
    return newItem;
  }

  public toList(): string[] {
    const list: string[] = [];
    if (this.topLeft != null)     { list.push(this.topLeft); }
    if (this.top != null)         { list.push(this.top); }
    if (this.topRight != null)    { list.push(this.topRight); }
    if (this.left != null)        { list.push(this.left); }
    if (this.right != null)       { list.push(this.right); }
    if (this.bottomLeft != null)  { list.push(this.bottomLeft); }
    if (this.bottom != null)      { list.push(this.bottom); }
    if (this.bottomRight != null) { list.push(this.bottomRight); }

    return list;
  }
}

export class PreFlickerState {
  constructor(
    public format: PANEL_FORMAT = PANEL_FORMAT.customFixed,
    public layout: PanelLayout = new PanelLayout(1, 1),
    public firstViewportIdIndex: number = 0) {
  }
}

export enum ViewerSplitModeStatus { active, inactive };
