import { ButtonInfo } from './button-info';

describe('ButtonInfo', () => {
  it('should create an instance', () => {
    expect(new ButtonInfo()).toBeTruthy();
  });
});
