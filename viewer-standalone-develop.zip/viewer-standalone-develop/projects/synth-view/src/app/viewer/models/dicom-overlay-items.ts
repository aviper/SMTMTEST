
import { DICOM_OVERLAY_STYLE } from './viewer-settings-info';
import { ExamSeries } from './exam-series';
import { VirtualSeries } from './virtual-series';
import { IMAGE_LATERALITY, MammoInfo } from './mammo-info';
import Fovia from 'foviaapi';

export enum DICOM_OVERLAY_ITEM {
  PATIENT_NAME = 0,
  PATIENT_BIRTHDAY,
  PATIENT_MRN,
  PATIENT_SEX,
  SERIES_NUMBER,
  SERIES_NAME,
  SERIES_NAME_SUBSERIES, // Thumbnails for 3D/MPR
  VIEWPORT_TITLE,        // 3D specific
  IMAGE_COUNT,           // Thumbnails
  IMAGE_NUMBER,
  INSTITUTION_NAME,
  INSTITUTION_ADDRESS,
  OPERATORS_NAME,
  CASSETTE_ID,
  STATION_NAME,
  UNITID,
  STUDY_DESCRIPTION,
  STUDY_DATE_TIME,
  ACQUISITION_DATE_TIME,
  STUDY_AGE,
  ACCESSION_NUMBER,
  WINDOW_LEVEL,
  SCALE_COMPRESSION,
  RENDER_TYPE,    // Debugging 3D specific
  SLICE_THICKNESS,
  SLICE_THICKNESS_LOCATION,
  SLICE_LOCATION, // 3D specific
  VIEW_POSITION,  // 3D Specific
  SLAB_THICKNESS, // 3D specific
  CONTRAST,
  FIELD_OF_VIEW,
  CROP,
  TE_TR,
  PULSE_SEQUENCE,
  CAD,
  DUPLICATE,
  STACK_LOCATION,
  IMAGE_LATERALITY,
  FUSION,
  TR_TE_FOV,      // For MR -- Repetition Time, Echo Time, Field of View
  WL_FIELD_ECHO, // For MR -- Window/Level, Field Strength, Echo Train Length
}

export interface IDicomOverlayItems {

  topLeftItems: Array<DICOM_OVERLAY_ITEM>;
  topCenterItems: Array<DICOM_OVERLAY_ITEM>;     // Thumbnails
  topRightItems: Array<DICOM_OVERLAY_ITEM>;
  middleLeftItems: Array<DICOM_OVERLAY_ITEM>;
  middleRightItems: Array<DICOM_OVERLAY_ITEM>;
  bottomLeftItems: Array<DICOM_OVERLAY_ITEM>;
  bottomCenterItems: Array<DICOM_OVERLAY_ITEM>;  // Thumbnails
  bottomRightItems: Array<DICOM_OVERLAY_ITEM>;
}

// This will be subclassed for various modalities or groups of modalities
// This builds an array of item types to be included in each corner, based primarily
// on the viewer setting for "Full Overlay" vs "Partial Overlay". Derived classes

class EmptyDicomOverlayItems implements IDicomOverlayItems {
  protected constructor() {}
  public get topLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get topCenterItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get topRightItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get middleLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get middleRightItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get bottomRightItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  public get bottomCenterItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
  protected get emptyItems(): Array<DICOM_OVERLAY_ITEM> {
    return new Array<DICOM_OVERLAY_ITEM>;
  }
}

class BaseDicomOverlayItems extends EmptyDicomOverlayItems {

  protected constructor(protected examSeries: ExamSeries, protected overlayStyle: DICOM_OVERLAY_STYLE) {
    super();
  }

  public override get topLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_FULL && this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      items.push(DICOM_OVERLAY_ITEM.PATIENT_NAME);
      items.push(DICOM_OVERLAY_ITEM.PATIENT_MRN);
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.PATIENT_BIRTHDAY);
        items.push(DICOM_OVERLAY_ITEM.PATIENT_SEX);
      }
    }
    items.push(DICOM_OVERLAY_ITEM.DUPLICATE);
    return items;
  }

  public override get topRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_FULL || this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      items.push(DICOM_OVERLAY_ITEM.STUDY_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.ACQUISITION_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.STUDY_AGE);
    } else {
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.INSTITUTION_NAME);
        items.push(DICOM_OVERLAY_ITEM.STUDY_DESCRIPTION);
      }
      items.push(DICOM_OVERLAY_ITEM.STUDY_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.ACQUISITION_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.STUDY_AGE);

      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.ACCESSION_NUMBER);
      }
    }
    return items;
  }

  public override get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_FULL && this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      items.push(DICOM_OVERLAY_ITEM.CONTRAST);
      items.push(DICOM_OVERLAY_ITEM.SLICE_THICKNESS_LOCATION);
      items.push(DICOM_OVERLAY_ITEM.WINDOW_LEVEL);
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.FIELD_OF_VIEW);
        items.push(DICOM_OVERLAY_ITEM.SERIES_NAME);
      }
    }
    return items;
  }

  public override get bottomRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.SERIES_NUMBER);
    items.push(DICOM_OVERLAY_ITEM.IMAGE_NUMBER);

    if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
      items.push(DICOM_OVERLAY_ITEM.SCALE_COMPRESSION);
      items.push(DICOM_OVERLAY_ITEM.CROP);
    }
    return items;
  }
}

export class BaseDicomOverlayItems2D extends BaseDicomOverlayItems {
  public constructor(examSeries: ExamSeries, protected imageNum: number | null, overlayStyle: DICOM_OVERLAY_STYLE) {
    super(examSeries, overlayStyle);
  }
}

export class BaseDicomOverlayItems3D extends BaseDicomOverlayItems {
  public constructor(examSeries: ExamSeries, overlayStyle: DICOM_OVERLAY_STYLE) {
    super(examSeries, overlayStyle);
  }
  public override get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.CAD);
    items.push(DICOM_OVERLAY_ITEM.CONTRAST);
    items.push(DICOM_OVERLAY_ITEM.WINDOW_LEVEL);
    if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
      items.push(DICOM_OVERLAY_ITEM.SLICE_THICKNESS);
      items.push(DICOM_OVERLAY_ITEM.FIELD_OF_VIEW);
      items.push(DICOM_OVERLAY_ITEM.VIEWPORT_TITLE);
    }
    return items;
  }
  public override get bottomRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.SERIES_NUMBER);
    items.push(DICOM_OVERLAY_ITEM.VIEW_POSITION);
    items.push(DICOM_OVERLAY_ITEM.SLICE_LOCATION);
    if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
      items.push(DICOM_OVERLAY_ITEM.RENDER_TYPE);
      items.push(DICOM_OVERLAY_ITEM.SLAB_THICKNESS);
      items.push(DICOM_OVERLAY_ITEM.SCALE_COMPRESSION);
      items.push(DICOM_OVERLAY_ITEM.CROP);
    }
    return items;
  }
}

export class CtPtDicomOverlayItems2D extends BaseDicomOverlayItems2D {
}

export class CtPtDicomOverlayItems3D extends BaseDicomOverlayItems3D {
}

export class CrDxDicomOverlayItems2D extends BaseDicomOverlayItems2D {
}

export class FusedDicomOverlayItems3D extends BaseDicomOverlayItems3D {
  public override get topRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.FUSION);
    return items;
  }
  public override get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }

  public override get bottomRightItems(): Array<DICOM_OVERLAY_ITEM> {
    return this.emptyItems;
  }
}

export class MgDicomOverlayItems2D extends BaseDicomOverlayItems2D {
  private readonly mammoInfo: MammoInfo | null = null;
  constructor(examSeries: ExamSeries, imageNumber: number | null, overlayStyle: DICOM_OVERLAY_STYLE, private virtualSeries: VirtualSeries | null) {
    super(examSeries, imageNumber, overlayStyle);
    if (imageNumber != null) {
      if (this.virtualSeries && this.virtualSeries.currentExamSeries != null) {
        this.mammoInfo = this.virtualSeries.currentExamSeries.getMammoInfo(this.virtualSeries.currentSopInstanceUID);
      }
    }
  }

  public override get topLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && !this.reverseOverlay) ||
        (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && this.reverseOverlay) ||
        (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.UNKNOWN)) {
      return this.topItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  public override get topRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && !this.reverseOverlay) ||
        (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && this.reverseOverlay)) {
      return this.topItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  public override get middleLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && !this.reverseOverlay) ||
      (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && this.reverseOverlay) ||
      (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.UNKNOWN)) {
      return this.middleItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  public override get middleRightItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && !this.reverseOverlay) ||
      (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && this.reverseOverlay)) {
      return this.middleItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  public override get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && !this.reverseOverlay) ||
        (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && this.reverseOverlay) ||
        (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.UNKNOWN)) {
      return this.bottomItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  public override get bottomRightItems(): Array<DICOM_OVERLAY_ITEM> {
    if ((this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.LEFT && !this.reverseOverlay) ||
      (this.mammoInfo && this.mammoInfo.laterality === IMAGE_LATERALITY.RIGHT && this.reverseOverlay)) {
      return this.bottomItems;
    }
    return new Array<DICOM_OVERLAY_ITEM>;
  }
  private get topItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_FULL || this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      items.push(DICOM_OVERLAY_ITEM.STUDY_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.ACQUISITION_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.STUDY_AGE);
      items.push(DICOM_OVERLAY_ITEM.INSTITUTION_NAME);
      items.push(DICOM_OVERLAY_ITEM.INSTITUTION_ADDRESS);
      items.push(DICOM_OVERLAY_ITEM.STATION_NAME);
      items.push(DICOM_OVERLAY_ITEM.CASSETTE_ID);
      items.push(DICOM_OVERLAY_ITEM.OPERATORS_NAME);
      items.push(DICOM_OVERLAY_ITEM.DUPLICATE);
    } else {
      items.push(DICOM_OVERLAY_ITEM.PATIENT_NAME);
      items.push(DICOM_OVERLAY_ITEM.PATIENT_MRN);
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.PATIENT_BIRTHDAY);
        items.push(DICOM_OVERLAY_ITEM.PATIENT_SEX);
      }
      items.push(DICOM_OVERLAY_ITEM.INSTITUTION_NAME);
      items.push(DICOM_OVERLAY_ITEM.INSTITUTION_ADDRESS);
      items.push(DICOM_OVERLAY_ITEM.STATION_NAME);
      items.push(DICOM_OVERLAY_ITEM.CASSETTE_ID);
      items.push(DICOM_OVERLAY_ITEM.OPERATORS_NAME);
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.STUDY_DESCRIPTION);
        items.push(DICOM_OVERLAY_ITEM.ACCESSION_NUMBER);
      }
      items.push(DICOM_OVERLAY_ITEM.STUDY_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.ACQUISITION_DATE_TIME);
      items.push(DICOM_OVERLAY_ITEM.STUDY_AGE);
      items.push(DICOM_OVERLAY_ITEM.DUPLICATE);
    }
    return items;
  }
  private get middleItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.IMAGE_LATERALITY);
    return items;
  }
  private get bottomItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_FULL || this.overlayStyle === DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      if (this.imageNum != null && this.examSeries.isMultiframeImage(this.imageNum)) {
        items.push(DICOM_OVERLAY_ITEM.SERIES_NUMBER);
        items.push(DICOM_OVERLAY_ITEM.IMAGE_NUMBER);
      } else {
        items.push(DICOM_OVERLAY_ITEM.STACK_LOCATION);
      }
    } else {
      items.push(DICOM_OVERLAY_ITEM.CAD);
      items.push(DICOM_OVERLAY_ITEM.CONTRAST);
      items.push(DICOM_OVERLAY_ITEM.WINDOW_LEVEL);
      if (this.imageNum != null && this.examSeries.isMultiframeImage(this.imageNum)) {
        items.push(DICOM_OVERLAY_ITEM.SERIES_NUMBER);
        items.push(DICOM_OVERLAY_ITEM.IMAGE_NUMBER);
      } else {
        items.push(DICOM_OVERLAY_ITEM.STACK_LOCATION);
      }
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.SCALE_COMPRESSION);
        items.push(DICOM_OVERLAY_ITEM.CROP);
        items.push(DICOM_OVERLAY_ITEM.FIELD_OF_VIEW);
        items.push(DICOM_OVERLAY_ITEM.SERIES_NAME);
      }
    }
    return items;
  }
  private get reverseOverlay(): boolean {
    if (this.virtualSeries && this.virtualSeries.imageSets) {
      return this.virtualSeries.imageSets[0].flipStepOnly;
    }
    return false;
  }
}

export class MrDicomOverlayItems2D extends BaseDicomOverlayItems2D {
  public override get bottomLeftItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    if (this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_FULL && this.overlayStyle !== DICOM_OVERLAY_STYLE.HIDE_PARTIAL) {
      items.push(DICOM_OVERLAY_ITEM.CONTRAST);
      items.push(DICOM_OVERLAY_ITEM.SLICE_THICKNESS_LOCATION);
      items.push(DICOM_OVERLAY_ITEM.WL_FIELD_ECHO);
      items.push(DICOM_OVERLAY_ITEM.TR_TE_FOV);
      if (this.overlayStyle === DICOM_OVERLAY_STYLE.SHOW_FULL) {
        items.push(DICOM_OVERLAY_ITEM.SERIES_NAME);
      }
    }
    return items;
  }
}

export class MrDicomOverlayItems3D extends BaseDicomOverlayItems3D {
}

export class NmDicomOverlayItems2D extends BaseDicomOverlayItems2D {
}

export class NmDicomOverlayItems3D extends BaseDicomOverlayItems3D {
}

export class UsDicomOverlayItems2D extends BaseDicomOverlayItems2D {
}

export class XaDicomOverlayItems2D extends BaseDicomOverlayItems2D {
}

export class ThumbnailOverlaylItems extends EmptyDicomOverlayItems {
  constructor(protected examSeries: ExamSeries, protected overlayStyle: DICOM_OVERLAY_STYLE) {
    super();
  }
  public override get topCenterItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.SERIES_NAME_SUBSERIES);
    return items;
  }
  public override get bottomCenterItems(): Array<DICOM_OVERLAY_ITEM> {
    const items: Array<DICOM_OVERLAY_ITEM> = new Array<DICOM_OVERLAY_ITEM>;
    items.push(DICOM_OVERLAY_ITEM.IMAGE_COUNT);
    return items;
  }
}
