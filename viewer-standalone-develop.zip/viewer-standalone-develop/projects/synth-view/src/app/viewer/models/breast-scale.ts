import Fovia from 'foviaapi';
import { SynthContextSettings } from '../adaptors';
import { SynthStyles } from '../adaptors';
import { IMAGE_LATERALITY, MammoInfo } from './mammo-info';

export function drawBreastScale(canvas: HTMLCanvasElement, frame: number, mammoInfo: MammoInfo): void {
  const synthStyles = new SynthStyles();
  const synthContextSettings = new SynthContextSettings(synthStyles.visualAttribute, synthStyles.colorNormal, synthStyles.colorHighlight);
  const context = synthContextSettings.getSynthContextSettings(canvas.getContext('2d'));

  if (context != null) {
    // Draw the scale horizontally,
    // Until 12/18/25 we used to draw it vertically on the left or right side, except for smaller viewports.
    const length = Math.floor(canvas.width * 0.4);
    const rulerY: number = canvas.height - (canvas.height > 200 ? canvas.height / 100 : 4);
    const y: number = rulerY - 24;
    const startPoint: Fovia.Util.Point = new Fovia.Util.Point(Math.floor((canvas.width / 2) - (length / 2)), y);
    const endPoint: Fovia.Util.Point = new Fovia.Util.Point(startPoint.x + length, y);
    const textWidth = context.measureText(mammoInfo.breastScaleText[1]).width;

    context.beginPath();
    context.moveTo(startPoint.x, startPoint.y);
    context.lineTo(endPoint.x, endPoint.y);
    context.stroke();

    context.textAlign = 'center';

    context.fillText(mammoInfo.breastScaleText[0], startPoint.x - textWidth, startPoint.y);
    context.fillText(mammoInfo.breastScaleText[1], endPoint.x + textWidth, endPoint.y);

    const xCenter = Math.floor(length * ((frame - 1) / (mammoInfo.frameCount - 1)));
    context.fillRect(startPoint.x + xCenter - synthStyles.grabberSize / 2, startPoint.y - synthStyles.grabberSize / 2, synthStyles.grabberSize, synthStyles.grabberSize);
  }
}
