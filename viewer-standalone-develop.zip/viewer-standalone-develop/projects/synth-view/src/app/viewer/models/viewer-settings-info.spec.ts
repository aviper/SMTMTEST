import { ViewerSettingsInfo } from './viewer-settings-info';

describe('ViewerSessionInfo', () => {
  it('should create an instance', () => {
    expect(new ViewerSettingsInfo()).toBeTruthy();
  });
});
