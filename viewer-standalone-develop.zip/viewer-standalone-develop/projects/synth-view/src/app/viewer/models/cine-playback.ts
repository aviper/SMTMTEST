
import { ICineSpeedOptions } from '@idgital/vision-auth-interface';

import { DEFAULT_CINE_SPEED, DicomTags, DICOM_TAGS, getTagValueAsNumber, getTagValueAsString } from "@server-api";
import { CINE_MODE } from "./utility-classes";

export const DEFAULT_RENDER_DELAY = 50;
// Establish the cine playback characteristics for a series
// Simply establish the playback rate specified by the user OR
// specified by the DICOM header for the series.
export class CinePlayback {
  public cineMode: CINE_MODE = CINE_MODE.loop;
  public cineFrameRate: number = DEFAULT_CINE_SPEED;

  public beginFrame: number = 0;
  public endFrame: number;
  public renderDelayMsecs: number = DEFAULT_RENDER_DELAY; // default frame time

  private useDicomMetaFile = false;
  constructor(frameCount: number) {
    this.endFrame = frameCount - 1;
  }

  public init(hpCineSpeedOptions: ICineSpeedOptions, tags: DicomTags | undefined): void {
    if (hpCineSpeedOptions.useDicomMetafile && tags != null) {
      this.setTrim(tags);
      this.setFPS(tags);
      this.setCineLoop(tags);
      this.setFrameTime(tags);
      this.useDicomMetaFile = true;
    } else {
      // Requirements say to ensure user's frame rate is 1..30 fps
      this.cineFrameRate = Math.min(30, Math.max(1, hpCineSpeedOptions.cineSpeed));
      this.computeRenderDelay();
    }
    //console.log(`${this.constructor.name} FPS: ${this.cineFrameRate} Metadata: ${this.useDicomMetaFile}`, this);
  }

  public useDicomCineModule(): boolean {
    return this.useDicomMetaFile;
  }

  private setFPS(tags: DicomTags): void {
    // Tested with US DICOM data
    const cineRate = getTagValueAsNumber(tags, DICOM_TAGS.CINE_RATE);
    const prefCineRate = getTagValueAsNumber(tags, DICOM_TAGS.RECOMMENDED_DISPLAY_FRAME_RATE);
    if (cineRate) {
      this.cineFrameRate = cineRate;
    }
    if (prefCineRate) {
      this.cineFrameRate = prefCineRate;
    }
    this.computeRenderDelay();
  }

  private setTrim(tags: DicomTags): void {
    // Tested with XA DICOM data
    let beginFrame = getTagValueAsNumber(tags, DICOM_TAGS.START_TRIM);
    let endFrame = getTagValueAsNumber(tags, DICOM_TAGS.STOP_TRIM);
    if (beginFrame != null && endFrame != null) {
      // Image Frames 1...n are returned. Convert to zero origin, guard
      // against potential zero origin data.
      // TO DO: Put these values to work during playback
      beginFrame = Math.max(0, beginFrame - 1);
      endFrame = Math.min(this.endFrame, endFrame - 1);
      if (beginFrame < endFrame && endFrame <= this.endFrame) {
        this.beginFrame = beginFrame;
        this.endFrame = endFrame;
      }
    }
  }

  private setCineLoop(tags: DicomTags): void {
    // Tested with US DICOM data
    const preferredPlaybackSeq = getTagValueAsNumber(tags, DICOM_TAGS.PREFERRED_PLAYBACK_SEQUENCING);
    if (preferredPlaybackSeq != null) {
      this.cineMode = preferredPlaybackSeq == 0 ? CINE_MODE.loop : CINE_MODE.bounce;
    }
  }

  private setFrameTime(tags: DicomTags): void {
    // Tested with US DICOM data
    const frameIncrementPtr = getTagValueAsString(tags, DICOM_TAGS.FRAME_INCREMENT_POINTER);
    if (!frameIncrementPtr) {
      return;
    }
    if (frameIncrementPtr === DICOM_TAGS.FRAME_TIME) {
      const frameTime = getTagValueAsNumber(tags, DICOM_TAGS.FRAME_TIME);
      if (frameTime != null) {
        this.renderDelayMsecs = frameTime;
        this.computeFrameRate();
      }
    } else if (frameIncrementPtr === DICOM_TAGS.FRAME_TIME_VECTOR) {
      // TO DO: Cine Module is incompletely implemented
      // * Add parsing check for
      //   - Frame Time Vector
      //   Integrate Frame Time Vector with playback
    }
  }
  // TO DO: Support for XA Mask 00286100	MaskSubtractionSequence needs to be done to support
  // XA playback correctly.
  
  private computeRenderDelay(): void {
    // Compute a sensible frame time/delay in case it is not provided by the DICOM header FrameTime
    const renderDelay = 1000 / this.cineFrameRate;
    if (this.renderDelayMsecs != renderDelay) {
      this.renderDelayMsecs = renderDelay;
    }
  }
  private computeFrameRate(): void {
    // Compute a frame rate in case it is not provided by the DICOM header FPS settings
    const frameRate = 1000 / this.renderDelayMsecs;
    if (this.cineFrameRate != frameRate) {
      this.cineFrameRate = frameRate;
    }
  }
}
