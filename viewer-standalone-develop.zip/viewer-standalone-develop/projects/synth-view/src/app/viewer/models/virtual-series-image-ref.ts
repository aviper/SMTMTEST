import Fovia from 'foviaapi';
import { makeImageKey } from '@server-api';
import { VirtualSeriesImageSet } from './virtual-series-image-set';
import { WLInfo } from './window-level';

export class VirtualSeriesImageRef {

  private wlInfo?: WLInfo; // w/l information can be relocated to exam
  constructor(public imageSet: VirtualSeriesImageSet, public imageIndex: number) {}

  public toString(): string {
    return `imageIndex ${this.imageIndex}`;
  }

  public get imageKey(): string {
    if (this.imageSet && this.imageSet.seriesDataContext) {
      const tags = this.imageSet.seriesDataContext.imageTags[this.imageIndex];
      return makeImageKey(tags.sopInstanceUID, tags.frameNumber);
    } else {
      return `blank_${this.imageIndex}`;
    }
  }

  public get sdcTags(): Fovia.DICOMImageTags | null {
    return (this.imageSet && this.imageSet.seriesDataContext)
      ? this.imageSet.seriesDataContext.imageTags[this.imageIndex]
      : null;
  }
  public setWindowLevel(wl: WLInfo): void {
    this.wlInfo = wl; // store a copy
  }

  public getWindowLevel(): WLInfo | null {
    return this.wlInfo ?? null;
  }
}
