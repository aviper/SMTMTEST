import { OpencvMatInfo } from '../image-process/models/opencv-mat-info';
import { ImageAttributes } from '../utils';
import DICOMImageTags = Fovia.DICOMImageTags;

export enum EDGE_ENHANCEMENT_LEVEL_TYPE  {
   low = 'Low' , medium = 'Medium', high =  'High', none = 'Off'
  }
export interface IEdgeEnhancementLevelEntry {
  type: EDGE_ENHANCEMENT_LEVEL_TYPE;
  selected?: boolean;
}

export interface IImageEnhancementRequest {
  sopInstanceUID: string;
  frameNo: number;
  level: EDGE_ENHANCEMENT_LEVEL_TYPE;
  imageAttributes: ImageAttributes;
  imageTags: DICOMImageTags;
}


export class EdgeEnhancementLevel implements IEdgeEnhancementLevelEntry {
  public type: EDGE_ENHANCEMENT_LEVEL_TYPE;
  public store;
  constructor(entry: EDGE_ENHANCEMENT_LEVEL_TYPE) {
    this.type = entry;
    this.store = entry !== EDGE_ENHANCEMENT_LEVEL_TYPE.none;
  }
  public toString(): string {
    return this.type;
  }
  static fromString(level: string | null): EdgeEnhancementLevel | null {
    if (!level) { return null; }
    const valid = Object.values(EDGE_ENHANCEMENT_LEVEL_TYPE).includes(level as EDGE_ENHANCEMENT_LEVEL_TYPE);
    return valid ? new EdgeEnhancementLevel(level as EDGE_ENHANCEMENT_LEVEL_TYPE) : null;
  }
}


