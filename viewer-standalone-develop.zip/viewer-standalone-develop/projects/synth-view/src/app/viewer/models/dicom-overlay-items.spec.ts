import { AdditionalOverlayInfo, DicomOverlayContents } from './dicom-overlay-contents';
import { ExamSeries } from '../services';
import { DICOM_OVERLAY_STYLE } from './viewer-settings-info';

describe('DicomOverlayContents', () => {
  it('should create an instance', () => {
    expect(new DicomOverlayContents(new AdditionalOverlayInfo(null, null, false, null), DICOM_OVERLAY_STYLE.SHOW_FULL)).toBeTruthy();
  });
});
