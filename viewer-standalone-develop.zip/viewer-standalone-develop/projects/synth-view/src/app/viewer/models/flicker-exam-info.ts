import { DICOM_TAGS, getTagValueAsString } from '@server-api';
import dayjs from 'dayjs';
import { ExamSeries } from './exam-series';
import { VirtualSeriesImageSet } from './virtual-series-image-set';

export enum FLICKER_STACK {
  PA,
  LAT,
  LCC,
  RCC,
  LMLO,
  RMlO,
  LEFT,
  RIGHT,
  OTHER
}
export class FlickerExamInfo {
  public studyInstanceUID: string | null = null;

  private date: string | null = null;
  private time: string | null = null;
  private imageSetsMap: Map<FLICKER_STACK, VirtualSeriesImageSet[]> = new Map<FLICKER_STACK, VirtualSeriesImageSet[]>;

  constructor(dicomTagsMap: Map<string, any>, origSeries: ExamSeries[]) {
    for (const tags of dicomTagsMap.values()) {
      if (tags != null) {
        if (this.date === null) {
          this.date = getTagValueAsString(tags, DICOM_TAGS.STUDY_DATE);
        }
        if (this.time === null) {
          this.time = getTagValueAsString(tags, DICOM_TAGS.STUDY_TIME);
        }
        if (this.studyInstanceUID === null) {
          this.studyInstanceUID = getTagValueAsString(tags, DICOM_TAGS.STUDY_INSTANCE_UID);
        }
      }
    }
  }

  public get isValid(): boolean {
    for (const imageSets of this.imageSetsMap.entries()) {
      if (imageSets.length > 0) {
        return true;
      }
    }
    return false;
  }

  public addImageSet(setType: FLICKER_STACK, imageSet: VirtualSeriesImageSet[]): void {
    this.imageSetsMap.set(setType, imageSet);
  }

  public getImageSet(setType: FLICKER_STACK): VirtualSeriesImageSet[] {
    return this.imageSetsMap.get(setType) ?? [];
  }

  public getImageSetByTypes(setTypes: FLICKER_STACK[]): VirtualSeriesImageSet[] {
    const imageSets: VirtualSeriesImageSet[] = [];
    for (const setType of setTypes) {
      imageSets.push(...this.imageSetsMap.get(setType) ?? []);
    }
    return imageSets;
  }

  public compareDateTime(info: FlickerExamInfo): number {
    if (info.date === this.date && info.time === this.time) {
      return 0;
    }
    else if (info.date !== this.date) {
      if (dayjs(info.date).isBefore(this.date)) {
        return -1;
      }
      else {
        return 1;
      }
    } else {
      if (dayjs(info.time).isBefore(this.time)) {
        return -1;
      }
      else {
        return 1;
      }
    }
  }
}
export class FlickerItem {
  constructor(public flickerExamInfoIndex: number, public virtualExamSeriesIndex: number, public virtualImageSet: VirtualSeriesImageSet) { }
}
