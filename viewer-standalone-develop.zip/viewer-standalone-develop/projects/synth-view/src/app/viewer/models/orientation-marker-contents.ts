import Fovia from 'foviaapi';
import RenderParams = Fovia.RenderParams;
import RenderParams2D = Fovia.RenderParams2D;
import RenderParams3D = Fovia.RenderParams3D;
import Vector = Fovia.Util.Vector;

import { ExamSeries } from '../models';
import { is2DRenderParams, is3DRenderParams, isBlendedRenderParams } from '../utils';

class Markers {
  public top = '';
  public left = '';
  public right = '';
  public bottom = '';
}

export class OrientationMarkerContents {
  private readonly _top: string = '';
  private readonly _left: string = '';
  private readonly _right: string = '';
  private readonly _bottom: string = '';

  constructor(private examSeries: ExamSeries | null, private renderParams: RenderParams | null) {
    if (examSeries == null || renderParams == null) {
      return;
    }

    let markers: Markers = new Markers;

    if (is2DRenderParams(renderParams)) {
      const renderParams2D = renderParams as RenderParams2D;
      const orientationPatient: string = examSeries.foviaSeriesDataContext.getDicomTagByIndex(renderParams2D.imageNumber).imageOrientationPatient;
      markers = this.set2DOrientationMarkers(renderParams2D, orientationPatient);
    } else if (is3DRenderParams(renderParams)) {
      const renderParams3D = renderParams as RenderParams3D;
      markers = this.set3DOrientationMarkers(renderParams3D!);
    } else if (isBlendedRenderParams(renderParams)) {
      // DO WHAT
    }


    this._left = markers.left;
    this._right = markers.right;
    this._top = markers.top;
    this._bottom = markers.bottom;
  }

  public get top(): string {
    return this._top;
  }
  public get right(): string {
    return this._right;
  }
  public get left(): string {
    return this._left;
  }
  public get bottom(): string {
    return this._bottom;
  }

  private set2DOrientationMarkers(renderParams2D: RenderParams2D, orientationPatient: string): Markers {
    const markers = new Markers();

    let imgOrientationXVector = new Vector(-1, -1, -1);
    let imgOrientationYVector = new Vector(-1, -1, -1);

    if (orientationPatient != null && orientationPatient !== '') {
      let tmp: string[] = orientationPatient.split('\\');
      let modifiedOrientation: string;

      imgOrientationXVector = new Vector(parseFloat(tmp[0]), parseFloat(tmp[1]), parseFloat(tmp[2]));
      imgOrientationYVector = new Vector(parseFloat(tmp[3]), parseFloat(tmp[4]), parseFloat(tmp[5]));
      let imgOrientationZVector: Vector = imgOrientationXVector.cross(imgOrientationYVector);
      // rotate90
      if (renderParams2D.rotate === Fovia.ImageRotation.rotate90) {
        imgOrientationXVector = new Vector(-(parseFloat(tmp[3])), -(parseFloat(tmp[4])), -(parseFloat(tmp[5])));
        imgOrientationYVector = new Vector(parseFloat(tmp[0]), parseFloat(tmp[1]), parseFloat(tmp[2]));
        modifiedOrientation = imgOrientationXVector.x + '\\' + imgOrientationXVector.y + '\\' + imgOrientationXVector.z + '\\' +
          imgOrientationYVector.x + '\\' + imgOrientationYVector.y + '\\' + imgOrientationYVector.z;
        imgOrientationZVector = imgOrientationXVector.cross(imgOrientationYVector);
        tmp = modifiedOrientation.split('\\');
      }
      // rotate180
      else if (renderParams2D.rotate === Fovia.ImageRotation.rotate180) {
        imgOrientationXVector = new Vector(-(parseFloat(tmp[0])), -(parseFloat(tmp[1])), -(parseFloat(tmp[2])));
        imgOrientationYVector = new Vector(-(parseFloat(tmp[3])), -(parseFloat(tmp[4])), -(parseFloat(tmp[5])));
        modifiedOrientation = imgOrientationXVector.x + '\\' + imgOrientationXVector.y + '\\' + imgOrientationXVector.z + '\\' +
          imgOrientationYVector.x + '\\' + imgOrientationYVector.y + '\\' + imgOrientationYVector.z;
        tmp = modifiedOrientation.split('\\');
      }
      // rotate270
      else if (renderParams2D.rotate === Fovia.ImageRotation.rotate270) {
        imgOrientationXVector = new Vector(parseFloat(tmp[3]), parseFloat(tmp[4]), parseFloat(tmp[5]));
        imgOrientationYVector = new Vector(-(parseFloat(tmp[0])), -(parseFloat(tmp[1])), -(parseFloat(tmp[2])));
        modifiedOrientation = imgOrientationXVector.x + '\\' + imgOrientationXVector.y + '\\' + imgOrientationXVector.z + '\\' +
          imgOrientationYVector.x + '\\' + imgOrientationYVector.y + '\\' + imgOrientationYVector.z;
        tmp = modifiedOrientation.split('\\');
      }
      // flipHorizontal
      if (renderParams2D.flip === Fovia.ImageFlip.flipHorizontal) {
        imgOrientationXVector = new Vector(-(parseFloat(tmp[0])), -(parseFloat(tmp[1])), -(parseFloat(tmp[2])));
        imgOrientationYVector = new Vector(parseFloat(tmp[3]), parseFloat(tmp[4]), parseFloat(tmp[5]));
        modifiedOrientation = imgOrientationXVector.x + '\\' + imgOrientationXVector.y + '\\' + imgOrientationXVector.z + '\\' +
          imgOrientationYVector.x + '\\' + imgOrientationYVector.y + '\\' + imgOrientationYVector.z;
      }
      const negX: Vector = this.reverseVector(new Vector(imgOrientationXVector));
      const negY: Vector = this.reverseVector(new Vector(imgOrientationYVector));

      const isMG = this.examSeries?.isModalityMG() ?? false;
      markers.left = this.getOrientationLabel(imgOrientationXVector, isMG);
      markers.right = this.getOrientationLabel(negX, isMG);
      markers.top = this.getOrientationLabel(imgOrientationYVector, isMG);
      markers.bottom = this.getOrientationLabel(negY, isMG);
    }
    return markers;
  }

  private getOrientationLabel(vector: Vector, isMG: boolean): string {
    const label = Fovia.Util.getPatientOrientationLabel(vector);
    // Don't show Posterior on mammo images since we chest wall justify those images and don't want the P to block tissue.
    return !isMG ? label : label.toUpperCase() !== 'P' ? label : '';
  }

  private set3DOrientationMarkers(renderParams3D: RenderParams3D): Markers {
    const markers = new Markers();
    if (renderParams3D.transform) {
      const xVector = renderParams3D.transform.getXVector();
      const yVector = renderParams3D.transform.getYVector();

      // the internal coordinate system is opposite from JavaScript so reverse the vectors
      const negX = this.reverseVector(new Vector(xVector));
      const negY = this.reverseVector(new Vector(yVector));

      markers.left = Fovia.Util.getPatientOrientationLabel(xVector);
      markers.right = Fovia.Util.getPatientOrientationLabel(negX);
      markers.top = Fovia.Util.getPatientOrientationLabel(yVector);
      markers.bottom = Fovia.Util.getPatientOrientationLabel(negY);
    } else {
      console.error(`${this.constructor.name} set3DOrientationMarkers transform is null cannot compute orientation markers`);
    }

    return markers;
  }

  private reverseVector(negVector: Vector): Vector {
    negVector.x = -negVector.x;
    negVector.y = -negVector.y;
    negVector.z = -negVector.z;
    return negVector;
  }
}
