import { WLInfo } from './window-level';
import { DICOM_TAGS, getTagValueAsNumber, getTagValueAsString } from '@server-api';

/*
 Determine the Window/Level or VOI LUT configuration for each image/frame
 Supports multiple wl/voiluts per image
 Supports multiple settings for multiple frames of an image
 Not yet supported: WL parsing from GSPS
*/
class FrameWLInfo {
  public voiLuts: WLInfo[] = [];
  public wls: WLInfo[] = [];
}
export class DICOMWindowLevelInfo {
  private _frameWLInfo: FrameWLInfo[] = [];
  constructor(tags: any, public instanceUID: string) {
    this._frameWLInfo = this.parseVOIInfo(tags);
  }

  public getImageWLInfo(index: number): WLInfo[] | null {
    if (index >= 0 && index < this._frameWLInfo.length) {
      return this._frameWLInfo[index].wls;
    }
    return null;
  }
  public getImageVoiLutInfo(index: number): WLInfo[] | null {
    if (index >= 0 && index < this._frameWLInfo.length) {
      return this._frameWLInfo[index].voiLuts;
    }
    return null;
  }

  private parseVOIInfo(tags: any): FrameWLInfo[] {
    const frameInfoList: FrameWLInfo[] = [];
    if (tags != null) {
      // Parse for:
      // 1. VOI LUT Macro in Root of Image
      // 2. FRAME VOI LUT Macro Nested within FRAME_VOI_LUT_SEQUENCE for each frame of an image
      //    Despite it's name, there's no VOI lut data in this sequence.

      // Is there a VOI LutMacro at the root for this image?
      const frameInfo: FrameWLInfo | null = this.parseVOILutMacro(tags);
      if (frameInfo != null) {
        frameInfoList.push(frameInfo);
      }
      // Enhanced sopclasses may have a sequence which also needs to be inspected
      const sequenceItem: any | null = tags[DICOM_TAGS.FRAME_VOI_LUT_SEQUENCE] ? tags[DICOM_TAGS.FRAME_VOI_LUT_SEQUENCE]['Value'] : null;
      // console.log(`parseVOIInfo 1 ${tags.sopinstanceuid}`, sequenceItem, frameInfoList, tags);
      if (sequenceItem != null) {
        // Sequence is comprised of an array of VOILutMacros, parse them now
        const subSequenceItem: any | null = sequenceItem[0] ? sequenceItem[0] : null;
        if (subSequenceItem != null) {
          for (let i = 0; i < sequenceItem.length; i++) {
            const frameInfo = new FrameWLInfo();
            frameInfo.wls = this.parseWLRelatedTags(sequenceItem[i]);
            frameInfoList.push(frameInfo);
          }
        }
      }
    }
    // console.log(`parseVOIInfo 2 ${tags.sopinstanceuid}`, tags, frameInfoList);
    return frameInfoList;
  }

  private parseVOILutMacro(tags: any): FrameWLInfo | null {
    let frameInfo: FrameWLInfo | null = null;
    // One pass parsing, Parse tags in order
    // Get the WL related values

    const wlInfo: WLInfo[] = this.parseWLRelatedTags(tags);
    const voiInfo: WLInfo[] = this.parseVOILutSequence(tags);
    if (wlInfo.length > 0 || voiInfo.length > 0) {
      frameInfo = new FrameWLInfo();
      frameInfo.wls = wlInfo;
      frameInfo.voiLuts = voiInfo;
    }
    return frameInfo;

  }

  private parseVOILutSequence(tags: any): WLInfo[] {
    const voiLutInfoList: WLInfo[] = [];
    const sequenceItem: any | null = tags[DICOM_TAGS.VOI_LUT_SEQUENCE] ? tags[DICOM_TAGS.VOI_LUT_SEQUENCE]['Value'] : null;
    if (sequenceItem != null) {
      const subSequenceItem: any | null = sequenceItem[0] ? sequenceItem[0] : null;
      // We have at least one set of values
      if (subSequenceItem != null) {
        // Contains an array of 1 or more VOI Luts
        for (let i = 0; i < sequenceItem.length; i++) {
          // Descriptor is required for each VOI lut
          const v_descriptor = getTagValueAsString(sequenceItem[i], DICOM_TAGS.VOI_LUT_DESCRIPTOR);
          if (v_descriptor) {
            const v_explanation = getTagValueAsString(sequenceItem[i], DICOM_TAGS.VOI_LUT_EXPLANATION);
            const wlInfo = new WLInfo(i, v_explanation ?? `LUT #${i + 1}`);
            voiLutInfoList.push(wlInfo);
          }
        }
        // console.info(`${this.constructor.name} parseVOILutMacro found ${voiLutInfoList.length} voi lut macros`);
      }
      else {
        // console.info(`${this.constructor.name} parseVOILutMacro no macro found`);
      }
    } else {
      // console.log(`${this.constructor.name} parseVOILutMacro no sequence found`);
    }
    return voiLutInfoList;

  }

  private parseWLRelatedTags(tags: any): WLInfo[] {
    const wlInfoList: WLInfo[] = [];

    try {
      // One pass parsing, Parse tags in order
      // Get the WL related values
      const ww: string | null = getTagValueAsString(tags, DICOM_TAGS.WINDOW_WIDTH);
      const wc = getTagValueAsString(tags, DICOM_TAGS.WINDOW_CENTER);
      const we = getTagValueAsString(tags, DICOM_TAGS.WINDOW_CW_EXPLANATION);
      const wf = getTagValueAsString(tags, DICOM_TAGS.VOI_LUT_FUNCTION); // values LINEAR LINEAR_EXACT SIGMOID

      if (ww == null || wc == null) {
        // console.info(`${this.constructor.name} parseWLRelatedTags no window/level entries found`);
        const smallestPixelValue = getTagValueAsNumber(tags, DICOM_TAGS.SMALLEST_IMAGE_PIXEL_VALUE);
        const largestPixelValue = getTagValueAsNumber(tags, DICOM_TAGS.LARGEST_IMAGE_PIXEL_VALUE);
        if (smallestPixelValue == null || largestPixelValue == null) {
          return wlInfoList;
        }
        // console.info(`${this.constructor.name} parseWLRelatedTags using smallest/largest pixel tags`);
        const wlInfo = new WLInfo();
        wlInfo.width = largestPixelValue - smallestPixelValue + 1;
        wlInfo.level = wlInfo.width / 2;
        wlInfo.description = 'Auto';
        // console.info(`${this.constructor.name} parseWLRelatedTags using smallest/largest pixel tags `, wlInfo);
        wlInfoList.push(wlInfo);
        return wlInfoList;
      }
      const wws = ww.split('\\');
      const wcs = wc.split('\\');
      if (wws.length != wcs.length) {
        // console.info(`${this.constructor.name} parseWLRelatedTags ww entries don't match wc entries`, wws, wcs);
        return wlInfoList;
      }
      const wes = we ? we.split('\\') : '';
      // TO DO: sometimes w/l values are duplciated in the dicom header no reason to propagate duplicates?
      for (let i = 0; i < wws.length; i++) {
        const wlInfo = new WLInfo();
        wlInfo.width = Number(wws[i]);
        wlInfo.level = Number(wcs[i]);
        if (wes != null && i < wes.length) {
          wlInfo.description = wes[i];
        } else {
          wlInfo.description = `#${i+1}`;
        }
        if (wf) {
          wlInfo.wlFunction = wf; // Default is linear same as not present.
        }
        wlInfoList.push(wlInfo);
      }

      // console.log(`${this.constructor.name} parseWLRelatedTags ${wlInfoList.length} window/level entries found`, wlInfoList);

    } catch (err) {
      console.error(`${this.constructor.name} parseWLRelatedTags exception ${JSON.stringify(err)}`);
    }
    return wlInfoList;
  }
}
