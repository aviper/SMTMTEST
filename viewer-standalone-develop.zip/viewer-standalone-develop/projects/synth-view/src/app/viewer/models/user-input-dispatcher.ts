import { UserInputEvent } from './user-input-event';
import { EVENT_INFO, IEventHandler } from './base-event-handler';


// Class to route keyboard dispatch keyboard and mouse events to a handler
export class UserInputDispatcher {

  constructor(private handler: IEventHandler) {
  }

  public dispatch(inputEvent: UserInputEvent): boolean {
    return this.dispatchEventInfo(inputEvent);
  }

  protected dispatchEventInfo(inputEvent: UserInputEvent): boolean {
    if (inputEvent.keyboardEvent != null) {
      return this.dispatchKeyboardEvent(inputEvent.eventInfo, inputEvent.keyboardEvent);
    }
    if (inputEvent.mouseEvent != null) {
      return this.dispatchMouseEvent(inputEvent.eventInfo, inputEvent.mouseEvent);
    }
    if (inputEvent.wheelEvent != null) {
      return this.dispatchWheelEvent(inputEvent.eventInfo, inputEvent.wheelEvent);
    }
    return false;
  }

  // return true if handled
  protected dispatchMouseEvent(eventInfo: EVENT_INFO, event: MouseEvent): boolean {
    let handled = false;
    if (this.handler == null) {
      return handled;
    }
    switch (eventInfo) {
      case EVENT_INFO.eClick:
        // console.log(`dispatchMouseEvent eClick ${EVENT_INFO[eventInfo]}`, eventInfo, event);
        handled = this.handler.mouseClick(event);
        break;
      case EVENT_INFO.eContextMenu:
        // console.log(`dispatchMouseEvent eContextMenu ${EVENT_INFO[eventInfo]}`, eventInfo, event);
        handled = this.handler.mouseContextMenu(event);
        break;
      case EVENT_INFO.eDoubleClick:
        handled = this.handler.mouseDoubleClick(event);
        break;
      case EVENT_INFO.eMouseDown:
      case EVENT_INFO.eLeftDownHold:
        handled = this.handler.mouseDown(event);
        break;
      case EVENT_INFO.eMouseEnter:
        handled = this.handler.mouseEnter(event);
        break;
      case EVENT_INFO.eMouseLeave:
        handled = this.handler.mouseLeave(event);
        break;
      case EVENT_INFO.eMouseMove:
        handled = this.handler.mouseMove(event);
        break;
      case EVENT_INFO.eMouseOut:
        handled = this.handler.mouseOut(event);
        break;
      case EVENT_INFO.eMouseOver:
        handled = this.handler.mouseOver(event);
        break;
      case EVENT_INFO.eMouseUp:
      case EVENT_INFO.eLeftDownRelease:
        handled = this.handler.mouseUp(event);
        break;
      case EVENT_INFO.eMouseMoveStopped:
        handled = this.handler.mouseMoveStopped(event);
        break;
      default:
    }
    return handled;
  }

  protected dispatchKeyboardEvent(eventInfo: EVENT_INFO, event: KeyboardEvent): boolean {
    let handled = false;
    if (this.handler == null) {
      return handled;
    }
    switch (eventInfo) {
      case EVENT_INFO.eKeyDown:
        handled = this.handler.keyDown(event);
        break;
      case EVENT_INFO.eKeyPress:
        handled = this.handler.keypress(event);
        break;
      case EVENT_INFO.eKeyUp:
        handled = this.handler.keyUp(event);
        break;
      default:
    }
    return handled;
  }

  protected dispatchWheelEvent(eventInfo: EVENT_INFO, event: WheelEvent): boolean {
    let handled = false;
    if (this.handler == null) {
      return handled;
    }
    handled = this.handler.wheel(event);
    return handled;
  }
}
