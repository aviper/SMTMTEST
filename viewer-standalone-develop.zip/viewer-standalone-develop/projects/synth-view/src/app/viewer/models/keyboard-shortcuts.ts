import { HOT_KEY_COMMAND, HOT_KEY_TYPE } from './utility-classes';
import { TOOL_TYPE } from '../tools';
import { EVENT_INFO } from './base-event-handler';

export type TModifierKey = 'metaKey' | 'ctrlKey' | 'altKey' | 'shiftKey' | 'numPad'  ;

export interface KeyConfig {
  key: string;
  ctrl: boolean;
  shift: boolean;
  alt: boolean;
  meta: boolean;
  numpad: boolean;
  action: HOT_KEY_TYPE;
}

export function keyActionFromInfo(info: EVENT_INFO): HOT_KEY_TYPE | undefined {
  switch (info) {
    case EVENT_INFO.eKeyDown:
      return HOT_KEY_TYPE.down;
    case EVENT_INFO.eKeyUp:
    case EVENT_INFO.eKeyPress:
      return HOT_KEY_TYPE.up;
    case EVENT_INFO.eKeyHold:
      return HOT_KEY_TYPE.hold;

    default:
      return undefined;
  }
}

export function keyActionFromEvent(event: KeyboardEvent): HOT_KEY_TYPE | undefined {
  switch (event.type) {
    case 'keydown':
      return HOT_KEY_TYPE.down;
    case 'keyup':
    case 'keypress':
      return HOT_KEY_TYPE.up;

    default:
      return undefined;
  }
}

export function keysFromEvent(keyboardEvent: KeyboardEvent, action?: EVENT_INFO): KeyConfig {
  const numLockOn = keyboardEvent.getModifierState('NumLock');
  return {
    key: keyboardEvent.key,
    ctrl: keyboardEvent.ctrlKey,
    shift: keyboardEvent.shiftKey,
    alt: keyboardEvent.altKey,
    meta: keyboardEvent.metaKey,
    numpad: numLockOn && keyboardEvent.code.includes('Numpad'),
    action: (action === undefined ? keyActionFromEvent(keyboardEvent) : keyActionFromInfo(action)) || HOT_KEY_TYPE.down,
  };
}

export interface SharedShortcut {
  name: string;
  keyCombination: KeyCombination;
}

export interface KeyCombination {
  modifierKeys: TModifierKey[];
  key: string | string[];
}

export interface Shortcut {
  name: string;
  keyCombination: KeyCombination;
}

export const SHORTCUTS: Record<string, Shortcut> = {
  ['context-sensitive-1']: {
    name: 'context-sensitive-1',
    keyCombination: {
      modifierKeys: [],
      key: ['1'],
    },
  },
  ['context-sensitive-2']: {
    name: 'context-sensitive-2',
    keyCombination: {
      modifierKeys: [],
      key: ['2'],
    },
  },
  ['context-sensitive-3']: {
    name: 'context-sensitive-3',
    keyCombination: {
      modifierKeys: [],
      key: ['3'],
    },
  },
  ['context-sensitive-4']: {
    name: 'context-sensitive-4',
    keyCombination: {
      modifierKeys: [],
      key: ['4'],
    },
  },
  ['context-sensitive-5']: {
    name: 'context-sensitive-5',
    keyCombination: {
      modifierKeys: [],
      key: ['5'],
    },
  },
  ['context-sensitive-6']: {
    name: 'context-sensitive-6',
    keyCombination: {
      modifierKeys: [],
      key: ['6'],
    },
  },
  ['context-sensitive-7']: {
    name: 'context-sensitive-7',
    keyCombination: {
      modifierKeys: [],
      key: ['7'],
    },
  },
  ['context-sensitive-8']: {
    name: 'context-sensitive-8',
    keyCombination: {
      modifierKeys: [],
      key: ['8'],
    },
  },
  ['context-sensitive-9']: {
    name: 'context-sensitive-9',
    keyCombination: {
      modifierKeys: [],
      key: ['9'],
    },
  },
  ['context-sensitive-0']: {
    name: 'context-sensitive-0',
    keyCombination: {
      modifierKeys: [],
      key: ['0'],
    },
  },
  ['context-sensitive--']: {
    name: 'context-sensitive--',
    keyCombination: {
      modifierKeys: [],
      key: ['-'],
    },
  },
  ['context-sensitive-=']: {
    name: 'context-sensitive-=',
    keyCombination: {
      modifierKeys: [],
      key: ['='],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.nextPanelPage]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.nextPanelPage],
    keyCombination: {
      modifierKeys: [],
      key: ['PageDown'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.prevPanelPage]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.prevPanelPage],
    keyCombination: {
      modifierKeys: [],
      key: ['PageUp'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.olderComparison]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.olderComparison],
    keyCombination: {
      modifierKeys: [],
      key: ['Backspace'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.newerComparison]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.newerComparison],
    keyCombination: {
      modifierKeys: ['shiftKey'],
      key: ['Backspace'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.helpAbout]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.helpAbout],
    keyCombination: {
      modifierKeys: ['shiftKey'],
      key: ['F1'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.reloadExams]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.reloadExams],
    keyCombination: {
      modifierKeys: [],
      key: ['F5'],
    },
  },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.showDicomTags]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.showDicomTags],
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['F2'],
  //   },
  // },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.showHangingProtocol]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.showHangingProtocol],
  //   keyCombination: {
  //     modifierKeys: ['ctrlKey', 'shiftKey'],
  //     key: ['F2'],
  //   },
  // },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.swapAdjacent]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.swapAdjacent],
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['F3'],
  //   },
  // },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleTomo]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleTomo],
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: [';'],
  //   },
  // },
  [TOOL_TYPE[TOOL_TYPE.eToggleMPR]]: {
    name: TOOL_TYPE[TOOL_TYPE.eToggleMPR],
    keyCombination: {
      modifierKeys: [],
      key: ['/'],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eToggle2D]]: {
    name: TOOL_TYPE[TOOL_TYPE.eToggle2D],
    keyCombination: {
      modifierKeys: [],
      key: [','],
    },
  },
  // ['Tool - Rotate']: {
  //   name: 'Tool - Rotate 90',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['/'],
  //   },
  // },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleDICOMOverlay]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleDICOMOverlay],
    keyCombination: {
      modifierKeys: [],
      key: ['A', 'a'],
    },
  },
  // ['Tool - Measure']: {
  //   name: 'Tool - Measure',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['B', 'b'],
  //   },
  // },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCadAI]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCadAI],
    keyCombination: {
      modifierKeys: [],
      key: ['C', 'c'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCompareMode]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCompareMode],
    keyCombination: {
      modifierKeys: [],
      key: ['D', 'd'],
    },
  },
  // ['Tool - Swap Images']: {
  //   name: 'Tool - Swap Images',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['E', 'e'],
  //   },
  // },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleFlicker]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleFlicker],
    keyCombination: {
      modifierKeys: [],
      key: ['F', 'f'],
    },
  },
  // ['Tool - Drop Arrow']: {
  //   name: 'Tool - Drop Arrow',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['G', 'g'],
  //   },
  // },
  // ['Tool - Annotate spine']: {
  //   name: 'Tool - Annotate spine',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['H', 'h'],
  //   },
  // },
  // ['Tool - Invert Greyscale']: {
  //   name: 'Tool - Invert Greyscale',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['I', 'i'],
  //   },
  // },
  // ['Tool - Text Annotation']: {
  //   name: 'Tool - Text Annotation',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['J', 'j'],
  //   },
  // },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleKeyImage]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleKeyImage],
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['K', 'k'],
  //   },
  // },
  [TOOL_TYPE[TOOL_TYPE.eToggleKeyObjects]]: {
    name: TOOL_TYPE[TOOL_TYPE.eToggleKeyObjects],
    keyCombination: {
      modifierKeys: [],
      key: ['M', 'm'],
    },
  },
  // ['Tool - Pan']: {
  //   name: 'Tool - Pan',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['N', 'n'],
  //   },
  // },
  // [TOOL_TYPE[TOOL_TYPE.eEdgeEnhancement]]: {
  //   name: TOOL_TYPE[TOOL_TYPE.eEdgeEnhancement],
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['O', 'o'],
  //   },
  // },
  // ['Tool - Page']: {
  //   name: 'Tool - Page',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['P', 'p'],
  //   },
  // },
  // ['Tool - Page All']: {
  //   name: 'Tool - Page All',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['Q', 'q'],
  //   },
  // },
  // ['Tool - ROI']: {
  //   name: 'Tool - ROI',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['R', 'r'],
  //   },
  // },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.reverseSeries]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.reverseSeries],
  //   keyCombination: {
  //     modifierKeys: ['ctrlKey'],
  //     key: ['R', 'r'],
  //   },
  // },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCrop]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleCrop],
    keyCombination: {
      modifierKeys: [],
      key: ['S', 's'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.showToolbox]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.showToolbox],
    keyCombination: {
      modifierKeys: [],
      key: ['T', 't'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleAnnotations]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleAnnotations],
    keyCombination: {
      modifierKeys: [],
      key: ['U', 'u'],
    },
  },
  // ['Tool - Flip']: {
  //   name: 'Tool - Flip Horizontal',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['V', 'v'],
  //   },
  // },
  // ['Tool - Window Width/Level']: {
  //   name: 'Tool - Window Width/Level',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['W', 'w'],
  //   },
  // },
  // ['Tool - 3D Cursor']: {
  //   name: 'Tool - 3D Cursor',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['X', 'x'],
  //   },
  // },
  // ['Tool - Cine']: {
  //   name: 'Tool - Cine',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['Y', 'y'],
  //   },
  // },
  // ['Tool - Magnify']: {
  //   name: 'Tool - Magnify',
  //   keyCombination: {
  //     modifierKeys: [],
  //     key: ['Z', 'z'],
  //   },
  // },
  [TOOL_TYPE[TOOL_TYPE.eNavWorklist]]: {
    name: TOOL_TYPE[TOOL_TYPE.eNavWorklist],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: [',', '<'],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eNavMarkReadNext]]: {
    name: TOOL_TYPE[TOOL_TYPE.eNavMarkReadNext],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: ['.', '>'],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eNavSkipToNextExam]]: {
    name: TOOL_TYPE[TOOL_TYPE.eNavSkipToNextExam],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: [' '],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eNavMarkReadExit]]: {
    name: TOOL_TYPE[TOOL_TYPE.eNavMarkReadExit],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: ['Enter'],
    },
  },
  ['MG Protocol - Previous']: {
    name: 'MG Protocol - Previous',
    keyCombination: {
      modifierKeys: [],
      key: ['['],
    },
  },
  ['MG Protocol - Next ']: {
    name: 'MG Protocol - Next',
    keyCombination: {
      modifierKeys: [],
      key: [']'],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eToggleLocalizerLines]]: {
    name: TOOL_TYPE[TOOL_TYPE.eToggleLocalizerLines],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: ['\\', '|'],
    },
  },
  [TOOL_TYPE[TOOL_TYPE.eToggleThumbnail]]: {
    name: TOOL_TYPE[TOOL_TYPE.eToggleThumbnail],
    keyCombination: {
      modifierKeys: ['ctrlKey', 'shiftKey'],
      key: [']', '}'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleUsePowerWheel]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.toggleUsePowerWheel],
    keyCombination: {
      modifierKeys: [],
      key: ['\`'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite1]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite1],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['1'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite2]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite2],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['2'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite3]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite3],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['3'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite4]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite4],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['4'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite5]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite5],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['5'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite6]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite6],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['6'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite7]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite7],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['7'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite8]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite8],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['8'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite9]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.presetFavorite9],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['9'],
    },
  },
  [HOT_KEY_COMMAND[HOT_KEY_COMMAND.resetWL]]: {
    name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.resetWL],
    keyCombination: {
      modifierKeys: ['numPad'],
      key: ['0'],
    },
  },
  // [HOT_KEY_COMMAND[HOT_KEY_COMMAND.eUserCalibration]]: {
  //   name: HOT_KEY_COMMAND[HOT_KEY_COMMAND.eUserCalibration],
  //   keyCombination: {
  //     modifierKeys: ['alt'],
  //     key: ['c'],
  //   }
  // },
};
export const SHARED_SHORTCUTS: SharedShortcut[] = Object.values(SHORTCUTS).map(shortcut => ({
  name: shortcut.name,
  keyCombination: shortcut.keyCombination,
}));
