import { OrientationMarkerContents } from './orientation-marker-contents';

describe('OrientationMarkerContents', () => {
  it('should create an instance', () => {
    const examSeries = null;
    const renderParams = null;
    expect(new OrientationMarkerContents(examSeries, renderParams)).toBeTruthy();
  });
});
