import { PresetEntry } from './preset-entry';

describe('PresetEntry', () => {
  it('should create an instance', () => {
    expect(new PresetEntry()).toBeTruthy();
  });
});
