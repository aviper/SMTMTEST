import { NO_VOI_LUT } from "./window-level";
export interface IPresetEntry {
  title: string;
  w: number;
  l: number;
}

export interface IVOILUTPresetEntry {
  title: string;
  i: number; //voi lut index
}

export const PRESET_NOT_SET = Number.MAX_SAFE_INTEGER;

export class PresetEntry implements IPresetEntry {
  public title: string;
  public w: number = PRESET_NOT_SET;
  public l: number = PRESET_NOT_SET;

  constructor(entry: IPresetEntry) {
    this.title = entry.title;
    this.w = entry.w;
    this.l = entry.l;
  }

  public toString(): string {
    return `${this.title} W:${this.w} L:${this.l}`;
  }
}

export class VOILutEntry implements IVOILUTPresetEntry {
  public title: string;
  i: number = NO_VOI_LUT; //voi lut index

  constructor(entry: IVOILUTPresetEntry) {
    this.title = entry.title;
    this.i = entry.i;
  }

  public toString(): string {
    return `${this.title} I:${this.i}`;
  }
}
