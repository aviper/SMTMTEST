import { DICOM_TAGS, getTagValueAsNumber, getTagValueAsString } from '@server-api';


export class SUVInfo {
  public earliestAcquisitionTime: string | null = null; // This is handed to us. It is the oldest acquisition time in the series of images.
  public readonly actualFrameDuration: number | null = null;
  public readonly acquisitionDate: string | null = null;
  public readonly acquisitionTime: string | null = null;
  public readonly correctedImage: string | null = null;
  public readonly decayCorrection: string | null = null;
  public readonly frameReferenceTime: string | null = null;
  public readonly gePrivateScanDateTime: string | null = null;
  public readonly manufacturer: string | null = null;
  public readonly modality: string | null = null;
  public readonly patientWeight: number | null = null;
  public readonly rescaleSlope: number | null = null;
  public readonly philipsPrivateScaleFactor: number | null = null;
  public readonly philipsAltPrivateScaleFactor: number | null = null;
  public readonly radionuclideHalfLife: number | null = null;
  public readonly radionuclideTotalDose: number | null = null;
  public readonly radiopharmaceuticalStartDatetime: string | null = null;
  public readonly radiopharmaceuticalStartTime: string | null = null;
  public readonly seriesDate: string | null = null;
  public readonly seriesTime: string | null = null;
  public readonly units: string | null = null;

  constructor(tags: any, instanceUID: string) {
    if (tags != null) {
      let sequenceItem: any | null = null;
      // let subSequenceItem: any | null = null;
      const valueAsString: string | null = getTagValueAsString(tags, DICOM_TAGS.SOP_CLASS_UID);
      if (valueAsString === null) {
        console.error(`Unable to parse SOP Class UID tag for image ${instanceUID}`);
        return;
      }
      this.manufacturer = getTagValueAsString(tags, DICOM_TAGS.MANUFACTURER);
      this.seriesDate = getTagValueAsString(tags, DICOM_TAGS.SERIES_DATE);
      this.seriesTime = getTagValueAsString(tags, DICOM_TAGS.SERIES_TIME);
      this.acquisitionTime = getTagValueAsString(tags, DICOM_TAGS.ACQUISITION_TIME);
      this.acquisitionDate = getTagValueAsString(tags, DICOM_TAGS.ACQUISITION_DATE);
      this.actualFrameDuration = getTagValueAsNumber(tags, DICOM_TAGS.ACTUAL_FRAME_DURATION);
      this.decayCorrection = getTagValueAsString(tags, DICOM_TAGS.DECAY_CORRECTION);
      this.frameReferenceTime = getTagValueAsString(tags, DICOM_TAGS.FRAME_REFERENCE_TIME);
      this.patientWeight = getTagValueAsNumber(tags, DICOM_TAGS.PATIENT_WEIGHT);
      this.rescaleSlope = getTagValueAsNumber(tags, DICOM_TAGS.RESCALE_SLOPE);
      this.units = getTagValueAsString(tags, DICOM_TAGS.UNITS);
      this.correctedImage = getTagValueAsString(tags, DICOM_TAGS.CORRECTED_IMAGE);

      sequenceItem = tags[DICOM_TAGS.RADIOPHARMACEUTICAL_INFORMATION_SEQUENCE] ? tags[DICOM_TAGS.RADIOPHARMACEUTICAL_INFORMATION_SEQUENCE]['Value'] : null;
      if (sequenceItem) {
        this.radionuclideHalfLife = getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.RADIONUCLIDE_HALF_LIFE);
        this.radionuclideTotalDose = getTagValueAsNumber(sequenceItem[0], DICOM_TAGS.RADIONUCLIDE_TOTAL_DOSE);
        this.radiopharmaceuticalStartTime = getTagValueAsString(sequenceItem[0], DICOM_TAGS.RADIOPHARMACEUTICAL_START_TIME);
        this.radiopharmaceuticalStartDatetime = getTagValueAsString(sequenceItem[0], DICOM_TAGS.RADIOPHARMACEUTICAL_START_DATETIME);
      }

      // A few specific private tags.
      this.gePrivateScanDateTime = getTagValueAsString(tags, DICOM_TAGS.GE_PRIVATE_SCAN_DATE_AND_TIME);
      this.philipsAltPrivateScaleFactor = getTagValueAsNumber(tags, DICOM_TAGS.PHILIPS_PRIVATE_UNKNOWN);
      this.philipsPrivateScaleFactor = getTagValueAsNumber(tags, DICOM_TAGS.PHILIPS_PRIVATE_SCALE_FACTOR);
    }
  }
}
