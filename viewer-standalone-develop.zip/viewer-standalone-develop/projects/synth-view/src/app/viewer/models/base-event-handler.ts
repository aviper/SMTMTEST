import { BehaviorSubject, Observable } from 'rxjs';

export enum EVENT_INFO {
  eNone = 0,
  eClick,
  eContextMenu,
  eDoubleClick,
  eKeyDown,
  eKeyPress,
  eKeyUp,
  eKeyHold,
  eLeftDownHold,
  eLeftDownRelease,
  eMiddleClick,
  eMouseDown,
  eMouseEnter,
  eMouseLeave,
  eMouseMove,
  eMouseOut,
  eMouseOver,
  eMouseUp,
  eMultiFirstRelease, // When multiple buttons were down but one has been released.
  eRightDownHold,
  eWheel,
  eMouseMoveStopped
}

export interface IEventHandler {
    // Common dispatcher for any kind of event
    keypress(event: KeyboardEvent): boolean;
    keyUp(event: KeyboardEvent): boolean;
    keyDown(event: KeyboardEvent): boolean;

    mouseClick(event: MouseEvent): boolean;
    mouseContextMenu(event: MouseEvent): boolean;
    mouseDoubleClick(event: MouseEvent): boolean;
    mouseDown(event: MouseEvent): boolean;
    mouseEnter(event: MouseEvent): boolean;
    mouseLeave(event: MouseEvent): boolean;
    mouseMove(event: MouseEvent): boolean;
    mouseOut(event: MouseEvent): boolean;
    mouseOver(event: MouseEvent): boolean;
    mouseUp(event: MouseEvent): boolean;
    mouseMoveStopped(event: MouseEvent): boolean;

    wheel(event: WheelEvent): boolean;

    mouseEntered$: Observable<boolean>;
}

// Provide derived methods for events of interest
export class BaseEventHandler implements IEventHandler {
    private mouseEntered$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

    // By default, we don't handle keypresses unless they are explicity over-ridden
    public keypress(event: KeyboardEvent): boolean { event.preventDefault(); return false; }
    public keyUp(event: KeyboardEvent): boolean { event.preventDefault(); return false; }
    public keyDown(event: KeyboardEvent): boolean { event.preventDefault(); return false; }

    // Event handlers must override the methods they want to handle
    public mouseClick(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseContextMenu(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseDoubleClick(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseDown(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseEnter(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseLeave(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseMove(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseOut(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseOver(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseUp(event: MouseEvent): boolean { event.preventDefault(); return false; }
    public mouseMoveStopped(event: MouseEvent): boolean { event.preventDefault(); return false; }

    public wheel(event: WheelEvent): boolean { event.preventDefault(); return false; }

    // Useful for determining whether the mouse has entered this component
    public get mouseEntered$(): Observable<boolean> {
      return this.mouseEntered$$;
    }

}
