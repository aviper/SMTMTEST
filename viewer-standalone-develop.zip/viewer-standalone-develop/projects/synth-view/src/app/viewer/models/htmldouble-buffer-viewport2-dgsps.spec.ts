import { HTMLDoubleBufferViewport2DGSPS } from './htmldouble-buffer-viewport2-dgsps';

describe('HTMLDoubleBufferViewport2DGSPS', () => {
  it('should create an instance', () => {
    expect(new HTMLDoubleBufferViewport2DGSPS('foo',10,10)).toBeTruthy();
  });
});
