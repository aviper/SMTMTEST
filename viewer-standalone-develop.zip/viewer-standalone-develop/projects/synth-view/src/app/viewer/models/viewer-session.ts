import Fovia from 'foviaapi';
import ReturnCode = Fovia.ReturnCode;

import { ExamGroup } from '@server-api';
import { ExamGroupId } from '@idgital/vision-auth-interface';

import { ExamSource } from './exam-source';


/**
 * Maintains all of the non-display data associated with a viewing session.
 *
 * Fields
 * ------
 * - `sessionId`: The controller-assigned identifier for the session.
 * - `imagingServer`: The `URL` of the Fovia instance or gateway server used to load data into the session.
 * - `primaryExamUID`: The DICOM study instance UID of the primary exam.
 * - `examSources`: The set of source information for all unique exams loaded into the session.
 * - `uidToExamSource`: A table mapping DICOM study instance UID to the `ExamSource` from which it is loaded.
 * - `comparisonExamUIDs`: The set of all known comparison exam study instance UIDs.
 * - `currentComparisonExamUID`: The comparison exam UID for the comparison exam currently being interacted with, or `undefined`.
 */
export class ViewerSession {
  public currentComparisonExamUID: (string | undefined);

  public readonly examGroupId: ExamGroupId;
  public readonly primaryExamUID: string;

  private _examGroup: ExamGroup;

  constructor(examGroup: ExamGroup) {
    this._examGroup = examGroup;
    const primaryExamUID = examGroup.primaryExam.studyUID as string;
    this.currentComparisonExamUID = undefined;

    // Set the current comparison exam to the first one in the list
    if (examGroup.comparisonExams.length > 0) {
      this.currentComparisonExamUID = examGroup.comparisonExams[0].studyUID as string;
    }

    this.examGroupId = examGroup.groupId;
    this.primaryExamUID = primaryExamUID;
    // TODO: Patient information, physician information
  }

  get examGroup(): ExamGroup {
    return this._examGroup;
  }

  /**
   * Retrieve the exam source information for a given study instance UID.
   * @param uid The DICOM study instance UID.
   * @returns The associated `ExamSource`, or `undefined` if the study instance UID is not known.
   */
  public getExamSourceForUID(uid: (string | undefined)): (ExamSource | undefined) {
    if (uid !== undefined) {
      const examInfo = this.examGroup.examInformationForUID(uid);
      if (examInfo == null) {
        return undefined;
      } else {
        return new ExamSource(examInfo);
      }
    } else {
      return undefined;
    }
  }

  /**
   * Add a new `ExamSource` for a comparison exam.
   * @param examInfo Information about where to find the comparison exam.
   * @returns A `tuple [(ExamSource | undefined), boolean]` where:
   * - The first value is the `ExamSource` for the comparison exam,
   * - The second value is `true` if the `ExamSource` was newly created, or `false` if the `ExamSource` already existed.
   */
  // public addComparisonExamSource(examInfo: IExamInformation): [(ExamSource | undefined), boolean] {
  //   if (examInfo.instanceUID !== undefined) {
  //     let created = false;
  //     let source = this.uidToExamSource.get(examInfo.instanceUID);
  //     if (source === undefined) {
  //       source = new ExamSource(this.sessionId, examInfo, examInfo.sourceType);
  //       this.uidToExamSource.set(examInfo.instanceUID, source);
  //       this.examSources.push(source);
  //       created = true;
  //     }
  //     return [source, created];
  //   } else { // No study instance UID provided
  //     return [undefined, false];
  //   }
  // }

  // Call after all application services have been cleaned up
  // public async unloadAllExamsfromFovia(): Promise<boolean> {
  //   const allPromises = new Array<Promise<unknown>>();
  //   this.uidToExamSource.forEach((value: ExamSource, key: string) => {
  //     this.uidToExamSource.delete(key);
  //     const examUnloadedPromise = this.unloadExam(key);
  //     allPromises.push(examUnloadedPromise);
  //   });
  //   return Promise.allSettled(allPromises)
  //     .then(() => {
  //       console.info(`Server-side resources for viewer session ${this.sessionId} fully unloaded.`);
  //       return true;
  //     })
  //     .catch((reason?: any) => {
  //       console.warn(`Fovia reports that server-side resources for one or more studies of viewer session ${this.sessionId} failed to unload - are renders in-progress?`);
  //       return false;
  //     });
  // }
  //
  // private async unloadExam(studyUID: string): Promise<ReturnCode> {
  //   return this.foviaService.unloadExamServerData(studyUID);
  // }
}
