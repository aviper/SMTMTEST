import Fovia from 'foviaapi';
import SeriesDataContext = Fovia.SeriesDataContext;
import { IMAGE_CROP_RULE, IMAGE_DISPLAY_ALIGNMENT, IMAGE_RES_RULE } from './utility-classes';
import { ExamSeries } from './exam-series';
import { IMAGE_VIEW_POSITION_MODIFIER, MAMMO_IMAGE_TYPE } from './mammo-info';
import { makeImageKeyFromImageTags } from '@server-api';

export class VirtualSeriesImageSet {
  public overrideImageAlignment = false;
  public flipStepOnly = false;
  public seriesDataContext: SeriesDataContext | null;
  public numImages;
  private _isDuplicate = false;
  private _isBlank = false;

  // Track annotations that need to be added to the imageSet images when they are rendered in a viewport.
  // This supports the copying of existing annotations when adding an image to the montage.
  private _clonedAnnotations = new Map<string, Fovia.GraphicAnnotation[]>();

  constructor(public sourceSeries: ExamSeries | null,
              public firstImageIndex: number,
              public lastImageIndex: number,
              public imageAlignment: IMAGE_DISPLAY_ALIGNMENT = IMAGE_DISPLAY_ALIGNMENT.none,
              public flipHorizontal: boolean = false,
              public rotate180: boolean = false,
              public imageResRule: IMAGE_RES_RULE = IMAGE_RES_RULE.unknown,
              public imageCropRule: IMAGE_CROP_RULE = IMAGE_CROP_RULE.unknown,
  ) {
    this.seriesDataContext = sourceSeries?.foviaSeriesDataContext ?? null;
    if (sourceSeries == null) {
      this._isBlank = true;
    }
    this.numImages = lastImageIndex - firstImageIndex + 1;
  }

  set isDuplicate(value: boolean) {
    this._isDuplicate = value;
  }

  get isDuplicate(): boolean {
    return this._isDuplicate;
  }

  get isBlank(): boolean {
    return this._isBlank;
  }


  public duplicate(markAsDuplicate: boolean = false): VirtualSeriesImageSet {
    const duplicateSeries = new VirtualSeriesImageSet(
      this.sourceSeries,
      this.firstImageIndex,
      this.lastImageIndex,
      this.imageAlignment,
      this.flipHorizontal,
      this.rotate180,
      this.imageResRule,
      this.imageCropRule,
    );
    if (markAsDuplicate) {
      duplicateSeries.isDuplicate = true;
    }
    return duplicateSeries;
  }

  public toString(): string {
    return `start ${this.firstImageIndex} end ${this.lastImageIndex}`;
  }

  public addClonedAnnotation(imageIndex: number, annotation: Fovia.GraphicAnnotation): void {
    if (this.seriesDataContext == null) {
      console.error(`addClonedAnnotation: sdc required when adding annotation to imageSet`);
      return;
    }
    if (imageIndex < this.firstImageIndex || imageIndex > this.lastImageIndex) {
      console.error(`addClonedAnnotation: imageIndex out of range`);
      return;
    }
    const imageKey = makeImageKeyFromImageTags(this.seriesDataContext.imageTags[imageIndex]);
    let annotations = this._clonedAnnotations.get(imageKey);
    if (annotations == null) {
      annotations = [];
      this._clonedAnnotations.set(imageKey, annotations);
    }
    annotations.push(annotation);
  }
  public detachClonedAnnotations(): Map<string, Fovia.GraphicAnnotation[]> {
    const ret = this._clonedAnnotations;
    this._clonedAnnotations = new Map<string, Fovia.GraphicAnnotation[]>();
    return ret;
  }

}

export function sortImageSetForMammo(imageSet: VirtualSeriesImageSet[]): VirtualSeriesImageSet[] {
  if (imageSet.some(i => i.isBlank)) {
    console.error(`sortImageSetForMammo cannot sort imageSet: imageSet has blank image. `);
    return imageSet;
  }

  return imageSet.sort( (s1, s2): number => {
    const s1Tags = s1.sourceSeries?.getMammoInfo(s1.sourceSeries.getImageInstanceUID(s1.firstImageIndex));
    const s2Tags = s2.sourceSeries?.getMammoInfo(s2.sourceSeries.getImageInstanceUID(s2.firstImageIndex));

    if (s1Tags != null && s2Tags != null) {
      if (s1Tags.viewPosition !== s2Tags.viewPosition) {
        if (s1Tags.viewPosModifier !== s2Tags.viewPosModifier) {
          return s1Tags.viewPosModifier < s2Tags.viewPosModifier ? -1 : 0;
        }
        return s1Tags.viewPosition < s2Tags.viewPosition ? -1 : 1;
      } else if (s1Tags.imageType !== s2Tags.imageType) {
        // Favor xray image over synthetic image.
        return s1Tags.imageType === MAMMO_IMAGE_TYPE.PRIMARY ? -1 : 1;
      } else if (s1Tags.viewPosModifier === IMAGE_VIEW_POSITION_MODIFIER.IMPLANT_DISPLACED) {
        if (s2Tags.viewPosModifier === IMAGE_VIEW_POSITION_MODIFIER.IMPLANT_DISPLACED) {
          if (s1Tags.acquisitionTime === s2Tags.acquisitionTime) {
            return 0;
          }
          // Favor newer image.
          return s1Tags.acquisitionTime > s2Tags.acquisitionTime ? -1 : 1;
        }
        return -1;
      } else if (s2Tags.viewPosModifier === IMAGE_VIEW_POSITION_MODIFIER.IMPLANT_DISPLACED) {
        // Note that the case where both images are implant displaced is handled in the case above.
        return 1;
      } else if (s1Tags.viewPosModifier === s2Tags.viewPosModifier) {
        return 0;
      } else {
        return s1Tags.viewPosModifier < s2Tags.viewPosModifier ? -1 : 0;
      }
    } else {
      return 0;
    }
  });
}
