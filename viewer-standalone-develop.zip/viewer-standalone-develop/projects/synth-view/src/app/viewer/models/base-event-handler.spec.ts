import { BaseEventHandler } from './base-event-handler';

describe('BaseEventHandler', () => {
  it('should create an instance', () => {
    expect(new BaseEventHandler()).toBeTruthy();
  });
});
