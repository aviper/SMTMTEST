import { getPanelTemplate, PANEL_TEMPLATE_TYPE } from './panel-template';

describe('MPRPanelLayout', () => {
  it('should create an instance', () => {
    const panelLayout = getPanelTemplate(PANEL_TEMPLATE_TYPE.eMPR, 0);
    expect(panelLayout).toBeTruthy();
  });
});
