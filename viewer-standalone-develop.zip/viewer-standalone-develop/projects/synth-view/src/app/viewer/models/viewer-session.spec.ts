import { ViewerSession } from './viewer-session';
import {
  UUID,
  uuid4
} from '@server-api';

describe('ViewerSession', () => {
  it('should create an instance', () => {
    expect(new ViewerSession(uuid4())).toBeTruthy();
  });
});
