import Fovia from 'foviaapi';
import { FUSION_VIEWPORT_TYPE } from './htmldouble-buffer-viewport-mprfusion';
import { getPendingRenderParams3D, getPendingRenderParamsFusion } from '@server-api';

export class HTMLDoubleBufferViewportMPRFused extends Fovia.UI.HTMLFusionViewportMPR {
  public type = FUSION_VIEWPORT_TYPE.FUSED;
  constructor(htmlElementName: string,
    width: number,
    height: number,
    repaintable?: boolean,
    usePNG?: boolean,
    renderEngineLocation?: Fovia.RenderLocation) {
    super(htmlElementName, width, height, repaintable, usePNG, renderEngineLocation);
    this.doubleBufferInit();
  }

  // Getter for base class property marked as 'private'.
  get volDataInfoArray(): Fovia.VolumeDataContext[] {
    const volumeDataInfoArray = (this as any).volumeDataInfoArray;
    if (volumeDataInfoArray != null) {
      return volumeDataInfoArray as Fovia.VolumeDataContext[];
    } else {
      return [];
    }
  }

  public getPendingRenderParams(): Fovia.RenderParams3D {
    const rp = this.getFusedRenderParams(0);
    if (rp == null) {
      return getPendingRenderParams3D(this as Fovia.UI.HTMLDoubleBufferViewport3D);
    }
    return rp;
  }

  public getFusedRenderParams(index: number): Fovia.RenderParams3D | null {
    const rps = getPendingRenderParamsFusion(this as Fovia.UI.HTMLFusionViewportMPR);
    if (Array.isArray(rps) && (rps as Array<Fovia.RenderParams3D>).length === 2 && index >= 0 && index < 2) {
      return (rps as Array<Fovia.RenderParams3D>)[index];
    } else {
      return null;
    }
  }
}
