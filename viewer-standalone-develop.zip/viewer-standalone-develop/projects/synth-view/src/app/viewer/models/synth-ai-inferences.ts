import { BreastLabelingInference } from "../utils";
import Fovia from "foviaapi";

export type BoundingBox = [number, number, number, number];

export class SynthAiInferences {
  private _boundingBoxMap: Map<string, BoundingBox>;

  constructor() {
    this._boundingBoxMap = new Map();
  }

  public setBoundingBoxes(inference: BreastLabelingInference) {
    Object.entries(inference).forEach(([uid, report]) => {
      if (report.breast_box.length === 4) {
        this._boundingBoxMap.set(uid, report.breast_box as BoundingBox);
      }
    });
  }

  public getBoundingBox(instanceUid: string) {
    return this._boundingBoxMap.get(instanceUid);
  }

  // The width and height need to be the original values, not the values after rotation
  public static transform(boundingBox: BoundingBox, rotation: Fovia.ImageRotation, flip: Fovia.ImageFlip, origWidth: number, origHeight: number): BoundingBox {
    let [x1, y1, x2, y2] = boundingBox;

    if (flip === Fovia.ImageFlip.flipHorizontal) {
      let origX1 = x1;
      x1 = origWidth - x2;
      x2 = origWidth - origX1;
      
      // Horizontal flipping inverts the order of rotation, so the 90 and 270 cases are swapped between flipped and non-flipped switches
      switch (rotation) {
        case Fovia.ImageRotation.rotate0: return boundingBox;
        case Fovia.ImageRotation.rotate90: return [y1, origWidth - x2, y2, origWidth - x1];
        case Fovia.ImageRotation.rotate180: return [origWidth - x2, origHeight - y2, origWidth - x1, origHeight - y1];
        case Fovia.ImageRotation.rotate270: return [origHeight - y2, x1, origHeight - y1, x2];
      }
    }
    
    switch (rotation) {
      case Fovia.ImageRotation.rotate0: return boundingBox;
      case Fovia.ImageRotation.rotate90: return [origHeight - y2, x1, origHeight - y1, x2];
      case Fovia.ImageRotation.rotate180: return [origWidth - x2, origHeight - y2, origWidth - x1, origHeight - y1];
      case Fovia.ImageRotation.rotate270: return [y1, origWidth - x2, y2, origWidth - x1];
    }
  }
}