import { BehaviorSubject, Subject } from 'rxjs';
import { TOOL_TYPE } from '../tools';
import { ContentType, LaunchArguments } from '@idgital/vision-interface';

import { HangingProtocol } from '@server-api';
import { VirtualSeries } from './virtual-series';
import { PresetEntry } from './preset-entry';
import { ViewerSettingsService } from '../services';
import { EdgeEnhancementLevel } from './edge-enhancement-level';
import { WLPropagateMode } from './window-level-propagation';
import { AlignedSeriesInfo } from './compare-mode-info';

export const DEFAULT_SHOW_ANNOTATIONS = true;
export const DEFAULT_SHOW_CADAI = false;

export const enum DICOM_OVERLAY_STYLE {
  SHOW_PARTIAL = 0,
  SHOW_FULL,
  HIDE_PARTIAL,  // Indicates user prefers partial, but currently toggled off
  HIDE_FULL,     // Indicates user prefers full, but currently toggled off
}

export const enum WINDOW_MODE {
  INDEPENDENT_SINGLE_DISPLAY,
  INDEPENDENT_DUAL_DISPLAY,
  EMBEDDED
}

export const enum IMAGE_SIZING {
  FIT_TO_VIEWPORT,
  FULL_RESOLUTION,
  AUTO_CROP,
}

export interface ITomoSwap {
  viewportId: string;
  series: VirtualSeries;
  preCineTool: TOOL_TYPE;
}

export class ViewerSettingsInfo {
  public activePanelId$$ = new BehaviorSubject<string>('');
  public activeToolType$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.ePage);
  public toolToggled$$ = new Subject<TOOL_TYPE>();
  public activeViewport$$ = new BehaviorSubject<string>('');
  public measureToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eMeasureLinear);
  public roiToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eROIPoint);
  public rotateToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eRotateCW90);
  public mirrorToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eFlipHorizontal);
  public annotateToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eAnnotateArrow);
  public pageToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.ePage);
  public cropToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eToggleCrop);
  public deleteToolGroupSelection$$ = new BehaviorSubject<TOOL_TYPE>(TOOL_TYPE.eDeleteSeries);

  public showDicomOverlay$$ = new BehaviorSubject<boolean>(true);
  public showUserAnnotations$$ = new BehaviorSubject<boolean>(DEFAULT_SHOW_ANNOTATIONS);
  public showRuler$$ = new BehaviorSubject<boolean>(true);
  public showLocalizerLines$$ = new BehaviorSubject<boolean>(true);
  public useToolbar$$ = new BehaviorSubject<boolean>(false);
  public showThumbnails$$ = new BehaviorSubject<boolean>(true);
  public showFlicker$$ = new BehaviorSubject<boolean>(false);
  public showCadAI$$ = new BehaviorSubject<boolean>(DEFAULT_SHOW_CADAI);
  public toggleKeyImage$$ = new Subject<boolean>();
  public showNextComparisonExam$$ = new Subject<boolean>();
  public usingPowerWheel$$ = new BehaviorSubject<boolean>(false);
  public swapAdjacent$$ = new Subject<boolean>;
  public reverseSeries$$ = new Subject<boolean>;
  public enableUserCalibrationTool$$ = new BehaviorSubject<boolean>(false);

  public imageSizing$$ = new BehaviorSubject<IMAGE_SIZING>(IMAGE_SIZING.FIT_TO_VIEWPORT);
  public showToolbox$$ = new Subject<boolean>();
  public showVisionMenu$$ = new Subject<string>();
  public showDicomTags$$ = new Subject<boolean>();
  public showHangingProtocol$$ = new Subject<boolean>();
  public dicomOverlayOption$$ = new BehaviorSubject<DICOM_OVERLAY_STYLE>(DICOM_OVERLAY_STYLE.SHOW_FULL);
  public windowMode$$: BehaviorSubject<WINDOW_MODE>;
  public mammoTomoSwap$$ = new Subject<ITomoSwap>();
  public toggleTomoHotkey$$ = new Subject<string>();
  public applyPresetFavorite$$ = new Subject<number>();
  public resetWL$$ = new Subject<boolean>();

  public primaryHangingProtocol$$ = new BehaviorSubject<HangingProtocol>(new HangingProtocol());
  public comparisonHangingProtocol$$ = new BehaviorSubject<HangingProtocol>(new HangingProtocol());

  public isMammoPresentationModeActive$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  public showCompareModeViewPorts$$ = new Subject<AlignedSeriesInfo[]>();

  public readonly launchSpanCount: number;
  public readonly launchWindowX: number;
  public readonly launchWindowY: number;
  public readonly launchWindowSizeX: number;
  public readonly launchWindowSizeY: number;
  public readonly launchEmbedded: boolean;
  public readonly launchFullscreen: boolean;
  public readonly launchContentType: ContentType;
  public edgeEnhancementLevelFavorites: EdgeEnhancementLevel | null = null;
  public mrWlPropagateModeFavorites: WLPropagateMode | null = null;
  public xrayWlPropagateModeFavorites: WLPropagateMode | null = null;
  public wlPresetFavorites: PresetEntry[] = [];
  public colorPalettePresetFavorites: string[] = [];

  constructor() {
    let launchArgs: LaunchArguments;

    if (document !== undefined && document.URL) {
      const url = new URL(document.URL);
      launchArgs = LaunchArguments.from(url);
    } else {
      launchArgs = LaunchArguments.default();
    }

    this.launchSpanCount = launchArgs.spanCount;
    this.launchWindowX = launchArgs.windowX;
    this.launchWindowY = launchArgs.windowY;
    this.launchWindowSizeX = launchArgs.windowSizeX;
    this.launchWindowSizeY = launchArgs.windowSizeY;
    this.launchEmbedded = launchArgs.embedded;
    this.launchFullscreen = launchArgs.fullscreen;
    this.launchContentType = launchArgs.contentType;

    // console.log(`ViewerSettings @${launchArgs.windowX},${launchArgs.windowY} w=${launchArgs.windowSizeX}xh=${launchArgs.windowSizeY}`);

    if (launchArgs.embedded) {
      this.windowMode$$ = new BehaviorSubject<WINDOW_MODE>(WINDOW_MODE.EMBEDDED);
    } else {
      if (launchArgs.spanCount > 1) {
        this.windowMode$$ = new BehaviorSubject<WINDOW_MODE>(WINDOW_MODE.INDEPENDENT_DUAL_DISPLAY);
      } else {
        this.windowMode$$ = new BehaviorSubject<WINDOW_MODE>(WINDOW_MODE.INDEPENDENT_SINGLE_DISPLAY);
      }
    }
  }

  get windowMode(): WINDOW_MODE {
    return this.windowMode$$.getValue();
  }
}
