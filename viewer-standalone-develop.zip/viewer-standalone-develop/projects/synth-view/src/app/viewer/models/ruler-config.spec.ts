import { RulerConfig } from './ruler-config';

describe('RulerConfig', () => {
  it('should create an instance', () => {
    expect(new RulerConfig(1,1,'')).toBeTruthy();
  });
});
