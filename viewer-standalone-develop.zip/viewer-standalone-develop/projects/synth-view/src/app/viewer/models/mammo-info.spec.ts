import { MammoInfo } from './mammo-info';

describe('MammoInfo', () => {
  it('should create an instance', () => {
    const tags: any = 0;
    const uid: string = '1.2.3';
    expect(new MammoInfo(tags, uid)).toBeTruthy();
  });
});
