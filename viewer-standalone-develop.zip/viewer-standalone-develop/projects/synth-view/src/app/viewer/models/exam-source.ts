import {
  ExamInformation
} from '@server-api';

/**
 * Information about an exam. ExamSource is initialized from ExamInformation
 *
 * Fields
 * ------
 * - `sessionId`: The ExamGroupId identifying the current exam group
 * - `examType`: A string identifying the type of the exam, for example `'CT'`.
 * - `datasource`: Information about the data source where the exam images and other data are located.
 * - `instanceId`: The unique identifier for the exam, for example the DICOM Study Instance UID.
 */
export class ExamSource {
  readonly dataSourceURL: string;
  readonly instanceId: string;

  constructor(examInformation: ExamInformation) {
    this.instanceId = examInformation.studyUID;
    this.dataSourceURL = examInformation.dataSourceURL;
  }
}


// Essentially the same as ILoadStudyResults but seriesList is never null and unneeded items are removed.
export interface ILoadedStudyResults {
  studyInstanceUID: string;
  seriesList: Fovia.ScanDirSeriesResults[];
  nonImageSeriesList: Fovia.ScanDirSeriesResults[] | null;
  nonImageDicomTags: any[] | null;
}
