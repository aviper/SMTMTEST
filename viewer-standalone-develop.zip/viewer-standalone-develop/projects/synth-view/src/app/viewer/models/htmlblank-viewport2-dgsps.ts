import { HTMLDoubleBufferViewport2DGSPS } from './htmldouble-buffer-viewport2-dgsps';

export class HTMLBlankViewport2DGSP extends HTMLDoubleBufferViewport2DGSPS {
  constructor(htmlElementName: string, width: number, height: number) {
    super(htmlElementName, width, height);
  }

  public override init(seriesDataContext: Fovia.SeriesDataContext, onDrawCallback?: Function, imageMetaDataReceived?: any, enableImageLevelRP?: boolean, callbackFunc?: Function): Promise<any> {
    console.error('HTMLBlankViewport2DGSP cannot be init()');
    return new Promise((resolve, reject) => {
      reject();
    });
  }

  public override isBlankViewport(): boolean {
    return true;
  }
}
