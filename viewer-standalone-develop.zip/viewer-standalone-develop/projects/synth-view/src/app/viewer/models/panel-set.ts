import { BehaviorSubject, Observable } from 'rxjs';
import dayjs from 'dayjs';
export enum PANEL_TYPE {
  ePrimary2DPanel = 0,
  ePrimaryMPRPanel,
  ePrimaryKOPanel,
  ePrimaryFusionPanel,
  ePrior2DPanel,
  ePriorMPRPanel,
  ePriorKOPanel,
  ePriorFusionPanel,
  eNoPanel,
  eEmptyPanel,
  ePrimaryCompareModePanel,
  ePriorCompareModePanel
}

export function panelTypeToPanelSet(panelType: PANEL_TYPE): PANEL_SET {
  return PrimaryPanelSetTypes.indexOf(panelType) > -1 ? PANEL_SET.ePrimaryPanelSet : PriorPanelSetTypes.indexOf(panelType) > -1 ? PANEL_SET.ePriorPanelSet : PANEL_SET.eEmptyPanelSet;
}
export function panelTypeIsKO(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePrimaryKOPanel || panelType === PANEL_TYPE.ePriorKOPanel;
}
export function panelTypeIs2D(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePrimary2DPanel || panelType === PANEL_TYPE.ePrior2DPanel || panelType === PANEL_TYPE.eEmptyPanel;
}
export function panelTypeIsMPR(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePrimaryMPRPanel || panelType === PANEL_TYPE.ePriorMPRPanel;
}

export function panelTypeIsFusion(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePrimaryFusionPanel || panelType === PANEL_TYPE.ePriorFusionPanel;
}
export function panelTypeIsPrimaryCompareMode(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePrimaryCompareModePanel;
}
export function panelTypeIsPriorCompareMode(panelType: PANEL_TYPE): boolean {
  return panelType === PANEL_TYPE.ePriorCompareModePanel;
}

// Panels are grouped by Primary-related panels and Prior related panels. When there are more than one panel available
// for a group, then they appear as stacked panels in the UI.
// Pressing the MPR/3D button, creates a new panel, of the appropriate type which is specific to primary or prior.
// Creating a Primary KO, creates a new KO panel for Primary.
// Detecting a Prior KO during load, creates a KO panel, populated by the KO content
// We don't anticipate allowing the user to "create" a new KO panel for a Prior .
// There may be more than one panel type in any given panel set.
//
// For the most part, the panels in a set are associated with a particular exam.

export enum PANEL_SET { eUnknown = -1, ePrimaryPanelSet = 0, ePriorPanelSet = 1, eEmptyPanelSet = 2 }
const PrimaryPanelSetTypes = [PANEL_TYPE.ePrimary2DPanel, PANEL_TYPE.ePrimaryMPRPanel, PANEL_TYPE.ePrimaryKOPanel, PANEL_TYPE.ePrimaryFusionPanel, PANEL_TYPE.ePrimaryCompareModePanel];
const PriorPanelSetTypes = [PANEL_TYPE.ePrior2DPanel, PANEL_TYPE.ePriorMPRPanel, PANEL_TYPE.ePriorKOPanel, PANEL_TYPE.ePriorFusionPanel, PANEL_TYPE.ePriorCompareModePanel];
const EmptyPanelSetTypes = [PANEL_TYPE.eEmptyPanel];

// 2D - 'Current' vs. 'Images '+ study date
// KO - Key Images
const PanelSetTitles: string[][] = [
  ['Current', 'MPR', 'Key Images', 'Fusion'],
  ['Images ', 'MPR', 'Key Images', 'Fusion'],
  ['Empty'],
  ['Compare Mode']
];

export class PanelInfo {
  private panelTitle$$: BehaviorSubject<string>;
  private bAllowViewportDrop = true;
  private _studyDate = '';

  constructor(public readonly id: string, readonly paneltitle: string, public readonly panelType: PANEL_TYPE, public readonly panelSet: PANEL_SET) {
    this.panelTitle$$ = new BehaviorSubject<string>(paneltitle);
    this.bAllowViewportDrop = !(this.isMPR);
  }

  public get is2D(): boolean {
    return panelTypeIs2D(this.panelType);
  }

  public get isMPR(): boolean {
    return panelTypeIsMPR(this.panelType);
  }

  public get isFusion(): boolean {
    return panelTypeIsFusion(this.panelType);
  }

  public get isKeyObject(): boolean {
    return panelTypeIsKO(this.panelType);
  }

  public get isPriorCompareMode(): boolean {
    return panelTypeIsPriorCompareMode(this.panelType);
  }
  public get isPrimaryCompareMode(): boolean {
    return panelTypeIsPrimaryCompareMode(this.panelType);
  }

  public get isPrimary(): boolean {
    return PrimaryPanelSetTypes.indexOf(this.panelType) > -1;
  }

  public get isPrior(): boolean {
    return PriorPanelSetTypes.indexOf(this.panelType) > -1;
  }

  public get hasResetButton(): boolean {
    return this.isFusion;
  }

  public get hasPlanesDropdown(): boolean {
    return this.isFusion;
  }

  public get hasSeriesLabel(): boolean {
    return !this.isFusion;
  }

  public get canChangeLayout(): boolean {
    return this.is2D || this.isKeyObject || this.isPrimaryCompareMode;
  }

  public get canOneUp(): boolean {
    return !this.isFusion;
  }

  public addTitleStudyDate(studyDate: string): void {
    this._studyDate = studyDate;
    if (studyDate === '') {
      return;
    }
    const date: string = dayjs(studyDate, 'YYYYMMDD').format(' DD/MMM/YYYY');
    const newTitle = this.panelTitle$$.value + date;
    this.panelTitle$$.next(newTitle);
  }

  public get panelTitle$(): Observable<string> {
    return this.panelTitle$$.asObservable();
  }

  public get allowViewportDrop(): boolean {
    return this.bAllowViewportDrop;
  }

  public get studyDate(): string {
    return this._studyDate !== '' ? dayjs(this._studyDate, 'YYYYMMDD').format(' DD MMM YYYY') : '';
  }

  public toString(): string {
    return `id: ${this.id} '${this.paneltitle}' ${PANEL_TYPE[this.panelType]} ${PANEL_SET[this.panelSet]}`;
  }
}

export function getPriorPanelInfo(panelId: string, panelType: PANEL_TYPE, studyDate: string = ''): PanelInfo {
  const index = PriorPanelSetTypes.indexOf(panelType);
  const panelInfo = new PanelInfo(panelId, PanelSetTitles[PANEL_SET.ePriorPanelSet][index], panelType, PANEL_SET.ePriorPanelSet);
  panelInfo.addTitleStudyDate(studyDate);
  return panelInfo;
}
export function getPrimaryPanelInfo(panelId: string, panelType: PANEL_TYPE): PanelInfo {
  const index = PrimaryPanelSetTypes.indexOf(panelType);
  // We don't decorate the tabs for Primary study with study date info. It's conceivable a user
  // might have more than 1 MPR/3D Panel, we may want to decorate those for clarity. We'll see.
  return new PanelInfo(panelId, PanelSetTitles[PANEL_SET.ePrimaryPanelSet][index], panelType, PANEL_SET.ePrimaryPanelSet);
}
export function getEmptyPanelInfo(panelId: string, panelType: PANEL_TYPE): PanelInfo {
  const index = EmptyPanelSetTypes.indexOf(panelType);
  return new PanelInfo(panelId, PanelSetTitles[PANEL_SET.eEmptyPanelSet][index], panelType, PANEL_SET.eEmptyPanelSet);
}
