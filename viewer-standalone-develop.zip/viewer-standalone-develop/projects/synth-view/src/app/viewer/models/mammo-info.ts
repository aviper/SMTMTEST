import { IMAGE_DISPLAY_ALIGNMENT } from './utility-classes';
import { DICOM_TAGS, getTagValueAsString, SOP_CLASS } from '@server-api';

export enum IMAGE_LATERALITY { UNKNOWN = -1, LEFT, RIGHT }
export enum MAMMO_IMAGE_TYPE { UNKNOWN = -1, PRIMARY, GENERATED }
export enum MAMMO_VIEW_TYPE {
  UNKNOWN = -1,
  RCC,
  LCC,
  RMLO,
  LMLO,
  RCC_TOMO,
  LCC_TOMO,
  RMLO_TOMO,
  LMLO_TOMO
}

// Potentially will sort by these values. Please don't rearrange them.
export enum IMAGE_VIEW_POSITION {
  UNKNOWN = -1,
  CC,
  CCFB,
  XCCL,
  XCCM,
  MLO,
  LMO,
  ML,
  LM,
  SIO,
  ISO,
}
// Potentially will sort by these values. Please don't rearrange them.
export enum IMAGE_VIEW_POSITION_MODIFIER {
  UNKNOWN = -1,
  NONE,
  IMPLANT_DISPLACED,
  CLEAVAGE,
  AXILLARY_TAIL,
  ROLLED_LATERAL,
  ROLLED_MEDIAL,
  ROLLED_INFERIOR,
  ROLLED_SUPERIOR,
  MAGNIFICATION,
  SPOT_COMPRESSION,
  TANGENTIAL,
  NIPPLE_IN_PROFILE,
  ANTERIOR_COMPRESSION,
  INFRA_MAMMARY_FOLD,
  AXILLARY_TISSUE
}

export class MammoInfo {
  private _laterality: IMAGE_LATERALITY = IMAGE_LATERALITY.UNKNOWN;
  private _viewPosition: IMAGE_VIEW_POSITION = IMAGE_VIEW_POSITION.UNKNOWN;
  private _viewPosModifier: IMAGE_VIEW_POSITION_MODIFIER = IMAGE_VIEW_POSITION_MODIFIER.UNKNOWN;
  private _patientOrientation: string[] = [];
  private _tomosynthesis = false;
  private _viewType: MAMMO_VIEW_TYPE = MAMMO_VIEW_TYPE.UNKNOWN;
  private _flipHorizontal = false;
  private _rotate180 = false;
  private _imageAlignment = IMAGE_DISPLAY_ALIGNMENT.none;
  private _frameCount = 0;
  private _breastScaleText: string[] = ['x', 'x'];
  private _acquisitionTime = 0;
  private _imageType = MAMMO_IMAGE_TYPE.UNKNOWN;
  private _institutionAddress = '';
  private _stationName = '';
  private _cassetteId = '';
  private _operatorsName = '';

  constructor(tags: any, instanceUID: string) {
    if (tags != null) {
      let sequenceItem: any | null = null;
      let subSequenceItem: any | null = null;
      let tagValue: string | null = getTagValueAsString(tags, DICOM_TAGS.SOP_CLASS_UID);
      if (tagValue === null) {
        console.error(`Unable to parse SOP Class UID tag for image ${instanceUID}`);
        return;
      }
      tagValue = tagValue.toUpperCase();
      this._tomosynthesis = tagValue === SOP_CLASS.TOMO;

      // Get the acquisition time.
      tagValue = getTagValueAsString(tags, DICOM_TAGS.ACQUISITION_TIME);
      if (tagValue) {
        this._acquisitionTime = Number(tagValue);
      }

      // Get the image type (primary or generated).
      tagValue = getTagValueAsString(tags, DICOM_TAGS.IMAGE_TYPE);
      if (tagValue) {
        this._imageType = tagValue.toUpperCase().includes('GENERATED') ? MAMMO_IMAGE_TYPE.GENERATED : MAMMO_IMAGE_TYPE.PRIMARY;
      }

      // This group of tags is included on the DICOM overlay for mammo images.
      // The tags may be found at the root or in the CONTRIBUTING_EQUIPMENT_SEQUENCE.
      tagValue = getTagValueAsString(tags, DICOM_TAGS.INSTITUTION_ADDRESS);
      if (tagValue) {
        this._institutionAddress = tagValue;
      }

      tagValue = getTagValueAsString(tags, DICOM_TAGS.STATION_NAME);
      if (tagValue) {
        this._stationName = tagValue;
      }

      tagValue = getTagValueAsString(tags, DICOM_TAGS.CASSETTE_ID);
      if (tagValue) {
        this._cassetteId = tagValue;
      }

      tagValue = getTagValueAsString(tags, DICOM_TAGS.OPERATORS_NAME);
      if (tagValue) {
        this._operatorsName = tagValue;
      }

      // This group of tags is included on the DICOM overlay for mammo images.
      // The tags may be found at the root or in the CONTRIBUTING_EQUIPMENT_SEQUENCE.
      // Look in that sequence even if we found the tags at the root.
      tagValue = null;
      sequenceItem = tags[DICOM_TAGS.CONTRIBUTING_EQUIPMENT_SEQUENCE] ? tags[DICOM_TAGS.CONTRIBUTING_EQUIPMENT_SEQUENCE]['Value'] : null;
      if (sequenceItem) {
        tagValue = getTagValueAsString(sequenceItem[0], DICOM_TAGS.INSTITUTION_ADDRESS);
        if (tagValue) {
          this._institutionAddress = tagValue;
        }

        tagValue = getTagValueAsString(sequenceItem[0], DICOM_TAGS.STATION_NAME);
        if (tagValue) {
          this._stationName = tagValue;
        }

        tagValue = getTagValueAsString(sequenceItem[0], DICOM_TAGS.CASSETTE_ID);
        if (tagValue) {
          this._cassetteId = tagValue;
        }

        tagValue = getTagValueAsString(sequenceItem[0], DICOM_TAGS.OPERATORS_NAME);
        if (tagValue) {
          this._operatorsName = tagValue;
        }
      }

      // Get the view position.
      tagValue = null;
      sequenceItem = tags[DICOM_TAGS.VIEW_CODE_SEQUENCE] ? tags[DICOM_TAGS.VIEW_CODE_SEQUENCE]['Value'] : null;
      if (sequenceItem) {
        tagValue = getTagValueAsString(sequenceItem[0], DICOM_TAGS.CODE_VALUE);
      }
      if (tagValue == null) { // Value not found in sequence, or no sequence
        tagValue = getTagValueAsString(tags, DICOM_TAGS.VIEW_POSITION, true);
      }
      if (tagValue) {
        if (tagValue === 'R-1024A' || tagValue === 'Y-X1770' || tagValue.includes('XCCL')) {
          this._viewPosition = IMAGE_VIEW_POSITION.XCCL;
        } else if (tagValue === 'R-1024B' || tagValue === 'Y-X1771' || tagValue.includes('XCCM')) {
          this._viewPosition = IMAGE_VIEW_POSITION.XCCM;
        } else if (tagValue === 'R-10244' || tagValue.includes('FB')) {
          this._viewPosition = IMAGE_VIEW_POSITION.CCFB;
        } else if (tagValue === 'R-102D0' || tagValue.includes('SIO')) {
          this._viewPosition = IMAGE_VIEW_POSITION.SIO;
        } else if (tagValue === 'R-40AAA' || tagValue.includes('ISO')) {
          this._viewPosition = IMAGE_VIEW_POSITION.ISO;
        } else if (tagValue === 'R-10226' || tagValue.includes('MLO')) {
          this._viewPosition = IMAGE_VIEW_POSITION.MLO;
        } else if (tagValue === 'R-10230' || tagValue.includes('LMO')) {
          this._viewPosition = IMAGE_VIEW_POSITION.LMO;
        } else if (tagValue === 'R-10224' || tagValue.includes('ML')) {
          this._viewPosition = IMAGE_VIEW_POSITION.ML;
        } else if (tagValue === 'R-10228' || tagValue.includes('LM')) {
          this._viewPosition = IMAGE_VIEW_POSITION.LM;
        } else if (tagValue === 'R-10242' || tagValue.includes('CC')) {
          this._viewPosition = IMAGE_VIEW_POSITION.CC;
        }
      }

      // Get any view position modifier.
      if (sequenceItem) {
        subSequenceItem = sequenceItem[0] ? sequenceItem[0][DICOM_TAGS.VIEW_MODIFIER_CODE_SEQUENCE] : null;
        if (subSequenceItem && subSequenceItem['Value']) {
          tagValue = getTagValueAsString(subSequenceItem['Value'][0], DICOM_TAGS.CODE_VALUE, true);
          if (tagValue) {
            switch (tagValue) {
              case 'R-102D2':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.CLEAVAGE;
                break;
              case 'R-102D1':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.AXILLARY_TAIL;
                break;
              case 'R-102D3':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.ROLLED_LATERAL;
                break;
              case 'R-102D4':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.ROLLED_MEDIAL;
                break;
              case 'R-102CA':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.ROLLED_INFERIOR;
                break;
              case 'R-102C9':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.ROLLED_SUPERIOR;
                break;
              case 'R-102D5':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.IMPLANT_DISPLACED;
                break;
              case 'R-102D6':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.MAGNIFICATION;
                break;
              case 'R-102D7':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.SPOT_COMPRESSION;
                break;
              case 'R-102C2':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.TANGENTIAL;
                break;
              case 'R-40AB3':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.NIPPLE_IN_PROFILE;
                break;
              case 'P2-00161':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.ANTERIOR_COMPRESSION;
                break;
              case 'R-40ABE':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.INFRA_MAMMARY_FOLD;
                break;
              case 'R-40AB2':
                this._viewPosModifier = IMAGE_VIEW_POSITION_MODIFIER.AXILLARY_TISSUE;
                break;
            }
          }
        }
      }
      // Get orientation as an array of two strings.
      tagValue = getTagValueAsString(tags, DICOM_TAGS.PATIENT_ORIENTATION, true);
      if (tagValue) {
        this._patientOrientation = tagValue.split('\\');
      }

      // Get laterality. Consider cleavage as Right.
      tagValue = null;
      sequenceItem = tags[DICOM_TAGS.SHARED_FUNCTIONAL_GROUPS_SEQUENCE] ? tags[DICOM_TAGS.SHARED_FUNCTIONAL_GROUPS_SEQUENCE]['Value'] : null;
      if (sequenceItem) {
        subSequenceItem = sequenceItem[0] ? sequenceItem[0][DICOM_TAGS.FRAME_ANATOMY_SEQUENCE] : null;
        if (subSequenceItem) {
          tagValue = getTagValueAsString(subSequenceItem['Value'][0], DICOM_TAGS.FRAME_LATERALITY, true);
        }

        subSequenceItem = sequenceItem[0] ? sequenceItem[0][DICOM_TAGS.FRAME_ANATOMY_SEQUENCE] : null;
        if (subSequenceItem) {
          tagValue = getTagValueAsString(subSequenceItem['Value'][0], DICOM_TAGS.FRAME_LATERALITY, true);
        }
      }
      if (tagValue === null) {
        tagValue = getTagValueAsString(tags, DICOM_TAGS.IMAGE_LATERALITY, true);
      }
      if (tagValue) {
        if (tagValue.includes('R') || tagValue.includes('B')) {
          this._laterality = IMAGE_LATERALITY.RIGHT;
        } else if (tagValue.includes('L')) {
          this._laterality = IMAGE_LATERALITY.LEFT;
        }
      }

      // Get the delta in Image Position (Patient) from the first to last frame.
      tagValue = getTagValueAsString(tags, DICOM_TAGS.NUMBER_OF_FRAMES);
      if (tagValue) {
        this._frameCount = Number(tagValue);
      }

      if (this._tomosynthesis && this._frameCount > 0) {
        let first = true;
        const firstFramePos: number[] = [0, 0, 0];
        const frameDelta: number[] = [0, 0, 0];
        let position: string[] = ['', '', ''];

        for (let i = 0; i < this._frameCount; i++) {
          sequenceItem = tags[DICOM_TAGS.PER_FRAME_FUNCTIONAL_GROUPS_SEQUENCE] ? tags[DICOM_TAGS.PER_FRAME_FUNCTIONAL_GROUPS_SEQUENCE]['Value'] : null;
          if (sequenceItem) {
            subSequenceItem = sequenceItem[i] ? sequenceItem[i][DICOM_TAGS.PLANE_POSITION_SEQUENCE] : null;
            if (subSequenceItem) {
              tagValue = getTagValueAsString(subSequenceItem['Value'][0], DICOM_TAGS.IMAGE_POSITION_PATIENT, true);
              if (tagValue) {
                position = tagValue.split('\\');

                if (position.length === 3) {
                  if (first) {
                    first = false;
                    firstFramePos[0] = Number(position[0]);
                    firstFramePos[1] = Number(position[1]);
                    firstFramePos[2] = Number(position[2]);
                  }
                  else {
                    frameDelta[0] = Number(position[0]) - firstFramePos[0];
                    frameDelta[1] = Number(position[1]) - firstFramePos[1];
                    frameDelta[2] = Number(position[2]) - firstFramePos[2];
                  }
                }
              }
            }
          }
        }
        // CC images should change primarily along the z-axis.
        // MLO etc. should change primarily along the x-axis.
        if (this._viewPosition === IMAGE_VIEW_POSITION.CC || this._viewPosition === IMAGE_VIEW_POSITION.CCFB
          || this._viewPosition === IMAGE_VIEW_POSITION.XCCL || this._viewPosition === IMAGE_VIEW_POSITION.XCCM)
        {
          if (frameDelta[2] !== 0.0) {
            this._breastScaleText = frameDelta[2] > 0.0 ? ['I', 'S'] : ['S', 'I'];
          }
        }
        else if (this._viewPosition === IMAGE_VIEW_POSITION.MLO || this._viewPosition === IMAGE_VIEW_POSITION.ML
          || this._viewPosition === IMAGE_VIEW_POSITION.LMO || this._viewPosition === IMAGE_VIEW_POSITION.LM
          || this._viewPosition === IMAGE_VIEW_POSITION.SIO || this._viewPosition === IMAGE_VIEW_POSITION.ISO)
        {
          if (frameDelta[0] !== 0.0) {
            if (this._laterality === IMAGE_LATERALITY.LEFT) {
              this._breastScaleText = frameDelta[0] > 0.0 ? ['M', 'L'] : ['L', 'M'];
            } else {
              this._breastScaleText = frameDelta[0] > 0.0 ? ['L', 'M'] : ['M', 'L'];
            }
          }
        }
      }
    }
    this.determineViewType();
    this.determineRotateFlip();
    this.determineAlignment();
  }

  public get isValid(): boolean {
    return this._viewType !== MAMMO_VIEW_TYPE.UNKNOWN;
  }

  public get imageType(): MAMMO_IMAGE_TYPE {
    return this._imageType;
  }

  get isSynthetic(): boolean {
    return this._imageType === MAMMO_IMAGE_TYPE.GENERATED;
  }

  public get laterality(): IMAGE_LATERALITY {
    return this._laterality;
  }
  public get viewPosition(): IMAGE_VIEW_POSITION {
    return this._viewPosition;
  }
  public get viewPosModifier(): IMAGE_VIEW_POSITION_MODIFIER {
    return this._viewPosModifier;
  }
  public get patientOrientation(): string[] {
    return this._patientOrientation;
  }
  public get tomosynthesis(): boolean {
    return this._tomosynthesis;
  }
  public get viewType(): MAMMO_VIEW_TYPE {
    return this._viewType;
  }
  public get rotate180(): boolean {
    return this._rotate180;
  }
  public get flipHorizontal(): boolean {
    return this._flipHorizontal;
  }
  public get imageAlignment(): IMAGE_DISPLAY_ALIGNMENT {
    return this._imageAlignment;
  }
  public get frameCount(): number {
    return this._frameCount;
  }
  public get breastScaleText(): string[] {
    return this._breastScaleText;
  }
  public get acquisitionTime(): number {
    return this._acquisitionTime;
  }

  public get institutionAddress(): string {
    return this._institutionAddress;
  }

  public get stationName(): string {
    return this._stationName;
  }

  public get cassetteId(): string {
    return this._cassetteId;
  }

  public get operatorsName(): string {
    return this._operatorsName;
  }

  private determineViewType(): void {
    switch (this.viewPosition) {
      case IMAGE_VIEW_POSITION.CC:
      case IMAGE_VIEW_POSITION.CCFB:
      case IMAGE_VIEW_POSITION.XCCL:
      case IMAGE_VIEW_POSITION.XCCM:
        switch (this.laterality) {
          case IMAGE_LATERALITY.LEFT:
            this._viewType = this.tomosynthesis ? MAMMO_VIEW_TYPE.LCC_TOMO : MAMMO_VIEW_TYPE.LCC;
            break;
          case IMAGE_LATERALITY.RIGHT:
            this._viewType = this.tomosynthesis ? MAMMO_VIEW_TYPE.RCC_TOMO : MAMMO_VIEW_TYPE.RCC;
            break;
        }
        break;

      case IMAGE_VIEW_POSITION.LM:
      case IMAGE_VIEW_POSITION.LMO:
      case IMAGE_VIEW_POSITION.ML:
      case IMAGE_VIEW_POSITION.MLO:
      case IMAGE_VIEW_POSITION.ISO:
      case IMAGE_VIEW_POSITION.SIO:
        switch (this.laterality) {
          case IMAGE_LATERALITY.LEFT:
            this._viewType = this.tomosynthesis ? MAMMO_VIEW_TYPE.LMLO_TOMO : MAMMO_VIEW_TYPE.LMLO;
            break;
          case IMAGE_LATERALITY.RIGHT:
            this._viewType = this.tomosynthesis ? MAMMO_VIEW_TYPE.RMLO_TOMO : MAMMO_VIEW_TYPE.RMLO;
            break;
        }
        break;
    }
  }

  private determineRotateFlip(): void {
    if (this.patientOrientation == null || this.patientOrientation.length !== 2) {
      console.log('Missing or bad patient orientation for the image.');
      return;
    }
    //
    // We need to deal with rotated and mirrored views.
    // This logic does NOT handle all possibilities, but it does deal with
    // upside down and backwards.
    //
    //  RCC  -- P/L
    //  LCC  -- A/R
    //  RMLO -- P/F
    //  LMLO -- A/F
    //
    // XCCL, XCCM, and are the same as CC
    // ML is treated the same as MLO
    //
    // LM, LMO, CC(from below), SIO, and ISO aren't handled here
    //
    if (this.viewPosition === IMAGE_VIEW_POSITION.ML || this.viewPosition === IMAGE_VIEW_POSITION.MLO || this.viewPosition === IMAGE_VIEW_POSITION.LM) {
      if (this.laterality === IMAGE_LATERALITY.LEFT) {
        if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('H')) {
          this._rotate180 = true;
          this._flipHorizontal = true;
        }
        else if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('H')) {
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('F')) {
          this._flipHorizontal = true;
        }
      }
      else {
        // Right laterality
        if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('H')) {
          this._flipHorizontal = true;
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('H')) {
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('F')) {
          this._flipHorizontal = true;
        }
      }
    }
    else if (this.viewPosition === IMAGE_VIEW_POSITION.CC || this.viewPosition === IMAGE_VIEW_POSITION.XCCL || this.viewPosition === IMAGE_VIEW_POSITION.XCCM) {
      if (this.laterality === IMAGE_LATERALITY.LEFT) {
        if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('L')) {
          this._flipHorizontal = true;
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('L')) {
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('R')) {
          this._flipHorizontal = true;
        }
      }
      else // Right laterality
      {
        if (this.patientOrientation[0].includes('P') && this.patientOrientation[1].includes('R')) {
          this._flipHorizontal = true;
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('R')) {
          this._rotate180 = true;
        }
        else if (this.patientOrientation[0].includes('A') && this.patientOrientation[1].includes('L')) {
          this._flipHorizontal = true;
        }
      }
    }
  }
  private determineAlignment(): void {
    switch (this.laterality) {
      case IMAGE_LATERALITY.LEFT:
        this._imageAlignment = IMAGE_DISPLAY_ALIGNMENT.left;
        break;
      case IMAGE_LATERALITY.RIGHT:
        this._imageAlignment = IMAGE_DISPLAY_ALIGNMENT.right;
        break;
      default:
        this._imageAlignment = IMAGE_DISPLAY_ALIGNMENT.none;
    }
  }
}
