import { LocalizerLines } from './localizer-lines';

describe('LocalizerLines', () => {
  it('should create an instance', () => {
    expect(new LocalizerLines()).toBeTruthy();
  });
});
