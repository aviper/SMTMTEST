

export const enum BUTTON_SCOPE {
  eNone = 0,
  e2D,      // 2D (excludes MPR)
  eMPR,     // MPR Only
  eMPR_3D,  // MPR & 3D Volume
  e3D,      // 3D Volume only
  eAll,     // All viewports
  eFused,   // Fused viewport
}
