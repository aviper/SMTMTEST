import { FlickerExamInfo } from './flicker-exam-info';
import { ExamSeries } from './exam-series';
describe('FlickerExamInfo', () => {
  it('should create an instance', () => {
    const dicomTagsMap = new Map<string, any>();
    const origSeries: ExamSeries[] = [];
    expect(new FlickerExamInfo(dicomTagsMap, origSeries)).toBeTruthy();
  });
});
