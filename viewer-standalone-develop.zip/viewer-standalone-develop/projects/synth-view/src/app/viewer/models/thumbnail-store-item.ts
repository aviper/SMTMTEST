import { AdaptorsService,
  FoviaService,
  MemoryCacheService,
  ToolService,
  ViewportPauseService,
  VirtualSeriesRenderManager
} from '../services';
import { VirtualSeries } from './virtual-series';
import { HTMLDoubleBufferViewport2DGSPS } from './htmldouble-buffer-viewport2-dgsps';
import { calcMiddleImageRefIndex } from '../utils';
import { ExamSeries } from './exam-series';
import { BehaviorSubject, Observable } from 'rxjs';
import { ThumbnailStoreService } from '../stores';

export class ThumbnailStoreItem {
  private isCurrentImageDeleted$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private isSeriesDeleted$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  public seriesCurrentlyDisplayed = false;
  public renderManager: VirtualSeriesRenderManager;
  public foviaHtmlViewport: HTMLDoubleBufferViewport2DGSPS | null = null;
  public thumbnailVirtualSeries: VirtualSeries;  // this is used for rendering the thumbnail images
  public isCurrentImageDeleted$: Observable<boolean> = this.isCurrentImageDeleted$$;
  public isSeriesDeleted$: Observable<boolean> = this.isSeriesDeleted$$;

  constructor(public id: string,
              public sourceVirtualSeries: VirtualSeries,
              protected foviaService: FoviaService,
              public viewportPauseService: ViewportPauseService,
              public memoryCacheService: MemoryCacheService,
              private thumbnailStoreService: ThumbnailStoreService,
              public isCompareMode: boolean) {

    this.thumbnailVirtualSeries = this.sourceVirtualSeries.duplicate();
    this.updateKeyObject();

    this.renderManager = new VirtualSeriesRenderManager(
      foviaService, viewportPauseService, memoryCacheService, this.thumbnailVirtualSeries,
      this.onFoviaViewportChanged.bind(this),
      this.onDrawCallback.bind(this),
      this.onImageMetaDataReceived.bind(this),
      null,
      this.onIsCurrentImageDeleted.bind(this),
      true
    );
    this.renderManager.fullResolution = false;
  }

  protected onDrawCallback(foviaHTMLViewport: Fovia.UI.HTMLViewport,
                           canvas: HTMLCanvasElement,
                           width: number,
                           height: number, onDrawCallbackComplete: () => void): void {
    onDrawCallbackComplete();
    this.renderCompleted();
  }

  public onImageMetaDataReceived(data: any): void {
  }

  public onFoviaViewportChanged(vp: HTMLDoubleBufferViewport2DGSPS): void {
    this.foviaHtmlViewport = vp;
  }

  public onIsCurrentImageDeleted(isDeleted: boolean): void {
    this.isCurrentImageDeleted$$.next(isDeleted);
  }

  public onSeriesDeleted(isDeleted: boolean): void {
    this.isSeriesDeleted$$.next(isDeleted);
  }

  public async releaseResources(): Promise<void> {
    await this.renderManager.releaseSessionResources();
  }

  public get examSeries(): ExamSeries | null {
    return this.thumbnailVirtualSeries.currentExamSeries;
  }

  public get volumeIsLoaded(): boolean {
    return this.examSeries?.volumeDataContext != null;
  }

  public async initFoviaViewport(toolService: ToolService, adaptorsService: AdaptorsService): Promise<void> {
    if (this.id == null) {
      console.warn(`initFoviaViewport: viewportId undefined`);
      return;
    }
    await this.renderManager.connect(this.id, toolService, adaptorsService);
  }

  public async disconnectFoviaViewport(): Promise<void> {
    await this.renderManager.disconnect(this.id);
  }

  public async initialRender(): Promise<void> {
    await this.viewportPauseService.waitUntilViewportNotBusy(this.id);
    await this.gotoImageAndRender(this.getInitialThumbnailImageRefIndex());
  }

  protected renderStarted(str: string = ''): void {
    if (this.viewportPauseService.isRendering(this.id)) {
      // console.warn(` renderStarted id: ${this.viewportId} - render already active - from ${str}`);
    }
    // console.warn(`RP-- renderStarted id:${this.viewportId} ${str} - renderStarted`);
    this.viewportPauseService.renderStarted(this.id);
  }

  protected renderCompleted(): void {
    // console.log(`RP-- id:${viewportId} - renderCompleted`);
    this.viewportPauseService.renderCompleted(this.id);
  }

  public async gotoToNextImageAndRender(forward: boolean): Promise<void> {

    // If rendering is paused or a render is active, skip advancing to the next image and rendering it.
    if (this.viewportPauseService.isPaused(this.id)) {
      console.warn(`gotoToNextImageAndRender: skipping render, is Paused for id ${this.id}`);
      return;
    }
    // If an image is in the middle of being rendered, skip advancing to the next image and rendering it.
    if (this.viewportPauseService.isRendering(this.id)) {
      // console.log(`gotoToNextImageAndRender: skipping render, isRendering already for id ${this.viewportId}`);
      return;
    }
    if (this.foviaHtmlViewport == null) {
      console.warn(`gotoToNextImageAndRender: fovia viewport undefined`);
      return;
    }

    if (this.thumbnailVirtualSeries.gotoNextImage(forward)) {
      await this.renderFoviaViewport();
      this.thumbnailStoreService.viewportScrolled(this.id);
    }
  }

  public async gotoImageAndRender(imageNumberIndex: number): Promise<boolean> {
    if (this.id == null) {
      console.warn(`gotoImageAndRender: viewportId undefined`);
      return false;
    }

    // If rendering is paused or a render is active, skip advancing to the next image and rendering it.
    if (this.viewportPauseService.isPaused(this.id)) {
      console.warn(`gotoImageAndRender: skipping render, is Paused for id ${this.id}`);
      return false;
    }
    // If an image is in the middle of being rendered, skip advancing to the next image and rendering it.
    if (this.viewportPauseService.isRendering(this.id)) {
      return false;
    }
    this.thumbnailVirtualSeries.currentImageRefIndex = imageNumberIndex;
    return await this.renderFoviaViewport();
  }

  public async renderFoviaViewport(): Promise<boolean> {
    if (this.foviaHtmlViewport == null) {
      console.warn('renderFoviaViewport: foviaHtmlViewport undefined');
      return false;
    }
    // If rendering is paused, just ignore the request (for now).
    // Currently, this pause happens when a viewport component is about to be torn down,
    // so no important render will be lost.
    if (this.viewportPauseService.isPaused(this.id)) {
      console.warn(`renderFoviaViewport: skipping render, is Paused for id ${this.id}}`);
      return false;
    }

    // if a render is already active, just ignore the request.  It's up to the caller
    // to manage render requests if the fovia viewport is busy.
    if (this.viewportPauseService.isRendering(this.id)) {
      console.warn(`renderFoviaViewport: skipping render, isRendering already for id ${this.id}`);
      return false;
    }

    await this.viewportPauseService.waitUntilViewportNotBusy(this.id);
    if (this.viewportPauseService.isPaused(this.id)) {
      console.warn(`renderFoviaViewport: viewport is paused for id ${this.id} `);
      return false;
    }
    if (this.foviaHtmlViewport == null) {
      console.warn(`renderFoviaViewport: foviaHtmlViewport undefined (2) for id ${this.id}`);
      return false;
    }
    this.renderStarted('renderFoviaViewport');
    const renderResult = await this.renderCurrentImage();
    if (!renderResult) {
      this.renderCompleted();
    }
    return true;
  }

  public updateKeyObject(): void {
    // For KO thumbnails we want the thumbnail to display the KO image.
    if (this.sourceVirtualSeries.koImageKey) {
      this.thumbnailVirtualSeries.koImageKey = this.sourceVirtualSeries.koImageKey;
      this.thumbnailVirtualSeries.currentImageRefIndex = this.sourceVirtualSeries.currentImageRefIndex;
    }
  }

  private async renderCurrentImage(): Promise<boolean> {
      // console.info(`renderCurrentImage: {${this.constructor.name} vp: ${this.id}, image#: ${this.thumbnailVirtualSeries.currentImageRefIndex} `);
      return await this.renderManager.renderCurrentImageRef();
  }

  private getInitialThumbnailImageRefIndex(): number {
    // For KO thumbnails we want the thumbnail to show the KO image in the series.
    if (this.thumbnailVirtualSeries.koImageKey) {
      return this.thumbnailVirtualSeries.currentImageRefIndex;
    }
    // Use similar logic as for finding the middle image in a non-virtual series
    return calcMiddleImageRefIndex(this.thumbnailVirtualSeries);
  }
}
