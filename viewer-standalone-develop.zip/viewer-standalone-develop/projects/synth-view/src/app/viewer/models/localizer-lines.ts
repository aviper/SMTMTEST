import Fovia from 'foviaapi';
import { SeriesDisplayStoreItem } from '../stores';

export interface ILocalizerInfo {
  sourceItem: SeriesDisplayStoreItem;
  destItem: SeriesDisplayStoreItem;
}

export function drawLocalizer(lineInfo: ILocalizerInfo, canvas: HTMLCanvasElement): void {
  const sourceViewport = lineInfo.sourceItem.foviaHtmlViewport;
  const destViewport = lineInfo.destItem.foviaHtmlViewport;
  const context: CanvasRenderingContext2D | null = canvas.getContext('2d');
  if (context && sourceViewport && destViewport && lineInfo.destItem.series) {
    const sdc = lineInfo.destItem.series.foviaSeriesDataContext;
    const mappedTopLeftCorner = sdc.mapPointFromFrameOfReference(sourceViewport.topLeftCorner, false);
    const mappedTopRightCorner = sdc.mapPointFromFrameOfReference(sourceViewport.topRightCorner, false);
    const mappedBotLeftCorner = sdc.mapPointFromFrameOfReference(sourceViewport.botLeftCorner, false);
    const mappedBotRightCorner = sdc.mapPointFromFrameOfReference(sourceViewport.botRightCorner, false);

    const points: Fovia.Util.Point[] = [];
    // Change image pixels to monitor pixels and position to location of image in viewport
    points.push(destViewport.getRenderEngine().dicomImagePixelToRenderImagePixel(mappedTopLeftCorner.imagePixel));
    points.push(destViewport.getRenderEngine().dicomImagePixelToRenderImagePixel(mappedTopRightCorner.imagePixel));
    points.push(destViewport.getRenderEngine().dicomImagePixelToRenderImagePixel(mappedBotRightCorner.imagePixel));
    points.push(destViewport.getRenderEngine().dicomImagePixelToRenderImagePixel(mappedBotLeftCorner.imagePixel));

    // Don't draw if the rectangle is ridiculous.
    context.lineWidth = 2;
    context.fillStyle = '#a8a8a8';
    context.strokeStyle = '#a8a8a8';
    context.shadowColor = '#a8a8a8';

    // Reduce the plane to two endpoints.
    orderPlanePoints(points);

    // We want to draw just a line rather than the "plane", so we'll draw the line through the middle of the
    // rectangle we calculated.
    context.beginPath();
    context.moveTo(points[0].x, points[0].y);
    context.lineTo(points[1].x, points[1].y);
    context.stroke();
  }
}

function orderPlanePoints(points: Fovia.Util.Point[]): void {
  const length1 = points[0].calculateDistance(points[1]);
  const length2 = points[1].calculateDistance(points[2]);

  if (length1 > length2) {
    // Segment 1 is longer. See which direction it goes.
    if (Math.abs(points[0].x - points[1].x) > Math.abs(points[0].y - points[1].y)) {
      points[0].y = (points[0].y + points[3].y) / 2;
      points[0].x = (points[0].x + points[3].x) / 2;
      points[1].y = (points[1].y + points[2].y) / 2;
      points[1].x = (points[1].x + points[2].x) / 2;
    } else {
      points[0].x = (points[0].x + points[3].x) / 2;
      points[0].y = (points[0].y + points[3].y) / 2;
      points[1].x = (points[1].x + points[2].x) / 2;
      points[1].y = (points[1].y + points[2].y) / 2;
    }
  } else {
    // Segment 2 is longer. See which direction it goes.
    if (Math.abs(points[1].x - points[2].x) > Math.abs(points[1].y - points[2].y)) {
      points[0].y = (points[0].y + points[1].y) / 2;
      points[0].x = (points[0].x + points[1].x) / 2;
      points[1].y = (points[2].y + points[3].y) / 2;
      points[1].x = (points[2].x + points[3].x) / 2;
    } else {
      points[0].x = (points[0].x + points[1].x) / 2;
      points[0].y = (points[0].y + points[1].y) / 2;
      points[1].x = (points[2].x + points[3].x) / 2;
      points[1].y = (points[2].y + points[3].y) / 2;
    }
  }
  points.splice(2, 2);
}
