import Fovia from 'foviaapi';
import { calcMiddleImageRefIndex, calcSeriesPlane, IMAGE_PLANE, imagePlaneToHpPlane, imagePositionPatientToVector } from '../utils';
import { MemoryCacheService } from '../services';
import { BehaviorSubject, Observable } from 'rxjs';
import { ExamSeries } from './exam-series';
import { Exam } from './exam';
import { VirtualSeriesImageRef } from './virtual-series-image-ref';
import { VirtualSeriesImageSet } from './virtual-series-image-set';
import { DICOM_TAGS, ISeriesOrderSeries, makeImageKey, SOP_CLASS, SYNTH_CONTENT_DESC_MONTAGE_PRIORS } from '@server-api';
import { CinePlayback } from './cine-playback';
import SeriesDataContext = Fovia.SeriesDataContext;
import { HangingProtocol } from '@server-api';
import { SlopeIntercept, WindowLevelHelper } from './window-level';

export class VirtualSeries implements ISeriesOrderSeries {
  private imageNumToImageRef: VirtualSeriesImageRef[] = [];
  private _currentImageRefIndex = 0;
  private _requestedImageRefIndex = -1;
  private baseImageIndexForRelativeIncrement: number | null = null;
  private imageKeys = new Set<string>();       // keys for all images in the series
  private imageCacheKeys = new Set<string>();  // keys for images currently cached
  private percentCached$$ = new BehaviorSubject<number>(0);
  private _allFramesLoadedOnServer: Promise<boolean> | null = null;
  private _isStoredKoImage = false;
  public percentCached$: Observable<number> = this.percentCached$$;
  public displayByDefault = true;
  public name = '';
  public koImageKey: string | null = null;   // If this series contains a key object this will hold the SOP Instance UID and frame number of it.
  public cinePlayback: CinePlayback;
  public ignoreRender = false;

  constructor(public imageSets: VirtualSeriesImageSet[], public isDuplicate: boolean = false) {
    this.init();
    this.cinePlayback = new CinePlayback(this.imageCount);
  }
  public init(): void {
    if (this.imageSets.length === 0) {
      console.log(`VirtualSeries constructor: empty imageSets array`);
    }
    this.imageNumToImageRef = this.imageSets.flatMap(imageSet => {
      const arr: VirtualSeriesImageRef[] = [];
      for (let i = imageSet.firstImageIndex; i <= imageSet.lastImageIndex; i++) {
        arr.push(new VirtualSeriesImageRef(imageSet, i));
      }
      return arr;
    });

    for (const imageRef of this.imageNumToImageRef) {
      this.imageKeys.add(imageRef.imageKey);
    }
  }
  public duplicate(markAsDuplicate: boolean = false): VirtualSeries {
    return new VirtualSeries(this.imageSets.map(imageSet => imageSet.duplicate(markAsDuplicate)), true);
  }

  public reverse(): void {
    this.imageNumToImageRef.reverse();
  }

  public static createSimpleVirtualSeries(parentExam: Exam, foviaSeries: Fovia.ScanDirSeriesResults, seriesDataContext: SeriesDataContext): VirtualSeries {
    const examSeries = new ExamSeries(parentExam, foviaSeries, parentExam.isPrimary, seriesDataContext);
    const imageSet = new VirtualSeriesImageSet(examSeries, 0, seriesDataContext.getNumImages() - 1);
    return new VirtualSeries([imageSet]);
  }
  get imageCount(): number {
    return this.imageNumToImageRef.length;
  }

  get isStacked(): boolean {
    return (this.imageSets.length > 1);
  }

  public hasImageKey(key: string): boolean {
    return this.imageKeys.has(key);
  }

  get currentImageRef(): VirtualSeriesImageRef {
    return this.imageNumToImageRef[this._currentImageRefIndex];
  }

  get middleImageRef(): VirtualSeriesImageRef {
    return this.getImageRefFromImageIndex( calcMiddleImageRefIndex(this) );
  }

  getImageRefFromImageIndex(index: number): VirtualSeriesImageRef {
    return this.imageNumToImageRef[index];
  }

  set currentImageRefIndex(index: number) {
    if (index < 0 || index >= this.imageNumToImageRef.length) {
      console.error(`set currentImageRefIndex: index ${index} out of bounds. max = ${this.imageNumToImageRef.length - 1}`);
      return;
    }
    this._currentImageRefIndex = index;
  }

  get currentImageRefIndex(): number {
    return this._currentImageRefIndex;
  }

  set requestedImageRefIndex(index: number) {
    this._requestedImageRefIndex = index;
  }

  get requestedImageRefIndex(): number {
    return this._requestedImageRefIndex;
  }

  get currentSetIndex(): number {
    return this.imageSets.indexOf(this.currentImageRef.imageSet) ?? 0;
  }

  public get currentSetStartFrame(): number {
    return this.getSetStartFrame(this.currentSetIndex);
  }

  get currentSopClassUID(): string {
    return this.imageTags(this.currentImageRef?.imageIndex)?.sopClassUID ?? '';
  }

  get currentSopInstanceUID(): string {
    return this.imageTags(this.currentImageRef?.imageIndex)?.sopInstanceUID ?? '';
  }

  public indexFromSopInstanceUID(sopInstanceUID: string): number {
    return this.imageRefs.findIndex((imageRef) => {
      return sopInstanceUID === imageRef.sdcTags?.sopInstanceUID;
    });
  }

  get currentFrameNumber(): number {
    return this.imageTags(this.currentImageRef?.imageIndex)?.frameNumber ?? 0;
  }

  public getImageRefByImageKey(imageKey: string): VirtualSeriesImageRef | null {
    if (this.hasImageKey(imageKey)) {
      const imageRef = this.imageNumToImageRef.find(imageRef => imageRef.imageKey === imageKey);
      return imageRef ?? null;
    }
    return null;
  }

  public getThickness(): number {
    if (this.imageCount === 0) {
      return 0;
    }
    return this.middleImageRef.sdcTags?.sliceThickness ?? 0;
  }

  public getPlane(): IMAGE_PLANE {
    if (this.imageCount === 0) {
      return IMAGE_PLANE.UNKNOWN;
    }
    const middleImageRef = this.getImageRefFromImageIndex( calcMiddleImageRefIndex(this) );
    if (middleImageRef.imageSet.sourceSeries == null) {
      return IMAGE_PLANE.UNKNOWN;
    }
    return calcSeriesPlane(middleImageRef.imageSet.sourceSeries);
  }

  public getHpPlane(): 'sagittal' | 'coronal' | 'axial' | '' {
    return imagePlaneToHpPlane(this.getPlane());
  }

  public getWithContrast(): boolean {
    if (this.imageCount === 0) {
      return false;
    }
    const middleImageRef = this.getImageRefFromImageIndex( calcMiddleImageRefIndex(this) );
    if (middleImageRef.sdcTags == null) {
      return false;
    }
    if (middleImageRef.imageSet.sourceSeries == null) {
      return false;
    }
    const contrastBolusRoute = middleImageRef.imageSet.sourceSeries.getContrastBolusRoute(middleImageRef.sdcTags.sopInstanceUID);
    return (contrastBolusRoute != null && contrastBolusRoute.indexOf('IV') !== -1);
  }

  public getHpDebugObj(): any {
    if (this.imageCount === 0) {
      return {imageCount: 0};
    }
    return {
      desc: this.currentImageRef.imageSet.seriesDataContext?.seriesDescription ?? '',
      seriesNum: this.currentImageRef.imageSet.seriesDataContext?.seriesNumber ?? -1,
      numImages: this.currentImageRef.imageSet.seriesDataContext?.getNumImages() ?? 0,
      plane: this.getHpPlane(),
      thickness: this.getThickness(),
      contrast: this.getWithContrast(),
    };
  }


  public getImageRefsFromCurrent(): VirtualSeriesImageRef[] {
    const currentSeriesUID = this.currentExamSeries?.seriesInstanceUID;
    if (currentSeriesUID == null) {
      console.error('getImageRefsFromCurrent() seriesUID is null');
      return [];
    }

    // return imageRefs that match current image's seriesUID
    return this.imageNumToImageRef.slice(this._currentImageRefIndex).filter(imageRef => imageRef.imageSet.sourceSeries != null && imageRef.imageSet.sourceSeries.seriesInstanceUID === currentSeriesUID);
  }

  public updatePercentCached(cacheManager: MemoryCacheService): void {
    this.imageCacheKeys.clear();
    for (const key of this.imageKeys) {
      if (cacheManager.imageIsInMemoryCache(key) || (cacheManager.imageIsInOpfsCache(key) ?? false)) {
        this.imageCacheKeys.add(key);
      }
    }
    this.percentCached$$.next(this.percentCached);
  }

  public toString(): string {
    const tags = this.imageTags(this.currentImageRef.imageIndex);
    const imageNumber = this.currentImageRef.imageIndex; // aka frame number
    const studyUID = this.currentSeriesDataContext?.studyInstanceUID;
    const seriesUID = this.currentSeriesDataContext?.seriesInstanceUID;
    const instanceUID = tags?.sopInstanceUID;
    return `${imageNumber}-${studyUID}-${seriesUID}-${instanceUID}`;
  }

  public getImageDescriptorPath(imageIndex: number): string {

    if (imageIndex < 0 || imageIndex >= this.imageNumToImageRef.length) {
      console.error(`getImagePath: imageIndex ${imageIndex} out of bounds. max = ${this.imageNumToImageRef.length - 1}`);
      return '';
    }

    const tags = this.imageTags(imageIndex);
    const studyUID = this.currentSeriesDataContext?.studyInstanceUID;
    const seriesUID = this.currentSeriesDataContext?.seriesInstanceUID;
    const instanceUID = tags?.sopInstanceUID;
    return `/studies/${studyUID}/series/${seriesUID}/instances/${instanceUID}`;
  }

  public get imageRefs(): VirtualSeriesImageRef[] {
    return this.imageNumToImageRef;
  }

  public hasSameImageRefs(otherSeries: VirtualSeries): boolean {
    return this.imageRefs.length === otherSeries.imageRefs.length &&
        this.isStoredKoImage === otherSeries.isStoredKoImage &&
        this.imageRefs.every((value, index) => value.imageKey === otherSeries.imageRefs[index].imageKey);
  }

  public gotoNextImageSet(forward: boolean): boolean {
    const nextImageIndex = this.getSetStartFrame(forward ? this.nextSetIndex : this.previousSetIndex);
    if (nextImageIndex > -1 && nextImageIndex < this.imageCount) {
      this.currentImageRefIndex = nextImageIndex;
      return true;
    }
    return false;
  }

  public gotoNextImage(forward: boolean): boolean {
    const oldIndex = this._currentImageRefIndex;
    this._currentImageRefIndex = this.getNextImageRefIndex(forward);
    return (this._currentImageRefIndex !== oldIndex);
  }

  public getNextImageRefIndex(forward: boolean): number {
    return forward
        ? Math.min(this._currentImageRefIndex + 1, this.imageCount - 1)
        : Math.max(this._currentImageRefIndex - 1, 0);
  }

  public isValidImageRefIndex(index: number): boolean {
    return index < this.imageCount && index >= 0;
  }

  setCurrentImageAsBaseForRelativeIncrement(): void {
    this.baseImageIndexForRelativeIncrement = this.currentImageRefIndex;
  }

  clearRelativeIncrementBaseImage(): void {
    this.baseImageIndexForRelativeIncrement = null;
  }

  public gotoNextImageByRelativeIncrement(positionIncrement: Fovia.Util.Vector): boolean {
    if (this.baseImageIndexForRelativeIncrement == null) {
      console.error('gotoNextImageByRelativeIncrement: baseImageIndexForRelativeIncrement not defined');
      return false;
    }
    const baseImagePosition = this.getImagePositionPatient(this.baseImageIndexForRelativeIncrement);
    if (!baseImagePosition) {
      console.error(`gotoNextImageByRelativeIncrement: baseImagePosition undefined`);
      return false;
    }
    const closestImageIndex = this.getClosestImageByRelativeIncrement(baseImagePosition, positionIncrement);
    this._currentImageRefIndex = Math.max(Math.min(closestImageIndex, this.imageCount - 1), 0);
    return true;
  }

  // Get index of image that is the closest to a base image plus an increment
  public getClosestImageByRelativeIncrement(baseImagePosition: Fovia.Util.Vector, increment: Fovia.Util.Vector): number {
    const targetImagePosition = baseImagePosition.add(increment);

    let closestImageIndex = null;
    let closestDistanceToTarget: number | null = null;
    for (let i = 0; i < this.imageNumToImageRef.length; i++) {
      const imagePosition = this.getImagePositionPatient(i);
      if (imagePosition != null) {
        const distance = targetImagePosition
          .sub(imagePosition)
          .length();
        if (closestDistanceToTarget == null || distance < closestDistanceToTarget) {
          closestDistanceToTarget = distance;
          closestImageIndex = i;
        }
      }
    }
    if (closestImageIndex == null) {
      console.error(`getClosestImageByRelativeIncrement: failed to find closest image. exam:${this.currentExamSeries?.parentExam.studyInstanceUID}  series:${this.currentExamSeries?.seriesInstanceUID}`);
      return 0;
    }
    return closestImageIndex;
  }

  public getImagePositionPatient(imageRefIndex: number): Fovia.Util.Vector | null {
    if (imageRefIndex < 0 || imageRefIndex >= this.imageNumToImageRef.length) {
      console.error(`getImagePositionPatient: index ${imageRefIndex} out of bounds. max = ${this.imageNumToImageRef.length - 1}`);
      return null;
    }
    const imageRef = this.imageNumToImageRef[imageRefIndex];
    const imagePositionPatient = imageRef.imageSet.sourceSeries?.getImagePositionPatient(imageRef.imageIndex) ?? null;

    if (imagePositionPatient) {
      return imagePositionPatientToVector(imagePositionPatient);
    } else {
      return null;
    }
  }

  public getCurrentImagePositionPatient(): Fovia.Util.Vector | null {
    return this.getImagePositionPatient(this.currentImageRefIndex);
  }

  get currentExamSeries(): ExamSeries | null {
    return this.currentImageRef.imageSet.sourceSeries;
  }

  get currentSeriesDataContext(): SeriesDataContext | null {
    return this.currentImageRef.imageSet.seriesDataContext;
  }

  public imageTags(imageNumber: number): Fovia.DICOMImageTags | null {
    return this.currentSeriesDataContext?.imageTags[imageNumber] ?? null ;
  }

  // debug helper.  for now will return -1 for non-image series.
  public get ImageSeriesIndex(): number {
    return this.currentExamSeries?.parentExam.getImageSeriesIndex(this) ?? -1;
  }

  public get cachedImageCount(): number {
    return this.imageCacheKeys.size;
  }

  public clearCachedImageTracking(): void {
    this.imageCacheKeys.clear();
  }

  public get percentCached(): number {
    if (this.imageCount !== 0) {
      return Math.round((this.cachedImageCount / this.imageCount) * 100);
    }
    return 0;
  }

  public hasKeyObject(imageKey: string): boolean {
    return (this.koImageKey === imageKey);
  }

  public hasKeyObjectIncludingCopies(sopInstanceUID: string, frameNumber: number): boolean {
    return (this.koImageKey?.startsWith(makeImageKey(sopInstanceUID, frameNumber)) ?? false);
  }

  private get nextSetIndex(): number {
    const nextIndex = this.currentSetIndex + 1;
    return nextIndex < this.imageSets.length ? nextIndex : -1;
  }

  private get previousSetIndex(): number {
    const previousIndex = this.currentSetIndex - 1;
    return previousIndex >= 0 ? previousIndex : -1;
  }

  public getSetStartFrame(setIndex: number): number {
    if (setIndex >= 0 && setIndex < this.imageSets.length) {
      let count = 0;
      for (let i = 0; i < setIndex; i++) {
        count += this.imageSets[i].numImages;
      }
      return count;
    }
    return -1;
  }

  public get isStoredKoImage(): boolean {
    return this._isStoredKoImage;
  }

  public set isStoredKoImage(b: boolean) {
    this._isStoredKoImage = b;
  }

  public get isStoredScKoImage(): boolean {
    if (!this.isStoredKoImage) {
      return false;
    }
    const exam = this.currentImageRef.imageSet.sourceSeries?.parentExam;
    if (exam == null) {
      return false;
    }
    const sopClassUid = exam.getTagValueAsString(this.currentSopInstanceUID, DICOM_TAGS.SOP_CLASS_UID);
    return sopClassUid?.trim() === SOP_CLASS.SC;
  }

  public get isStoredMontageComparisonImage(): boolean {
    if (!this.isStoredKoImage) {
      return false;
    }
    const exam = this.currentImageRef.imageSet.sourceSeries?.parentExam;
    if (exam == null) {
      return false;
    }
    const seriesDescription = exam.getTagValueAsString(this.currentSopInstanceUID, DICOM_TAGS.SERIES_DESCRIPTION) ?? '';
    return seriesDescription.trim().startsWith(SYNTH_CONTENT_DESC_MONTAGE_PRIORS);
  }

  private isImageInSeries(sdc: SeriesDataContext, imageUID: string, frameNumber: number): boolean {
    for (const imageSet of this.imageSets) {
      if (imageSet.seriesDataContext) {
        if (imageSet.seriesDataContext.seriesInstanceUID === sdc.seriesInstanceUID) {
          for (let i = imageSet.firstImageIndex; i <= imageSet.lastImageIndex; i++) {
            if (imageSet.seriesDataContext.imageTags[i]?.sopInstanceUID === imageUID &&
              imageSet.seriesDataContext.imageTags[i]?.frameNumber === frameNumber) {
              return true;
            }
          }
        }
      }
    }
    return false;
  }

  public allImagesAvailableFor3D(): boolean {
    const exam = this.currentExamSeries?.parentExam;

    // virtual series that are exam-less or made from multiple series don't qualify
    if (exam == null || this.isStacked) {
      return false;
    }
    const frames = this.imageRefs.map(imageRef => ({sopInstanceUID: imageRef.sdcTags?.sopInstanceUID ?? '', frameNumber: imageRef.sdcTags?.frameNumber ?? 0}));
    return exam.examLoadContext.allImagesAvailableOnServer(frames);
  }

  public applyCenterImageFirstHpRule(hp: HangingProtocol): void {
    const plane = this.getHpPlane();
    if (plane === '') {
      return;
    }
    const centerSliceFirst = hp.seriesPresentationOptions.centerSliceFirst[plane];
    if (centerSliceFirst) {
      this._currentImageRefIndex = calcMiddleImageRefIndex(this);
    }
  }

  public updateAutoWLTagsIfNeeded(rp: Fovia.RenderParams2D): void {
    const tags = this.imageTags(this.currentImageRef.imageIndex);
    if (tags == null) {
      return;
    }
    // Already have a WL for this image - current WL setting is not from AutoWL.
    if (tags.windowCenter.length > 0 && tags.windowWidth.length > 0) {
      return;
    }
    // Must have autoWL'd this image, save the value so that onResetWL works correctly.
    const slope = tags.rescaleSlope ?? 1;
    const intercept = tags.rescaleIntercept ?? 0;

    const wlHelper = WindowLevelHelper.fromRenderParams(rp, new SlopeIntercept(slope, intercept));
    // Only have a VOI LUT?
    if (wlHelper.wl.isVOILut) {
      return;
    }
    tags.windowCenter = wlHelper.displayedWL.level.toString();
    tags.windowWidth = wlHelper.displayedWL.width.toString();
    // console.log(`Updating SDC tags from AutoWL value for Key:${this.currentImageRef.imageKey} ImageIndex: ${this.currentImageRef.imageIndex} to W/L: ${tags.windowWidth}/${tags.windowCenter} `);
  }

  public addImageUserCalibration(imageKey: string, userReportedLength: number, measurementPixels: number): void {
    const imageRef = this.getImageRefByImageKey(imageKey);
    if (imageRef) {
      imageRef.imageSet.sourceSeries?.parentExam.addImageUserCalibration(imageKey, userReportedLength, measurementPixels);
    }
  }

  public getImagePixelSpacing(imageKey: string): string | null {
    const imageRef = this.getImageRefByImageKey(imageKey);
    if (imageRef) {
      return imageRef.imageSet.sourceSeries?.parentExam.getImagePixelSpacing(imageKey) ?? null;
    }
    return null;
  }

  /**
   * Returns boolean that determines if image can have a user calibration.
   */
  public canBeUserCalibrated(): boolean {
    // If pixel spacing tag does not exist then image can be user calibrated
    if (this.currentImageRef.sdcTags != null) {
      if (this.currentImageRef.sdcTags.pixelSpacing === '' || this.currentImageRef.sdcTags.pixelSpacing == null) {
        return true;
      }
    }

    return false;
  }
}
