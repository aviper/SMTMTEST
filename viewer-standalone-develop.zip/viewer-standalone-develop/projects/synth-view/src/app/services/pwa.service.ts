import { Injectable, isDevMode } from '@angular/core';
import { NoNewVersionDetectedEvent, SwUpdate, VersionEvent, VersionReadyEvent } from '@angular/service-worker';
import { filter, Subject, takeUntil, tap, timer } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PwaService {

  private listeningForUpdates = false;
  private versionHash: string | null = null;
  private readonly unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private swUpdate: SwUpdate) {}

  startListeningForSwUpdates(): void {
    // if (isDevMode() || this.listeningForUpdates) {
    // Use commented out code above to prevent service worker from running in development mode.
    // if (this.listeningForUpdates) {
    // Use commented out code above to enable service worker when running in development mode.
    if (isDevMode() || this.listeningForUpdates) {
      return;
    }

    this.swUpdate.versionUpdates
      .pipe(
        tap((event) => {
          if (this.isNoNewVersionEvent(event)) {
            this.handleNoNewVersionDetected(event);
          }
        }),
        filter(this.isVersionReadyEvent),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((versionEvent) => this.handleVersionReady(versionEvent));

    timer(0, 60000)
      .pipe(takeUntil(this.unsubscribe$$))
      .pipe(tap(() => {
        console.info('Checking for updates...');
      }))
      .subscribe(async () => await this.swUpdate.checkForUpdate());

    this.listeningForUpdates = true;
  }

  stopListeningForSwUpdates(): void {
    this.unsubscribe$$.next();
    this.listeningForUpdates = false;
  }

  // Just a console log for now. Updates are automatically installed by the service worker when app window is refreshed.
  private handleVersionReady(versionEvent: VersionReadyEvent): void {
    console.info(`New version ready to install. Current: ${versionEvent.currentVersion.hash} | Latest: ${versionEvent.latestVersion.hash}`);
  }

  // Sometimes the service worker sends a new version hash as a NoNewVersionDetectedEvent. This is a safeguard to handle that.
  private handleNoNewVersionDetected(event: NoNewVersionDetectedEvent): void {
    if (this.versionHash && this.versionHash !== event.version.hash) {
      console.warn(`Service worker sent a NoNewVersionDetectedEvent with a different version hash: ${event.version.hash}. Current version hash: ${this.versionHash}. New version will be installed on next refresh.`);
    }

    console.info('No new version detected. Current version:', event.version.hash);
    this.versionHash = event.version.hash;
  }

  private isVersionReadyEvent(event: VersionEvent): event is VersionReadyEvent {
    return event.type === 'VERSION_READY' &&
      'currentVersion' in event &&
      'latestVersion' in event;
  }

  private isNoNewVersionEvent(event: VersionEvent): event is NoNewVersionDetectedEvent {
    return event.type === 'NO_NEW_VERSION_DETECTED';
  }
}
