import { Injectable } from '@angular/core';
import { SessionDataService } from '../viewer/services';
import { Exam, ViewerSession } from '../viewer/models';
import { ExamLoadContext, ExamLoadServerPerformanceMetrics } from '@server-api';

const MEGABYTE = 1024 * 1024;

interface RecordedTime {
  perfMS: number;
  dateTime: Date;
}

interface CacheStats {
  cache: number,
  opfsCache: number,
  timeRecorded: RecordedTime,
  imageKey?: string,
}

type ValueOf<T> = T[keyof T];

export const ImageLoadingEventType = {
  PRELOAD_REQUEST: 'PRELOAD_REQUEST',
  GET_ASYNC: 'GET_ASYNC',
  START_CACHE_PRELOAD: 'START_CACHE_PRELOAD',
  START_CACHE_ASYNC: 'START_CACHE_ASYNC',
  DOWNLOAD_START: 'DOWNLOAD_START',
  DOWNLOAD_END: 'DOWNLOAD_END',
  CACHED: 'CACHED',
} as const;

type ImageLoadingEventType = ValueOf<typeof ImageLoadingEventType>;

interface ImageLoadingEvent {
  event: ImageLoadingEventType;
  eventIndex: number;
  examId: string;
  imageKey: string;
  timeRecorded: RecordedTime;
  fileSizeBytes?: number;
}

export const PaintingEventType = {
  PAINT_REQUESTED: 'PAINT_REQUESTED',
  PAINT_FINISHED: 'PAINT_FINISHED',
} as const;

type PaintingEventType = ValueOf<typeof PaintingEventType>;

interface PaintingEvent {
  event: PaintingEventType;
  eventIndex: number;
  timeRecorded: RecordedTime;
  viewportId: string;
  imageKey: string;
}

interface ExamInfo {
  examDescription: string;
  numImageSeries: number;
  numImages: number;
  numNonImageSeries: number;
  serverCached?: boolean;
  serverReady?: number;
  serverTotal?: number;
  serverStart?: string;
  serverFinish?: string;
}

@Injectable({
  providedIn: 'root'
})
export class PerfMonitorService {
  private userId: number | null;
  private _primaryStudyUID: string | null;
  private _loadExamGroupStarted: RecordedTime | null;
  private _sessionStarted: RecordedTime | null;
  private _preloadStarted: RecordedTime | null;

  private _cacheMax: number;
  private _opfsCacheMax: number;
  private _cacheStats: CacheStats[];

  private _loadingTimeline: ImageLoadingEvent[];
  private _paintingTimeline: PaintingEvent[];

  private _examInfo: Record<string, ExamInfo>;
  private _examLoadContexts: Record<string, ExamLoadContext>;

  constructor(
    private sessionDataService: SessionDataService,
  ) {
    this.sessionDataService.activeViewerSession$
      .subscribe((activeSession) => {
        if (activeSession != null) {
          this.recordSessionInfo(activeSession);
        }
      });

    this.userId = null;
    this._primaryStudyUID = null;
    this._loadExamGroupStarted = null;
    this._sessionStarted = null;
    this._preloadStarted = null;
    this._cacheStats = [];
    this._loadingTimeline = [];
    this._paintingTimeline = [];
    this._cacheMax = 0;
    this._opfsCacheMax = 0;
    this._examInfo = {};
    this._examLoadContexts = {};

    // Currently, the only way to read these metrics is to call these functions in the dev console
    (window as any).synthPerfMetrics = this.printInfo.bind(this);
    (window as any).synthPerfDump = this.dumpFullContext.bind(this);
  }

  public reset() {
    this.userId = null;
    this._primaryStudyUID = null;
    this._loadExamGroupStarted = null;
    this._sessionStarted = null;
    this._preloadStarted = null;
    this._cacheStats = [];
    this._loadingTimeline = [];
    this._paintingTimeline = [];
    this._cacheMax = 0;
    this._opfsCacheMax = 0;
    this._examInfo = {};
    this._examLoadContexts = {};
  }

  // This function currently does some unsavory things, like iterating over the same list multiple times in order
  // to find different event items. This isn't very Big-O friendly, but this is only called manually in the console,
  // so it's allowed to perform poorly for readability.
  private printInfo() {
    const lastImageCached = this._loadingTimeline.findLast(e => e.event === ImageLoadingEventType.CACHED);
    if (!this._preloadStarted || !lastImageCached) {
      console.error('Preload not started, no useful performance logs yet');
      return;
    }

    const startTime = this._preloadStarted.perfMS;
    const endTime = lastImageCached.timeRecorded.perfMS;

    const lastCacheEvent = this._cacheStats[this._cacheStats.length - 1];
    console.table({
      'User ID': this.userId,
      'Primary Exam': this._primaryStudyUID,
      'Cache Max': formatByteSize(this._cacheMax),
      'Current Cache': `${formatByteSize(lastCacheEvent.cache)} (${Math.ceil(lastCacheEvent.cache / this._cacheMax)}%)`,
      'OPFS Max': formatByteSize(this._opfsCacheMax),
      'Current OPFS': `${formatByteSize(lastCacheEvent.opfsCache)} (${Math.ceil(lastCacheEvent.opfsCache / this._opfsCacheMax)}%)`,
    });

    console.table({
      'Exam Load Start': timeColumn(this._loadExamGroupStarted),
      'Session Start': timeColumn(this._sessionStarted),
      'First Image Preload': timeColumn(this._loadingTimeline.find(e => e.event === ImageLoadingEventType.PRELOAD_REQUEST)?.timeRecorded),
      'First Fovia Image Request': timeColumn(this._loadingTimeline.find(e => e.event === ImageLoadingEventType.GET_ASYNC)?.timeRecorded),
    });

    // Use the ExamLoadContext to obtain up-to-date information on server-side performance metrics
    // Server-side performance metrics are only available once the load has completed on the server
    for (const [examId, examLoadContext] of Object.entries(this._examLoadContexts)) {
      const examInfo = this._examInfo[examId];
      if (examInfo && examLoadContext && examLoadContext.performanceMetrics) {
        const metrics = examLoadContext.performanceMetrics;
        const serverStartTime = new Date(metrics.timestamps.start);
        const serverFinishTime = new Date(metrics.timestamps.start + metrics.markers.total);
        examInfo.serverCached = metrics.buckets.diskLoad > 0;
        examInfo.serverReady = metrics.markers.ready;
        examInfo.serverTotal = metrics.markers.total;
        examInfo.serverStart = serverStartTime.toISOString();
        examInfo.serverFinish = serverFinishTime.toISOString();
      }
    }
    console.table(this._examInfo);

    const between = (timeMS: number) => timeMS >= startTime && timeMS <= endTime;
    // This initial filter lets us only grab download events after the preload period starts
    const preloadLoadEvents = this._loadingTimeline.filter(e => between(e.timeRecorded.perfMS));
    const firstDownloadStartEvent = preloadLoadEvents.find(e => e.event === ImageLoadingEventType.DOWNLOAD_START);
    const downloadEndEvents = preloadLoadEvents.filter(e => e.event === ImageLoadingEventType.DOWNLOAD_END);
    const totalDownloadEndEvents = downloadEndEvents.length;
    const lastDownloadEndEvent = downloadEndEvents[totalDownloadEndEvents - 1];
    const preloadDownloadPeriodSeconds = (lastDownloadEndEvent.timeRecorded.perfMS - (firstDownloadStartEvent?.timeRecorded.perfMS || 0)) / 1000;

    const paintEvents = this._paintingTimeline.filter(e => between(e.timeRecorded.perfMS));
    // This is probably just the first and last event, but I wanna be sure
    const firstPaintStartEvent = paintEvents.find(e => e.event === PaintingEventType.PAINT_REQUESTED);
    const paintEndEvents = paintEvents.filter(e => e.event === PaintingEventType.PAINT_FINISHED);
    const totalPaintEndEvents = paintEndEvents.length;
    const lastPaintEndEvent = paintEndEvents[totalPaintEndEvents - 1];
    const preloadPaintPeriodSeconds = (lastPaintEndEvent.timeRecorded.perfMS - (firstPaintStartEvent?.timeRecorded.perfMS || 0)) / 1000;

    console.table({
      'Preload Image Download Rate': timeRateColumnn(totalDownloadEndEvents, preloadDownloadPeriodSeconds),
      'Preload Paint Rate': timeRateColumnn(totalPaintEndEvents, preloadPaintPeriodSeconds),
    });
  }

  private dumpFullContext() {
    const serverMetrics: Record<string, ExamLoadServerPerformanceMetrics> = {};
    // Gather server-side performance metrics, which are only available once an exam load has completed
    for (const [examId, examLoadContext] of Object.entries(this._examLoadContexts)) {
      if (examLoadContext && examLoadContext.performanceMetrics) {
        serverMetrics[examId] = examLoadContext.performanceMetrics;
      }
    }
    // Using `trace` since log, error, warn, info, and debug were overwritten in production
    console.trace(JSON.stringify({
      userId: this.userId,
      primaryStudyUID: this._primaryStudyUID,
      loadExamGroupStarted: this._loadExamGroupStarted,
      sessionStarted: this._sessionStarted,
      preloadStarted: this._preloadStarted,
      cacheMax: this._cacheMax,
      opfsCacheMax: this._opfsCacheMax,
      cacheStats: this._cacheStats,
      loadingTimeline: this._loadingTimeline,
      paintingTimeline: this._paintingTimeline,
      examInfo: this._examInfo,
      serverMetrics
    }));
  }



  public startLoadExamGroup() {
    this._loadExamGroupStarted = now();
  }

  public startSession() {
    this._sessionStarted = now();
  }

  public startPreload() {
    this._preloadStarted = now();
  }

  public recordExams(exams: (Exam | null)[]) {
    for (const exam of exams) {
      if (exam) {
        const examLoadContext = exam.examLoadContext;
        const originalImageSeries = exam.originalImageSeries;
        this._examInfo[exam.studyInstanceUID] = {
          examDescription: originalImageSeries[0].foviaSeriesDataContext.studyDescription,
          numImageSeries: originalImageSeries.length,
          numImages: originalImageSeries.reduce((sum: number, series) => {
            return sum + series.numImages;
          }, 0),
          numNonImageSeries: exam.nonImageSeries.length
        };
        this._examLoadContexts[exam.studyInstanceUID] = examLoadContext;
      }
    }
  }

  public recordInitialCacheStats(
    cache: number,
    cacheMax: number,
    opfsCache: number,
    opfsCacheMax: number,
  ) {
    this._cacheMax = cacheMax;
    this._opfsCacheMax = opfsCacheMax;
    this.recordCacheStats(cache, opfsCache);
  }

  public recordCacheStats(cache: number, opfsCache: number, imageKey?: string) {
    this._cacheStats.push({
      cache,
      opfsCache,
      timeRecorded: now(),
      imageKey,
    });
  }

  public recordImageLoadEvent(event: ImageLoadingEventType, examId: string, imageKey: string, fileSizeBytes?: number) {
    this._loadingTimeline.push({
      event,
      examId,
      imageKey,
      fileSizeBytes,
      timeRecorded: now(),
      eventIndex: this._loadingTimeline.length,
    });
  }

  public recordPaintEvent(event: PaintingEventType, viewportId: string, imageKey: string) {
    this._paintingTimeline.push({
      event,
      viewportId,
      imageKey,
      timeRecorded: now(),
      eventIndex: this._paintingTimeline.length,
    });
  }

  private recordSessionInfo(session: ViewerSession) {
    this.userId = session.examGroup.user.userId;
    this._primaryStudyUID = session.primaryExamUID;
    console.log(session);
  }
}

function now(): RecordedTime {
  return {
    // It might seem weird to round the performance time, but the decimal values of
    // `performance.now()` aren't very useful (lots of values like "12.019999999")
    // which indicate that the precision is low. We really only need accuracy to the
    // millisecond
    perfMS: Math.round(performance.now()),
    dateTime: new Date(),
  };
}

function timeColumn(time?: RecordedTime | null) {
  return time
    ? {
      'ISO Time': time.dateTime.toISOString(),
      'MS since browser load': time.perfMS,
    }
    : null;
}

function timeRateColumnn(occurances: number, lengthSeconds: number) {
  return {
    'Total Occurances': occurances,
    'Time Period (seconds)': lengthSeconds,
    'Average Rate': `${occurances / lengthSeconds}/second`,
  }
}

function formatByteSize(byteCount: number): string {
  return `${Math.ceil(byteCount / MEGABYTE)}MB`;
}
