import { Injectable } from '@angular/core';
import setup from 'logrocket/setup';

export interface LogRocketSetupConfig {
  logRocket: {
    sdkServer: string;
    ingestServer: string;
    appId: string;
  };
  identity: {
    uid: string; // usually a combination of environment name and user id
    userId: number;
    name: string;
    email: string;
    deviceId: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class LogRocketService {
  private LogRocket: any;
  private sessionTracking = false;

  isSessionTracking(): boolean {
    return this.sessionTracking;
  }

  init(logRocketSetupConfig: LogRocketSetupConfig): void {
    console.log('logRocketSetupConfig', logRocketSetupConfig);

    if (!logRocketSetupConfig?.identity || !logRocketSetupConfig?.logRocket) {
      return;
    }

    if (!this.LogRocket) {
      this.LogRocket = setup({
        sdkServer: logRocketSetupConfig.logRocket.sdkServer,
        ingestServer: logRocketSetupConfig.logRocket.ingestServer
      });
    }

    this.LogRocket.init(logRocketSetupConfig.logRocket.appId);

    this.LogRocket.identify(logRocketSetupConfig.identity.uid, {
      id: logRocketSetupConfig.identity.userId,
      name: logRocketSetupConfig.identity.name,
      email: logRocketSetupConfig.identity.email,
      deviceId: logRocketSetupConfig.identity.deviceId,
    });

    this.sessionTracking = true;
  }
}
