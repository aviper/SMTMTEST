import { TestBed } from '@angular/core/testing';
import { SynthViewComponent } from './app.component';

describe('SynthViewComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        SynthViewComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(SynthViewComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'Synthesis VISION'`, () => {
    const fixture = TestBed.createComponent(SynthViewComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('Synthesis VISION');
  });

});
