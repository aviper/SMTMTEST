import { Component, OnInit } from '@angular/core';
import { PulseVisionApiService } from '@pulse-zero-api';
import { PwaService } from './services/pwa.service';

@Component({
  standalone: false,
  selector: 'app-synth-view',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class SynthViewComponent implements OnInit {
  constructor(
    protected pulseVisionApi: PulseVisionApiService,
    private pwaService: PwaService,
  ) {
    const isOpfsReadOnly = true;
    pulseVisionApi.init(isOpfsReadOnly);
  }

  title = 'Synth VISION';

  ngOnInit(): void {
    this.pwaService.startListeningForSwUpdates();
  }
}
