// jest.config.js (javascript file)
module.exports = {
  rootDir: "./",
  preset: 'jest-preset-angular',
  setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
};