import { from, lastValueFrom, NEVER, Observable, ReplaySubject, take, takeUntil } from 'rxjs';
import Fovia from 'foviaapi';

import { AuthorizationToken, IExamGroupExamInformation } from '@idgital/vision-auth-interface';
import { ExamId } from '@idgital/vision-interface';

import { ExamGroup, ExamInformation, ExamLoadStatus, ExamLoadCondition, ExamLoadVersion } from '../models';
import { findInvalidImageFrames, makeImageKey, IFoviaStudySRData, FOVIA_SR_PRESENTATION_SCHEMA_VERSION } from '../utils';

export interface ExamLoadServerPerformanceMetrics {
  timestamps: {
    start: number;          // Unix timestamp at which request started processing on the server
    reqrx: number;          // Timestamp at which request was received on server
    restx: number;          // Timestamp at which request was completed on server
  },
  markers: {
    ready: number;          // Milliseconds from request received until displayimagesloaded event
    total: number;          // Milliseconds from request received until completion of request
  },
  buckets: {
    authorization: number;  // Milliseconds spent checking user access to study
    decodeCBOR: number;     // Milliseconds spent decoding objects from CBOR (coming from Fovia native code)
    decodeJSON: number;     // Milliseconds spent decoding objects from JSON (JSON.parse)
    encodeCBOR: number;     // Milliseconds spent encoding objects to CBOR (to pass to Fovia native code)
    encodeJSON: number;     // Milliseconds spent encoding objects to JSON (JSON.stringify)
    diskAccess: number;     // Milliseconds spent on disk I/O (excluding scanDICOMDir)
    download: number;       // Milliseconds spent downloading from healthcare backend (excluding metadata)
    metadata: number;       // Milliseconds spent retrieving DICOM+JSON metadata
    loadFrame: number;      // Milliseconds spent in Fovia native updatePixelData
    loadImage: number;      // Milliseconds spent in Fovia native loadDICOMImage
    loadStudy: number;      // Milliseconds spent constructing Fovia FDI from DICOM+JSON
    protocols: number;      // Milliseconds spent fetching hanging protocols
    diskLoad: number;       // Milliseconds spent loading study data from disk (scanDICOMDir)
    foviaJson: number;      // Milliseconds spent converting DICOM+JSON metadata to magical Fovia form
    trimScanDir: number;    // Milliseconds spent stripping off data from ScanDirResults that do not apply to the requested study
    sendMessage: number;    // Milliseconds spent sending progress updates to the client
    fairyDust: number;      // Milliseconds spent doing whatever Fovia getPatientList does
    metadataHash: number;   // Milliseconds spent hashing DICOM+JSON metadata
  }
}

export class ExamLoadContext {
  examGroup: ExamGroup;
  studyInstanceUID: ExamId;
  loadVersion: ExamLoadVersion | undefined;
  loadCondition: ExamLoadCondition;
  dicomJsonMetadata: any[] | null;
  scanDirResults: Fovia.ScanDirResults | null;
  performanceMetrics: ExamLoadServerPerformanceMetrics | null;

  // Supplied to precacher from server for writing to OPFS
  serverMetadataHash: string | undefined;
  serverScanDirResultsJSON: any | undefined;

  // supplied by viewer after it reads them from OPFS (to support fast client-side loading)
  clientMetadataHash: string | undefined;
  clientScanDirResultsJSON: any | undefined;
  clientExamSRData: IFoviaStudySRData | undefined;
  canUseClientExamSRData: boolean;

  // Track availability of images and individual image frames
  private readyImageFramesTracker: ReadyItemsTracker;
  private readySopInstancesTracker: ReadyItemsTracker;

  private dicomJsonMetadataReady: ReadyItem;     // signaled when download of dicom headers from server completed
  private clientScanDirResultsReady: ReadyItem;  // signaled if client-side fast-loaded scanDirResults are up-to-date and available
  private serverScanDirResultsReady: ReadyItem;  // signaled when server-side scanDirResults are available
  private serverExamLoadCompleted: ReadyItem;    // signaled when server-side load is complete and all images/frames are available
  private readonly serverExamLoadCompleted$: Observable<boolean>;

  // Track image frames that are missing or invalid.
  // The invalid state of a frame lets the app know not to attempt subsequent download or display of the frame
  private invalidImageFrames = new Set<string>();

  // Track SOP instances that are not available on the server
  private unavailableSopInstances = new Map<string, number>();

  // Track image frames that are not available on the server
  private unavailableImageFrames = new Map<string, number>();

  constructor(examGroup: ExamGroup, studyInstanceUID: ExamId, loadCondition: ExamLoadCondition, clientExamVersion?: string, clientScanDirResultsJSON?: any, clientExamSRData?: IFoviaStudySRData) {
    this.examGroup = examGroup;
    this.studyInstanceUID = studyInstanceUID;
    this.loadVersion = undefined;
    this.loadCondition = loadCondition;
    this.dicomJsonMetadata = null;
    this.clientMetadataHash = clientExamVersion;
    this.clientScanDirResultsJSON = clientScanDirResultsJSON;
    this.clientExamSRData = clientExamSRData;
    this.canUseClientExamSRData = false;
    this.serverMetadataHash = undefined;
    this.serverScanDirResultsJSON = undefined;
    this.scanDirResults = null;
    this.performanceMetrics = null;

    this.serverExamLoadCompleted = new ReadyItem(NEVER, false);
    this.serverExamLoadCompleted$ = from(this.serverExamLoadCompleted.waitForItemReady());

    // A default value of 'true' for these should be OK because if the server load completes, these items should have completed.
    // And, for frames and sopInstances, failures are tracked separately in 'unavailableImageFrames' and 'unavailableSopInstances'.
    this.dicomJsonMetadataReady = new ReadyItem(this.serverExamLoadCompleted$, true);
    this.clientScanDirResultsReady = new ReadyItem(this.serverExamLoadCompleted$, true);
    this.serverScanDirResultsReady = new ReadyItem(this.serverExamLoadCompleted$, true);
    this.readySopInstancesTracker = new ReadyItemsTracker(this.serverExamLoadCompleted$, true);
    this.readyImageFramesTracker = new ReadyItemsTracker(this.serverExamLoadCompleted$, true);
  }

  public get accessToken(): AuthorizationToken {
    return this.examGroup.accessToken;
  }

  public get forPrimaryExam(): boolean {
    return this.studyInstanceUID === this.examGroup.primaryExam.studyUID;
  }

  // Wait for a frame to be ready for download.  A frame is ready if any of these is true:
  //   - the frame is signaled as ready
  //   - the associated SOP instance is signaled as ready
  //   - the entire exam load is signaled as complete (needed for scanDicomDir exams)
  //
  public async frameReadyToDownload(sopInstanceUID: string, frameNumber: number): Promise<boolean> {
    try {
      const imageKey = makeImageKey(sopInstanceUID, frameNumber);
      const ready = await Promise.race([
        this.readyImageFramesTracker.waitForItemReady(imageKey),
        this.readySopInstancesTracker.waitForItemReady(sopInstanceUID),
        this.serverExamLoadCompleted.waitForItemReady()
      ]);
      return ready && !this.isImageFrameInvalid(imageKey) && !this.isImageFrameUnavailable(sopInstanceUID, frameNumber);
    } catch (err) {
      console.error(`waitForFrameReadyToDownload`, err);
    }
    return false;
  }

  // Synchronous check for availability of all image frames passed in.
  // Don't call this before exam loading completed.
  public allImagesAvailableOnServer(frames: Array<{sopInstanceUID: string, frameNumber: number}>): boolean {
    return frames.find( frame => {
      return (this.unavailableImageFrames.get(makeImageKey(frame.sopInstanceUID, frame.frameNumber)) != null ||
              this.unavailableSopInstances.get(frame.sopInstanceUID) != null)
    } ) === undefined;
  };

  // prepping future support for waiting for an individual volume to be ready for loading on the server
  public async waitForFramesAvailableOnServer(frames: Array<{sopInstanceUID: string, frameNumber: number}>): Promise<boolean> {
    let failure = false;
    const allResults = await Promise.all(
      frames.map(frame => this.frameReadyToDownload(frame.sopInstanceUID, frame.frameNumber))
    ).catch(reason => {
      failure = true;
    });
    return (
      !failure &&
      allResults != null &&
      allResults.find(result => !result) == null
    );
  }

  public async dicomJsonMetadataComplete(): Promise<boolean> {
    return await this.dicomJsonMetadataReady.waitForItemReady();
  }

  public async scanDirResultsComplete(): Promise<boolean> {
    return await Promise.race([
      this.clientScanDirResultsReady.waitForItemReady(),  // this will never be signaled if there is a mismatch between client and server exam versions
      this.serverScanDirResultsReady.waitForItemReady(),
    ]);
  }

  public async serverScanDirResultsComplete(): Promise<boolean> {
    return this.serverScanDirResultsReady.waitForItemReady();
  }

  public async serverExamLoadComplete(): Promise<boolean> {
    return this.serverExamLoadCompleted.waitForItemReady();
  }

  public onExamNotAvailable(httpStatus: number, serverDetail: string, notAuthorized: boolean): void {
    /* Empty */
  }

  public onServerExamLoadComplete(): void {
    this.serverExamLoadCompleted.setItemReady(true);
  }

  public onSopInstanceNotAvailable(seriesInstanceUID: string, sopInstanceUID: string, httpStatus: number, serverDetail: string): void {
    this.unavailableSopInstances.set(sopInstanceUID, httpStatus);
    this.readySopInstancesTracker.setItemReady(sopInstanceUID, false);
  }

  public onImageFrameNotAvailable(seriesInstanceUID: string, sopInstanceUID: string, frameNumber: number, httpStatus: number, serverDetail: string): void {
    const imageKey = makeImageKey(sopInstanceUID, frameNumber);
    this.markImageFrameAsInvalid(imageKey);
    this.unavailableImageFrames.set(imageKey, httpStatus); // set specific error code here when available
    this.readyImageFramesTracker.setItemReady(imageKey, false);
  }

  public onExamAccessAuthorized(examInformation: IExamGroupExamInformation): ExamInformation {
    if (this.studyInstanceUID !== this.examGroup.primaryExam.studyUID) {
      // This access check was for a comparison exam.
      // The comparison exam may not have been part of the exam group at the time the exam group access was resolved.
      return this.examGroup.addComparisonExam(examInformation);
    } else {
      // The access check was for the primary exam, which was already defined as part of the exam group.
      return this.examGroup.primaryExam;
    }
  }

  public onDicomJsonMetadataReceived(dicomMetadata: any[], examVersion: string, loadVersion: ExamLoadVersion | undefined, scanDirResults: Fovia.ScanDirResults | undefined): void {
    this.loadVersion = loadVersion;
    this.serverMetadataHash = examVersion;
    this.dicomJsonMetadata = dicomMetadata;
    this.dicomJsonMetadataReady.setItemReady(true);
    if (scanDirResults != null && loadVersion === 'client') {
      if (this.scanDirResults == null) {
        this.setScanDirResults(scanDirResults);   // we'll be using the scanDirResults supplied by the client
      }
      if (this.clientExamSRData) {
        if (
          // The cached SR data can only be used if ALL of the following conditions are met:
          // 1. All exam SR data was successfully retrieved from the server during caching to the client,
          // 2. The Fovia SR schema version used during caching matches the current version,
          // 3. The exam version cached matches the current exam version in the healthcare backend.
          this.clientExamSRData.errorSeriesUID.length === 0 &&
          this.clientExamSRData.examVersion === examVersion &&
          this.clientExamSRData.foviaSchema === FOVIA_SR_PRESENTATION_SCHEMA_VERSION) {
            this.canUseClientExamSRData = true;
          } else {
            console.trace(`Fast loading disabled for ${this.studyInstanceUID}; cached SR data is stale or incomplete`);
            this.canUseClientExamSRData = false;
          }
      } else {
        // No cached SR data - it will have to be loaded on the server.
        this.canUseClientExamSRData = false;
      }
      this.clientScanDirResultsReady.setItemReady(true);
    }
  }

  public onImageFrameLoaded(seriesInstanceUID: string, sopInstanceUID: string, frameNumber: number): void {
    const key = makeImageKey(sopInstanceUID, frameNumber);
    this.unavailableImageFrames.delete(key);
    this.readyImageFramesTracker.setItemReady(key, true);
  }

  public onSopInstanceLoaded(seriesInstanceUID: string, sopInstanceUID: string): void {
    this.unavailableSopInstances.delete(sopInstanceUID);  // not expected to be in this map at this point, but maybe someday
    this.readySopInstancesTracker.setItemReady(sopInstanceUID, true);
  }

  public onDisplayImagesLoaded(scanDirResults: Fovia.ScanDirResults, serverScanDirResultsJSON: any, examVersion: string, loadVersion: ExamLoadVersion | undefined): void {
    this.loadVersion = loadVersion;
    this.serverMetadataHash = examVersion;
    this.serverScanDirResultsJSON = serverScanDirResultsJSON;
    if (this.scanDirResults == null) {
      this.setScanDirResults(scanDirResults);  // we'll be using the scanDirResults supplied by the server
    }
    this.serverScanDirResultsReady.setItemReady(true);
  }

  public onServerPerformanceMetricsReady(metrics: ExamLoadServerPerformanceMetrics): void {
    this.performanceMetrics = metrics;
  }

  private setScanDirResults(scanDirResults: Fovia.ScanDirResults): void {
    this.scanDirResults = scanDirResults;

    const invalidImageFrames = findInvalidImageFrames(this.studyInstanceUID, this.scanDirResults);
    invalidImageFrames.forEach(imageKey => this.markImageFrameAsInvalid(imageKey));

    this.examGroup.updateExamLoadStatus(this.studyInstanceUID, ExamLoadStatus.LOADED);
  }

  // Track general image frame failures, such as missing from the exam, or containing invalid data.
  public markImageFrameAsInvalid(imageKey: string): void {
    console.warn(`markImageFrameAsInvalid:  ${imageKey}`);
    this.invalidImageFrames.add(imageKey);
  }
  public isImageFrameInvalid(imageKey: string): boolean {
    return this.invalidImageFrames.has(imageKey);
  }

  public isImageFrameUnavailable(sopInstanceUid: string, frameNumber: number): boolean {
    const isUnavailable =  this.unavailableSopInstances.get(sopInstanceUid) != null || this.unavailableImageFrames.get( makeImageKey(sopInstanceUid, frameNumber) ) != null;
    if (isUnavailable) {
      // console.log(`isImageFrameUnavailable returns TRUE`, sopInstanceUid, frameNumber);
    }
    return isUnavailable;
  }

  public imageFrameErrorCode(sopInstanceUid: string, frameNumber: number): number {
    let httpError = this.unavailableImageFrames.get(makeImageKey(sopInstanceUid, frameNumber));
    if (httpError === undefined) {
      httpError = this.unavailableSopInstances.get(sopInstanceUid);
    }
    return httpError ?? -1;
  }
}

// Provides access to a one-shot boolean BehaviorSubject through a Promise
class ReadyItem {
  private readyPromise: Promise<boolean> | null = null;
  private ready$$ = new ReplaySubject<boolean>(1);
  private itemHasBeenSet = false;

  constructor(private waitUntil$: Observable<any>, private defaultValue: boolean) {
  }

  // Signal that the item's boolean value is now available.
  public setItemReady(success: boolean): void {
    if (!this.itemHasBeenSet) {
      this.ready$$.next(success);
      this.itemHasBeenSet = true;
    }
  }

  // Wait for the item to be set. 'until' will force the promise to immediately complete with the value 'defaultValue'
 private async _waitForItemReady(): Promise<boolean> {
    try {
      return lastValueFrom(
        this.ready$$.pipe(
          take(1),
          takeUntil(this.waitUntil$)
        ),
        { defaultValue: this.defaultValue }  // this is returned if 'until' fires and completes the observable
      );
    } catch (err) {
      console.log(`_waitForItemReady - error`, err);
      console.error(`_waitForItemReady - error`);
      return false;
    }
  }

  public async waitForItemReady(): Promise<boolean> {
    if (this.readyPromise == null) {
      this.readyPromise = this._waitForItemReady();
    }
    return this.readyPromise;
  }
}

// Manage a map of ReadyItems
class ReadyItemsTracker {
  private map = new Map<string, ReadyItem>();
  constructor(private waitUntil$: Observable<any>, private defaultValue: boolean) { }

  public get size(): number {
    return this.map.size;
  }
  public setItemReady(key: string, success: boolean): void {
    this.getMapItemForKey(key).setItemReady(success);
  }

  public async waitForItemReady(key: string): Promise<boolean> {
    return this.getMapItemForKey(key).waitForItemReady();
  }

  private getMapItemForKey(key: string): ReadyItem {
    let readyItem = this.map.get(key);
    if (readyItem == null) {
      readyItem = new ReadyItem(this.waitUntil$, this.defaultValue);
      this.map.set(key, readyItem);
    }
    return readyItem;
  }
}
