import { AuthorizationToken, ExamGroupId, IExamGroupDefinition } from '@idgital/vision-auth-interface';

import { ExamGroupStore } from '../stores';

export class ExamGroupAuthorizationContext {
  examGroupStore: ExamGroupStore;
  accessTokens: AuthorizationToken[];

  constructor(tokens: AuthorizationToken[], target: ExamGroupStore) {
    this.examGroupStore = target;
    this.accessTokens = tokens;
  }

  public onExamGroupAccessAuthorized(tokenIndex: number, groupDefinition: IExamGroupDefinition): ExamGroupId {
    const accessToken = this.accessTokens[tokenIndex];
    const examGroup = this.examGroupStore.addOrUpdateExamGroup(groupDefinition, accessToken);
    return examGroup.groupId;
  }

  public onExamGroupAccessUnauthorized(tokenIndex: number, notAuthorized: boolean): void {
    /* Empty */
  }
}
