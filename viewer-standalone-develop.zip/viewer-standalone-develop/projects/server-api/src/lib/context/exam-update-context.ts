import { AuthorizationToken, IExamGroupExamInformation } from '@idgital/vision-auth-interface';
import { ExamId } from '@idgital/vision-interface';

import { ExamGroup } from '../models';

export class ExamUpdateContext {
  examGroup: ExamGroup;
  studyInstanceUID: ExamId;
  sopInstanceUID: string;
  dicomBuffer: ArrayBuffer;

  constructor(examGroup: ExamGroup, studyInstanceUID: ExamId, newSopInstanceUID: string, dicomBuffer: ArrayBuffer) {
    this.examGroup = examGroup;
    this.studyInstanceUID = studyInstanceUID;
    this.sopInstanceUID = newSopInstanceUID;
    this.dicomBuffer = dicomBuffer;
  }

  public get accessToken(): AuthorizationToken {
    return this.examGroup.accessToken;
  }

  public get forPrimaryExam(): boolean {
    return this.studyInstanceUID === this.examGroup.primaryExam.studyUID;
  }

  public onExamAccessUnauthorized(notAuthorized: boolean): void {
    /* Empty */
  }
}
