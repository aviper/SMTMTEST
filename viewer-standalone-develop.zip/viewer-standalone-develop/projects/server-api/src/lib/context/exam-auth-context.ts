import {
  AuthorizationToken,
  IExamGroupExamInformation,
} from '@idgital/vision-auth-interface';

import {
  ExamId,
} from '@idgital/vision-interface';
import { ExamGroup, ExamInformation } from '../models';

export class ExamAuthorizationContext {
  examGroup: ExamGroup;
  studyInstanceUID: ExamId;

  constructor(examGroup: ExamGroup, studyInstanceUID: ExamId) {
    this.examGroup = examGroup;
    this.studyInstanceUID = studyInstanceUID;
  }

  public get accessToken(): AuthorizationToken {
    return this.examGroup.accessToken;
  }

  public get forPrimaryExam(): boolean {
    return this.studyInstanceUID === this.examGroup.primaryExam.studyUID;
  }

  public onExamAccessAuthorized(examInformation: IExamGroupExamInformation): ExamInformation {
    if (this.studyInstanceUID !== this.examGroup.primaryExam.studyUID) {
      // This access check was for a comparison exam.
      // The comparison exam may not have been part of the exam group at the time the exam group access was resolved.
      return this.examGroup.addComparisonExam(examInformation);
    } else {
      // The access check was for the primary exam, which was already defined as part of the exam group.
      return this.examGroup.primaryExam;
    }
  }

  public onExamAccessUnauthorized(notAuthorized: boolean): void {
    /* Empty */
  }
}
