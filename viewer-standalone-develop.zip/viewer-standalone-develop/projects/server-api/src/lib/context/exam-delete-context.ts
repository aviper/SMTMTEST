import {
  AuthorizationToken
} from '@idgital/vision-auth-interface';

import {
  ExamId,
} from '@idgital/vision-interface';

import { ExamGroup } from '../models';
import { getDicomInstanceObjectKey } from '../utils/dicom-utils';

export interface IDicomInstance {
  studyInstanceUID: ExamId;
  seriesInstanceUID: string;
  sopInstanceUID: string | null;
}


export class ExamDeleteInstanceContext {
  examGroup: ExamGroup;
  dicomInstance: IDicomInstance;

  constructor(examGroup: ExamGroup, dicomInstance: IDicomInstance) {
    this.examGroup = examGroup;
    this.dicomInstance = dicomInstance;
  }

  public get accessToken(): AuthorizationToken {
    return this.examGroup.accessToken;
  }

  public get forPrimaryExam(): boolean {
    return this.dicomInstance.studyInstanceUID === this.examGroup.primaryExam.studyUID;
  }

  public onExamAccessUnauthorized(notAuthorized: boolean): void {
    /* Empty */
  }

  public get studyInstanceUID(): ExamId {
    return this.dicomInstance.studyInstanceUID;
  }

  public get sopInstanceUID(): string | null {
    return this.dicomInstance.sopInstanceUID;
  }

  public get objectKey(): string {
    return getDicomInstanceObjectKey(this.dicomInstance);
  }
}
