import { ExamGroup } from '../models';
import { AuthorizationToken, IExamGroupDefinition, ExamGroupId } from '@idgital/vision-auth-interface';

export class ExamGroupStore {
  public allExamGroups: ExamGroup[];
  public indexByGroupId: Map<ExamGroupId, ExamGroup>;
  public indexByAuthToken: Map<AuthorizationToken, ExamGroup>;

  constructor() {
    this.allExamGroups = [];
    this.indexByGroupId = new Map();
    this.indexByAuthToken = new Map();
  }

  examGroupIdForOrderId(orderId: number): ExamGroupId {
    return orderId.toString();
  }

  addOrUpdateExamGroup(groupDefinition: IExamGroupDefinition, accessToken: AuthorizationToken): ExamGroup {
    const groupId = this.examGroupIdForOrderId(groupDefinition.orderId);
    let examGroup = this.indexByGroupId.get(groupId);
    if (examGroup !== undefined) {
      // Update an existing exam group - the access token may have changed.
      const priorAccessToken = examGroup.accessToken;
      examGroup.accessToken = accessToken;
      this.indexByAuthToken.delete(priorAccessToken);
      this.indexByAuthToken.set(accessToken, examGroup);
      // Update an existing exam group - user permissions or preferences may have changed.
      examGroup.user.update(groupDefinition);
      // Update an existing exam group - comparison exams may have been added.
      // - Explicitly not handling removal here, because such an operation makes no logical sense.
      for (const examDefinition of groupDefinition.comparisons) {
        examGroup.addComparisonExam(examDefinition);
      }
    } else {
      // Create a new exam group.
      examGroup = new ExamGroup(groupId, accessToken, groupDefinition);
      this.allExamGroups.push(examGroup);
      this.indexByGroupId.set(groupId, examGroup);
      this.indexByAuthToken.set(accessToken, examGroup);
    }
    return examGroup;
  }

  findExamGroupById(id: ExamGroupId): ExamGroup | undefined {
    return this.indexByGroupId.get(id);
  }

  findExamGroupByToken(accessToken: AuthorizationToken): ExamGroup | undefined {
    return this.indexByAuthToken.get(accessToken);
  }

  dropExamGroup(id: ExamGroupId): void {
    const examGroup = this.indexByGroupId.get(id);
    if (examGroup === undefined) {
      return;
    }
    const accessToken = examGroup.accessToken;
    let targetIndex = 0;
    for (const examGroup of this.allExamGroups) {
      if (examGroup.groupId !== id) {
        targetIndex++;
      } else {
        break;
      }
    }
    this.allExamGroups.splice(targetIndex, 1);
    this.indexByGroupId.delete(id);
    this.indexByAuthToken.delete(accessToken);
  }

  orderExamGroupsByTokenOrder(tokens: AuthorizationToken[]): void {
    const examGroups: ExamGroup[] = [];
    for (const token of tokens) {
      const group = this.findExamGroupByToken(token);
      if (group != null) {
        examGroups.push(group);
      }
    }
    this.allExamGroups = examGroups;
  }
}
