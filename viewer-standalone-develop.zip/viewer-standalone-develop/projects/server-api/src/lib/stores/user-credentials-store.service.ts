import { Injectable } from '@angular/core';

import { AuthenticationToken, UserId } from '@idgital/vision-auth-interface';
import { UserCredentials } from '../utils';

@Injectable({
  providedIn: 'root'
})
export class UserCredentialsStoreService {
  private credentials: UserCredentials | null;

  constructor() {
    this.credentials = UserCredentials.fromStorage();
  }

  public get current(): UserCredentials | null {
    return this.credentials;
  }

  public update(userId: UserId, authToken: AuthenticationToken): void {
    this.credentials = new UserCredentials(userId, authToken);
  }

  public invalidate(): void {
    this.credentials = null;
  }
}
