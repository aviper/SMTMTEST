import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

import Fovia from 'foviaapi';
import { LogSupport, LOG_LEVEL, LOG_SCOPE } from './log-support';
import { promiseTimeout } from '../utils';
import { extractErrorCodeFromException,PV_ERRORS } from '@worker-compatible-api';
import { AuthenticationToken, UserId } from '@idgital/vision-auth-interface';

/**
 * Manages the connection with the Fovia render server.
 */
@Injectable({
  providedIn: 'root'
})
export class FoviaConnectService implements OnDestroy {
  private unsubscribe$$: Subject<void> = new Subject<void>();
  private connected$$: BehaviorSubject<boolean | null> = new BehaviorSubject<boolean | null>(null);
  public connected$: Observable<boolean | null> = this.connected$$;
  public sessionLost = false;
  public lastConnectionResult: Fovia.ReturnCode | null = null;
  public requestedTermination = false;

  // Note: The Fovia client API only supports a single active connection due to use of global state.
  public clientId: string | null = null;
  public serverContext: Fovia.ServerContext | null = null;
  private serverPromise: Promise<Fovia.ServerContext> | null = null;
  private serverLocation: URL | undefined = undefined;
  private static connectionCount = 0;

  public constructor() {
    this.subscriptions();
  }

  /**
   * Retrieve the server connection status.
   */
  public get connected(): boolean {
    return this.connected$$.value == null ? false : this.connected$$.value;
  }

  public foviaConnectionOptions(userId: UserId, userAuthToken: AuthenticationToken, sessionId: string): any {
    return {
      headers: {
        'userid': userId,
        'userauthtoken': userAuthToken/*,
        'fovia-session-id': sessionId*/
      }
    };
  }
  
  // TEMP TEMP until fovia starts returning return codes for SDK Mismatch etc.
  public async requestServerConnectionWithTimeout(url: string | URL, userId: UserId, userAuthToken: AuthenticationToken, sessionId: string): Promise<Fovia.ServerContext | null> {
    const TIMEOUT = 10000; // 10s
    const requestPromise = this.requestServerConnection(url, userId, userAuthToken, sessionId);
    let result: Fovia.ServerContext | null = null;
    try {
      result = await promiseTimeout<Fovia.ServerContext, PV_ERRORS>(requestPromise, TIMEOUT, PV_ERRORS.TIMEOUT);
    } catch(err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`requestServerConnectionWithTimeout exception promise timed out for (${url}) ${TIMEOUT/1000} sec ${errCode}`);
      // When we timeout, ensure we emit the result as a failed connection so we can retry.
      this.notifyConnected = false;
    }
    return result;

  }
  /**
   * Attempt to establish a connection to the render server.
   * When the connection is established, the `connected$$` signal will become `true`.
   * @param url The URL of the render server, including port.
   * @param userId The internal SynthOS user identifier of the user connecting to the system.
   * @param userAuthToken The current authentication token of the user connecting to the system.
   * @param sessionId A unique identifier for the Fovia session, used for load balancing.
   * @returns A `Promise` that can be used to `await` the connection result.
   */
  public requestServerConnection(url: string | URL, userId: UserId, userAuthToken: AuthenticationToken, sessionId: string): Promise<Fovia.ServerContext> {
    try {
      if (!(url instanceof URL)) {
        url = new URL(url);
      }
      // Note: Do not check `connected` here.
      // A connection may have been requested, but not yet established.
      if (this.serverPromise !== null) {
        // Detect (and fail) the case where a connection to a different server is requested.
        if (this.serverLocation !== undefined) {
          const urlExisting = this.serverLocation.toString();
          const urlRequested = url.toString();
          if (urlExisting === urlRequested) {
            // Same target => return the existing promise.
            return this.serverPromise;
          } else {
            // Different target => fail.
            return new Promise((_, reject) => {
              reject(`Cannot connect to multiple render server instances simultaneously.\n  Requested: ${urlRequested}\n  Existing: ${urlExisting}`);
            });
          }
        }
      }

      console.log(`${this.constructor.name} requestServerConnection render server ${url.toString()}.`);

      const protocol = url.protocol;
      const host = url.hostname;
      let port = url.port;
      const resolvedUrl = url;
      if (!port && protocol.startsWith('https')) {
        port = '443';
      }

      const foviaTransport = undefined;
      const foviaAuthToken = undefined;
      const foviaOptions = this.foviaConnectionOptions(userId, userAuthToken, sessionId);
      const markConnectInit = 'fovia-connect-init';
      const markConnectDone = 'fovia-connect-done';
      const spanConnect = 'fovia-connect';

      document.cookie = `fovia_route=${sessionId}; domain=${host}; path=/socket.io/; SameSite=Lax; Secure`;

      this.requestedTermination = false;
      this.serverLocation = url;
      this.serverPromise = new Promise((resolve, reject) => {
        performance.mark(markConnectInit, {
          detail: {
            server: url.toString(),
            token: userAuthToken
          }
        });
        this.lastConnectionResult = null;
        Fovia.FoviaAPI.requestServerConnection(
          (result: Fovia.ReturnCode) => {
            let clientId = null;
            this.lastConnectionResult = result;
            if (result !== undefined && result === Fovia.ReturnCode.ok) {
              clientId = Fovia.ServerContext.getClientID();
            }
            performance.mark(markConnectDone, {
              detail: {
                server: url.toString(),
                token: userAuthToken,
                status: result,
                clientId
              }
            });
            performance.measure(spanConnect, {
              start: markConnectInit,
              end: markConnectDone,
              detail: {
                server: url.toString(),
                token: userAuthToken,
                status: result,
                clientId
              }
            });
            this.handleServerConnectionResult(resolvedUrl, result);
            if (result !== undefined && result !== Fovia.ReturnCode.ok) {
              reject(result);
              this.serverContext = null;
              this.serverPromise = null;
              this.serverLocation = undefined;
            } else {
              this.serverContext = Fovia.ServerContext;
              this.clientId = Fovia.ServerContext.getClientID();
              console.log(`${this.constructor.name} requestServerConnection resolves new connection ${url.toString()}.`);
              resolve(Fovia.ServerContext);
            }
          },
          (err: unknown) => {
            this.handleFatalServerError(err);
          },
          (reason: Fovia.DisconnectCode) => {
            this.handleServerDisconnection(reason);
          },
          host, port, protocol, foviaTransport, foviaAuthToken, foviaOptions
        );
      });
      return this.serverPromise;

    } catch (err) { // Error parsing URL, etc.
      return new Promise((_, reject) => {
        console.error(`${this.constructor.name} Exception while connecting to the render server at ${url.toString()}`, err);
        reject(err);
      });
    }
  }

  /**
   * Request immediate termination of the client's connection to the server.
   * Any server-side resources associated with the client connection and cache session are unloaded.
   */
  public async terminateServerConnection(): Promise<unknown> {
    if (Fovia && Fovia.ServerContext && this.clientId) {
      console.log(`Requesting termination of server session '${this.clientId}'`);
      performance.mark(`fovia-terminate-${this.clientId}`);
      this.requestedTermination = true;
      return Fovia.ServerContext.terminateServerConnection()
        .catch(err => {
          console.error(`Terminating render server connection '${this.clientId}' failed`, err);
        })
        .finally(() => {
          this.clientId = null;
          this.serverContext = null;
          this.serverLocation = undefined;
          this.serverPromise = null;
          this.sessionLost = true;
          this.notifyConnected = false;
        });
    } else {
      return new Promise((resolve, reject) => {
        console.log(`No server session to terminate`);
        resolve(Fovia.ReturnCode.ok);
      });
    }
  }

  private set notifyConnected(value: boolean) {
    queueMicrotask(() => {
      this.connected$$.next(value);
    });
  }
  /**
   * Perform any initialization necessary when the connection to the server is restored
   * after a temporary connection loss, but the server-side session was _not_ lost.
   */
  private onServerSessionRestored(): void {
  }

  /**
   * Perform any cleanup necessary after the server session has been terminated.
   * Note that any server-side resources have been lost by the time this condition is reported.
   * @param unexpectedTermination This value is `true` if the server session was terminated unexpectedly.
   */
  private onServerSessionTerminated(unexpectedTermination: boolean): void {
    if (unexpectedTermination) {
    } else {
      // This is an expected termination, no notification required
    }
    this.clientId = null;
    this.serverContext = null;
    this.serverLocation = undefined;
    this.serverPromise = null;
    this.sessionLost = true;
  }

  /**
   * Handle Fovia reporting the result of a connection attempt.
   * This function always runs _prior_ to the server connection promise being resolved.
   * @param url The URL of the render server.
   * @param result The result of the connection attempt.
   */
  private handleServerConnectionResult(url: URL, result: Fovia.ReturnCode): void {
    if (result === undefined || result === Fovia.ReturnCode.ok) {
      this.serverContext = Fovia.ServerContext;
      // Notify any listeners that the connection is established.
      this.sessionLost = false;
      this.notifyConnected = true;
      console.info(`${this.constructor.name} The render server connection to ${url} has been established.`);
      LogSupport.logInfo(`The render server connection to ${url} has been established.`);
    } else {
      // Anything other than Fovia.ReturnCode.ok is an error.
      // Clearing of connection-related fields happens in the anonymous wrapper callback in requestServerConnection.
      LogSupport.logError(`The render server connection to ${url} could not be established: ${result}.`);
      console.error(`${this.constructor.name} The render server connection to ${url} could not be established: ${result}.`);
    }
  }

  /**
   * Handle Fovia reporting a loss of connection to the server.
   * @param err Additional information describing the reason for the disconnection, and indicating whether it may be recoverable.
   */
  private handleServerDisconnection(err: Fovia.DisconnectCode): void {
    const markReconnected = `fovia-reconnect-${this.clientId}`;
    const markDisconnected = `fovia-disconnect-${this.clientId}`;

    if (err === Fovia.DisconnectCode.networkReconnected) {
      const oldClientId = this.clientId;
      const newClientId = Fovia.ServerContext.getClientID();
      const message = `The render server connection has been restored without losing the current session (oldClientId=${oldClientId}, newClientId=${newClientId})`;
      performance.mark(markReconnected, {
        detail: {
          oldClientId,
          newClientId
        }
      });
      performance.measure('fovia-connection-lost', {
        start: markDisconnected,
        end: markReconnected,
        detail: {
          clientId: this.clientId
        }
      });
      this.clientId = newClientId;
      this.onServerSessionRestored();
      this.sessionLost = false;
      this.notifyConnected = true;
      LogSupport.logInfo(message);
      console.info(message);
      return;
    }

    let unexpectedTermination = true;
    if (this.requestedTermination) {
      unexpectedTermination = false;
    }

    if (err === Fovia.DisconnectCode.lossOfNetwork) {
      this.sessionLost = false;
    } else {
      this.sessionLost = true;
    }

    performance.mark(markDisconnected, {
      detail: {
        clientId: this.clientId,
        reason: Fovia.DisconnectCode[err]
      }
    });

    switch (err) {
      case Fovia.DisconnectCode.connectionTerminated: { // Assume intentional disconnection here.
        const message = `The render server connection '${this.clientId}' has been terminated`;
        this.onServerSessionTerminated(unexpectedTermination);
        this.sessionLost = true;
        LogSupport.logInfo(message);
        console.info(message);
      } break;

      case Fovia.DisconnectCode.sessionTimeoutDueToInactivity:
      case Fovia.DisconnectCode.maxNumberOfConnectionsReached: { // This is fatal, the server node is nuking our session.
        const message = `The render server has forcefully terminated connection '${this.clientId}' (DisconnectCode ${Fovia.DisconnectCode[err]})`;
        this.onServerSessionTerminated(unexpectedTermination);
        this.sessionLost = true;
        LogSupport.logError(message);
        console.error(message);
      } break;

      case Fovia.DisconnectCode.lossOfNetwork: { // This is temporary, we may be able to reconnect.
        const message = `The render server connection '${this.clientId}' has been lost, but the server session is not disconnected`;
        this.sessionLost = false;
        LogSupport.logError(message);
        console.error(message);
      } break;
    }

    this.notifyConnected = false;
  }

  /**
   * Handle an _unrecoverable_ server error being reported by Fovia on the current `Fovia.ServerContext`.
   * @param err Additional information associated with the error.
   */
  private handleFatalServerError(err: unknown): void {
    let unexpectedTermination = true;
    if (this.requestedTermination) {
      unexpectedTermination = false;
    }

    performance.mark('fovia-session-lost', {
      detail: {
        clientId: this.clientId,
        error: err
      }
    });

    if (unexpectedTermination) {
      const message = `A fatal error was reported by the render server for connection '${this.clientId}'`;
      LogSupport.logError(message);
      console.error(message, err);
    }

    this.onServerSessionTerminated(unexpectedTermination);
    this.sessionLost = true;
    this.notifyConnected = false;
  }

  private subscriptions(): void {
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

  public ngOnDestroy(): void {
    this.terminateServerConnection().then();
    this.unsubscribe();
  }
}
