import Fovia from 'foviaapi';

export enum LOG_LEVEL {
  DEBUG = Fovia.Logger.level.debug,
  INFO = Fovia.Logger.level.info,
  WARNING = Fovia.Logger.level.warn,
  ERROR = Fovia.Logger.level.error,
  FORCE_DEBUG = 1000,
  FORCE_INFO = 1001
}

export enum LOG_SCOPE {
  EXAM,
  IMAGE,
  SYSTEM,
}

export enum LOG_SOURCE {
  CACHE,
  CORE,
  VIEWER,
  UNKNOWN,
}

class QueuedMessage {
  constructor(public level: LOG_LEVEL, public scope: LOG_SCOPE, public message: string, public details: string[] = []) {
  }
}

export class LogSupport {
  private sessionID: string | null = null;
  private source = LOG_SOURCE.UNKNOWN;
  private userID = 'Unknown';
  private queuedMessages: QueuedMessage[] = [];
  private static _instance: LogSupport;

  constructor() { }

  public static setSource(userId: string, source: LOG_SOURCE): void {
    this.instance.userID = userId;
    this.instance.source = source;
    Fovia.Logger.setDebugLevel(LOG_LEVEL.INFO);
  }

  public static setSession(sessionId: string): void {
    this.instance.sessionID = sessionId;
    Fovia.Logger.setDebugLevel(LOG_LEVEL.INFO);
  }

  public static isConnected(): boolean {
    return Fovia.Logger.isInitialized();
  }

  public static set level(level: LOG_LEVEL) {
    let foviaLevel = level;

    // We have a couple extra levels that Fovia wouldn't understand, so translate for Fovia.
    if (level === LOG_LEVEL.FORCE_DEBUG) {
      foviaLevel = LOG_LEVEL.DEBUG;
    } else if (level === LOG_LEVEL.FORCE_INFO) {
      foviaLevel = LOG_LEVEL.INFO;
    }
    Fovia.Logger.setDebugLevel(foviaLevel);
  }

  public static get level(): LOG_LEVEL {
    return Fovia.Logger.currentDebugLevel;
  }

  //  EXAM scope -- provide study UID in the exam parameter
  //  IMAGE scope -- also provide image UID in the image parameter
  public static logDebug(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.DEBUG, message, scope, exam, image);
  }
  public static logInfo(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.INFO, message, scope, exam, image);
  }
  public static logForceDebug(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.FORCE_DEBUG, message, scope, exam, image);
  }
  public static logForceInfo(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.FORCE_INFO, message, scope, exam, image);
  }
  public static logWarn(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.WARNING, message, scope, exam, image);
  }
  public static logError(message: string, scope: LOG_SCOPE = LOG_SCOPE.SYSTEM, exam: string = '', image: string = ''): void {
    this.instance.log(LOG_LEVEL.ERROR, message, scope, exam, image);
  }

  private static get instance(): LogSupport {
    if (!this._instance) {
      this._instance = new LogSupport();
    }

    return this._instance;
  }

  private log(level: LOG_LEVEL, message: string, scope: LOG_SCOPE, exam: string = '', image: string = ''): void {
    const details: string[] = [];

    // Use the 'not provided' placeholder in case a dev failed to provide them for IMAGE or EXAM scope.
    details.push(exam === '' ? 'not provided' : exam);
    details.push(image === '' ? 'not provided' : image);

    if (LogSupport.isConnected()) {
      // Once we're called with the Fovia logger initialized we'll finish any messages we queued up
      // while we waited and then clear the queue.
      if (this.queuedMessages.length > 0) {
        for (const item of this.queuedMessages) {
          this.logMessage(item.level, item.scope, item.message, item.details);
        }
        this.queuedMessages = [];
      }

      this.logMessage(level, scope, message, details);
    } else {
      // If the Fovia logger isn't ready we queue up the message for later.
      this.queuedMessages.push(new QueuedMessage(level, scope, message, details));
    }
  }

  private logMessage(level: LOG_LEVEL, scope: LOG_SCOPE, message: string, details: string[]): void {
    // It would be neat to customize and use Fovia's prefix, but it's private
    // and Logger doesn't supply a getter. So once we set it all log messages
    // use that same prefix.
    const currentLevel = Fovia.Logger.currentDebugLevel;
    if (level === LOG_LEVEL.FORCE_DEBUG || level === LOG_LEVEL.FORCE_INFO) {
      // If we're told to force the log entry we may need up raise the log level temporarily.
      Fovia.Logger.setDebugLevel(level === LOG_LEVEL.FORCE_DEBUG ? LOG_LEVEL.DEBUG : LOG_LEVEL.INFO);
    }

    message = `${this.buildPrefix(scope, details)}, message: ${message}`;
    switch (level) {
      case LOG_LEVEL.DEBUG:
      case LOG_LEVEL.FORCE_DEBUG:
        Fovia.Logger.debug(message);
        break;
      case LOG_LEVEL.ERROR:
        Fovia.Logger.error(message);
        break;
      case LOG_LEVEL.INFO:
      case LOG_LEVEL.FORCE_INFO:
        Fovia.Logger.info(message);
        break;
      case LOG_LEVEL.WARNING:
        Fovia.Logger.warn(message);
        break;
    }
    // Set the log level back to what it was in case we changed it for a FORCE.
    Fovia.Logger.setDebugLevel(currentLevel);
  }

  private buildPrefix(scope: LOG_SCOPE, details: string[]): string {
    let prefix = `Synthesis - app: ${LOG_SOURCE[this.source]}, scope: ${LOG_SCOPE[scope]}, session: ${this.sessionID}, user: ${this.userID} `;

    switch (scope) {
      case LOG_SCOPE.EXAM:
        prefix += `study UID: ${details[0]}`;
        break;
      case LOG_SCOPE.IMAGE:
        if (details.length === 1) {
          details.push('not provided');
        }
        prefix += `study UID: ${details[0]} instance UID: ${details[1]}`;
        break;
      case LOG_SCOPE.SYSTEM:
        break;
    }
    return prefix;
  }
}
