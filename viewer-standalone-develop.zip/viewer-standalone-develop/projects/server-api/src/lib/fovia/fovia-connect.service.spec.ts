import { TestBed } from '@angular/core/testing';

import { FoviaConnectService } from './fovia-connect.service';

describe('FoviaConnectService', () => {
  let service: FoviaConnectService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FoviaConnectService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
