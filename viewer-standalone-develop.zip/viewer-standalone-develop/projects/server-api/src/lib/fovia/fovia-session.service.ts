import { Injectable } from '@angular/core';
import { uuid4 } from '../utils';
import { ExamGroupId } from '@idgital/vision-auth-interface';

/**
 * Manages the connection with the Fovia render server.
 */
@Injectable({
  providedIn: 'root'
})
export class FoviaSessionService {
  private _sessionId: string | null = null;

  public constructor() {
  }

  public get current(): string | null {
    return this._sessionId;
  }

  public generateNew(examGroupId: ExamGroupId | null=null): string {
    if (examGroupId) {
        this._sessionId = `${uuid4()}-${examGroupId}`;
    } else {
        this._sessionId = uuid4();
    }
    return this._sessionId;
  }
}
