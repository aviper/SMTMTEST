import { TestBed } from '@angular/core/testing';

import { LogSupport } from './log-support';

describe('LogSupport', () => {
  let service: FoviaLogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FoviaLogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
