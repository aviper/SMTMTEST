import Fovia from 'foviaapi';

export enum ERROR_CODES {
  NO_ERROR = 'No Error',
  NO_FOVIA_3D_LICENSE = '3D Not licensed',
  FOVIA_ERROR = 'Error returned from Fovia',
}

export interface ISaveResultStatus {
  resultCode: Fovia.ReturnCode; // All non-ok returns are bad news, ok returns are ambiguous -- ok, nothing to do; ok, saved ok, etc.
  hadChanges: boolean; // New objects were saved, when no GSPS objects were modified nothing is changed and return code is ok.
  metadata: Fovia.NonImageSeriesDataContext | null; // Note: Not always present in result, even if save completed successfully.
  datasets: Map<string, ArrayBuffer>; // Map of SOP Instance UID to the ArrayBuffer containing the Part10 data - empty if nothing needs to be stored back to the datasource.
}

export class SaveResultStatus implements ISaveResultStatus {
  public resultCode: Fovia.ReturnCode = Fovia.ReturnCode.ok;
  public hadChanges = false;
  public metadata: Fovia.NonImageSeriesDataContext | null = null;
  public datasets = new Map<string, ArrayBuffer>();

  constructor(status: Fovia.ReturnCode= Fovia.ReturnCode.ok, hadChanges: boolean= false) {
    this.resultCode = status;
    this.hadChanges = hadChanges;
  }
}
