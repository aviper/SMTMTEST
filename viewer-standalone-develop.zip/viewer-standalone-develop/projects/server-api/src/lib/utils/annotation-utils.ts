import { getPendingRenderParams2D } from './fovia-utils';
import Fovia from 'foviaapi';

// Make a deep copy of an existing annotation
export function cloneAnnotation(source: Fovia.GraphicAnnotation): Fovia.GraphicAnnotation {
  if (source instanceof Fovia.PointGraphicAnnotation) {
    return new Fovia.PointGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
  }
  if (source instanceof Fovia.PolylineGraphicAnnotation) {
    return new Fovia.PolylineGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
  }
  if (source instanceof Fovia.AngleGraphicAnnotation) {
    return new Fovia.AngleGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
  }
  if (source instanceof Fovia.CircleGraphicAnnotation) {
    const clone = new Fovia.CircleGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
    clone.setBoundingPoints();
    return clone;
  }
  if (source instanceof Fovia.EllipseGraphicAnnotation) {
    return new Fovia.EllipseGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
  }
  if (source instanceof Fovia.TextGraphicAnnotation) {
    return new Fovia.TextGraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
  }
  return new Fovia.GraphicAnnotation(source.graphicLayer, source.graphicObjects, source.textObjects, source.referencedImageSequence, source.graphicLayerIndex, source.annotationColor);
}

// Add a set of annotations to the current image of a render engine
export function addAnnotationsToRenderEngine(annotations: Fovia.GraphicAnnotation[], sopInstanceUid: string, frameNumber: number, vp: Fovia.UI.HTMLDoubleBufferViewport2D): void {
  if (annotations.length === 0) {
    return;
  }
  const renderEngine = vp.getRenderEngine();
  const rp = getPendingRenderParams2D(vp);
  const tags = renderEngine.getSeriesDataContext().imageTags[rp.imageNumber];
  if (tags.sopInstanceUID !== sopInstanceUid || tags.frameNumber !== frameNumber) {
    console.error(`addAnnotationsToRenderEngine:  Can only add annotations to render engine's current image.  sopInstanceUid=${sopInstanceUid}, frameNumber=${frameNumber}`);
    return;
  }
  for (const annotation of annotations) {
    addAnnotation(annotation, sopInstanceUid, frameNumber, renderEngine);
  }
}

function addAnnotation(annotation: Fovia.GraphicAnnotation, sopInstanceUid: string, frameNumber: number, renderEngine: Fovia.RenderEngineContext2D): boolean {
  annotation.setIsNewFlag(true);
  annotation.setShowLabelFlag(true);
  if (annotation instanceof Fovia.PointGraphicAnnotation) {
    return renderEngine.addPointAnnotation(annotation as Fovia.PointGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  if (annotation instanceof Fovia.PolylineGraphicAnnotation) {
    return renderEngine.addLineAnnotation(annotation as Fovia.PolylineGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  if (annotation instanceof Fovia.AngleGraphicAnnotation) {
    return renderEngine.addAngleAnnotation(annotation as Fovia.AngleGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  if (annotation instanceof Fovia.CircleGraphicAnnotation) {
    return renderEngine.addCircleAnnotation(annotation as Fovia.CircleGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  if (annotation instanceof Fovia.EllipseGraphicAnnotation) {
    return renderEngine.addEllipseAnnotation(annotation as Fovia.EllipseGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  if (annotation instanceof Fovia.TextGraphicAnnotation) {
    return renderEngine.addTextAnnotation(annotation as Fovia.TextGraphicAnnotation, sopInstanceUid, frameNumber);
  }
  return false;
}
