import { AuthenticationToken, UserId } from '@idgital/vision-auth-interface';

export const USER_TOKEN_KEY = 'token';
export const USER_ID_KEY = 'userId';

// Note - using the getSynthUserId and getSynthUserToken functions requires that the calling application
// share the same origin as the SynthOS frontend.

export function getSynthUserId(): number | null {
  const userIdStr = localStorage.getItem(USER_ID_KEY);
  if (!userIdStr) {
    return null;
  } else {
    return parseInt(userIdStr, 10);
  }
}

export function getSynthUserToken(): string | null {
  const userToken = sessionStorage.getItem(USER_TOKEN_KEY);
  // console.log(`getSynthUserToken returns ${userToken}`, sessionStorage);
  return userToken;
}

export class UserCredentials {
  private _userId: UserId;
  private _authToken: AuthenticationToken;

  constructor(id: UserId, token: AuthenticationToken) {
    this._userId = id;
    this._authToken = token;
  }

  public get userId(): UserId {
    return this._userId;
  }

  public get authToken(): AuthenticationToken {
    return this._authToken;
  }

  static fromStorage(): UserCredentials | null {
    const userId = getSynthUserId();
    const token = getSynthUserToken();

    if (userId != null && token != null) {
      return new UserCredentials(userId, token);
    } else {
      return null;
    }
  }
}
