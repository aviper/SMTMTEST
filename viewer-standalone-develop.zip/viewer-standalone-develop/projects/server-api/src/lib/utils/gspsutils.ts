import Fovia from 'foviaapi';
import dayjs from 'dayjs';
import dayjsPluginUTC from 'dayjs/plugin/utc';
import { HTMLViewport2DGSPS } from '../models';
import { ISaveResultStatus, SaveResultStatus } from './error-codes';
import {
  SYNTH_CONTENT_LABEL,
  SYNTH_CONTENT_DESC_PR,
  SYNTH_CREATOR_NAME
} from './dicom-constants';
import RenderEngineContext2D = Fovia.RenderEngineContext2D;
import { IDicomInstance } from '../context';

const CADSR_CONTENT_LABEL = 'CADSR';

export interface DicomTag {
  group: Number;
  element: Number;
  tagValue: any;
}

 export class PresentationInfo {

  public compareContentCreationTime(info: PresentationInfo): number {
    return info.getContentCreationDateTimeInDICOMFormat().localeCompare(this.getContentCreationDateTimeInDICOMFormat());
  }

  constructor(private prInstance: any, private modality: string = 'PR') { }

  public getLabel(): string {
    if (this.prInstance) {
      if (this.modality === 'PR') {
        const str = this.getDateStr(this.prInstance.presentationCreationDate, this.prInstance.presentationCreationTime);
        return this.prInstance.contentDescription + '-' + this.prInstance.contentLabel + ' (' + str + ')';
      } else {
        const str = this.getDateStr(this.prInstance.seriesDate, this.prInstance.seriesTime);
        return 'KO' + ' (' + str + ')';
      }
    }
    return '';
  }

  private getContentCreationDateTimeInDICOMFormat(): string {
    let str = '';
    if (this.modality === 'PR') {
      str = this.prInstance.presentationCreationDate;
      if (this.prInstance.presentationCreationTime) {
        str = str + ' ' + this.prInstance.presentationCreationTime;
      }
    } else {
      str = this.prInstance.seriesDate;
      if (this.prInstance.seriesTime) {
        str = str + ' ' + this.prInstance.seriesTime;
      }
    }
    return str;
  }

  public getPRInstance(): any {
    return this.prInstance;
  }

  private validateNumber(num: number, upperRange: number, lowerRange: number, errorMessage: string): void {
    if (num > upperRange || num < lowerRange) {
      throw Error(errorMessage);
    }
  }

  private validateStringLength(str: string, length: number, errorMessage: any): void {
    if (str && str.length < length) {
      throw Error(errorMessage);
    }
  }

  public parseDate(strDate: string, strTime: string): Date {
    const error = 'Invalid Date Format';
    this.validateStringLength(strDate, 8, error);

    const year = parseInt(strDate.substring(0, 4));
    const month = parseInt(strDate.substring(4, 6));
    const day = parseInt(strDate.substring(6, 8));

    this.validateNumber(month, 12, 1, error);
    this.validateNumber(month, 31, 1, error);
    const date = new Date();
    date.setFullYear(year, month, day);
    if (strTime) {
      this.validateStringLength(strTime, 6, error);
      const hh = parseInt(strTime.substring(0, 2));
      this.validateNumber(hh, 23, 0, error);

      const mm = parseInt(strTime.substring(2, 4));
      this.validateNumber(mm, 59, 0, error);
      const ss = parseInt(strTime.substring(4, 6));
      this.validateNumber(ss, 59, 0, error);
      date.setHours(hh);
      date.setMinutes(mm);
      date.setSeconds(ss);

    }
    return date;
  }

  public getDateStr(strDate: string, strTime: string): string {
    const error = 'Invalid Date Format';
    this.validateStringLength(strDate, 8, error);

    const year = (strDate.substring(0, 4));
    const month = (strDate.substring(4, 6));
    const day = (strDate.substring(6, 8));

    let str = month + '/' + day + '/' + year;
    if (strTime) {
      this.validateStringLength(strTime, 6, error);
      const hh = strTime.substring(0, 2);
      const mm = strTime.substring(2, 4);
      const ss = strTime.substring(4, 6);
      str = str + ' ' + hh + ':' + mm + ':' + ss;
    }
    return str;
  }
}

export class GSPSUtils {
  // added for processing and saving of non-image objects
  private nonImageSeriesResults: Fovia.NonImageSeriesResults | null = null;
  private readonly presentationSeriesGroup: Fovia.PresentationSeriesGroup;
  private viewports: Array<HTMLViewport2DGSPS> = [];
  private showFindingThreshold = 0;
  private static instance: GSPSUtils;
  private convertTxtObjToTxtAnn = false;
  private dicomElementDataList: Array<DicomTag>;
  private _primaryStudyInstanceUID = '';
  private _annotationModified = false;

  // track if a CAD SR has been processed for a given SDC (tracked by series uid)
  private _processedCADForSDC: Map<string, string[]> = new Map<string, string[]>; // <seriesUID, cadSr_sopinstanceUIDs>

  /**
   * To create an object provide list of viewports, number of columns and rows and flag to state whether to handle window resizing
   */
  private constructor() {
    this.presentationSeriesGroup = new Fovia.PresentationSeriesGroup();

    // This is the only place we can provide the TYPE 1 tags required by GSPS Content
    this.dicomElementDataList = [
      { group: 0x0070, element: 0x0080, tagValue: SYNTH_CONTENT_LABEL },  // Type 1
      { group: 0x0070, element: 0x0081, tagValue: SYNTH_CONTENT_DESC_PR }, // Type 2
      { group: 0x0070, element: 0x0084, tagValue: SYNTH_CREATOR_NAME },   // Type 2 (should be the persons name creating this, should be followed by 0040,1101 Persion ID Code sequence
      { group: 0x0008, element: 0x103e, tagValue: SYNTH_CONTENT_DESC_PR },
    ];
  }

  public static getInstance(): GSPSUtils {
    if (!this.instance) {
      this.instance = new GSPSUtils();
    }

    return this.instance;
  }

  public static reInit(): void {
    this.instance = new GSPSUtils();
  }

  public setViewport(viewport: any): void {
    // This is different from fovia's version. No isViewportExist() check
    this.viewports.push(viewport);
  }

  /**
   * Get PresentationSeriesGroup. It contains basic presentation and context details as description
   *
   * @returns An Fovia.PresentationSeriesGroup object
   *
   */
  public getPresentationSeriesGroup(): Fovia.PresentationSeriesGroup {
    return this.presentationSeriesGroup;
  }

  /**
   * Get list of presentation data information. It contains basic presentation and context details as description
   *
   * @returns An array of Fovia.Util.IPresentationDataContext object
   *
   */
  public getPresentationDataList(): Fovia.Util.IPresentationDataContext[] {
    let presentationData: Fovia.Util.IPresentationDataContext[] = [];
    if (this.presentationSeriesGroup != null) {
      presentationData = this.presentationSeriesGroup.getPresentationInfo();
    }
    return presentationData;
  }
  /**
	 * Send DICOM files to server using STOW RS
	 * @param files
	 * @param studyInstanceUID
	 * @param stowRSProvider
	 */
  public sendDICOMFiles(files: string[], studyInstanceUID: string, stowRSProvider: string): void{
    const json = {
      pluginjs: 'jsplugin_wado/stow-rs-plugin',
      studyInstanceUID: studyInstanceUID,
      fileNames: files,
      stowRSProvider: stowRSProvider,
      stowEndpoint: null, // fixes compile error
    };
    if (Fovia.Util.getURLParam('wadoEndpoint')){
      json['stowEndpoint'] = Fovia.Util.getURLParam('wadoEndpoint');
    }
    Fovia.ServerContext.callCustomJSFunction(json, new Map<string, ProgressCallback>()).then( ( data ) => {
      if (data){
        console.log( 'Successfully completed dicom file sending' );
      }
    } ).catch (  ( reason ) => {
      console.log( 'Failed sending dicom file to the cloud datastore', reason );
      throw reason;
    } );
  }
  /**
	 * Send DICOM buffer to server using STOW-RS
	 * @param dicomData
	 * @param studyInstanceUID
	 * @param stowRSProvider
	 */
  public sendDICOMBuffer(dicomData: any, studyInstanceUID: string, stowRSProvider: string): void {
    const json = {
      pluginjs: 'jsplugin_wado/stow-rs-plugin',
      studyInstanceUID: studyInstanceUID,
      dicomBuffer: dicomData,
      stowRSProvider: stowRSProvider,
      stowEndpoint: null, // fixes compile error
    };
    if (Fovia.Util.getURLParam('wadoEndpoint')){
      json['stowEndpoint'] = Fovia.Util.getURLParam('wadoEndpoint');
    }
    Fovia.ServerContext.callCustomJSFunction( json , new Map<string, ProgressCallback>()).then( ( data ) => {
      console.log( data );
      console.log( 'Successfully completed dicom buffer sending' );
    } ).catch (  ( reason ) => {
      console.log( 'Failed sending dicom buffer to the cloud datastore', reason );
      throw reason;
    } );
  }
  /**
   * Asynchronous method to save list of presentation data available for the current study.
   * This takes all the presentation data available in PresentationSeriesGroup class
   * and in every viewport and sends back to server
   */
  public async saveAnnotations(newSopInstanceUID: string): Promise<ISaveResultStatus> {
    // Go through each viewport and  get the presentation state and consolidate it.
    // This loop effectively eliminates consideration of any images that have not been displayed. So it's a
    // good check for changes but not a great check for the overall count of annotations.
    const consolidatedPresentationDataContextHolder = new Fovia.ConsolidatedPresentationDataContextHolder();
    const saveResult = new SaveResultStatus();
    let haveNewAnnotations = false;

    let presentationList: Array<Fovia.PresentationDataContext> = [];
    for (let i = 0; i < this.viewports.length; i++) {
      const viewport = this.viewports[i];
      // This is a change from fovia's version.  We only consider series from the requested (primary) exam
      if (!viewport.hasSeriesDataContext()) {
        continue;
      }
      if (viewport.getSeriesDataContext().studyInstanceUID !== this.primaryStudyInstanceUID) {
        continue;
      }
      if (!viewport.allowSaveAnnotations) {
        continue;
      }
      // Sync the viewing attributes with Presentation state
      // We only deal with annotations. No need to mess with W/L, rotate and flip.
      // viewport.syncViewingAttributes();

      // This is a change from fovia's version.  We're only interested in annotations for the time being.
      // The "ToSave" part of the function name is misleading since it is supposed to find "modified" items,
      // but the "modified" flag only seems to be set to true for newly created annotations.
      // So, we ask for the "ToSave" items but really get the "new" items.
      // To help get around this issue I've taken over the parameter passed to the viewport
      // version of the function. Intead of specifying whether or not to pay attention to the W/L, rotate, etc.
      // I've used that parameter to specify whether to collect not-new annotations or just the neww ones.
      // Then I make two calls. One for the not-new ones and ones for the new ones.
      presentationList = viewport.getPresentationListToSave(false);
      for (const presentation of presentationList) {
        if (presentation.contentLabel === SYNTH_CONTENT_LABEL) {
          // These are annotations added in this session.
          haveNewAnnotations = true;
          consolidatedPresentationDataContextHolder.consolidatePresentationDataContext(presentation);
        }
      }

      // Since we can't reliably get "modified" items, we'll get all items and rely on the _annotationModified flag.
      presentationList = viewport.getAllPresentationList();
      for (const presentation of presentationList) {
        if (presentation.contentLabel === SYNTH_CONTENT_LABEL) {
          consolidatedPresentationDataContextHolder.consolidatePresentationDataContext(presentation);
        }
      }
    }

    // Don't do any saving if nothing has changed.
    // We track deletions and Fovia tracks modifications, so that's the easiest first check.
    if (!haveNewAnnotations && !this.annotationModified) {
      console.log('No new or modified annotations to save.');
      return saveResult;
    }

    // This should be the list of all current Synthesis annotations.
    const presentationDataList = [];
    for (const presentation of consolidatedPresentationDataContextHolder.getPresentationDataContextList()) {
      presentationDataList.push(presentation.toJSON());
    }

    // Changed from Fovia's version to use examSource and return SaveResultStatus
    if (presentationDataList.length > 0) {
      const presentation: any = {};

      presentation['path'] = '';
      presentation['data'] = presentationDataList;
      // send custom tags
      presentation['dicomElementDataList'] = [...this.dicomElementDataList];
      const date = new Date();
      const creationDate = this.makePresentationCreationDate(date);
      const creationTime = this.makePresentationCreationTime(date);
      presentation['dicomElementDataList'].push(
        { group: 0x0002, element: 0x0003, tagValue: newSopInstanceUID },     // Media Storage SOP Instance UID
        { group: 0x0008, element: 0x0018, tagValue: newSopInstanceUID },
        { group: 0x0070, element: 0x0082, tagValue: creationDate },
        { group: 0x0070, element: 0x0083, tagValue: creationTime }
      );
      presentation['saveViewingAttribute'] = true;
      presentation['stream'] = true;

      try {
        const foviaResult: any = await Fovia.PresentationUtil.savePresentation(presentation);
        if (foviaResult.err === Fovia.ReturnCode.ok) {
          // Decode result
          let nonImageSeries: Fovia.NonImageSeriesDataContext;
          if (typeof CBOR === 'object') {
            // if loading from foviaAPI.js (not WebPack), this will be true
            nonImageSeries = CBOR.decode(foviaResult.rpCBOR);
          } else {
            // @ts-ignore when using WebPack, Fovia.CBORAccess.CBOR will be accessible, but not "CBOR"
            nonImageSeries = Fovia.CBORAccess.CBOR.decode(foviaResult.rpCBOR);
          }

          saveResult.resultCode = Fovia.ReturnCode.ok;
          saveResult.hadChanges = true;
          saveResult.metadata = nonImageSeries;

          if (foviaResult.presentaionstates /* spelling, yes */) {
            // Collect the ArrayBuffer(s) containing the P10 data to sync back to the datasource.
            for (const key in foviaResult.presentaionstates /* spelling, yes */) {
              saveResult.datasets.set(newSopInstanceUID, foviaResult.presentaionstates[key]);
            }
          }

          console.log(`Saved ${presentationDataList.length} annotation(s) for exam ${this.primaryStudyInstanceUID}`, presentation, foviaResult);
          return saveResult;

        } else {
          console.error(`Failed to save ${presentationDataList.length} annotation(s) for exam ${this.primaryStudyInstanceUID}`);
          console.log(`Failed to save ${presentationDataList.length} annotation(s) for exam ${this.primaryStudyInstanceUID}`, presentation, foviaResult);
          saveResult.resultCode = Fovia.ReturnCode.fail;
          return saveResult;
        }
      } catch (err) {
        console.error(`Exception while attempting to save ${presentationDataList.length} annotation(s) for exam ${this.primaryStudyInstanceUID}`, err);
        console.log(`Failed to save ${presentationDataList.length} annotation(s) for exam ${this.primaryStudyInstanceUID}`, presentation);
        saveResult.resultCode = Fovia.ReturnCode.fail;
        return saveResult;
      }
    } else {
      console.log(`No annotations to save for exam ${this.primaryStudyInstanceUID}`);
      saveResult.resultCode = Fovia.ReturnCode.ok;
      return saveResult;
    }
  }

  /**
   * Set NonImageSeriesResults class to hold all the NonImageSeriesData for study
   *
   * @param nonImageSeriesResults Fovia.NonImageSeriesResults object with NonImageSeries data
   *
   */
  public setNonImageSeriesResults(nonImageSeriesResults: Fovia.NonImageSeriesResults): void {
    this.nonImageSeriesResults = nonImageSeriesResults;

    const nonImageSeriesMap: Map<Fovia.SupportedNonImageModelType, Fovia.NonImageSeriesDataContext[]> = this.nonImageSeriesResults.getNonImageSeriesMap();
    const mapList = [...nonImageSeriesMap.entries()];
    mapList.forEach((entry) => {
      entry[1].forEach((sdc) => {
        console.log(`----------- NonImageSeries ${Fovia.SupportedNonImageModelType[entry[0]]} ${sdc.modality} ${sdc.seriesDescription} ${sdc.seriesDate} ${sdc.seriesInstanceUID}`, sdc);
      });
    });
  }

  /**
   * Get list of NonImageSeriesDataContext for given NonImage type.
   * It internally invokes getNonImageSeriesDataList of PresentationSeriesGroup class
   *
   * @param type enum of Fovia.SupportedNonImageModelType
   *
   * @returns Array of Fovia.NonImageSeriesDataContext
   */
  public getNonImageSeriesDataList(type: Fovia.SupportedNonImageModelType): Array<Fovia.NonImageSeriesDataContext> | null {
    if (this.nonImageSeriesResults == null) {
      return null;
    }
    return this.nonImageSeriesResults.getNonImageSeriesDataList(type);
  }

  public createPresentations(presentationSeriesDataContextList: any, renderEngine: any, studyInfo: Fovia.DICOMStudy, patientInfo: Fovia.DICOMDirEntry): void {
    if (!presentationSeriesDataContextList || presentationSeriesDataContextList.length === 0 || !renderEngine) {
      return;
    }

    // We're only interested in OUR most recent GSPS, so get its date and time for later comparison.
    const synthPresentations = presentationSeriesDataContextList.filter((presentation: any) => presentation.contentLabel === SYNTH_CONTENT_LABEL);
    const [mostRecentDate, mostRecentTime] = this.getMostRecentDateTime(synthPresentations);

    // Go through all the presentations and find our annotations snd CAD. That's all we currently show.
    for (const presentation of presentationSeriesDataContextList) {
      let presentationDataContext = this.presentationSeriesGroup.get(presentation.sopInstanceUid, presentation.instanceNumber);
      if (presentationDataContext == null) {
        presentationDataContext = new Fovia.PresentationDataContext(renderEngine.renderEngineLocation === Fovia.RenderLocation.Client ? 0 : renderEngine.renderEngineID);

        presentationDataContext.instanceNumber = presentation.instanceNumber;
        presentationDataContext.setStudy(studyInfo);
        presentationDataContext.setPatient(patientInfo);

        presentationDataContext.contentDescription = presentation.contentDescription;
        presentationDataContext.presentationCreationDate = presentation.presentationCreationDate;
        presentationDataContext.presentationCreationTime = presentation.presentationCreationTime;
        presentationDataContext.contentCreatorName = presentation.contentCreatorName;
        presentationDataContext.sopInstanceUid = presentation.sopInstanceUid;
        presentationDataContext.path = presentation.path;
        presentationDataContext.referencedSeriesSequence = new Array<Fovia.ReferencedSeries>();
        if (presentation.referencedSeriesSequence) {
          presentation.referencedSeriesSequence.forEach((series: any) => {
            if (series && series.referencedSeriesInstanceUid) {
              presentationDataContext.referencedSeriesSequence.push(Object.assign(new Fovia.ReferencedSeries(), series));
            }
          });
        }
        presentationDataContext.graphicAnnotationContext.setFindingThreshold(this.showFindingThreshold);
        presentationDataContext.graphicAnnotationContext.setPresentationDataContext(presentationDataContext);
        presentationDataContext.graphicAnnotationContext.constructAnnotations(presentation, true, false, this.convertTxtObjToTxtAnn);
        presentationDataContext.viewingAttribute.merge(presentation.viewingAttribute);
        presentationDataContext.mergeDisplayAreaSequence(presentation.displayArea);
        presentationDataContext.mergeGraphicLayerSequence(presentation.graphicLayerSequence);
        presentationDataContext.contentLabel = presentation.contentLabel;
      }

      if (presentation.source === 'cad') {
        // Assuming this a validation check. If image is not valid, then don't include it as part of the presentation list
        let isValidCad = true;
        const imageTags: Fovia.DICOMImageTags[] = renderEngine.seriesDataContext.imageTags;
        for (let index = 0; index < imageTags.length; index++) {
          const imageTag = imageTags[index];
          if (!imageTag.spatialLocationPreserved) {
            // return;
            isValidCad = false;
            break;
          }
        }
        if (!isValidCad) {
          console.warn('cad is not valid for ', presentation.sopInstanceUid);
          continue;
        }
        presentationDataContext.contentLabel = CADSR_CONTENT_LABEL;
        presentationDataContext.contentDescription = 'ORIGINAL CADSR';
        presentationDataContext.isEnabled = true;
        this.presentationSeriesGroup.add(presentationDataContext);

        const nonimage: Fovia.DICOMNonImageSeries = new Fovia.DICOMNonImageSeries();
        const cad = new Fovia.CadSrSeriesContext(patientInfo, studyInfo, nonimage);
        cad.mergePresentation(presentationDataContext);
        renderEngine.addCadSeriesDataContext(cad);
        this.changeGraphicLayerIndex(presentationDataContext);

        // We only want to set the CAD info for a sdc once
        let cadSopInstanceUIDs = this._processedCADForSDC.get(renderEngine.seriesDataContext.seriesInstanceUID);
        if (cadSopInstanceUIDs == null) {
          cadSopInstanceUIDs = [];
        }
        if (cadSopInstanceUIDs.find(uid => uid === presentation.sopInstanceUid) == null) {
          this.mergeCadFindingInfo(presentation, renderEngine, presentationDataContext.graphicAnnotationContext);
          cadSopInstanceUIDs.push(presentation.sopInstanceUid);
          this._processedCADForSDC.set(renderEngine.seriesDataContext.seriesInstanceUID, cadSopInstanceUIDs);
        }

      } else if (presentationDataContext.contentLabel === SYNTH_CONTENT_LABEL) {
        if (mostRecentDate === presentationDataContext.presentationCreationDate && mostRecentTime === presentationDataContext.presentationCreationTime) {
          this.presentationSeriesGroup.add(presentationDataContext);
        }
      }
    }

    const applicableList = this.getApplicablePresentationStateInfoList(mostRecentDate, mostRecentTime, renderEngine.seriesDataContext.seriesInstanceUID);
    const annotationParams = new Array<Fovia.PresentationDataContext>();
    for (const item of applicableList) {
      if (item) {
        annotationParams.push(item.getPRInstance());
      }
    }

    // setPresentationDataList will select and display the zeroth element in the list.
    // We want to also include CAD.
    renderEngine.setPresentationDataList(annotationParams);

    // setPresentationDataList will select and display the most recent GSPS, we want to also include CAD always.
    for (const presentationDataContext of annotationParams ) {
      if (presentationDataContext.contentLabel === CADSR_CONTENT_LABEL) {
        presentationDataContext.isEnabled = true;
      }
    }

    for (const presentationDataContext of annotationParams ) {
      if (presentationDataContext.contentLabel === CADSR_CONTENT_LABEL) {
        presentationDataContext.isEnabled = true;
      }
    }
  }


  private changeGraphicLayerIndex(presentationDataContext: Fovia.PresentationDataContext): void {
    const annotations = presentationDataContext.graphicAnnotationContext.getAllAnnotations();
    for (const annotation of annotations) {
      annotation.graphicLayerIndex = -1;
    }
  }


  private mergeCadFindingInfo(presentation: any, renderEngine: any, graphicAnnotationContext: Fovia.GraphicAnnotationContext): void {
    const cadFindings = this.getCadFindingInfo(presentation, renderEngine, graphicAnnotationContext);
    for (const cadFindingInfo of cadFindings) {
      renderEngine.seriesDataContext.cadFindingsInfo.push(cadFindingInfo);

    }
  }

  public getCadFindingInfo(presentation: any, renderEngine: any | null, graphicAnnotationContext: Fovia.GraphicAnnotationContext): Array<Fovia.CADFindingsInfo> {
    // Validate the incomming presentation
    const cadFindings: Array<Fovia.CADFindingsInfo> = [];
    if (!presentation) {
      return cadFindings;
    }

    // Check whether the given presentation is cad sr type
    if (presentation.source !== 'cad') {
      return cadFindings;
    }

    // Check whether annotations exists in the given presentation
    const graphicAnnotationSequence: Array<Fovia.GraphicAnnotation> = presentation.graphicAnnotations;
    if (!graphicAnnotationSequence || graphicAnnotationSequence.length === 0) {
      return cadFindings;
    }

    for (const annotation of graphicAnnotationSequence) {
      const value = graphicAnnotationContext.getShowFindingThreshold(annotation);
      if (value && value <= this.showFindingThreshold) {
        continue;
      }

      let _referencedImages = annotation.referencedImageSequence;
      // Check if referenced image sequence is available
      if (_referencedImages.length === 0) {
        let referencedImageSequence: Array<Fovia.ReferencedImage> = [];
        for (const referencedSeries of presentation.referencedSeriesSequence) {
          referencedImageSequence = referencedImageSequence.concat(referencedSeries.referencedImageSequence);
        }
        _referencedImages = referencedImageSequence;
      }

      for (const referencedImage of _referencedImages) {

        if (referencedImage.referencedFrameNumbers.length === 0) {
          referencedImage.referencedFrameNumbers.push(1);
        }

        if (renderEngine !== null && !renderEngine.seriesDataContext.IsInstanceExists(referencedImage.referencedSopInstanceUid)) {
          continue;
        }

        for (let index = 0; index < referencedImage.referencedFrameNumbers.length; index++) {
          const key = `${referencedImage.referencedSopInstanceUid}_${referencedImage.referencedFrameNumbers[index]}`;

          const cadFindingsInfo: Fovia.CADFindingsInfo = new Fovia.CADFindingsInfo();
          if (annotation.graphicLayer === Fovia.Util.Constants.MAMMOGRAPHY_BREAST_DENSITY) {
            cadFindingsInfo.numOfDensityFindings++;
          }
          else if (annotation.graphicLayer === Fovia.Util.Constants.CALCIFICATION_CLUSTER) {
            cadFindingsInfo.numOfClusterFindings++;
          }

          if (cadFindingsInfo.isFindingExists()) {
            cadFindingsInfo.sopInstanceUID = key;
            cadFindings.push(cadFindingsInfo);
            // renderEngine.seriesDataContext.updateCADFindingsInfo(cadFindingsInfo);
          }
        }
      }
    }
    return cadFindings;
  }

  public getByReferencedSeries(referencedSeriesInstanceUid: string): Array<Fovia.PresentationDataContext> {
    return this.presentationSeriesGroup.getByReferencedSeries(referencedSeriesInstanceUid);
  }

  /**
   * Constructs new PresentationInfo from each GSPS object, sort them based on content creation date/time and returns sorted list
   */
  private getApplicablePresentationStateInfoList(mostRecentDate: string, mostRecentTime: string, seriesInstanceUID: string): Array<PresentationInfo> {
    const applicableList = this.getByReferencedSeries(seriesInstanceUID);
    const presentationInfoList = new Array<PresentationInfo>();
    if (applicableList) {
      for (const item of applicableList) {
        if (item) {
          if (item.contentLabel === SYNTH_CONTENT_LABEL) {
            if (item.presentationCreationDate === mostRecentDate && item.presentationCreationTime === mostRecentTime) {
              presentationInfoList.push(new PresentationInfo(item));
            }
          } else if (item.contentLabel === CADSR_CONTENT_LABEL) {
            presentationInfoList.push(new PresentationInfo(item));
          }
        }
      }
    }
    presentationInfoList.sort((info1, _) => {
      // If there's a set of our annotations, make it first in the list.
      return info1.getPRInstance().contentLabel === SYNTH_CONTENT_LABEL ? -1 : 0;
    });
    return presentationInfoList;
  }

  // Provide the list of SopInstances for each non-image object
  public getAllNonImageSeriesDataList(): Array<string> {
    const nonImageSeriesUIDs: Array<string> = [];
    if (this.nonImageSeriesResults == null) {
      return nonImageSeriesUIDs;
    }
    const nonImageSeriesMap = this.nonImageSeriesResults.getNonImageSeriesMap();
    const mapList = [...nonImageSeriesMap.entries()];
    mapList.forEach((entry) => {
      entry[1].forEach((sdc) => {
        const uid = sdc.nonImageDataList[0].sopInstanceUid.trim();
        nonImageSeriesUIDs.push(uid);
      });
    });
    return nonImageSeriesUIDs;
  }

  public hasKeyImages(studyUID: string): boolean {
    const koList = this.getNonImageSeriesDataList(Fovia.SupportedNonImageModelType.key_object);
    if (koList == null) {
      return false;
    }
    const koIndex = koList.findIndex((ko) => {
      return ko.studyInstanceUID === studyUID;
    });
    return koIndex >= 0;
  }

  public getMostRecentKOInstanceUID(studyUID: string): IDicomInstance | null {
    const keyImageSeriesDataList = this.getNonImageSeriesDataList(Fovia.SupportedNonImageModelType.key_object);
    const sortedKeyInfoList = new Array<PresentationInfo>();
    if (keyImageSeriesDataList != null) {
      keyImageSeriesDataList.forEach(keyDataContext => {
        if (keyDataContext && keyDataContext.studyInstanceUID === studyUID) {
          sortedKeyInfoList.push(new PresentationInfo(keyDataContext, 'KO'));
        }
      });
      sortedKeyInfoList.sort((info1, info2) => {
        return info1.compareContentCreationTime(info2);
      });
    }
    if (sortedKeyInfoList.length == 0) {
      return null;
    }
    const entry: Fovia.NonImageSeriesDataContext = sortedKeyInfoList[0].getPRInstance();
    const instance: IDicomInstance = {
          studyInstanceUID: entry.studyInstanceUID,
          seriesInstanceUID: entry.seriesInstanceUID,
          sopInstanceUID: entry.nonImageDataList[0].sopInstanceUid
        };
    return instance;
  }

  public setKeyImages(sdc: Fovia.SeriesDataContext): void {
    // console.log(`-------- setKeyImages: Evaulating KO against series ${sdc.seriesInstanceUID}`, sdc);
    const keyImageSequence = new Fovia.Util.SopInstanceSequence();
    const keyImageInstances: Fovia.Util.SopInstance[] = [];
    const keyImageSeriesDataList = this.getNonImageSeriesDataList(Fovia.SupportedNonImageModelType.key_object);
    const sortedKeyInfoList = new Array<PresentationInfo>();
    if (keyImageSeriesDataList != null) {
      keyImageSeriesDataList.forEach(keyDataContext => {
        if (keyDataContext) {
          sortedKeyInfoList.push(new PresentationInfo(keyDataContext, 'KO'));
        }
      });

      sortedKeyInfoList.sort((info1, info2) => {
        return info1.compareContentCreationTime(info2);
      });
    }

    if (keyImageSeriesDataList != null) {
      // console.log(`keyImageSeriesDataList found ${keyImageSeriesDataList.length} KO documents`);
      // Starting with the most recent KO, keep examing each one until we find matching KeyImages, then ignore the rest
      for (let i = 0; i < sortedKeyInfoList.length && keyImageInstances.length === 0; i++) {
        const keyImageSeriesData = sortedKeyInfoList[i].getPRInstance();
        // KO models
        const nonImageDataList = keyImageSeriesData.nonImageDataList;
        // console.log(`nonImageDataList ${i}/${sortedKeyInfoList.length} ${nonImageDataList.length} key images`, nonImageDataList);
        for (let j = 0; j < nonImageDataList.length; j++) {
          // Set key object related information
          const nonImageData = nonImageDataList[j];
          let referencedImageSequence = nonImageData.contentSequence.referencedImageSequence;
          const referencedSeriesSequence = nonImageData.currentRequestedProcedureEvidenceSequence.referencedSeriesSequence;

          for (let i_1 = 0; i_1 < referencedSeriesSequence.length; i_1++) {
            if (referencedSeriesSequence[i_1].referencedSeriesInstanceUid === sdc.seriesInstanceUID) {

              referencedImageSequence = referencedImageSequence.concat(referencedSeriesSequence[i_1].referencedImageSequence);
            }
          }
          for (let index = 0; index < referencedImageSequence.length; index++) {
            const referencedImage = referencedImageSequence[index];
            const referencedFrameNumbers = referencedImage.referencedFrameNumbers;
            // If no frame number is mentioned, assume it is 1
            if (referencedFrameNumbers.length === 0) {
              referencedFrameNumbers.push(1);
            }
            for (let index2 = 0; index2 < referencedFrameNumbers.length; index2++) {
              const keyImageContext: Fovia.Util.SopInstance = {
                sopInstanceUid: referencedImage.referencedSopInstanceUid,
                frameNumber: referencedFrameNumbers[index2]
              };
              // ensure we don't produce duplicate key images from the various referencedImageSequences
              const index = keyImageInstances.findIndex((keyImage) => {
                return keyImageContext.sopInstanceUid === keyImage.sopInstanceUid &&
                  keyImageContext.frameNumber === keyImage.frameNumber;
              });
              if (index === -1) {
                // console.log(`adding key image ${index2}/${referencedFrameNumbers.length} ${keyImageContext.sopInstanceUid} ${keyImageContext.frameNumber} key image to list`);
                keyImageSequence.add(referencedImage.referencedSopInstanceUid, referencedFrameNumbers[index2]);
              }
            }
          }
        }
      }
      const imageNumbers = [];
      const imageTags = sdc.imageTags;
      const keyImages = keyImageSequence.getAll();
      for (let i = 0; i < keyImages.length; i++) {
        const keyImage = keyImages[i];
        // console.log(`${i}/${keyImages.length} keyImage is ${keyImage.sopInstanceUid} ${keyImage.frameNumber} imageTags ${imageTags.length}`);
        for (let _i = 0, imageTags_1 = imageTags; _i < imageTags_1.length; _i++) {
          const imageTag = imageTags_1[_i];
          if (imageTag.sopInstanceUID !== keyImage.sopInstanceUid) {
            continue;
          }
          // In case of multi-frame
          if (imageTag.totalFrames > 1) {
            if (imageTag.frameNumber !== keyImage.frameNumber) {
              continue;
            }
            // DICOM Image numbers are 1 origin, not 0 origin
            imageNumbers.push((_i));
          } else {
            imageNumbers.push((_i));
          }
        }
      }
      // Preserve the order of the Key Images to be how they were stored in the KO document
      // Sorting re-orders a reading result, which could be un-safe.
      // Explicitly ignoring Fovia code
      sdc.keyImages = imageNumbers;
      // console.log(`setKeyImages: ${sdc.seriesInstanceUID} contains ${imageNumbers.length} key images`);
    }
  }

  public set primaryStudyInstanceUID(value: string) {
    this._primaryStudyInstanceUID = value;
    // When we get a new primary study UID we'll start over assuming nothing has changed yet.
    this._annotationModified = false;
  }

  public get primaryStudyInstanceUID(): string {
    return this._primaryStudyInstanceUID;
  }

  public deleteAnnotation(renderEngine: RenderEngineContext2D, graphicType: Fovia.GraphicType, sopInstanceUid: string, frameNumber: number): void {
    if (this.primaryStudyInstanceUID === renderEngine.getSeriesDataContext().studyInstanceUID) {
      this._annotationModified = true;
    }
    renderEngine.deleteAnnotation(graphicType, sopInstanceUid, frameNumber);
  }

  public set annotationModified(value: boolean) {
    // TODO: We need to check the study UID to avoid tricking ourselves into writing the GSPS
    // for the primary exam when a change is made to a comparison exam.
    this._annotationModified = value;
  }

  public get annotationModified(): boolean {
    return this._annotationModified;
  }

  private makePresentationCreationDate(date: Date): string {
    dayjs.extend(dayjsPluginUTC);
    const utcNow = dayjs.utc(date);
    return `${utcNow.format('YYYYMMDD')}`;
  }

  private makePresentationCreationTime(date: Date): string {
    const utcNow = dayjs.utc(date);
    return `${utcNow.format('HHmmss.SSS')}`;
  }

  private getMostRecentDateTime(synthPresentations: any): [ string, string ] {
    if (synthPresentations.length > 0) {
      synthPresentations.sort((a: any, b: any) => {
        if (Number(a.presentationCreationDate) < Number(b.presentationCreationDate)) {
          return -1;
        }
        else if (Number(a.presentationCreationDate) > Number(b.presentationCreationDate)) {
          return 1;
        }
        else {
          if (a.presentationCreationTime < b.presentationCreationTime) {
            return -1;
          }
          else if (a.presentationCreationTime > b.presentationCreationTime) {
            return 1;
          }
          else {
            return 0;
          }
        }
      });
      return [synthPresentations[synthPresentations.length - 1].presentationCreationDate, synthPresentations[synthPresentations.length - 1].presentationCreationTime];
    }
    return ['', ''];
  }
}
