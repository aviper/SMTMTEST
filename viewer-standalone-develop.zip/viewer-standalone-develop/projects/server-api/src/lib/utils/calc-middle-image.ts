import Fovia from 'foviaapi';

export const MIN_IMAGES_FOR_PLANE = 10;

export function calcMiddleImage(series: Fovia.SeriesDataContext): number {
  return series.getNumImages() > MIN_IMAGES_FOR_PLANE ? Math.floor(series.getNumImages() / 2) : 0;
}
