import { GSPSUtils } from './gspsutils';

describe('GSPSUtils', () => {
  it('should create an instance', () => {
    expect(new GSPSUtils()).toBeTruthy();
  });
});
