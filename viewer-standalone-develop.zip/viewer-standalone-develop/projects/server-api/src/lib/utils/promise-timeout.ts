import * as WorkerTimers from 'worker-timers';

// Generic function returns desired promise type or time-out type, provided as a parameter.
// Then uses Promise.race to resolve a timer-promise and the desired promise
//
// Example: wait for promise to resolve in 1 second, if it doesn't return null.
//
// const p: Promise<string> = getPromiseString();
// const result: string | null = await promiseTimeout<string, null>(p, 1000, null);

export async function promiseTimeout<P, R>(promise: Promise<P>, timeout_ms: number, timeoutValue: R): Promise<P> {
  // timeout promise rejects after timeout_ms elapses;
  let timerId: any;
  const timeout = new Promise<P>((_, reject) =>
    timerId = WorkerTimers.setTimeout(() => {
      reject(timeoutValue);
    }, timeout_ms));
  return Promise.race([promise, timeout])
    .finally(() => WorkerTimers.clearTimeout(timerId));
}
