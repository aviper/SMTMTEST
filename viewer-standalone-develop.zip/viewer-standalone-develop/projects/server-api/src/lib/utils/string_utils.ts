 export function JSONParseSafe(value: string): any | null {
  let result: any | null = null;
  try {
    result = JSON.parse(value);
  } catch (err) {
    console.error(`JSONParseSafe exception for JSON "${value}"`, err);
  }
  return result;
}

export function isInternalEmail(email: string): boolean {
  const emailParts = email.split('@');
  if (emailParts.length !== 2) {
    return false;
  }
  const domain = emailParts[1].toLowerCase();
  const internalEmailDomains = ['synthesis.health', 'synthesishealthinc.com'];
  return internalEmailDomains.includes(domain);
}
