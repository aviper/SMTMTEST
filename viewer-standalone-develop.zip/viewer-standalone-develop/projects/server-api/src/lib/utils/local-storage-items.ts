import Fovia from 'foviaapi';
import { ClientRenderMode, ClientConfigData } from '../models';

export class LocalStorageItems {
  private static _instance: LocalStorageItems;
  private _renderLocation: Fovia.RenderLocation = Fovia.RenderLocation.Hybrid;
  private _purgeOldExams = true;
  private _overrideLogger: string | null = null;
  private _overlayFontSize: number | null = null;
  private _edgeEnhancementLevel: string | null = null;
  private _mrWlPropagateMode: string | null = null;
  private _xrayWlPropagateMode: string | null = null;
  private _clientConfigDefaults: ClientConfigData | null = null;
  private _disableTranscoding: boolean = false;
  private _backgroundTestsEnabled = false;

  constructor() {
    // No configuration available from the server yet
    this.resolveClientConfiguration(null);
  }

  public resolveClientConfiguration(config: ClientConfigData | null): void {
    const overrideRenderLocation = localStorage.getItem('render-location');
    const overridePurgeOldExams = localStorage.getItem('purge-old-exams');
    const overrideLogger = localStorage.getItem('override-logger');
    const overrideOverlayFontSize = localStorage.getItem('overlay-font-size');
    const overrideEdgeEnhancementLevel = localStorage.getItem('edge-enhancement-level');
    const disableTranscoding = localStorage.getItem('disable-transcoding');
    const overrideBackgroundTestsEnabled = localStorage.getItem('background-tests-enabled');
    let defaultRenderMode = Fovia.RenderLocation.Hybrid;

    if (config && config.defaultRenderMode) {
      switch (config.defaultRenderMode) {
        case ClientRenderMode.Client:
          defaultRenderMode = Fovia.RenderLocation.Client;
          break;
        case ClientRenderMode.Hybrid:
          defaultRenderMode = Fovia.RenderLocation.Hybrid;
          break;
        case ClientRenderMode.Server:
          defaultRenderMode = Fovia.RenderLocation.Server;
          break;
        default:
          console.warn(`Default render location '${config.defaultRenderMode}' from server configuration not recognized`);
          break;
      }
    }

    // renderLocation can be toggled to "client" in local storage, else use the default from the server, or Hybrid if no server config is available
    if (overrideRenderLocation) {
      if (overrideRenderLocation.toLowerCase() === ClientRenderMode.Client) {
        this._renderLocation = Fovia.RenderLocation.Client;
      } else if (overrideRenderLocation.toLowerCase() === ClientRenderMode.Hybrid) {
        this._renderLocation = Fovia.RenderLocation.Hybrid;
      } else if (overrideRenderLocation.toLowerCase() === ClientRenderMode.Server) {
        this._renderLocation = Fovia.RenderLocation.Server;
      } else {
        console.warn(`Unsupported value for 'render-location' override '${overrideRenderLocation}'`);
        this._renderLocation = defaultRenderMode;
      }
    } else {
      this._renderLocation = defaultRenderMode;
    }
    // purgeOldExams is true unless we find "no" for the item in local storage
    this._purgeOldExams = (!(overridePurgeOldExams && overridePurgeOldExams.toLowerCase() === 'no'));
    // backgroundTestsEnabled is false unless we find "yes" for the item in local storage
    this._backgroundTestsEnabled = (overrideBackgroundTestsEnabled?.toLowerCase() === 'yes');
    // If set overrideLogger will be used to override the apps default logger setting
    this._overrideLogger = overrideLogger;
    if (overrideOverlayFontSize && overrideOverlayFontSize.length !== 0) {
      this._overlayFontSize = +overrideOverlayFontSize;
    }
    if (overrideEdgeEnhancementLevel && overrideEdgeEnhancementLevel.length !== 0) {
      this._edgeEnhancementLevel = overrideEdgeEnhancementLevel;
    }
    const mrWlPropagateMode = localStorage.getItem('mr-wl-propagate-mode');
    if (mrWlPropagateMode && mrWlPropagateMode.length !== 0) {
      this._mrWlPropagateMode = mrWlPropagateMode;
    }
    const xrayWlPropagateMode = localStorage.getItem('xray-wl-propagate-mode');
    if (xrayWlPropagateMode && xrayWlPropagateMode.length !== 0) {
      this._xrayWlPropagateMode = xrayWlPropagateMode;
    }
    if (disableTranscoding != null) {
      if (disableTranscoding.length !== 0) {
        // The key is present and has a value - disable by default
        const valueLowerCase  = disableTranscoding.toLowerCase();
        if (valueLowerCase === 'false' || valueLowerCase === 'no' || valueLowerCase === 'off' || valueLowerCase === '0') {
          this._disableTranscoding = false;
        } else {
          this._disableTranscoding = true;
        }
      } else {
        // The key is present, but with no value - assume disable
        this._disableTranscoding = true;
      }
    } else {
      // If the key is not present, let the server decide
      this._disableTranscoding = false;
    }
    this._clientConfigDefaults = config;

    switch (this._renderLocation) {
      case Fovia.RenderLocation.Client:
        console.log(`Render location resolves to '${ClientRenderMode.Client}'`);
        break;
      case Fovia.RenderLocation.Hybrid:
        console.log(`Render location resolves to '${ClientRenderMode.Hybrid}'`);
        break;
      case Fovia.RenderLocation.Server:
        console.log(`Render location resolves to '${ClientRenderMode.Server}'`);
        break;
      default:
        console.warn(`Render location resolves to unknown value ${this._renderLocation}`);
        break;
    }
  }

  public static get clientConfigurationDefaults(): ClientConfigData | null {
    return LocalStorageItems.instance._clientConfigDefaults;
  }

  public static get edgeEnhancementLevel(): string | null {
    return LocalStorageItems.instance._edgeEnhancementLevel;
  }

  public static set edgeEnhancementLevel(level: string)  {
    LocalStorageItems.instance._edgeEnhancementLevel = level;
    if (level.toLowerCase() !== 'off') {
      localStorage.setItem('edge-enhancement-level', level);
    }
    else {
      localStorage.removeItem('edge-enhancement-level');
    }
  }
  public static get mrWlPropagateMode(): string | null {
    return LocalStorageItems.instance._mrWlPropagateMode;
  }

  public static set mrWlPropagateMode(level: string) {
    LocalStorageItems.instance._mrWlPropagateMode = level;
    localStorage.setItem('mr-wl-propagate-mode', level);
  }

  public static get renderLocation(): Fovia.RenderLocation {
    return LocalStorageItems.instance._renderLocation;
  }

  public static get shouldPurgeOldExams(): boolean {
    return LocalStorageItems.instance._purgeOldExams;
  }

  public static get backgroundTestsEnabled(): boolean {
    return LocalStorageItems.instance._backgroundTestsEnabled;
  }

  public static get overrideLogger(): string | null  {
    return LocalStorageItems.instance._overrideLogger;
  }

  public static get overlayFontSize(): number | null {
    return LocalStorageItems.instance._overlayFontSize;
  }

  public static set overlayFontSize(size: number)  {
    LocalStorageItems.instance._overlayFontSize = size;
    localStorage.setItem('overlay-font-size', size.toString());
  }

  public static get xrayWlPropagateMode(): string | null {
    return LocalStorageItems.instance._xrayWlPropagateMode;
  }

  public static set xrayWlPropagateMode(level: string)  {
    LocalStorageItems.instance._xrayWlPropagateMode = level;
    localStorage.setItem('xray-wl-propagate-mode', level);
  }

  public static get disableTranscoding(): boolean {
    return LocalStorageItems.instance._disableTranscoding;
  }

  static get instance(): LocalStorageItems {
    if (!this._instance) {
      this._instance = new LocalStorageItems();
    }
    return this._instance;
  }
}
