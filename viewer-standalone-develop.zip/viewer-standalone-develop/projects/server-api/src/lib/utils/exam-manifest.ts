// The format of the SR data is determined by Fovia, and could change in some future SDK release.
// If that happens, increment FOVIA_SR_PRESENTATION_SCHEMA_VERSION to invalidate the cached SR data in OPFS.
// 1 => 7.0.4.3150
export const FOVIA_SR_PRESENTATION_SCHEMA_NONE = 0;
export const FOVIA_SR_PRESENTATION_SCHEMA_VERSION = 1;

export interface IFoviaSeriesSRData {
  presentations: Array<any> | null;
  markerSummary: any | undefined;
}

export interface IFoviaStudySRData {
  foviaSchema: number; // Set to FOVIA_SR_PRESENTATION_SCHEMA_VERSION
  examVersion: string | undefined; // Hash of DICOM+JSON metadata returned by healthcare backend when exam was cached
  imageSeriesUID: Array<string>; // Array of DICOM Series Instance UID which are referenced by DICOM SRs
  imageSeriesSR: Record<string, IFoviaSeriesSRData>; // SR data for each item in imageSeriesUID
  errorSeriesUID: Array<string>; // Array of DICOM Series Instance UID for which SR data could not be retrieved
  errorSeriesDesc: Array<string>; // Array of DICOM Series Description of series for which SR data could not be retrieved
}

export interface ICachedExamManifest {
  examManifest: any; // Javascript object which can be used to construct Fovia.ScanDirResults
  examSRData: IFoviaStudySRData; // DICOM structured report data returned by Fovia
}
