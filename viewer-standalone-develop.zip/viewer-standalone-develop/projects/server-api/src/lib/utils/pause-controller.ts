import { BehaviorSubject, filter, lastValueFrom, take } from 'rxjs';

export class PauseController {
  protected isPaused$$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  protected pauseTimeoutTimer: unknown | null = null;

  public pause(): void {
    if (!this.isPaused$$.value) {
      this.clearPauseTimeoutTimer();
      this.isPaused$$.next(true);
    }
  }

  public isPaused(): boolean {
    return (this.isPaused$$.value);
  }

  public resume(): void {
    this.clearPauseTimeoutTimer();
    if (this.isPaused$$.value) {
      // console.log(`resumeCaching`);
      this.isPaused$$.next(false);
    }
  }

  public pauseWithTimeout(timeoutMs: number): void {
    console.log(`pauseWithTimeout: timeoutMs=${timeoutMs}`);
    this.pause();
    this.startPauseTimeoutTimer(timeoutMs);
  }

  public async waitWhilePaused(): Promise<void> {
    if (!this.isPaused$$.value) {
      return;
    }
    console.log(`waitWhilePaused: WAITING`);
    await lastValueFrom(this.isPaused$$
      .pipe(
        filter(paused => !paused),
        take(1)
      ));
      console.log(`waitWhilePaused: RESUMING`);
  }

  protected clearPauseTimeoutTimer(): void {
    if (this.pauseTimeoutTimer != null) {
      // console.log(`clearPauseTimeoutTimer`);
      clearTimeout(this.pauseTimeoutTimer as number);
      this.pauseTimeoutTimer = null;
    }
  }

  protected startPauseTimeoutTimer(timeoutMs: number): void {
    this.clearPauseTimeoutTimer();
    // console.log(`startPauseTimeoutTimer timeoutMs=${timeoutMs}`);
    this.pauseTimeoutTimer = setTimeout(() => {
      this.resume();
    }, timeoutMs);
  }

}
