export class PatientModule {
  constructor(public patient_name: string | null, public patient_id: string | null, public patient_birthday: string | null, public patient_sex: string | null) {
  }
}

export class FileMetaModule {
  constructor(public implementation_class_uid: string, public implementation_class_version_name: string) {
  }
}

export class ReferenceStudySequenceItem {
  constructor(public ref_sop_class_uid: string, public ref_sop_instance_uid: string) {
  }
}

export class StudyModule {
  constructor(public study_date: string | null,
              public study_time: string | null,
              public study_instance_uid: string,
              public accession_number: string | null,
              public referring_physician_name: string | null,
              public study_id: string | null,
              public ref_study_sequence: ReferenceStudySequenceItem[] | null) {

  }
}

export class SeriesModule {
  constructor(public series_date: string | null, public series_time: string | null, public modality: string,
              public series_instance_uid: string, public series_description: string, public series_number: string){
  }
}

export class FrameOfReferenceModule {
  constructor(public frame_of_ref_uid: string, public position_ref_indicator: string | null) {
  }
}

export class SCEquipmentModule {
  constructor(public conversion_type: string, public sc_device_id: string, public sc_device_manufacturer: string, public sc_device_manufacturer_model_name: string, public sc_device_software_versions: string) {
  }
}

export class ImageModule {
  constructor(public instance_number: string | null, public patient_orientation: string | null){
  }
}

export class VOILutModule {
  constructor(public window_center: string | null, public window_width: string | null) {}
}

export class SecondaryCaptureImageIOD {
  constructor(public fileMeta: FileMetaModule,
              public patient: PatientModule,
              public study: StudyModule,
              public series: SeriesModule,
              public scEquipment: SCEquipmentModule,
              public image: ImageModule,
              public voiLut: VOILutModule){
  }
}
