import { IDicomInstance } from '../context';
import { DICOM_ALLTAGS, DICOM_VR, IDicomTagDetails, ReverseTagMap } from './dicom-constants';
import dayjs from 'dayjs';

export type DicomTags = Record<string, DicomTagObject>;
export interface DicomTagObject {
  // We can do much better than this using discriminated unions, though that would
  // be a lot of work to pour over every single case for each VR tag
  vr: string;
  Value?: Array<string | number | AlphabeticSubObject | DicomTags>;
  BulkDataURI?: string;
}

interface AlphabeticSubObject {
  Alphabetic: string;
}

export function getTagValueAsString(tagsJson: DicomTags, tagID: string, toUpper: boolean = false): string | null {
  if (!tagsJson) {
    return null;
  }

  const tagObject = tagsJson[tagID];
  if (tagObject) {
    const tagValue = parseTagAsString(tagObject);
    if (tagValue) {
      return toUpper ? tagValue.toUpperCase().trim() : tagValue.trim();
    }
  }

  return null;
}
export function getTagValueAsNumber(tagsJson: DicomTags, tagID: string): number | null {
  const valueStr = getTagValueAsString(tagsJson, tagID);
  if (valueStr) {
    const value: number | null = Number(valueStr);
    if (isNaN(value)) {
      console.error(`getTagValueAsNumber: invalid value - ${valueStr}`);
      return null;
    }
    return value;
  }
  return null;
}

export function parseTagAsString(tagObject: DicomTagObject): string | null {
  if (tagObject) {
    let tagValue: string | null = null;
    const tagVR = tagObject.vr;
    const subObject = tagObject.Value;

    if (subObject) {
      switch (tagVR) {
        case DICOM_VR.PersonName:
          if (subObject.length > 0) {
            tagValue = (subObject[0] as AlphabeticSubObject).Alphabetic;
          }
          break;

        case DICOM_VR.SequenceOfItems:
          tagValue = 'Sequence';
          break;

        default:
          tagValue = condenseTag(subObject);
      }

      return tagValue;
    }
  }
  return null;
}

export function parseAllTags(tags?: DicomTags): IDicomTagDetails[] {
  const entries: IDicomTagDetails[] = [];

  if (tags) {
    traverseJSON(tags, (key, value): boolean => {
      const description = ReverseTagMap.tagMap.get(key) || 'Unrecognized Tag';
      const tagValue = parseTagAsString(value);
      entries.push({
        key,
        description,
        value: tagValue || '',
      });
      return tagValue === 'Sequence';
    });
  }

  return entries;
}

export function getDicomInstance(tags: DicomTags): IDicomInstance {
  const instance: IDicomInstance = {
    studyInstanceUID: getTagValueString(tags, DICOM_ALLTAGS.StudyInstanceUID),
    seriesInstanceUID: getTagValueString(tags, DICOM_ALLTAGS.SeriesInstanceUID),
    sopInstanceUID: getTagValueString(tags, DICOM_ALLTAGS.SOPInstanceUID)
  };
  return instance;
}

export function getDicomInstanceObjectKey(instance: IDicomInstance): string {
  return `${instance.studyInstanceUID}-${instance.seriesInstanceUID}` + instance != null ? `-${instance.sopInstanceUID}` : '';
}

export function getModality(tags: DicomTags): string {
  return getTagValueString(tags, DICOM_ALLTAGS.Modality).toUpperCase();
}

export function compareDicomDatetime(datetime1: string, datetime2: string): number {
  const dt1 = dayjs(datetime1, 'YYYYMMDDHHmmss', true).format('YYYYMMDD HHmmss').split(' ');
  const dt2 = dayjs(datetime1, 'YYYYMMDDHHmmss', true).format('YYYYMMDD HHmmss').split(' ');
  return compareDicomDateAndTime(dt1[0], dt2[0], dt1[1], dt2[1]);
}

export function compareDicomDateAndTime(date1: string, time1: string, date2: string, time2: string): number {
  const dateCompare = compareDicomDate(date1, date2);
  return dateCompare !== 0 ? dateCompare : compareDicomTime(time1, time2);
}

export function compareDicomDate(date1: string, date2: string): number {
  if (date1 !== date2) {
    return Number(date1) > Number(date2) ? 1 : -1;
  }
  return 0;
}

export function compareDicomTime(time1: string, time2: string): number {
  if (time1 !== time2) {
    return Number(time1) > Number(time2) ? 1 : -1;
  }
  return 0;
}

export function deltaTimeInSeconds(startTime: string, endTime: string): number {
  const startHour = parseInt(startTime.substring(0, 2));
  const startMin = parseInt(startTime.substring(2, 4));
  const startSecond = parseFloat(startTime.substring(4));

  const endHour = parseInt(endTime.substring(0, 2));
  const endMin = parseInt(endTime.substring(2, 4));
  const endSecond = parseFloat(endTime.substring(4));

  const hourDelta = (endHour - startHour) * 60 * 60;
  const minDelta = (endMin - startMin) * 60;
  const secondDelta = (endSecond - startSecond);

  return hourDelta + minDelta + secondDelta;
}

function getTagValueString(tags: DicomTags, id: string): string {
  const value = getTagValueAsString(tags, id);
  return value ? value : '';
}

function traverseJSON(tagObject: DicomTags, callback: (key: string, value: DicomTagObject) => boolean): void {
  for (const [key, object] of Object.entries(tagObject)) {
    if (callback(key, object)) {
      // Deal with all the elements at this level.
      const values = object.Value;
      if (Array.isArray(values)) {
        values.forEach(value => traverseJSON(value as DicomTags, callback));
      }
    }
  }
}

function condenseTag(full: any): string | null{
  let first = true;
  let condensed = '';
  if (full.length === 1) {
    return String(full[0]);
  }

  for (const val of full) {
    const tagValue = String(val);
    if (!first) {
      condensed += '\\';
    }
    if (tagValue && tagValue.trim) {
      condensed += tagValue.trim();
    } else {
      condensed += ' ';
      return null;
    }
    first = false;
  }
  return condensed;
}
