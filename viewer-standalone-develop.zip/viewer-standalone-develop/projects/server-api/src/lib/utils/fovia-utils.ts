import Fovia from 'foviaapi';
import HTMLViewport = Fovia.UI.HTMLViewport;
export function isCadAIGraphicLayer(graphicLayer: string): boolean {
  return (graphicLayer === Fovia.Util.Constants.CALCIFICATION_CLUSTER ||
    graphicLayer === Fovia.Util.Constants.MAMMOGRAPHY_BREAST_DENSITY);
}

export function makeImageKey(imageUID: string, frameNumber: number): string {
  return imageUID + '_' + frameNumber;
}

export function makeCopiedImageKey(imageUID: string, frameNumber: number, copyNumber: number): string {
  return makeImageKey(imageUID, frameNumber) + '_' + copyNumber;
}

export function makeImageKeyFromImageTags(tags: Fovia.DICOMImageTags): string {
  return makeImageKey(tags.sopInstanceUID.trim(), tags.frameNumber);
}

export function setFoviaBufferDataType(buffer: ArrayBuffer, bitsAllocated: number, pixelRepresentation: number): Int8Array | Uint8Array | Int16Array | Uint16Array {
  if (bitsAllocated === 8) {
    return (pixelRepresentation === 0) ? new Uint8Array(buffer) : new Int8Array(buffer);
  } else /* if (bitsAllocated === 16) */ {
    return (pixelRepresentation === 0) ? new Uint16Array(buffer) : new Int16Array(buffer);
  }
}


// getRenderEngineActive() and setRenderEngineActive() are used to workaround the Fovia SDK's tracking of when a viewport has an active
// render.  The SDK will short circuit the client-side rendering pipeline if a render is already active.  This can cause rendering to
// hang in our app because we have our own active render tracking, and we rely on every render we request calling our client callback
// when completed.
// todo: When Fovia's implementation of this has settled, rely on normal typing
export function getRenderEngineActive(vp: HTMLViewport): boolean {
  return ((vp.getRenderEngine() as any).getRenderEngineActive != null)
    ? (vp.getRenderEngine() as any).getRenderEngineActive()
    : false;
}
export function setRenderEngineActive(vp: HTMLViewport, isActive: boolean): void {
  if ((vp.getRenderEngine() as any).setRenderEngineActive != null) {
    (vp.getRenderEngine() as any).setRenderEngineActive(isActive);
  }
}

// updateActiveEngine is used to work around difficulty accessing a private method for
// updating the renderparams for the currently active engine -- whenever the imageNumber
// is changed. Fovia takes care of doing this in their adaptors ... which we're not using.
export function updateActiveEngine(vp: HTMLViewport, rp: Fovia.RenderParams2D): boolean {
  const reContext: any = vp.getRenderEngine() as any;
  if ((vp.getRenderEngine() as any).updateActiveEngine != null) {
    (vp.getRenderEngine() as any).updateActiveEngine(rp);
    return true;
  }
  return false;
}

export function getFoviaClientConnectionId(): string {
  if (Fovia.ServerContext) {
    const nodeServer = Fovia.ServerContext.getPrivateNodeServer();
    if (nodeServer) {
      return nodeServer.server.io.engine.id;
    }
  }
  return 'none';
}

export function findInvalidImageFrames(studyInstanceUID: string, scanDirResults: Fovia.ScanDirResults): string[] {
  const failedImageKeys: string[] = [];
  try {
    const foviaSeries = scanDirResults.findStudy(studyInstanceUID);
    for (const series of foviaSeries) {
      if (series.isNonImageSeries ||
        series.dicomSeries == null ||
        series.dicomSeries.getNumImages == null ||
        series.dicomSeries.imageTags == null) {
        continue;
      }
      for (let i = 0; i < series.dicomSeries.getNumImages(); i++) {
        const tags = series.dicomSeries.imageTags[i];

        // 'totalFrames = 0' is an indicator that a frame is invalid
        if (tags != null && tags.totalFrames != null && tags.totalFrames <= 0) {
          failedImageKeys.push(makeImageKey(tags.sopInstanceUID, tags.frameNumber));
        }
      }
    }
    if (failedImageKeys.length > 0) {
      console.error(`findInvalidImageFrames: found ${failedImageKeys.length} bad image frames`, failedImageKeys);
    }
  } catch (err) {
    console.error(`findInvalidImageFrames failed: ${err}`);
  }
  return failedImageKeys;
}

export function calcImagePixelsByteCountFromTags(tags: Fovia.DICOMImageTags) {
  // In theory, according to DICOM, 'BitsAllocated' could be 1 or a multiple of 8.
  let bytesPerPixel: number;
  if (tags.bitsAllocated === 1) {
    bytesPerPixel = 1 / 8;  // really odd case of 1 bit per pixel.
  } else {
    bytesPerPixel = Math.ceil(tags.bitsAllocated / 8);
  }
  return tags.rows * tags.cols * bytesPerPixel * tags.samplesPerPixel;
}

export function isMultiFrameImageFrame(sdc: Fovia.SeriesDataContext, image_num: number): boolean {
  if (image_num < 0 || image_num > sdc.imageTags.length - 1) {
    console.error(`isMultiFrameImageFrame: image_num "${image_num}" out of range`);
    return false;
  }
  const tags = sdc.imageTags[image_num];
  const totalFrames = tags.totalFrames ?? 1;
  return totalFrames > 1;
}

export function isTomoImageFrame(sdc: Fovia.SeriesDataContext, image_num: number): boolean {
  return sdc.modality === 'MG' && isMultiFrameImageFrame(sdc, image_num);
}

export function getPendingRenderParams2D(vp: Fovia.UI.HTMLViewport2D): Fovia.RenderParams2D {
  let rp = vp.getRenderEngine().getPendingRenderParams();
  if (rp == null) {
    rp = vp.getRenderEngine().getCachedRenderParams();
  }
  return rp;
}

export function getPendingRenderParams3D(vp: Fovia.UI.HTMLViewport3D): Fovia.RenderParams3D {
  const rp = vp.getRenderEngine().getCachedRenderParams();
  return rp;
}

export function getPendingRenderParamsFusion(vp: Fovia.UI.HTMLFusionViewportMPR): Fovia.RenderParams3D[] {
  const renderEngines: Fovia.BlendedRenderEngineContext3D[] = vp.getRenderEngine().renderEngineList;
  const rps: Fovia.RenderParams3D[] = [];

  for (const engine of renderEngines) {
    const rp = engine.getCachedRenderParams();
    rps.push(rp);
  }
  return rps;
}

export function estimateOpfsMBytesForFoviaExam(exam: Fovia.ScanDirSeriesResults[]): number {
  const bytesPerPixel = 2;
  const imageOverheadBytes = 500;
  const examOverheadBytes = 0;
  const estLutSizeBytes = 95000;

  const estLutsPerImage = (sdc: Fovia.SeriesDataContext): number => {
    const modality = sdc.modality.toUpperCase().trim();
    return (modality === 'CR' || modality === 'DX')
      ? 1
      : 0;
  }

  let pixelCount = 0;
  let imageCount = 0;
  let estLutCount = 0;
  for (const series of exam) {
    if (series.isNonImageSeries) {
      continue;
    }
    const sdc = series.dicomSeries;
    const lutsPerImage = estLutsPerImage(sdc);
    for (let i = 0; i < sdc.imageCount; i++) {
      imageCount++;
      estLutCount += lutsPerImage;
      const tags = sdc.imageTags[i];
      pixelCount += tags.rows * tags.cols;
    }
  }
  const totalPixelBytes = pixelCount * bytesPerPixel,
        totalImageOverheadBytes = imageCount * imageOverheadBytes,
        totalLutBytes = estLutCount * estLutSizeBytes,
        totalExamMB = (examOverheadBytes + totalImageOverheadBytes + totalPixelBytes + totalLutBytes) / (1024 * 1024),
        fudgeFactorMB = 100;
  return totalExamMB + fudgeFactorMB;
}

