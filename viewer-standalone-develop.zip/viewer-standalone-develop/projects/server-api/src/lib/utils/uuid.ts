export type UUID = string;

/**
 * Generate a new UUID version 4 value.
 * @returns A string conforming to the UUID version 4 specification. See RFC4122.
 */
export function uuid4(): UUID {
  // Copied from StackOverflow because it was self-contained. See:
  // https://stackoverflow.com/questions/1320568/best-way-to-generate-unique-ids-client-side-with-javascript
  const guidHolder = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
  const hex = '0123456789abcdef';
  let r = 0;
  let guidResponse = '';
  for (let i = 0; i < 36; i++) {
    if (guidHolder[i] !== '-' && guidHolder[i] !== '4') {
      // each x and y needs to be random
      r = (Math.random() * 16) | 0;
    }

    if (guidHolder[i] === 'x') {
      guidResponse += hex[r];
    } else if (guidHolder[i] === 'y') {
      // clock-seq-and-reserved first hex is filtered and remaining hex values are random
      r &= 0x3; // bit and with 0011 to set pos 2 to zero ?0??
      r |= 0x8; // set pos 3 to 1 as 1???
      guidResponse += hex[r];
    } else {
      guidResponse += guidHolder[i];
    }
  }

  return guidResponse;
}
