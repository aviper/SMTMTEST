import { Injectable } from '@angular/core';
import { AuthenticationToken, AuthorizationToken } from '@idgital/vision-auth-interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserCredentialsStoreService } from '../stores';
import { Observable, of } from 'rxjs';

interface IDeleteImage {
  // This should be the orderId
  examId: number;
  seriesDescription: string;
  seriesId: string;
  isImages: boolean;
}

export class DeleteImage implements IDeleteImage {
  constructor(public examId: number,
              public seriesDescription: string,
              public seriesId: string,
              public isImages: boolean) {}
}

@Injectable({
  providedIn: 'root'
})
export class CoreBackendService {
  private _host: URL;
  private userToken: AuthenticationToken | null = null;

  constructor(private http: HttpClient, private userCredentialStore: UserCredentialsStoreService) {
    this._host = new URL(window.origin);
  }

  public set host(host: string | URL) {
    this._host = new URL(host);
    console.log(`${this.constructor.name} core backend service host ${this._host.host}`);
  }

  public get host(): URL {
    return this._host;
  }

  public deleteImages(deleteImage: DeleteImage): Observable<string | null> {
    if (!this.checkUserToken()) {
      return of('check user token validation failed.');
    }

    const headers = this.getHeaders();
    const delete_image: IDeleteImage = {
      examId: deleteImage.examId,
      seriesDescription: deleteImage.seriesDescription,
      seriesId: deleteImage.seriesId,
      isImages: deleteImage.isImages
    };
    const body = JSON.stringify(delete_image);

    try{
      return this.http.post<null>(`${this.host}orders/deleteImages`,
        body, {
        headers: new HttpHeaders(headers)
        });
    } catch (error) {
      console.error(`${this.constructor.name} core delete image error occurred`, error);
      return of(error as string);
    }
  }

  private getHeaders(): any {
    const headers: any = {
      'Content-Type': 'application/json'
    };
    if (this.userToken) {
      headers['Authorization'] = `Bearer ${this.userToken}`;
    }
    return headers;
  }

  private checkUserToken(): boolean {
    if (this.userCredentialStore.current === null) {
      console.error(`${this.constructor.name} checkUserToken failed. UserCredentials is null.`);
      return false;
    }

    if (this.userCredentialStore.current.authToken == null || this.userCredentialStore.current.authToken.length === 0) {
      console.error(`${this.constructor.name} checkUserToken failed. AuthToken is not present.`);
      return false;
    }

    this.userToken = this.userCredentialStore.current.authToken;
    return true;
  }
}
