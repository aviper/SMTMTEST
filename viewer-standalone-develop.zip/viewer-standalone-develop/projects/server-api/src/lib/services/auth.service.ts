// auth.service.ts - Interact with the authentication and authorization services (token-auth) via Fovia plugins.
import { Injectable } from '@angular/core';
import Fovia from 'foviaapi';

import {
  AuthorizationToken,
  ExamGroupId,
  IExamGroupDefinition,
  IExamGroupExamInformation,
  UserId
} from '@idgital/vision-auth-interface';
import { ExamId } from '@idgital/vision-interface';


import { getFoviaClientConnectionId, UserCredentials } from '../utils';
import { validateExamGroupDefinition, validateExamGroupExam } from '../models';
import { ExamAuthorizationContext, ExamGroupAuthorizationContext } from '../context';
import { LOG_LEVEL, LOG_SCOPE, LOG_SOURCE, LogSupport } from '../fovia/log-support';


/**
 * Generate a masked version of a sensitive value, suitable for inclusion in log messages.
 * @param value The sensitive value.
 * @param n [n=6] The maximum number of characters of `value` to included in the masked value.
 * @returns The masked value, including only the last `n` characters of `value`.
 */
function mask(value: string, n: number= 6): string {
  if (value.length >= n) {
    return `***${value.substring(value.length - n)}`;
  } else {
    return `***${value}`;
  }
}

// Types returned by Fovia group-auth and study-auth plugins - only needed in this module
interface AuthPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
  };
}

interface StudyAuthorizedData { // The user is authorized to access the exam
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  examInformation: IExamGroupExamInformation;
}

interface StudyNotAuthorizedData { // The user is not authorized to access the exam
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
}

interface ExamGroupAuthorizedData { // The user is authorized to access the exam group
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  tokenIndex: number;
  examGroup: IExamGroupDefinition;
}

interface ExamGroupNotAuthorizedData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  tokenIndex: number;
}

// Types returned by AuthService
export class ExamGroupAccessResult {
  authorizedExamGroups: ExamGroupId[];
  unauthorizedSessionTokens: AuthorizationToken[];
  allAuthorized: boolean;
  userId: UserId;

  constructor(userId: UserId) {
    this.userId = userId;
    this.allAuthorized = false;
    this.authorizedExamGroups = [];
    this.unauthorizedSessionTokens = [];
  }
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() { }

  /**
   * Perform an access check for the authenticated user against one or more exam groups.
   * If the user is authorized to access an exam group, exam information, encryption keys, user preferences, and user access within the exam group is returned.
   * @param sourceName The name of the application making the request, used for logging purposes.
   * @param userCredentials The user credentials to supply with the request.
   * @param context The request context defining the parameters of the operation.
   * @returns A `Promise` that resolves with information about the operation.
   */
  public async resolveExamGroupAccess(sourceName: string, userCredentials: UserCredentials, context: ExamGroupAuthorizationContext): Promise<ExamGroupAccessResult> {
    return new Promise(async (resolve) => {
      const result = new ExamGroupAccessResult(userCredentials.userId);
      const userId = userCredentials.userId;
      const userAuthToken = userCredentials.authToken;
      const sessionTokens = context.accessTokens;
      const clientId = getFoviaClientConnectionId();
      const initTimestamp = performance.now();
      const markName = `resolve-group.${initTimestamp}`;
      const markNameBase = `${initTimestamp}`;
      const markNameBeg = `rg.${markNameBase}.beg`;
      const markNameEnd = `rg.${markNameBase}.end`;
      const tokenCount = sessionTokens ? sessionTokens.length : 0;
      const checkAuthPayload = {
        pluginjs: 'synth-fovia/group-auth.plugin',
        userId,
        sourceName,
        userAuthToken,
        sessionTokens
      };


      try {
        performance.mark(markNameBeg);
        const checkAuthEvents = new Map();
        checkAuthEvents.set('authorized', (args: any, authData: ExamGroupAuthorizedData) => {
          const maskedSessionToken = mask(sessionTokens[authData.tokenIndex]);
          console.log(`${this.constructor.name} [${clientId}] [${authData.promiseID}] [${userId}] [${maskedSessionToken}] User authorized to access exam group`, authData.examGroup);
          if (validateExamGroupDefinition(authData.examGroup)) {
            const examGroupId = context.onExamGroupAccessAuthorized(authData.tokenIndex, authData.examGroup);
            result.authorizedExamGroups.push(examGroupId);
            performance.mark('rg.authorized', {
              detail: {
                sourceName,
                tokenIndex: authData.tokenIndex,
                examGroupId
              }
            });
          } else {
            console.error(`${this.constructor.name} [${clientId}] [${authData.promiseID}] [${userId}] [${maskedSessionToken}] Invalid exam group data returned from server - see server logs`, authData.examGroup);
            context.onExamGroupAccessUnauthorized(authData.tokenIndex, /* notAuthorized=*/false);
            result.unauthorizedSessionTokens.push(sessionTokens[authData.tokenIndex]);
            performance.mark('rg.invalid', {
              detail: {
                sourceName,
                tokenIndex: authData.tokenIndex,
                definition: authData.examGroup
              }
            });
          }
        });
        checkAuthEvents.set('unauthorized', (args: any, errData: ExamGroupNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionTokens[errData.tokenIndex]);
          console.error(`${this.constructor.name} [${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] User is not authorized to access exam group`, errData);
          context.onExamGroupAccessUnauthorized(errData.tokenIndex, /*notAuthorized=*/true);
          result.unauthorizedSessionTokens.push(sessionTokens[errData.tokenIndex]);
          performance.mark('rg.unauthorized', {
            detail: {
              sourceName,
              tokenIndex: errData.tokenIndex
            }
          });
        });
        checkAuthEvents.set('failure', (args: any, errData: ExamGroupNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionTokens[errData.tokenIndex]);
          console.error(`${this.constructor.name} [${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] Token check failed - see server logs`, errData);
          context.onExamGroupAccessUnauthorized(errData.tokenIndex, /*notAuthorized=*/false);
          result.unauthorizedSessionTokens.push(sessionTokens[errData.tokenIndex]);
          performance.mark('rg.failure', {
            detail: {
              sourceName,
              tokenIndex: errData.tokenIndex
            }
          });
        });

        const response = await Fovia.ServerContext.callCustomJSFunction(checkAuthPayload, checkAuthEvents) as AuthPluginResponse;
        // - response.result.success is true if all tokens were authorized
        // - response.result.success is false if any token was unauthorized/failure
        if (response.result.success) {
          console.log(`${this.constructor.name} [${clientId}] [----] [${userId}] User is authorized to access all ${sessionTokens.length} exam group(s)`);
          result.allAuthorized = true;
        } else {
          console.error(`${this.constructor.name} [${clientId}] [----] [${userId}] User is not authorized to access one or more exam groups`);
          result.allAuthorized = false;
        }
      } catch (err) {
        console.error(`${this.constructor.name} [${clientId}] [----] [${userId}] Error resolving session tokens`, err);
        result.allAuthorized = false;
      } finally {
        performance.mark(markNameEnd);
        performance.measure(markName, {
          detail: {
            userId,
            sourceName,
            tokenCount
          },
          start: markNameBeg,
          end: markNameEnd
        });
        resolve(result);
      }
    });
  }

  /**
   * Perform an access check for the authenticated user for a single exam.
   * This operation is used to perform access checks for ad-hoc comparison exams which were not part of the exam group during initial load.
   * If the user is authorized to access the exam group, and the exam is part of the exam group, exam information is returned.
   * @param sourceName The name of the application making the request, used for logging purposes.
   * @param userCredentials The user credentials to supply with the request.
   * @param context The request context defining the parameters of the operation.
   * @returns A `Promise` that resolves to `true` if all of the exam group authorization checks succeeded, indicating that the user is authorized to access those exam groups, or `false` if one or more checks failed for some reason.
   */
  public async resolveExamAccess(sourceName: string, userCredentials: UserCredentials, context: ExamAuthorizationContext): Promise<IExamGroupExamInformation | null> {
    return new Promise(async (resolve) => {
      let examInformation: IExamGroupExamInformation | null = null;
      const userId = userCredentials.userId;
      const userAuthToken = userCredentials.authToken;
      const sessionToken = context.accessToken;
      const studyInstanceUID = context.studyInstanceUID;
      const clientId = getFoviaClientConnectionId();
      const initTimestamp = performance.now();
      const markName = `resolve-study.${studyInstanceUID}`;
      const markNameBeg = `rs.${studyInstanceUID}.beg`;
      const markNameEnd = `rs.${studyInstanceUID}.end`;
      const checkAuthPayload = {
        pluginjs: 'synth-fovia/study-auth.plugin',
        userId,
        sourceName,
        userAuthToken,
        sessionToken,
        studyInstanceUID
      };
      try {
        performance.mark(markNameBeg);
        const checkAuthEvents = new Map();
        checkAuthEvents.set('authorized', (args: any, authData: StudyAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          const errors: Array<string> = [];
          console.log(`${this.constructor.name} [${clientId}] [${authData.promiseID}] [${userId}] [${maskedSessionToken}] User authorized to access exam ${studyInstanceUID}`, authData.examInformation);
          if (validateExamGroupExam(authData.examInformation, errors)) {
            context.onExamAccessAuthorized(authData.examInformation);
            examInformation = authData.examInformation;
            performance.mark('rs.authorized', {
              detail: {
                sourceName,
                studyInstanceUID
              }
            });
          } else {
            console.error(`${this.constructor.name} [${clientId}] [${authData.promiseID}] [${userId}] [${maskedSessionToken}] Exam information validation failed for ${studyInstanceUID}`, authData.examInformation, errors);
            context.onExamAccessUnauthorized(/*notAuthorized=*/false);
            examInformation = null;
          }
        });
        checkAuthEvents.set('unauthorized', (args: any, errData: StudyNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`${this.constructor.name} [${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] User is not authorized to access exam ${studyInstanceUID}`, errData);
          context.onExamAccessUnauthorized(/*notAuthorized=*/true);
          performance.mark('rs.unauthorized', {
            detail: {
              sourceName,
              studyInstanceUID
            }
          });
        });
        checkAuthEvents.set('failure', (args: any, errData: StudyNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`${this.constructor.name} [${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] Token check failed for exam ${studyInstanceUID} - see server logs`, errData);
          context.onExamAccessUnauthorized(/*notAuthorized=*/false);
          performance.mark('rs.failure', {
            detail: {
              sourceName,
              studyInstanceUID
            }
          });
        });

        await Fovia.ServerContext.callCustomJSFunction(checkAuthPayload, checkAuthEvents) as AuthPluginResponse;
      } catch (err) {
        console.error(`${this.constructor.name} [${clientId}] [----] [${userId}] Error checking access to exam ${studyInstanceUID}`, err);
        examInformation = null;
      } finally {
        performance.mark(markNameEnd);
        performance.measure(markName, {
          detail: {
            userId,
            sourceName,
            studyInstanceUID
          },
          start: markNameBeg,
          end: markNameEnd
        });
        resolve(examInformation);
      }
    });
  }
}
