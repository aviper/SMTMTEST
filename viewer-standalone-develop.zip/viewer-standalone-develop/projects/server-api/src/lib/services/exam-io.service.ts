
import { Injectable } from '@angular/core';
import Fovia from 'foviaapi';

import { getFoviaClientConnectionId, UserCredentials } from '../utils';
import { LOG_LEVEL, LOG_SCOPE, LOG_SOURCE, LogSupport } from '../fovia/log-support';
import { ExamDeleteInstanceContext, ExamLoadContext, ExamUpdateContext, ExamLoadServerPerformanceMetrics } from '../context';
import { IExamGroupExamInformation } from '@idgital/vision-auth-interface';
import { ExamId } from '@idgital/vision-interface';
import { ExamLoadVersion } from '../models';
import { LocalStorageItems } from '../utils';

/**
 * Generate a masked version of a sensitive value, suitable for inclusion in log messages.
 * @param value The sensitive value.
 * @param n [n=6] The maximum number of characters of `value` to included in the masked value.
 * @returns The masked value, including only the last `n` characters of `value`.
 */
function mask(value: string, n: number= 6): string {
  if (value.length >= n) {
    return `***${value.substring(value.length - n)}`;
  } else {
    return `***${value}`;
  }
}

// Types returned by Fovia delete-object, get-pixels, load-study and store-object plugins - only needed in this module

interface DeleteObjectPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
  };
}


interface LoadStudyPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
    haveMetadata: boolean;
    metadataHash: string | undefined;
    scanDirResultsJSON: any;
    performanceMetrics: ExamLoadServerPerformanceMetrics;
  };
}

interface StoreObjectPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
  };
}

interface GetPixelsPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
    pixelDataType: 'none' | 'uncompressed' | 'deflated';
    studyInstanceUID: string;
    seriesInstanceUID: string;
    sopInstanceUID: string;
    imageNumber: number;
    nonImageDataParams: any | undefined;
    pixelBuffer: ArrayBuffer | undefined;
  };
}

interface StudyAuthorizedData { // The user is authorized to access the exam
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  examInformation: IExamGroupExamInformation;
}

interface StudyNotAuthorizedData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  detail: string;
}

interface DicomJsonStudyMetadata {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  loadVersion: ExamLoadVersion;
  metadata: any;
  metadataHash: string;
}

interface MissingStudyData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  httpStatus: number;
  detail: string;
}

interface MissingFrameData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  seriesInstanceUID: string;
  sopInstanceUID: string;
  frameNumber: number;
  httpStatus: number;
  detail: string;
}

interface MissingObjectData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  seriesInstanceUID: string;
  sopInstanceUID: string;
  httpStatus: number;
  detail: string;
}

interface ImageFrameAvailableData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  seriesInstanceUID: string;
  sopInstanceUID: string;
  frameNumber: number;
  haveMetadata: boolean;
}

interface StudyObjectAvailableData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  seriesInstanceUID: string;
  sopInstanceUID: string;
  haveMetadata: boolean;
}

interface StudyDisplayImagesLoadedData {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  studyInstanceUID: ExamId;
  loadVersion: ExamLoadVersion;
  scanDirResultsJSON: any;
  haveMetadata: boolean;
  metadataHash: string;
}

export interface ImagePixelData {
  pixelDataType: 'none' | 'uncompressed' | 'deflated';
  nonImageDataParams: any | null;
  pixelBuffer: ArrayBuffer | null;
}

@Injectable({
  providedIn: 'root'
})
export class ExamIoService {
  private getPixelsEvents = new Map();

  constructor() { }

  /**
   * Load an exam into client session memory on the server.
   * The exam is loaded only if the user provides a valid authentication token, a valid authorization token, and the exam is part of the exam group.
   * @param sourceName The name of the application making the request, used for logging purposes.
   * @param userCredentials The user credentials to supply with the request.
   * @param context The request context defining the parameters of the operation.
   * @returns A `Promise` that resolves to a `Fovia.ScanDirResults` instance, or `null` if the load failed.
   */
  public async loadExam(sourceName: string, userCredentials: UserCredentials, context: ExamLoadContext): Promise<Fovia.ScanDirResults | null> {
    return new Promise(async (resolve) => {
      let result: Fovia.ScanDirResults | null = null;
      const userId = userCredentials.userId;
      const userAuthToken = userCredentials.authToken;
      const sessionToken = context.accessToken;
      const studyInstanceUID = context.studyInstanceUID;
      const metadataHash = context.clientMetadataHash;
      const loadCondition = context.loadCondition;
      const markName = `load-study.${studyInstanceUID}`;
      const markNameBase = `ls.${studyInstanceUID}`;
      const markNameBeg = `${markNameBase}.beg`;
      const markNameEnd = `${markNameBase}.end`;
      const disableTranscoding = LocalStorageItems.disableTranscoding;
      const loadStudyPayload = {
        pluginjs: 'synth-fovia/load-study.plugin',
        userId,
        sourceName,
        userAuthToken,
        sessionToken,
        studyInstanceUID,
        metadataHash,
        loadCondition,
        disableTranscoding
      };
      const loadStartTime = performance.now();
      const initTimestamp = loadStartTime;
      let authTimestamp = loadStartTime;
      let imagesLoadedTime: number | null = null;
      let instanceCount = 0;
      let clientId = 'none';


      try {
        performance.mark(markNameBeg);

        // Retrieving the clientId could fail if the server connection is terminated after the load begins.
        // Make sure the clientId is retrieved inside of the try...catch block.
        clientId = getFoviaClientConnectionId();

        const loadStudyEvents = new Map();
        loadStudyEvents.set('authorized', (args: any, studyData: StudyAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          console.log(`[${clientId}] [${studyData.promiseID}] [${userId}] [${maskedSessionToken}] User is authorized to access exam ${studyInstanceUID}`, studyData);
          context.onExamAccessAuthorized(studyData.examInformation);
          authTimestamp = performance.now();
          performance.mark('ls.authorized', {
            detail: {
              sourceName,
              studyInstanceUID,
              duration: (performance.now() - initTimestamp)
            }
          });
        });
        loadStudyEvents.set('headers', (args: any, dicomJsonMetadata: DicomJsonStudyMetadata) => {
          const maskedSessionToken = mask(sessionToken);
          console.log(`[${clientId}] [${dicomJsonMetadata.promiseID}] [${userId}] [${maskedSessionToken}] Received metadata for exam ${studyInstanceUID}`);
          if (dicomJsonMetadata.metadataHash == null) {
            console.error(`Metadata received has is null`);
          }
          let clientScanDirResults: Fovia.ScanDirResults | undefined;
          if (dicomJsonMetadata.loadVersion === 'client' && context.clientScanDirResultsJSON != null) {
            clientScanDirResults = new Fovia.ScanDirResults(context.clientScanDirResultsJSON);
            console.log(`[${clientId}] [${dicomJsonMetadata.promiseID}] [${userId}] Using client-supplied cached scannedDirResults for ${studyInstanceUID}`);
            resolve(clientScanDirResults);
          } else if (context.clientScanDirResultsJSON != null) {
            console.warn(`[${clientId}] [${dicomJsonMetadata.promiseID}] [${userId}] ${studyInstanceUID} cannot use client-supplied cached scannedDirResults - server's version of exam may be newer`);
          }
          context.onDicomJsonMetadataReceived(dicomJsonMetadata.metadata, dicomJsonMetadata.metadataHash, dicomJsonMetadata.loadVersion, clientScanDirResults);
          performance.mark('ls.headers', {
            detail: {
              sourceName,
              studyInstanceUID,
              duration: (performance.now() - authTimestamp)
            }
          });
        });
        loadStudyEvents.set('loadedframe', (args: any, frameData: ImageFrameAvailableData) => {
          // const maskedSessionToken = mask(sessionToken);
          // console.log(`[${clientId}] [${frameData.promiseID}] [${userId}] [${maskedSessionToken}] Loaded display frame ${frameData.frameNumber} for exam ${studyInstanceUID}`, frameData);
          context.onImageFrameLoaded(frameData.seriesInstanceUID, frameData.sopInstanceUID, frameData.frameNumber);
          /* performance.mark('ls.loadframe', {
            detail: {
              sourceName,
              studyInstanceUID,
              seriesInstanceUID: frameData.seriesInstanceUID,
              sopInstanceUID: frameData.sopInstanceUID,
              frameNumber: frameData.frameNumber
            }
          }); */
        });
        loadStudyEvents.set('loadedobject', (args: any, instanceData: StudyObjectAvailableData) => {
          // const maskedSessionToken = mask(sessionToken);
          // console.log(`[${clientId}] [${instanceData.promiseID}] [${userId}] [${maskedSessionToken}] Loaded SOP instance ${instanceData.sopInstanceUID} for exam ${studyInstanceUID}`, instanceData);
          context.onSopInstanceLoaded(instanceData.seriesInstanceUID, instanceData.sopInstanceUID);
          instanceCount++;
          /* performance.mark('ls.loadinstance', {
            detail: {
              sourceName,
              studyInstanceUID,
              seriesInstanceUID: instanceData.seriesInstanceUID,
              sopInstanceUID: instanceData.sopInstanceUID
            }
          }); */
        });
        loadStudyEvents.set('displayimagesloaded', (args: any, studyData: StudyDisplayImagesLoadedData) => {
          performance.mark('ls.ready', {
            detail: {
              sourceName,
              studyInstanceUID,
              duration: (performance.now() - authTimestamp)
            }
          });

          // const maskedSessionToken = mask(sessionToken);
          // console.log(`[${clientId}] [${studyData.promiseID}] [${userId}] [${maskedSessionToken}] Loaded display images for exam ${studyInstanceUID}`, studyData);
          const scanDirResults = new Fovia.ScanDirResults(studyData.scanDirResultsJSON);

          // The exam (but not necessarily all of its images) is now ready to be loaded into the viewer
          result = scanDirResults;
          context.onDisplayImagesLoaded(scanDirResults, studyData.scanDirResultsJSON, studyData.metadataHash, studyData.loadVersion);
          imagesLoadedTime = performance.now();
          performance.mark('ls.resolve', {
            detail: {
              sourceName,
              studyInstanceUID,
              duration: (performance.now() - authTimestamp)
            }
          });

          resolve(result);
        });
        loadStudyEvents.set('missingstudy', (args: any, errData: MissingStudyData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] Backend missing exam ${studyInstanceUID}`, errData);
          context.onExamNotAvailable(errData.httpStatus, errData.detail, /*notAuthorized=*/false);
          performance.mark('ls.notfound', {
            detail: {
              sourceName,
              studyInstanceUID
            }
          });
        });
        loadStudyEvents.set('missingframe', (args: any, errData: MissingFrameData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] Backend missing frame ${errData.frameNumber} of SOP instance ${errData.sopInstanceUID} of exam ${studyInstanceUID}`, errData);
          context.onImageFrameNotAvailable(errData.seriesInstanceUID, errData.sopInstanceUID, errData.frameNumber, errData.httpStatus, errData.detail);
          performance.mark('ls.noframe', {
            detail: {
              sourceName,
              studyInstanceUID,
              seriesInstanceUID: errData.seriesInstanceUID,
              sopInstanceUID: errData.sopInstanceUID,
              frameNumber: errData.frameNumber
            }
          });
        });
        loadStudyEvents.set('missingobject', (args: any, errData: MissingObjectData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] Backend missing SOP instance ${errData.sopInstanceUID} of exam ${studyInstanceUID}`, errData);
          context.onSopInstanceNotAvailable(errData.seriesInstanceUID, errData.sopInstanceUID, errData.httpStatus, errData.detail);
          instanceCount++;
          performance.mark('ls.noinstance', {
            detail: {
              sourceName,
              studyInstanceUID,
              seriesInstanceUID: errData.seriesInstanceUID,
              sopInstanceUID: errData.sopInstanceUID
            }
          });
        });
        loadStudyEvents.set('unauthorized', (args: any, errData: StudyNotAuthorizedData) => {
          authTimestamp = performance.now();
          performance.mark('ls.unauthorized', {
            detail: {
              sourceName,
              studyInstanceUID,
              duration: (performance.now() - initTimestamp),
              detail: errData.detail
            }
          });
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] User is not authorized to access exam ${studyInstanceUID}`, errData);
          context.onExamNotAvailable(-1, errData.detail, /*notAuthorized=*/true);
        });

        console.log(`[${clientId}] [----] [${userId}] Begin load of exam ${studyInstanceUID}`);
        const reqtx = performance.now();
        const response = await Fovia.ServerContext.callCustomJSFunction(loadStudyPayload, loadStudyEvents) as LoadStudyPluginResponse;
        const resrx = performance.now();
        if (response.result.success) {
          console.log(`[${clientId}] [----] [${userId}] Completed load of exam ${studyInstanceUID}`);
          const scanDirResults = new Fovia.ScanDirResults(response.result.scanDirResultsJSON);
          result = scanDirResults;
        } else {
          console.error(`[${clientId}] [----] [${userId}] Failed to load exam ${studyInstanceUID} - check server logs`, response.result.message);
        }
        const serverMetrics = response.result.performanceMetrics;
        if (serverMetrics) {
          context.onServerPerformanceMetricsReady(serverMetrics);
        }
      } catch (err) {
        // Note - if clientId is 'none' here, the client connection was forcibly terminated in the middle of the call.
        console.error(`[${clientId}] [----] [${userId}] Exception loading study ${studyInstanceUID}`, err);
        performance.mark('ls.exception', {
          detail: {
            sourceName,
            studyInstanceUID,
            err
          }
        });
        result = null;
      } finally {
        // if (imagesLoadedTime != null) {
        //   const totalTime = (performance.now() - loadStartTime) / 1000;
        //   const savedSecs = (performance.now() - imagesLoadedTime) / 1000;
        //   console.log(`We saved ${savedSecs.toFixed(2)} secs.  From ${totalTime.toFixed(2)} to ${(totalTime - savedSecs).toFixed(2)}`);
        // } else {
        //   console.log(`Oh well.  No time saved loading exam`);
        // }
        performance.mark(markNameEnd);
        performance.measure(markName, {
          detail: {
            sourceName,
            studyInstanceUID,
            instanceCount
          },
          start: markNameBeg,
          end: markNameEnd
        });
        context.onServerExamLoadComplete();
        resolve(result);
      }
    });
  }

  /**
   * Retrieve source pixel data for a specific image frame.
   * The pixel data may be returned compressed using the deflate algorithm to improve transfer performance.
   * @param studyInstanceUID The DICOM Study Instance UID of the study defining the image.
   * @param seriesInstanceUID The DICOM Series Instance UID of the series defining the image.
   * @param sopInstanceUID The DICOM SOP Instance UID of the SOP instance defining the image.
   * @param imageNumber The Fovia internal image number.
   * @param uniqueId A string of the form `seriesInstanceUID.subSeriesID`, where `subSeriesID` is the Fovia sub-series index.
   * @param imageKey A string of the form `sopInstanceUID_frameNumber`, where `frameNumber` is the Fovia frame index.
   * @returns A `Promise` that resolves to an object containing LUTs and the raw pixel data buffer.
   */
  public async loadImagePixelData(sourceName: string, studyInstanceUID: ExamId, seriesInstanceUID: string, sopInstanceUID: string, imageNumber: number, uniqueId: string, imageKey: string): Promise<ImagePixelData | null> {
    return new Promise(async (resolve) => {
      let pixelDataType: 'none' | 'uncompressed' | 'deflated' = 'none';
      let nonImageDataParams = null;
      let pixelBuffer = null;
      const clientId = getFoviaClientConnectionId();
      const initTimestamp = performance.now();
      const getPixelsPayload = {
        pluginjs: 'synth-fovia/store-object.plugin',
        sourceName,
        studyInstanceUID,
        seriesInstanceUID,
        sopInstanceUID,
        imageNumber,
        uniqueId,
        imageKey,
        failAfterMilliseconds: 10000
      };

      try {
        const getPixelsEvents = this.getPixelsEvents;
        // - no events reported by this plugin
        // console.log(`[${clientId}] [----] [${userId}] Request pixels for ${studyInstanceUID} image ${imageKey}`);
        const response = await Fovia.ServerContext.callCustomJSFunction(getPixelsPayload, getPixelsEvents) as GetPixelsPluginResponse;
        if (response.result.success && response.result.pixelBuffer !== undefined && response.result.nonImageDataParams !== undefined) {
          pixelDataType = response.result.pixelDataType;
          nonImageDataParams = response.result.nonImageDataParams;
          pixelBuffer = response.result.pixelBuffer;
          /* performance.mark('px.get', {
            detail: {
              sourceName,
              imageKey,
              pixelDataType,
              length: pixelBuffer.byteLength,
              duration: (performance.now() - initTimestamp)
            }
          }); */
        } else {
          console.error(`[${clientId}] [----] Failed to retrieve pixels for ${studyInstanceUID} image ${imageKey} - ${response.result.message}`, response.result);
        }
      } catch (err) {
        console.error(`[${clientId}] [----] Exception while retrieving pixels for ${studyInstanceUID} image ${imageKey}`, err);
      } finally {
        if (pixelDataType === 'none') {
          resolve(null);
        } else {
          resolve({
            pixelDataType,
            nonImageDataParams,
            pixelBuffer
          });
        }
      }
    });
  }

  /**
   * Write a SOP instance to the healthcare backend.
   * The SOP instance is stored only if the user provides a valid authentication token, a valid authorization token, the exam is part of the exam group and the user has the correct permissions within the exam group.
   * @param sourceName The name of the application making the request, used for logging purposes.
   * @param userCredentials The user credentials to supply with the request.
   * @param context The request context defining the parameters of the operation.
   * @returns A `Promise` that resolves to `true` if the store operation completed successfully or `false` if the store operation failed.
   */
  public async storeInstance(sourceName: string, userCredentials: UserCredentials, context: ExamUpdateContext): Promise<boolean> {
    return new Promise(async (resolve) => {
      let success = false;
      const clientId = getFoviaClientConnectionId();
      const userId = userCredentials.userId;
      const userAuthToken = userCredentials.authToken;
      const sessionToken = context.accessToken;
      const studyInstanceUID = context.studyInstanceUID;
      const sopInstanceUID = context.sopInstanceUID;
      const dicomBuffer = context.dicomBuffer;
      const objectKey = context.sopInstanceUID;
      const markName = `store-instance.${sopInstanceUID}`;
      const markNameBase = `si.${sopInstanceUID}`;
      const markNameBeg = `${markNameBase}.beg`;
      const markNameEnd = `${markNameBase}.end`;
      const storeObjectPayload = {
        pluginjs: 'synth-fovia/store-object.plugin',
        userId,
        sourceName,
        userAuthToken,
        sessionToken,
        studyInstanceUID,
        dicomBuffer,
        objectKey
      };

      try {
        performance.mark(markNameBeg);
        const storeObjectEvents = new Map();
        storeObjectEvents.set('unauthorized', (args: any, errData: StudyNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] User is not authorized to access exam ${studyInstanceUID}`, errData);
          context.onExamAccessUnauthorized(/*notAuthorized=*/true);
          performance.mark('si.unauthorized', {
            detail: {
              sourceName,
              studyInstanceUID,
              objectKey,
              userId,
              detail: errData.detail
            }
          });
        });

        console.log(`[${clientId}] [----] [${userId}] Begin store of ${sopInstanceUID} to exam ${studyInstanceUID}, ${dicomBuffer.byteLength} byte(s)`);
        const response = await Fovia.ServerContext.callCustomJSFunction(storeObjectPayload, storeObjectEvents) as StoreObjectPluginResponse;
        if (response.result.success) {
          console.log(`[${clientId}] [----] [${userId}] Store of ${sopInstanceUID} to exam ${studyInstanceUID} completed successfully`);
          success = true;
        } else {
          console.error(`[${clientId}] [----] [${userId}] Store of ${sopInstanceUID} to exam ${studyInstanceUID} failed - ${response.result.message}`);
          success = false;
        }
      } catch (err) {
        console.error(`[${clientId}] [----] [${userId}] Exception storing DICOM object ${sopInstanceUID} for exam ${studyInstanceUID}`);
        success = false;
      } finally {
        performance.mark(markNameEnd);
        performance.measure(markName, {
          detail: {
            sourceName,
            studyInstanceUID,
            objectKey
          },
          start: markNameBeg,
          end: markNameEnd
        });
        resolve(success);
      }
    });
  }

  /**
   * Delete a SOP instance from the healthcare backend.
   * The SOP instance is deleted only if the user provides a valid authentication token, a valid authorization token, the exam is part of the exam group and the user has the correct permissions within the exam group.
   * StudyUID/SeriesUID/SopInstanceUID must be provided or the request is rejected.
   *
   * @param sourceName The name of the application making the request, used for logging purposes.
   * @param userCredentials The user credentials to supply with the request.
   * @param context The request context defining the parameters of the operation.
   * @returns A `Promise` that resolves to `true` if the delete operation completed successfully or `false` if the delete operation failed.
   */
  public async deleteInstance(sourceName: string, userCredentials: UserCredentials, context: ExamDeleteInstanceContext): Promise<boolean> {
    return new Promise(async (resolve) => {
      let success = false;
      const clientId = getFoviaClientConnectionId();
      const userId = userCredentials.userId;
      const userAuthToken = userCredentials.authToken;
      const sessionToken = context.accessToken;
      const dicomInstance = context.dicomInstance;
      const key = context.sopInstanceUID != null ? `image-${context.sopInstanceUID}` : `series-${context.dicomInstance.seriesInstanceUID}`;
      const studyInstanceUID = context.studyInstanceUID;
      const objectKey = context.objectKey;
      const markName = `delete-instance.${context.sopInstanceUID}`;
      const markNameBase = `si.${key}`;
      const markNameBeg = `${markNameBase}.beg`;
      const markNameEnd = `${markNameBase}.end`;
      const deleteObjectPayload = {
        pluginjs: 'synth-fovia/delete-object.plugin',
        userId,
        sourceName,
        userAuthToken,
        sessionToken,
        dicomInstance,
      };

      try {
        performance.mark(markNameBeg);
        const storeObjectEvents = new Map();
        storeObjectEvents.set('unauthorized', (args: any, errData: StudyNotAuthorizedData) => {
          const maskedSessionToken = mask(sessionToken);
          console.error(`[${clientId}] [${errData.promiseID}] [${userId}] [${maskedSessionToken}] User is not authorized to access exam ${studyInstanceUID}`, errData);
          context.onExamAccessUnauthorized(/*notAuthorized=*/true);
          performance.mark('di.unauthorized', {
            detail: {
              sourceName,
              studyInstanceUID,
              objectKey,
              userId,
              detail: errData.detail
            }
          });
        });

        console.log(`[${clientId}] [----] [${userId}] Begin delete of ${key} for exam ${studyInstanceUID}`);
        const response = await Fovia.ServerContext.callCustomJSFunction(deleteObjectPayload, storeObjectEvents) as DeleteObjectPluginResponse;
        if (response.result.success) {
          console.log(`[${clientId}] [----] [${userId}] Delete of ${key} for exam ${studyInstanceUID} completed successfully`);
          success = true;
        } else {
          console.error(`[${clientId}] [----] [${userId}] Delete of ${key} for exam ${studyInstanceUID} failed - ${response.result.message}`);
          success = false;
        }
      } catch (err) {
        console.error(`[${clientId}] [----] [${userId}] Exception deleting DICOM object ${key} for exam ${studyInstanceUID}`);
        success = false;
      } finally {
        performance.mark(markNameEnd);
        performance.measure(markName, {
          detail: {
            sourceName,
            studyInstanceUID,
            objectKey
          },
          start: markNameBeg,
          end: markNameEnd
        });
        resolve(success);
      }
    });
  }
}
