import { TestBed } from '@angular/core/testing';

import { MontageService } from './montage.service';

describe('MontageService', () => {
  let service: MontageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MontageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
