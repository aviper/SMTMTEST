import { Injectable } from '@angular/core';
import Fovia from 'foviaapi';

import { getFoviaClientConnectionId, UserCredentials } from '../utils';
import { ClientConfigData } from '../models';

interface ClientConfigPluginResponse {
  promiseID: string; // Note: Fovia requires this exact spelling/casing
  result: {
    success: boolean;
    message: string | undefined;
    configs: ClientConfigData;
    defaults: ClientConfigData;
  }
}

@Injectable({
  providedIn: 'root'
})
export class ClientConfigService {
  constructor() { }

  public async loadConfig(sourceName: string, userId: number, userName?: string): Promise<ClientConfigData | null> {
    return new Promise(async (resolve) => {
      const clientId = getFoviaClientConnectionId();
      const clientConfigEvents = new Map();
      const clientConfigPayload = {
        pluginjs: 'synth-fovia/client-config.plugin',
        sourceName,
        userName,
        userId
      };

      try {
        // - no events reported by this plugin
        console.log(`[${clientId}] [----] [${userId}] [${userName}] Request client configuration`);
        const response = await Fovia.ServerContext.callCustomJSFunction(clientConfigPayload, clientConfigEvents) as ClientConfigPluginResponse;
        if (response.result.success && response.result.configs !== undefined) {
          console.log(`[${clientId}] [${response.promiseID}] [${userId}] [${userName}] Server returned client configuration`, response.result.configs, response.result.defaults);
          resolve(response.result.configs);
        } else {
          console.error(`[${clientId}] [${response.promiseID}] [${userId}] [${userName}] Failed to retrieve client configuration - ${response.result.message}`, response.result);
          resolve(null);
        }
      } catch (err) {
        console.error(`[${clientId}] [----] [${userId}] [${userName}] Exception while querying client configuration`, err);
        resolve(null);
      }
    });
  }
}
