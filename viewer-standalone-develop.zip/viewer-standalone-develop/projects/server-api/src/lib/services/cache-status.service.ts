import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EMPTY, Observable, of } from 'rxjs';

import { CacheStatus, UserId } from '@idgital/cache-status-interface';
import { AuthenticationToken } from '@idgital/pulse-vision-interface';
import { AuthorizationToken } from '@idgital/vision-auth-interface';

import { UserCredentialsStoreService } from '../stores';

/*
The URL for cache-status is http://localhost:8080/api/v1/cache-status with endpoints:
[POST] http://localhost:8080/api/v1/cache-status/update
[GET] http://localhost:8080/api/v1/cache-status/user/USERID
[DELETE] http://localhost:8080/api/v1/cache-status/user/USERID
*/
// cache-status-service doesn't consume data structures form cache-status-inteface
// so current shapes of required objects is exported from here at the moment.
export { CacheStatus, UserId } from '@idgital/cache-status-interface';
export interface IExamCacheStatus {
  studyUID: string;
  cacheStatus: CacheStatus;
  timeStamp: Date;
}

export interface IExamGroupCacheStatus extends IExamGroupStatus {
  examGroup: IExamCacheStatus[];
}

export interface IExamGroupStatus {
  orderId: number;
  userId: UserId;
  examGroupCacheStatus: CacheStatus;
  timeStamp: Date;
}

export class ExamGroupStatusArray {
  constructor(
    public orders: IExamGroupStatus[]
  ) { }
}

class ExamStatusList {
  constructor(
    public exams: IExamCacheStatus[]
  ) { }
}

@Injectable({
  providedIn: 'root'
})
export class CacheStatusService {

  private readonly BASE_URL_V1 = '/api/v1';
  private _host: URL;
  private userToken: AuthenticationToken;
  private userId: UserId;
  public sessionToken: AuthorizationToken;

  constructor(private httpClient: HttpClient,
              private userCredentialStore: UserCredentialsStoreService
  ) {
    this._host = new URL(window.origin);
    this.userToken = '';
    this.userId = -1;
    this.sessionToken = '';
  }

  public set host(host: string) {
    this._host = new URL(host + this.BASE_URL_V1);
    console.log(`${this.constructor.name} host ${host}`, this._host);
  }

  public get host(): URL {
    return this._host;
  }

  // Get HTTP headers supplied when calling cache-status service from frontend (ie. launcher, synthos FE or PZ app)
  private getCacheStatusFrontendHeaders(): any {
    const headers: any = {
      'Content-Type': 'application/json'
    };
    if (this.userToken) {
      headers['Authorization'] = `Bearer ${this.userToken}`;
    }
    if (this.sessionToken) {
      headers['Session'] = this.sessionToken;
    }
    return headers;
  }

  // Get HTTP headers supplied when calling cache-status service from backend (ie. synthos BE)
  private getCacheStatusBackendHeaders(): any {
    const headers: any = {
      'Content-Type': 'application/json',
      'apikey': '1564132' // Must match API_KEY in cache-status-svc section of test-platform/docker-compose.yml; requires special nginx config
    };
    return headers;
  }

  public updateExamGroupStatus(examGroupStatus: IExamGroupCacheStatus): Observable<string | null> {
    if (this.validationsFailed()) {
      return of('');
    }
    const groupStatus: IExamGroupStatus = {
      orderId: examGroupStatus.orderId,
      userId: examGroupStatus.userId,
      examGroupCacheStatus: examGroupStatus.examGroupCacheStatus,
      timeStamp: examGroupStatus.timeStamp
    };

    const body = JSON.stringify(groupStatus);
    const headers = this.getCacheStatusFrontendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      console.info(`${this.constructor.name} updateExamGroupStatus sending ${body}`, options);
      return this.httpClient.post<string | null>(`${this.host}/cache-status/update`, body, options);
    } catch (err) {
      console.error(`${this.constructor.name} updateExamGroupStatus Exception updating exam group cache status:`, err);
      return of(err as string);
    }
  }

  public updateExamsStatus(examStatus: IExamCacheStatus[]): Observable<string | null> {
    if (this.validationsFailed() || this.validateExamsStatusFailed(examStatus)) {
      return of('');
    }
    const examList = {
      exams: examStatus
    };
    // console.info(`${this.constructor.name} updateExamsStatus list is`, examList);
    const body = JSON.stringify(examList);
    const headers = this.getCacheStatusFrontendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      console.info(`${this.constructor.name} updateExamsStatus sending ${body}`, options);
      return this.httpClient.post<string | null>(`${this.host}/cache-status/updateExams`, body, options);
    } catch (err) {
      console.error(`${this.constructor.name} updateExamsStatus Exception updating exam cache status:`, err);
      return of(err as string);
    }
  }

  public getCacheStatusRequestedExams(studyUIDs: string[]): Observable<IExamCacheStatus[] | null> {
    if (this.validationsFailed()) {
      return of(null);
    }
    if (studyUIDs.length === 0) {
      console.info(`${this.constructor.name} getCacheStatusRequestedExams studyUIDs list is empty`);
      return of(null);
    }
    const examList = {
      studyUIDs: studyUIDs
    };
    const body = JSON.stringify(examList);
    const headers = this.getCacheStatusFrontendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.post<IExamCacheStatus[]>(`${this.host}/cache-status/get-exams-cache-status`, body, options);
    } catch (err) {
      console.error(`${this.constructor.name} getCacheStatusForExam exception:`, err);
      return of(null);
    }
  }

  public getExamGroupCacheStatusForUser(userId: UserId): Observable<ExamGroupStatusArray | null> {
    if (this.validationsFailed()) {
      return of(null);
    }
    const headers = this.getCacheStatusBackendHeaders();
    headers['Accept'] = 'application/json';

    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.get<ExamGroupStatusArray>(`${this.host}/cache-status/user/${this.userId}`, options);
    } catch (err) {
      console.error(`${this.constructor.name} getCacheStatus exception:`, err);
      return of(null);
    }
  }

  public getExamCacheStatusForUser(userId: UserId): Observable<IExamCacheStatus[] | null> {
    if (this.validationsFailed()) {
      return of(null);
    }

    const headers = this.getCacheStatusFrontendHeaders();
    headers['Accept'] = 'application/json';

    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.get<IExamCacheStatus[]>(`${this.host}/cache-status/user/${userId}/granulated`, options);
    } catch (err) {
      console.error(`${this.constructor.name} getCacheStatus exception:`, err);
      return of(null);
    }
  }

  public getExamGroupCacheStatusForOrder(orderId: number): Observable<IExamGroupStatus | null> {
    if (this.validationsFailed()) {
      return of(null);
    }

    const headers = this.getCacheStatusBackendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.get<IExamGroupStatus>(`${this.host}/cache-status/user/${this.userId}/order/${orderId}`, options);
    } catch (err) {
      console.error(`${this.constructor.name} getCacheStatusForOrder exception:`, err);
      return of(null);
    }
  }

  public getCacheStatusForExam(studyUID: string): Observable<IExamCacheStatus | null> {
    if (this.validationsFailed()) {
      return of(null);
    }

    const headers = this.getCacheStatusFrontendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.get<IExamCacheStatus>(`${this.host}/cache-status/user/${this.userId}/exam/${studyUID}`, options);
    } catch (err) {
      console.error(`${this.constructor.name} getCacheStatusForExam exception:`, err);
      return of(null);
    }
  }

  public deleteAllCacheStatus(): Observable<string> {
    if (this.validationsFailed()) {
      return EMPTY;
    }

    const headers = this.getCacheStatusFrontendHeaders();
    const options = {
      headers: new HttpHeaders(headers)
    };
    try {
      return this.httpClient.delete<string>(`${this.host}/cache-status/user/${this.userId}`, options);
    } catch (err) {
      console.error(`${this.constructor.name} deleteCacheStatus exception:`, err);
      return of('');
    }
  }

  private validationsFailed(): boolean {
    // We always have a userToken, it's faster to use the sessionToken when we have it.
    return this.validateHostFailed() || (this.validateUserTokenFailed() && this.validateSessionTokenFailed());
  }

  private validateHostFailed(): boolean {
    if (this._host.toString() === '') {
      console.error(`${this.constructor.name} validateHostFailed`);
      return true;
    }
    return false;
  }

  private validateSessionTokenFailed(): boolean {
    if (this.sessionToken === '') {
      console.error(`${this.constructor.name} validateSessionTokenFailed`);
      return true;
    }
    return false;
  }

  private validateUserTokenFailed(): boolean {
    if (this.userCredentialStore.current === null) {
      console.error(`${this.constructor.name} validateUserTokenFailed`);
      return true;
    }
    if (this.userCredentialStore.current.authToken.length === 0) {
      console.error(`${this.constructor.name} validateUserTokenFailed authToken has zero length`);
      return true;
    }

    this.userToken = this.userCredentialStore.current.authToken;
    this.userId = this.userCredentialStore.current.userId;
    // console.log(`${this.constructor.name} validateUserToken ${this.userId} ${this.userToken.slice(1, 20)}`);
    return false;
  }

  private validateExamsStatusFailed(examsStatus: IExamCacheStatus[]): boolean {
    if (examsStatus.length === 0) {
      console.error(`${this.constructor.name} validateExamsStatusFailed list is empty`);
      true;
    }
    for (const exam of examsStatus) {
      if (exam == null) {
        console.error(`${this.constructor.name} validateExamsStatusFailed failed null entry encountered`);
        return true;
      }
      if (!exam.studyUID.includes('.')) {
        console.error(`${this.constructor.name} validateExamsStatusFailed invalid study uid ${exam.studyUID} encountered`);
        return true;
      }
    }
    return false;
  }
}
