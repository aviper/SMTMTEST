import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserCredentialsStoreService } from '../stores';
import { Observable, of } from 'rxjs';
import { AuthenticationToken, AuthorizationToken } from '@idgital/vision-auth-interface';
import { SecondaryCaptureImageIOD } from '../utils';

export class StoreMontageImage {
  constructor(public sessionToken: string,
              public studyUID: string,
              public sopInstanceUID: string,
              public secondaryCaptureImageIOD: SecondaryCaptureImageIOD,
              public isColor: boolean,
              public arrayBuffer: ArrayBuffer) { }
}

@Injectable({
  providedIn: 'root'
})
export class MontageService {
  private readonly BASE_URL_V1 = 'api/v1';
  private _host: URL;
  private userToken: AuthenticationToken | null = null;
  private sessionToken: AuthorizationToken | null = null;

  constructor(private http: HttpClient, private userCredentialStore: UserCredentialsStoreService) {
    this._host = new URL(window.origin);
  }

  public set host(host: string | URL) {
    this._host = new URL(this.BASE_URL_V1, host);
    console.log(`${this.constructor.name} montage service host ${this._host.host}`);
  }

  public get host(): URL {
    return this._host;
  }

  public storeMontage(storeMontageImage: StoreMontageImage): Observable<string | null> {
    if (!this.checkUserToken()) {
      return of('check user token validation failed.');
    }

    if (!this.checkSessionToken(storeMontageImage.sessionToken)) {
      return of('check session token validation failed');
    }

    const headers = {};

    const file_meta = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.fileMeta);
    const patient = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.patient);
    const study = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.study);
    const series = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.series);
    const scEquipment = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.scEquipment);
    const image = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.image);
    const voi_lut = JSON.stringify(storeMontageImage.secondaryCaptureImageIOD.voiLut);

    const formData = new FormData();
    formData.append('buffer', new Blob([storeMontageImage.arrayBuffer]), 'montage_buffer.png');
    formData.append('sop_instance_uid', storeMontageImage.sopInstanceUID);
    formData.append('is_color', storeMontageImage.isColor ? 'true' : 'false');
    formData.append('file_meta', file_meta);
    formData.append('patient', patient);
    formData.append('study', study);
    formData.append('series', series);
    formData.append('sc_equipment', scEquipment);
    formData.append('image', image);
    formData.append('voi_lut', voi_lut);
    formData.append('sessionToken', storeMontageImage.sessionToken);
    formData.append('userAuthToken', this.userToken ?? '');

    try {
      return this.http.post<string | null>(`${this.host}/montage/${storeMontageImage.studyUID}`,
        formData, {
          headers: headers
        });
    } catch (error) {
      console.error(`${this.constructor.name} storeMontage error occurred`, error);
      return of(error as string);
    }
  }

  private getMontageHeaders(sessionToken: string): any {
    const headers: any = {};
    if (this.userToken) {
      headers['Authorization'] = `Bearer ${this.userToken}`;
    }
    if (sessionToken) {
      this.sessionToken = sessionToken;
      headers['Session'] = this.sessionToken;
    }
    return headers;
  }

  private checkSessionToken(sessionToken: string): boolean {
    if (sessionToken == null || sessionToken === '') {
      console.error(`${this.constructor.name} checkSessionToken failed.`);
      return false;
    }
    return true;
  }

  private checkUserToken(): boolean {
    if (this.userCredentialStore.current === null) {
      console.error(`${this.constructor.name} checkUserToken failed. UserCredentials is null.`);
      return false;
    }

    if (this.userCredentialStore.current.authToken == null || this.userCredentialStore.current.authToken.length === 0) {
      console.error(`${this.constructor.name} checkUserToken failed. AuthToken is not present.`);
      return false;
    }

    this.userToken = this.userCredentialStore.current.authToken;
    return true;
  }
}
