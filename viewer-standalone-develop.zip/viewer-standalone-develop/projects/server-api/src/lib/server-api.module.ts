import { NgModule } from '@angular/core';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

import { AuthService } from './services/auth.service';
import { ExamIoService } from './services/exam-io.service';
import { CacheStatusService } from './services/cache-status.service';
import { FoviaConnectService } from './fovia/fovia-connect.service';
import { ServerApiService } from './server-api.service';
import { UserCredentialsStoreService } from './stores';

@NgModule({
  declarations: [
  ],
  imports: [
  ],
  exports: [
  ],
  providers: [
    AuthService,
    ExamIoService,
    CacheStatusService,
    FoviaConnectService,
    ServerApiService,
    UserCredentialsStoreService,
    provideHttpClient(withInterceptorsFromDi())
  ],
})
export class ServerApiModule { }
