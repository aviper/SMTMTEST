import {
  UserId,
  ExamGroupId,
  AuthorizationToken,
  IExamGroupDefinition,
  IExamGroupUserInformation,
  IExamGroupExamInformation
} from '@idgital/vision-auth-interface';
import { ExamId } from '@idgital/vision-interface';

import { HangingProtocol } from './hanging-protocol';

export enum ExamLoadStatus {
  NOT_LOADED = 0,
  LOAD_FAILED = 1,
  LOADED = 2
}

export type ExamLoadCondition = (
  | 'always' // Always proceed with loading the data on the server
  | 'mismatched' // Only load the data on the server if there's a hash mismatch
  | 'never' // Never load the data on the server
  );

export type ExamLoadVersion = (
  | 'client' // Use data cached on the client; it is up-to-date
  | 'server' // Use data loaded on the server; client data may be stale
  );

export function validateExamGroupUser(user: IExamGroupUserInformation, errors: Array<string>): boolean {
  let valid = true;
  if (!user) {
    errors.push('- Missing user attribute');
    valid = false;
  }
  if (!user.encryptionKey) {
    errors.push('- Missing user encryption key');
    valid = false;
  }
  if (!user.permissions) {
    errors.push('- Missing user permissions');
    valid = false;
  }
  if (user.permissions.canEdit == null) {
    errors.push('- Missing user can edit permission');
    valid = false;
  }
  if (user.permissions.canSave == null) {
    errors.push('- Missing user can save permission');
    valid = false;
  }
  if (!user.preferences) {
    errors.push('- Missing user preferences');
    valid = false;
  }
  if (user.preferences.cacheQuotaGB == null) {
    errors.push('- Missing user cache quota preference');
    valid = false;
  }
  return valid;
}

export function validateExamGroupExam(exam: IExamGroupExamInformation, errors: Array<string>): boolean {
  if (!exam) {
    errors.push('- Missing exam information');
    return false;
  }
  if (!exam.studyUID) {
    errors.push('- Missing study instance UID');
    return false;
  }
  if (!exam.examType) {
    errors.push('- Missing exam type');
    return false;
  }
  if (!exam.hangingProtocol) {
    errors.push('- Missing hanging protocol');
    return false;
  }
  if (!exam.dataSourceURL) {
    errors.push('- Missing data source');
    return false;
  }
  return true;
}

export function validateExamGroupDefinition(group: IExamGroupDefinition): boolean {
  const errors: Array<string> = [];
  let valid = true;

  if (!group) {
    valid = false;
  }
  if (!group.orderId) {
    errors.push('- Missing exam group order ID');
    valid = false;
  }
  if (!validateExamGroupUser(group.user, errors)) {
    errors.push('- Invalid user information');
    valid = false;
  }
  if (!validateExamGroupExam(group.primary, errors)) {
    errors.push('- Invalid primary exam definition');
    valid = false;
  }
  if (group.comparisons) {
    for (const comparisonItem of group.comparisons) {
      if (!validateExamGroupExam(comparisonItem, errors)) {
        let studyUID = 'unknown';
        if (comparisonItem && comparisonItem.studyUID) {
          studyUID = comparisonItem.studyUID;
        }
        errors.push(`- Invalid comparison exam definition ${studyUID}`);
        valid = false;
      }
    }
  }
  if (!valid) {
    console.error(`Exam group data validation failed`, errors, group);
  }
  return valid;
}

export class ExamGroupUser {
  public userId: UserId;
  public keyBytes: Uint8Array;
  public canEdit: boolean;
  public canSave: boolean;
  public canDelete: boolean;
  public cacheQuotaGB: number;

  protected importKeyPromise: Promise<CryptoKey> | null = null;

  constructor(group: IExamGroupDefinition) {
    this.userId = group.user.userId;
    this.keyBytes = new Uint8Array(group.user.encryptionKey); // Copy
    // console.log(`${this.constructor.name} userId: ${this.userId} key: ${group.user.encryptionKey}`, group);
    this.canEdit = group.user.permissions.canEdit;
    this.canSave = group.user.permissions.canSave;
    this.canDelete = group.user.permissions.canDelete;
    this.cacheQuotaGB = group.user.preferences.cacheQuotaGB;
  }

  public async getEncryptionKey(): Promise<CryptoKey | null> {
    try {
      if (this.importKeyPromise == null) {
        const dataFormat = 'raw';
        const algorithm = 'AES-GCM';
        const extractable = false;
        const keyUsages: KeyUsage[] = [
          'encrypt',
          'decrypt'
        ];
        this.importKeyPromise = window.crypto.subtle.importKey(dataFormat, this.keyBytes, algorithm, extractable, keyUsages);
      }
      const cryptoKey = await this.importKeyPromise;
      console.log(`${this.constructor.name} userId: ${this.userId} encryptionKey is `, cryptoKey);
      return cryptoKey;

    } catch (err) {
      console.error(`${this.constructor.name} userId: ${this.userId} importKey failed with exception:`, err);
      console.error(`${this.constructor.name} userId: ${this.userId} FATAL/SERIOUS ERROR encryption key is NULL`);
      return null;
    }
  }

  update(group: IExamGroupDefinition): void {
    // UserId, encryption key cannot change
    this.canEdit = group.user.permissions.canEdit;
    this.canSave = group.user.permissions.canSave;
    this.canDelete = group.user.permissions.canDelete;
    this.cacheQuotaGB = group.user.preferences.cacheQuotaGB;
  }
}

export class ExamInformation {
  studyUID: ExamId;
  primary: boolean;
  dataSourceURL: string;
  hangingProtocol: HangingProtocol;
  loadStatus: ExamLoadStatus;

  constructor(exam: IExamGroupExamInformation, isPrimary: boolean) {
    this.studyUID = exam.studyUID;
    this.primary = isPrimary;
    this.dataSourceURL = exam.dataSourceURL;
    this.hangingProtocol = new HangingProtocol(exam.hangingProtocol);
    this.loadStatus = ExamLoadStatus.NOT_LOADED;
  }
}

export class ExamGroup {
  public groupId: ExamGroupId;
  public orderId: number;
  public accessToken: AuthorizationToken;
  public user: ExamGroupUser;
  public allExams: ExamInformation[];
  public primaryExam: ExamInformation;
  public comparisonExams: ExamInformation[];

  private examsByStudyUID: Map<ExamId, ExamInformation>;

  constructor(groupId: ExamGroupId, accessToken: AuthorizationToken, group: IExamGroupDefinition) {
    this.groupId = groupId;
    this.orderId = group.orderId;
    this.accessToken = accessToken;
    this.user = new ExamGroupUser(group);
    this.allExams = [];
    this.comparisonExams = [];
    this.examsByStudyUID = new Map<ExamId, ExamInformation>();

    const primaryExam = new ExamInformation(group.primary, /*isPrimary=*/true);
    this.primaryExam = primaryExam;
    this.allExams.push(primaryExam);
    this.examsByStudyUID.set(primaryExam.studyUID, primaryExam);

    if (group.comparisons) {
      for (const item of group.comparisons) {
        const examInfo = this.examsByStudyUID.get(item.studyUID);
        if (examInfo === undefined) {
          this.addComparisonExam(item);
        } else {
          console.warn(`${this.constructor.name} examGroupId: ${this.groupId} duplicate comparison exam ${examInfo.studyUID} not added to exam group comparisons.`);
        }
      }
    }
  }

  public examInformationForUID(studyUID: ExamId): ExamInformation | undefined {
    return this.examsByStudyUID.get(studyUID);
  }

  public updateExamLoadStatus(studyUID: ExamId, loadStatus: ExamLoadStatus): void {
    const examInformation = this.examInformationForUID(studyUID);
    if (examInformation) {
      examInformation.loadStatus = loadStatus;
    }
  }

  public addComparisonExam(exam: IExamGroupExamInformation): ExamInformation {
    let examInfo = this.examsByStudyUID.get(exam.studyUID);
    if (examInfo === undefined) {
      examInfo = new ExamInformation(exam, /*isPrimary=*/false);
      this.allExams.push(examInfo);
      this.comparisonExams.push(examInfo);
      this.examsByStudyUID.set(examInfo.studyUID, examInfo);
    }
    return examInfo;
  }
}
