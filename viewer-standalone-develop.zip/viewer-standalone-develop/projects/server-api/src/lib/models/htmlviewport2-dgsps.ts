import Fovia from 'foviaapi';

import { cloneAnnotation, GSPSUtils, getPendingRenderParams2D, isCadAIGraphicLayer, makeImageKeyFromImageTags, setRenderEngineActive } from '../utils';
import GraphicType = Fovia.GraphicType;
import GraphicAnnotation = Fovia.GraphicAnnotation;

export class HTMLViewport2DGSPS extends Fovia.UI.HTMLViewport2D {

  protected _imageLevelRenderParams = false;
  protected presentationSeriesGroupMgr: Fovia.PresentationSeriesGroup | null = null;
  protected nonImageSeriesDataContext: Fovia.NonImageSeriesDataContext | null = null;
  protected _renderLocation: Fovia.RenderLocation;
  public allowSaveAnnotations = true;

  constructor(htmlElementName: string,
    width: number,
    height: number,
    repaintable: boolean = false,
    usePNG: boolean = false,
    renderEngineType: Fovia.RenderLocation = Fovia.RenderLocation.Server,
    public readonly isThumbnail: boolean = false) {
    super(htmlElementName, width, height, repaintable, usePNG, renderEngineType);
    this._renderLocation = renderEngineType;
    this.displayoPixelSpacingWarning(false);
    this.doubleBufferInit();
  }

  public get renderLocation(): Fovia.RenderLocation {
    return this._renderLocation;
  }

  public get imageLevelRenderParams(): boolean {
    return this._imageLevelRenderParams;
  }

  public set imageLevelRenderParams(value: boolean) {
    this._imageLevelRenderParams = value;
  }

  /**
   * initialize the HTMLViewport2D
   * @param seriesDataContext DICOM series (or sub-series) details associate with this viewport
   * @param onDrawCallback callback invoked after the image is displayed on the screen
   * @returns This is an asynchronous method that returns a Promise as follows:
   * <i>Promise</i> .then(void)  .catch (err: <a href="../enums/Fovia.ReturnCode.html"> <i>ReturnCode</i> </a>)
   * <i>callbackFunc</i>(err:  <a href="../enums/Fovia.ReturnCode.html"> <i>ReturnCode</i> </a>, void)
   */
  public override init(seriesDataContext: Fovia.SeriesDataContext, onDrawCallback?: Function, imageMetaDataReceived?: any, enableImageLevelRP?: boolean, callbackFunc?: Function): Promise<any> {
    this.imageLevelRenderParams = enableImageLevelRP ? enableImageLevelRP : false;
    return new Promise((resolve, reject) => {
      super.init(seriesDataContext, onDrawCallback, imageMetaDataReceived, enableImageLevelRP, callbackFunc).then(() => {
        setRenderEngineActive(this, false);
        this.presentationSeriesGroupMgr = GSPSUtils.getInstance().getPresentationSeriesGroup();

        if (!this.isThumbnail) {
          const nonImageData = this.renderEngine.getNonImageData();

          if (nonImageData && nonImageData.presentations) {
            GSPSUtils.getInstance().createPresentations(nonImageData.presentations, this.renderEngine, seriesDataContext.getStudyData(), seriesDataContext.getPatientData());
          }

          this.createDefaultPresentationObject();
        }

        if (resolve) {
          resolve({});
        }

        // if an old style callback was specified, invoke it.
        if (callbackFunc != null) {
          callbackFunc(Fovia.ReturnCode.ok);
        }

      }).catch((err) => {
        if (reject) {
          reject(err);
        }

        // if an old style callback was specified, invoke it.
        if (callbackFunc != null) {
          callbackFunc(err);
        }

      });
    });
  }

  public currentImageHasCadAnnotation(): boolean {
    if (this.isThumbnail) {
      return false;
    }
    const pendingRenderParams = getPendingRenderParams2D(this);
    if (!pendingRenderParams) {
      console.warn('currentImageHasCadUIAnnotation: pendingRenderParams undefined');
      return false;
    }
    const imageTags = this.renderEngine.getSeriesDataContext().imageTags[pendingRenderParams.imageNumber];
    if (!imageTags) {
      console.warn(`currentImageHasCadUIAnnotation: imageTags undefined for image number ${pendingRenderParams.imageNumber}`);
      return false;
    }
    const annotations = this.getAnnotationsOnImage(makeImageKeyFromImageTags(imageTags));

    // console.log(`currentImageHasCadAnnotation: annotations`, annotations);
    // return annotations.find(annot => annot.hasCadGraphicAnnotation(imageTags)) !== undefined;
    return annotations.find(annot => isCadAIGraphicLayer(annot.graphicLayer)) !== undefined;

  }

  public cloneAnnotationsFromImage(imageKey: string): Fovia.GraphicAnnotation[] {
    // Exclude CAD annotations.
    return this.getAnnotationsOnImage(imageKey)
      .filter(annotation => !isCadAIGraphicLayer(annotation.graphicLayer))
      .map(annotation => cloneAnnotation(annotation));
  }

  public getAnnotationsOnImage(imageKey: string): Fovia.GraphicAnnotation[] {
    const annotations: GraphicAnnotation[] = [];
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.point, imageKey));
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.polyline, imageKey));
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.circle, imageKey));
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.ellipse, imageKey));
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.text, imageKey));
    annotations.push(...this.renderEngine.getAnnotations(GraphicType.angle, imageKey));
    return annotations;
  }

  public override setDefaultAdaptors(renderType: Fovia.RenderType): void {
  }

  /**
   * @description Get the presentation list from PresentationSeriesGroup associated with this viewport
   * @param considerViewingAttributeChange whether or not to treat W/L, rotate and flip as a change
   * @returns Returns PresentationDataContext list in success case, empty list will be returned in failure case
   */
  public getPresentationListToSave(considerViewingAttributeChange: boolean = false): Array<Fovia.PresentationDataContext> {
    if (!this.isThumbnail && this.renderEngine) {
      const totalPresentation: number = (this.presentationSeriesGroupMgr == null) ? 0 : this.presentationSeriesGroupMgr.getTotalPresentation();
      return this.renderEngine.getPresentationListToSave(totalPresentation, false);
    }
    return new Array(0);
  }

  public getAllPresentationList(): Array<Fovia.PresentationDataContext> {
    if (!this.isThumbnail && this.presentationSeriesGroupMgr !== null) {
      return this.presentationSeriesGroupMgr.getAll();
    }
    return new Array(0);
  }

  /**
   * @description Display or hide the annotations based on the given flag
   * @param showAnnotation Specifies the toggle boolean flag
   */
  public override displayAnnotations(showAnnotation: boolean = true): void {

    this.renderEngine.displayAnnotations(showAnnotation);
    this.htmlViewportAdaptors.displayAnnotations(showAnnotation);
  }

  /**
   * @description Display or hide the annotations when button clicked from viewport
   */
  public toggleAnnotationVisibility(): void {

    this.renderEngine.toggleAnnotationVisibility();
    this.htmlViewportAdaptors.displayAnnotations(this.renderEngine.canShowAnnotations());
  }

  /**
   * @description Toggle the presentation state based the given boolean flag
   * @param flag Specifies the boolean flag
   */
  public togglePresentationState(flag: boolean = true): void {
    if (this.isThumbnail) {
      return;
    }
    this.renderEngine.setPresentationState(flag);
  }

  /**
   *
   * @param type
   * @param isFreeline
   */
  public activateAnnotation(type: number, isFreeline: boolean = false): void {
    throw new Error('activateAnnotation SHOULD NOT BE USED -- use the one in fmhtmlViewportAdaptors');
  }

  /**
   * @description Check whether TextAnnotationAdaptor is enabled or disabled
   * @returns True will be returned if adaptor valid or else false will be returned
   */
  public isTextAdaptorActive(): boolean {
    throw new Error('isTextAdaptorActive SHOULD NOT BE USED -- use the one in fmhtmlViewportAdaptors');
  }

  /**
   * @description Toggle the Annotation to edit or not
   * @param flag Specifies boolean flag
   */
  public toggleAnnotationEdit(flag: boolean): void {
    throw new Error('toggleAnnotationEdit SHOULD NOT BE USED -- use the one in fmhtmlViewportAdaptors');
  }

  /**
   * Update render parameters to render engine instance
   * @param renderParams Specifies the render parameter
   */
  public applyPresentationStates(renderParams: any): Promise<string> {
    return new Promise((resolve) => {
      this.renderEngine.applyPresentationStates(renderParams).then(() => {
        resolve('done');
      });
    });
  }

  /**
   * @description Set graphic data line width to be rendered based on the graphic data type
   * @param graphicType Specifies the graphic data type
   * @param width Specifies the width
   *
   * @returns Returns value returned by setLineWidth method call from renderEngine
   */
  public setLineWidth(graphicType: Fovia.GraphicType, width: number): boolean {
    return this.renderEngine.setLineWidth(graphicType, width);
  }

  /**
   * @description Set line graphic data color to be rendered based on the graphic data type
   * @param graphicType Specifies the graphic data type
   * @param color Specifies the color
   *
   * @returns Returns value returned by setLineColor method call from renderEngine
   */
  public setLineColor(graphicType: Fovia.GraphicType, color: string): boolean {
    return this.renderEngine.setLineColor(graphicType, color);
  }

  /**
   * @description Get the boolean flag whether Presentation date available or not
   * @returns Returns true if date available, false will be returned if date not available
   */
  public isPresentationDataAvailable(): boolean {
    return this.renderEngine.isPresentationDataAvailable();
  }

  /**
   * @description Set annotation color (in rgb) for given graphic layer
   * @param graphicLayer graphic layer
   * @param r r value
   * @param g g value
   * @param b b value
   *
   * @returns Returns the value returned by setAnnotationColor method call from render engine
   */
  public setAnnotationColor(graphicLayer: string, r: number, g: number, b: number): void {
    return this.renderEngine.setAnnotationColor(graphicLayer, r, g, b);
  }

  /**
   * Asynchronous method invoked before invoking renderfinal on this render engine.
   * and set to render engine and PresentationSeriesGroup class
   */
  public constructNonImageSeriesData(): Promise<string> {
    return new Promise((resolve, reject) => {
      resolve('done');
    });
  }

  /**
   * Invoke render engine's createDefaultPresentationObject object if render engine is valid
   */
  public createDefaultPresentationObject(): void {
    if (!this.renderEngine) {
      return;
    }
    this.renderEngine.createDefaultPresentationObject();
  }

  public syncViewingAttributes(): void {
    const rp = getPendingRenderParams2D(this);
    this.renderEngine.updateViewingAttribute(rp);
  }

  public async enablePresentation(sopInstanceUID: string): Promise<void> {
    this.renderEngine.enablePresentation(sopInstanceUID);
    const rp = getPendingRenderParams2D(this);
    this.renderEngine.applyPresentationStates(rp);
    // not yet render protected, but never called 11/2025
    await this.renderEngine.setRenderParams(rp, Fovia.RenderRequest.renderFinal);
  }

  public async togglePresentationSelection(sopInstanceUID: string): Promise<void> {
    this.renderEngine.togglePresentationSelection(sopInstanceUID);
    const rp = getPendingRenderParams2D(this);
    this.renderEngine.applyPresentationStates(rp);
    // not yet render protected, but never called 11/2025
    await this.renderEngine.setRenderParams(rp, Fovia.RenderRequest.renderFinal);  }

  public isBlankViewport(): boolean {
    return false;
  }
}
