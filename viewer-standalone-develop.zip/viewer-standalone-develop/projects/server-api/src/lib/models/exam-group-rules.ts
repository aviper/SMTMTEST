import Fovia from 'foviaapi';

import { isTomoImageFrame } from '../utils';
import { ExamGroup } from './exam-group';

// Given an exam group, provide support for various rules
// we want to support for different study types.
export class ExamGroupRules {
  constructor(private examGroup: ExamGroup) { }

  public shouldCacheImageFrame(sdc: Fovia.SeriesDataContext, image_num: number): boolean {
    return shouldCacheImageFrame(this.examGroup, sdc, image_num);
  }
}

export function shouldCacheImageFrame(examGroup: ExamGroup, sdc: Fovia.SeriesDataContext, image_num: number): boolean {
  // Always OK to cache non-tomo image frames
  if (!isTomoImageFrame(sdc, image_num)) {
    return true;
  }

  // Only cache tomos for primary or first comparison exam
  const isPrimary = examGroup.primaryExam.studyUID === sdc.studyInstanceUID;
  const isFirstComparison = examGroup.comparisonExams.length ? examGroup.comparisonExams[0].studyUID === sdc.studyInstanceUID : false;
  return isPrimary || isFirstComparison;
}
