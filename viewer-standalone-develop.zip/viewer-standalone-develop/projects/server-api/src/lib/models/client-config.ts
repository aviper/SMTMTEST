export enum ClientRenderMode {
  Client = 'client',
  Server = 'server',
  Hybrid = 'hybrid'
}

export interface ClientConfigData {
  environmentName: string;
  defaultRenderMode: ClientRenderMode;
  featureFlags: any;
}
