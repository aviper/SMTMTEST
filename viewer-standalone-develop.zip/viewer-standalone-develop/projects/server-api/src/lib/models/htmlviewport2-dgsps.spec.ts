import { HTMLViewport2DGSPS } from './htmlviewport2-dgsps';

describe('HTMLViewport2DGSPS', () => {
  it('should create an instance', () => {
    expect(new HTMLViewport2DGSPS()).toBeTruthy();
  });
});
