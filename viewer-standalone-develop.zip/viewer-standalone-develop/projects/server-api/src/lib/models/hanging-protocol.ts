import { ICineSpeedOptions, IDoNotDisplayCriteria, IFavoriteToolOptions, IHangingProtocol, IMammoStep, ISeriesOrder, ISeriesPresentationOptions } from '@idgital/vision-auth-interface';
export const DEFAULT_CINE_SPEED = 20;
export const MONTAGE_SERIES_DESCRIPTION = 'MONTAGE';

function defaultMammoStep(id: number): IMammoStep {
  return {
    id,
    leftPanel: '',
    rightPanel: ''
  };
}

function defaultMammoStepList(count: number): IMammoStep[] {
  const result: IMammoStep[] = [];
  for (let i = 1; i <= count; ++i) {
    result.push(defaultMammoStep(i));
  }
  return result;
}


function defaultCineSpeedOptions(): ICineSpeedOptions {
  return {
    cineSpeed: DEFAULT_CINE_SPEED,
    useDicomMetafile: false
  }
}

function defaultFavoriteToolOptions(): IFavoriteToolOptions {
  return {
    tool: '',
    powerWheel: false
  }
}

function defaultCenterSliceFirstOptions(): Record<string, boolean> {
  return {
    'sagittal': false,
    'coronal': false,
    'axial': false,
  }
}

function defaultSeriesOrderOptions(): ISeriesOrder {
  return {
    active: false,
    outerOrder: ['plane', 'contrast', 'thickness'],
    innerOrder: {
      plane: ['sagittal', 'coronal', 'axial'],
      contrast: ['without', 'with'],
      thickness: ['thicker', 'thinner'],
    },
    seriesTypesOrder: [], // future feature
  }
}

function defaultSeriesPresentationOptions(): ISeriesPresentationOptions {
  return {
    centerSliceFirst: defaultCenterSliceFirstOptions(),
    seriesOrder: defaultSeriesOrderOptions()
  }
}

export const DEFAULT_HANGING_PROTOCOL: IHangingProtocol = {
  id: 'Vision Default',
  examType: '',
  dicomAnnotationsFull: true,
  syncedPaging: true,
  keyImagesFirst: true,
  doNotDisplay: {
    criteria: [],
  },
  thumbnails: true,
  viewports: 1,
  groupSingleFrame: true,
  flicker: false,
  showAllImage: true,
  mammoDisplaySteps: defaultMammoStepList(12),
  cineSpeedOptions: defaultCineSpeedOptions(),
  topToolbar: false,
  notAllImagesDisplayedWarning: false,
  favoriteToolOptions: defaultFavoriteToolOptions(),
  seriesPresentationOptions: defaultSeriesPresentationOptions(),
};

export interface ISeriesOrderSeries {
  getThickness(): number;
  getHpPlane(): 'sagittal' | 'coronal' | 'axial' | '';
  getWithContrast(): boolean;
  getHpDebugObj(): any;
}
export type SeriesSortComparatorFn = (series1: ISeriesOrderSeries, series2: ISeriesOrderSeries) => number;

export class HangingProtocol implements IHangingProtocol {
  public id: string;
  public cineSpeedOptions: ICineSpeedOptions;
  public dicomAnnotationsFull: boolean;
  public doNotDisplay: IDoNotDisplayCriteria;
  public examType: string;
  public favoriteToolOptions: IFavoriteToolOptions;
  public seriesPresentationOptions: ISeriesPresentationOptions;
  public seriesSortComparatorFn: SeriesSortComparatorFn | null = null;
  public flicker: boolean;
  public groupSingleFrame: boolean;
  public keyImagesFirst: boolean;
  public mammoDisplaySteps: IMammoStep[];
  public notAllImagesDisplayedWarning: boolean;
  public showAllImage: boolean;
  public syncedPaging: boolean;
  public thumbnails: boolean;
  public topToolbar: boolean;
  public viewports: number;

  constructor(hp: IHangingProtocol | null = null) {
    if (hp == null) {
      hp = DEFAULT_HANGING_PROTOCOL;
    }
    this.examType = hp.examType.trim().toUpperCase();
    this.id = hp.id;
    this.dicomAnnotationsFull = hp.dicomAnnotationsFull;
    this.syncedPaging = hp.syncedPaging;
    this.keyImagesFirst = hp.keyImagesFirst;
    this.doNotDisplay = hp.doNotDisplay;
    this.thumbnails = hp.thumbnails;
    this.viewports = hp.viewports;
    this.groupSingleFrame = hp.groupSingleFrame;
    this.flicker = hp.flicker;
    this.showAllImage = hp.showAllImage;
    this.mammoDisplaySteps = hp.mammoDisplaySteps;
    this.cineSpeedOptions = hp.cineSpeedOptions ?? defaultCineSpeedOptions();
    this.topToolbar = hp.topToolbar ?? false;
    this.notAllImagesDisplayedWarning = hp.notAllImagesDisplayedWarning ?? false;
    this.favoriteToolOptions = hp.favoriteToolOptions ?? defaultFavoriteToolOptions();
    this.seriesPresentationOptions = hp.seriesPresentationOptions ?? defaultSeriesPresentationOptions();
    if (this.seriesPresentationOptions.centerSliceFirst == null) {
      this.seriesPresentationOptions.centerSliceFirst = defaultCenterSliceFirstOptions();
    }
    if (this.seriesPresentationOptions.seriesOrder == null) {
      this.seriesPresentationOptions.seriesOrder = defaultSeriesOrderOptions();
    }

    if (this.seriesPresentationOptions.seriesOrder?.active) {
      this.seriesSortComparatorFn = generateHangingProtocolSeriesSortComparatorFn(this.seriesPresentationOptions.seriesOrder);
    }
  }
}

export class CineSpeedOptions implements ICineSpeedOptions {
  public readonly cineSpeed: number = DEFAULT_CINE_SPEED;
  public readonly useDicomMetafile: boolean = true; // FOR TESTING

  constructor(hp?: IHangingProtocol) {
    if (hp && hp.cineSpeedOptions) {
      this.cineSpeed = hp.cineSpeedOptions.cineSpeed;
      this.useDicomMetafile = hp.cineSpeedOptions.useDicomMetafile;
    }
  }
}

export class HangingProtocolDoNotDisplaySeriesRules {
  private seriesDescription = { applyRule: true, values: [MONTAGE_SERIES_DESCRIPTION.toUpperCase().trim()] };
  private sliceThickness = { applyRule: false, value: 0 };

  constructor(doNotDisplay?: IDoNotDisplayCriteria) {
    const dndCriteria = doNotDisplay?.criteria;
    if (!dndCriteria || !Array.isArray(dndCriteria)) {
      console.error(`HangingProtocolDoNotDisplaySeriesRules: unrecognized item - malformed criteria`, dndCriteria);
      return;
    }
    dndCriteria.forEach(item => {

      if (item != null && item.checked && item.key === 'series_description' && item.criteriaValue != null) {

    this.seriesDescription.applyRule = true;
        this.seriesDescription.values = item.criteriaValue
            .split(',')
            .map((str:string) => str.toUpperCase().trim());
        this.seriesDescription.values.push(MONTAGE_SERIES_DESCRIPTION.toUpperCase().trim());

      } else if (item != null && item.checked && item.key === 'slice_thickness' && item.criteriaValue != null) {
        const value = Number(item.criteriaValue);
    if (isNaN(value)) {
      this.sliceThickness.applyRule = false;
      console.error(`doNotDisplaySeriesRules: invalid slice thickness ${value}`);
    } else {
      this.sliceThickness.applyRule = true;
      this.sliceThickness.value = value;
    }
      } else if (item != null && item.checked && item.key !== 'field_of_view') {
        // slice_thickness is currently ignored
        console.error(`HangingProtocolDoNotDisplaySeriesRules: unrecognized item`, item);
      }
    });
    // console.log('HangingProtocolDoNotDisplaySeriesRules', this);
  }

  public applyRules(seriesDescription: string, sliceThickness: number): boolean {
    return ((this.seriesDescription.applyRule && this.applySeriesDescriptionRule(seriesDescription)) ||
      (this.sliceThickness.applyRule && this.applySliceThicknessRule(sliceThickness)));
  }

  private applySeriesDescriptionRule(seriesDescription: string): boolean {
    const desc = seriesDescription.toUpperCase().trim();
    return (desc.length > 0 && this.seriesDescription.values.find(value => desc.includes(value)) != null);
  }

  private applySliceThicknessRule(sliceThickness: number): boolean {
    return sliceThickness <= this.sliceThickness.value;
  }
}

export function generateHangingProtocolSeriesSortComparatorFn(seriesOrder: ISeriesOrder): SeriesSortComparatorFn {
  // If series sorting isn't active, return a comparator function that always returns 0
  if (!seriesOrder.active) {
    return (item1, item2) => 0;
  }

  // Build an array of comparator functions, one for each series comparison attribute in the hanging protocol
  const comparatorFns = seriesOrder.outerOrder.map(outerItem => {
    return (series1: ISeriesOrderSeries, series2: ISeriesOrderSeries) => {
      switch (outerItem) {
        case 'plane':
          return comparePlanes(seriesOrder, series1, series2);
        case 'contrast':
          return compareHasContrast(seriesOrder, series1, series2);
        case 'thickness':
          return compareThicknesses(seriesOrder, series1, series2);
      }
    }
  });

  // Build a function that iterates the array of comparator functions, calling each one until items being compared are unequal
  const returnFn = (item1: ISeriesOrderSeries, item2: ISeriesOrderSeries) => {
    for (const comparatorFn of comparatorFns) {
      const value = comparatorFn(item1, item2);
      if (value != 0) {
        return value;
      }
    }
    return 0;
  }
  return returnFn;
}

function compareThicknesses(seriesOrder: ISeriesOrder,
                            series1: ISeriesOrderSeries,
                            series2: ISeriesOrderSeries) : number {
  const thickness1 = series1.getThickness();
  const thickness2 = series2.getThickness();
  if (thickness1 === thickness2) {
    return 0;
  }
  let value1, value2 : 'thicker' | 'thinner';
  if (thickness1 > thickness2) {
    value1 = 'thicker';
    value2 = 'thinner';
  } else {
    value1 = 'thinner';
    value2 = 'thicker';
  }
  return doSortComparison(seriesOrder.innerOrder.thickness, value1, value2, 'compareThicknesses', series1.getHpDebugObj(), series2.getHpDebugObj());
}

function compareHasContrast(seriesOrder: ISeriesOrder,
                            series1: ISeriesOrderSeries,
                            series2: ISeriesOrderSeries) : number {
  const hasContrast1 = series1.getWithContrast() ? 'with' : 'without';
  const hasContrast2 = series2.getWithContrast() ? 'with' : 'without';
  return doSortComparison(seriesOrder.innerOrder.contrast, hasContrast1, hasContrast2, 'compareHasContrast', series1.getHpDebugObj(), series2.getHpDebugObj());
}

function comparePlanes(seriesOrder: ISeriesOrder,
                       series1: ISeriesOrderSeries,
                       series2: ISeriesOrderSeries) : number {
  return doSortComparison(seriesOrder.innerOrder.plane, series1.getHpPlane(), series2.getHpPlane(), 'comparePlanes', series1.getHpDebugObj(), series2.getHpDebugObj());
}

function doSortComparison(sortDefinition: string[], value1: string, value2: string, debugDesc: string, debugObj1: any, debugObj2: any): number {
  const sortIndex1 = getSortIndex(sortDefinition, value1);
  const sortIndex2 = getSortIndex(sortDefinition, value2);
  // console.log(`${debugDesc} - value1=${value1}, value2=${value2}, sortIndex1=${sortIndex1}, sortIndex2=${sortIndex2}, ret=${sortIndex1 - sortIndex2}`,debugObj1, debugObj2);
  return (sortIndex1 - sortIndex2)
}

function getSortIndex(sortDefinition: String[], value: string): number {
  let sortIndex = sortDefinition.findIndex( item => item === value);
  if (sortIndex === -1) {
    sortIndex =  Number.MAX_SAFE_INTEGER;
  }
  return sortIndex;
}
