
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import Fovia from 'foviaapi';

import {
  AuthenticationToken,
  IExamGroupExamInformation,
  UserId
} from '@idgital/vision-auth-interface';

import {
  ExamId,
} from '@idgital/vision-interface';

import {
  AuthService,
  ExamGroupAccessResult
} from './services/auth.service';

import {
  ExamIoService,
  ImagePixelData
} from './services/exam-io.service';

import {
  ExamAuthorizationContext,
  ExamDeleteInstanceContext,
  ExamGroupAuthorizationContext,
  ExamLoadContext,
  ExamUpdateContext
} from './context';

import { UserCredentialsStoreService } from './stores';
import { ExamGroup, ExamLoadStatus, ClientConfigData } from './models';
import { CacheStatusService, IExamGroupCacheStatus, IExamCacheStatus } from './services/cache-status.service';
import { FoviaConnectService } from './fovia/fovia-connect.service';
import { FoviaSessionService } from './fovia/fovia-session.service';
import { UserCredentials } from './utils';
import { MontageService, StoreMontageImage } from './services/montage.service';
import { CoreBackendService, DeleteImage } from './services/core-backend.service';
import { ClientConfigService } from './services/client-config.service';

@Injectable({
  providedIn: 'root'
})
export class ServerApiService {
  private _applicationName: string;
  private _host: string | null;

  constructor(
    private fovia: FoviaConnectService,
    private authService: AuthService,
    private examIoService: ExamIoService,
    private cacheStatusService: CacheStatusService,
    private userCredentialsStore: UserCredentialsStoreService,
    private montageService: MontageService,
    private coreBackendService: CoreBackendService,
    private clientConfigService: ClientConfigService,
    private foviaSessionService: FoviaSessionService
  ) {
    console.log(`${this.constructor.name} Starting`);
    this._applicationName = 'unknown';
    this._host = null;
  }

  public ngOnDestroy(): void {
    this.fovia.ngOnDestroy();
  }

  public get applicationName(): string {
    return this._applicationName;
  }

  public set applicationName(value: string) {
    this._applicationName = value;
  }

  public get userCredentials(): UserCredentials | null {
    return this.userCredentialsStore.current;
  }

  public get serverContext(): Fovia.ServerContext | null {
    return this.fovia.serverContext;
  }

  public get foviaConnected$(): Observable<boolean | null> {
    return this.fovia.connected$;
  }

  public get foviaConnected(): boolean {
    return this.fovia.connected;
  }

  public get foviaSessionLost(): boolean {
    return this.fovia.sessionLost;
  }

  public get foviaClientId(): string | null {
    return this.fovia.clientId;
  }

  public get foviaSessionId(): string | null {
    return this.foviaSessionService.current;
  }

  public get sessionLost(): boolean {
    return this.fovia.sessionLost;
  }

  public get requestedDisconnection(): boolean {
    return this.fovia.requestedTermination;
  }

  public get lastFoviaReturnCode(): Fovia.ReturnCode | null {
    return this.fovia.lastConnectionResult;
  }

  public get host(): string | null {
    return this._host;
  }

  public invalidateUserCredentials(): void {
    this.userCredentialsStore.invalidate();
  }

  public updateUserCredentials(userId: UserId, authToken: AuthenticationToken): void {
    this.userCredentialsStore.update(userId, authToken);
  }

  public foviaConnectionOptions(): any {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }

    let currentFoviaSessionId = this.foviaSessionService.current;
    if (currentFoviaSessionId === null) {
      currentFoviaSessionId = this.foviaSessionService.generateNew();
    }

    const userId = userCredentials.userId;
    const authToken = userCredentials.authToken;
    const sessionId = currentFoviaSessionId;
    return this.fovia.foviaConnectionOptions(userId, authToken, sessionId);
  }

  public connect(host: string | URL): Promise<Fovia.ServerContext> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }

    if (typeof host === 'string') {
      this._host = host;
    } else {
      this._host = (host as URL).host;
    }

    const userId = userCredentials.userId;
    const userAuthToken = userCredentials.authToken;
    const sessionId = this.foviaSessionService.generateNew();
    return this.fovia.requestServerConnection(host, userId, userAuthToken, sessionId);
  }

  // TEMPORARY TEMPORARY - as part of 2.3/2.4 work we found that Fovia is not always returning with an error code
  // for (e.g. SDK Mismtach) some errors. So use promise timeout to identify these problems until
  // fovia can get us a release that properly returns error codes.
  public connectWithTimeout(host: string | URL): Promise<Fovia.ServerContext | null> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }

    if (typeof host === 'string') {
      this._host = host;
    } else {
      this._host = (host as URL).host;
    }

    const userId = userCredentials.userId;
    const userAuthToken = userCredentials.authToken;
    const sessionId = this.foviaSessionService.generateNew();
    return this.fovia.requestServerConnectionWithTimeout(host, userId, userAuthToken, sessionId);
  }

  public async disconnect(): Promise<unknown> {
    return this.fovia.terminateServerConnection();
  }

  public loadConfig(userName?: string): Promise<ClientConfigData | null> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }

    const userId = userCredentials.userId;
    return this.clientConfigService.loadConfig(this._applicationName, userId, userName);
  }

  public resolveExamAccess(context: ExamAuthorizationContext): Promise<IExamGroupExamInformation | null> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }
    return this.authService.resolveExamAccess(this._applicationName, userCredentials, context);
  }

  public resolveExamGroupAccess(context: ExamGroupAuthorizationContext): Promise<ExamGroupAccessResult> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }
    return this.authService.resolveExamGroupAccess(this._applicationName, userCredentials, context);
  }

  public loadExam(context: ExamLoadContext): Promise<Fovia.ScanDirResults | null> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }
    return this.examIoService.loadExam(this._applicationName, userCredentials, context);
  }

  public loadImagePixelData(studyInstanceUID: ExamId, seriesInstanceUID: string, sopInstanceUID: string, imageNumber: number, uniqueId: string, imageKey: string): Promise<ImagePixelData | null> {
    // This doesn't take a request context object for two reasons:
    // 1. Call frequency - 1-10k+ times per-exam,
    // 2. The request to get pixel data doesn't utilize Fovia's event reporting mechanism
    return this.examIoService.loadImagePixelData(this._applicationName, studyInstanceUID, seriesInstanceUID, sopInstanceUID, imageNumber, uniqueId, imageKey);
  }

  public storeInstance(context: ExamUpdateContext): Promise<boolean> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied`);
    }
    return this.examIoService.storeInstance(this._applicationName, userCredentials, context);
  }

  public deleteInstance(context: ExamDeleteInstanceContext): Promise<boolean> {
    const userCredentials = this.userCredentialsStore.current;
    if (userCredentials === null) {
      throw new Error(`${this.constructor.name} No user credentials supplied for sop instance deletion`);
    }
    return this.examIoService.deleteInstance(this._applicationName, userCredentials, context);
  }

  public unloadExam(examGroup: ExamGroup, studyInstanceUID: ExamId): Promise<boolean> {
    return new Promise(async (resolve) => {
      let unloadResult = true;
      const examInformation = examGroup.examInformationForUID(studyInstanceUID);
      if (examInformation !== undefined) {
        // Does Fovia maintain any server-side resources for a failed load? Guessing yes.
        if (examInformation.loadStatus !== ExamLoadStatus.NOT_LOADED) {
          try {
            const foviaResult = await Fovia.ServerContext.release2DImageDataSessionResource(examInformation.studyUID) as { err: Fovia.ReturnCode };
            if (foviaResult.err !== Fovia.ReturnCode.ok) {
              console.error(`${this.constructor.name} release2DImageDataSessionResource failed for ${examInformation.studyUID} (${ExamLoadStatus[examInformation.loadStatus]}) with ReturnCode ${Fovia.ReturnCode[foviaResult.err]}`);
              if (examInformation.loadStatus === ExamLoadStatus.LOADED) {
                unloadResult = false;
              }
            }
          } catch (err) {
            console.error(`${this.constructor.name} Exception during release2DImageDataSessionResource for ${examInformation.studyUID}`, err);
            if (examInformation.loadStatus === ExamLoadStatus.LOADED) {
              unloadResult = false;
            }
          }
        }
      }
      resolve(unloadResult);
    });
  }

  public unloadExamGroup(examGroup: ExamGroup): Promise<boolean> {
    return new Promise(async (resolve) => {
      let unloadResult = true;
      // TEST: Fovia says that calling release2DImageDataSessionResource for each exam is unnecessary
      // when Fovia.ServerContext.terminateServerConnection is used. Skip this for now.
      /*
      for (const examInformation of examGroup.allExams) {
        // Does Fovia maintain any server-side resources for a failed load? Guessing yes.
        if (examInformation.loadStatus !== ExamLoadStatus.NOT_LOADED) {
          try {
            // console.log(`${this.constructor.name} unloadExamGroup release2DImageDataSessionResource for ${examInformation.studyUID}`);
            const foviaResult = await Fovia.ServerContext.release2DImageDataSessionResource(examInformation.studyUID) as { err: Fovia.ReturnCode };
            if (foviaResult.err !== Fovia.ReturnCode.ok) {
              console.error(`${this.constructor.name} release2DImageDataSessionResource failed for ${examInformation.studyUID} (${ExamLoadStatus[examInformation.loadStatus]}) with ReturnCode ${Fovia.ReturnCode[foviaResult.err]}`);
              if (examInformation.loadStatus === ExamLoadStatus.LOADED) {
                unloadResult = false;
              }
            }
            // console.log(`${this.constructor.name} unloadExamGroup release2DImageDataSessionResource for ${examInformation.studyUID} COMPLETE`);
            // TODO: Do we need to update the loadStatus to not loaded???
          } catch (err) {
            console.error(`${this.constructor.name} Exception during release2DImageDataSessionResource for ${examInformation.studyUID}`, err);
            if (examInformation.loadStatus === ExamLoadStatus.LOADED) {
              unloadResult = false;
            }
          }
        }
      }
        */
      resolve(unloadResult);
    });
  }

  // CacheStatus Service api
  public set cacheServiceHost(value: string) {
    this.cacheStatusService.host = value;
  }

  public set sessionToken(value: AuthenticationToken) {
    this.cacheStatusService.sessionToken = value;
  }

  public get cacheServiceHost(): URL {
    return this.cacheStatusService.host;
  }

  public updateExamGroupStatus(examGroupStatus: IExamGroupCacheStatus): Observable<string | null> {
    return this.cacheStatusService.updateExamGroupStatus(examGroupStatus);
  }

  public updateExamsStatus(examStatus: IExamCacheStatus[]): Observable<string | null> {
    return this.cacheStatusService.updateExamsStatus(examStatus);
  }

  public deleteAllCacheStatus(): Observable<string> {
    return this.cacheStatusService.deleteAllCacheStatus();
  }

  // Montage Service
  public set montageServiceHost(value: string | URL) {
    this.montageService.host = value;
  }

  public storeMontage(storeMontageImage: StoreMontageImage): Observable<string | null> {
    return this.montageService.storeMontage(storeMontageImage);
  }

  // Core backend service
  public set coreBackendServiceHost(value: string | URL) {
    this.coreBackendService.host = value;
  }

  public deleteImage(deleteImage: DeleteImage): Observable<string | null> {
    return this.coreBackendService.deleteImages(deleteImage);
  }
}
