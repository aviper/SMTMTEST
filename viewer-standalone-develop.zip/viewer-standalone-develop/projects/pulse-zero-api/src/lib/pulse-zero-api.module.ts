import { NgModule } from '@angular/core';

import { ServerApiModule } from '@server-api';

import { CacheExamService, ComputeUtilsService, EncryptionKeyService, OpfsCacheService } from './services';
import { PulseVisionApiService } from './pulse-zero-api.service';

@NgModule({
  declarations: [
  ],
  imports: [
    ServerApiModule
  ],
  exports: [
  ],
  providers: [
    CacheExamService,
    ComputeUtilsService,
    EncryptionKeyService,
    OpfsCacheService,
    PulseVisionApiService
  ]
})
export class PulseVisionApiModule { }
