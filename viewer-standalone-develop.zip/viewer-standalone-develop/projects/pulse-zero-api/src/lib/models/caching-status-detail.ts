import { StudyStatus } from './exam-stats';
import { PerfTiming } from '@worker-compatible-api';

export class CachingStatusDetail extends PerfTiming {
  public quotaError = false;
  public complete = false;
  public fatalError = false;
  public cachingStopped = false;
  public lastCachedItem = -1;
  public itemsCachedCount = 0;

  constructor(public readonly status: StudyStatus) {
    super();
  }

  public completed(): void {
    this.complete = true;
    console.info(`${this.constructor.name} Caching step '${this.status}' ${this.cumulativeSecondsMessage()}`);
  }
}
