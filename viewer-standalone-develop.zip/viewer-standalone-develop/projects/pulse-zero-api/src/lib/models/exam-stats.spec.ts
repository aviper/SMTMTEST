import { ExamStats } from './exam-stats';

describe('ExamStats', () => {
  it('should create an instance', () => {
    expect(new ExamStats()).toBeTruthy();
  });
});
