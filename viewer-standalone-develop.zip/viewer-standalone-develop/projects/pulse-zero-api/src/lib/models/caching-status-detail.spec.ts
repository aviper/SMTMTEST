import { StudyStatus } from "./exam-stats";
import { CachingStatusDetail } from './caching-status-detail';

describe('CachingStatusDetail', () => {
  it('should create an instance', () => {
    expect(new CachingStatusDetail(StudyStatus.eNEW)).toBeTruthy();
  });
});
