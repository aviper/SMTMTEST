export class CachedStudyInfo {
  private _cacheTime: number;
  private _userId: string;

  constructor(
    public studyUID: string
  ) {
    this._cacheTime = 0;
    this._userId = '';
    // console.log(`${this.constructor.name} constructor ${this._userId} ${this.studyUID}`);
  }

  public get studyCacheTime(): number {
    return this._cacheTime;
  }

  public get userId(): string {
    // console.log(`${this.constructor.name} get userId ${this._userId} ${this.studyUID}`);
    return this._userId;
  }

  public set userId(value: string) {
    this._userId = value;
    // console.log(`${this.constructor.name} set userId ${this._userId} ${this.studyUID}`);
  }
  // Study cache-time is the maximum of its image's cacheTimes.
  public updateStudyCacheTime(imageCacheTime: number): void {
    this._cacheTime = Math.max(this._cacheTime, imageCacheTime);
  }
}
