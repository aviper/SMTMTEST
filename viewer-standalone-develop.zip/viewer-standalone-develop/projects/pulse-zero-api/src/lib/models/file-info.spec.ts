import { FileInfo } from './file-info';

describe('FileInfo', () => {
  it('should create an instance', () => {
    expect(new FileInfo()).toBeTruthy();
  });
});
