export interface IDiskInfo {
  estimatedTotalDiskSpaceMB: number;
  totalUsageMB: number;
  pulseVisionUsageMB: number;
  status: string;
}

export class DiskInfo implements IDiskInfo {
  public estimatedTotalDiskSpaceMB: number;
  public totalUsageMB: number;
  public pulseVisionUsageMB: number;
  public status: string;

  constructor() {
    this.estimatedTotalDiskSpaceMB = 0;
    this.totalUsageMB = 0;
    this.pulseVisionUsageMB = 0;
    this.status = 'NORMAL';
  }
}
