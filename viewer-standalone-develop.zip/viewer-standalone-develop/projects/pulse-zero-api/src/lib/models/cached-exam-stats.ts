import { BehaviorSubject, Observable } from 'rxjs';
import { KB, MB, TICKS_PER_SEC } from './constants';
import { ExamStats, ImageStats, StudyStatus, getExamStatsFromExamStatsObj } from './exam-stats';
import { CachedStudyInfo } from './exam-data';

export class CachedExamStats {

  private _stats: ExamStats = new ExamStats();
  private _studyInfo: CachedStudyInfo;
  private startStudyCachingTime = 0;
  private startImageCachingTime = 0;
  private perImageStats: Map<string, ImageStats> = new Map<string, ImageStats>();
  private manifestKB$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private manifestLoadTimeSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private manifestCacheTimeSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private seriesCount$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private studyElapsedSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private studyStatus$$: BehaviorSubject<StudyStatus> = new BehaviorSubject<StudyStatus>(StudyStatus.eNEW);
  private totalCachedImages$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private totalCacheWriteTimeSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private totalFetchTimeSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private totalMB$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private totalStudyCachingTimeSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private MBPerSec$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  public orders = '';
  public priority = '';

  public constructor(studyUID: string, stats: Object | null = null, studyInfo: CachedStudyInfo | null = null) {
    if (stats != null) {
      this.stats = getExamStatsFromExamStatsObj(stats);
    }

    this._studyInfo = studyInfo ?? this.initStudyCacheTime(studyUID);
    this._stats.studyUID = studyUID;
  }

  public get user(): string {
    return this.stats.userId;
  }

  public get modality(): string {
    return this.stats.modality;
  }

  public set modality(value: string) {
    this.stats.modality = value;
  }

  public get studyCacheTime(): number {
    return this._studyInfo.studyCacheTime;
  }

  public get studyCacheDate(): Date {
    return new Date(this._studyInfo.studyCacheTime);
  }

  public set studyInfo(value: CachedStudyInfo) {
    this._studyInfo = value;
  }

  public get manifestKB(): number {
    return this.manifestKB$$.value;
  }

  public get manifestKB$(): Observable<number> {
    return this.manifestKB$$;
  }

  public get manifestLoadTimeSec(): number {
    return this.manifestLoadTimeSec$$.value;
  }

  public get manifestLoadTimeSec$(): Observable<number> {
    return this.manifestLoadTimeSec$$;
  }

  public get manifestCacheTimeSec(): number {
    return this.manifestCacheTimeSec$$.value;
  }

  public get manifestCacheTimeSec$(): Observable<number> {
    return this.manifestCacheTimeSec$$;
  }
  public get MBPerSec(): number {
    return this.MBPerSec$$.value;
  }

  public get MBPerSec$(): Observable<number> {
    return this.MBPerSec$$;
  }

  public get seriesCount(): number {
    return this.seriesCount$$.value;
  }

  public get seriesCount$(): Observable<number> {
    return this.seriesCount$$;
  }

  public get stats(): ExamStats {
    return this._stats;
  }

  public set stats(value: ExamStats) {
    this._stats = value;
    // Propagate the imageStats to our map for runtime tracking/update
    for (const image of this.stats.imageStats) {
      this.perImageStats.set(image.imageUID, image);
    }
    this.updateStudyStatus(value.studyStatus);
    this.computeManifestStats().then(() => this.computeStats().then() );
  }

  public get studyElapsedSec(): number {
    return this.studyElapsedSec$$.value;
  }
  public get studyElapsedSec$(): Observable<number> {
    return this.studyElapsedSec$$;
  }

  public get studyStatus$(): Observable<StudyStatus> {
    return this.studyStatus$$;
  }
  public get studyStatus(): StudyStatus {
    return this.studyStatus$$.value;
  }

  public get studyUID(): string {
    return this.stats.studyUID;
  }

  public set totalExamImages(value: number) {

    this.stats.totalExamImages = value;
  }

  public get totalExamImages(): number {
    return this.stats.totalExamImages;
  }

  public get totalCachedImages(): number {
    return this.totalCachedImages$$.value;
  }

  public get totalCachedImages$(): Observable<number> {
    return this.totalCachedImages$$;
  }

  public get totalCacheWriteTimeSec(): number {
    return this.totalCacheWriteTimeSec$$.value;
  }
  public get totalCacheWriteTimeSec$(): Observable<number> {
    return this.totalCacheWriteTimeSec$$;
  }

  public get totalFetchTimeSec(): number {
    return this.totalFetchTimeSec$$.value;
  }
  public get totalFetchTimeSec$(): Observable<number> {
    return this.totalFetchTimeSec$$;
  }

  public get totalMB(): number {
    return this.totalMB$$.value;
  }

  public get totalMB$(): Observable<number> {
    return this.totalMB$$;
  }

  public get totalStudyCachingTimeSec(): number {
    return this.totalStudyCachingTimeSec$$.value;
  }

  public get totalStudyCachingTimeSec$(): Observable<number> {
    return this.totalStudyCachingTimeSec$$;
  }

  public get skippedImageCount(): number {
    return this.stats.skippedImageCount;
  }

  public set skippedImageCount(value: number) {
    this.stats.skippedImageCount = value;
  }

  public startCachingStudyTimer(): void {
    this.startStudyCachingTime = performance.now();
    console.warn(`${this.constructor.name} startCachingStudyTimer: ${this.studyUID} Status: ${this.studyStatus$$.value}`);
  }

  public startCachingImagesTimer(): void {
    this.startImageCachingTime = performance.now();
    console.warn(`${this.constructor.name} startCachingImagesTimer: ${this.studyUID} Status: ${this.studyStatus$$.value}`);
  }

  // Elapsed caching time is studyElapsed + image elapsed
  public endCachingStudyTimer(): void {
    const studyElapsed = performance.now() - this.startStudyCachingTime;
    console.warn(`${this.constructor.name} endCachingStudyTimer: ${this.studyUID} Status: ${this.studyStatus$$.value} - Elapsed sec ${studyElapsed / TICKS_PER_SEC}`);
    this.addStudyElapsedStat(studyElapsed);
  }

  public endCachingImagesTimer(): void {
    // Track cumulative time we spend caching the images
    this.stats.cacheImagesElapsed += performance.now() - this.startImageCachingTime;
    console.warn(`${this.constructor.name} endCachingImagesTimer: ${this.studyUID} Status: ${this.studyStatus$$.value} - Elapsed sec ${this.stats.cacheImagesElapsed / TICKS_PER_SEC}`);
  }

  public addManifestStats(startCacheWriteTime: number, bytes: number): void {
    this.stats.manifestBytes = bytes;
    this.stats.manifestLoadTime = performance.now() - this.startStudyCachingTime;
    this.stats.manifestCacheTime = performance.now() - startCacheWriteTime;
    this.computeManifestStats().then();
  }

  public addNewImageStats(
    imageUID: string,
    notation: string, // used to identify described issues with this image
    fetchImageTime: number,
    cacheWriteTime: number,
    totalImageTime: number,
    imageBytes: number,
    imageNum: number,
    isCached: boolean = false): void {

    const imageStats = new ImageStats(imageUID, notation, fetchImageTime, cacheWriteTime, totalImageTime, imageBytes, imageNum, isCached);
    const previousStats = this.perImageStats.get(imageUID);
    // Did we previously cache this image?
    if (previousStats != null) {
      // Avoid double-counting when we re-cache a previously cached study
      // if this image was previously cached, only update our cache count
      // if it wasn't previously cached
      if (!previousStats.isCached) {
        this.stats.cachedImageCount += isCached ? 1 : 0;
      }
    } else {
      this.stats.cachedImageCount += isCached ? 1 : 0;
    }

    this.perImageStats.set(imageUID, imageStats);
    this.stats.cacheImagesElapsed = performance.now() - this.startImageCachingTime;
  }

  public addSkippedImageStats(imageUID: string, notation: string, studyUID: string, imageNum: number): void {
    const previousStats = this.perImageStats.get(imageUID);
    // Go ahead and count the image we skipped
    // Did we previously cache this image?
    if (previousStats == null) {
      const imageStats = new ImageStats(imageUID, notation, 0, 0, 0, 0, imageNum, false, studyUID);
      this.perImageStats.set(imageUID, imageStats);
      this.stats.cachedImageCount += 1;
    }
  }

  private addStudyElapsedStat(elapsedTime: number): void {
    // All done with this caching pass -- may have been interrupted, update accumulated stats
    this.stats.studyElapsed += elapsedTime;
    this.computeStats().then();
  }

  public updateStudyStatus(status: StudyStatus): void {
    this.stats.studyStatus = status;
    this.studyStatus$$.next(this.stats.studyStatus);
  }

  public async computeManifestStats(): Promise<void> {
    this.manifestKB$$.next(this.stats.manifestBytes / KB);
    const manifestCacheSecs = this.stats.manifestCacheTime / TICKS_PER_SEC;
    this.manifestCacheTimeSec$$.next(manifestCacheSecs);
    const manifestLoadTimeSecs = this.stats.manifestLoadTime / TICKS_PER_SEC;
    this.manifestLoadTimeSec$$.next(manifestLoadTimeSecs);
  }

  public async computeStats(): Promise<void> {
    // Update the ExamStats object with the current per image info from the tracking map
    this.stats.imageStats = Array.from(this.perImageStats.values());
    const statTotal = this.sumImageStats(this.stats.imageStats);
    const totalBytes = statTotal.imageBytes + this.stats.manifestBytes;
    this.totalMB$$.next(totalBytes / MB);
    this.totalCachedImages$$.next(this.stats.cachedImageCount);
    this.totalStudyCachingTimeSec$$.next((statTotal.totalImageTime / TICKS_PER_SEC) + this.manifestCacheTimeSec$$.value);
    this.totalFetchTimeSec$$.next((statTotal.fetchImageTime / TICKS_PER_SEC) + this.manifestLoadTimeSec$$.value);
    this.totalCacheWriteTimeSec$$.next(statTotal.cacheWriteTime / TICKS_PER_SEC);
    this.studyElapsedSec$$.next((this.stats.studyElapsed + this.stats.cacheImagesElapsed) / TICKS_PER_SEC);
    const imagesCachedElapsedSecs = this.stats.cacheImagesElapsed / TICKS_PER_SEC;
    this.MBPerSec$$.next(imagesCachedElapsedSecs === 0 ? 0 : this.totalMB / imagesCachedElapsedSecs);
    // this.MBPerSec$$.next(this.totalStudyCachingTimeSec$$.value === 0 ? 0 : this.totalMB / this.totalStudyCachingTimeSec$$.value);
  }

  private initStudyCacheTime(studyUID: string): CachedStudyInfo {
    const csi = new CachedStudyInfo(studyUID);
    csi.updateStudyCacheTime(Date.now());
    return csi;
  }

  private sumImageStats(array: ImageStats[]): ImageStats {
    const statTotal = new ImageStats();
    for (const item of array) {
      statTotal.cacheWriteTime += item.cacheWriteTime;
      statTotal.fetchImageTime += item.fetchImageTime;
      statTotal.imageBytes += item.imageBytes;
      statTotal.totalImageTime += item.totalImageTime;
    }
    return statTotal;
  }
}
