import { CacheExamDetail } from './cache-exam-detail';

describe('CacheExamDetail', () => {
  it('should create an instance', () => {
    expect(new CacheExamDetail()).toBeTruthy();
  });
});
