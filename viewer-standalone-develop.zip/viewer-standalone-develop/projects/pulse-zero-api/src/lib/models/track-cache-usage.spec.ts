import { TrackCacheUsage } from './track-cache-usage';

describe('TrackCacheUsage', () => {
  it('should create an instance', () => {
    expect(new TrackCacheUsage()).toBeTruthy();
  });
});
