
import { CachedStudyInfo } from './exam-data';

describe('CachedStudyInfo', () => {
  it('should create an instance', () => {
    expect(new CachedStudyInfo('studyid')).toBeTruthy();
  });
});
