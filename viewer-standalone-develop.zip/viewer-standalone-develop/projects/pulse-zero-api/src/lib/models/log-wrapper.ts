import {
  LocalStorageItems,
  LogSupport
} from '@server-api';

// We can set this value from the debug console and
// change logging behavior. normal is routed to console.xxx defaults.
enum Logger {
  CONSOLE = 'console',
  CONSOLE_NONE = 'consolenone',
  CONSOLE_ERROR = 'consoleerror',
  CONSOLE_WARN = 'consolewarn',
  CONSOLE_INFO = 'consoleinfo',
  CONSOLE_DEBUG = 'consoledebug',
  SERVER_NONE = 'servernone',
  SERVER_ERROR = 'servererror',
  SERVER_WARN = 'serverwarn',
  SERVER_INFO = 'serverinfo',
  SERVER_DEBUG = 'serverdebug',
  SERVER_ALL = 'serverall'
}
let currentLogger: Logger = Logger.CONSOLE;
let defaultLogger = {
  logger: currentLogger as string
};
export { defaultLogger };

let overrideLogger: string | null = null;

// Remember the originally assigned functions
const consoleError = console.error;
const consoleWarn = console.warn;
const consoleInfo = console.info;
const consoleDebug = console.debug;
const consoleLog = console.log;

export function setupLogger(): void {
  currentLogger = (overrideLogger != null)
    ? overrideLogger as Logger
    : defaultLogger.logger as Logger;
  switch (currentLogger) {
    case Logger.CONSOLE: setupForLogConsole(5); break;
    case Logger.CONSOLE_DEBUG: setupForLogConsole(4); break;
    case Logger.CONSOLE_INFO: setupForLogConsole(3); break;
    case Logger.CONSOLE_WARN: setupForLogConsole(2); break;
    case Logger.CONSOLE_ERROR: setupForLogConsole(1); break;
    case Logger.SERVER_NONE: logSupport(0); break;
    case Logger.SERVER_ERROR: logSupport(1); break;
    case Logger.SERVER_WARN: logSupport(2); break;
    case Logger.SERVER_INFO: logSupport(3); break;
    case Logger.SERVER_DEBUG: logSupport(4); break;
    case Logger.SERVER_ALL: logSupport(5); break;
    default:
      console.error(`current logger not recognized: ${currentLogger}`);
  }
}

export function initializeDefaultLogger(logger: string): void {
  defaultLogger.logger = logger;
}

// !!NOTE:  Only call this function if the current application user's email address has a synthesis domain (@synthesis.health or synthesishealthinc.com)
export function enableLoggerOverride(): void {
  if (LocalStorageItems.overrideLogger != null) {
    console.warn('enableLoggerOverride - enabling');
    overrideLogger = LocalStorageItems.overrideLogger;
    setupLogger();
  } else {
    // console.warn('enableLoggerOverride - NOT enabling');
  }
}

export function disableLoggerOverride(): void {
  if (overrideLogger != null) {
    console.warn('disableLoggerOverride - disabling');
    overrideLogger = null;
    setupLogger();
  }
}

const noLogger = function (): void {
};

// Normal console logging - no mapping to LogSupport
function setupForLogConsole(config: number): void {
  console.error = config >= 1 ? consoleError : noLogger;
  console.warn = config >= 2 ? consoleWarn : noLogger;
  console.info = config >= 3 ? consoleInfo : noLogger;
  console.debug = config >= 4 ? consoleDebug : noLogger;
  console.log = config >= 5 ? consoleLog : noLogger;
}

// Provide mapping for LogSupport support with no console.log mapping. If
// we discover the log level has changed, switch to a different log mechanism
function logSupport(config: number): void {

  console.error = config >= 1 ? function (...args: any[]): void {
    LogSupport.isConnected() ? LogSupport.logError(logFormat(args)) : consoleError(...args);
  } : noLogger;

  console.warn = config >= 2 ? function (...args: any[]): void {
    LogSupport.isConnected() ? LogSupport.logWarn(logFormat(args)) : consoleWarn(...args);
  } : noLogger;

  console.info = config >= 3 ? function (...args: any[]): void {
    LogSupport.isConnected() ? LogSupport.logInfo(logFormat(args)) : consoleInfo(...args);
  } : noLogger;

  console.debug = config >= 4 ? function (...args: any[]): void {
    LogSupport.isConnected() ? LogSupport.logDebug(logFormat(args)) : consoleDebug(...args);
  } : noLogger;

  console.log = config >= 5 ? function (...args: any[]): void {
    LogSupport.isConnected() ? LogSupport.logDebug(logFormat(args)) : consoleLog(...args);
  } : noLogger;
}

// Provide serialialization of parameters -- be careful to ensure parameters
// don't contain self-references -- otherwise JSON.stringify fails. The symptom
// of this problem is a log line in fovia log from this logger, which has no content.
const IGNORE = [`undefined`, `function`];
const NATIVE = ['number', 'boolean', 'string', 'bigint', 'symbol'];

function logFormat(...args: any[]): string {
  let message = '';
  const messages: string[] = [];
  for (const param of args) {
    try {
      if (param == null) {
        continue;
      }
      const instance = typeof param;
      if (IGNORE.includes(instance)) {
        continue;
      }
      if (NATIVE.includes(instance)) {
        messages.push(`${param}`);
        continue;
      }
      if (instance === 'object') {
        messages.push(`${JSON.stringify(param)}`);
      }
    }
    catch (err) {
      // disabled this message for production
      // consoleError(`logFormat exception `, err, args); //
    }
  }
  if (messages.length === 0) {
    // disabled this message for production
    // consoleError(`empty log message with params`, args);
  } else {
    message = messages.join(',');
  }

  return message;
}

// Copied from https://github.com/douglascrockford/JSON-js/blob/master/cycle.js
/*
    cycle.js
    2021-05-31

    Public Domain.

    NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

    This code should be minified before deployment.
    See https://www.crockford.com/jsmin.html

    USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
    NOT CONTROL.
*/

// The file uses the WeakMap feature of ES6.

/*jslint eval */

/*property
    $ref, decycle, forEach, get, indexOf, isArray, keys, length, push,
    retrocycle, set, stringify, test

*/
/*
if (typeof JSON.decycle !== "function") {
  JSON.decycle = function decycle(object, replacer) {
    "use strict";


if (!Reflect.has(JSON, 'decycle') && Reflect.defineProperty(JSON, 'decycle', decycle)) {
  JSON.decycle()
}
function decycle(object: any, replacer: any) {

  // Make a deep copy of an object or array, assuring that there is at most
  // one instance of each object or array in the resulting structure. The
  // duplicate references (which might be forming cycles) are replaced with
  // an object of the form

  //      {"$ref": PATH}

  // where the PATH is a JSONPath string that locates the first occurance.

  // So,

  //      var a = [];
  //      a[0] = a;
  //      return JSON.stringify(JSON.decycle(a));

  // produces the string '[{"$ref":"$"}]'.

  // If a replacer function is provided, then it will be called for each value.
  // A replacer function receives a value and returns a replacement value.

  // JSONPath is used to locate the unique object. $ indicates the top level of
  // the object or array. [NUMBER] or [STRING] indicates a child element or
  // property.

  var objects = new WeakMap();     // object to path mappings

  return (function derez(value, path) {

    // The derez function recurses through the object, producing the deep copy.

    var old_path;   // The path of an earlier occurance of value
    var nu: any;    // The new object or array

    // If a replacer function was provided, then call it to get a replacement value.

    if (replacer !== undefined) {
      value = replacer(value);
    }

    // typeof null === "object", so go on if this value is really an object but not
    // one of the weird builtin objects.

    if (
      typeof value === "object"
      && value !== null
      && !(value instanceof Boolean)
      && !(value instanceof Date)
      && !(value instanceof Number)
      && !(value instanceof RegExp)
      && !(value instanceof String)
    ) {

      // If the value is an object or array, look to see if we have already
      // encountered it. If so, return a {"$ref":PATH} object. This uses an
      // ES6 WeakMap.

      old_path = objects.get(value);
      if (old_path !== undefined) {
        return { $ref: old_path };
      }

      // Otherwise, accumulate the unique value and its path.

      objects.set(value, path);

      // If it is an array, replicate the array.

      if (Array.isArray(value)) {
        nu = [];
        value.forEach(function (element, i) {
          nu[i] = derez(element, path + "[" + i + "]");
        });
      } else {

        // If it is an object, replicate the object.
        nu = {};
        Object.keys(value).forEach(function (name) {
          nu[name] = derez(
            value[name],
            path + "[" + JSON.stringify(name) + "]"
          );
        });
      }
      return nu;
    }
    return value;
  }(object, "$"));
}

    if (typeof JSON.retrocycle !== "function") {
      JSON.retrocycle = function retrocycle($) {
        "use strict";

function retrocycle($) {
  "use strict";

  // Restore an object that was reduced by decycle. Members whose values are
  // objects of the form
  //      {$ref: PATH}
  // are replaced with references to the value found by the PATH. This will
  // restore cycles. The object will be mutated.

  // The eval function is used to locate the values described by a PATH. The
  // root object is kept in a $ variable. A regular expression is used to
  // assure that the PATH is extremely well formed. The regexp contains nested
  // * quantifiers. That has been known to have extremely bad performance
  // problems on some browsers for very long strings. A PATH is expected to be
  // reasonably short. A PATH is allowed to belong to a very restricted subset of
  // Goessner's JSONPath.

  // So,
  //      var s = '[{"$ref":"$"}]';
  //      return JSON.retrocycle(JSON.parse(s));
  // produces an array containing a single element which is the array itself.

  var px = /^\$(?:\[(?:\d+|"(?:[^\\"\u0000-\u001f]|\\(?:[\\"\/bfnrt]|u[0-9a-zA-Z]{4}))*")\])*$/;

  (function rez(value) {

    // The rez function walks recursively through the object looking for $ref
    // properties. When it finds one that has a value that is a path, then it
    // replaces the $ref object with a reference to the value that is found by
    // the path.

    if (value && typeof value === "object") {
      if (Array.isArray(value)) {
        value.forEach(function (element, i) {
          if (typeof element === "object" && element !== null) {
            var path = element.$ref;
            if (typeof path === "string" && px.test(path)) {
              value[i] = eval(path);
            } else {
              rez(element);
            }
          }
        });
      } else {
        Object.keys(value).forEach(function (name) {
          var item = value[name];
          if (typeof item === "object" && item !== null) {
            var path = item.$ref;
            if (typeof path === "string" && px.test(path)) {
              value[name] = eval(path);
            } else {
              rez(item);
            }
          }
        });
      }
    }
  }($));
  return $;
}
/*
 * /**
 * Use CallSite to extract filename and number, for more info read: https://v8.dev/docs/stack-trace-api#customizing-stack-traces
 * @param numberOfLinesToFetch - optional, when we want more than one line back from the stacktrace
 * @returns {string|null} filename and line number separated by a colon, if numberOfLinesToFetch > 1 we'll return a string
 * that represents multiple CallSites (representing the latest calls in the stacktrace)
 *
 */
/*
const getFileNameAndLineNumber = function getFileNameAndLineNumber (numberOfLinesToFetch = 1) {
    const oldStackTrace = Error.prepareStackTrace;

    const boilerplateLines = line => line &&
        line.getFileName() &&
        (line.getFileName().indexOf('<My Module Name>') &&
        (line.getFileName().indexOf('/node_modules/') < 0));

    try {
        // eslint-disable-next-line handle-callback-err
        Error.prepareStackTrace = (err, structuredStackTrace) => structuredStackTrace;
        Error.captureStackTrace(this);
        // we need to "peel" the first CallSites (frames) in order to get to the caller we're looking for
        // in our case we're removing frames that come from logger module or from winston
        const callSites = this.stack.filter(boilerplateLines);
        if (callSites.length === 0) {
            // bail gracefully: even though we shouldn't get here, we don't want to crash for a log print!
            return null;
        }
        const results = [];
        for (let i = 0; i < numberOfLinesToFetch; i++) {
            const callSite = callSites[i];
            let fileName = callSite.getFileName();
            fileName = fileName.includes(BASE_DIR_NAME) ? fileName.substring(BASE_DIR_NAME.length + 1) : fileName;
            results.push(fileName + ':' + callSite.getLineNumber());
        }
        return results.join('\n');
    } finally {
        Error.prepareStackTrace = oldStackTrace;
    }
};

function humanReadableFormatter ({ level, message, ...metadata }) {
    const filename = getFileNameAndLineNumber();
    return `[${level}] [${filename}] ${message} ${JSON.stringify(metadata)}`;
}

const logger = winston.createLogger({
  transports: [
      new winston.transports.Console({
            level: 'info',
            handleExceptions: true,
            humanReadableUnhandledException: true,
            json: false,
            colorize: { all: true },
            stderrLevels: ['error', 'alert', 'critical'],
            format: combine(
                colorize(),
                timestamp(),
                humanReadableFormatter,
            ),
        })
    ]
});
*/
