import { CachedExamStats } from './cached-exam-stats';

describe('CachedExamStats', () => {
  it('should create an instance', () => {
    expect(new CachedExamStats('studyuid')).toBeTruthy();
  });
});
