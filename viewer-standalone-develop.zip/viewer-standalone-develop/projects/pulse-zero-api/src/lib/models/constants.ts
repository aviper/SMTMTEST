export const MB = 1024 * 1024;
export const KB = 1024;
export const TICKS_PER_SEC = 1000;
