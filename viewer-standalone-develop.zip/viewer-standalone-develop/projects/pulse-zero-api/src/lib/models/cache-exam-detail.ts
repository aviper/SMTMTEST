import { ExamGroup, ExamInformation, IExamCacheStatus, IExamGroupCacheStatus } from '@server-api';
import { StudyStatus } from './exam-stats';
/**
 * Data representing information about a single exam that is part of a particular session
 *
 * Fields
 * - `examGroup`: ExamGroup associated which contains this particular exam
 * - `groupCacheStatus`: reference to the cache status for this group
 * - `examInfo`: ExamInformation as available from token-auth-service
 * - `examCacheStatus`: reference to the cache status for this exam
 * - `priority`: number 1...n representing caching priority
 * - 'cached': status of study caching
 */
export interface IExamCacheStatusEx extends IExamCacheStatus {
  studyStatus: StudyStatus;
}

export interface IExamDetailInformation {
  examGroup: ExamGroup;
  groupCacheStatus: IExamGroupCacheStatus | null;
  examInfo: ExamInformation;
  examCacheStatus: IExamCacheStatusEx | null;
  priority: number;
  cached: boolean;
}

export class ExamDetailInformation implements IExamDetailInformation {
  private _groupCacheStatus: IExamGroupCacheStatus | null;
  private _examCacheStatus: IExamCacheStatusEx | null;
  private _cached: boolean;
  constructor(
    public examGroup: ExamGroup,
    public examInfo: ExamInformation,
    public priority: number
  ) {
    this._groupCacheStatus = null;
    this._examCacheStatus = null;
    this._cached = false;
  }

  public get groupCacheStatus(): IExamGroupCacheStatus | null {
    return this._groupCacheStatus;
  }

  public set groupCacheStatus(value: IExamGroupCacheStatus) {
    this._groupCacheStatus = value;
    this.logInfo();
  }

  public get cached(): boolean {
    return this._cached;
  }

  public set cached(value: boolean) {
    this._cached = value;
    this.logInfo();
  }

  public get examCacheStatus(): IExamCacheStatusEx | null {
    return this._examCacheStatus;
  }

  public set examCacheStatus(value: IExamCacheStatusEx) {
    this._examCacheStatus = value;
    this.logInfo();
  }

  private logInfo(): void {
  //  console.log(`${this.constructor.name} ${examDetailToString(this)}`);
  }
}
