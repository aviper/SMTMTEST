export class CachedImageInfo {
  constructor(
    public foviaImageKey: string,
    public studyUID: string,
    public pixelsFileSizeBytes: number,
  ) { }
}
