
export enum StudyStatus {
  eNEW = 'Not yet cached',
  eNOT_CACHED = 'No images cached',
  eSTARTING = 'Starting',
  eLOADING = 'Loading',
  eCACHE_INITIAL_STATS = 'Load Stats',
  eCREATE_CACHE_LIST = 'Create list of images',
  ePARTIALLY_CACHED = 'Paused',
  eCACHING_IMAGES = 'Caching',
  eCACHING_MANIFEST = 'Caching Manifest',
  eCACHING_STATS = 'Caching Stats',
  eCACHE_CLEANUP = 'Cache cleanup',
  eCACHED = 'Complete',
  eCACHING_ERROR = 'Caching Error'
}

export class ImageStats {
  // This structure is serialized to disk, if we make changes to the
  // structure we may need to support the earlier version for de-serialization.
  public fileVersion = '1.0';
  constructor(public imageUID: string = '', public notation: string = '',
    public fetchImageTime: number = 0,
    public cacheWriteTime: number = 0,
    public totalImageTime: number = 0,
    public imageBytes: number = 0,
    public imageNum: number = -1,
    public isCached: boolean = false,
    // Value only saved if it's different than main StudyUID -- stats saved if not cached
    public imageStudyUID: string = ''
  ) {
  }
}

const VERSION = '1.1';

export class ExamStats {
  // This structure is serialized to disk, if we make changes to the
  // structure we may need to support the earlier version for de-serialization.
  // Use and update with care - remember every user may have cached content from a previous version.
  public fileVersion = [...VERSION];
  public userId = '';
  public totalExamImages = 0;
  public studyUID = '';
  public studyStatus: StudyStatus = StudyStatus.eNEW;

  public studyElapsed = 0;
  public cacheImagesElapsed = 0;
  public manifestBytes = 0;
  public manifestLoadTime = 0;
  public manifestCacheTime = 0;
  public cachedImageCount = 0;
  public imageStats: ImageStats[] = [];
  public modality = '';
  public skippedImageCount = 0;
}

// Handle version specific ExamStat compatiability
export function getExamStatsFromExamStatsObj(examStatsObj: Object): ExamStats {
  const examStats: ExamStats = new ExamStats();
  Object.assign(examStats, examStatsObj);
  examStats.fileVersion = [...VERSION];
  return examStats;
}
