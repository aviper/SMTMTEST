import { DiskInfo } from './disk-info';

describe('DiskInfo', () => {
  it('should create an instance', () => {
    expect(new DiskInfo()).toBeTruthy();
  });
});
