import { CachedImageInfo } from './cached-image-info';

describe('CachedImageInfo', () => {
  it('should create an instance', () => {
    expect(new CachedImageInfo('a', 'b', 1, 2, undefined, undefined)).toBeTruthy();
  });
});
