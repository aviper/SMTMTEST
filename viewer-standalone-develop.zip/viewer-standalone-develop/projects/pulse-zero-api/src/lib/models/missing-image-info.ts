export const NO_IMAGE_DATA = -2;
const MAX_LOAD_STUDY_REQUESTS = 2;

export class RetryErrorInfo {
  constructor(
    public imageKey: string,
    public retryCount: number = 0,
    public errorCode: number[] = []) {
  }
}

export class MissingImageInfo {
  protected missingImages = new Map<string, RetryErrorInfo>();
  protected missingImageErrorSummary = new Map<number, number>();
  protected _loadCount = 0;

  public addMissingImage(imageKey: string, errorCode: number): void {
    let missingImageInfo = this.missingImages.get(imageKey);
    if (missingImageInfo !== undefined) {
      missingImageInfo.errorCode.push(errorCode);
      missingImageInfo.retryCount++;
    } else {
      missingImageInfo = new RetryErrorInfo(imageKey);
      missingImageInfo.errorCode.push(errorCode);
      this.missingImages.set(imageKey, missingImageInfo);
    }
    this.increaseErrorCount(errorCode);
  }

  // Invalid images are those images that don't belong to 'this' exam -- which can happen if
  // ScanDICOMDir results from fovia had other images which don't belong to 'this' study
  // We track this so we can reconcile our count of objects we handle versus what fovia thinks
  // belongs in the study
  public invalidImageCount = 0;

  public set loadCount(value: number) {
    this._loadCount = value;
  }

  public get loadCount(): number {
    return this._loadCount;
  }

  public removeMissingImage(imageKey: string): void {
    const missingImageInfo = this.missingImages.get(imageKey);
    if (missingImageInfo !== undefined) {
      this.missingImages.delete(imageKey);
      for (const errorCode of missingImageInfo.errorCode) {
        this.decreaseErrorCount(errorCode);
      }
    }
  }

  public hasErrorInfo(imageKey: string): boolean {
    return this.missingImages.has(imageKey);
  }

  public hasMissingImages(): boolean {
    return this.missingImageCount > 0;
  }

  public get missingImageCount(): number {
    return this.missingImages.size;
  }

  public shouldRetry(imageKey: string): boolean {
    const retryInfo = this.missingImages.get(imageKey);
    if (retryInfo !== undefined) {
      return this.shouldRetryError(retryInfo);
    }
    return false;
  }

  public hasRetriableErrors(): boolean {
    // NOT YET: When we know more about when we want to retry, enable this code.
    return false;
    if (this.loadCount >= MAX_LOAD_STUDY_REQUESTS) {
      return false;
    }
    let retriable = this.missingImageCount > 0;
    const retryInfoList = [...this.missingImages.values()];
    for (const retryInfo of retryInfoList) {
      retriable = this.shouldRetryError(retryInfo);
      if (retriable) {
        // At least one retriable entry
        return retriable;
      }
    }
    return retriable;
  }

  public logMissingImageSummary(studyUID: string): void {
    const errorList = [...this.missingImageErrorSummary];
    const errorInfoList: string[] = [];
    for (const info of errorList) {
      errorInfoList.push(`${this.getErrorCode(info[0])}: ${info[1].toString(10)}`);
    }
    console.warn(`MissingImage errorCode summary ${studyUID}: ${errorInfoList.join(',')}`);
  }

  private getErrorCode(errorCode: number): string {
    const str = errorCode === NO_IMAGE_DATA ? 'no pixel data' : `HTTP ${errorCode.toString(10)}`;
    return str;
  }

  private increaseErrorCount(errorCode: number): void {
    let errorCount = this.missingImageErrorSummary.get(errorCode);
    if (errorCount !== undefined) {
      errorCount++;
      this.missingImageErrorSummary.set(errorCode, errorCount);
    } else {
      this.missingImageErrorSummary.set(errorCode, 1);
    }
  }

  private decreaseErrorCount(errorCode: number): void {
    let errorCount = this.missingImageErrorSummary.get(errorCode);
    if (errorCount !== undefined) {
      errorCount--;
      if (errorCount === 0) {
        this.missingImageErrorSummary.delete(errorCode);
      } else {
        this.missingImageErrorSummary.set(errorCode, errorCount);
      }
    } else {
      console.log(`${this.constructor.name}.decreaseErrorCount UNEXPECTED missing error count for error code ${errorCode}`);
    }
  }

  private shouldRetryError(imageInfo: RetryErrorInfo): boolean {
    const lastErrorCode = imageInfo.errorCode[imageInfo.errorCode.length - 1];
    switch (lastErrorCode) {
      // Retriable HTTP errors
      case 408: // Request timeout
      case 425: // Too Early -- server not ready
      case 429: // Too many requests Rate-limiting, retry after delay
      case 502: // Bad gateway
      case 503: // Service unavailable
      case 504: // Gateway timeout
        return imageInfo.retryCount < MAX_LOAD_STUDY_REQUESTS;
      // All other error codes
      case 404: // Not found
      case 406: // Not acceptable w/ Google this means the exam could not be transcoded from it's Transfer Syntax to Not compressed
      case 500: // Internal Server Error
      default:
        return false;
    }
  }

}
