import { UUID } from '@server-api';

export enum BroadcastMessageName {
    viewerSessionUpdate = 'viewerSessionUpdate',
    viewerFocusUpdate = 'viewerFocusUpdate'
}

export interface IBroadcastMessageBase {
    messageName: string;
}

// Used to notify listeners of changes to the set of exams currently in a viewer session
export interface IViewerSessionUpdateMessage extends IBroadcastMessageBase {
    viewerInstanceID: UUID;
    primaryStudyUID: string;
    comparisonStudyUIDs: string[];
    internalUserId: number | null;
}

// Used to notify listeners when a viewer instance takes focus
export interface IViewerInstanceFocusMessage extends IBroadcastMessageBase {
    viewerInstanceID: UUID;
}
