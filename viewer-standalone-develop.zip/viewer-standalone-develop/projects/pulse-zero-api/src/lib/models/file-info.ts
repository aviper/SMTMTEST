import Fovia from 'foviaapi';

export interface IFileInfo {
  fileVersion: string;
  cryptoIvStr: string | null;
  cryptoKeyId: string | null;
  userId: string | null;
  cacheTime: number | null;
  pixeldata: any | null;
  key: any | null;
  lutEncoded: any | null;
  lut: ILutInfo | null;
  imageTagEncoded: any | null;
  minMax: IMinMax | null;
  overlay6000: any;
  overlay6000Encoded: any;
}

export interface ILutInfo {
  arraySize: number;
  buffer: number[];
  descBuffer: number[];
  lutExplanation: string;
  type: number;
}

export interface IMinMax {
  min: number;
  max: number;
}

export class FileInfo extends Fovia.SourcePixelData implements IFileInfo {
  // This structure is serialized to disk, if we make changes to the
  // structure we may need to support the earlier version for de-serialization.
  public fileVersion = '1.0';
  public cryptoIvStr: string | null;
  public cryptoKeyId: string | null;
  public minMax: IMinMax | null;
  public userId: string;
  public cacheTime: number;

  constructor(imageInfo: Fovia.SourcePixelData) {
    super(imageInfo.pixeldata, imageInfo.key, imageInfo.lutEncoded, imageInfo.imageTagEncoded);
    this.lut = imageInfo.lut;
    this.cryptoIvStr = null;
    this.cryptoKeyId = null;
    this.minMax = null;
    this.userId = '';
    this.cacheTime = Date.now();
    this.lutEncoded = null; // in base class, but not used
    this.pixeldata = null;  // in base class, but not used
  }

  private static fromDeserializedFields(fields: any): FileInfo | null {
    const imageInfo = new Fovia.SourcePixelData(null);
    const fileInfo = new FileInfo(imageInfo);
    fileInfo.fileVersion = fields.fileVersion ?? '';
    fileInfo.cryptoIvStr = fields.cryptoIvStr ?? null;
    fileInfo.cryptoKeyId = fields.cryptoKeyId ?? null;
    fileInfo.userId = fields.userId ?? null;
    fileInfo.cacheTime = fields.cacheTime ?? null;
    fileInfo.key = fields.key ?? null;
    fileInfo.lut = fields.lut ?? null;
    fileInfo.minMax = fields.minMax ?? null;
    fileInfo.pixeldata = null;   // in base class, but not used
    fileInfo.lutEncoded = null;  // in base class, but not used
    fileInfo.imageTagEncoded = fields.imageTagEncoded ?? null;
    return fileInfo;
  }

  public async serialize(): Promise<string | null> {
    try {
      this.pixeldata = null;
      this.lutEncoded = null;
      return JSON.stringify(this);
    } catch (err) {
      console.error(`${this.constructor.name}  serialize: stringify failed`);
      console.log(`${this.constructor.name}  serialize: stringify failed`, err);
    }
    return null;
  }

  public static async deserialize(serialized: string): Promise<FileInfo | null> {
    try {
      const fields = JSON.parse(serialized);
      if (fields == null) {
        console.error(`${this.constructor.name}  deserialize: JSON.parse empty return`);
        return null;
      }
      return FileInfo.fromDeserializedFields(fields);
    } catch (err) {
      console.error(`${this.constructor.name}  deserialize: failed`);
      console.log(`${this.constructor.name}  deserialize: failed`, err);
    }
    return null;
  }
}

