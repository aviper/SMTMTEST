import { BehaviorSubject, Observable } from 'rxjs';
import { CachedImageInfo } from './cached-image-info';
import { MB } from './constants';
import { DiskInfo } from './disk-info';
import { LogSupport } from '@server-api';

// We'll start with the maximum configurable quota. If we start with a more modest
// number, then users who have a large quota will have a startup quota error in their logs.
// We'll rely on the user's real quota configuration to update it pretty soon
export const STARTING_QUOTA_MB = 100000;
const NINETY_MB = 90;
const TEN_MB = 10;
export class TrackCacheUsage {
  protected diskInfo$$ = new BehaviorSubject<DiskInfo>(new DiskInfo());
  protected _lastDiskInfo = new DiskInfo();
  protected _cacheUsageBytes = 0;
  protected _lastCacheUsageReport = 0;
  protected _cacheUsageMB$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  protected cachedImageInfoMap = new Map<string, CachedImageInfo>();
  // Maximum amount of disk space we can use for our cache activity --
  // just a guess really unless the user actually tells us how much we can use,
  // which is what we're hoping for.
  // At this time OPFS won't tell us how much space is available for security reasons.
  protected _cacheQuotaMB: number = STARTING_QUOTA_MB;
  // OPFS reports when a request causes the current origin quota to be exceeded
  // Detect when this happens and track our definition of 'quota' to include this information
  // as well. The OPFS quota will be less than the user's configured quota.
  protected opfsCacheQuotaMB: number = STARTING_QUOTA_MB;

  // Set to true when we are bump up against our quota value. This aborts further handling of the exam images and will
  // cause a study to be dropped from the OPFS cache.
  protected cacheQuotaError$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  protected opfsEvictionDetectionCount$$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  protected _quietDuringRebuild = false;

  public set quietDuringRebuild(value: boolean) {
    this._quietDuringRebuild = value;
    if (!this._quietDuringRebuild) {
      // emit our current cacheUsedBytes
      this.cacheUsageBytes += 0;
      this.diskInfo = this._lastDiskInfo;
    }
  }

  public get cacheUsageMB(): number {
    return this._cacheUsageMB$$.value;
  }

  public get cacheUsageMB$(): Observable<number> {
    return this._cacheUsageMB$$;
  }

  public get cacheQuotaError(): boolean {
    return this.cacheQuotaError$$.value;
  }

  public get cacheQuotaError$(): Observable<boolean> {
    return this.cacheQuotaError$$;
  }

  public get cacheQuotaMB(): number {
    return this._cacheQuotaMB;
  }

  public set opfsEvictionDetectionCount(value: number) {
    this.opfsEvictionDetectionCount$$.next(value);
  }

  public get opfsEvictionDetectionCount(): number {
    return this.opfsEvictionDetectionCount$$.value;
  }

  public get opfsEvictionDetectionCount$(): Observable<number> {
    return this.opfsEvictionDetectionCount$$;
  }

  public set diskInfo(value: DiskInfo) {
    this._lastDiskInfo = value;
    if (!this._quietDuringRebuild) {
      this.diskInfo$$.next(value);
    }
  }

  public get diskInfo$(): Observable<DiskInfo> {
    return this.diskInfo$$;
  }

  public get diskInfo(): DiskInfo {
    return this.diskInfo$$.value;
  }

  public set cacheQuotaMB(value: number) {
    // If a user's quota is smaller than our current opfs quota,
    // we'll adopt it. Only allow increases to the quota if opfsCacheQuota
    // hasn't started throttling our disk usage
    if (this.opfsCacheQuotaMB === this._cacheQuotaMB || value < this.opfsCacheQuotaMB) {
      // adopt the new quota
      this.opfsCacheQuotaMB = value;
    }
    this._cacheQuotaMB = value;
    // console.log(`${this.constructor.name} cacheQuotaMB set to ${this._cacheQuotaMB} MB`);
    this.checkQuotaExceeded();
    const diskInfo = this.diskInfo$$.value;
    diskInfo.status = this.getCurrentDiskStatus();
    this.diskInfo = diskInfo;
  }

  public has(key: string): boolean {
    return this.cachedImageInfoMap.has(key);
  }

  public clear(): void {
    this.cachedImageInfoMap.clear();
    this.cacheUsageBytes = 0;
  }

  protected deleteImage(key: string): boolean {
    const info = this.cachedImageInfoMap.get(key);
    if (info != null) {
      this.cacheUsageBytes -= info.pixelsFileSizeBytes;
    }
    return this.cachedImageInfoMap.delete(key);
  }

  public set(key: string, value: CachedImageInfo): void {
    this.cacheUsageBytes += value.pixelsFileSizeBytes;
    this.cachedImageInfoMap.set(key, value);
  }

  public get cachedImageCount(): number {
    return this.cachedImageInfoMap.size;
  }

  public updateDiskSpaceInfo(spaceAvailable: StorageEstimate): DiskInfo {
    const diskInfo = new DiskInfo();
    // This spaceAvailable.quota is defined to be 60% of total (not available)
    // disk space. Worthless for tracking.
    diskInfo.estimatedTotalDiskSpaceMB = spaceAvailable.quota ? spaceAvailable.quota / MB : 0;
    diskInfo.totalUsageMB = spaceAvailable.usage ? spaceAvailable.usage / MB : 0;
    diskInfo.pulseVisionUsageMB = this.cacheUsageMB;
    diskInfo.status = this.getCurrentDiskStatus();
    this.diskInfo = diskInfo;
    return diskInfo;
  }

  // Called when we get OPFS errors
  public quotaErrorFromOPFS(quotaError: boolean): void {
    if (quotaError) {
      // Documentation on this error isn't great, and the circumstances that
      // trigger it are not well defined. So:
      // 1. establsih an opfsQuota quota value
      // 2. report a problem
      // 3. use disk info establish get a precise number.
      // 4. use a 10% 'cushion' around this quota so that we
      //    don't cause problems too often.
      const cushion = .1 * this.diskInfo.totalUsageMB;
      const newQuotaMB = this.diskInfo.totalUsageMB - cushion;
      const message = `${this.constructor.name} OPFS QUOTA ERROR quota changed from ${this.opfsCacheQuotaMB} MB to ${newQuotaMB} MB`;
      this.opfsCacheQuotaMB = newQuotaMB;
      console.log(message);
      LogSupport.logError(message);
    }
    this.checkQuotaExceeded();
  }

  public removeStudyImagesFromMap(studyUID: string): void {
    for (const imageInfo of this.cachedImageInfoMap) {
      if (imageInfo[1].studyUID === studyUID) {
        this.deleteImage(imageInfo[0]);
      }
    }
  }

  protected get cacheUsedBytes(): number {
    return this._cacheUsageBytes;
  }

  protected set cacheUsageBytes(value: number) {
    this._cacheUsageBytes = value;
    const usageMB = this._cacheUsageBytes / MB;
    const deltaMB = usageMB - (this._lastCacheUsageReport / MB);

    // Generally throttle the UI updates, heavily throttled during
    // rebuild, otherwise less throttling
    // During regular operation we report more frequently
    const throttleMB = this._quietDuringRebuild ? NINETY_MB : TEN_MB;
    // Periodically report updates to UI
    if (Math.abs(deltaMB) >= throttleMB
      || this._cacheUsageBytes === 0
      || this._cacheUsageBytes < this._lastCacheUsageReport) {

      this._cacheUsageMB$$.next(usageMB);
      this._lastCacheUsageReport = this._cacheUsageBytes;
      this.diskInfo$$.next(this._lastDiskInfo);
    }
    this.checkQuotaExceeded();
  }

  protected get cacheUsageBytes(): number {
    return this._cacheUsageBytes;
  }

  protected checkQuotaExceeded(): void {
    const cacheUsageMB = this._cacheUsageBytes / MB;
    const quota = Math.min(this.cacheQuotaMB, this.opfsCacheQuotaMB);
    const quotaExceeded = cacheUsageMB > quota;
    // console.log(`${this.constructor.name} checkQuotaExceeded ${this.cacheUsageMB} ${quota} current: ${this.cacheQuotaError} next: ${quotaExceeded}`);
    if (quotaExceeded !== this.cacheQuotaError) {
      const message = `${this.constructor.name} QUOTA ERROR ${this.cacheQuotaError} changing to ${quotaExceeded} usage: ${this.cacheUsageMB} disk: ${this.diskInfo.totalUsageMB} ${quota} min(${this.cacheQuotaMB} MB, ${this.opfsCacheQuotaMB} MB)`;
      quotaExceeded ? console.error(message) : console.info(message);
    }
    // Always notify the quota state
    this.cacheQuotaError$$.next(quotaExceeded);
  }

  protected getCurrentDiskStatus(): string {
    const status = this.cacheQuotaError ? 'QUOTA ERROR' :
      this.opfsEvictionDetectionCount > 0 ? 'EVICTION' : 'NORMAL';
    return status;
  }
}
