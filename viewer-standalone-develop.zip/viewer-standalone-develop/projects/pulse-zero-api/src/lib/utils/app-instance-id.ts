import { UUID, uuid4 } from '@server-api';

let _appInstanceID: UUID | null = null;
export function getAppInstanceID(): UUID {
  if (_appInstanceID == null) {
    _appInstanceID = uuid4();
  }
  return _appInstanceID;
}
