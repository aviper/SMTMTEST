import { IExamDetailInformation } from '../models';


export function examDetailToString(e: IExamDetailInformation): string {
  const examCacheStatus = e.examCacheStatus ? e.examCacheStatus.cacheStatus : 'null';
  const groupCacheStatus = e.groupCacheStatus ? e.groupCacheStatus.examGroupCacheStatus : 'null';
  const status = e.examCacheStatus ? e.examCacheStatus.studyStatus : 'not yet';
  const s = `${e.examInfo.studyUID} ${e.examGroup.groupId} examStatus: '${examCacheStatus}' status: '${status}' primary: ${e.examInfo.primary} priority: ${e.priority} cached: ${e.cached} groupStatus: '${groupCacheStatus}'`;
  return s;
}
