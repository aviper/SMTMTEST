import Fovia from 'foviaapi';
import { makeImageKey, promiseTimeout } from '@server-api';
import { decompressArrayBuffer, extractErrorCodeFromException, PV_ERRORS } from '@worker-compatible-api';
import { ComputeUtilsService } from '../services';

const ONE_SECOND_MS = 1000;
const IMAGE_DOWNLOAD_TIMEOUT_MS = 20000;
const PIXEL_BYTE_COUNT_THRESHOLD = 1048576;  // 1MB - images larger than this use the Plug-in

// Download an image's pixels from the Fovia sever.  First try the 'get-pixels' plug-in that compresses the pixels before sending using the 'deflate' algorithm.
// If that fails, fall back to Fovia's standard 'getSourcePixelData' function.
export async function downloadSourcePixelData(studyInstanceUID: string,
                                              seriesInstanceUID: string,
                                              subSeriesID: number,
                                              imageInstanceUID: string,
                                              imageNumber: number,
                                              frameNumber: number,
                                              imagePixelsByteCount: number,
                                              computeUtils: ComputeUtilsService | null = null): Promise<Fovia.SourcePixelData | null> {

  let data: Fovia.SourcePixelData | null = null;
  const uniqueID = seriesInstanceUID + '.' + subSeriesID;
  const imageKey = makeImageKey(imageInstanceUID, frameNumber);
  try {
    // For large images, first try to get compressed pixels through our fovia plug-in
    const foviaPluginPromise = getSourcePixelDataThroughPlugin(studyInstanceUID, seriesInstanceUID, subSeriesID, imageInstanceUID, imageNumber, frameNumber);
    data = await promiseTimeout<any, PV_ERRORS>(foviaPluginPromise, IMAGE_DOWNLOAD_TIMEOUT_MS + ONE_SECOND_MS, PV_ERRORS.TIMEOUT);
    if (data != null) {
      // console.log(`getSourcePixelData - from FOVIA PLUG-IN`);
    } else {
      // Next try to get the image pixels directly from the Fovia server
      console.info(`downloadSourcePixelData plugin failed.  retrying pixel data request through getSourcePixelDataThroughFoviaSafe for (${imageNumber} ${uniqueID} ${imageKey})`);
      const foviaServerPromise = getSourcePixelDataThroughFoviaSafe(imageNumber, uniqueID, imageKey);
      data = await promiseTimeout<Fovia.SourcePixelData | null, PV_ERRORS>(foviaServerPromise, IMAGE_DOWNLOAD_TIMEOUT_MS, PV_ERRORS.TIMEOUT);
      if (data == null) {
        console.error(`downloadSourcePixelData getSourcePixelDataThroughFoviaSafe returned null pixel data for (${imageNumber} ${uniqueID} ${imageKey})`);
      } else {
        // console.log(`getSourcePixelData - from FOVIA`);
      }
    }
  } catch (err) {
    const errCode = extractErrorCodeFromException(err);
    console.error(`downloadSourcePixelData exception for (${imageNumber} ${uniqueID} ${imageKey}) ${errCode}`, err);
  }
  return data;
}

enum PixelDataType {
  None = 'none',
  Uncompressed = 'uncompressed',
  Deflated = 'deflated'
}

interface GetPixelsPluginResult {
  success: boolean;
  message: string | undefined;
  errorId: string;
  pixelDataType: PixelDataType;
  studyInstanceUID: string;
  seriesInstanceUID: string;
  sopInstanceUID: string;
  imageNumber: number;
  nonImageDataParams: any | undefined;
  pixelBuffer: ArrayBuffer | undefined;
  imageTagEncoded: any | undefined;
}

async function getSourcePixelDataThroughPlugin(studyInstanceUID: string,
                                               seriesInstanceUID: string,
                                               subSeriesID: number,
                                               imageInstanceUID: string,
                                               imageNumber: number,
                                               frameNumber: number,
                                               computeUtils: ComputeUtilsService | null = null): Promise<Fovia.SourcePixelData | null> {

  try {
    const uniqueId = seriesInstanceUID + '.' + subSeriesID;
    const imageKey = imageInstanceUID.trim() + '_' + frameNumber;
    const pixelRequestPayload = {
      pluginjs: 'synth-fovia/get-pixels.plugin',
      sourceName: 'vision',
      studyInstanceUID: studyInstanceUID,
      seriesInstanceUID: seriesInstanceUID,
      sopInstanceUID: imageInstanceUID,
      imageNumber: imageNumber,
      uniqueId: uniqueId,
      imageKey: imageKey,
      failAfterMilliseconds: IMAGE_DOWNLOAD_TIMEOUT_MS
    };

    const pixelRequestEvents = new Map();
    const reply = await Fovia.ServerContext.callCustomJSFunction(pixelRequestPayload, pixelRequestEvents);
    const result = (reply as any)?.result as GetPixelsPluginResult;
    // console.log(`Got pixel data for ${imageKey}`, result);
    if (!result || !result.success || result.pixelDataType === PixelDataType.None || result.pixelBuffer == null) {
      console.log(`getSourcePixelDataThroughPlugin -no pixels returned`, result);
      return null;
    }
    if (result.pixelDataType === PixelDataType.Uncompressed) {
      console.log(`getSourcePixelDataThroughPlugin - pixels are uncompressed`, result);
    }

    // sanity check
    if (pixelRequestPayload.sopInstanceUID !== result.sopInstanceUID || pixelRequestPayload.imageNumber !== result.imageNumber) {
      console.error(`getSourcePixelDataThroughPlugin - result from plug-in does match request`);
      console.log(`getSourcePixelDataThroughPlugin - result from plug-in does match request`, pixelRequestPayload, result);
      return null;
    }

    const pixelData = (result.pixelDataType === PixelDataType.Uncompressed)
        ? result.pixelBuffer
        : computeUtils
        	? (await computeUtils.decompressArrayBuffer(result.pixelBuffer, 'deflate'))
	       : (await decompressArrayBuffer(result.pixelBuffer, 'deflate'));
    if (pixelData == null || pixelData.byteLength === 0) {
      console.error(`getSourcePixelDataThroughPlugin - decompressArrayBuffer failed`);
      return null;
    }

    const imageTagEncoded = result.imageTagEncoded; // Actually, this has already been decoded
    const returnVal = new Fovia.SourcePixelData(pixelData, imageKey, null, imageTagEncoded);
    returnVal.lut = (result.nonImageDataParams?.length == null || result.nonImageDataParams.length === 0) ? null : result.nonImageDataParams;

    // console.log(`getSourcePixelDataThroughPlugin success`, result, returnVal);
    return returnVal;

  } catch (err) {
    console.error(`getSourcePixelDataThroughPlugin failed - exception  studyInstanceUID=${studyInstanceUID},  imageInstanceUID=${imageInstanceUID}, frameNumber=${frameNumber}`);
    console.log(`getSourcePixelDataThroughPlugin failed - exception  studyInstanceUID=${studyInstanceUID},  imageInstanceUID=${imageInstanceUID}, frameNumber=${frameNumber}`, err);
    return null;
  }
}

async function getSourcePixelDataThroughFoviaSafe(imageNumber: number, uniqueID: string, imageKey: string): Promise<Fovia.SourcePixelData | null> {
  try {
    const result = await Fovia.ServerContext.getSourcePixelData(imageNumber, uniqueID, imageKey);
    if (result) {
      const imageTagEncoded = result.imageTagEncoded;
      let imageTagDecoded = null;
      if (imageTagEncoded) {
        // Decode the CBOR into JSON
        if (typeof CBOR === 'object') { // loading from foviaAPI.js (not WebPack)
          imageTagDecoded = CBOR.decode(imageTagEncoded);
        } else {
          imageTagDecoded = Fovia.CBORAccess.CBOR.decode(imageTagEncoded);
        }
      }
      result.imageTagEncoded = imageTagDecoded;
    }
    return result;
  } catch (err) {
    console.error(`getSourcePixelDataThroughFoviaSafe failed - exception  imageNumber=${imageNumber},  uniqueID=${uniqueID}, imageKey=${imageKey}`);
    console.log(`getSourcePixelDataThroughFoviaSafe failed - exception  imageNumber=${imageNumber},  uniqueID=${uniqueID}, imageKey=${imageKey}`, err);
  }
  return null;
}
