import { Mutex, Semaphore } from "async-mutex";

// Pass this to a worker pool constructor in order share the same semaphore across worker pools that
// should be limited by the number of CPU cores on the client workstation
export const computeWorkerPoolSize = Math.min(window.navigator.hardwareConcurrency, 12);
export const computeWorkerPoolSemaphore = new Semaphore(computeWorkerPoolSize);

export class WorkerPool<WorkerType> {
  protected workerAccessSemaphore: Semaphore;
  public workers: WorkerPoolItem<WorkerType>[] = [];

  constructor(protected workerName: string,
              protected workerFactoryFn: () => Promise<WorkerType>,
              protected poolSize: number,  // when passing in a semaphore, be sure that the poolsize is at least as large as the semaphore size
              protected semaphore?: Semaphore) {
    this.workerAccessSemaphore = semaphore ?? new Semaphore(this.poolSize);
    console.log(`${this.constructor.name} worker pool size ${computeWorkerPoolSize} hardware supports ${window.navigator.hardwareConcurrency}`);
  }
  public async init(): Promise<void>{

    // First, close existing workers if there are any
    if (this.workers.length > 0) {
      await this.workerAccessSemaphore.acquire(this.poolSize);
      this.workers = [];  // according to Comlink docs, garbage collection should be enough to close out web workers proxy'ed by ComLink.
      this.workerAccessSemaphore.release(this.poolSize);
    }

    // Create new workers
    for (let i = 0; i < this.poolSize; i++) {
      const worker = await this.workerFactoryFn();
      this.workers.push(new WorkerPoolItem(worker));
    }
  }

  public async acquireWorker(): Promise<WorkerType | null> {
    // console.log(`acquireReader: waiting - count = ${this.semaphore.getValue()}`);
    await this.workerAccessSemaphore.acquire();
    // console.log(`acquireWorker: acquired - count = ${this.semaphore.getValue()}`);
    const workerItem = this.workers.find(r => !r.isLocked) ?? null;
    if (workerItem != null) {
      await workerItem.lock();
      // console.log(`acquireWorker: acquired returning`, workerItem);
      return workerItem.worker;
    }
    console.error(`acquireWorker: failed`);
    this.workerAccessSemaphore.release();
    return null;
  }

  public releaseWorker(reader: WorkerType): void {
    const workerItem = this.workers.find(item => (item.worker === reader)) ?? null;
    if (workerItem != null) {
      workerItem.unlock();
      // console.log(`releaseWorker: released`, workerItem);
      this.workerAccessSemaphore.release();
    } else {
      console.error(`releaseWorker: failed`);
    }
  }
}

class WorkerPoolItem<WorkerType> {
  // Using a mutex here to make it easy to wait on a specific worker becoming available for use.
  // Other than that, it's just a way to mark that a given worker is currently being used.
  // Typically, it's the worker pool's semaphore that controls access to available workers.
  public mutex = new Mutex();
  constructor(public worker: WorkerType) {}

  public get isLocked(): boolean {
    return this.mutex.isLocked();
  }

  public async lock(): Promise<void> {
    await this.mutex.acquire()
  }

  public unlock(): void {
    this.mutex.release()
  }

  public async waitForUnlock(): Promise<void> {
    if (this.mutex.isLocked()) {
      await this.mutex.waitForUnlock();
    }
  }
}
