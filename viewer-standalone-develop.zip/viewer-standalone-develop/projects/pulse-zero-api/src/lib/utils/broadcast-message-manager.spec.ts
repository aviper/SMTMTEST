import { BroadcastMessageManager } from './broadcast-message-manager';

describe('BroadcastMessageManager', () => {
  it('should create an instance', () => {
    expect(new BroadcastMessageManager()).toBeTruthy();
  });
});
