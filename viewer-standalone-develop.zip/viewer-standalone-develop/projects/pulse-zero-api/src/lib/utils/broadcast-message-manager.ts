import { BroadcastMessageName, IBroadcastMessageBase } from '../models';

// Manages the use of the BroadcastChannel named 'synth-broadcast-channel' for both
// broadcasting events and handling events
export class BroadcastMessageManager {
  private channel = new BroadcastChannel('synth-broadcast-channel');
  private msgHandlers = new Map<string, (msg: any) => void>();

  constructor() {
    this.channel.addEventListener('message', (event) => {
      const msg = event.data as IBroadcastMessageBase;
      if (msg.messageName != null) {
        const handlerFn = this.msgHandlers.get(msg.messageName);
        if (handlerFn != null) {
          console.log(`${this.constructor.name} eventListener`, event);
          handlerFn(event.data);
        }
      }
    });
  }

  public setMessageHandler(msgName: BroadcastMessageName, handlerFn: (msg: any) => void): void {
    this.msgHandlers.set(msgName.toString(), handlerFn);
  }

  public broadcastMessage<MsgType extends IBroadcastMessageBase>(msg: MsgType): void {
    if (!msg.messageName) {
      console.error(`${this.constructor.name} broadcastMessage: no message name`);
      return;
    }
    console.log(`${this.constructor.name} broadcastMessage`, msg);
    this.channel.postMessage(msg);
  }
}
