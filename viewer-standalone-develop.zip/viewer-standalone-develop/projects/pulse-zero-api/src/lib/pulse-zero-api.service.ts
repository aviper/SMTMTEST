import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Mutex } from 'async-mutex';

import { AuthenticationToken, UserId } from '@idgital/vision-auth-interface';
import {
  ExamGroupUser,
  ServerApiService,
  UserCredentials,
  ICachedExamManifest
} from '@server-api';

import {
  BroadcastMessageName,
  CachedExamStats, disableLoggerOverride,
  IDiskInfo,
  IExamDetailInformation,
  IFileInfo,
  IViewerInstanceFocusMessage,
  IViewerSessionUpdateMessage,
  setupLogger
} from './models';
import {
  CacheExamService,
  EncryptionKeyService,
  OpfsCacheService,
  ComputeUtilsService
} from './services';
import {
  BroadcastMessageManager,
  downloadSourcePixelData,
  examDetailToString,
  getAppInstanceID,

} from './utils';
import {
  ComputeWorkerFactoryFn,
  OpfsWorkerFactoryFn,
  extractErrorCodeFromException,
  PerfTiming
} from '@worker-compatible-api';
import { OpfsUtilsService } from './services';


@Injectable({
  providedIn: 'root'
})
export class PulseVisionApiService {
  private _foviaConnectionCount = 0;
  private _foviaConnectionRequestCount = 0;
  private broadcastMessageManager = new BroadcastMessageManager();
  private foviaConnectionMutex: Mutex;
  private deletionMutex: Mutex;
  constructor(
    protected cacheExamService: CacheExamService,
    protected computeUtilsService: ComputeUtilsService,
    protected encryptionKeyService: EncryptionKeyService,
    protected opfsCacheService: OpfsCacheService,
    protected opfsUtilsService: OpfsUtilsService,
    protected serverApi: ServerApiService
  ) {
    console.log(`${this.constructor.name} Starting`);
    this.foviaConnectionMutex = new Mutex();
    this.deletionMutex = new Mutex();
  }

  public async init(isOpfsReadOnly: boolean): Promise<void> {
    const perfTime = new PerfTiming();
    setupLogger();
    console.log(`${this.constructor.name} FoviaConnectionMutexAcquired`);
    await this.encryptionKeyService.init();
    await this.cacheExamService.init();
    await this.foviaConnectionMutex.acquire();
    // This call could take a while, initial read of opfs cache
    this.opfsCacheService.init(isOpfsReadOnly).then();
    console.info(`${this.constructor.name} startupInit complete ${perfTime.elapsedSecondsMessage()} `);
  }

  public async initComputeUtilsService(computeWorkerFactoryFn: ComputeWorkerFactoryFn): Promise<void> {
    return this.computeUtilsService.initWorkerPool(computeWorkerFactoryFn);
  }

  public async initOpfsUtilsService(opfsWorkerFactoryFn: OpfsWorkerFactoryFn, readOnlyAccess: boolean): Promise<void> {
    return this.opfsUtilsService.initWorkerPool(opfsWorkerFactoryFn, readOnlyAccess);
  }

  public get examCount$(): Observable<number> {
    return this.opfsCacheService.examCount$;
  }

  public set userId(value: string) {
    this.opfsCacheService.userId = value;
  }

  public get userId(): string {
    return this.opfsCacheService.userId;
  }

  public set makeCacheSpaceAvailableFn(fn: (requiredSpaceMB: number) => Promise<boolean>) {
    this.cacheExamService.makeCacheSpaceAvailableFn = fn;
  }

  public async setExamGroupUser(value: ExamGroupUser): Promise<void> {
    const keyId: string = value.userId.toString(10);
    const key = await value.getEncryptionKey();
    if (key != null) {
      this.encryptionKeyService.setEncryptionKeyInfo(keyId, key);
    }
  }

  public get userCredentials(): UserCredentials | null {
    return this.serverApi.userCredentials;
  }

  public get cacheQuotaMB(): number {
    return this.opfsCacheService.cacheQuotaMB;
  }

  public set cacheQuotaMB(value: number) {
    this.opfsCacheService.cacheQuotaMB = value;
  }

  public get quotaError$(): Observable<boolean> {
    return this.opfsCacheService.cacheQuotaError$;
  }

  public get hasQuotaError(): boolean {
    return this.opfsCacheService.cacheQuotaError;
  }

  public get cacheUsageMB$(): Observable<number> {
    return this.opfsCacheService.cacheUsageMB$;
  }
  public get cacheUsageMB(): number {
    return this.opfsCacheService.cacheUsageMB;
  }

  public get foviaConnected(): boolean {
    return this.serverApi.foviaConnected;
  }

  public get foviaConnected$(): Observable<boolean | null> {
    return this.serverApi.foviaConnected$;
  }

  public get foviaConnectionCount(): number {
    return this._foviaConnectionCount;
  }

  public get foviaConnectionRequestCount(): number {
    return this._foviaConnectionRequestCount;
  }

  public async foviaInitCompleted(): Promise<void> {
    try {
      if (this.foviaConnectionMutex.isLocked()) {
        console.log(`${this.constructor.name} WAITING FOR FOVIA CONNECTION TO COMPLETE ...`);
        await this.foviaConnectionMutex.waitForUnlock();
        console.log(`${this.constructor.name} ... FOVIA CONNECTION COMPLETE ${this.foviaConnected}`);
      }
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} Error connecting to fovia ${errCode}`);
      console.info(`${this.constructor.name} Error connecting to fovia ${errCode}`, err);
    } finally {
    }
  }

  public async foviaInit(host: URL): Promise<boolean> {
    // console.log(`${this.constructor.name} foviaInit Starting connection to fovia at ${host}`);
    if (!this.foviaConnectionMutex.isLocked()) {
      // not already waiting
      // console.log(`${this.constructor.name} foviaInit Getting the mutex for connection to fovia at ${host}`);
      await this.foviaConnectionMutex.acquire();
    }
    try {
      console.log(`${this.constructor.name} foviaInit Requesting connection to fovia at ${host} ${this._foviaConnectionCount}`);
      this._foviaConnectionRequestCount++;
      // await this.serverApi.connect(host);
      // TEMP TEMP - use time out until fovia fixes their calls to return error code.
      await this.serverApi.connectWithTimeout(host);
      this._foviaConnectionCount++;
      console.log(`${this.constructor.name} foviaInit Connection complete to fovia at ${host} ${this._foviaConnectionRequestCount}/${this._foviaConnectionCount}`);
      this.foviaConnectionMutex.release();
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} foviaInit Error connecting to fovia ${errCode} ${this._foviaConnectionRequestCount}/${this._foviaConnectionCount}`, err);
    }
    return this.serverApi.foviaConnected;
  }

  public invalidateUserCredentials(): void {
    this.opfsCacheService.userId = '';
    disableLoggerOverride();
    this.serverApi.invalidateUserCredentials();
  }

  public updateUserCredentials(userId: UserId, userAuthToken: AuthenticationToken): void {
    const userIdStr = userId.toString();
    if (userIdStr !== this.opfsCacheService.userId) {
      this.opfsCacheService.userId = userIdStr;
      disableLoggerOverride();  // disable logging override because we don't know here if this is an internal user
    }
    this.serverApi.updateUserCredentials(userId, userAuthToken);
  }

  public async addExamToCache(examDetailInfo: IExamDetailInformation): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        // Initial connection- and later reconnections will wait
        if (!this.foviaConnected) {
          await this.foviaInitCompleted();
        }
        if (!this.foviaConnected) {
          console.error(`${this.constructor.name} addExamToCache ${examDetailInfo.examInfo.studyUID} ${examDetailToString(examDetailInfo)} must have an active fovia connection`);
          return resolve(this.foviaConnected);
        }
        // See if the exam already exists for some other user
        const studyUID = examDetailInfo.examInfo.studyUID;
        // Invalid StudyUID?
        if (studyUID == null || studyUID.length === 0) {
          console.error(`${this.constructor.name} addExamToCache ${examDetailToString(examDetailInfo)} unexpected condition instanceUID is null or empty`);
          return resolve(result);
        }
        await this.deletionComplete(); // ensure any pending deletions are allowed to complete
        const bStudyExists = await this.opfsCacheService.studyExists(studyUID);
        if (bStudyExists) {
          const bSameUser = this.opfsCacheService.studyExistsForCurrentUser(studyUID);
          if (!bSameUser) {
            // Existing study isn't for this user, delete it before we cache it again
            result = await this.deleteExamFromCache(studyUID);
            const message = `${this.constructor.name} addExamToCache deletion of other user's exam ${studyUID} from cache ${result ? 'succeeded' : 'failed'}`;
            if (!result) {
              console.error(message);
              return resolve(result);
            }
            console.log(message);
          }
        }
        // Make sure this user's info is being used for encryption
        await this.setExamGroupUser(examDetailInfo.examGroup.user);
        // Abort caching?
        if (this.cachingPaused || this.opfsCacheService.cacheQuotaError) {
          // Let exam cache management restart caching
          console.info(`${this.constructor.name} addExamToCache stop caching ${examDetailInfo.examInfo.studyUID} Paused:${this.cachingPaused} quota:${this.opfsCacheService.cacheQuotaError}`);
          return resolve(result);
        }

        result = await this.cacheExamService.addExamToCache(examDetailInfo);
        examDetailInfo.cached = result;
        console.log(`${this.constructor.name} addExamToCache ${studyUID} results ${result} ${examDetailToString(examDetailInfo)}`);
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name} addExamToCache ${examDetailInfo.examInfo.studyUID} ${examDetailToString(examDetailInfo)} exception ${errCode}`, err);
      }
      return resolve(result);
    });
  }

  public async stopCaching(): Promise<void> {
    return this.cacheExamService.stopCaching();
  }

  public async resumeCaching(): Promise<void> {
    await this.deletionComplete();
    console.log(`${this.constructor.name} resumeCaching`);
    return this.cacheExamService.resumeCaching();
  }

  public get cachingPaused(): boolean {
    return this.cacheExamService.isCachingPaused();
  }

  public clearExamsFromCache(): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        this.cacheExamService.clearExams();
        result = await this.opfsCacheService.clearExamCache();
      }
      catch (err) {
        console.error(`${this.constructor.name} clearExamsFromCache exception ${err}`, err);
      }
      return resolve(result);
    });
  }

  public async deleteExamsFromCache(studyUIDs: string[]): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        for (const studyUID of studyUIDs) {
          result = result && await this.deleteExamFromCache(studyUID);
        }
      }
      catch (err) {
        console.error(`${this.constructor.name} deleteExamsFromCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async deleteExamFromCache(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      this.deletionMutex.acquire();
      let result = false;
      try {
        console.info(`${this.constructor.name} deleteExamFromCache ${studyUID}...`);
        this.cacheExamService.deleteExam(studyUID);
        result = await this.opfsCacheService.removeStudyFromCache(studyUID);
        console.info(`${this.constructor.name} deleteExamFromCache ${studyUID} completed result: ${result}`);
      }
      catch (err) {
        console.error(`${this.constructor.name} deleteExamFromCache caught exception ${err}`);
      }
      this.deletionMutex.release();
      return resolve(result);
    });
  }

  public async getCachedExamStats(studyUID: string): Promise<CachedExamStats | null> {
    return new Promise(async (resolve) => {
      let result: CachedExamStats | null = null;
      try {
        result = await this.opfsCacheService.getCacheExamStats(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} getCachedExamStats caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public getDiskInfo$(): Observable<IDiskInfo> {
    return this.opfsCacheService.diskSpaceInfo$;
  }

  public async publishDiskInfo(): Promise<void> {
    return new Promise(async (resolve) => {
      try {
        await this.opfsCacheService.publishDiskSpaceInfo();
      }
      catch (err) {
        console.error(`${this.constructor.name} publishDiskInfo caught exception ${err}`);
      }
      return resolve();
    });
  }

  public async getImageFromFileCache(studyUID: string,
    seriesUID: string,
    imageUID: string,
    frameNumber: number): Promise<IFileInfo | null> {
    return new Promise(async (resolve) => {
      let result: IFileInfo | null = null;
      try {
        result = await this.opfsCacheService.getImageFromFileCache(studyUID, seriesUID, imageUID, frameNumber);
      }
      catch (err) {
        console.error(`${this.constructor.name} getImageFromFileCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async imageFileExists(studyUID: string,
    seriesUID: string,
    imageUID: string,
    frameNumber: number): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.imageFileExists(studyUID, seriesUID, imageUID, frameNumber);
      }
      catch (err) {
        console.error(`${this.constructor.name} imageFileExists caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async examVersionFileExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.examVersionFileExists(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} examVersionFileExists caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async getExamVersionFromFileCache(studyUID: string): Promise<string | null> {
    return new Promise(async (resolve) => {
      let result: any | null = null;

      try {
        result = await this.opfsCacheService.getExamVersionFromFileCache(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} getExamVersionFromFileCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async getExamDicomTagsFromFileCache(studyUID: string): Promise<any | null> {
    return new Promise(async (resolve) => {
      let result: any | null = null;

      try{
        result = await this.opfsCacheService.getDicomTagsFromFileCache(studyUID);
      } catch (err) {
        console.error(`${this.constructor.name} getExamDicomTagsFromFileCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async dicomTagsFileExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.dicomTagsFileExist(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} dicomTagsFileExists caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async getExamManifestFromFileCache(studyUID: string): Promise<ICachedExamManifest | null> {
    return new Promise(async (resolve) => {
      let result: ICachedExamManifest | null = null;

      try {
        result = await this.opfsCacheService.getExamManifestFromFileCache(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} getExamManifestFromFileCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async manifestFileExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.manifestFileExists(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} manifestFileExists caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async getStudyUIDsInCache(): Promise<string[]> {
    return new Promise(async (resolve) => {
      let result: string[] = [];
      try {
        result = await this.opfsCacheService.getCachedStudyUIDs();
      }
      catch (err) {
        console.error(`${this.constructor.name} getStudyUIDsInCache caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async getExamSubDirectoryNames(studyUID: string): Promise<string[]> {
    return new Promise(async (resolve) => {
      let result: string[] = [];
      try {
        result = await this.opfsCacheService.getExamSubDirectoryNames(studyUID);
      }
      catch (err) {
        console.error(`${this.constructor.name} getExamSubDirectoryNames caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async storagePersisted(): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.storagePersisted();
      }
      catch (err) {
        console.error(`${this.constructor.name} storagePersisted caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  public async storagePersist(): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      try {
        result = await this.opfsCacheService.storagePersist();

      }
      catch (err) {
        console.error(`${this.constructor.name} storagePersist caught exception ${err}`);
      }
      return resolve(result);
    });
  }

  // NOTE: This method should be called in development only to support testing the apps behavior when OPFS is evicted
  public async simulateOpfsEviction(): Promise<void> {
    return new Promise(async (resolve) => {
      this.opfsCacheService.simulateOpfsEviction();
      return resolve();
    });
  }

  public async initComplete(): Promise<void> {
    return new Promise(async (resolve) => {
      try {
        await this.opfsCacheService.initComplete();
      }
      catch (err) {
        console.error(`${this.constructor.name} initComplete caught exception ${err}`);
      }
      return resolve();
    });
  }

  // Called by Viewer instance to report a change to the set of exams in the viewer session
  public broadcastViewerSessionUpdate(primaryStudyUID: string, comparisonStudyUIDs: string[], internalUserId: number | null): void {
    const msg: IViewerSessionUpdateMessage = {
      messageName: BroadcastMessageName.viewerSessionUpdate,
      viewerInstanceID: getAppInstanceID(),
      primaryStudyUID: primaryStudyUID,
      comparisonStudyUIDs: comparisonStudyUIDs,
      internalUserId: internalUserId
    };
    this.broadcastMessageManager.broadcastMessage(msg);
  }

  // Called by PulseVision to react to viewer session updates
  public registerViewerSessionUpdateHandler(handlerFn: (viewerSessionUpdateMessage: IViewerSessionUpdateMessage) => void): void {
    this.broadcastMessageManager.setMessageHandler(BroadcastMessageName.viewerSessionUpdate, (msg) => {
      handlerFn(msg as IViewerSessionUpdateMessage);
    });
  }

  public get opfsEvictionDetectionCount$(): Observable<number> {
    return this.opfsCacheService.opfsEvictionDetectionCount$;
  }

  // Called by viewer instance when it takes focus (ie, becomes active)
  public broadcastViewerFocusUpdate(): void {
    const msg: IViewerInstanceFocusMessage = {
      messageName: BroadcastMessageName.viewerFocusUpdate,
      viewerInstanceID: getAppInstanceID(),
    };
    this.broadcastMessageManager.broadcastMessage(msg);
  }

  // Called by PulseVision to react to a viewer getting focus
  public registerViewerFocusUpdateHandler(handlerFn: (viewerInstanceFocusMessage: IViewerInstanceFocusMessage) => void): void {
    this.broadcastMessageManager.setMessageHandler(BroadcastMessageName.viewerFocusUpdate, (msg) => {
      handlerFn(msg as IViewerInstanceFocusMessage);
    });
  }

  public async downloadSourcePixelData(studyInstanceUID: string,
    seriesInstanceUID: string,
    subSeriesID: number,
    imageInstanceUID: string,
    imageNumber: number,
    frameNumber: number,
    imagePixelsByteCount: number
  ): Promise<any> {
    return downloadSourcePixelData(studyInstanceUID, seriesInstanceUID, subSeriesID, imageInstanceUID, imageNumber, frameNumber, imagePixelsByteCount, this.computeUtilsService);
  }

  public clearOpfsHandlesForStudyUID(studyUID: string) {
    this.opfsCacheService.clearOpfsHandlesForStudyUID(studyUID);
  }
  protected async deletionComplete(): Promise<void> {
    // Ensure that in-progress deletion operations are allowed to complete before OPFS operations continue
    if (this.deletionMutex.isLocked()) {
      await this.deletionMutex.waitForUnlock();
    }
  }
}
