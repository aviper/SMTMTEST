import { Injectable } from '@angular/core';

export interface IKeyIdPair {
  keyId: string;
  key: CryptoKey | null;
  toString(): string;
}

class KeyIdPair implements IKeyIdPair {
  constructor(
    public keyId: string,
    public key: CryptoKey | null
  ) {}
  public toString(): string {
    return `keyId: '${this.keyId}' key: ${this.key}`;
  }
}
// Track the current user's encryption key and keyId.
@Injectable({
  providedIn: 'root'
})
export class EncryptionKeyService {
  private keyIdPair: KeyIdPair;
  private keyCount = 0;
  constructor() {
    this.keyIdPair = new KeyIdPair('', null);
  }

  public async init(): Promise<void> {
    // provide initial key -- which would be bogus to use, until a real key is provided for this user
    try {
      const key = await this.generateCryptoKey();
      this.keyIdPair.key = key;
      console.log(`${this.constructor.name} ${this.keyIdPair.toString()}`, this.keyIdPair);
     }
    catch (err) {
      console.error(`${this.constructor.name} initial value for cryptoKey failed with exception:`, err);
    }

  }
  public setEncryptionKeyInfo(id: string, key: CryptoKey): void {
    if (this.keyCount > 0) {
      // ability to reliably encrypt/decrypt objects for this user relies on the encryption key not changing.
      // Raise an error if we find this condition.
      if (this.keyIdPair.keyId !== id) {
        console.error(`${this.constructor.name} setEncryptionKeyInfo changing a user's id is undexpected.`);
      }
      if (this.keyIdPair.key !== key) {
        console.error(`${this.constructor.name} setEncryptionKeyInfo changing a user's encrcyption key may prevent reliable decryption`);
      }
    }
    if (key == null) {
      console.error(`${this.constructor.name} setEncryptionKey SERIOUS ERROR encryption key may not be null` );
      return;
    }
    this.keyIdPair = new KeyIdPair(id, key);
    console.log(`${this.constructor.name} setEncryptionKeyInfo ${this.keyIdPair.toString()}`, this.keyIdPair);
  }

  public async getKeyForDecryption(keyId: string, studyUID: string): Promise<CryptoKey | null> {
    if (keyId !== this.keyIdPair.keyId) {
      console.error(`${this.constructor.name} getKeyForDecryption invalid keyId ${keyId} for ${studyUID}`);
      return null;
    }
    // console.log(`${this.constructor.name} getKeyForDecryption ${this.keyIdPair.toString()}`, this.keyIdPair);
    return this.keyIdPair.key;
  }

  public async getKeyForEncryption(studyUID: string): Promise<IKeyIdPair> {
   return this.keyIdPair;
  }

  protected async generateCryptoKey(): Promise<CryptoKey> {
    return window.crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256, // can be  128, 192, or 256
      },
      false, // whether the key is extractable (i.e. can be used in exportKey)
      ['encrypt', 'decrypt'] // can "encrypt", "decrypt", "wrapKey", or "unwrapKey"
    );
  }

}
