import { TestBed } from '@angular/core/testing';

import { OpfsCacheService } from './opfs-cache.service';

describe('OpfsCacheService', () => {
  let service: OpfsCacheService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpfsCacheService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
