import { Injectable } from '@angular/core';
import {
  calcAutoWindowLevel,
  IComputeWorker,
  ComputeWorkerFactoryFn,
  compressArrayBuffer,
  decompressArrayBuffer,
  encryptArrayBuffer,
  decryptArrayBuffer,
  ImagePerfAggregator,
  IWindowLevelRequest,
  IWindowLevelResponse,
  PerfMeasure
} from '@worker-compatible-api';
import { computeWorkerPoolSemaphore, computeWorkerPoolSize, WorkerPool } from '../utils';
import * as Comlink from 'comlink';

class ComputeWorkerPool extends WorkerPool<IComputeWorker> {}

// Provide a way to turn on /off web workers from browser console
let _computeWebWorkersEnabled = true;
function _enableComputeWebWorkers(enable: boolean) {
  _computeWebWorkersEnabled = enable;
  console.warn(`enableComputeWebWorkers: called with enable=${enable} `);
}
function _getComputeWebWorkersEnabled(): boolean {
  console.warn(`getComputeWebWorkersEnabled: returns ${_computeWebWorkersEnabled} `);
  return _computeWebWorkersEnabled;
}
(window as any).enableComputeWebWorkers = _enableComputeWebWorkers;
(window as any).getComputeWebWorkersEnabled = _getComputeWebWorkersEnabled;

@Injectable({
  providedIn: 'root'
})
export class ComputeUtilsService {
  protected workerPool: ComputeWorkerPool | null = null;
  public decryptPerfAggregator = new ImagePerfAggregator();
  public encryptPerfAggregator = new ImagePerfAggregator();
  public decompressPerfAggregator = new ImagePerfAggregator();
  public compressePerfAggregator = new ImagePerfAggregator();
  public autoWindowLevelAggregator = new ImagePerfAggregator();

  constructor() { }

  public async initWorkerPool(factoryFn: ComputeWorkerFactoryFn): Promise<void> {
    if (this.workerPool != null) {
      return;
    }
    this.workerPool = new ComputeWorkerPool('computeWorker', factoryFn, computeWorkerPoolSize, computeWorkerPoolSemaphore);
    await this.workerPool.init();
    console.log(`ComputeUtilsService.initWorkerPool:  poolSize = ${computeWorkerPoolSize}`);
  }

  public get canUseWorker(): boolean {
    return this.workerPool != null && _computeWebWorkersEnabled;
  }

  public async autoWindowlevel(request: IWindowLevelRequest): Promise<IWindowLevelResponse | null> {
    this.autoWindowLevelAggregator.perfDetails.usingWorkers = this.canUseWorker;
    const perf = new PerfMeasure(this.canUseWorker ? 'autoWindowLevel-worker' : 'autoWindowLevel-main');
    perf.start();
    const wlResult =  (this.canUseWorker)
      ? await this.autoWindowLevelWithWorker(request)
      : await calcAutoWindowLevel(request);
    const details = this.autoWindowLevelAggregator.addEvent(perf, wlResult ? 1 : 0);
    perf.end(details);
    return wlResult;
  }
  public async autoWindowLevelWithWorker(request: IWindowLevelRequest): Promise<IWindowLevelResponse | null> {
    if (this.workerPool == null) {
      console.error(`autoWindowLevelWithWorker: failed - no worker pool`);
      return null;
    }

    const tBeforeAcquire = performance.now();
    console.info(
      `Image ${request.sopInstanceUID}: requesting worker (pool size: ${this.workerPool.workers.length})`
    );

    const worker = await this.workerPool.acquireWorker();
    const tAfterAcquire = performance.now();

    const workerIndex = this.workerPool.workers.findIndex(w => w.worker === worker);
    console.info(
      `Image ${request.sopInstanceUID}: acquired worker #${workerIndex}, wait = ${(tAfterAcquire - tBeforeAcquire).toFixed(2)} ms`
    );

    if (worker == null) {
      console.error(`autoWindowLevelWithWorker: failed - no worker acquired`);
      return null;
    }

    const tStartProcessing = performance.now();
    let wlResult: IWindowLevelResponse | null = null;
    try {
      wlResult = await worker.calculateAutoWindowLevel(Comlink.transfer(request, [request.pixelData]));
    } catch (error: unknown) {
      console.error(`ComputeUtilsService.autoWindowLevelWithWorker: caught exception`, error);
    }
    const tEndProcessing = performance.now();

    console.info(
      `Image ${request.sopInstanceUID}: worker #${workerIndex} processing = ${(tEndProcessing - tStartProcessing).toFixed(2)} ms, releasing...`
    );

    this.workerPool.releaseWorker(worker);
    return wlResult;
  }
  public async decryptArrayBuffer(encryptedBuffer: ArrayBuffer, // WARNING: If a worker is used here, the caller will lose access to this buffer
                                  key: CryptoKey | null,
                                  iv: Uint8Array<ArrayBuffer>): Promise<ArrayBuffer | null> {
    this.decryptPerfAggregator.perfDetails.usingWorkers = this.canUseWorker;
    const perf = new PerfMeasure(this.canUseWorker ? 'decryptArrayBuffer-worker' : 'decryptArrayBuffer-main');
    perf.start();
    const decryptedBuf =  (this.canUseWorker)
        ? await this.decryptArrayBufferWithWorker(encryptedBuffer, key, iv.buffer)
        : await decryptArrayBuffer(encryptedBuffer, key, iv);
    const details = this.decryptPerfAggregator.addEvent(perf, decryptedBuf?.byteLength ?? 0);
    perf.end(details);
    return decryptedBuf;
  }

  public async decryptArrayBufferWithWorker(encryptedBuffer: ArrayBuffer, // WARNING: the caller will lose access to this buffer
                                            key: CryptoKey | null,
                                            iv: ArrayBuffer): Promise<ArrayBuffer | null> {
    if (this.workerPool == null) {
      console.error(`decryptArrayBufferWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`decryptArrayBufferWithWorker: failed - no file reader`);
      return null;
    }

    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.decryptArrayBuffer( Comlink.transfer(encryptedBuffer, [encryptedBuffer]), key, iv);
      if (arrayBuf.byteLength === 0) {
        arrayBuf = null;
      }
    } catch (error: unknown) {
      console.error(`ComputeUtilsService.decryptArrayBufferWithWorker: caught exception`);
    }

    this.workerPool.releaseWorker(worker);
    // console.log(`decryptArrayBufferWithWorker: decryptedByteCount=${arrayBuf?.byteLength}`);
    return arrayBuf;
  }

  public async encryptArrayBuffer(unencryptedBuffer: ArrayBuffer, // WARNING: If a worker is used here, the caller will lose access to this buffer
                                  key: CryptoKey | null,
                                  iv: Uint8Array<ArrayBuffer>): Promise<ArrayBuffer | null> {
    this.encryptPerfAggregator.perfDetails.usingWorkers = this.canUseWorker;
    const perf = new PerfMeasure(this.canUseWorker ? 'encryptArrayBuffer-worker' : 'encryptArrayBuffer-main');
    perf.start();
    const encryptedBuf = (this.canUseWorker)
      ? await this.encryptArrayBufferWithWorker(unencryptedBuffer, key, iv.buffer)
      : await encryptArrayBuffer(unencryptedBuffer, key, iv);
    const details = this.encryptPerfAggregator.addEvent(perf, encryptedBuf?.byteLength ?? 0);
    perf.end(details);
    return encryptedBuf;
  }

  public async encryptArrayBufferWithWorker(unencryptedBuffer: ArrayBuffer,  // WARNING: the caller will lose access to this buffer
                                            key: CryptoKey | null,
                                            iv: ArrayBuffer): Promise<ArrayBuffer | null> {
    if (this.workerPool == null) {
      console.error(`encryptArrayBufferWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`encryptArrayBufferWithWorker: failed - no file reader`);
      return null;
    }

    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.encryptArrayBuffer(Comlink.transfer(unencryptedBuffer, [unencryptedBuffer]), key, iv);
      if (arrayBuf.byteLength === 0) {
        arrayBuf = null;
      }
    } catch (error: unknown) {
      console.error(`ComputeUtilsService.encryptArrayBufferWithWorker: caught exception`);
    }

    this.workerPool.releaseWorker(worker);
    // console.log(`encryptArrayBufferWithWorker: encryptedByteCount=${arrayBuf?.byteLength}`);
    return arrayBuf;
  }

  public async compressArrayBuffer(arr: ArrayBuffer, format: CompressionFormat): Promise<ArrayBuffer | null> {
    this.compressePerfAggregator.perfDetails.usingWorkers = this.canUseWorker;
    const perf = new PerfMeasure(this.canUseWorker ? 'compressArrayBuffer-worker' : 'compressArrayBuffer-main');
    perf.start();
    const compressedBuf = (this.canUseWorker)
      ? await this.compressArrayBufferWithWorker(arr, format)
      : await compressArrayBuffer(arr, format);
    const details = this.compressePerfAggregator.addEvent(perf, compressedBuf?.byteLength ?? 0);
    perf.end(details);
    return compressedBuf;
  }

  public async compressArrayBufferWithWorker(arr: ArrayBuffer, format: CompressionFormat): Promise<ArrayBuffer | null> {
    if (this.workerPool == null) {
      console.error(`compressArrayBufferWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`compressArrayBufferWithWorker: failed - no file reader`);
      return null;
    }

    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.compressArrayBuffer(Comlink.transfer(arr, [arr]), format);
      if (arrayBuf.byteLength === 0) {
        arrayBuf = null;
      }
    } catch (error: unknown) {
      console.error(`ComputeUtilsService.compressArrayBufferWithWorker: caught exception`);
    }

    this.workerPool.releaseWorker(worker);
    // console.log(`compressArrayBufferWithWorker: compressedByteCount=${arrayBuf?.byteLength}`);
    return arrayBuf;
  }

  public async decompressArrayBuffer(arr: ArrayBuffer, format: CompressionFormat = 'deflate'): Promise<ArrayBuffer | null> {
    this.decompressPerfAggregator.perfDetails.usingWorkers = this.canUseWorker;
    const perf = new PerfMeasure(this.canUseWorker ? 'decompressArrayBuffer-worker' : 'decompressArrayBuffer-main');
    perf.start();
    const decompressedBuf = (this.canUseWorker)
      ? await this.decompressArrayBufferWithWorker(arr, format)
      : await decompressArrayBuffer(arr, format);
    const details = this.compressePerfAggregator.addEvent(perf, decompressedBuf?.byteLength ?? 0);
    perf.end(details);
    return decompressedBuf;
  }

  public async decompressArrayBufferWithWorker(arr: ArrayBuffer, format: CompressionFormat = 'deflate'): Promise<ArrayBuffer | null> {
    if (this.workerPool == null) {
      console.error(`decompressArrayBufferWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`decompressArrayBufferWithWorker: failed - no file reader`);
      return null;
    }

    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.decompressArrayBuffer(Comlink.transfer(arr, [arr]), format);
      if (arrayBuf.byteLength === 0) {
        arrayBuf = null;
      }
    } catch (error: unknown) {
      console.error(`ComputeUtilsService.decompressArrayBufferWithWorker: caught exception`);
    }
    this.workerPool.releaseWorker(worker);
    // console.log(`decompressArrayBufferWithWorker: compressedByteCount=${arrayBuf?.byteLength}`);
    return arrayBuf;
  }

}
