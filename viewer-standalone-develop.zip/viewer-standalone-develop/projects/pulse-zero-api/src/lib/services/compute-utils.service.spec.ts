import { TestBed } from '@angular/core/testing';

import { ComputeUtilsService } from './compute-utils.service';

describe('ComputeUtilsService', () => {
  let service: ComputeUtilsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComputeUtilsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
