import { TestBed } from '@angular/core/testing';

import { OpfsUtilsService } from './opfs-utils.service';

describe('OpfsUtilsService', () => {
  let service: OpfsUtilsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpfsUtilsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
