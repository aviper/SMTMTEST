import { Injectable, NgZone } from '@angular/core';
import { Mutex, Semaphore } from 'async-mutex';
import Fovia from 'foviaapi';

import {
  calcMiddleImage,
  estimateOpfsMBytesForFoviaExam,
  ExamGroupRules,
  ExamLoadContext,
  ExamLoadStatus,
  calcImagePixelsByteCountFromTags,
  LogSupport,
  makeImageKey,
  promiseTimeout,
  ServerApiService,
  setFoviaBufferDataType,
  IFoviaStudySRData,
  IFoviaSeriesSRData,
  FOVIA_SR_PRESENTATION_SCHEMA_VERSION
} from '@server-api';

import {
  extractErrorCodeFromException,
  PerfMeasure,
  PerfTiming,
  PV_ERRORS,
} from "@worker-compatible-api";
import { ComputeUtilsService } from './compute-utils.service';
import { OpfsCacheService } from './opfs-cache.service';
import { CachedExamStats, CachingStatusDetail, IMinMax, MissingImageInfo, NO_IMAGE_DATA, StudyStatus, TICKS_PER_SEC } from '../models';
import {
  examDetailToString,
  downloadSourcePixelData
} from '../utils';
import { IExamDetailInformation } from '../models';

export enum CACHED_IMAGE_STATUS { NOT_CACHED = 0, LOAD_TIMEOUT, LOAD_ERROR, MANIFEST_ERROR, PARTIALLY_CACHED, COMPLETELY_CACHED, CACHED_WITH_ERRORS }

// We use a counting semaphore to control the number of simultaneous activites we support
// Thse numbers may need to be tuned.
const MAX_CONCURRENT_IMAGES = 12; // Total number of outstanding pixel reading requests across all exams
const MAX_CONCURRENT_STUDY_LOADING = 1; // Total number of outstanding study loading request across all exams
const MAX_CONCURRENT_PIXEL_REQUESTS = 2; // Total number of oustanding fovia pixel load requests

// Provide active caching support for one exam at a time

@Injectable({
  providedIn: 'root'
})
export class CacheExamService {
  private loadedExams = new Map<string, CacheExam>();
  private cachingMutex: Mutex;
  private studyLoadingSemaphore: Semaphore;
  private imageLoadingSemaphore: Semaphore;
  private maxPixelRequestSemaphore: Semaphore;
  private currentExam: CacheExam | null;
  private _makeCacheSpaceAvailableFn: ((requiredSpace: number) => Promise<boolean>) | null = null;

  constructor(
    public opfsFileCache: OpfsCacheService,
    protected foviaServiceApi: ServerApiService,
    protected computeUtilsService: ComputeUtilsService,
    protected ngZone: NgZone
  ) {
    this.cachingMutex = new Mutex();
    this.currentExam = null;

    this.studyLoadingSemaphore = new Semaphore(MAX_CONCURRENT_STUDY_LOADING);
    this.imageLoadingSemaphore = new Semaphore(MAX_CONCURRENT_IMAGES);
    this.maxPixelRequestSemaphore = new Semaphore(MAX_CONCURRENT_PIXEL_REQUESTS);
  }

  public async init(): Promise<void> {
    // Cache as long as we hold the mutex
    await this.cachingMutex.acquire();
  }

  public set makeCacheSpaceAvailableFn(fn: (requiredSpace: number) => Promise<boolean>) {
    this._makeCacheSpaceAvailableFn = fn;
  }

  public async makeCacheSpaceAvailable(requiredSpace: number): Promise<boolean> {
    if (this._makeCacheSpaceAvailableFn == null) {
      console.error(`makeCacheSpaceAvailable: function is null`);
      return false;
    }
    return this._makeCacheSpaceAvailableFn(requiredSpace);
  }

  protected async getExam(examDetails: IExamDetailInformation): Promise<CacheExam> {
    return new Promise(async (resolve) => {
      const studyInstanceUID = examDetails.examInfo.studyUID;
      let exam = this.loadedExams.get(studyInstanceUID);
      if (exam == null) {
        exam = new CacheExam(this.opfsFileCache, this.foviaServiceApi, this.computeUtilsService, examDetails,
          this.cachingMutex, this.studyLoadingSemaphore, this.imageLoadingSemaphore, this.maxPixelRequestSemaphore, this.makeCacheSpaceAvailable.bind(this));
        await exam.init();
        console.info(`${this.constructor.name} Creating new exam ${examDetailToString(examDetails)}`);
        this.loadedExams.set(studyInstanceUID, exam);
      }
      return resolve(exam);
    });
  }

  public async addExamToCache(examDetails: IExamDetailInformation): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      result = await this.ngZone.runOutsideAngular(async (): Promise<boolean> => {
        try {

          const exam = await this.createExam(examDetails);
          if (exam == null) {
            return result;
          }
          // console.log(`${this.constructor.name} addExamToCach createExam ${examDetails.examInfo.studyUID}`, exam);
          this.currentExam = exam;
          console.info(`${this.constructor.name} addExamToCache starts caching ${exam.studyInstanceUID}`);
          const cacheStatus = await exam.cacheEntireExam();
          console.info(`${this.constructor.name} addExamToCache ends caching ${CACHED_IMAGE_STATUS[cacheStatus]} ${exam.studyInstanceUID} next step: '${exam.examDetail.examCacheStatus?.studyStatus}'`);

          result = !exam.hasQuotaError;
          this.currentExam = null;
        } catch (err) {
          const errCode = extractErrorCodeFromException(err);
          console.log(`${this.constructor.name} addExamToCache exception ${errCode}`, err);
          console.error(`${this.constructor.name} addExamToCache exception ${errCode}`);
        }
        return result;
      });
      return resolve(result);
    });
  }

  protected async createExam(examDetails: IExamDetailInformation): Promise<CacheExam | null> {
    return new Promise(async (resolve) => {

      const studyInstanceUID = examDetails.examInfo.studyUID;
      if (studyInstanceUID.length === 0) {
        console.error(`${this.constructor.name} createExam studyInstanceUID is empty`);
        return resolve(null);
      }
      // Get the target exam object
      const exam = await this.getExam(examDetails);
      if (exam == null) {
        console.error(`${this.constructor.name} createExam ${studyInstanceUID} returning, exam is null`);
      }
      return resolve(exam);
    });
  }

  public clearExams(): void {
    this.loadedExams.clear();
    this.currentExam = null;
  }

  // Caching may be paused & resumed using this caching mutex
  // We're not considered fully paused until any study that is
  // actively caching has stopped caching.
  public async stopCaching(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.ngZone.runOutsideAngular(async (): Promise<void> => {
        if (!this.isCachingPaused()) {
          this.cachingMutex.release();
          await this.cachingMutex.waitForUnlock();
          // If we're currently caching
          const exam = this.currentExam;
          if (exam != null) {
            await exam.cachingHasStopped();
            console.info(`${this.constructor.name} +++ stopCaching - caching has stopped for exam ${exam.studyInstanceUID}`);
          }
        }
      });
      return resolve();
    });
  }

  public hasStoppedCaching(): boolean {
    if (!this.isCachingPaused()) {
      return false;
    }
    if (this.currentExam == null) {
      return true;
    }
    if (this.currentExam.stoppedCaching()) {
      return true;
    }
    return false;
  }
  public async resumeCaching(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.ngZone.runOutsideAngular(async (): Promise<void> => {
        if (this.isCachingPaused()) {
          await this.cachingMutex.acquire();
        }
        console.log(`${this.constructor.name} +++ resumeCaching completes isCachingPaused ${this.isCachingPaused()}`);
      });
      return resolve();
    });
  }

  public isCachingPaused(): boolean {
    return !this.cachingMutex.isLocked();
  }

  public deleteExam(studyInstanceUID: string): void {
    const cachedExam = this.loadedExams.get(studyInstanceUID);
    if (cachedExam != null) {
      this.loadedExams.delete(studyInstanceUID);
    }
  }

  public async getLoadedExam(studyInstanceUID: string): Promise<CacheExam | null> {
    return new Promise(async (resolve) => {
      const cachedExam = this.loadedExams.get(studyInstanceUID);
      return resolve(cachedExam ?? null);
    });
  }

  private async unloadExam(studyInstanceUID: string): Promise<void> {
    return new Promise(async (resolve) => {
      await this.ngZone.runOutsideAngular(async (): Promise<void> => {
        const exam = this.loadedExams.get(studyInstanceUID);
        if (exam) {
          await exam.unloadStudy();
          this.loadedExams.delete(exam.studyInstanceUID);
        } else {
          console.error(`${this.constructor.name} unloadExam - Unknown study instance UID ${studyInstanceUID}`);
        }
      });
      return resolve();
    });
  }

  private async unloadExams(): Promise<void[]> {
    return new Promise(async (resolve) => {
      const unloadOperations = new Array<Promise<void>>();
      for (const studyInstanceUID of this.loadedExams.keys()) {
        const examUnloaded = this.unloadExam(studyInstanceUID);
        if (examUnloaded != null) {
          unloadOperations.push(examUnloaded);
        }
      }
      return resolve(Promise.all(unloadOperations));
    });
  }

  private async unloadAllExams(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.unloadExams();
      return resolve();
    });
  }

  public async stopProcessing(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.unloadAllExams();
      return resolve();
    });
  }

  public ngOnDestroy(): void {
    this.stopProcessing().then();
  }

}

// --------------------------
interface ImageInfo {
  sdc: Fovia.SeriesDataContext;
  imageNum: number;
  cacheStatus: number;
  success: boolean;
  index: number;
  retryCount: number;
}


const NO_SUCCESS = false;
const SUCCESS = true;

class CacheExam {

  public readonly studyInstanceUID: string;
  public cacheTimingStatus: CachedExamStats = new CachedExamStats('');
  protected cacheImageStatus: CACHED_IMAGE_STATUS = CACHED_IMAGE_STATUS.NOT_CACHED;
  protected cachingStoppedMutex: Mutex;
  protected currentCacheStep = 0;
  protected _currentStatusDetail: CachingStatusDetail = new CachingStatusDetail(StudyStatus.eNEW);
  protected readonly examCacheOrder: StudyStatus[] = [];
  protected examRules: ExamGroupRules;
  protected examLoadContext: ExamLoadContext | null = null;
  protected foviaExam: Fovia.ScanDirSeriesResults[] = [];
  protected foviaExamSRData: IFoviaStudySRData | null = null;
  protected initMutex: Mutex;
  protected initComplete = false;
  protected imageCacheList: ImageInfo[] = [];
  protected imageProcessedList: ImageInfo[] = [];
  protected missingImages = new MissingImageInfo();
  protected readonly studyStatusMap: Map<StudyStatus, CachingStatusDetail>;
  protected totalImagesInExam = 0;
  protected CACHED_STEP = 0;
  protected LOADING_STEP = 0;

  constructor(
    protected opfsFileCacheService: OpfsCacheService,
    protected foviaApi: ServerApiService,
    protected computeUtilsService: ComputeUtilsService,
    public readonly examDetail: IExamDetailInformation,
    private cachingMutex: Mutex,
    private studyLoadingSemaphore: Semaphore,
    private imageLoadingSemaphore: Semaphore,
    private maxPixelRequestSemaphore: Semaphore,
    private makeCacheSpaceAvailableFn: (requiredSpace: number) => Promise<boolean>
  ) {
    this.examRules = new ExamGroupRules(examDetail.examGroup);
    this.cachingStoppedMutex = new Mutex(); // Signals stopped when unlocked
    this.initMutex = new Mutex();
    this.studyStatusMap = new Map<StudyStatus, CachingStatusDetail>();

    // The order of the operations that are performed by exam caching
    // If caching is interrupted we'll track the status of what we were doing in order to resume.
    this.examCacheOrder.push(StudyStatus.eNEW);                 // Nothing cached
    this.examCacheOrder.push(StudyStatus.eSTARTING);            // Initial caching of stats
    this.examCacheOrder.push(StudyStatus.eLOADING);             // Loading from Fovia
    this.examCacheOrder.push(StudyStatus.eCACHE_INITIAL_STATS); // Update stats after load
    this.examCacheOrder.push(StudyStatus.eCACHING_MANIFEST);    // Caching of study manifest
    this.examCacheOrder.push(StudyStatus.eCREATE_CACHE_LIST);   // Create list of images to cache
    this.examCacheOrder.push(StudyStatus.eCACHING_IMAGES);      // Caching of images
    this.examCacheOrder.push(StudyStatus.eCACHING_STATS);       // Caching of completed stats
    this.examCacheOrder.push(StudyStatus.eCACHE_CLEANUP);       // Release resources
    this.examCacheOrder.push(StudyStatus.eCACHED);              // Caching complete

    for (const status of this.examCacheOrder) {
      this.studyStatusMap.set(status, new CachingStatusDetail(status));
    }
    let index = this.examCacheOrder.findIndex(value => value === StudyStatus.eLOADING);
    if (index > -1) {
      this.LOADING_STEP = index;
    }
    index = this.examCacheOrder.findIndex(value => value === StudyStatus.eCACHED);
    if (index > -1) {
      this.CACHED_STEP = index;
    }
    this.studyInstanceUID = examDetail.examInfo.studyUID as string;
  }

  public get studyDate(): string {
    return this.foviaExam[0].dicomSeries.studyDate;
  }

  public get hasFatalError(): boolean {
    return this.currentStatusDetail.fatalError;
  }

  public get hasQuotaError(): boolean {
    return this.currentStatusDetail.quotaError;
  }

  public get cacheStatus(): CACHED_IMAGE_STATUS {
    return this.cacheImageStatus;
  }

  public async cachingHasStopped(): Promise<boolean> {
    return new Promise(async (resolve) => {
      if (this.cachingStoppedMutex.isLocked()) {
        await this.cachingStoppedMutex.waitForUnlock();
      } else {
        console.log(`${this.constructor.name} cachingHasStopped caching was already stopped ${this.stoppedCaching()}`);
      }
      return resolve(this.stoppedCaching());
    });
  }

  // Can't complete async initialization in constructor,
  public async init(): Promise<void> {
    await this.initMutex.acquire();
    await this.cachingStoppedMutex.acquire();
    // See if we already have stats for this study -- if so use them.
    const examStats = await this.opfsFileCacheService.getCacheExamStats(this.studyInstanceUID);

    // Pick up the previous stats, if any so we can continue caching partial exams.
    this.cacheTimingStatus.stats = examStats != null ? examStats.stats : this.cacheTimingStatus.stats;

    // Exam was previously cached. See if it is complete
    const cachingComplete = (examStats != null &&
      examStats.totalExamImages > 0 &&
      examStats.totalCachedImages === examStats.totalExamImages &&
      examStats.stats.studyStatus === StudyStatus.eCACHED);

    const cachingInProgress = (examStats != null &&
      !cachingComplete &&
      examStats.totalExamImages > 0 &&
      examStats.totalCachedImages > 0);
    this.cacheTimingStatus = cachingComplete || cachingInProgress ? examStats : new CachedExamStats(this.studyInstanceUID);
    // Previously cached studies may be for a different user. Preserve this information
    // New stats don't have user information yet... provide it now.
    if (this.cacheTimingStatus.user === '') {
      this.cacheTimingStatus.stats.userId = this.opfsFileCacheService.userId;
    }
    let message = '';
    if (cachingComplete) {
      message = `${this.constructor.name} ***** ${this.studyInstanceUID} init complete, already cached ${cachingComplete} ${examStats?.totalCachedImages}`;
      this.start(StudyStatus.eCACHED);
      this.currentStatusDetail.completed();
      this.currentCacheStep = this.CACHED_STEP;
      this.cacheImageStatus = CACHED_IMAGE_STATUS.COMPLETELY_CACHED;
    } else if (cachingInProgress) {
      message = `${this.constructor.name} ***** ${this.studyInstanceUID} init complete, caching resuming ${cachingComplete} ${examStats?.totalCachedImages}`, this.cacheTimingStatus;
      this.start(StudyStatus.eNEW);
    } else {
      message = `${this.constructor.name} ***** ${this.studyInstanceUID} init complete, caching starting new exam}`;
      this.start(StudyStatus.eNEW);
    }
    console.info(message);
    this.initComplete = true;
    this.initMutex.release();
  }

  public async cacheEntireExam(): Promise<CACHED_IMAGE_STATUS> {
    return new Promise(async (resolve) => {
      if (this.initMutex.isLocked()) {
        await this.initMutex.waitForUnlock();
      }
      if (await this.opfsFileCacheService.detectAndHandleCacheEviction()) {
        const isOpfsReadOnly = false;
        await this.opfsFileCacheService.init(isOpfsReadOnly);
        return resolve(CACHED_IMAGE_STATUS.NOT_CACHED);
      }
      // Done?
      if (this.cachingComplete()) {
        return resolve(this.cacheImageStatus);
      }
      if (this.stoppedCaching()) {
        await this.cachingStoppedMutex.acquire();
      }
      const result = await this.continueCachingExam();
      console.debug(`${this.constructor.name} cacheEntireExam returns ${result} cachingComplete ${this.cachingComplete()} `);
      // report the caching status for this exam
      return resolve(this.cacheImageStatus);
    });
  }

  public async prepareToResume(hasRetriableErrors: boolean): Promise<void> {
    return new Promise(async (resolve) => {
      this.stop();
      // Have we loaded a study? then prepare to unload it
      // and ensure we re-start caching on the load step
      if (this.currentCacheStep >= this.LOADING_STEP &&
        (!this.cachingComplete() || hasRetriableErrors)) {
        console.info(`${this.constructor.name} +++ prepareToResume ${this.stoppedCaching()} unload fovia exam ${this.studyInstanceUID} current status ${this.cacheTimingStatus.studyStatus}`);
        // Reset our notion of which loading steps have been completed
        this.resetStatusToLoading();
        await this.unloadStudy(false);
      } else {
        console.debug(`${this.constructor.name} +++ prepareToResume cachingComplete ${this.cachingComplete()} `);
      }
      return resolve();
    });
  }

  public async unloadStudy(final = true): Promise<void> {
    return new Promise(async (resolve) => {
      try {
        console.info(`${this.constructor.name} unloadStudy ${this.studyInstanceUID} ... `);
        await this.foviaApi.unloadExam(this.examDetail.examGroup, this.studyInstanceUID);
        if (final) {
          this.cleanupLoadStudyData();
        }
        console.info(`${this.constructor.name} unloadStudy ... done`);
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name} error unloading exam ${errCode}`, err);
      }
      return resolve();
    });
  }

  protected cleanupLoadStudyData(): void {
    this.foviaExam = [];
    this.examLoadContext = new ExamLoadContext(this.examDetail.examGroup, this.examDetail.examInfo.studyUID, 'always');
  }

  protected set currentStatusDetail(value: CachingStatusDetail) {
    // This transmits any changes in exam caching status to the notifier
    // which will notify the cache-status service.
    this.examCacheStatus = value.status;
    this._currentStatusDetail = value;
  }

  protected set examCacheStatus(value: StudyStatus) {
    if (this.examDetail.examCacheStatus != null) {
      this.examDetail.examCacheStatus.studyStatus = value;
    }
  }
  protected get currentStatusDetail(): CachingStatusDetail {
    return this._currentStatusDetail;
  }

  protected isCachingPaused(): boolean {
    return !this.cachingMutex.isLocked();
  }

  protected shouldStopCaching(): boolean {
    return this.isCachingPaused() || this.hasQuotaError;
  }

  public stoppedCaching(): boolean {
    return !this.cachingStoppedMutex.isLocked;
  }

  protected loadFailed(): boolean {
    return this.examDetail.examInfo.loadStatus === ExamLoadStatus.LOAD_FAILED;
  }

  protected cachingComplete(): boolean {
    // Finishing loading all of the study OR a fovia load study failure is
    // considered "complete" -- we won't retry a study-load failure.
    const finished = this.examCacheOrder[this.currentCacheStep] === StudyStatus.eCACHED && this.currentStatusDetail.complete;
    return finished || this.loadFailed();
  }

  /*
  After a study has been loaded by fovia, we may stop and then later resume caching. This class tracks
  the points at which the caching was stopped, and will resume at that point when caching continues.
  The order of exam operations is as follows:
  NEW - initial state,
  LOADING - loading from fovia -- this may fail fatally.
  STARTING - initial caching of stats object to cache - this may fail if a quota error occurs
  CACHING_MANIFEST - writing manifest to cache - this may fail if a quota error occurs
  CREATING_CACH_LIST - assemble the list of images to be cached
  CACHING_IMAGES - writing each study image to cache - this may fail if a quota error occurs,
  CACHING_STATS - previously written stats are updated with the new stats object - this may fail if a quota error occurs
  CACHED - caching is complete

  Once a quota error is cleared, we should plan to resume caching, based on the last activity that failed for a quota violation.

  Caching may also be stopped by releasing the cachingMutex. This code checks the mutex
  1. After every caching step
  2. During CACHING_IMAGES
     we only pause the cache image task queue, and resume it when ready.

  Caching also tracks missing exam images for the exam and whether the http errors associated with those images are retriable.
  We will try up to MAX_LOAD_STUDY_REQUESTS times to load a study to resolve its retriable missing images.
  */

  protected async continueCachingExam(): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = true;
      let done = this.cachingComplete();
      LogSupport.setSession(`${this.examDetail.examGroup.groupId}-${this.examDetail.examInfo.studyUID}`);

      if (!this.canContinueCaching()) {
        return resolve(false);
      }

      while (!done) {
        result = await this.performStep(this.examCacheOrder[this.currentCacheStep]);

        if (this.shouldStopCaching()) {
          break;
        }

        if (!result) {
          this.stop();
          break;
        }

        done = this.cachingComplete();
        if (done) {
          break;
        }
        // Keep on caching
        this.nextCachingStep();
      }
      // We can be 'done' yet still have retriable errrors for the next caching pass
      const hasRetriableErrors = this.shouldStopCaching() ? false : this.missingImages.hasRetriableErrors();
      if (!done || hasRetriableErrors) {

        console.info(`${this.constructor.name} Caching stopped on ${this.currentCacheStep} is ${this.currentStatusDetail.status} shouldStopCaching ${this.shouldStopCaching()}`);
        if (this.shouldStopCaching() || hasRetriableErrors) {
          // We don't know when we'll get back to caching this exam and we
          // don't want server side resources to build up and exhaust fovia memory.
          // So we prepare to reload the exam so we can continue/try again
          await this.prepareToResume(hasRetriableErrors);
        }
      }

      if (!this.errorOccurred()) {
        console.info(`${this.constructor.name} Caching stopped on ${this.currentCacheStep} is ${this.currentStatusDetail.status} result was ${result}`);
        console.log(`${this.constructor.name} Caching stopped on`, this.cacheTimingStatus.stats);
      }
      // Signal that we've stopped
      this.cachingStoppedMutex.release();
      return resolve(result);
    });
  }

  protected errorOccurred(): boolean {
    let errorInfo = '';
    if (this.loadFailed()) {
      errorInfo = 'load failure';
    } else if (this.hasQuotaError) {
      errorInfo = 'quotaError';
    } else if (this.hasFatalError) {
      errorInfo = 'fatal error';
    }
    const result = errorInfo !== '';
    if (result) {
      console.error(`${this.constructor.name} Caching failed with ${errorInfo} on ${this.currentCacheStep}`);
      console.log(`${this.constructor.name} Caching failed with`, this.cacheTimingStatus.stats);
    }
    return result;
  }

  protected canContinueCaching(): boolean {
    if (this.currentStatusDetail.status !== StudyStatus.eNEW) {
      // Cannot restart from a fatal error
      if (this.hasFatalError) {
        console.error(`${this.constructor.name} canContinueCaching cannot continue caching, a fatal error was previously encounterd during ${this.currentStatusDetail.status}`);
        return false;
      }
      // Quota violation still present?
      if (this.currentStatusDetail.quotaError && this.opfsFileCacheService.cacheQuotaError) {
        console.error(`${this.constructor.name} canContinueCaching cannot continue caching,, quota error still exists`);
        return false;
      } else {
        this.currentStatusDetail.quotaError = false;
      }
      // Caching still stopped?
      if (this.currentStatusDetail.cachingStopped && this.isCachingPaused()) {
        console.error(`${this.constructor.name} canContinueCaching cannot continue caching, stopCachingMutext still locked`);
        return false;
      } else {
        this.currentStatusDetail.cachingStopped = false;
      }
    }
    return true;
  }

  protected async makeCacheSpaceAvailable(): Promise<boolean> {
    const extraHeadspaceMB = 0;
    const requiredSpace = estimateOpfsMBytesForFoviaExam(this.foviaExam) + extraHeadspaceMB;
    return this.makeCacheSpaceAvailableFn(requiredSpace);
  }

  protected async performStep(studyCacheStatus: StudyStatus): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      const imageStatusName = CACHED_IMAGE_STATUS[this.cacheImageStatus];
      console.log(`${this.constructor.name} performStep +++ '${studyCacheStatus}' '${imageStatusName}'  ${this.studyInstanceUID}... begin`, this.imageProcessedList);

      switch (studyCacheStatus) {
        case StudyStatus.eNEW: {
          result = true;
        } break;
        case StudyStatus.eSTARTING: {
          result = await this.cacheStats(studyCacheStatus);
        } break;
        case StudyStatus.eLOADING: {
          result = await this.loadStudy();
          if (result) {
            const isRoom = await this.makeCacheSpaceAvailable();
            if (!isRoom) {
              console.info(`${this.constructor.name} performStep  there may not be enough cache space for exam=${this.examLoadContext?.studyInstanceUID}. estimatedReqMB=${estimateOpfsMBytesForFoviaExam(this.foviaExam)}`);
            }
          }
        } break;
        case StudyStatus.eCACHE_INITIAL_STATS:
          result = await this.cacheStats(studyCacheStatus);
          break;
        case StudyStatus.eCACHING_MANIFEST:
          result = await this.cacheManifest();
          break;
        case StudyStatus.eCREATE_CACHE_LIST:
          result = await this.createImageCacheList();
          break;
        case StudyStatus.eCACHING_IMAGES:
          result = await this.cacheExamImages();
          break;
        case StudyStatus.eCACHING_STATS:
          result = await this.cacheFinalStats();
          // console.log(`*** estimated cache size = ${ estimateOpfsMBytesForFoviaExam(this.foviaExam) }`);
          // console.log(`*** actual    cache size = ${ (await this.opfsFileCacheService.getCacheExamStats(this.studyInstanceUID))?.totalMB }`);
          break;
        case StudyStatus.eCACHE_CLEANUP:
          // We've already written the final stats to OPFS,
          // Unload
          result = true;
          await this.opfsFileCacheService.publishDiskSpaceInfo();
          this.foviaExam = [];
          await this.unloadStudy();
          break;
        case StudyStatus.eCACHED:
          // Deliberately empty so we can know cache cleanup is complete
          this.currentStatusDetail.completed();
          result = true;
          break;
        default:
          console.error(`${this.constructor.name} performStep Unhandled case '${studyCacheStatus}' '${imageStatusName}' ${this.studyInstanceUID}`);
      }
      if (result && !this.shouldStopCaching()) {
        console.log(`${this.constructor.name} performStep +++ '${studyCacheStatus}' '${imageStatusName}' ${this.studyInstanceUID}... completed ${result}`);
      } else {
        if (this.loadFailed()) {
          console.error(`${this.constructor.name} performStep +++ '${studyCacheStatus}' '${imageStatusName}' ${this.studyInstanceUID}... load failed ${result} removing from opfs cache`);
          this.stop();
          await this.opfsFileCacheService.removeStudyFromCache(this.studyInstanceUID);
          await this.unloadStudy();
          this.examCacheStatus = StudyStatus.eCACHING_ERROR;
        } else {
          let issueToReport = ''
          if (this.shouldStopCaching()) {
            issueToReport = this.isCachingPaused() ? `caching pause detected caching stopped` : `quota error raised caching stopped`;
          }
          const message = `${this.constructor.name} performStep +++ '${studyCacheStatus}' '${imageStatusName}' ${this.studyInstanceUID}... not completed ${issueToReport} ${result}`
          if (!this.isCachingPaused()) {
            console.error(message);
          } else {
            console.warn(message);
          }
        }
      }
      return resolve(result);
    });
  }

  protected start(status: StudyStatus): void {
    const currentStatus = this.studyStatusMap.get(status);
    if (currentStatus == null) {
      console.error(`${this.constructor.name}:start unexpected study status may not be null`);
      return;
    }
    this.currentStatusDetail = currentStatus;
    this.currentStatusDetail.start();
  }

  protected stop(): void {
    this.currentStatusDetail.stop();
  }

  protected nextCachingStep(): void {
    this.stop();
    this.currentStatusDetail.completed();
    this.currentCacheStep++;
    this.start(this.examCacheOrder[this.currentCacheStep]);
  }

  protected resetStatusToLoading(): void {
    // Reset our tracking of caching step status when we need to reload
    for (let index = this.LOADING_STEP; index < this.examCacheOrder.length; index++) {
      const status = this.examCacheOrder[index];
      const detail = new CachingStatusDetail(status);
      this.studyStatusMap.set(status, detail);
    }
    // Prepare to restart at the loading step
    this.currentCacheStep = this.LOADING_STEP;
    // Set the next caching step to loading
    const status = this.cacheTimingStatus.studyStatus;
    this.start(status);
    this.cacheTimingStatus.updateStudyStatus(status);
    // If we are also in the midst of a quota problem, track this state
    this.currentStatusDetail.quotaError = this.hasQuotaError;
    this.currentStatusDetail.cachingStopped = this.isCachingPaused();
  }

  protected async loadStudy(): Promise<boolean> {
    return new Promise(async (resolve) => {
      if (this.foviaApi.userCredentials == null) {
        console.error(`${this.constructor.name} loadStudy missing user credentials`);
        return resolve(false);
      }
      const [count, releaseFn] = await this.studyLoadingSemaphore.acquire();
      if (this.shouldStopCaching()) {
        console.warn(`${this.constructor.name} loadStudy signaled shouldStopCaching ${count}`);
        releaseFn();
        return resolve(false);
      }
      const perf = new PerfMeasure('loadStudy');
      perf.start();
      const userId = this.foviaApi.userCredentials.userId;
      const authToken = this.foviaApi.userCredentials.authToken;
      this.cacheTimingStatus.updateStudyStatus(StudyStatus.eLOADING);
      this.cacheTimingStatus.startCachingStudyTimer();
      let result = false;
      const perfTime = new PerfTiming();
      try {

        const foviaOptions = this.foviaApi.foviaConnectionOptions();
        Fovia.ServerContext.initializeCacheClient(foviaOptions);

        const reLoad = this.cacheImageStatus != CACHED_IMAGE_STATUS.NOT_CACHED ? 're-' : '';
        this.cacheImageStatus = CACHED_IMAGE_STATUS.NOT_CACHED;
        this.examLoadContext = new ExamLoadContext(this.examDetail.examGroup, this.examDetail.examInfo.studyUID, 'always');
        // We've seen study loading on fovia server be a long time, but also hangs (or crashes)... originally
        // this was 110 seconds (10k slice exam (80 secs) + slow auth). But that wasn't enough for large tomos using Wado,
        // where we would also get a timeout. We think 5 minutes might be enough.
        const TIMEOUT = 300000;

        const scanDirResultsReadyPromise = this.foviaApi.loadExam(this.examLoadContext);
        const scanDirResultsReadyPromiseTO = promiseTimeout<Fovia.ScanDirResults | null, PV_ERRORS>(scanDirResultsReadyPromise, TIMEOUT, PV_ERRORS.TIMEOUT);
        const examLoadCompletePromise = this.examLoadContext.serverExamLoadComplete();
        const examLoadCompletePromiseTO = promiseTimeout<boolean, PV_ERRORS>(examLoadCompletePromise, TIMEOUT, PV_ERRORS.TIMEOUT);
        const promises = [scanDirResultsReadyPromiseTO, examLoadCompletePromiseTO];
        const results = await Promise.allSettled(promises);
        const scanDirResults = this.examLoadContext.scanDirResults;

        // Verify that all is well
        if (results[0] == null || scanDirResults == null) {
          console.error(`${this.constructor.name} ${reLoad}loadStudy returned null, unexpected condition ${examDetailToString(this.examDetail)} ${perfTime.elapsedSecondsMessage()}`);
          this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOAD_FAILED;
          this.cacheImageStatus = CACHED_IMAGE_STATUS.LOAD_ERROR;
          releaseFn();
          perf.end({ status: `loadExam failed`, id: this.studyInstanceUID });
          return resolve(false);
        } else if (!results[1]) {
          // Whole study wouldn't load
          console.error(`${this.constructor.name} ${reLoad}loadStudy complete failed ${examDetailToString(this.examDetail)} ${perfTime.elapsedSecondsMessage()}`);
          this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOAD_FAILED;
          this.cacheImageStatus = CACHED_IMAGE_STATUS.LOAD_ERROR;
          releaseFn();
          perf.end({ status: `loadExam complete failed`, id: this.studyInstanceUID });
          return resolve(result);
        }

        const foviaExam = scanDirResults.findStudy(this.studyInstanceUID);
        if (foviaExam == null) {
          // Ran into this problem with 7.0.2.3148, hadn't encountered it before
          throw `scanDirResults.findStudy(this.studyInstanceUID) returned null for ${this.studyInstanceUID}`;
        }


        // The exam is fully loaded on the server at this point.
        // Pull back the complete set of SR presentations and store them alongside the manifest.
        // Some exams won't have any SR. For these, only the foviaSchema and examVersion are set.
        const examSRData: IFoviaStudySRData = {
          foviaSchema: FOVIA_SR_PRESENTATION_SCHEMA_VERSION,
          examVersion: this.examLoadContext.serverMetadataHash,
          imageSeriesUID: [],
          imageSeriesSR: {},
          errorSeriesUID: [],
          errorSeriesDesc: []
        };
        for (const series of foviaExam) {
          if (series.isNonImageSeries || !series.dicomSeries) {
            continue; // No SDC
          }
          const sdc = series.dicomSeries;
          const seriesUID = sdc.seriesInstanceUID;
          if (!sdc.cachedNonImageDataArray || !sdc.cachedNonImageDataArray.structuredReports) {
            continue; // No SRs
          }
          // Note this series has one or more SRs referencing it.
          examSRData.imageSeriesUID.push(seriesUID);
          try {
            const seriesSRData = await Fovia.ServerContext.getSrDataBySeriesInstanceUid(seriesUID);
            if (seriesSRData) {
              console.log(`${this.constructor.name} - loadStudy -  Retrieved SR data for ${seriesUID}`, seriesSRData);
              examSRData.imageSeriesSR[seriesUID] = seriesSRData as IFoviaSeriesSRData;
            }
          } catch (err) {
            console.error(`${this.constructor.name} - loadStudy -  Failed to retrieve SR data for ${seriesUID}`, err);
            examSRData.errorSeriesDesc.push(sdc.seriesDescription);
            examSRData.errorSeriesUID.push(seriesUID);
          }
        }

        console.info(`${this.constructor.name} loadStudy Exam ${reLoad}loaded ${examDetailToString(this.examDetail)} ${count} ${perfTime.elapsedSecondsMessage()} `);
        this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOADED;
        this.sanityCheck(foviaExam);
        this.logFoviaSeriesInfo(foviaExam);
        this.missingImages.loadCount++;
        this.foviaExamSRData = examSRData;
        this.foviaExam = foviaExam;
        result = true;
        perf.end({ status: `success`, id: this.studyInstanceUID });

      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        this.cacheImageStatus = errCode === PV_ERRORS.TIMEOUT ? CACHED_IMAGE_STATUS.LOAD_TIMEOUT : CACHED_IMAGE_STATUS.LOAD_ERROR;
        this.currentStatusDetail.fatalError = this.cacheImageStatus === CACHED_IMAGE_STATUS.LOAD_TIMEOUT ? false : true;
        console.error(`${this.constructor.name} loadStudy -  Fovia error for ${examDetailToString(this.examDetail)} ${errCode} ${perfTime.elapsedSecondsMessage()}`);
        this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOAD_FAILED;
        perf.end({ status: `exception`, id: this.studyInstanceUID });
      }
      releaseFn();
      return resolve(result);
    });

  }

  protected async cacheStats(studyStatus: StudyStatus): Promise<boolean> {
    return new Promise(async (resolve) => {
      const perf = new PerfMeasure('cacheStats');
      perf.start();

      let result = false;
      this.cacheTimingStatus.updateStudyStatus(studyStatus);
      if (this.cacheTimingStatus == null) {
        console.error(`${this.constructor.name} cacheStats studyStatus ${studyStatus} unexpected `);
      }
      if (studyStatus === StudyStatus.eSTARTING) {
        // Create a directory for this new study
        result = await this.opfsFileCacheService.addStudyUIDToFileCache(this.studyInstanceUID);
        if (!result) {
          console.error(`${this.constructor.name} cacheStats ${studyStatus} - failed to create study directory for ${this.studyInstanceUID} ${result}`);
          perf.end({ status: `opfs addStudyUIDToFileCache failed`, id: this.studyInstanceUID });
          return resolve(result);
        }
        // Cache our starting stats - the UI will fetch stats only from OPFS
        result = await this.opfsFileCacheService.addCachedExamStatsToCache(this.studyInstanceUID, this.cacheTimingStatus);
        console.log(`${this.constructor.name} cacheStats ${studyStatus} - cached starting stats completed with ${result}`);
      } else {
        // Update the stats as we go along
        result = await this.opfsFileCacheService.updateCachedExamStatsToCache(this.studyInstanceUID, this.cacheTimingStatus);
      }
      if (!result) {
        this.saveOPFSErrorInfo(`${this.constructor.name} cacheStats ${studyStatus} failed with ${result}`);
        this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOAD_FAILED;
        perf.end({ status: `opfs write failed`, id: this.studyInstanceUID });
        return resolve(result);
      }
      perf.end({ status: `success`, id: this.studyInstanceUID });

      return resolve(result);
    });
  }

  protected async cacheManifest(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const perf = new PerfMeasure('cacheManifest');
      perf.start();

      let bResult = false;
      if (this.examLoadContext != null) {
        this.cacheTimingStatus.updateStudyStatus(StudyStatus.eCACHING_MANIFEST);
        this.cacheImageStatus = CACHED_IMAGE_STATUS.NOT_CACHED;
        const startCacheWrite = performance.now();
        if (!this.examLoadContext.serverMetadataHash) {
          this.saveOPFSErrorInfo(`No exam signature returned by server`);
          this.cacheImageStatus = CACHED_IMAGE_STATUS.MANIFEST_ERROR;
          this.cacheTimingStatus.addManifestStats(startCacheWrite, 0);
          perf.end({ status: `No exam signature returned by server`, id: this.studyInstanceUID });
          return resolve(bResult);
        }
        if (!this.examLoadContext.serverScanDirResultsJSON) {
          this.saveOPFSErrorInfo(`No ScanDirResults returned by server`);
          this.cacheImageStatus = CACHED_IMAGE_STATUS.MANIFEST_ERROR;
          this.cacheTimingStatus.addManifestStats(startCacheWrite, 0);
          perf.end({ status: `No ScanDirResults returned by server`, id: this.studyInstanceUID });
          return resolve(bResult);
        }
        if (!this.foviaExamSRData) {
          this.saveOPFSErrorInfo(`No SR data generated during study load`);
          this.cacheImageStatus = CACHED_IMAGE_STATUS.MANIFEST_ERROR;
          this.cacheTimingStatus.addManifestStats(startCacheWrite, 0);
          perf.end({ status: `No SR data generated during study load`, id: this.studyInstanceUID });
          return resolve(bResult);
        }
        const fileVersion = this.examLoadContext.serverMetadataHash;
        const examManifest = this.examLoadContext.serverScanDirResultsJSON;
        const examSRData = this.foviaExamSRData;
        const result1 = await this.opfsFileCacheService.addExamManifestToFileCache(this.studyInstanceUID, examManifest, examSRData, fileVersion);
        if (result1 === 0) {
          this.saveOPFSErrorInfo(`Caching manifest failed`);
          this.cacheImageStatus = CACHED_IMAGE_STATUS.MANIFEST_ERROR;
          this.cacheTimingStatus.addManifestStats(startCacheWrite, result1);
          perf.end({ status: `addExamManifestToFileCache failed`, id: this.studyInstanceUID });
          return resolve(bResult);
        }

        const result2 = await this.opfsFileCacheService.addDicomTagsToFileCache(this.studyInstanceUID, this.examLoadContext.dicomJsonMetadata);
        if (result2 === 0) {
          this.saveOPFSErrorInfo(`Caching dicom headers failed`);
          this.cacheImageStatus = CACHED_IMAGE_STATUS.MANIFEST_ERROR;
          this.cacheTimingStatus.addManifestStats(startCacheWrite, result1 + result2);
          perf.end({ status: `addDicomTagsToFileCache failed`, id: this.studyInstanceUID });
          return resolve(bResult);
        }
        const totalBytes = result1 + result2;
        this.cacheTimingStatus.addManifestStats(startCacheWrite, totalBytes);
        console.log(`${this.constructor.name} Caching manifest completed without error`);
        perf.end({ status: `success`, id: this.studyInstanceUID });
        bResult = true;
      }
      return resolve(bResult);
    });
  }

  protected async cacheFinalStats(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const perf = new PerfMeasure('cacheFinalStats');
      perf.start();
      let result = false;
      console.log(`Caching final stats for ${this.studyInstanceUID}`);
      if (this.cacheExamImages.length === 0) {
        this.cacheTimingStatus.updateStudyStatus(StudyStatus.eCACHED);
        this.cacheTimingStatus.endCachingImagesTimer();
        result = await this.opfsFileCacheService.updateCachedExamStatsToCache(this.studyInstanceUID, this.cacheTimingStatus);
        if (!result) {
          this.saveOPFSErrorInfo(`Caching stats failed after images cached`);
          this.cacheTimingStatus.updateStudyStatus(StudyStatus.ePARTIALLY_CACHED);
          perf.end({ status: `updateCachedExamStatsToCache failed`, id: this.studyInstanceUID });
        } else {
          console.log(`${this.constructor.name} Caching final stats completed`);
          perf.end({ status: `success`, id: this.studyInstanceUID });
        }
        return resolve(result);
      }
      console.error(`${this.constructor.name} cacheFinalStats - unexpected code sequence encountered... final stats not cached`);
      console.log(`${this.constructor.name} cacheFinalStats`, this.cacheTimingStatus.stats);
      perf.end({ status: `no images cached`, id: this.studyInstanceUID });

      return resolve(result);
    });
  }

  protected saveOPFSErrorInfo(message: string): void {
    // to do: Show this message in the UI and Log it to long term log
    this.currentStatusDetail.quotaError = this.hasQuotaError;
    if (this.currentStatusDetail.quotaError) {
      this.currentStatusDetail.fatalError = false;
      console.warn(`${this.constructor.name} ${message} quotaError: ${this.currentStatusDetail.quotaError}`);
    }
  }

  // This may be called more than once, if a study is re-cached. This may happen if caching was interrupted
  // before it was completed, because exam priority changed.
  protected async createImageCacheList(): Promise<boolean> {
    const perf = new PerfMeasure('createImageCacheList');
    perf.start();
    let result = false;

    if (this.examLoadContext == null) {
      console.error(`${this.constructor.name} createImageCacheList ${this.studyInstanceUID} ExamLoadContext may not be null `);
      return result;
    }

    try {
      // create the list of images to be cached. The order of the
      // images in the list is the order in which they will arrive.
      // So we'll cache the first image of every series, the middle
      // image of every series(for thumbnails), then the 2nd image
      // in every series etc.
      //
      // In the future we will use Hanging Protocol for this study to
      // further restrict the images that are cached for the study
      // (e.g. thin slices etc.)

      // We may need to reload and re-cache an exam if we encountered
      // an interruption during loading -- e.g. quota error, fovia connection loss etc.
      this.imageCacheList = [];
      this.imageProcessedList = [];
      let invalidImageCount = 0;
      let skippedImageCount = 0;
      const validSeriesImageMap = new Map<Fovia.SeriesDataContext, number[]>();
      let foviaTotalImages = 0;
      // filter out any images that don't belong to this exam
      for (const series of this.foviaExam) {
        if (series.isNonImageSeries) {
          console.log(`${this.constructor.name} ${this.studyInstanceUID} ceateImageCacheList skipping non-image series list iength is ${series.nonImageSeriesResults.getNonImageSeriesMap().size}`);
          continue;
        }
        if (series.dicomSeries.imageCount === 0) {
          console.log(`${this.constructor.name} createImageCacheList skipping series ${series.seriesInstanceUID} with no images`);
          continue;
        }
        foviaTotalImages += series.dicomSeries.getNumImages();
        const validImageIndexes: number[] = [];
        for (let i = 0; i < series.dicomSeries.getNumImages(); i++) {
          const imageSDC: Fovia.SeriesDataContext = series.dicomSeries;
          const imageStudyUID = imageSDC.studyInstanceUID;
          const image = imageSDC.imageTags[i];
          // Does this image belong to a different study? then Track it.
          const differentStudy = imageStudyUID !== this.studyInstanceUID;
          if (differentStudy) {
            const imagekey = makeImageKey(image.sopInstanceUID, image.frameNumber);
            invalidImageCount++;
            console.error(`${this.constructor.name} createImageCacheList sopInstance ${imagekey} has studyUID ${imageStudyUID} doesn't match ${this.studyInstanceUID}, will not be cached`);
          } else {
            // Based on the study and image type we may not cache all of the images. Don't even include them in the candidate lists.
            if (!this.examRules.shouldCacheImageFrame(imageSDC, i)) {
              skippedImageCount++;
              continue;
            } else {
              validImageIndexes.push(i);
            }
          }
        }
        validSeriesImageMap.set(series.dicomSeries, validImageIndexes);
        // console.log(`${this.constructor.name} createImageCacheList adding series ${series.dicomSeries.seriesInstanceUID} #images ${series.dicomSeries.imageCount} keeping ${validImageIndexes.length}`);
      }
      // Prepare list of images to be cached, in the order required by the viewer
      let expectedImageCount = 0;
      let imageSeriesList = Array.from(validSeriesImageMap);
      for (const [sdc, imageNums] of imageSeriesList) {
        // console.log(`${this.constructor.name} createImageCacheList Series # ${sdc.seriesNumber} ${imageNums.length}`);
        expectedImageCount += imageNums.length;
        if (imageNums.length === 0) {
          // no valid images in this series
          continue;
        }
        // Gather the first image and 'middle' image from each series to be cached using our calcMiddleImage function
        // This can result in the first image and the 'middle' image, being the same. Remove any processed images from
        // our list as we go.
        const firstImage = imageNums[0];
        const middleImageIndex = calcMiddleImage(sdc);
        const middleImage = imageNums[middleImageIndex];

        this.imageCacheList.push({ sdc: sdc, imageNum: firstImage, cacheStatus: 0, success: NO_SUCCESS, index: this.imageCacheList.length, retryCount: 0 });
        // MiddleImage is the first image? calcMiddleImage may do this
        if (middleImage === firstImage) {
          // remove first image from remaining images to be cached
          // console.log(`${this.constructor.name} createImageCacheList first == middle  ${firstImage} ${middleImage}  ${imageNums.length}`);
          imageNums.shift();
          // console.log(`${this.constructor.name} createImageCacheList first == middle  ${firstImage} ${middleImage}  ${imageNums.length}`);
        } else {
          this.imageCacheList.push({ sdc: sdc, imageNum: middleImage, cacheStatus: 0, success: NO_SUCCESS, index: this.imageCacheList.length, retryCount: 0 });
          // remove first image and middle image from remaining images to be cached
          // console.log(`${this.constructor.name} createImageCacheList first != middle  ${firstImage} ${middleImage} ${middleImageIndex} ${imageNums.length}`);
          imageNums.splice(middleImageIndex, 1);
          // console.log(`${this.constructor.name} createImageCacheList first != middle  ${firstImage} ${middleImage} ${middleImageIndex}  ${imageNums.length}`);
          imageNums.shift();
          // console.log(`${this.constructor.name} createImageCacheList first != middle  ${firstImage} ${middleImage} ${middleImageIndex}  ${imageNums.length}`);
        }
        validSeriesImageMap.set(sdc, imageNums);
      }
      // Append the remaining images to our list
      imageSeriesList = Array.from(validSeriesImageMap);
      for (const [sdc, imageNums] of imageSeriesList) {
        for (const imageNum of imageNums) {
          // Track the index in this cache list for each request
          this.imageCacheList.push({ sdc: sdc, imageNum: imageNum, cacheStatus: 0, success: NO_SUCCESS, index: this.imageCacheList.length, retryCount: 0 });
        }
      }

      // Assemble the list of missing images for this exam list
      for (const imageInfo of this.imageCacheList) {
        const imageKey = this.makeImageKey(imageInfo.sdc, imageInfo.imageNum);
        const image = imageInfo.sdc.imageTags[imageInfo.imageNum];
        const frameNumber = image.frameNumber;

        const canDownload = await this.examLoadContext.frameReadyToDownload(image.sopInstanceUID, frameNumber);
        if (!canDownload) {
          const httpStatus = this.examLoadContext.imageFrameErrorCode(image.sopInstanceUID, frameNumber);
          this.missingImages.addMissingImage(imageKey, httpStatus);
        } else {
          // This could occur if we are re-trying caching of the exam and some errors are no longer occurring.
          // If this image was previously missing, remove it from our tracking list
          this.missingImages.removeMissingImage(imageKey);
        }
      }

      // Make sure we're accounting for everything
      if (foviaTotalImages !== this.imageCacheList.length + invalidImageCount + skippedImageCount) {
        console.warn(`${this.constructor.name} createImageCacheList cacheList reconcilliation with fovia: ${foviaTotalImages} != ${this.imageCacheList.length + invalidImageCount + skippedImageCount}`);
      }
      if (this.imageCacheList.length !== expectedImageCount) {
        console.warn(`${this.constructor.name} createImageCacheList cacheList ${this.imageCacheList.length} doesn't match total images ${expectedImageCount} `);
      }

      if (this.imageCacheList.length > 0) {
        this.cacheTimingStatus.totalExamImages = this.imageCacheList.length;
        this.cacheTimingStatus.skippedImageCount = skippedImageCount;
        result = true;
      } else {
        // failed to load study as defined
        console.error(`${this.constructor.name} ${this.studyInstanceUID} cache list is empty after removing ${invalidImageCount} foreign images. Marking exam as failed.`);
        this.examDetail.examInfo.loadStatus = ExamLoadStatus.LOAD_FAILED;
        this.cacheImageStatus = CACHED_IMAGE_STATUS.LOAD_ERROR;
      }
      this.missingImages.invalidImageCount = invalidImageCount;
      perf.end({ status: `success`, id: this.studyInstanceUID });
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} createImageCacheList exception encountered ${this.foviaExam[0].dicomSeries.studyInstanceUID} failed with ${errCode}`);
      perf.end({ status: `exception`, id: this.studyInstanceUID });

    }
    return result;
  }


  /**
   * Cache the list of exam images that was previously constructed. We want to be able to
   * call this method more than once in order to resume caching of a study after a pause or
   * recoverable errors. Even though we track success or failure for each image, we try the whole
   * list again in case the study was removed from the cache because its worklist priority changed.
   *
   * We enter this method for a few use cases:
   * 1. The first time we 'begin' image caching for a study with no previous stats
   * 2. After caching is resumed for a study - at which time we'll continue caching with our image list until
   *    it's exhausted
   * 3. When we re-cache images for a study which already has some stats
   */
  protected async cacheExamImages(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const perf = new PerfMeasure('cacheExamImages');
      perf.start();
      this.cacheTimingStatus.endCachingStudyTimer();
      this.cacheTimingStatus.updateStudyStatus(StudyStatus.eCACHING_IMAGES);
      this.cacheImageStatus = CACHED_IMAGE_STATUS.NOT_CACHED;
      // Start timing each time we start/resume caching images for a study
      this.cacheTimingStatus.startCachingImagesTimer();
      // Minimize the number of outstanding promises -- makes pausing/resuming caching easier. Image caching request
      // is 'just in time' from the list of remaining requests.
      while (this.imageCacheList.length > 0) {
        if (this.shouldStopCaching()) {
          // Stop caching
          break;
        }

        await this.imageLoadingSemaphore.waitForUnlock();
        // Start caching the next image in the list, moving the item to a processed list.
        const imageInfo: ImageInfo | undefined = this.imageCacheList.shift();
        if (imageInfo != null) {
          try {
            this.cacheImageUsingSemaphore(imageInfo).then((infoStatus: ImageInfo) => {
              this.handleStatusResult(infoStatus);
            });
          } catch (err) {
            const errCode = extractErrorCodeFromException(err);
            console.error(`${this.constructor.name} cacheExamImages exception encountered ${errCode}`);
          }
        }
      }

      // Rendezvous - Ensure all tasks complete before proceeding
      for (let i = 0; i < MAX_CONCURRENT_IMAGES; i++) {
        await this.imageLoadingSemaphore.acquire();
      }
      for (let i = 0; i < MAX_CONCURRENT_IMAGES; i++) {
        this.imageLoadingSemaphore.release();
      }

      // Are we bailing for some reason when there are still images left to cache?
      if (this.shouldStopCaching() && this.imageCacheList.length > 0) {
        // Don't keep timing if we need to pause
        this.cacheTimingStatus.endCachingImagesTimer();
        await this.cacheTimingStatus.computeStats();
        console.warn(`${this.constructor.name} cacheExamImages shouldStopCaching ${this.studyInstanceUID} ${this.cacheTimingStatus.totalCachedImages}/${this.cacheTimingStatus.totalExamImages}  images cached`);
        // Forcing image caching to stop because of pause or quota error, we expect to resume
        // Non fatal error, we need to stop caching until it's corrected
        // Preserve our ability to continue caching if the opportunity arises ...
        perf.end({ status: 'aborted', id: this.studyInstanceUID });
        return resolve(false);
      }

      const allCached = this.cacheTimingStatus.totalExamImages === this.cacheTimingStatus.stats.cachedImageCount &&
        this.cacheTimingStatus.totalExamImages > 0;
      if (!allCached) {
        const missingOrInvalid = `${this.missingImages.missingImageCount}-${this.missingImages.invalidImageCount}`;
        console.warn(`${this.constructor.name} cacheExamImages ${this.studyInstanceUID} ${this.cacheTimingStatus.totalCachedImages}/${this.cacheTimingStatus.totalExamImages} (missing-invalid:${missingOrInvalid}) images partially cached`);
        this.missingImages.logMissingImageSummary(this.studyInstanceUID);
        this.cacheImageStatus = this.cacheTimingStatus.totalCachedImages === 0 ? CACHED_IMAGE_STATUS.NOT_CACHED : CACHED_IMAGE_STATUS.PARTIALLY_CACHED;
        perf.end({ status: `success partially cached`, id: this.studyInstanceUID });
      } else {
        console.info(`${this.constructor.name} cacheExamImages ${this.studyInstanceUID} ${this.cacheTimingStatus.totalCachedImages}/${this.cacheTimingStatus.totalExamImages} images fully cached`);
        this.cacheImageStatus = CACHED_IMAGE_STATUS.COMPLETELY_CACHED;
        perf.end({ status: `success fully cached`, id: this.studyInstanceUID });
      }
      await this.cacheTimingStatus.computeStats();
      // No matter how many images we were able to cache (it could have been none), if we get
      // to this point, we've completed this task.
      return resolve(true);
    });
  }

  protected handleStatusResult(imageStatus: ImageInfo): void {
    if (imageStatus.success === SUCCESS) {
      this.imageProcessedList.push(imageStatus);
    }
  }

  protected async cacheImageUsingSemaphore(imageInfo: ImageInfo): Promise<ImageInfo> {
    return new Promise(async (resolve) => {
      const [count, releaseFn] = await this.imageLoadingSemaphore.acquire();

      const perf = new PerfMeasure('cacheImage');
      perf.start();
      const imageKey = this.makeImageKey(imageInfo.sdc, imageInfo.imageNum);
      const image = imageInfo.sdc.imageTags[imageInfo.imageNum];

      let result = false;

      try {
        result = await this.cacheImageAndStats(imageInfo, perf);
      } catch (err) {
        console.error(`${this.constructor.name} cacheImageUsingSemaphore exception  ${imageInfo.sdc.studyInstanceUID} ${imageKey}`, err);
      } finally {
        if (!result) {
          // console.error(`${this.constructor.name} cacheImageUsingSemaphore failed for ${count}  ${imageInfo.sdc.studyInstanceUID} ${imageKey}`);
          perf.end({ status: `error`, key: imageKey });

        } else {
          perf.end({ status: `success`, key: imageKey });
        }
        releaseFn();
      }
      return resolve(imageInfo);
    });
  }

  protected async cacheImageAndStats(imageInfo: ImageInfo, perf: PerfMeasure): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      if (this.shouldStopCaching()) {
        return resolve(result);
      }
      try {
        result = await this.cacheImage(imageInfo, perf);
        if (!result) {
          const imageKey = this.makeImageKey(imageInfo.sdc, imageInfo.imageNum);
          this.saveOPFSErrorInfo(`cacheImage error for ${imageInfo.sdc.studyInstanceUID} ${imageKey}`);
        }
        await this.cacheTimingStatus.computeStats();
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name}:cacheImageUsingSemaphore exception caught ${errCode} returning ${result}`);
      }
      return resolve(result);
    });
  }

  private async cacheImage(imageInfo: ImageInfo, perf: PerfMeasure): Promise<boolean> {
    return new Promise(async (resolve) => {

      imageInfo.cacheStatus = 0;
      const start = new Date().getTime();
      const imageKey = this.makeImageKey(imageInfo.sdc, imageInfo.imageNum);
      if (imageKey.length === 0) {
        return resolve(false);
      }
      perf.addMark('cacheImage', start, { key: imageKey });
      imageInfo.cacheStatus++;
      const startTime = performance.now();
      const studyUID = imageInfo.sdc.studyInstanceUID;

      let fetchTime = 0;
      let imageWriteTime = 0;
      let totalTime = 0;
      let bResult = false;
      try {
        const image = imageInfo.sdc.imageTags[imageInfo.imageNum];
        const imageUID = image.sopInstanceUID;
        const frameNumber = image.frameNumber;

        // console.log(`${this.constructor.name} cacheImage ----------- ${imageKey}`);
        imageInfo.cacheStatus++;
        const exists = await this.opfsFileCacheService.imageFileExists(studyUID, '', imageUID, frameNumber);
        if (exists) {
          imageInfo.success = SUCCESS;
          // Already have the pixels for this image? no need to load them again from the server
          // console.info(`${this.constructor.name} cacheImage image already present for ${studyUID} ${seriesUID} ${imageKey} ${imageInfo.index}`);
          perf.addMark('cacheImage complete early', start, { key: imageKey, message: 'OPFS imageFile exists' });
          return resolve(exists);
        }
        // If this image is in our current missing image list, we won't bother to try loading it
        imageInfo.cacheStatus++;
        if (this.missingImages.hasErrorInfo(imageKey)) {
          perf.addMark('Missing Image', start, { key: imageKey });
          imageInfo.success = NO_SUCCESS;
          return resolve(false);
        }

        perf.addMark('getImagePixels start', start, { key: imageKey });
        // Fetch pixel data buffer from fovia
        imageInfo.cacheStatus++;
        const startFetchTime = performance.now();
        const data: Fovia.SourcePixelData | null = await this.getImagePixels(imageInfo.sdc, imageInfo.imageNum, frameNumber);
        // If our promise times-out, then we can get a null back. Not a fatal error
        if (data == null) {
          fetchTime = performance.now() - startFetchTime;
          totalTime = performance.now() - startTime;
          this.cacheTimingStatus.addNewImageStats(imageKey, 'fovia error/timeout getImagePixels', fetchTime, imageWriteTime, totalTime, 0, imageInfo.index);
          perf.addMark('getImagePixels failed', start, { key: imageKey });
          return resolve(bResult);
        }

        perf.addMark('getImagePixels complete', start, { key: imageKey });
        // Bail out when we're signaled to
        imageInfo.cacheStatus++;
        if (this.shouldStopCaching()) {
          console.warn(`${this.constructor.name} cacheImage shouldStopCaching detected bailing before writing pixel data for ${imageKey}`);
          perf.addMark('addImageToFileCache interrupted', start, { key: imageKey, message: 'stopped/paused by application' });
          return resolve(bResult);
        }

        let minMax: IMinMax | null = null;
        if (imageInfo.sdc.imageTags[imageInfo.imageNum].windowCenter == null || imageInfo.sdc.imageTags[imageInfo.imageNum].windowWidth == null) {
          // commenting out for now
          // minMax = this.getImagePixelsMinMax(data, imageInfo.sdc.imageTags[imageInfo.imageNum]);
          // console.log(`cacheImage  minMax - key=${imageKey}`, minMax);
        }

        imageInfo.cacheStatus++;
        fetchTime = performance.now() - startFetchTime;
        const startWriteTime = performance.now();
        // grab the image size before we pass this pixel array buffer off to worker thread for writing (and lose access)
        const imageByteLength = data.pixeldata.byteLength;
        // Add image data to opfs file cache
        const result = await this.opfsFileCacheService.addImageToFileCache(studyUID, '', imageUID, frameNumber, data, minMax);
        imageWriteTime = performance.now() - startWriteTime;
        totalTime = performance.now() - startTime;
        imageInfo.cacheStatus++;
        if (!result) {
          console.error(`${this.constructor.name} cacheImage failed to cache image data for ${imageKey}`);
          this.cacheTimingStatus.addNewImageStats(imageKey, 'opfs error', fetchTime, imageWriteTime, totalTime, 0, imageInfo.index);
          perf.addMark('addImageToFileCache failed', start, { key: imageKey });
          return resolve(bResult);
        }

        perf.addMark('addImageToFileCache complete', start, { key: imageKey });

        // console.info(`${this.constructor.name} cacheImage succeeded ${imageNum} ${sdc.studyInstanceUID} ${sdc.seriesInstanceUID} ${imageKey}`, data);
        // console.info(`${this.constructor.name} cacheImage succeeded ${imageNum} ${sdc.studyInstanceUID} ${sdc.seriesInstanceUID} ${imageKey}`);
        imageInfo.cacheStatus++;
        this.cacheTimingStatus.addNewImageStats(imageKey, '', fetchTime, imageWriteTime, totalTime, imageByteLength, imageInfo.index, SUCCESS);

        imageInfo.cacheStatus++;
        imageInfo.success = SUCCESS;
        this.currentStatusDetail.itemsCachedCount++;
        this.currentStatusDetail.lastCachedItem = imageInfo.index;
        // If this image was previously missing, remove it from our tracking list
        this.missingImages.removeMissingImage(imageKey);
        perf.addMark('cacheImage complete', start, { key: imageKey });
        bResult = true;
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name}:cacheImage failed ${studyUID} ${imageKey} exception encountered ${errCode}`);
        const totalTime = performance.now() - startTime;
        this.cacheTimingStatus.addNewImageStats(imageKey, 'exception encountered', fetchTime, imageWriteTime, totalTime, 0, imageInfo.index);
        this.currentStatusDetail.fatalError = true;
        perf.addMark('cacheImage exception', start, { key: imageKey });
      }
      return resolve(bResult);
    });
  }

  private getImagePixelsMinMax(data: Fovia.SourcePixelData, tags: Fovia.DICOMImageTags): IMinMax {
    const bytes = setFoviaBufferDataType(data.pixeldata, tags.bitsAllocated, tags.pixelRepresentation);
    const imageData = new Fovia.ImageData(bytes, null, null, true);
    return imageData.minMax;
  }

  private async getImagePixels(sdc: Fovia.SeriesDataContext, imageNum: number, frameNumber: number): Promise<Fovia.SourcePixelData | null> {
    const uniqueID = sdc.seriesInstanceUID + '.' + sdc.subSeriesID;
    const imageKey = this.makeImageKey(sdc, imageNum);
    if (imageKey.length === 0) {
      return null;
    }
    //
    // Get the image pixels
    let data: Fovia.SourcePixelData | null = null;
    try {
      const sopInstanceUID = sdc.imageTags[imageNum].sopInstanceUID;
      const byteCount = calcImagePixelsByteCountFromTags(sdc.imageTags[imageNum]);
      data = await downloadSourcePixelData(sdc.studyInstanceUID, sdc.seriesInstanceUID, sdc.subSeriesID, sopInstanceUID, imageNum, frameNumber, byteCount, this.computeUtilsService);
      if (data == null) {
        //  N.B. null may be returned for timeouts OR invalid pixel data  -- so would like to retry the timeouts. In the future
        //  we need to return a tuple which clarifies the problem for null case so we can enable the following line
        //   this.examLoadContext.markImageFrameAsInvalid(imageKey);
        console.error(`${this.constructor.name} getImagePixels failed for downloadSourcePixelData no image data (${imageNum} ${imageKey})`);
        this.missingImages.addMissingImage(imageKey, NO_IMAGE_DATA);
      }
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} getImagePixels failed for getSourcePixelData (${imageNum} ${uniqueID} ${imageKey}) ${errCode}`, err);
    }
    return data;
  }

  private sanityCheck(foviaExamSeries: Fovia.ScanDirSeriesResults[]): void {
    try {
      for (let i = 0; i < foviaExamSeries.length; i++) {
        const series = foviaExamSeries[i];
        if (series.seriesInstanceUID == null) {
          console.warn(`${this.constructor.name} sanityCheck series index ${i} has undefined seriesInstuanceUID for ${this.studyInstanceUID}' `);
        }
        const seriesStudyUID = series.dicomSeries?.studyInstanceUID ?? null;
        if (seriesStudyUID == null) {
          console.warn(`${this.constructor.name} sanityCheck series index ${i} with seriesInstanceUID '${series.dicomSeries?.seriesInstanceUID}' has undefined studyInstanceUid.  exam's studyInstanceUid is '${this.studyInstanceUID}' `);
        } else if (seriesStudyUID !== this.studyInstanceUID) {
          console.error(`${this.constructor.name} sanityCheck series index ${i} mismatch between exam study uid '${this.studyInstanceUID}' and series study uid expecting '${seriesStudyUID}'`);
        }
      }
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} sanityCheck failed ${errCode}`, err);
    }
  }

  private logFoviaSeriesInfo(foviaExam: Fovia.ScanDirSeriesResults[]): void {
    // test-test-test
    console.log(`${this.constructor.name} ----------------- Study Series Info for ${this.examDetail.examInfo.primary ? 'Primary' : 'Comparison'} Exam ${this.studyInstanceUID} ------------------------`, foviaExam);
    foviaExam.forEach(series => {

      if (series.isNonImageSeries) {
        console.info(`${this.constructor.name} Non Image Series`, series);
        return;
      }
      const seriesStudyUID = series.dicomSeries?.studyInstanceUID ?? null;

      if (seriesStudyUID == null) {
        console.warn(`${this.constructor.name} Image Series: series.dicomSeries.studyInstanceUID is null for ${this.studyInstanceUID}`, series);
      } else if (seriesStudyUID !== this.studyInstanceUID) {
        console.error(`${this.constructor.name} Image Series: mismatch between exam study uid '${this.studyInstanceUID}' and series study uid '${seriesStudyUID}'`);
      }
      if (series.containsSubSeries) {
        console.info(`${this.constructor.name} Image Series: Exam has sub-series: seriesDesc: ${series.dicomSeries?.seriesDescription ?? ''} subSeriesID: ${series.dicomSeries?.subSeriesID ?? -1} is3Dable: ${series.dicomSeries?.is3DableSeries ?? false} subseries-count:${series.subSeries?.length ?? 0}`);
        series.subSeries.forEach((sdc: Fovia.SeriesDataContext, index) => {
          console.log(`${this.constructor.name}   - ${index} subSeriesID: ${sdc.subSeriesID ?? -1} is3Dable: ${sdc.is3DableSeries ?? false} #images: ${sdc.getNumImages()}`);
          this.totalImagesInExam += sdc.getNumImages();
        });
      } else {
        const numImages = (series.dicomSeries?.getNumImages != null) ? series.dicomSeries.getNumImages() : 0;
        console.info(`${this.constructor.name} Image Series: seriesDesc: ${series.dicomSeries?.seriesDescription ?? ''} subSeriesID: ${series.dicomSeries?.subSeriesID ?? -1} is3Dable: ${series.dicomSeries?.is3DableSeries ?? false}  #images: ${numImages}`);
        this.totalImagesInExam += numImages;
      }

      // Determine the modality for this exam -- so that our stats are modality specific
      if (this.cacheTimingStatus.modality.length === 0 && series.dicomSeries != null) {
        this.cacheTimingStatus.modality = series.dicomSeries.modality;
        console.info(`${this.constructor.name} Modality is ${this.cacheTimingStatus.modality}`);
      }
    }
    );
    // test-test-test
    console.log(`------------------------------------------------------------`);
  }

  private makeImageKey(sdc: Fovia.SeriesDataContext, imageNum: number): string {

    try {
      const image = sdc.imageTags[imageNum];
      return makeImageKey(image.sopInstanceUID, image.frameNumber);

    } catch (err) {
      console.error(`${this.constructor.name} makeImageKey failed`, err);
    }
    return '';
  }

}
