import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Mutex } from 'async-mutex';

import {
  FOVIA_SR_PRESENTATION_SCHEMA_NONE,
  ICachedExamManifest,
  IFoviaStudySRData,
  makeImageKey
} from '@server-api';
import { EncryptionKeyService, IKeyIdPair } from './encryption-key.service';

import {
  CachedExamStats,
  CachedImageInfo,
  CachedStudyInfo,
  DiskInfo,
  FileInfo,
  IDiskInfo,
  IFileInfo,
  IMinMax,
  TrackCacheUsage,
  StudyStatus,
} from '../models';

import {
  cryptoIvToString,
  stringToCryptoIv,
  extractErrorCodeFromException,
  PV_ERRORS,
  setFileExceptionHandler,
  getOPFSRootDirectorySafe,
  getDirectoryHandleSafe,
  getFileSafe,
  ICachedImageInfo,
  ImageDirInfo,
  opfsGetExistingDirectoryHandle,
  getFileHandleSafe,
  opfsGetExistingFileHandle,
  removeEntrySafe,
  valuesSafe,
  opfsStoragePersistedSafe,
  opfsStoragePersistSafe,
  jsonParseSafe,
  PerfMeasure,
  PerfTiming
} from "@worker-compatible-api";
import { ComputeUtilsService } from "./compute-utils.service";
import { OpfsUtilsService } from "./opfs-utils.service";

const QUIET = true;
const CREATE_STUDY_DIR = true;
@Injectable({
  providedIn: 'root'
})
export class OpfsCacheService {
  /*
  OPFS Notes:
  1. file time-stamps are not supported -- to keep it "simple", we're using the epoch timestamp of when the image was cached.
  2. "Available disk space" is misleading -- it's the theoretical maximum OPFS could use, IFF it were free. There is
      no way to determine user's actual disk freespace.
  3. OPFS files are stored on "the system drive" -- which may or may-not be the c: drive
  4. Files are stored as 'persistent' or 'best-efforts'.
    a. persistent - may require user permission and doesn't have the advantage of just "going away"
    b. best-efforts (default) - allows the OS to "evict" OPFS files (all or none sort of thing) when there is disk-space pressure
  5. Two applications may be accessing the directory at the same time
    a. PulseVision - as it caches studies and manages the cache size
    b. SynthVision - as it loads pixel data for studies,
    c. SV uses the PulseVisionApi library directly -- we can make provisions for SV to communicate w/ PV if needed.

  PulseVision Directory Layout:
    <opfs root>
    ...
      | <synthCache directory>
        | <foviaImages directory>
          | studyInstanceUID 1 directory>
            | <examManifest directory>
              |<studyInstanceUID._manifest file>
              |<studyInstanceUID._manifestInfo file>
              |<studyInstanceUID._version file>
            | <examStats directory>
              |<studyInstanceUID._examStats file>
              |<studyInstanceUID._examStatsInfo file>
            | <sopInstanceUID-frame1 directory>
              | <sopInstanceUID-frame1._pixels file>
              | <sopInstanceUID-frame1._data file>
            | <sopInstanceUID-frameN directory>
            | ....
            | <last sopInstanceUID-frame directory>
            | ....
          | <studyInstanceUID ... directory>
          | ...
          | <last studyInstanceUID directory>
          | ...
  */
  protected opfsRoot: FileSystemDirectoryHandle | null = null;

  protected readonly cacheRootName = 'synthCache';
  protected readonly foviaImagesRootName = 'foviaImages';
  protected readonly manifestDirName = 'examManifest';
  protected readonly manifestFileSuffix = '_manifest';
  protected readonly manifestSRFileSuffix = '_manifestSRData';
  protected readonly manifestInfoFileSuffix = '_manifestInfo';
  protected readonly manifestVersionFileSuffix = '_version';
  protected readonly imagePixelFileSuffix = '_pixels';
  protected readonly imageDataFileSuffix = '_data';
  protected readonly examStatsDirName = 'examStats';
  protected readonly examStatsFileSuffix = '_examStats';
  protected readonly dicomTagsFileSuffix = '_dicomTags';
  protected readonly dicomTagsInfoFileSuffix = '_dicomTagsInfo';

  protected opfsSynthCache: FileSystemDirectoryHandle | null = null;
  protected opfsFoviaImages: FileSystemDirectoryHandle | null = null;

  protected cacheUsageInfoMap = new TrackCacheUsage();
  protected cachedExamStatsMap = new Map<string, CachedExamStats>();
  protected studyUIDMap = new Map<string, CachedStudyInfo>();
  protected studyUIDHandleMap = new Map<string, FileSystemDirectoryHandle>();

  // These are 'Map of Maps' structures.  The outer maps are keyed by StudyUID.  The inner maps are keyed by
  protected studyUIDChildDirHandlesMap = new Map<string, Map<string, FileSystemDirectoryHandle>>();
  protected studyUIDChildFileHandlesMap = new Map<string, Map<string, FileSystemFileHandle>>();

  protected inited = false;

  protected doImageCompression = false;
  protected doManifestCompression = true;
  protected doStatsCompression = true;
  protected doDicomTagsCompression = true;

  // Provide a mechanism to publish changes to the number of cached exams
  protected examCount$$: BehaviorSubject<number>;

  // Provide synchronization for long running rebuild operation
  protected rebuildMutex: Mutex;

  // Set to 'true' if this instance of the class will only be reading files from OPFS.  Intended to be set to 'true' for the viewer.
  protected readOnlyMode = false;

  public accumulatedReadTimeMs = 0;
  // Current UserID,
  public userId = '';

  constructor(
    private encryptionKeyService: EncryptionKeyService,
    private computeUtilsService: ComputeUtilsService,
    private opfsUtilsService: OpfsUtilsService) {

    this.examCount$$ = new BehaviorSubject<number>(0);
    this.rebuildMutex = new Mutex();
    this.rebuildMutex.acquire().then(()=> console.log(`>>> rebuildMutext acquired`));
    setFileExceptionHandler(err => {
      this.onFileException(err);
    });
  }

  public async init(readOnlyMode: boolean): Promise<void> {
    this.readOnlyMode = readOnlyMode;
    // Read the contents of OPFS cache and init the service
    await this.cacheInit();
    this.examCount$$.next(this.studyUIDMap.size);
    if (!this.readOnlyMode) {
      this.updateDiskSpaceInfo().then();
    }
  }

  public get examCount$(): Observable<number> {
    return this.examCount$$;
  }

  public get cacheQuotaError$(): Observable<boolean> {
    return this.cacheUsageInfoMap.cacheQuotaError$;
  }

  public get cacheQuotaError(): boolean {
    return this.cacheUsageInfoMap.cacheQuotaError;
  }

  public set cacheQuotaMB(value: number) {
    this.cacheUsageInfoMap.cacheQuotaMB = value;
  }

  public get cacheQuotaMB(): number {
    return this.cacheUsageInfoMap.cacheQuotaMB;
  }

  public get cacheUsageMB$(): Observable<number> {
    return this.cacheUsageInfoMap.cacheUsageMB$;
  }

  public get cacheUsageMB(): number {
    return this.cacheUsageInfoMap.cacheUsageMB;
  }

  public set opfsEvictionDetectionCount(value: number) {
    this.cacheUsageInfoMap.opfsEvictionDetectionCount = value;
  }

  public get opfsEvictionDetectionCount(): number {
    return this.cacheUsageInfoMap.opfsEvictionDetectionCount;
  }

  public get opfsEvictionDetectionCount$(): Observable<number> {
    return this.cacheUsageInfoMap.opfsEvictionDetectionCount$;
  }

  private set examCount(value: number) {
    this.examCount$$.next(value);
  }

  private get examCount(): number {
    return this.examCount$$.value;
  }

  // Called under two conditions
  // 1. construction of this class
  // 2. after eviction has been detected
  private async cacheInit(): Promise<boolean> {
    let result = false;
    if (!this.inited) {
      const perf = new PerfMeasure(`cacheInit`);
      const perfTime = new PerfTiming();
      perf.start();
      if (!this.rebuildMutex.isLocked()) {
        await this.rebuildMutex.acquire();
      }
      console.info(`${this.constructor.name} rebuild mutex acquired ${perfTime.elapsedSecondsMessage()}`);

      if (this.opfsEvictionDetectionCount > 0) {
        console.warn(`${this.constructor.name}:init after ${this.opfsEvictionDetectionCount} eviction`);
        this.clearAllMaps();
      }
      this.inited = true;
      this.opfsRoot = await getOPFSRootDirectorySafe();
      if (this.opfsRoot == null) {
        console.error(`${this.constructor.name}:init OPFS Root directory not found.`);
        this.rebuildMutex.release();
        perf.end({ status: `no opfsroot` });
        return result;
      }
      this.opfsSynthCache = await getDirectoryHandleSafe(this.opfsRoot, this.cacheRootName, { create: true });

      if (this.opfsSynthCache == null) {
        console.error(`${this.constructor.name}:init - this.opfsSynthCache undefined`);
        this.rebuildMutex.release();
        perf.end({ status: `no opfsroot handle` });
        return result;
      }
      this.opfsFoviaImages = await getDirectoryHandleSafe(this.opfsSynthCache, this.foviaImagesRootName, { create: true });

      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name}:init - this.opfsFoviaImages undefined`);
        this.rebuildMutex.release();
        perf.end({ status: `no fovia images handle` });
        return result;
      }

      // A read-only client does not use the cache maps.  Building them adds performance overhead.
      if (this.readOnlyMode) {
        this.rebuildMutex.release();
        perf.end({ status: `success readOnlyMode` });
        return true;
      }

      try {
        await this.rebuildCachedImageInfoAndExamStatsMap();
        // !! blow away cache here for debugging !!
        // await this.deleteDirectoryContents(this.opfsFoviaImages);

        // const cacheStats = await getDirectoryEntriesRecursive(this.opfsSynthCache);
        // console.log(`${this.constructor.name} init : cacheStats`, cacheStats);
        // console.log(`${this.constructor.name} init cachedImageMap  size:${this.cacheSizeMB.toFixed(2)}MB`, this.cachedImageInfoMap);

        this.examCount = this.studyUIDMap.size;
        perf.end({ status: `success NOt readOnlyMode` });
        result = true;
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name}:init - exception during rebuild ${errCode}`, err);
        perf.end({ status: `error exception` });
      } finally {
        this.rebuildMutex.release();

        // Prepare log message for startup performance

        const elapsedMs = perfTime.elapsedMs;
        const perfMessage = perfTime.elapsedSecondsMessage();
        const imageCount = this.cacheUsageInfoMap.cachedImageCount == 0 ? 1 : this.cacheUsageInfoMap.cachedImageCount;
        const timePerImage = (elapsedMs / imageCount).toFixed(3);
        const workerInfo = `useWorkers(${this.opfsUtilsService.canUseWorker})`;
        const examCount = `Exams: ${this.examCount.toLocaleString("en-US")}`;
        const imageCountMessage = `Images : ${this.cacheUsageInfoMap.cachedImageCount.toLocaleString("en-US")}`;
        const timeMessage = `completed in ${perfMessage}, per image ${timePerImage} ms`;
        const cacheUsageMB = `Cache Usage: ${Math.round(this.cacheUsageInfoMap.cacheUsageMB).toLocaleString("en-US")} MB / Quota: ${this.cacheUsageInfoMap.cacheQuotaMB.toLocaleString("en-US")} MB`

        console.info(`${this.constructor.name} rebuild mutex released ${workerInfo} Total Cached: ${imageCountMessage} ${examCount} ${timeMessage}`);
        console.info(`${this.constructor.name} ${cacheUsageMB}`);
      }
    }
    return result;
  }

  public async initComplete(): Promise<void> {
    await this.rebuildComplete();
  }

  public async cacheRootDirectoryExists(): Promise<boolean> {
    return new Promise(async (resolve) => {
      if (!this.opfsRoot) {
        return resolve(false);
      }
      const cacheRoot = await getDirectoryHandleSafe(this.opfsRoot, this.cacheRootName, { create: false });
      return resolve(cacheRoot != null);
    });
  }

  private async cacheWasEvicted(): Promise<boolean> {
    // After an eviction, everything in the origin's OPFS will be deleted, so
    //  checking for the existence of our OPFS root directory is a pretty solid way to detect eviction  ** as long as no operation
    //  that results in the re-creation of this root directory happens before this check is done **.  So, it requires that this
    //  check is done as soon as possible after eviction occurs.
    await this.rebuildMutex.acquire();
    const result = !(await this.cacheRootDirectoryExists());
    this.rebuildMutex.release();
    return result;
  }

  public async detectAndHandleCacheEviction(err: unknown | undefined = undefined): Promise<boolean> {
    // No handling for eviction in read-only mode
    if (this.readOnlyMode) {
      return false;
    }
    return new Promise(async (resolve) => {
      const evicted = await this.cacheWasEvicted();
      const errCode = (err != null) ? extractErrorCodeFromException(err) : PV_ERRORS.NOERROR;
      if (evicted) {
        // Using a queueMicrotask to let the current (failed) operation run its course before going into eviction recovery logic
        console.error(`${this.constructor.name} detectAndHandleCacheEviction evicted ${err} ${errCode} `);
        queueMicrotask(() =>
          this.opfsEvictionDetectionCount++);
      }
      return resolve(evicted);
    });
  }

  // NOTE: This method should be called in development only to support testing the apps behavior when OPFS is evicted
  public async simulateOpfsEviction(): Promise<void> {
    return new Promise(async (resolve) => {
      try {
        if (this.opfsRoot != null) {
          await this.opfsRoot?.removeEntry(this.cacheRootName, { recursive: true });
        }
      } catch (err) {
        console.error(`${this.constructor.name} simulateOpfsEviction returned an error`);
      }
      return resolve();
    });
  }

  public async storagePersisted(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const result = await opfsStoragePersistedSafe();
      const ret = (typeof result === 'boolean') ? result : false;
      console.info(`${this.constructor.name} storagePersisted returning ${ret}`);
      return resolve(ret);
    });
  }

  public async storagePersist(): Promise<boolean> {
    return new Promise(async (resolve) => {

      const result = await opfsStoragePersistSafe();
      const ret = (typeof result === 'boolean') ? result : false;
      console.info(`${this.constructor.name} storagePersist returning ${ret}`);
      return resolve(ret);
    });
  }

  public async getImageFromFileCache(studyUID: string,
    seriesUID: string,
    imageUID: string,
    frameNumber: number): Promise<IFileInfo | null> {

    const imageKey = makeImageKey(imageUID, frameNumber);

    return new Promise(async (resolve) => {
      const perf = new PerfMeasure(`opfs-read-image-${imageKey}`);
      perf.start();

      let result: IFileInfo | null = null;
      if (this.opfsFoviaImages == null) {
        // console.error(`${this.constructor.name} getImageFromFileCache ${studyUID} - FoviaImages directory does not exist`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const startGetStudyDir = performance.now();
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.error(`${this.constructor.name} getImageFromFileCache ${studyUID} opfsStudyDir == null.`);
        return resolve(result);
      }
      perf.addMark('getstudydirhandle', startGetStudyDir);

      // use the Fovia image key construct in the directory and filenames for the image
      const imageNameRoot = makeImageKey(imageUID, frameNumber);

      // each image has its own directory containing a file with information about the image and a file of pixel data
      const startGetImageDir = performance.now();
      const opfsImageDir = await this.getExistingImageDirectoryHandle(studyUID, opfsStudyDir, imageNameRoot);
      if (opfsImageDir == null) {
        // console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} opfsGetExistingDirectoryHandle ${imageNameRoot} returns null for ${imageNameRoot}`);
        return resolve(result);
      }
      perf.addMark('getimagedirhandle', startGetImageDir);

      const startGetPixelFile = performance.now();
      const imagePixelFileFn = imageNameRoot + this.imagePixelFileSuffix;
      const opfsImagePixelsFile = await this.getExistingFileHandle(studyUID, opfsImageDir, imagePixelFileFn);
      if (opfsImagePixelsFile == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} opfsGetExistingDirectoryHandle ${imagePixelFileFn} returns null for ${imageNameRoot}`);
        return resolve(result);
      }
      perf.addMark('getpixelfilehandle', startGetPixelFile);

      // start reading the pixel file now so that it can overlap with reading the data file
      const startReadPixelFile = performance.now();
      const encryptedPixelsPromise = this.readPixelFile(opfsImagePixelsFile, imageKey);

      const imageDataFileFn = imageNameRoot + this.imageDataFileSuffix;
      const opfsImageInfoFile = await this.getExistingFileHandle(studyUID, opfsImageDir, imageDataFileFn);
      if (opfsImageInfoFile == null) {
        // console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} opfsGetExistingDirectoryHandle ${imageDataFileFn} returns null for ${imageNameRoot}`);
        return resolve(result);
      }

      const contents = (await this.readImageInfoFile(opfsImageInfoFile, imageKey)) ?? '';
      const fileInfo: FileInfo | null = await FileInfo.deserialize(contents);
      if (fileInfo == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} jsonParseSafe result is null for ${imageNameRoot}`);
        return resolve(result);
      }

      if (fileInfo.cryptoIvStr == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} fileInfo.cryptoIvStr is null for ${imageNameRoot}`);
        return resolve(result);
      }
      if (fileInfo.cryptoKeyId == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} fileInfo.cryptoKeyId is null for ${imageNameRoot}`);
        return resolve(result);
      }
      // The info file data contains crypto key and IV.  Grab them and remove from the data
      const ivStr = fileInfo.cryptoIvStr;
      const keyId = fileInfo.cryptoKeyId;
      fileInfo.cryptoIvStr = null;
      fileInfo.cryptoKeyId = null;

      const cryptoIv = stringToCryptoIv(ivStr);
      const encryptionKey = await this.encryptionKeyService.getKeyForDecryption(keyId, studyUID);
      if (encryptionKey == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} unable to retrieve key for ${imageNameRoot}`);
        return resolve(result);
      }

      const encryptedPixels = await encryptedPixelsPromise;
      if (encryptedPixels == null) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} readPixelFile ${opfsImagePixelsFile.name} returns null for ${imageNameRoot}`);
        return resolve(result);
      }

      const decryptedPixels = await this.decryptArrayBuffer(encryptedPixels, encryptionKey, cryptoIv);
      if (!decryptedPixels || decryptedPixels.byteLength === 0) {
        console.warn(`${this.constructor.name} getImageFromFileCache '${studyUID} decryptArrayBuffer for ${imageNameRoot}`);
        return resolve(result);
      }

      fileInfo.pixeldata = this.doImageCompression ? await this.decompressArrayBuffer(decryptedPixels, 'gzip') : decryptedPixels;

      result = fileInfo;
      perf.end();
      return resolve(result);
    });
  }

  private async getFileSize(fileHandle: FileSystemFileHandle): Promise<number> {
    const file = await getFileSafe(fileHandle);
    if (file == null) {
      console.error(`${this.constructor.name} getFileSize 'getFileSafe ${fileHandle.name} returns null`);
      return 0;
    }
    return file.size;
  }

  private async readPixelFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<ArrayBuffer | null> {
    // When reading files one at a time, it only pays to use workers for large files.
    const useWorkerFileSizeThreshold = 0; // just use workers for now
    const fileSize = await this.getFileSize(fileHandle);
    const useWorker = this.opfsUtilsService.canUseWorker && (fileSize > useWorkerFileSizeThreshold);
    const opLogTag = useWorker ? 'pixelFileRead-worker' : 'pixelFileRead-main';
    return await this.readBinaryFile(fileHandle, useWorker, opLogTag, itemLogTag);
  }

  private async readManifestFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<ArrayBuffer | null> {
    // When reading files one at a time, it only pays to use workers for large files.
    const useWorkerFileSizeThreshold = 0; // just use workers for now
    const fileSize = await this.getFileSize(fileHandle);
    const useWorker = this.opfsUtilsService.canUseWorker && (fileSize > useWorkerFileSizeThreshold);
    const opLogTag = useWorker ? 'manifestFileRead-worker' : 'manifestFileRead-main';
    return await this.readBinaryFile(fileHandle, useWorker, opLogTag, itemLogTag);
  }

  private async readManifestInfoFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<string | null> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'manifestInfoFileRead-worker' : 'manifestInfoFileRead-main';
    return await this.readTextFile(fileHandle, true, opLogTag, itemLogTag);
  }

  private async readDicomTagstFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<ArrayBuffer | null> {
    // When reading files one at a time, it only pays to use workers for large files.
    const useWorkerFileSizeThreshold = 0; // just use workers for now
    const fileSize = await this.getFileSize(fileHandle);
    const useWorker = this.opfsUtilsService.canUseWorker && (fileSize > useWorkerFileSizeThreshold);
    const opLogTag = useWorker ? 'dicomTagsFileRead-worker' : 'dicomTagsFileRead-main';
    return await this.readBinaryFile(fileHandle, useWorker, opLogTag, itemLogTag);
  }

  private async readDicomTagsInfoFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<string | null> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'dicomtagsInfoFileRead-worker' : 'dicomtagsInfoFileRead-main';
    return await this.readTextFile(fileHandle, true, opLogTag, itemLogTag);
  }

  private async readImageInfoFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<string | null> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'imageInfoFileRead-worker' : 'imageInfoFileRead-main';
    return await this.readTextFile(fileHandle, true, opLogTag, itemLogTag);
  }
  private async readExamStatsFile(fileHandle: FileSystemFileHandle, itemLogTag: string): Promise<ArrayBuffer | null> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'examStatsFileRead-worker' : 'examStatsFileRead-main';
    return this.readBinaryFile(fileHandle, true, opLogTag, itemLogTag);
  }

  private async decompressArrayBuffer(compressedBuffer: ArrayBuffer, format: CompressionFormat): Promise<ArrayBuffer | null> {
    return await this.computeUtilsService.decompressArrayBuffer(compressedBuffer, format);
  }

  private async compressArrayBuffer(uncompressedBuffer: ArrayBuffer, format: CompressionFormat): Promise<ArrayBuffer | null> {
    return await this.computeUtilsService.compressArrayBuffer(uncompressedBuffer, format);
  }

  private async decryptArrayBuffer(encryptedBuffer: ArrayBuffer, key: CryptoKey | null, iv: Uint8Array<ArrayBuffer>): Promise<ArrayBuffer | null> {
    return await this.computeUtilsService.decryptArrayBuffer(encryptedBuffer, key, iv);
  }

  private async encryptArrayBuffer(unencryptedBuffer: ArrayBuffer, key: CryptoKey | null, iv: Uint8Array<ArrayBuffer>): Promise<ArrayBuffer | null> {
    return await this.computeUtilsService.encryptArrayBuffer(unencryptedBuffer, key, iv);
  }

  private async readBinaryFile(fileHandle: FileSystemFileHandle, canUseWorker: boolean, opLogTag: string, itemLogTag: string): Promise<ArrayBuffer | null> {
    return this.opfsUtilsService.readBinaryFile(fileHandle, canUseWorker, opLogTag, itemLogTag);
  }

  private async readTextFile(fileHandle: FileSystemFileHandle, canUseWorker: boolean, opLogTag: string, itemLogTag: string): Promise<string | null> {
    return await this.opfsUtilsService.readTextFile(fileHandle, canUseWorker, opLogTag, itemLogTag);
  }

  private async writePixelFile(fileHandle: FileSystemFileHandle, arrayBuffer: ArrayBuffer, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'pixelFileWrite-worker' : 'pixelFileWrite-main';
    return await this.opfsUtilsService.writeBinaryFile(fileHandle, arrayBuffer, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async writeManifestFile(fileHandle: FileSystemFileHandle, arrayBuffer: ArrayBuffer, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'manifestFileWrite-worker' : 'manifestFileWrite-main';
    return await this.opfsUtilsService.writeBinaryFile(fileHandle, arrayBuffer, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async writedManifestInfoFile(fileHandle: FileSystemFileHandle, contents: string, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'manifestInfoFileWrite-worker' : 'manifestInfoFileWrite-main';
    return await this.opfsUtilsService.writeTextFile(fileHandle, contents, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }
  private async writeDicomTagsFile(fileHandle: FileSystemFileHandle, arrayBuffer: ArrayBuffer, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'dicomTagsFileWrite-worker' : 'dicomTagsFileWrite-main';
    return await this.opfsUtilsService.writeBinaryFile(fileHandle, arrayBuffer, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async writeDicomTagsInfoFile(fileHandle: FileSystemFileHandle, contents: string, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'dicomTagsInfoFileWrite-worker' : 'dicomTagsInfoFileWrite-main';
    return await this.opfsUtilsService.writeTextFile(fileHandle, contents, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async writeImageInfoFile(fileHandle: FileSystemFileHandle, contents: string, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'imageInfoFileWrite-worker' : 'imageInfoFileWrite-main';
    return await this.opfsUtilsService.writeTextFile(fileHandle, contents, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async writeExamStatsFile(fileHandle: FileSystemFileHandle, arrayBuffer: ArrayBuffer, itemLogTag: string): Promise<boolean> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'examStatsFileWrite-worker' : 'examStatsFileWrite-main';
    return await this.opfsUtilsService.writeBinaryFile(fileHandle, arrayBuffer, true, opLogTag, itemLogTag, this.handleErrors.bind(this));
  }

  private async getStudyImageInfo(studyDirHandle: FileSystemDirectoryHandle, itemLogTag: string): Promise<ImageDirInfo[] | null> {
    const opLogTag = this.opfsUtilsService.canUseWorker ? 'getStudyImageInfo-worker' : 'getStudyImageInfo-main';
    return await this.opfsUtilsService.getStudyImageInfo(studyDirHandle, true, itemLogTag, opLogTag);
  }
  public async imageFileExists(studyUID: string,
    seriesUID: string,
    imageUID: string,
    frameNumber: number): Promise<boolean> {

    const imageKey = makeImageKey(imageUID, frameNumber);
    const markName = `opfs-image-exists.${imageKey}`;
    const markNameBase = `image-exists.${imageKey}`;
    const markNameBeg = `${markNameBase}.beg`;
    const markNameEnd = `${markNameBase}.end`;
    const perfMark = (markName: string, start: number): void => {
      performance.mark(`oie.${markName}`, {
        detail: { imageKey, duration: (performance.now() - start) }
      });
    }

    return new Promise(async (resolve) => {
      const startTime = performance.now();
      performance.mark(markNameBeg);

      let result = false;
      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} imageFileExists ${studyUID} - FoviaImages directory does not exist`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }

      const imageNameRoot = makeImageKey(imageUID, frameNumber);
      const imageDirName = this.getImageDirName(studyUID, imageNameRoot);
      if (this.cacheUsageInfoMap.has(imageDirName)) {
        return resolve(result);
      }
      // Keep checking, PulseVision App may have cached it, and it's not yet in the map for the stand-alone library
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        // Not an error, it may not be cached yet...
        return resolve(result);
      }

      const opfsImageDir = await this.getExistingImageDirectoryHandle(studyUID, opfsStudyDir, imageNameRoot, QUIET);
      if (opfsImageDir == null) {
        return resolve(result);
      }

      // split the pixels and general image info into 2 files
      const opfsImagePixelsFile = await this.getExistingFileHandle(studyUID, opfsImageDir, imageNameRoot + this.imagePixelFileSuffix, QUIET);
      const opfsImageInfoFile = await this.getExistingFileHandle(studyUID, opfsImageDir, imageNameRoot + this.imageDataFileSuffix, QUIET);

      if (opfsImagePixelsFile == null || opfsImageInfoFile == null) {
        return resolve(result);
      }
      result = true;
      performance.mark(markNameEnd);
      performance.measure(markName, {
        detail: {
          imageKey
        },
        start: markNameBeg,
        end: markNameEnd
      });
      return resolve(result);
    });
  }

  private async getExistingImageDirectoryHandle(studyUID: string, opfsDirectory: FileSystemDirectoryHandle, dirName: string, quiet: boolean = false): Promise<FileSystemDirectoryHandle | null> {
    let studyChildDirHandleMap = this.studyUIDChildDirHandlesMap.get(studyUID);
    if (!studyChildDirHandleMap) {
      studyChildDirHandleMap = new Map<string, FileSystemDirectoryHandle>();
      this.studyUIDChildDirHandlesMap.set(studyUID, studyChildDirHandleMap);
    }
    let childDirHandle = studyChildDirHandleMap.get(dirName) ?? null;
    if (!childDirHandle) {
      childDirHandle = await opfsGetExistingDirectoryHandle(opfsDirectory, dirName, quiet);
      if (childDirHandle != null) {
        studyChildDirHandleMap.set(dirName, childDirHandle);
      }
    }
    return childDirHandle;
  }

  private async getExistingFileHandle(studyUID: string, opfsDirectory: FileSystemDirectoryHandle, fileName: string, quiet: boolean = false): Promise<FileSystemFileHandle | null> {
    let studyChildFileHandleMap = this.studyUIDChildFileHandlesMap.get(studyUID);
    if (!studyChildFileHandleMap) {
      studyChildFileHandleMap = new Map<string, FileSystemFileHandle>();
      this.studyUIDChildFileHandlesMap.set(studyUID, studyChildFileHandleMap);
    }
    let childFileHandle = studyChildFileHandleMap.get(fileName) ?? null;
    if (!childFileHandle) {
      childFileHandle = await opfsGetExistingFileHandle(opfsDirectory, fileName, quiet);
      if (childFileHandle != null) {
        studyChildFileHandleMap.set(fileName, childFileHandle);
      }
    }
    return childFileHandle;
  }

  public async getExamSubDirectoryNames(studyUID: string): Promise<string[]> {
    return new Promise(async (resolve) => {
      let result: string[] = [];
      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} getExamSubDirectoryNames unexpected condition opfsFoviaImages is null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      const opfsStudyDir = await getDirectoryHandleSafe(this.opfsFoviaImages, studyUID, { create: false }, true);
      if (opfsStudyDir == null) {
        // console.error(`${this.constructor.name} getExamSubDirectoryNames ${studyUID} opfsStudyDir == null.`);
        return resolve(result);
      }

      // @ts-ignore - 'fromAsync()' and 'keys()' are in the runtime lib, but not in the types used by TS
      result = await Array.fromAsync(opfsStudyDir.keys());
      return resolve(result);
    });
  }

  public async studyExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      // console.log(`${this.constructor.name} studyExists ${studyUID} `,opfsStudyDir);
      return resolve(opfsStudyDir != null);
    });
  }

  // Cached studies are encrypted on a per user basis, so see if we have one for this user
  public studyExistsForCurrentUser(studyUID: string): boolean {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} studyExistsForCurrentUser method not available in readonly mode`);
      return false;
    }
    const info = this.studyUIDMap.get(studyUID);
    if (info == null) {
      console.log(`${this.constructor.name} studyExistsForCurrentUser ${studyUID} not found`);
      return false;
    }
    const bSameUser = info.userId === this.userId;
    // console.log(`${this.constructor.name} studyExistsForCurrentUser ${studyUID} saved for user ${info.userId} ${this.userId} ${bSameUser}`);
    return bSameUser;
  }

  public async addStudyUIDToFileCache(studyUID: string): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addStudyUIDToFileCache method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {

      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID, CREATE_STUDY_DIR);
      return resolve(opfsStudyDir != null);
    });
  }

  // FileSystemDirectoryHandle move method is not yet supported (aka renaming of files/directories). We'd prefer to write
  // our image directory to a temporary name, and then rename the directory when completed to avoid race conditions
  // between readers and writers for opfs.
  //
  // Add a new image subdirectory to the study folder and store an encrypted pixel file and info file.
  // If a failure occurs, remove the directory so we don't leave a "partial" image directory in place
  // https://github.com/GoogleChrome/developer.chrome.com/blob/main/site/en/articles/file-system-access/index.md
  public async addImageToFileCache(studyUID: string,
    seriesUID: string,
    imageUID: string,
    frameNumber: number,
    imageData: Fovia.SourcePixelData,
    minMax: IMinMax | null): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addImageToFileCache method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {
      let result = false;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} addImageToFileCache '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }

      const imageNameRoot = makeImageKey(imageUID, frameNumber);
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} addImageToFileCache '${studyUID}' getStudyDirectoryHandle is null for ${imageNameRoot}`);
        return resolve(result);
      }
      const opfsImageDir = await getDirectoryHandleSafe(opfsStudyDir, imageNameRoot, { create: true });
      if (opfsImageDir == null) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} opfsImageDir == null for ${imageNameRoot}`);
        return resolve(result);
      }

      // split the pixels and general image info into 2 files
      const opfsImagePixelsFile = await getFileHandleSafe(opfsImageDir, imageNameRoot + this.imagePixelFileSuffix, { create: true });
      if (opfsImagePixelsFile == null) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} opfsImagePixelsFile == null for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }
      const opfsImageInfoFile = await getFileHandleSafe(opfsImageDir, imageNameRoot + this.imageDataFileSuffix, { create: true });
      if (opfsImageInfoFile == null) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} opfsImageInfoFile == null for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }

      const keyIdPair: IKeyIdPair = await this.encryptionKeyService.getKeyForEncryption(studyUID);
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      // Add the key ID and iv in the image info and write the file
      // The image info file will contain all of the image data except the pixels, plus the encryption key ID and IV, userId and
      // cache time
      const imageInfo = new FileInfo(imageData);
      imageInfo.cryptoIvStr = cryptoIvToString(iv);
      imageInfo.cryptoKeyId = keyIdPair.keyId;
      imageInfo.minMax = minMax;
      imageInfo.cacheTime = Date.now(); // timestamp in milliseconds since epoc, used directly to determine Least Recently Cached
      imageInfo.userId = this.userId;
      const serialized = await imageInfo.serialize();
      if (serialized == null) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} imageInfo serialize failed for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }
      const infoFileSize = serialized.length;
      let writeFile = await this.writeImageInfoFile(opfsImageInfoFile, serialized, imageUID);
      if (!writeFile) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} writeImageInfoFile failed for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }

      // encrypt the pixels and write to file
      const pixels = this.doImageCompression
        ? await this.compressArrayBuffer(imageData.pixeldata as ArrayBuffer, 'gzip')
        : imageData.pixeldata as ArrayBuffer;
      const encryptedPixels = await this.encryptArrayBuffer(pixels as ArrayBuffer, keyIdPair.key, iv);
      if (!encryptedPixels) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} pixel encryption failed for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }

      // ----- testing ----
      // const ivStr = cryptoIvToString(iv);
      // const testIv = stringToCryptoIv(ivStr);
      // console.log('Image iv decryption test', iv, testIv);
      // const decryptedPixels = await decryptArrayBuffer(encryptedPixels as ArrayBuffer, keyIdPair.key, iv.buffer) as ArrayBuffer;
      //
      // const viewPixels = new Uint8Array(pixels);
      // const viewDecryptPixels = new Uint8Array(decryptedPixels);
      //
      // for (let i = 0; i < viewPixels.length; i++) {
      //   if (i >= viewDecryptPixels.length || viewDecryptPixels[i] !== viewPixels[i]) {
      //     console.error(`decyption test comparision error encountered at index ${i}`);
      //     break;
      //   }
      // }
      // ----- end testing ----
      const pixelFileSize = encryptedPixels.byteLength;
      writeFile = await this.writePixelFile(opfsImagePixelsFile, encryptedPixels, imageUID);
      if (!writeFile) {
        console.warn(`${this.constructor.name} addImageToFileCache ${studyUID} writePixelFile failed for ${imageNameRoot}`);
        await this.deleteDir(opfsStudyDir, imageUID);
        return resolve(result);
      }
      const cachedImageInfo = new CachedImageInfo(opfsImageDir.name, studyUID, infoFileSize + pixelFileSize);
      this.cacheUsageInfoMap.set(opfsImageDir.name, cachedImageInfo);
      this.updateStudyUIDMap(studyUID, imageInfo.cacheTime, imageInfo.userId);
      await this.updateDiskSpaceInfo();
      result = true;
      return resolve(result);
    });
  }

  public async examVersionFileExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} examVersionFileExists '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} examVersionFileExists ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }

      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName, QUIET);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} examVersionFileExists ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsVersionFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestVersionFileSuffix, QUIET);
      if (opfsVersionFile == null) {
        console.warn(`${this.constructor.name} examVersionFileExists ${studyUID} opfsGetExistingFileHandle ${studyUID + this.manifestVersionFileSuffix} == null`);
        return resolve(result);
      }
      result = true;
      console.info(`${this.constructor.name} examVersionFileExists exists for ${studyUID}`);
      return resolve(result);
    });
  }

  public async getExamVersionFromFileCache(studyUID: string): Promise<string | null> {
    return new Promise(async (resolve) => {
      const result: any | null = null;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} getExamVersionFromFileCache '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} getExamVersionFromFileCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} getExamVersionFromFileCache ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsVersionFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestVersionFileSuffix);
      if (opfsVersionFile == null) {
        console.warn(`${this.constructor.name} getExamVersionFromFileCache ${studyUID} opfsGetExistingFileHandle ${studyUID + this.manifestVersionFileSuffix} == null`);
        return resolve(result);
      }
      const examVersionFile = await getFileSafe(opfsVersionFile);
      if (examVersionFile == null) {
        console.warn(`${this.constructor.name} getExamVersionFromFileCache ${studyUID} getFileSafe ${opfsVersionFile.name} == null`);
        return resolve(result);
      }
      const contents = await examVersionFile.text();
      return resolve(contents);
    });
  }

  public async addDicomTagsToFileCache(studyUID: string, dicomJsonMetadata: any[] | null): Promise<number> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addDicomTagsToFileCache method not available in readonly mode`);
      return 0;
    }
    return new Promise(async (resolve) => {
      let result = 0;
      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} opfsStudyDir == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }

      if (dicomJsonMetadata == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} dicomJsonMetadata == null`);
        return resolve(result);
      }

      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsManifestDir = await getDirectoryHandleSafe(opfsStudyDir, this.manifestDirName, { create: true });
      if (opfsManifestDir == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} getDirectoryHandleSafe ${this.manifestDirName} failed`);
        return resolve(result);
      }

      const dicomTagsInfoFn = studyUID + this.dicomTagsInfoFileSuffix;
      const opfsDicomTagsInfoFile = await getFileHandleSafe(opfsManifestDir, dicomTagsInfoFn, { create: true });
      if (opfsDicomTagsInfoFile == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} getFileHandleSafe ${dicomTagsInfoFn} failed`);
        return resolve(result);
      }

      const dicomTagsFn = studyUID + this.dicomTagsFileSuffix;
      const opfsDicomTagsFile = await getFileHandleSafe(opfsManifestDir, dicomTagsFn, { create: true });
      if (opfsDicomTagsFile == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} getFileHandleSafe ${dicomTagsFn} failed`);
        return resolve(result);
      }

      // Prepare to encrypt dicom tags file
      const keyIdPair = await this.encryptionKeyService.getKeyForEncryption(studyUID);
      const iv = window.crypto.getRandomValues(new Uint8Array(12));

      // Add the key ID and iv to the dicom tags info and write the file
      const dicomTagInfo = {
        cryptoIvStr: cryptoIvToString(iv),
        cryptoKeyId: keyIdPair.keyId,
      };
      const content = JSON.stringify(dicomTagInfo);
      const dicomTagsInfoFileLength = content.length;
      let writeFile = await this.writeDicomTagsInfoFile(opfsDicomTagsInfoFile, content, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} dicomTagInfo writeFile failed`);
        return resolve(result);
      }

      // encrypt the manifest and write to file
      // const compressStartTime = performance.now();
      const dicomTagsArray = new TextEncoder().encode(JSON.stringify(dicomJsonMetadata));
      const dicomTagsBuffer = this.doDicomTagsCompression ?
        await this.compressArrayBuffer(dicomTagsArray.buffer, 'gzip') : dicomTagsArray.buffer;
      // const compressEndDate = performance.now();

      // const compressText = this.doDicomTagsCompression ? 'Compressing' : 'Not compressing';
      // const compressTime = compressEndDate - compressStartTime;
      // console.info(`${compressText} dicom tags took ${compressTime} ms`);

      if (dicomTagsBuffer == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} compressArrayBuffer failed`);
        return resolve(result);
      }
      const dicomTagsBufferLength = dicomTagsBuffer.byteLength;  // do this now because 'encryptArrayBuffer' worker takes ownership of dicomTagsBuffer
      const encryptedDicomTags = await this.encryptArrayBuffer(dicomTagsBuffer, keyIdPair.key, iv);
      if (encryptedDicomTags == null) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} encryptArrayBuffer failed`);
        return resolve(result);
      }

      // ----- testing ----
      // const ivStr = cryptoIvToString(iv);
      // const testIv = stringToCryptoIv(ivStr);
      // console.log('Dicom Tags iv decryption test', iv, testIv);
      // const decryptedManifest = await decryptArrayBuffer(encryptedDicomTags, keyIdPair.key, iv) as ArrayBuffer;
      //
      // const viewManifest = new Uint8Array(dicomTagsBuffer);
      // const viewDecryptManifest = new Uint8Array(decryptedManifest);
      //
      // for (let i = 0; i < viewManifest.length; i++) {
      //   if (i >= viewDecryptManifest.length || viewDecryptManifest[i] !== viewManifest[i]) {
      //     console.error(`decryption test comparison error encountered at index ${i}`);
      //     break;
      //   }
      // }
      // ----- end testing ----

      // The version consists of a 64 byte hex string
      writeFile = await this.writeDicomTagsFile(opfsDicomTagsFile, encryptedDicomTags, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addDicomTagsToFileCache ${studyUID} writeDicomTagsFile failed`);
        return resolve(result);
      }

      console.info(`${this.constructor.name} addDicomTagsToFileCache for ${studyUID} completed`);
      await this.updateDiskSpaceInfo();
      result = dicomTagsBufferLength + dicomTagsInfoFileLength;
      return resolve(result);
    });
  }

  public async getDicomTagsFromFileCache(studyUID: string): Promise<string | null> {
    return new Promise(async (resolve) => {
      let result: any | null = null;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} getDicomTagsFromFileCache '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsDicomTagsFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.dicomTagsFileSuffix);
      const opfsDicomTagsInfoFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.dicomTagsInfoFileSuffix);
      if (opfsDicomTagsFile == null || opfsDicomTagsInfoFile == null) {
        console.warn(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} opfsGetExistingFileHandle ${studyUID + this.dicomTagsFileSuffix} == null`);
        return resolve(result);
      }

      const contents = (await this.readDicomTagsInfoFile(opfsDicomTagsInfoFile, studyUID)) ?? '';
      const dicomTagInfo = jsonParseSafe(contents);
      if (dicomTagInfo == null) {
        console.warn(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} jsonParseSafe ${opfsDicomTagsInfoFile.name} == null`);
        return resolve(result);
      }

      // The info file data contains crypto key and IV.  Grab them and remove from the data
      const ivStr = dicomTagInfo.cryptoIvStr;
      const keyId = dicomTagInfo.cryptoKeyId;

      const cryptoIv = stringToCryptoIv(ivStr);
      const encryptionKey = await this.encryptionKeyService.getKeyForDecryption(keyId, studyUID);
      if (encryptionKey == null) {
        console.error(`${this.constructor.name} getDicomTagsFromFileCache '${studyUID} getKeyForDescription is null for key id '${keyId} `);
        return resolve(result);
      }
      const encryptedDicomTagBuffer = await this.readDicomTagstFile(opfsDicomTagsFile, studyUID);
      if (encryptedDicomTagBuffer == null) {
        console.error(`${this.constructor.name} getDicomTagsFromFileCache '${studyUID} readDicomTagsFile ${opfsDicomTagsFile.name} is null `);
        return resolve(result);
      }
      const decryptedDicomTagBuffer = await this.decryptArrayBuffer(encryptedDicomTagBuffer, encryptionKey, cryptoIv);
      if (!decryptedDicomTagBuffer || decryptedDicomTagBuffer.byteLength === 0) {
        console.error(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} decryptArrayBuffer fails for ${opfsDicomTagsFile.name} `);
        return resolve(result);
      }

      // const decompressStartTime = performance.now();
      const dicomTagBuffer = this.doDicomTagsCompression ? await this.decompressArrayBuffer(decryptedDicomTagBuffer, 'gzip') : decryptedDicomTagBuffer;
      // const decompressEndTime = performance.now();
      if (dicomTagBuffer == null) {
        console.error(`${this.constructor.name} getDicomTagsFromFileCache ${studyUID} dicomTagBuffer is null`);
        return resolve(result);
      }

      // const decompressText = this.doDicomTagsCompression ? 'Decompressing' : 'Not decompressing';
      // const decompressTime = decompressEndTime - decompressStartTime;
      // console.info(`${decompressText} dicom tags took ${decompressTime} ms`);

      const dicomTagString = new TextDecoder().decode(dicomTagBuffer);
      result = jsonParseSafe(dicomTagString);

      return resolve(result);
    });
  }

  public async dicomTagsFileExist(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} dicomTagsFileExist '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} dicomTagsFileExist ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }

      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName, QUIET);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} dicomTagsFileExist ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsDicomTagsFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.dicomTagsFileSuffix, QUIET);
      const opfsDicomTagsInfoFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.dicomTagsInfoFileSuffix, QUIET);
      if (opfsDicomTagsFile == null || opfsDicomTagsInfoFile == null) {
        console.warn(`${this.constructor.name} dicomTagsFileExist ${studyUID} opfsGetExistingFileHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      result = true;
      console.info(`${this.constructor.name} dicomTagsFileExist exists for ${studyUID}`);
      return resolve(result);
    });
  }

  public async manifestFileExists(studyUID: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      let result = false;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} manifestFileExists '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} manifestFileExists ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }

      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName, QUIET);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} manifestFileExists ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsManifestFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestFileSuffix, QUIET);
      const opfsManifestInfoFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestInfoFileSuffix, QUIET);
      if (opfsManifestFile == null || opfsManifestInfoFile == null) {
        console.warn(`${this.constructor.name} manifestFileExists ${studyUID} opfsGetExistingFileHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      result = true;
      console.info(`${this.constructor.name} manifestFileExists exists for ${studyUID}`);
      return resolve(result);
    });
  }

  public async getExamManifestFromFileCache(studyUID: string): Promise<ICachedExamManifest | null> {
    return new Promise(async (resolve) => {
      let result: ICachedExamManifest | null = null;
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      // Root directory for the study.  Maybe worth caching this handle?
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsManifestDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.manifestDirName);
      if (opfsManifestDir == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} opfsGetExistingDirectoryHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      const opfsManifestFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestFileSuffix);
      const opfsManifestSRFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestSRFileSuffix, true); // May not exist
      const opfsManifestInfoFile = await opfsGetExistingFileHandle(opfsManifestDir, studyUID + this.manifestInfoFileSuffix);
      if (opfsManifestFile == null || opfsManifestInfoFile == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} opfsGetExistingFileHandle ${this.manifestDirName} == null`);
        return resolve(result);
      }
      if (opfsManifestSRFile == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache No SR data cached with manifest for ${studyUID}`);
        // Do not fail in this case, the load will just be slower
      }
      const contents = (await this.readManifestInfoFile(opfsManifestInfoFile, studyUID)) ?? '';
      const manifestInfo = jsonParseSafe(contents);
      if (manifestInfo == null) {
        console.warn(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} jsonParseSafe ${opfsManifestInfoFile.name} == null`);
        return resolve(result);
      }

      // The info file data contains crypto key and IV.  Grab them and remove from the data.
      // An IV for SR data was added in Vision 2.1.1. Try and handle the "upgrade" case here.
      // - The IV for the manifest may use a different name
      // - The IV for the SR data may not be present at all
      const keyId = manifestInfo.cryptoKeyId;
      const ivStrManifest = manifestInfo.cryptoIvStrManifest || manifestInfo.cryptoIvStr;
      const ivStrSRData: string | undefined = manifestInfo.cryptoIvStrSRData; // May be missing
      let cryptoIvSRData: Uint8Array<ArrayBuffer> | null = null;
      if (ivStrSRData) {
        cryptoIvSRData = stringToCryptoIv(ivStrSRData);
      }

      const cryptoIvManifest = stringToCryptoIv(ivStrManifest);
      const encryptionKey = await this.encryptionKeyService.getKeyForDecryption(keyId, studyUID);
      if (encryptionKey == null) {
        console.error(`${this.constructor.name} getExamManifestFromFileCache '${studyUID} getKeyForDescription is null for key id '${keyId} `);
        return resolve(result);
      }

      const encryptedManifestBuffer = await this.readManifestFile(opfsManifestFile, studyUID);
      if (encryptedManifestBuffer == null) {
        console.error(`${this.constructor.name} getExamManifestFromFileCache '${studyUID}' readManifestFile ${opfsManifestFile.name} is null`);
        return resolve(result);
      }
      const decryptedManifestBuffer = await this.decryptArrayBuffer(encryptedManifestBuffer, encryptionKey, cryptoIvManifest);
      if (!decryptedManifestBuffer || decryptedManifestBuffer.byteLength === 0) {
        console.error(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} decryptArrayBuffer fails for ${opfsManifestFile.name}`);
        return resolve(result);
      }

      const manifestBuffer = this.doManifestCompression ? await this.decompressArrayBuffer(decryptedManifestBuffer, 'gzip') : decryptedManifestBuffer;
      if (manifestBuffer == null) {
        console.error(`${this.constructor.name} getExamManifestFromFileCache '${studyUID}' manifestBuffer is null`);
        return resolve(result);
      }
      const manifestString = new TextDecoder().decode(manifestBuffer);
      const manifestObject = jsonParseSafe(manifestString);

      // Load and decrypt the cached SR data for the exam, which may not be present
      // Support for caching SR data was added in Vision 2.1.1
      let examSRDataObject: IFoviaStudySRData | null = null;
      if (opfsManifestSRFile != null && cryptoIvSRData != null) {
        // In this case, expect all of the following to be successful.
        const encryptedSRDataBuffer = await this.readManifestFile(opfsManifestSRFile, `${studyUID}-SR`);
        if (encryptedSRDataBuffer == null) {
          console.error(`${this.constructor.name} getExamManifestFromFileCache '${studyUID}' readManifestFile ${opfsManifestSRFile.name} is null`);
          return resolve(result);
        }

        const decryptedSRDataBuffer = await this.decryptArrayBuffer(encryptedSRDataBuffer, encryptionKey, cryptoIvSRData);
        if (!decryptedSRDataBuffer || decryptedSRDataBuffer.byteLength === 0) {
          console.error(`${this.constructor.name} getExamManifestFromFileCache ${studyUID} decryptArrayBuffer fails for ${opfsManifestSRFile.name}`);
          return resolve(result);
        }
        const examSRDataBuffer = this.doManifestCompression ? await this.decompressArrayBuffer(decryptedSRDataBuffer, 'gzip') : decryptedSRDataBuffer;
        if (examSRDataBuffer == null) {
          console.error(`${this.constructor.name} getExamManifestFromFileCache '${studyUID}' examSRDataBuffer is null`);
          return resolve(result);
        }
        const examSRDataString = new TextDecoder().decode(examSRDataBuffer);
        examSRDataObject = jsonParseSafe(examSRDataString);
      }

      // If SR data is missing from the cache, provide an empty object that
      // indicates the SR data was missing (schema version NONE)
      if (examSRDataObject == null) {
        examSRDataObject = {
          foviaSchema: FOVIA_SR_PRESENTATION_SCHEMA_NONE,
          examVersion: undefined,
          imageSeriesUID: [],
          imageSeriesSR: {},
          errorSeriesUID: [],
          errorSeriesDesc: []
        };
      }

      return resolve({
        examManifest: manifestObject,
        examSRData: examSRDataObject
      });
    });
  }

  // Typescript 5.5 doesn't support opfs move api (aka renaming of files). We'd prefer to write
  // our image files to a temporary name, and then rename the file when completed to avoid race conditions
  // between readers and writers for opfs. issues.chromium.org suggests the API may not be implemented/working yet.

  public async addExamManifestToFileCache(studyUID: string, manifestJson: any, examSRData: IFoviaStudySRData, examVersion: string): Promise<number> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addExamManifestToFileCache method not available in readonly mode`);
      return 0;
    }
    return new Promise(async (resolve) => {
      let result = 0;
      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} opfsStudyDir == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }

      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsManifestDir = await getDirectoryHandleSafe(opfsStudyDir, this.manifestDirName, { create: true });
      if (opfsManifestDir == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} getDirectoryHandleSafe ${this.manifestDirName} failed`);
        return resolve(result);
      }
      // One file for the manifest, one for SR data, and one for decryption support
      const manifestFn = studyUID + this.manifestFileSuffix;
      const opfsManifestFile = await getFileHandleSafe(opfsManifestDir, manifestFn, { create: true });
      if (opfsManifestFile == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} getFileHandleSafe ${manifestFn} failed`);
        return resolve(result);
      }
      const manifestSRFn = studyUID + this.manifestSRFileSuffix;
      const opfsManifestSRFile = await getFileHandleSafe(opfsManifestDir, manifestSRFn, { create: true });
      if (opfsManifestSRFile == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} getFileHandleSafe ${manifestSRFn} failed`);
        return resolve(result);
      }
      const manifestInfoFn = studyUID + this.manifestInfoFileSuffix;
      const opfsManifestInfoFile = await getFileHandleSafe(opfsManifestDir, manifestInfoFn, { create: true });
      if (opfsManifestInfoFile == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} getFileHandleSafe ${manifestInfoFn} failed`);
        return resolve(result);
      }
      // Manifest version hash
      const examVersionFn = studyUID + this.manifestVersionFileSuffix;
      const opfsExamVersionFile = await getFileHandleSafe(opfsManifestDir, examVersionFn, { create: true });
      if (opfsExamVersionFile == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} getFileHandleSafe ${examVersionFn} failed`);
        return resolve(result);
      }
      // Prepare to encrypt manifest
      // The manifest and SR data use the same key, but different nonce
      const keyIdPair = await this.encryptionKeyService.getKeyForEncryption(studyUID);
      const ivManifest = window.crypto.getRandomValues(new Uint8Array(12));
      const ivSRData = window.crypto.getRandomValues(new Uint8Array(12));

      // Add the key ID and iv to the manifest info and write the file
      const manifestInfo = {
        cryptoIvStrManifest: cryptoIvToString(ivManifest),
        cryptoIvStrSRData: cryptoIvToString(ivSRData),
        cryptoKeyId: keyIdPair.keyId,
      };

      const content = JSON.stringify(manifestInfo);
      const manifestInfoFileLength = content.length;
      let writeFile = await this.writedManifestInfoFile(opfsManifestInfoFile, content, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} writing manifestInfoFile failed`);
        return resolve(result);
      }

      // encrypt the manifest and write to file
      const manifestArray = new TextEncoder().encode(JSON.stringify(manifestJson));
      const examSRDataArray = new TextEncoder().encode(JSON.stringify(examSRData));
      const manifestAndSRDataLength = manifestArray.byteLength + examSRDataArray.byteLength;
      const manifestBuffer = this.doManifestCompression
        ? await this.compressArrayBuffer(manifestArray.buffer as ArrayBuffer, 'gzip')
        : manifestArray.buffer;
      if (manifestBuffer == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} compressArrayBuffer failed`);
        return resolve(result);
      }
      const examSRDataBuffer = this.doManifestCompression
        ? await this.compressArrayBuffer(examSRDataArray.buffer as ArrayBuffer, 'gzip')
        : examSRDataArray.buffer;
      if (examSRDataBuffer == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} compressArrayBuffer failed`);
        return resolve(result);
      }
      const encryptedManifest = await this.encryptArrayBuffer(manifestBuffer as ArrayBuffer, keyIdPair.key, ivManifest);
      if (encryptedManifest == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} manifest encryptArrayBuffer failed`);
        return resolve(result);
      }
      const encryptedSRData = await this.encryptArrayBuffer(examSRDataBuffer as ArrayBuffer, keyIdPair.key, ivSRData);
      if (encryptedSRData == null) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} SRData encryptArrayBuffer failed`);
        return resolve(result);
      }
      // ----- testing ----
      // const ivStr = cryptoIvToString(ivManifest);
      // const testIv = stringToCryptoIv(ivStr);
      // console.log('Manifest iv decryption test', ivManifest, testIv);
      // const decryptedManifest = await decryptArrayBuffer(encryptedManifest as ArrayBuffer, keyIdPair.key, iv) as ArrayBuffer;
      //
      // const viewManifest = new Uint8Array(manifestBuffer);
      // const viewDecryptManifest = new Uint8Array(decryptedManifest);
      //
      // for (let i = 0; i < viewManifest.length; i++) {
      //   if (i >= viewDecryptManifest.length || viewDecryptManifest[i] !== viewManifest[i]) {
      //     console.error(`decryption test comparison error encountered at index ${i}`);
      //     break;
      //   }
      // }
      // const ivStr2 = cryptoIvToString(ivSRData);
      // const testIv2 = stringToCryptoIv(ivStr2);
      // console.log('SRData iv decryption test', ivSRData, testIv2);
      // const decryptedSRData = await this.decryptArrayBuffer(encryptedSRData as ArrayBuffer, keyIdPair.key, ivSRData) as ArrayBuffer;
      //
      // const viewSRData = new Uint8Array(examSRDataBuffer);
      // const viewDecryptSRData = new Uint8Array(decryptedSRData);
      //
      // for (let i = 0; i < viewSRData.length; i++) {
      //   if (i >= viewDecryptSRData.length || viewDecryptSRData[i] !== viewSRData[i]) {
      //     console.error(`decryption test comparison error encountered at index ${i}`);
      //     break;
      //   }
      // }
      // ----- end testing ----
      writeFile = await this.writeManifestFile(opfsManifestFile, encryptedManifest, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} writing encrypted manifest failed`);
        return resolve(result);
      }
      // Use same mechanism for SR data
      writeFile = await this.writeManifestFile(opfsManifestSRFile, encryptedSRData, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} writing encrypted SR data failed`);
        return resolve(result);
      }

      // The version consists of a 64 byte hex string
      writeFile = await this.writeFile(opfsExamVersionFile, examVersion, 'addExamManifestToFileCache-examVersion', studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addExamManifestToFileCache ${studyUID} writing examVersion file failed.`);
        return resolve(result);
      }

      console.info(`${this.constructor.name} addExamManifestToFileCache for ${studyUID} completed`);
      await this.updateDiskSpaceInfo();
      result = manifestAndSRDataLength + manifestInfoFileLength + examVersion.length;
      return resolve(result);
    });
  }

  public async publishDiskSpaceInfo(): Promise<void> {
    await this.updateDiskSpaceInfo();
  }

  public get diskSpaceInfo$(): Observable<IDiskInfo> {
    return this.cacheUsageInfoMap.diskInfo$;
  }

  public async addCachedExamStatsToCache(studyUID: string, cachedExamStats: CachedExamStats): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addCachedExamStatsToCache method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {
      let result = false;

      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} addCachedExamStatsToCache ${studyUID} FoviaImages directory does not exist`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }

      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);

      if (opfsStudyDir == null) {
        console.warn(`${this.constructor.name} addCachedExamStatsToCache ${studyUID} opfsStudyDir opfsStudyDir == null}`);
        return resolve(result);
      }
      const opfsExamStatsDir = await getDirectoryHandleSafe(opfsStudyDir, this.examStatsDirName, { create: true });
      if (opfsExamStatsDir == null) {
        console.warn(`${this.constructor.name} addCachedExamStatsToCache ${studyUID} opfsExamStatsDir getDirectoryHandleSafe is null`);
        return resolve(result);
      }
      // One file for the examStats not encrypted no PHI allowed in file.
      const opfsExamStatsFile = await getFileHandleSafe(opfsExamStatsDir, studyUID + this.examStatsFileSuffix, { create: true });
      if (opfsExamStatsFile == null) {
        console.warn(`${this.constructor.name} addCachedExamStatsToCache ${studyUID} opfsExamStatsFile getFileHandleSafe is null`);
        return resolve(result);
      }

      // compress examStats and write to file
      const examStatsArray = new TextEncoder().encode(JSON.stringify(cachedExamStats.stats));

      const examStatsBuffer = this.doStatsCompression
        ? await this.compressArrayBuffer(examStatsArray.buffer, 'gzip')
        : examStatsArray.buffer;
      if (examStatsBuffer == null) {
        console.error(`${this.constructor.name} addCachedExamStatsToCache  ${studyUID} compressArrayBuffer failed}`);
        return resolve(result);
      }
      // ----- testing ----
      //console.log(`examStatsArray ${examStatsArray.length} examStatsBuffer ${examStatsBuffer.byteLength}`);
      //const decompressedExamStatsBuffer = this.doStatsCompression ? await decompressArrayBuffer(examStatsBuffer, 'gzip') : examStatsBuffer;
      //if (decompressedExamStatsBuffer == null) {
      //  console.error(`decompression test decompressedExamStatsBuffer is null`);
      //  return resolve(result);
      //}
      //const viewStats = new Uint8Array(examStatsArray.buffer);
      //const viewDecompressedStats = new Uint8Array(decompressedExamStatsBuffer);
      //
      //for (let i = 0; i < viewStats.length; i++) {
      //  if (i >= viewDecompressedStats.length || viewDecompressedStats[i] !== viewStats[i]) {
      //    console.error(`decompression test comparision error encountered at index ${i}`,viewStats, viewDecompressedStats);
      //    break;
      //  }
      //}
      //
      // ----- end testing ----
      const writeFile = await this.writeExamStatsFile(opfsExamStatsFile, examStatsBuffer, studyUID);
      if (!writeFile) {
        console.error(`${this.constructor.name} addCachedExamStatsToCache  ${studyUID} writeFile failed}`);
        return resolve(result);
      }

      console.info(`${this.constructor.name} addCachedExamStatsToCache ${studyUID} completed`, cachedExamStats.stats, examStatsBuffer);
      this.updateExamStatsMap(studyUID, cachedExamStats);
      await this.updateDiskSpaceInfo();
      result = true;
      return resolve(result);
    });
  }
  public async updateCachedExamStatsToCache(studyUID: string, cachedExamStats: CachedExamStats): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} updateCachedExamStatsToCache method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {

      // connect the studyInfo to the stats object so we can get all study 'stats' in one request.
      let result = false;
      const studyInfo = this.studyUIDMap.get(studyUID);
      if (studyInfo != null) {
        console.warn(`${this.constructor.name} updateCachedExamStatsToCache updating study info for stats ${studyUID}`);
        console.log(`${this.constructor.name} updateCachedExamStatsToCache updating study info for stats ${studyUID}`, studyInfo, cachedExamStats.studyInfo);
        cachedExamStats.studyInfo = studyInfo;
      } else {
        console.warn(`${this.constructor.name} updateCachedExamStatsToCache study info for stats unchanged ${studyUID}`);
      }

      this.updateExamStatsMap(studyUID, cachedExamStats);

      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} updateCachedExamStatsToCache ${studyUID} - FoviaImages directory does not exist`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      if (opfsStudyDir == null) {
        console.error(`${this.constructor.name} updateCachedExamStatsToCache ${studyUID} opfsStudyDir == null`);
        return resolve(result);
      }
      const opfsExamStatsDir = await opfsGetExistingDirectoryHandle(opfsStudyDir, this.examStatsDirName, QUIET);
      if (opfsExamStatsDir == null) {
        console.error(`${this.constructor.name} updateCachedExamStatsToCache  ${studyUID} ${this.examStatsDirName} directory does not exist`);
        return resolve(result);
      }
      // One file for the examStats - no phi, so no encryption/decryption
      const examStatsfn = studyUID + this.examStatsFileSuffix;
      const opfsExamStatsFile = await opfsGetExistingFileHandle(opfsExamStatsDir, examStatsfn, QUIET);
      if (opfsExamStatsFile == null) {
        console.error(`${this.constructor.name} updateCachedExamStatsToCache ${studyUID} opfsGetExistingFileHandle ${examStatsfn} file is null`);
        return resolve(result);
      }

      const examStatsArray = new TextEncoder().encode(JSON.stringify(cachedExamStats.stats));

      const examStatsBuffer = this.doStatsCompression
        ? await this.compressArrayBuffer(examStatsArray.buffer, 'gzip')
        : examStatsArray.buffer;
      if (examStatsBuffer == null) {
        console.error(`${this.constructor.name} addCachedExamStatsToCache  ${studyUID} compressArrayBuffer failed}`);
        return resolve(result);
      }

      const writeFile = await this.writeExamStatsFile(opfsExamStatsFile, examStatsBuffer, studyUID);
      if (!writeFile) {
        return resolve(result);
      }

      await this.updateDiskSpaceInfo();
      result = true;
      console.info(`${this.constructor.name} updateCachedExamStatsToCache ${studyUID} completed`);
      console.log(`${this.constructor.name}`, cachedExamStats.stats);
      return resolve(result);
    });
  }

  private async writeFile(handle: FileSystemFileHandle, fileContents: FileSystemWriteChunkType | null, opLogTag: string, uid: string): Promise<boolean> {
    let result: boolean;
    if (typeof fileContents === 'string') {
      result = await this.opfsUtilsService.writeTextFile(handle, fileContents, true, opLogTag, uid, this.handleErrors.bind(this));
    } else if (fileContents instanceof ArrayBuffer) {
      result = await this.opfsUtilsService.writeBinaryFile(handle, fileContents, true, opLogTag, uid, this.handleErrors.bind(this));
    } else {
      result = false;
      console.error(`OpfsCacheService.writeFile: unexpected data type: ${typeof fileContents}`);
    }
    return result;
  }

  private async deleteDir(dirHandle: FileSystemDirectoryHandle, subDirName: string): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} deleteDir method not available in readonly mode`);
      return false;
    }
    const result = await removeEntrySafe(dirHandle, subDirName, { recursive: true });
    if (!result) {
      console.error(`${this.constructor.name} deleteDir removeEntrySafe for ${dirHandle.name} returned an error`);
    }
    return result;
  }

  private async updateDiskSpaceInfo(): Promise<DiskInfo> {
    let diskInfo = new DiskInfo();
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} updateDiskSpaceInfo method not available in readonly mode`);
      return diskInfo;
    }
    try {
      const start = performance.now();
      const spaceAvailable: StorageEstimate = await navigator.storage.estimate();
      const elapsed = performance.now() - start;
      diskInfo = this.cacheUsageInfoMap.updateDiskSpaceInfo(spaceAvailable);
      // console.log(`Disk usage ${diskInfo.totalUsageMB} in ${elapsed} ms`);
    } catch (err) {
      // Type error may be thrown by navigator.storage.estimate.
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} updateDiskSpaceInfo - failed: ${errCode}`, err);
    }
    return diskInfo;
  }

  private getImageDirName(studyUID: string, imageNameRoot: string): string {
    return `${studyUID}/${imageNameRoot}`;
  }

  private updateExamStatsMap(studyUID: string, cachedExamStats: CachedExamStats): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} updateExamStatsMap method not available in readonly mode`);
      return;
    }
    // console.log(`${this.constructor.name} updateExamStatsMap for ${studyUID}`, cachedExamStats.stats);
    this.cachedExamStatsMap.set(studyUID, cachedExamStats);
    this.examCount = this.studyUIDMap.size;
  }

  private removeExamStatsMap(studyUID: string): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} removeExamStatsMap method not available in readonly mode`);
      return;
    }
    console.log(`${this.constructor.name} Removing stats for ${studyUID}`);
    if (this.cachedExamStatsMap.has(studyUID)) {
      this.cachedExamStatsMap.delete(studyUID);
    } else {
      console.error(`${this.constructor.name} removeExamStatsMap unable to remove entry for ${studyUID}, it does not exist`);
    }
  }

  private updateStudyUIDMap(studyUID: string, cacheTime: number, userId: string): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} updateStudyUIDMap method not available in readonly mode`);
      return;
    }
    let studyInfo = this.studyUIDMap.get(studyUID);

    if (studyInfo == null) {
      studyInfo = new CachedStudyInfo(studyUID);
      studyInfo.userId = userId;
      this.addStudyUIDMap(studyUID, studyInfo);
      // console.log(`${this.constructor.name} updateStudyUIDMap creating new cachedStudyInfo ${studyUID}`, studyInfo);
    }
    studyInfo.updateStudyCacheTime(cacheTime);
  }

  private addStudyUIDMap(studyUID: string, cachedStudyInfo: CachedStudyInfo): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addStudyUIDMap method not available in readonly mode`);
      return;
    }
    // console.log(`${this.constructor.name} addStudyUIDMap cachedStudyInfo ${studyUID}`, cachedStudyInfo);
    this.studyUIDMap.set(studyUID, cachedStudyInfo);
    this.examCount = this.studyUIDMap.size;
  }

  private removeStudyUIDMaps(studyUID: string): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} removeStudyUIDMaps method not available in readonly mode`);
      return;
    }
    if (this.studyUIDHandleMap.has(studyUID)) {
      this.studyUIDHandleMap.delete(studyUID);
    }
    if (this.studyUIDChildDirHandlesMap.has(studyUID)) {
      this.studyUIDChildDirHandlesMap.delete(studyUID);
    }
    if (this.studyUIDChildFileHandlesMap.has(studyUID)) {
      this.studyUIDChildFileHandlesMap.delete(studyUID);
    }
    if (this.studyUIDMap.has(studyUID)) {
      console.log(`${this.constructor.name} Removing study UID for ${studyUID}`);
      this.studyUIDMap.delete(studyUID);
    }
    this.examCount = this.studyUIDMap.size;
  }

  private async getExamStatsFromFileCache(studyDirHandle: FileSystemDirectoryHandle): Promise<CachedExamStats | null> {

    return new Promise(async (resolve) => {
      let result: CachedExamStats | null = null;
      const studyUID = studyDirHandle.name;
      const opfsExamStatsDir = await opfsGetExistingDirectoryHandle(studyDirHandle, this.examStatsDirName);
      if (opfsExamStatsDir == null) {
        console.error(`${this.constructor.name} getExamStatsFromFileCache ${studyUID} opfsGetExistingDirectoryHandle ${this.examStatsDirName} failed.`);
        return resolve(result);
      }
      const examStatsFn = studyDirHandle.name + this.examStatsFileSuffix;
      const opfsExamStatsFile = await opfsGetExistingFileHandle(opfsExamStatsDir, examStatsFn);
      if (opfsExamStatsFile == null) {
        console.error(`${this.constructor.name} getExamStatsFromFileCache ${studyUID} opfsGetExistingFileHandle ${examStatsFn} failed.`);
        return resolve(result);
      }

      const examStatsFile = await this.readExamStatsFile(opfsExamStatsFile, studyUID);
      if (examStatsFile == null) {
        console.error(`${this.constructor.name} getExamStatsFromFileCache  ${studyUID} readExamStatsFile failed.`);
        return resolve(result);
      }
      const examStatsBuffer = this.doStatsCompression ? await this.decompressArrayBuffer(examStatsFile, 'gzip') : examStatsFile;
      if (examStatsBuffer == null) {
        console.error(`${this.constructor.name} getExamStatsFromFileCache  ${studyUID} decompressArrayBuffer failed}`);
        return resolve(result);
      }
      const examStatsString = new TextDecoder().decode(examStatsBuffer);

      const examStatsObj = jsonParseSafe(examStatsString);
      if (examStatsObj == null) {
        console.log(`${this.constructor.name} getExamStatsFromFileCache ${studyUID} jsonParse failed ${examStatsBuffer.byteLength}`, examStatsBuffer);
        console.error(`${this.constructor.name} getExamStatsFromFileCache ${studyUID} jsonParse failed ${examStatsBuffer.byteLength}`);
        return resolve(result);
      }
      // console.log(`${this.constructor.name} getExamStatsFromFileCache  ${studyUID} examStatsObj`, examStatsObj);
      // console.log(`${this.constructor.name} ${examStatsString}`, examStatsObj);
      const cachedStudyInfo = this.studyUIDMap.has(studyUID) ? this.studyUIDMap.get(studyUID) : null;
      result = new CachedExamStats(studyUID, examStatsObj, cachedStudyInfo);
      // console.log(`${this.constructor.name} ${examStatsString}`, cachedExamStats.stats);
      // console.log(`${this.constructor.name} getExamStatsFromFileCache  ${studyUID} studyInfo/CachedStats`, cachedStudyInfo, result.stats);
      return resolve(result);
    });
  }

  public async getCacheExamStats(studyInstanceUID: string): Promise<CachedExamStats | null> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} getCacheExamStats method not available in readonly mode`);
      return null;
    }
    return new Promise(async (resolve) => {
      // Guard race condition on startup while maps are being built, protect with critical section
      await this.rebuildComplete();
      if (this.cachedExamStatsMap.size === 0) {
        return resolve(null);
      }

      const cachedExamStats = this.cachedExamStatsMap.get(studyInstanceUID);
      if (cachedExamStats == null) {
        // When we initiate caching, we check to see if we already have stats for the study --
        // it's not always an error if they're not in the cache
        // console.info(`${this.constructor.name} getCacheExamStats  ${studyInstanceUID} not found`);
      } else {
        // console.info(`${this.constructor.name} getCacheExamStats  ${studyInstanceUID}`, cachedExamStats.stats);
      }
      return resolve(cachedExamStats ?? null);
    });
  }

  // Get the studyDirectoryHandle from a map if it exists or by getting it from OPFS, and proactively storing
  // it in the handle map for the next request.
  private async getStudyDirectoryHandle(studyUID: string, create: boolean = false): Promise<FileSystemDirectoryHandle | null> {
    return new Promise(async (resolve) => {
      if (this.opfsFoviaImages == null) {
        console.warn(`${this.constructor.name} getStudyDirectoryHandle '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(null);
      }
      let opfsStudyDir: FileSystemDirectoryHandle | undefined | null = undefined;
      if (this.studyUIDHandleMap.has(studyUID)) {
        opfsStudyDir = this.studyUIDHandleMap.get(studyUID);
      } else {
        opfsStudyDir = create ? await getDirectoryHandleSafe(this.opfsFoviaImages, studyUID, { create: true }) :
          await opfsGetExistingDirectoryHandle(this.opfsFoviaImages, studyUID, QUIET);
        if (opfsStudyDir != null) {
          this.studyUIDHandleMap.set(studyUID, opfsStudyDir);
        }
      }
      return resolve(opfsStudyDir ?? null);
    });
  }

  public async getCachedStudyUIDs(): Promise<string[]> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} getCachedStudyUIDs method not available in readonly mode`);
      return [];
    }
    return new Promise(async (resolve) => {
      await this.rebuildComplete();
      const uids: string[] = Array.from(this.studyUIDHandleMap.keys());
      return resolve(uids);
    });
  }

  public async clearExamCache(): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} clearExamCache method not available in readonly mode`);
      return false;
    }
    if (this.opfsFoviaImages == null) {
      console.error(`${this.constructor.name} clearExamCache - this.opfsFoviaImages undefined`);
      return false;
    }
    console.log(`${this.constructor.name} clearExamCache starting...`);
    // @ts-ignore
    // For each cached study...
    for (const studyDirHandle of this.studyUIDHandleMap.values()) {
      await this.removeAllStudyImagesFromFileCache(studyDirHandle.name);
    }
    await this.deleteDirectoryContents(this.opfsFoviaImages);
    console.log(`${this.constructor.name} clearExamCache finished...`);
    this.clearAllMaps();
    await this.rebuildCachedImageInfoAndExamStatsMap();
    await this.updateDiskSpaceInfo();
    return true;
  }

  // Removes study from opfs and all maps that track studies
  public async removeStudyFromCache(studyUID: string): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} removeStudyFromCache method not available in readonly mode`);
      return false;
    }
    let result = false;
    if (this.opfsFoviaImages == null) {
      console.error(`${this.constructor.name} removeStudyFromCache - this.opfsFoviaImages undefined`);
      this.detectAndHandleCacheEviction().then();
      return result;
    }
    const studyDirHandle = await this.getStudyDirectoryHandle(studyUID);
    if (studyDirHandle == null) {
      console.error(`${this.constructor.name} removeStudyFromCache nothing to do directory is null ${studyUID}`);
      return true;
    }
    result = await this.removeAllStudyImagesFromFileCache(studyUID);
    if (result) {
      result = await this.deleteDir(this.opfsFoviaImages, studyUID);
    }
    // console.log(`${this.constructor.name} removeStudyFromCache completed for ${studyUID} ${result}`);
    await this.updateDiskSpaceInfo();
    return result;

  }

  public clearOpfsHandlesForStudyUID(studyUID: string) {
    this.studyUIDHandleMap.delete(studyUID);
    this.studyUIDChildFileHandlesMap.delete(studyUID);
    this.studyUIDChildDirHandlesMap.delete(studyUID);
  }

  protected clearAllMaps(): void {
    this.studyUIDHandleMap.clear();
    this.studyUIDChildFileHandlesMap.clear();
    this.studyUIDChildDirHandlesMap.clear();
    this.studyUIDMap.clear();
    this.cachedExamStatsMap.clear();
    this.cacheUsageInfoMap.clear();
  }

  protected async rebuildComplete(): Promise<void> {
    if (this.rebuildMutex.isLocked()) {
      // console.log(`${this.constructor.name} rebuild mutex is locked`);
      await this.rebuildMutex.waitForUnlock();
      // console.log(`${this.constructor.name} rebuild mutex is unlocked`);
    }
  }

  protected async rebuildCachedImageInfoAndExamStatsMap(): Promise<void> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap method not available in readonly mode`);
      return;
    }
    if (this.opfsFoviaImages == null) {
      console.error(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap - this.opfsFoviaImages undefined`);
      return;
    }

    try {
      const perfTime = new PerfTiming();
      this.cacheUsageInfoMap.clear();
      console.log(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap starting...`);
      // For each cached study...
      const directoryIterator = valuesSafe(this.opfsFoviaImages);
      if (directoryIterator == null) {
        console.error(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap directoryIterator is null`);
        return;
      }
      // Prevent UI from being updated during rebuild so we minimize our UI cycles and
      // maximize cpu cycles spent for this rebuild.
      this.cacheUsageInfoMap.quietDuringRebuild = true;
      const promises = new Array<Promise<void>>();
      for await (const studyDirHandle of directoryIterator) {
        if (studyDirHandle.kind === 'directory') {
          this.addStudyDirHandle(studyDirHandle);
          // promises.push(this.addCachedExamStatsImageInfoToMap(studyDirHandle));
          await this.addCachedExamStatsImageInfoToMap(studyDirHandle);
          promises.push(this.addAllStudyImagesToCachedImageInfoMap(studyDirHandle));
        }
      }
      await Promise.allSettled(promises);
      this.cacheUsageInfoMap.quietDuringRebuild = false;

      console.info(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap finished ${perfTime.elapsedSecondsMessage()}`);
    } catch (err) {
      const errCode = extractErrorCodeFromException(err);
      console.error(`${this.constructor.name} rebuildCachedImageInfoAndExamStatsMap exception encountered ${errCode}`, err);
    }
  }

  public async cleanupIncompletelyCachedExams(): Promise<void> {
    // Evaluate the exam stats for each study, if it is incomplete, delete the exam
    // This may occur if Pulse Vision is shut down while it is in the process of caching.
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} cleanupIncompletelyCachedExams method not available in readonly mode`);
      return;
    }
    let count = 0;
    const examStatsList = Array.from(this.cachedExamStatsMap);
    for (const [key, value] of examStatsList) {
      if (value.studyStatus !== StudyStatus.eCACHED) {
        console.log(`${this.constructor.name} cleanupIncompleteCachedExams removing study ${key} '${value.studyStatus}'`);
        await this.removeStudyFromCache(key);
        count++;
      }
    }
    console.log(`${this.constructor.name} cleanupIncompleteCachedExams completed removed ${count} studies`);
    await this.updateDiskSpaceInfo();
  }

  protected addStudyDirHandle(handle: FileSystemDirectoryHandle): void {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addStudyDirHandle method not available in readonly mode`);
      return;
    }
    if (this.studyUIDHandleMap.has(handle.name)) {
      return;
    }
    this.studyUIDHandleMap.set(handle.name, handle);
  }

  protected async removeAllStudyImagesFromFileCache(studyUID: string): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} removeAllStudyImagesFromFileCache method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {
      let result = false;
      if (this.opfsFoviaImages == null) {
        console.error(`${this.constructor.name} removeAllStudyImagesFromFileCache '${studyUID}' opfsFoviaImages == null`);
        this.detectAndHandleCacheEviction().then();
        return resolve(result);
      }
      const opfsStudyDir = await this.getStudyDirectoryHandle(studyUID);
      try {
        if (opfsStudyDir == null) {
          return resolve(result);
        }
        await this.removeAllStudyImagesFromCachedImageInfoMap(studyUID);
        await this.deleteDirectoryContents(opfsStudyDir);
        result = true;
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name} removeAllStudyImagesFromFileCache ${studyUID}- failed: ${opfsStudyDir == null ? 'handle is null' : opfsStudyDir.name} ${errCode}`, err);
      }
      await this.updateDiskSpaceInfo();
      return resolve(result);
    });
  }

  protected async addAllStudyImagesToCachedImageInfoMap(studyDirHandle: FileSystemDirectoryHandle): Promise<void> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addAllStudyImagesToCachedImageInfoMap method not available in readonly mode`);
      return;
    }
    return new Promise(async (resolve) => {
      const studyUID = studyDirHandle.name;
      try {
        const imageDirInfo: ImageDirInfo[] | null = await this.getStudyImageInfo(studyDirHandle, 'addAllStudyImagesToCachedImageInfoMap');
        if (imageDirInfo) {
          for (const image of imageDirInfo) {
            const fileInfo: FileInfo | null = await FileInfo.deserialize(image.imageInfoFileContent);
            if (fileInfo == null) {
              console.error(`${this.constructor.name} addAllStudyImagesToCachedImageInfoMap study ${studyUID} image ${image.foviaImageKey} unable to parse data file`);
              continue;
            }

            const cachedImageInfo = new CachedImageInfo(image.foviaImageKey, image.studyUID, image.pixelsFileSizeBytes);
            this.cacheUsageInfoMap.set(cachedImageInfo.foviaImageKey, cachedImageInfo);
            this.updateStudyUIDMap(image.studyUID, fileInfo.cacheTime, fileInfo.userId);
          }
        } else {
          console.error(`${this.constructor.name} addAllStudyImagesToCachedImageInfoMap study ${studyUID} image missing all cachedImageInfo SERIOUS PROBLEM`);
        }
        return resolve();
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name} addAllStudyImagesToCachedImageInfoMap ${studyUID}- failed: ${errCode}`, err);
      }
    });
  }
  protected async addCachedExamStatsImageInfoToMap(studyDirHandle: FileSystemDirectoryHandle): Promise<void> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} addCachedExamStatsImageInfoToMap method not available in readonly mode`);
      return;
    }
    return new Promise(async (resolve) => {
      const studyUID = studyDirHandle.name;
      try {
        const cachedExmStats = await this.getExamStatsFromFileCache(studyDirHandle);
        if (cachedExmStats == null) {
          console.error(`${this.constructor.name} addCachedExamStatsImageInfoToMap ${studyUID} CachedExamStats file not found found removing exam`);
          await this.removeStudyFromCache(studyUID);
          return resolve();
        }
        this.updateExamStatsMap(studyUID, cachedExmStats);
      } catch (err) {
        const errCode = extractErrorCodeFromException(err);
        console.error(`${this.constructor.name} addCachedExamStatsImageInfoToMap  ${studyUID} exception ${errCode}`, err);
      }
      return resolve();
    });
  }

  protected async removeAllStudyImagesFromCachedImageInfoMap(studyUID: string): Promise<void> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} removeAllStudyImagesFromCachedImageInfoMap method not available in readonly mode`);
      return;
    }
    return new Promise(async (resolve) => {
      this.cacheUsageInfoMap.removeStudyImagesFromMap(studyUID);
      this.removeExamStatsMap(studyUID);
      this.removeStudyUIDMaps(studyUID);
      return resolve();
    });
  }

  protected async deleteDirectoryContents(directory: FileSystemDirectoryHandle): Promise<void> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} deleteDirectoryContents method not available in readonly mode`);
      return;
    }
    return new Promise(async (resolve) => {
      // @ts-ignore
      const directoryIterator = valuesSafe(directory);
      if (directoryIterator == null) {
        return resolve();
      }
      const promises = new Array<Promise<boolean>>();
      for await (const handle of directoryIterator) {
        if (handle == null) {
          console.error(`${this.constructor.name} deleteDirectoryContents null handle encountered for directory ${directory.name}`);
          continue;
        }
        promises.push(removeEntrySafe(directory, handle.name, { recursive: true }));
      }
      const results = await Promise.all(promises);
      return resolve();
    });
  }

  // OPFS may impose its own quota against our app, check to see if this has happened so
  // we can fail. More remediation of this issue may be required.
  // special handling for OPFS QUOTA_EXCEEDED
  private handleErrors(errorCode: PV_ERRORS): boolean {
    let fatalError = false;
    let cacheQuotaError = false;
    switch (errorCode) {
      case PV_ERRORS.QUOTA_EXCEEDED:
        fatalError = true;
        cacheQuotaError = true;
        break;
      // deliberate fall through
      case PV_ERRORS.NO_MODIFICATION_ALLOWED:
      case PV_ERRORS.NOT_ALLOWED:
      case PV_ERRORS.OFFSET_ERROR:
      case PV_ERRORS.ABORT:
      case PV_ERRORS.INVALID_STATE:
      case PV_ERRORS.INVALID_MODIFICATION: fatalError = true; break;
    }
    this.handleOPFSQuotaError(cacheQuotaError).then();
    return errorCode !== PV_ERRORS.NOERROR;
  }

  private onFileException(err: unknown): void {
    this.detectAndHandleCacheEviction(err).then();
  }

  private async handleOPFSQuotaError(cacheQuotaError: boolean): Promise<void> {
    if (cacheQuotaError) {
      // Using a queueMicrotask to let the current (failed) operation run its course before handling this error
      queueMicrotask(async () => {
        await this.updateDiskSpaceInfo();
        this.cacheUsageInfoMap.quotaErrorFromOPFS(cacheQuotaError);
      });
    } else {
      // Check for quota errors anytime we get a series error from opfs
      this.cacheUsageInfoMap.quotaErrorFromOPFS(cacheQuotaError);
    }
  }
}
