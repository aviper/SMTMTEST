import { Injectable } from '@angular/core';
import {
  closeSafe,
  createWriteableSafe,
  getFileSafe,
  getStudyImageInfo,
  ICachedImageInfo,
  ImageDirInfo,
  IOpfsWorker,
  OpfsWorkerFactoryFn,
  PerfMeasure,
  ImagePerfAggregator,
  PV_ERRORS,
  writeSafe,
} from "@worker-compatible-api";
import { WorkerPool } from '../utils';
import * as Comlink from "comlink";

class OpfsWorkerPool extends WorkerPool<IOpfsWorker> {}

// Provide a way to turn on /off web workers from browser console
let _opfsWebWorkersEnabled = true;
function _enableOpfsWebWorkers(enable: boolean) {
  _opfsWebWorkersEnabled = enable;
  console.warn(`enableOpfsWebWorkers: called with enable=${enable} `);
}
function _getOpfsWebWorkersEnabled(): boolean {
  console.warn(`getOpfsWebWorkersEnabled: returns ${_opfsWebWorkersEnabled} `);
  return _opfsWebWorkersEnabled;
}
(window as any).enableOpfsWebWorkers = _enableOpfsWebWorkers;
(window as any).getOpfsWebWorkersEnabled = _getOpfsWebWorkersEnabled;

@Injectable({
  providedIn: 'root'
})
export class OpfsUtilsService {
  protected workerPool: OpfsWorkerPool | null = null;
  protected readOnlyMode = false;
  public readonly workerPoolSize = 12;

  public binaryFileWritePerfAggregator = new ImagePerfAggregator();
  public textFileWritePerfAggregator = new ImagePerfAggregator();

  public binaryFileReadPerfAggregator = new ImagePerfAggregator();
  public textFileReadPerfAggregator = new ImagePerfAggregator();

  public getStudyImageInfoPerfAggregator = new ImagePerfAggregator();

  constructor() { }

  public async initWorkerPool(factoryFn: OpfsWorkerFactoryFn, readOnlyMode: boolean): Promise<void> {
    if (this.workerPool != null) {
      return;
    }
    this.readOnlyMode = readOnlyMode
    this.workerPool = new OpfsWorkerPool('OpfsWorker', factoryFn, this.workerPoolSize);
    await this.workerPool.init();
    console.log(`OpfsUtilsService.initWorkerPool:  poolSize = ${this.workerPoolSize}`);
  }

  public get canUseWorker(): boolean {
    return this.workerPool != null && _opfsWebWorkersEnabled;
  }

  // ------------------- STUDY LEVEL FUNCTIONS --------------------------
  public async getStudyImageInfo(studyDirHandle: FileSystemDirectoryHandle, canUseWorker: boolean, opLogTag: string, itemLogTag: string): Promise<ImageDirInfo[] | null> {
    this.getStudyImageInfoPerfAggregator.perfDetails.usingWorkers = (this.canUseWorker && canUseWorker);
    const perf = new PerfMeasure(opLogTag + '-' + itemLogTag);
    perf.start();

    const imageDirInfoArray = (this.canUseWorker && canUseWorker)
      ? await this.getStudyImageInfoWithWorker(studyDirHandle, opLogTag, itemLogTag)
      : await this.getStudyImageInfoMainThread(studyDirHandle, opLogTag, itemLogTag);

    // Timing in terms of number of images retrieved.
    const details = this.getStudyImageInfoPerfAggregator.addEvent(perf, imageDirInfoArray?.length ?? 0, itemLogTag);
    perf.end(details);

    return imageDirInfoArray;
  }

  public async getStudyImageInfoMainThread(studyDirHandle: FileSystemDirectoryHandle, opLogTag: string, itemLogTag: string): Promise<ImageDirInfo[] | null> {

    let studyImageInfo: ImageDirInfo[] | null = null;
    try {
      studyImageInfo = await getStudyImageInfo(studyDirHandle);
    } catch (error: unknown) {
      console.error(`getStudyImageInfoMainThread: caught exception`);
    }
    return studyImageInfo;
  }

  public async getStudyImageInfoWithWorker(studyDirHandle: FileSystemDirectoryHandle, opLogTag: string, itemLogTag: string): Promise<ImageDirInfo[] | null> {
    if (this.workerPool == null) {
      console.error(`getStudyImageInfoWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`getStudyImageInfoWithWorker: failed - no file reader`);
      return null;
    }
    let studyImageInfo: ImageDirInfo[] | null = null;
    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.getStudyImageInfo(studyDirHandle, opLogTag, itemLogTag);
      if (arrayBuf != null) {
        const decoder = new TextDecoder();
        const contents = decoder.decode(arrayBuf);
        studyImageInfo = JSON.parse(contents);
      }
    } catch (error: unknown) {
      console.error(`getStudyImageInfoWithWorkerr: caught exception`);
    }
    this.workerPool.releaseWorker(worker);
    // console.log(`getStudyImageInfoWithWorker - byteCount=${arrayBuf?.byteLength}`);
    return studyImageInfo;
  }

  // ------------------- FILE READING --------------------------

  public async readBinaryFile(fileHandle: FileSystemFileHandle, canUseWorker: boolean, opLogTag: string, itemLogTag: string): Promise<ArrayBuffer | null> {

    this.binaryFileReadPerfAggregator.perfDetails.usingWorkers = (this.canUseWorker && canUseWorker);
    const perf = new PerfMeasure(opLogTag + '-' + itemLogTag);
    perf.start();

    const arrayBuf = (this.canUseWorker && canUseWorker)
        ? await this.readBinaryFileWithWorker(fileHandle, opLogTag, itemLogTag)
        : await this.readBinaryFileWithMainThread(fileHandle, opLogTag, itemLogTag);

    const details = this.binaryFileReadPerfAggregator.addEvent(perf, arrayBuf?.byteLength ?? 0, itemLogTag);
    perf.end(details);

    return arrayBuf;

  }

  public async readTextFile(fileHandle: FileSystemFileHandle, canUseWorker: boolean, opLogTag: string, itemLogTag: string): Promise<string | null> {

    this.textFileReadPerfAggregator.perfDetails.usingWorkers = (this.canUseWorker && canUseWorker);
    const perf = new PerfMeasure(opLogTag + '-' + itemLogTag);
    perf.start();

    const contents = (this.canUseWorker && canUseWorker)
        ? await this.readTextFileWithWorker(fileHandle, opLogTag, itemLogTag)
        : await this.readTextFileWithMainThread(fileHandle, opLogTag, itemLogTag);

    const details = this.textFileReadPerfAggregator.addEvent(perf, contents?.length ?? 0, itemLogTag);
    perf.end(details);

    return contents;
  }


  public async readBinaryFileWithWorker(fileHandle: FileSystemFileHandle, opLogTag: string, itemLogTag: string): Promise<ArrayBuffer | null> {
    if (this.workerPool == null) {
      console.error(`readBinaryFileWithWorker: failed - no worker pool`);
      return null;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`readBinaryFileWithWorker: failed - no file reader`);
      return null;
    }
    let arrayBuf: ArrayBuffer | null = null;
    try {
      arrayBuf = await worker.readBinaryFile(fileHandle, opLogTag, itemLogTag);
    } catch (error: unknown) {
      console.error(`OpfsUtilsService.readBinaryFileWithWorker: caught exception`);
    }
    this.workerPool.releaseWorker(worker);
    // console.log(`readBinaryFileWithWorker - byteCount=${arrayBuf?.byteLength}`);
    return arrayBuf;
  }

  public async readBinaryFileWithMainThread(fileHandle: FileSystemFileHandle, opLogTag: string, itemLogTag: string): Promise<ArrayBuffer | null> {
    const file = await getFileSafe(fileHandle);
    if (file == null) {
      console.error(`${this.constructor.name} readFile 'getFileSafe ${fileHandle.name} returns null`);
      return null;
    }
    return file.arrayBuffer();
  }

  public async readTextFileWithWorker(fileHandle: FileSystemFileHandle, opLogTag: string, itemLogTag: string): Promise<string | null> {
    const arrayBuf = await this.readBinaryFileWithWorker(fileHandle, opLogTag, itemLogTag);
    if (arrayBuf == null) {
      console.error(`OpfsUtilsService.readTextFileWithWorker: this.readBinaryFileWithWorker failed`);
      return null;
    }
    // It might make sense to do the conversion to text in the web worker.  However, strings are
    // not transferable objects, so an extra memory copy would be required.
    let contents: string | null = null;
    try {
      const decoder = new TextDecoder();
      contents = decoder.decode(arrayBuf);
      // console.log(`readTextFileWithWorker - charCount=${contents.length}`);
    } catch (error: unknown) {
      console.error(`OpfsUtilsService.readTextFileWithWorker: caught exception decoding to string`);
    }
    return contents;
  }

  public async readTextFileWithMainThread(fileHandle: FileSystemFileHandle, opLogTag: string, itemLogTag: string): Promise<string | null> {
    const file = await getFileSafe(fileHandle);
    if (file == null) {
      console.error(`${this.constructor.name} readTextFileWithMainThread 'getFileSafe ${fileHandle.name} returns null`);
      return null;
    }
    return file.text();
  }

  // ------------------- FILE WRITING --------------------------

  public async writeBinaryFile(fileHandle: FileSystemFileHandle,
                               arrayBuffer: ArrayBuffer, // WARNING: If a worker is used here, the caller will lose access to this buffer
                               canUseWorker: boolean,
                               opLogTag: string,
                               itemLogTag: string,
                               onErrorFn: (errorCode: PV_ERRORS) => boolean): Promise<boolean> {

    this.binaryFileWritePerfAggregator.perfDetails.usingWorkers = (this.canUseWorker && canUseWorker);;
    const perf = new PerfMeasure(opLogTag + '-' + itemLogTag);
    perf.start();

    const result = (this.canUseWorker && canUseWorker)
        ? await this.writeBinaryFileWithWorker(fileHandle, arrayBuffer, opLogTag, itemLogTag)
        : await this.writeFileWithMainThread(fileHandle, arrayBuffer, opLogTag, itemLogTag, onErrorFn);

    const details = this.binaryFileWritePerfAggregator.addEvent(perf, result ? arrayBuffer.byteLength : 0, itemLogTag);
    perf.end(details);

    return result;
  }

  public async writeTextFile(fileHandle: FileSystemFileHandle,
                               contents: string,
                               canUseWorker: boolean,
                               opLogTag: string,
                               itemLogTag: string,
                               onErrorFn: (errorCode: PV_ERRORS) => boolean): Promise<boolean> {

    this.textFileWritePerfAggregator.perfDetails.usingWorkers = (this.canUseWorker && canUseWorker);;
    const perf = new PerfMeasure(opLogTag + '-' + itemLogTag);
    perf.start();

    const result = (this.canUseWorker && canUseWorker)
        ? await this.writeTextFileWithWorker(fileHandle, contents, opLogTag, itemLogTag)
        : await this.writeFileWithMainThread(fileHandle, contents, opLogTag, itemLogTag, onErrorFn);

    const details = this.textFileWritePerfAggregator.addEvent(perf, result ? contents.length : 0, itemLogTag);
    perf.end(details);

    return result;
  }

  private async writeBinaryFileWithWorker(fileHandle: FileSystemFileHandle,
                                          arrayBuffer: ArrayBuffer, // WARNING: the caller will lose access to this buffer
                                          opLogTag: string,
                                          itemLogTag: string): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} writeBinaryFileWithWorker method not available in readonly mode`);
      return false;
    }
    if (this.workerPool == null) {
      console.error(`opfsWorkerPool: failed - no worker pool`);
      return false;
    }
    const worker = await this.workerPool.acquireWorker();
    if (worker == null) {
      console.error(`writeBinaryFileWithWorker: failed - no file reader`);
      return false;
    }
    let ret = false;
    try {
      ret = await worker.writeBinaryFile(fileHandle, Comlink.transfer(arrayBuffer, [arrayBuffer]), opLogTag, itemLogTag); // Comlink.transfer makes the object transferable
    } catch (error: unknown) {
      console.error(`writeBinaryFileWithWorker: exception caught from worker.writeBinaryFile`);
      ret = false;
    }
    this.workerPool.releaseWorker(worker);
    // (`writeBinaryFileWithWorker - success=${ret}`);
    return ret;
  }

  private async writeTextFileWithWorker(fileHandle: FileSystemFileHandle,
                                        contents: string,
                                        opLogTag: string,
                                        itemLogTag: string): Promise<boolean> {
    let uint8Array: Uint8Array<ArrayBuffer> | null = null;
    try {
      const encoder = new TextEncoder();
      uint8Array = encoder.encode(contents);
    } catch (error: unknown) {
      console.error(`writeTextFileWithWorker: exception caught from text encoding`);
    }
    return (uint8Array == null) ? false : this.writeBinaryFileWithWorker(fileHandle, uint8Array.buffer, opLogTag, itemLogTag);
  }

  public async writeFileWithMainThread(handle: FileSystemFileHandle,
                                       fileContents: FileSystemWriteChunkType | null,
                                       opLogTag: string,
                                       itemLogTag: string,
                                       onErrorFn: (errorCode: PV_ERRORS) => boolean): Promise<boolean> {
    if (this.readOnlyMode) {
      console.error(`${this.constructor.name} writeFile method not available in readonly mode`);
      return false;
    }
    return new Promise(async (resolve) => {
      let result = false;
      if (handle == null) {
        console.error(`${this.constructor.name} writeFile ${opLogTag} ${itemLogTag} handle cannot be null`);
        resolve(result);
        return;
      }
      if (fileContents == null) {
        console.error(`${this.constructor.name} writeFile ${opLogTag} ${itemLogTag} fileContents cannot be null`);
        resolve(result);
        return;
      }
      const writeable = await createWriteableSafe(handle);
      if (writeable == null) {
        console.error(`${this.constructor.name} writeFile ${opLogTag} ${itemLogTag} createWriteableSafe ${handle.name} failed`);
        resolve(result);
        return;
      }
      let error: PV_ERRORS = await writeSafe(writeable, fileContents);
      if (onErrorFn(error)) {
        const index = error as unknown as keyof typeof PV_ERRORS;
        console.error(`${this.constructor.name}  writeFile ${opLogTag}  ${itemLogTag} writeSafe ${handle.name} failed  ${PV_ERRORS[index]}`);
        // per OPFS, cannot close failed writeable stream, so don't try
        resolve(result);
        return;
      }

      error = await closeSafe(writeable);
      if (onErrorFn(error)) {
        const index = error as unknown as keyof typeof PV_ERRORS;
        console.error(`${this.constructor.name}  writeFile ${opLogTag} ${itemLogTag} closeSafe ${handle.name} failed  ${PV_ERRORS[index]}`);
        resolve(result);
        return;
      }
      result = true;
      resolve(result);
    });
  }
}
