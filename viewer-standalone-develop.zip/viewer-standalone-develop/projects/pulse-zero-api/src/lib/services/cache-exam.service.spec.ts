import { TestBed } from '@angular/core/testing';

import { CacheExamService } from './cache-exam.service';

describe('CacheExamService', () => {
  let service: CacheExamService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CacheExamService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
