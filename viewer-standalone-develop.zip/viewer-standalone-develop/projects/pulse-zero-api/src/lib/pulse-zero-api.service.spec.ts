import { TestBed } from '@angular/core/testing';

import { PulseVisionApiService } from './pulse-zero-api.service';

describe('PulseVisionApiService', () => {
  let service: PulseVisionApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PulseVisionApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
