# PulseVisionApi

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.3.0.

## Code scaffolding

Run `ng generate component component-name --project pulse-zero-api` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project pulse-zero-api`.
> Note: Don't forget to add `--project pulse-zero-api` or else it will be added to the default project in your `angular.json` file.

## Build

Run `ng build pulse-zero-api` to build the library. The build artifacts will be stored in the `dist/` directory.
Run `npm run pulseVision-api` will build the library and its dependencies

## Publishing

After building your library with `ng build pulse-zero-api`, go to the dist folder `cd dist/pulse-zero-api` and run `npm publish`.

## Running unit tests

Run `ng test pulse-zero-api` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
