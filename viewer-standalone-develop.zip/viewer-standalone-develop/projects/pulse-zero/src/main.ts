import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { initializeDefaultLogger } from '@pulse-zero-api';

if (environment.production) {
  enableProdMode();
  initializeDefaultLogger('serverinfo');
} else {
  initializeDefaultLogger('console');
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
