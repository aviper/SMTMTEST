import { version, buildDate, commitHash, UDI } from '../../../synth-view/src/environments/version.prod';
import { IEnvironment, NA } from './environment-interface';
// Set defaults for production environment
export const environment: IEnvironment = {
    production: true,
    version: version ? version : NA,
    buildDate: buildDate ? buildDate : NA,
    commitHash: commitHash ? commitHash : NA,
    UDI: UDI ? UDI : NA
};
