export const NA = 'N/A';

export interface IEnvironment {
  production: boolean;
  version: string;
  buildDate: string;
  commitHash: string;
  UDI: string;
};
