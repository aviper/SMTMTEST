import { Component } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import {
  IDiskInfo,
  PulseVisionApiService
} from '@pulse-zero-api';

import {
  LogSupport
} from '@server-api';

import {
  ExamCacheManagementService
} from '../services';


const NO_USER_TOKEN = 'no token';
@Component({
  standalone: false,
  selector: 'app-exam-info',
  templateUrl: './exam-info.component.html',
  styleUrl: './exam-info.component.scss'
})
export class ExamInfoComponent {
  public offerBuiltInStudySelection = false;
  public estimatedTotalDiskSpaceMB = '';
  public totalUsageMB = '';
  public pulseVisionUsageMB = '';
  public diskStatus = '';
  public examCount = 0;
  public readonly PAUSE_CACHING = 'Pause Caching';
  public readonly RESUME_CACHING = 'Resume Caching';
  private _studyUIDs = '';
  private _persistentOPFSIsChecked$$: BehaviorSubject<boolean>;

  constructor(
    private examCacheManagementService: ExamCacheManagementService,
    private pulseVisionService: PulseVisionApiService
  ) {
    this.examCacheManagementService.publishDiskSpaceInfo().then();
    this._persistentOPFSIsChecked$$ = new BehaviorSubject<boolean>(false);
    this.examCacheManagementService.storagePersisted().then((value: boolean) => this._persistentOPFSIsChecked$$.next(value));
    this.examCacheManagementService.storagePersist().then((result) => this._persistentOPFSIsChecked$$.next(result));
  }

  public get userToken(): string {
    return this.pulseVisionService.userCredentials ? this.pulseVisionService.userCredentials.authToken : NO_USER_TOKEN;
  }

  public get cacheReport$(): Observable<string> {
    return this.examCacheManagementService.cacheReport$;
  }

  public get deletionCount(): number {
    return this.examCacheManagementService.selectedStudies.length;
  }

  public get isCaching$(): Observable<boolean> {
    return this.examCacheManagementService.isCaching$;
  }
  public onChangedUsersDiskQuotadMB(value: number): void {
    console.log(`onChangedUsersDiskQuotadMB got ${value}`);
    LogSupport.logInfo(`onChangedUsersDiskQuotadMB got ${value}`);
    this.examCacheManagementService.cacheQuotaMB = value;
  }

  public get cacheQuotaMB$(): Observable<number> {
    return this.examCacheManagementService.cacheQuotaMB$;
  }
  public get cacheQuotaMessage$(): Observable<string> {
    return this.examCacheManagementService.cacheQuotaMessage$;
  }
  /**
   * https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria
   * Data for an origin can be stored in two ways in a browser, persistent and best-effort:
   *
   * Best-effort (default): this is the way that data is stored by default. Best-effort data persists
   *   as long as the origin is below its quota, the device has enough storage space, and the
   *   user doesn't choose to delete the data via their browser's settings. when the browser needs to
   *   evict best-effort data, it does so without interrupting the user. (n.b. PulseVision experience is this
   *   can happen at any time).
   * Persistent: an origin can opt-in to store its data in a persistent way. Data stored this
   *   way is only evicted, or deleted, if the user chooses to, by using their browser's settings.
   *   To learn more, see When is data evicted.
   *
   * Based on our testing, persistent selection does not result in OPFS reporting that storage is persistend
   * when a HTTP connection is in use. Cache Manager always selects persistent by default.
   * When using HTTPS OPFS does report that that persistence is selected and it shows in the UI
   *
   * In Firefox, when a site chooses to use persistent storage, the user is notified with a UI
   * popup that their permission is requested.
   *
   * Safari and most Chromium-based browsers, such as Chrome or Edge, automatically approve or deny
   * the request based on the user's history of interaction with the site and do not show any prompts to the user.
   *
   * (MDN says) Note that research from the Chrome team shows that data is very rarely deleted by the browser.
   * If a user visits a website regularly, there is very little chance that its stored data, even in best-effort
   * mode, will get evicted by the browser. This is not our Pulse Zero Experience whan a C: drive has only 2-3GB and
   * storage is only 300MB.
   *
   * User's can turn on persistent OPFS storage, but they can't turn it off until the cache is cleared
   */

  public get persistentOPFSIsChecked$(): Observable<boolean> {
    return this._persistentOPFSIsChecked$$;
  }

  public set persistentOPFSIsChecked(value: boolean) {
    console.log(`persistentOPFSIsChecked ${value}`);
    LogSupport.logInfo(`persistentOPFSIsChecked ${value}`);
    this.examCacheManagementService.storagePersist().then((result) => this._persistentOPFSIsChecked$$.next(result));
  }

  public onPersist(value: boolean): void {
    if (value) {
      this.persistentOPFSIsChecked = value;
    }
  }

  public onClearCacheClicked(): void {
    console.log(`clear cache clicked`);
    LogSupport.logInfo(`clear cache clicked`);
    this.examCacheManagementService.clearExamCache().then();
  }

  public onReloadDocumentClicked(): void {
    window.location.reload();
  }

  public onDeleteSelections(): void {
    console.log(`delete selections clicked`);
    LogSupport.logInfo(`delete selections clicked`);
    this.examCacheManagementService.deleteSelectedStudies().then();
  }

  public onPauseResumeCaching(): void {
    if (this.examCacheManagementService.cachingPaused) {
      console.log(`user pressed resume caching`);
      LogSupport.logInfo(`user pressed resume caching`);
      this.examCacheManagementService.resumeCaching();
    } else {
      console.log(`user pressed pause caching`);
      LogSupport.logInfo(`user pressed pause caching`);
      this.examCacheManagementService.stopCaching().then();
    }
  }

  public onDisconnectFovia(): void {
    let message = `user pressed disconnect fovia`;
    console.log(message);
    LogSupport.logInfo(message);
    this.examCacheManagementService.terminateFoviaConnection().then(
      () => {
        message = 'fovia terminate completed';
        console.log(message);
        LogSupport.logInfo(message);
      }
    );
  }

  public onGetDiskInfo(): void {
    console.log(`getDisk info clicked`);
    LogSupport.logInfo(`getDisk info clicked`);
    this.examCacheManagementService.publishDiskSpaceInfo().then();
  }

  public get diskInfo$(): Observable<IDiskInfo> {
    return this.examCacheManagementService.getDiskInfo$();
  }

  public get cacheUsageMB$(): Observable<number> {
    return this.pulseVisionService.cacheUsageMB$;
  }

  public get quotaError$(): Observable<boolean> {
    return this.examCacheManagementService.quotaError$;
  }



}
