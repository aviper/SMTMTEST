import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';

import { PulseVisionApiModule } from '@pulse-zero-api';
import { ServerApiModule } from '@server-api';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { ExamInfoComponent } from './exam-info-component/exam-info.component';
import { ExamStatusComponent } from './exam-status-component/exam-status.component';
import { UserInfoComponent } from './user-info-component/user-info.component';
import { CacheStatusNotifierService, CacheStatusStoreService, ControlService, ExamCacheManagementService } from './services';
import { CustomErrorHandlerService } from './services/custom-error-handler.service';


@NgModule({
  declarations: [
    ExamInfoComponent,
    ExamStatusComponent,
    UserInfoComponent,
    AppComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    ClipboardModule,
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatListModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    PulseVisionApiModule,
    ServerApiModule
  ],
  exports: [],
  providers: [
    CacheStatusNotifierService,
    CacheStatusStoreService,
    ControlService,
    ExamCacheManagementService,
    provideHttpClient(withInterceptorsFromDi()),
    { provide: ErrorHandler, useClass: CustomErrorHandlerService },
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
