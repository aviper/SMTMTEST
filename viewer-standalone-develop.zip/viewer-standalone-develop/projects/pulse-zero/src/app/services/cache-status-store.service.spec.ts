import { TestBed } from '@angular/core/testing';

import { CacheStatusStoreService } from './cache-status-store.service';

describe('CacheStatusStoreServiceService', () => {
  let service: CacheStatusStoreService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CacheStatusStoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
