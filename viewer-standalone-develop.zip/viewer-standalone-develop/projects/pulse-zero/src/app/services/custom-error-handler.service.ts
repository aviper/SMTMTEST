import { ErrorHandler, Injectable } from '@angular/core';
import { ControlService } from './control.service';

// Backstop for exceptions that aren't caught anywhere else
@Injectable({
  providedIn: 'root'
})
export class CustomErrorHandlerService extends ErrorHandler {

  constructor(private controlService: ControlService) {
    super();
  }

  public override handleError(error: any): void {
    super.handleError(error);
    try {
       // for now, let's keep this pretty simple - avoid infinite error loops.
       // todo: log error message to cloud here.  That's apt to be asynchronous - be careful
       this.controlService.notifyCrashError();
    } catch (err) {
       try {
         // maybe log an error to cloud here
       } catch (err) {
         // yikes! give up - do nothing
       }
    }
  }
}
