import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';

import { Idb, IdbExamGroupStatus, IdbExamStatus } from '@idgital/pulse-vision-interface';
import { IExamCacheStatus, IExamGroupCacheStatus } from '@server-api';

// Service to store current cache-status of cached exams and exam groups in pulse-vision-cache index db.
// This DB is shared with Synth OS Front end
// Interface assumes that enum CacheStatus is the same as IdbExamStatus
const NOT_SET = -1;
@Injectable({
  providedIn: 'root'
})
export class CacheStatusStoreService {
  private cacheStatusDB = new Idb();

  private inited: boolean = false;

  private userId: number = NOT_SET
  public cacheStatusUpdated$$ = new ReplaySubject<boolean>(1);
  public constructor() { }

  public async init(userId: number): Promise<void> {
    try {
      this.userId = userId;
      await this.cacheStatusDB.init();
      if (this.userId === NOT_SET) {
        throw 'Invalid user id';
      }
      console.info(`${this.constructor.name} init() complete for cacheStatus DB userId:${this.userId}`);
      this.inited = true;
    } catch (err) {
      console.error(`${this.constructor.name} init() FAILED for cacheStatus DB userId: ${this.userId}`, err);
    }
  }

  public get isInited(): boolean {
    return this.inited;
  }
  
  public async recordCount(): Promise<number> {
    if (this.notReady()) {
      return -1;
    }
    return new Promise(async (resolve) => {
      try {
        const info = await this.cacheStatusDB.getAllExamStatusesByUserId(this.userId);
        return resolve(info.length);
      } catch (err) {
        console.error(`${this.constructor.name} recordCount DB failed to update status for ${this.userId}`, err);
      }
      return resolve(-1);
    });
  }
  public async updateExamCacheStatus(examCacheStatus: IExamCacheStatus): Promise<void> {
    if (this.notReady()) {
      return;
    }
    return new Promise(async (resolve) => {
      const status: Omit<IdbExamStatus, 'id'> = {
        userId: this.userId,
        studyUid: examCacheStatus.studyUID,
        status: examCacheStatus.cacheStatus
      };
      try {
        await this.cacheStatusDB.putExamStatus(status);
        this.notifyCacheStatusUpdated();
        console.log(`${this.constructor.name} updateExamCacheStatus DB ${this.userId}`, status);
      } catch (err) {
        console.error(`${this.constructor.name} updateExamCacheStatus DB failed to update status for ${this.userId} ${examCacheStatus.studyUID} ${examCacheStatus.cacheStatus}`, err);
      }
      return resolve();
    });
  }

  public async updateExamGroupCacheStatus(examGroupCacheStatus: IExamGroupCacheStatus): Promise<void> {
    if (this.notReady()) {
      return;
    }

    return new Promise(async (resolve) => {
      const status: Omit<IdbExamGroupStatus, 'id'> = {
        userId: this.userId,
        groupId: examGroupCacheStatus.orderId,
        status: examGroupCacheStatus.examGroupCacheStatus
      };
      try {
        await this.cacheStatusDB.putExamGroupStatus(status);
        this.notifyCacheStatusUpdated();
        console.log(`${this.constructor.name} updateExamGroupCacheStatus DB updated ${this.userId}`, status);
      } catch (err) {
        console.error(`${this.constructor.name} updateExamGroupCacheStatus DB failed to update status for ${this.userId} ${examGroupCacheStatus.orderId} ${examGroupCacheStatus.examGroupCacheStatus}`, err);
      }
      return resolve();
    });
  }

  public async deleteUserCacheStatus(): Promise<void> {
    if (this.notReady()) {
      console.warn(`${this.constructor.name} deleteUserCacheStatus unable to delete DB content for user ${this.userId} not ready`);
      return;
    }

    return new Promise(async (resolve) => {
      try {
        await this.cacheStatusDB.deleteUserStatuses(this.userId);
        this.notifyCacheStatusUpdated();
      } catch (err) {
        console.error(`${this.constructor.name} deleteUserCacheStatus failed for user ${this.userId}`, err);
      }
      return resolve();
    });
  }

  private notReady(): boolean {
    const result = !this.inited || this.userId === NOT_SET;
    if (!this.inited) {
      console.error(`${this.constructor.name} notReady DB not yet inited for ${this.userId}`);
    } else if (this.userId == NOT_SET) {
      console.error(`${this.constructor.name} notReady DB userId not set`);
    }
    return result;
  }

  private notifyCacheStatusUpdated(): void {
    this.cacheStatusUpdated$$.next(true);
  }
}
