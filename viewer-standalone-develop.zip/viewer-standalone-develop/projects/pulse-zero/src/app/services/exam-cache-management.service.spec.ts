import { TestBed } from '@angular/core/testing';

import { ExamCacheManagementService } from './exam-cache-management.service';

describe('ExamCacheManagementService', () => {
  let service: ExamCacheManagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExamCacheManagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
