import { Injectable, NgZone } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { filter, Observable, ReplaySubject, Subject, takeUntil } from 'rxjs';
import { Mutex } from 'async-mutex';

import { CacheStatus } from '@idgital/cache-status-interface';
import { CacheStatusStoreService } from './cache-status-store.service';

import { CachedExamStats, StudyStatus } from '@pulse-zero-api';

import { ExamGroup, ExamInformation, IExamCacheStatus, IExamGroupCacheStatus, ServerApiService } from '@server-api';
import { ExamCacheStatus, ExamGroupCacheStatus } from './types/cach-status.types';

// Track the status of ExamGroups being actively cached, and
// the status of studies held in the cache.
// Need to be able to:
// 1. Track progress of cache status individual studies
//    a. Provided by new ExamGroup caching requests
//    b. Found in the OPFS cache, and not yet connected to an exam group
// 2. Report caching status of individual exams
//    a. As they are actively being cached
//    b. Whenever they are 'discovered' in the cache at startup
//    c. As they are purged from the cache during operation
// 3. As each exam completes caching, the caching status of all
//    exam groups which reference the study are updated. There may be more than one.
//    This occurs when:
//    a. two or more studies are acquired for a patient on the
//    same visit.
//    b. these new studies may share relevant priors which are being cached
//    c. these new studies may become 'relevant' to one another.
// 4. As studies are purged from the cache
//    a. We report their cache status as not cached
// 5. When ExamGroups drop off of the current caching list
//    a. We remove the ExamGroup from tracking
//    b. We do not report the ExamGroup as "not cached" at the time it is removed
//    c. We leave the studies associated with the exam group in the tracking
//       tables as long as they are physically present in the cache
// 6. When a new exam arrives that refers to studies that are already cached
//    a. We update the cache Status of the examGroup and report it
//    b. Any exams which are not being tracked are added for tracking
// 7. We clear this tracker when
//    a. We detect an eviction (assuming we can continue operating, which is not clear yet)
// 8. On startup we notify the cache-status-service to:
//    a. clear (delete) all cache status for this 'user'.
//    b. as the cache is restored, the cache status of each individual exam for 'this' user
//       is reported as 'cached'
//    c. there may be other studies in this cache for other users, their caching status is **not*
//      reported.
//
// This class tracks examGroup reltionships to studies and vice-versa to support all of these operations.
// Ideally, we would:
// 1. Update Exam Cache Status no more than 3 times for each exam
//    a. Not-cached -> Caching
//    b. Caching -> Cached
//    c. Caching -> Purged for Caching -> Not-Cached
// 2. Update ExamGroupStatus no more than 3 times for each ExamGroup
//    a. Not-cached -> Caching
//    b. Caching -> Cached
//    c. Caching -> Purged for Caching -> Not-Cached
const NOT_SET = -1;

@Injectable({
  providedIn: 'root'
})
export class CacheStatusNotifierService {

  public reportStartupStats = true;
  private unsubscribe$$ = new Subject<void>();
  // Only one instance of a paricular studyUID is cached by Pulse Vision
  // These maps establish the relationship between studies and their associate examGroups.
  // ExamGroupCacheStatus objects refer to ExamCacheStatus objects between these two maps
  private studyUIDStatusMap = new Map<string, ExamCacheStatus>();
  private studyUIDExamGroupMap = new Map<string, ExamGroupCacheStatus[]>();
  private examGroupDefinitionMap = new Map<number, ExamGroupCacheStatus>();
  // Map used to access IExamGroupDefinition and ExamGroupCacheStatus information
  // private orderIdExamGroupMap = new Map<number, ExamGroupTraker>();

  private examCacheStatus$$ = new ReplaySubject<IExamCacheStatus[]>(1);
  private examGroupStatus$$ = new ReplaySubject<IExamGroupCacheStatus>(1);
  private examGroupCacheComplete$$ = new ReplaySubject<number>(1);
  private startupStats: CachedExamStats[] = [];
  private userId: number = NOT_SET;
  private dbInitMutex: Mutex = new Mutex();

  constructor(
    private cacheStatusStoreService: CacheStatusStoreService,
    private serverApiService: ServerApiService,
    private ngZone: NgZone) {
    this.subscribe();
  }

  public async init(): Promise<void> {
    this.reportStartupStats = true;
    this.studyUIDExamGroupMap.clear();
    this.studyUIDStatusMap.clear();
    this.examGroupDefinitionMap.clear();
    if (!this.dbInitMutex.isLocked()) {
      await this.dbInitMutex.acquire();
    }
  }

  public get examGroupCacheComplete$(): Observable<number> {
    return this.examGroupCacheComplete$$;
  }

  public get cacheStatusUpdated$(): Observable<boolean> {
    return this.cacheStatusStoreService.cacheStatusUpdated$$;
  }

  // On startup, report the stats of exams that are found in the cache
  public startupStatus(examStats: CachedExamStats[]): void {
    this.startupStats = examStats;
  }

  public async reInit(): Promise<void> {
    await this.init();
    await this.initCacheStatusService(this.userId);
  }

  // Publishing of startupStatus must wait for this notification to occur
  public async initCacheStatusService(userId: number): Promise<void> {
    this.userId = userId;
    await this.cacheStatusStoreService.init(this.userId);
    this.dbInitMutex.release();
  }

  // When OPFS init completes, ensure we update the
  // cache status for the (previously) cached exams just once
  // Depending on how long it takes to gather the stats from OPFS
  // these stats may arrive before we're ready to send them to
  // the cache status service. Make sure we've cleared the cache
  // status service before we start to report the startup stats.
  public async updateStartupCacheStatus(): Promise<void> {
    if (this.dbInitMutex.isLocked()) {
      await this.dbInitMutex.waitForUnlock();
    }
    if (this.reportStartupStats) {
      console.info(`DB is Inited ${this.cacheStatusStoreService.isInited} before delete recordCount ${await this.cacheStatusStoreService.recordCount()}`);
      await this.cacheStatusStoreService.deleteUserCacheStatus();
      console.info(`DB is Inited ${this.cacheStatusStoreService.isInited} after delete recordCount ${await this.cacheStatusStoreService.recordCount()}`);
      if (this.startupStats.length > 0) {
        this.reportStartupCacheStatus();
        console.info(`DB is Inited ${this.cacheStatusStoreService.isInited} after status udate recordCount ${await this.cacheStatusStoreService.recordCount()}`);
      }
      this.reportStartupStats = false;
    }
  }

  protected reportStartupCacheStatus(): void {
    for (const stats of this.startupStats) {
      // Add the previously cached exams to our tracking and assign it's cached status from the stats
      this.addOrUpdateExam(stats.studyUID, stats.studyStatus);
    }
    this.startupStats = [];
  }

  // Exams might not be linked to an exam group, we track the cache
  // status of the user's exams coming from OPFS which may not (yet) have an exam group relationship
  // These operations may cause an observable to fire. When it fires, we
  // update the associated exam groups and notify cache-status-service of the change.
  public addOrUpdateExam(exam: ExamInformation | string, status?: StudyStatus): ExamCacheStatus {
    const studyUID: string = typeof exam === 'string' ? exam : exam.studyUID;
    const cachedInfo: ExamCacheStatus = this.getExamCacheStatus(studyUID);
    if (status) {
      cachedInfo.studyStatus = status; // Trigger notification
    }
    return cachedInfo;
  }

  // Is any part of this exam group in the cache?
  public examGroupIsInCache(orderId: number): boolean {
    const cacheStatus = this.examGroupDefinitionMap.get(orderId);
    if (cacheStatus != null) {
      return cacheStatus.examGroupCacheStatus === CacheStatus.eCACHED ||
        cacheStatus.examGroupCacheStatus === CacheStatus.eCACHING_IMAGES;
    }
    return false;
  }

  public addorUpdateExamGroup(examGroup: ExamGroup): ExamGroupCacheStatus {
    // 1. If orderId doesn't exist, create a new ExamGroupCacheStatus
    // 2. If it does exist, reconcile the ExamGroupCacheStatus to ensure all exams are present, add new exams, remove old if needed
    // 3. Create or update ExamGroupCacheStatus for this exam
    // 4. Return ExamGroupCacheStatus
    const orderId = examGroup.orderId;
    let examGroupCacheStatus = this.examGroupDefinitionMap.get(orderId);
    if (examGroupCacheStatus != null) {
      // Resolve any changes to this exam e.g. number of comparisons or CacheStatus
      examGroupCacheStatus = this.updateExamGroupCacheStatus(examGroup, examGroupCacheStatus);
    } else {
      // Create a new ExamGroupCacheStatus
      examGroupCacheStatus = this.createExamGroupCacheStatus(examGroup);
      this.examGroupDefinitionMap.set(examGroup.orderId, examGroupCacheStatus);
    }
    return examGroupCacheStatus;
  }

  // Remove study UID from tracking when it is deleted from OPFS and no longer in the current order list
  public removeExamFromNotification(studyUID: string): void {
    console.info(`${this.constructor.name} removeExamFromNotification removing study ${studyUID} relationship map`);

    const examStatus = this.studyUIDStatusMap.get(studyUID);
    const groupStatusList = this.studyUIDExamGroupMap.get(studyUID);
    if (groupStatusList == null) {
      // This error suggests application has lost synchronization with caching status
      console.error(`${this.constructor.name} removeExamFromNotification unexpected ${studyUID} not in relationship map, maps out of sync`);
      return;
    }
    if (examStatus == null) {
      // Code assumes studies in OPFS at startup for this user or
      // studies that are no longer in the current order list are
      // still represented in notifier until they are removed.
      // This error suggests application has lost synchronization with caching status
      console.error(`${this.constructor.name} removeExamFromNotification unexpected ${studyUID} not in map`);
      return;
    }
    // Signal that the exam is no longer cached.
    examStatus.cacheStatus = CacheStatus.eNOT_CACHED;

    // More than one study references this exam, so we won't remove it yet, it's just not cached any longer.
    if (groupStatusList.length > 0) {
      // Policy is that as long as a study is referenced by an examGroup, we don't remove it from maps.
      console.error(`${this.constructor.name} removeExamFromNotification ${studyUID} is still referenced by ${groupStatusList.length} Orders, e.g. ${groupStatusList[0].orderId}`, groupStatusList[0]);
      return;
    }
    this.examGroupArrayCleanup(studyUID, groupStatusList);
  }

  private examGroupArrayCleanup(studyUID: string, groupStatusList: ExamGroupCacheStatus[]): void {
    if (groupStatusList.length === 0) {
      // No orders left referencing this study
      this.studyUIDExamGroupMap.delete(studyUID);
      this.studyUIDStatusMap.delete(studyUID);
    }
  }

  // Remove order <-> study relationship, if the exam is not cached, and has no other relationships, remove it.
  // If it is cached, leave it as a cached study until it is purged from opfs
  private removeExamFromOrderNotification(studyUID: string, orderId: number): void {
    console.info(`${this.constructor.name} removeExamFromOrderNotification removing order ${orderId} for ${studyUID} from relationship map`);
    const examStatus = this.studyUIDStatusMap.get(studyUID);
    const groupStatusList = this.studyUIDExamGroupMap.get(studyUID);
    if (groupStatusList == null) {
      // This error suggests application has lost synchronization with caching status
      console.error(`${this.constructor.name} removeExamFromOrderNotification unexpected ${studyUID} not in relationship map, maps out of sync`);
      return;
    }
    if (examStatus == null) {
      // Code assumes studies in OPFS at startup for this user or
      // studies that are no longer in the current order list are
      // still represented in notifier until they are removed.
      // This error suggests application has lost synchronization with caching status
      console.error(`${this.constructor.name} removeExamFromOrderNotification unexpected ${studyUID} not in map`);
      return;
    }
    const index = groupStatusList.findIndex((entry) => entry.orderId === orderId);
    const includesOrder = index > -1;
    const isCached = examStatus.cacheStatus === CacheStatus.eCACHED;

    if (!includesOrder && isCached) {
      console.error(`${this.constructor.name} removeExamFromOrderNotification unexpected ${orderId} for ${studyUID} not in relationship map, maps out of sync`);
      return;
    }

    // Remove the relationship to this particular order
    groupStatusList.splice(index, 1);

    // Other orders refer to this study or its a cached study, we're done
    // If cached, we track it's status as cached, in OPFS until it is purged or
    // associated with a new ExamGroup
    if (groupStatusList.length > 0 || isCached) {
      return;
    }
    // study is not cached and nothing else references it
    this.examGroupArrayCleanup(studyUID, groupStatusList);
  }

  // Remove a particular exam group from notification -- this may leave cached studies orphaned in the cache, that's ok.
  public removeExamGroupFromNotification(orderId: number): void {
    console.info(`${this.constructor.name} removeExamGroupFromNotification removing order ${orderId} relationship maps`);

    const examGroup = this.examGroupDefinitionMap.get(orderId);
    if (examGroup == null) {
      console.error(`${this.constructor.name} removeExamGroupFromNotification unexpected ${orderId} not in map`);
      return;
    }

    // Remove all relationships to this order
    for (const examStatus of examGroup.examGroup) {
      this.removeExamFromOrderNotification(examStatus.studyUID, orderId);
    }
    // re-compute the caching status for this group
    examGroup.examGroupCacheStatus = CacheStatus.eNOT_CACHED;
    this.examGroupDefinitionMap.delete(orderId);
  }

  private subscribe(): void {

    this.examCacheStatus$$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (examCacheStatus: IExamCacheStatus[]) => {
        await this.ngZone.runOutsideAngular(async (): Promise<void> => {
          // console.log(`${this.constructor.name} this.examCacheStatus$$ fires`, examCacheStatus);
          // For each examCacheStatus update, notify associated exam groups
          await this.notifyExamGroupStatusList(examCacheStatus);
          // Store the status in our DB to share with FE
          await this.cacheStatusStoreService.updateExamCacheStatus(examCacheStatus[0]);
          // this.onHandleUpdateExamCacheStatus(examCacheStatus);
        });
      });

    this.examGroupStatus$$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (groupCacheStatus: IExamGroupCacheStatus) => {
        await this.ngZone.runOutsideAngular(async (): Promise<void> => {
          // console.log(`${this.constructor.name} this.examGroupStatus$$ fires`, groupCacheStatus);
          // Store the status in our DB to share with FE
          await this.cacheStatusStoreService.updateExamGroupCacheStatus(groupCacheStatus);
          // this.onHandleUpdateExamGroupStatus(groupCacheStatus);
        })
      });
  }


  private onHandleUpdateExamCacheStatus(examCacheStatus: IExamCacheStatus[]): void {
    this.serverApiService
      .updateExamsStatus(examCacheStatus)
      .pipe(
        filter((status) => status == null)
      ).subscribe(
        {
          next: (response: string | null) => {
            if (response != null) {
              console.error(`${this.constructor.name} updateExamsStatus failed`, response);
            } else {
              // console.info(`${this.constructor.name} updateExamsStatus was successful`, response);
            }
          },
          error: (error: HttpErrorResponse) => {
            this.handleHttpError(error);
          }
        });
  }

  private onHandleUpdateExamGroupStatus(groupCacheStatus: IExamGroupCacheStatus): void {
    // for each examGroupStatus update notify cache-status-service of change
    // console.log(`${this.constructor.name} this.examGroupStatus$$ OrderId ${groupCacheStatus.orderId}`,groupCacheStatus);
    if (groupCacheStatus.examGroupCacheStatus === CacheStatus.eCACHED) {
      this.examGroupCacheComplete$$.next(groupCacheStatus.orderId);
    }

    this.serverApiService
      .updateExamGroupStatus(groupCacheStatus)
      .pipe()
      .subscribe({
        next: (response: string | null) => {
          if (response != null) {
            console.error(`${this.constructor.name} updateExamGroupStatus failed`);
          } else {
            // console.info(`${this.constructor.name} updateExamGroupStatus returned `, response);
          }
        },
        error: (error: HttpErrorResponse) => {
          this.handleHttpError(error);
        }
      });

  }

  private handleHttpError(response: HttpErrorResponse): void {
    const message = ` ${response.status} ${response.statusText} ${response.message} ${response.error.message}`;
    const tostring = response.error.toString();
    console.error(`${this.constructor.name} handleHttpError ${message} - ${tostring}, ${response.error.stack ?? ''}`, response);
  }

  private async notifyExamGroupStatusList(examCacheStatus: IExamCacheStatus[]): Promise<void> {
    for (const status of examCacheStatus) {
      console.log(`${this.constructor.name} cache status notification for StudyUID ${status.studyUID} '${status.cacheStatus}'`);
      await this.notifyExamGroupStatus(status);
    }
  }

  // When cache status for a particular exam is changing
  // 1. lookup associated ExamGroupCacheStatus[]
  // 2. For each ExamGroupCacheStatus[] call notify
  private async notifyExamGroupStatus(examCacheStatus: IExamCacheStatus): Promise<void> {
    const studyUID = examCacheStatus.studyUID;
    const groupStatusList: ExamGroupCacheStatus[] | undefined = this.studyUIDExamGroupMap.get(studyUID);
    if (groupStatusList == null) {
      // Unexpected
      console.error(`${this.constructor.name} notifyExamGroupStatus unexpected ${studyUID} no studies found to notify`);
    } else {
      for (const groupStatus of groupStatusList) {
        const oldStatus = groupStatus.examGroupCacheStatus;
        const changed = groupStatus.notifyIfChanged();
        console.log(`${this.constructor.name} notifyExamGroupStatus ${studyUID} ${changed} groupStatus '${oldStatus}' -> '${groupStatus.examGroupCacheStatus}'`, examCacheStatus);
      }
    }
  }

  private updateExamGroupCacheStatus(examGroup: ExamGroup, currentCacheStatus: ExamGroupCacheStatus): ExamGroupCacheStatus {
    // This examGroup orderId is already in our map, determine if it needs to be updated
    // comparison exams may be added or removed, so keep our maps 'up to date'
    // 1. Determine new studies to be added
    // 1. Determine old studies to be kept/preserved
    // 2. Determine old studies to be removed
    const newStudyUIDs: string[] = examGroup.allExams.map(entry => entry.studyUID);
    const currentStudyUIDs: string[] = currentCacheStatus.examGroup.flatMap((entry)=> entry.studyUID);
    const toRemoveList = currentStudyUIDs.filter((uid) => !newStudyUIDs.includes(uid));
    const toKeepList = newStudyUIDs.filter((uid) => currentStudyUIDs.includes(uid));
    const toAddList = newStudyUIDs.filter((uid) => !currentStudyUIDs.includes(uid));
    console.log(`${this.constructor.name} updateExamGroupCacheStatus add, keep, remove, newuids, udis`, toAddList, toKeepList, toRemoveList, newStudyUIDs, currentStudyUIDs );

    // Filter out studies that are not in the new list
    if (toRemoveList.length > 0) {
      currentCacheStatus = this.removeStudyUIDsFromExamGroupRelationship(toRemoveList, currentCacheStatus);
    }
    // Verify we have are keeping the right studies
    for (const studyUID of toKeepList) {
      const index = currentCacheStatus.examGroup.findIndex((entry) => entry.studyUID === studyUID);
      if (index === -1) {
        // Unexpected -- suggests we have a tracking problem in our maps
        console.error(`${this.constructor.name} updateExamGroupCacheStatus unexpected ${studyUID} in OrderId ${currentCacheStatus.orderId} not kept `);
      }
    }
    const addedExamStatus = this.getExamsCacheStatus(toAddList);
    // Now add in the new ones and update our maps
    if (addedExamStatus.length > 0) {
      currentCacheStatus.examGroup = currentCacheStatus.examGroup.concat(addedExamStatus);
      this.updateStudyUIDExamGroupRelationship(currentCacheStatus);
    }
    console.log(`${this.constructor.name} updateExamGroupCacheStatus returning`, currentCacheStatus);

    return currentCacheStatus;
  }

  // Only call this method iff examGroup does not exist in our map
  // Create a new ExamGroupCacheStatus object and ensure it
  // is linked into maps accordingly
  private createExamGroupCacheStatus(examGroup: ExamGroup): ExamGroupCacheStatus {
    const examGroupStatus = this.createExamGroup(examGroup);
    // Now add this object to our maps
    this.examGroupDefinitionMap.set(examGroup.orderId, examGroupStatus);
    this.updateStudyUIDExamGroupRelationship(examGroupStatus);

    return examGroupStatus;
  }

  // Track the list of examGroups each studyUID is associated with -- there may be more
  // than one.
  private updateStudyUIDExamGroupRelationship(examGroupStatus: ExamGroupCacheStatus): void {
    let groupStatusList: ExamGroupCacheStatus[] | undefined;
    for (const exam of examGroupStatus.examGroup) {
      const studyUID = exam.studyUID;
      groupStatusList = this.studyUIDExamGroupMap.get(studyUID);
      if (groupStatusList == null) {
        groupStatusList = [];
        this.studyUIDExamGroupMap.set(studyUID, groupStatusList);
      }
      const index = groupStatusList.findIndex((examGroup) => examGroup.orderId === examGroupStatus.orderId);
      if (index === -1) {
        groupStatusList.push(examGroupStatus);
        this.studyUIDExamGroupMap.set(studyUID, groupStatusList);
      }
    }
  }

  private removeStudyUIDsFromExamGroupRelationship(studyUIDs: string[], examGroupStatus: ExamGroupCacheStatus): ExamGroupCacheStatus {
    console.info(`${this.constructor.name} removeStudyUIDsFromExamGroupRelationship studyUIDs ${studyUIDs.join(',')} order ${examGroupStatus.orderId} from relationship map`);

    for (const studyUID of studyUIDs) {
      this.removeStudyUIDFromExamGroupRelationship(studyUID, examGroupStatus);
      const index = examGroupStatus.examGroup.findIndex((entry) => entry.studyUID === studyUID);
      if (index > -1) {
        examGroupStatus.examGroup.splice(index, 1);
      }
    }
    return examGroupStatus;
  }

  // Track the list of examGroups each studyUID is associated with -- there may be more
  // than one.
  private removeStudyUIDFromExamGroupRelationship(studyUID: string, examGroupStatus: ExamGroupCacheStatus): void {
    console.info(`${this.constructor.name} removeStudyUIDFromExamGroupRelationship studyUID ${studyUID} for order ${examGroupStatus.orderId} from relationship map`);

    const groupStatusList: ExamGroupCacheStatus[] | undefined = this.studyUIDExamGroupMap.get(studyUID);
    if (groupStatusList == null) {
      // This error suggests application has lost synchronization with caching status
      console.error(`${this.constructor.name} removeStudyUIDFromExamGroupRelationship unexpected ${studyUID} not in relationship map, maps out of sync`);
      return;
    }
    const index = groupStatusList.findIndex((entry) => entry.orderId === examGroupStatus.orderId);
    if (index === -1) {
      console.error(`${this.constructor.name} removeStudyUIDExamGroupMap unexpected ${studyUID} OrderId ${examGroupStatus.orderId} not found `);
      return;
    }
    groupStatusList.splice(index, 1);
    this.studyUIDExamGroupMap.set(studyUID, groupStatusList);
    // Nothing else references this study?
    if (groupStatusList.length === 0) {
      // Group list may have become empty -- that's OK. Study may be cached and is ready to be hooked up again
      const examStatus = this.studyUIDStatusMap.get(studyUID);
      // If the exam hasn't been cached, we can just drop it from tracking, nothing more to do
      if (examStatus != null && examStatus.cacheStatus === CacheStatus.eNOT_CACHED) {
        this.examGroupArrayCleanup(studyUID, groupStatusList);
      }
    }
  }

  private createExamGroup(examGroup: ExamGroup): ExamGroupCacheStatus {
    const examList: ExamCacheStatus[] = [];
    // Get a status object for each exam
    examList.push(this.getExamCacheStatus(examGroup.primaryExam.studyUID));
    for (const comparison of examGroup.comparisonExams) {
      examList.push(this.getExamCacheStatus(comparison.studyUID));
    }
    const examGroupStatus = new ExamGroupCacheStatus(this.examGroupStatus$$);
    // console.info(`${this.constructor.name} createExamGroup new ExamGroupCacheStatus for OrderId ${examGroup.orderId} `, examList);
    examGroupStatus.setexamGroup(examGroup, examList);
    return examGroupStatus;
  }

  // Get a group of examStatus from the maps -- creating them if they don't exist
  private getExamsCacheStatus(studyUIDs: string[]): ExamCacheStatus[] {
    const examStatus: ExamCacheStatus[] = [];
    for (const studyUID of studyUIDs) {
      examStatus.push(this.getExamCacheStatus(studyUID));
    }
    return examStatus;
  }

  // Get the examStatus from our maps, if it doesn't exist, add it now
  private getExamCacheStatus(studyUID: string): ExamCacheStatus {
    let cachedInfo: ExamCacheStatus | undefined = this.studyUIDStatusMap.get(studyUID);
    if (cachedInfo == null) {
      cachedInfo = new ExamCacheStatus(this.examCacheStatus$$);
      // console.info(`${this.constructor.name} getExamCacheStatus new ExamCacheStatus for studyUID: ${studyUID} `);
      cachedInfo.studyUID = studyUID;
      this.studyUIDStatusMap.set(studyUID, cachedInfo);
      this.studyUIDExamGroupMap.set(studyUID, []);
    }
    return cachedInfo;
  }

  public ngOnDestroy(): void {
    this.unsubscribe();
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }
}
