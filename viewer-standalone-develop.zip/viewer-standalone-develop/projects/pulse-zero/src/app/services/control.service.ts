import { Injectable, NgZone } from '@angular/core';
import { BehaviorSubject, Observable, ReplaySubject, Subject, takeUntil } from 'rxjs';

import {
  AuthenticationToken,
  AuthorizationToken,
  ChangeTrigger,
  CommunicationId,
  ErrorData,
  ErrorTrigger,
  MessageBase,
  MessageEventListener,
  MessageTarget,
  MessageType,
  Result,
  StartSessionData,
  Terminate,
  UpdateSessionData,
  UserId
} from '@idgital/pulse-vision-interface';

import {
  PulseVisionApiService
} from '@pulse-zero-api';

import {
  ExamGroup,
  ExamGroupAuthorizationContext,
  ExamGroupStore,
  LOG_SOURCE, LogSupport,
  ServerApiService
} from '@server-api';

import { PerfTiming } from '@worker-compatible-api';

import { CacheStatusNotifierService } from './cache-status-notifier.service';
import { opfsWorkerFactory, computeWorkerFactory } from '../workers/worker-factories';

class PVErrorData implements ErrorData {

  constructor(public commId: CommunicationId,
    public source: MessageType,
    public message: string,
    public trigger: ErrorTrigger = '',
    public reloadRequired: boolean = false) { }
}

// ControlService: Handles the communication between the Pulse Zero application and the controlling application.

@Injectable({
  providedIn: 'root'
})
export class ControlService {
  private channelMsgFn: MessageEventListener | undefined;
  private _controller: (MessageTarget | undefined);
  private channel: MessageChannel | undefined;
  private _commId: CommunicationId = '';
  private _foviaUrl: URL = new URL(`${window.origin}`);
  private _cacheStatusServiceUrl = `${window.origin}`;
  private unsubscribe$$ = new Subject<void>();
  private currentStudyList$$ = new BehaviorSubject<ExamGroup[]>([]);
  private initFoviaSignal$$ = new ReplaySubject<boolean>(1)
  private examGroupStore = new ExamGroupStore();
  private userId: UserId = -1;
  constructor(
    private pulseVisionApiService: PulseVisionApiService,
    private serverApi: ServerApiService,
    private cacheStatusNotifier: CacheStatusNotifierService,
    private ngZone: NgZone
  ) {
    this.channelMsgFn = undefined;
    this._controller = undefined;
    this.channel = undefined;
    this.serverApi.applicationName = 'CACHE';
    this.listenForCacheStatusUpdates();
  }

  public async init(): Promise<void> {
    const perfTime = new PerfTiming();
    const isOpfsReadOnly = false;

    await this.ngZone.runOutsideAngular(async (): Promise<void> => {
      await this.cacheStatusNotifier.init();
      // Fire up workers so we can use them during opfs initialization
      await this.pulseVisionApiService.initComputeUtilsService(computeWorkerFactory);
      await this.pulseVisionApiService.initOpfsUtilsService(opfsWorkerFactory, /*readOnlyAccess=*/false);
      await this.pulseVisionApiService.init(isOpfsReadOnly);
    });

    this.channelMsgFn = this.handleChannelMessage.bind(this);

    const controllingWindow = window.opener || window.parent;

    console.log(`${this.constructor.name} init Starting PulseVision Control service`, window, controllingWindow);
    LogSupport.logInfo(`${this.constructor.name} init Starting PulseVision Control service`);

    if (window && controllingWindow) {
      this._controller = controllingWindow;
    } else {
      this._controller = undefined;
    }

    console.log(`${this.constructor.name} init Creating PulseVision message channel`);
    LogSupport.logInfo(`${this.constructor.name} init Creating PulseVision message channel`);

    // The ControlService transfers ownership of MessageChannel.port1 to the controlling entity.
    // The ControlService maintains ownership of MessageChannel.port2.
    this.channel = new MessageChannel();
    this.channel.port2.addEventListener('message', this.channelMsgFn);
    this.channel.port2.start();

    const message = `${this.constructor.name} init Opened PulseVision message channel ${perfTime.elapsedSeconds}`;
    console.info(message);
    LogSupport.logInfo(message);
  }

  public get currentExamList$(): Observable<ExamGroup[]> {
    return this.currentStudyList$$;
  }

  public get signalInitFovia$(): Observable<boolean> {
    return this.initFoviaSignal$$;
  }

  public get hasController(): boolean {
    return this._controller !== undefined;
  }

  public get commId(): CommunicationId {
    return this._commId;
  }

  /**
    * Notify the controlling entity of the request result
   * @param commId The currently active session identifier.
   * @param reason One of the values of `ChangeTrigger` indicating the reason for the change.
   */
  public notifyResult(commId: CommunicationId, reason: ChangeTrigger): void {
    if (this.channel != null) {
      this.channel.port2.postMessage({
        type: MessageType.RESULT,
        data: {
          commId: commId,
          reason: reason
        } as Result
      });
    }
  }

  /**
    * Notify the controlling entity that the pulse vision application has updated cache status information.
  */
  public notifyCacheStatusUpdated(): void {
    if (this.channel != null) {
      this.channel.port2.postMessage({
        type: MessageType.STATUS_STATE_UPDATED
      });
    } else {
      console.error(`${this.constructor.name} notifyStatusStateUpdated has no valid controller; cache status updated cannot be reported`);
      LogSupport.logError(`${this.constructor.name} notifyStatusStateUpdated has no valid controller;  cache status updated  cannot be reported`);
    }
  }

  /**
   * Retrieve a reference to the entity controlling the pulse vision application instance.
   * Typically, this is [window.opener](https://developer.mozilla.org/en-US/docs/Web/API/Window/opener), but it can be anything that can receive a message.
   */
  public get controller(): (MessageTarget | undefined) {
    return this._controller;
  }

  /**
   * Set the reference to the entity controlling the pulse vision application instance.
   * Typically, this is [window.opener](https://developer.mozilla.org/en-US/docs/Web/API/Window/opener), but it can be anything that can receive a message.
   * This setter is present for testing purposes only.
   */
  public set controller(value: (MessageTarget | undefined)) {
    this._controller = value;
  }

  public get foviaUrl(): URL {
    return this._foviaUrl;
  }

  public get cacheStatusServiceUrl(): string {
    return this._cacheStatusServiceUrl;
  }

  /**
   * Notify the controlling entity that the pulse vision application instance has encountered an error.
   */
  public notifyError(reason: MessageType, message: string, errorTrigger: ErrorTrigger = '', reloadRequired: boolean = false): void {
    if (this.controller) {
      const error = new PVErrorData(this.commId, reason, message, errorTrigger, reloadRequired);
      console.log(`${this.constructor.name} notifyError reporting pulse vision error back to controller:`, error);
      LogSupport.logInfo(`${this.constructor.name} notifyError reporting pulse vision error back to controller: ${error.message}`);
      this.sendErrorMessage(error);
    } else {
      console.error(`${this.constructor.name} notifyError has no valid controller; error cannot be reported`, message);
      LogSupport.logError(`${this.constructor.name} notifyError has no valid controller; error cannot be reported ${message}`);
    }
  }
  /**
   * Notify the controlling entity that the pulse vision application instance is ready to receive commands.
   */
  public notifyReady(): void {
    if (this.controller && this.channel) {
      // Transfer ownership of MessageChannel.port1 to the controlling entity.
      console.info(`${this.constructor.name} transferring message port to controller`);
      this.controller.postMessage(MessageType.READY, '*', [
        this.channel.port1
      ]);
    } else {
      console.error(`${this.constructor.name} notifyReady has no valid controller; ready status cannot be reported`);
    }
  }

  /**
   * Notify the controlling entity that the pulse vision application instance has encountered browser storage eviction and requires a reload.
   */
  public notifyEvictionError(): void {
    const message = ` Image downloads on this computer were deleted by the operating system`;
    console.error(`${this.constructor.name} EVICTION DETECTED - ${message}`);
    this.notifyError(MessageType.ERROR, message, 'eviction', true);
  }

  /**
   * Notify the controlling entity that the pulse vision application instance is in a general 'hung' state and needs to be restarted
   */
  public notifyCrashError(): void {
    const message = `Cache Manager needs to be restarted`;
    console.error(`${this.constructor.name} Crash Error - ${message}`);
    this.notifyError(MessageType.ERROR, message, 'crash', true);
  }
  /**
    * Notify the controlling entity that the pulse vision fovia sdk does not match the fovia server and needs to be restarted
    */
  public notifyReloadForFoviaError(): void {
    const message = `Fovia SDK mismatch error Cache Manager needs to be restarted`;
    console.error(`${this.constructor.name} SDK Error - ${message}`);
    this.notifyError(MessageType.ERROR, message, '', true);
  }

  /**
   * Establish our caching session
   * @param request establishes the information needed to begin caching
   */
  public startSession(request: StartSessionData): void {
    try {
      const message = `${this.constructor.name} startSession received request to start cache session: ${JSON.stringify(request)}`;
      console.info(message);
      if (this.invalidCommId(request.commId, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} startSession invalid commId:`, request);
        LogSupport.logError(`${this.constructor.name} startSession invalid commId: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidRenderServiceURL(request.renderService, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} startSession invalid renderService url:`, request);
        LogSupport.logError(`${this.constructor.name} startSession invalid renderService url: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidCacheStatusServiceURL(request.cacheStatusService, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} startSession invalid cacheStatusService url:`, request);
        LogSupport.logError(`${this.constructor.name} startSession invalid cacheStatusService url: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidUserId(request.userId, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} startSession invalid userId:`, request);
        LogSupport.logError(`${this.constructor.name} startSession invalid userId: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidUserToken(request.userToken, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} startSession invalid userToken:`, request);
        LogSupport.logError(`${this.constructor.name} startSession invalid userToken: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidAuthorizationToken(request.sessionTokens, MessageType.START_CACHE_SESSION)) {
        console.error(`${this.constructor.name} invalid startSession session tokens encountered:`, request);
        LogSupport.logError(`${this.constructor.name} invalid startSession session tokens encountered: ${JSON.stringify(request)}`);
        return;
      }
      this.handleValidStartSession(request).then();
    }
    catch (err) {
      console.error(`${this.constructor.name} startSession exception`, err);
      this.notifyError(MessageType.START_CACHE_SESSION, `exception encountered handling startSession message`);
    }
  }

  public ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }

private async handleValidStartSession(request: StartSessionData): Promise<void> {
    this._commId = request.commId;
    // update user credentials
    this.userId = request.userId;
    this.serverApi.cacheServiceHost = this.cacheStatusServiceUrl;
    this.pulseVisionApiService.updateUserCredentials(this.userId, request.userToken);

    console.log(`${this.constructor.name} handleValidStartSession - Sending Early Ack`);
    this.notifyResult(this._commId, 'start');


    try {
      // Before we start caching, initialize the cache status service and connect to cache-status db
      await this.cacheStatusNotifier.initCacheStatusService(this.userId);

      console.log(`${this.constructor.name} handleValidStartSession`);
      await this.connectToFoviaServer(this.foviaUrl);
      LogSupport.setSource(this.pulseVisionApiService.userId, LOG_SOURCE.CACHE);

      
      // Exchange token with auth service for the real info
      await this.getExamDefintionFromTokens(request, MessageType.START_CACHE_SESSION);

      this.notifyResult(this._commId, 'fully_initialized');
    } catch (error) {
      console.error(`${this.constructor.name} Background Initialization Failed`, error);
      this.notifyResult(this._commId, 'error');
    }
    
  }

  /*
   * Update caching session from updated data
   * @param request establishes the information needed to begin caching
   */
  public updateSession(request: UpdateSessionData): void {
    try {

      console.log(`${this.constructor.name} updateSession received request to update cache session:`);
      LogSupport.logInfo(`${this.constructor.name} updateSession received request to update cache session:`);
      console.log(request);
      if (this.invalidCommId(request.commId, MessageType.UPDATE_CACHE_SESSION)) {
        console.error(`${this.constructor.name} updateSession invalid commId:`, request);
        LogSupport.logError(`${this.constructor.name} updateSession invalid commId: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidUserToken(request.userToken, MessageType.UPDATE_CACHE_SESSION)) {
        console.error(`${this.constructor.name} updateSession invalid userToken:`, request);
        LogSupport.logError(`${this.constructor.name} updateSession invalid userToken: ${JSON.stringify(request)}`);
        return;
      }
      if (this.invalidAuthorizationToken(request.sessionTokens, MessageType.UPDATE_CACHE_SESSION)) {
        console.error(`${this.constructor.name} invalid updateSession session tokens encountered:`, request);
        LogSupport.logError(`${this.constructor.name} invalid updateSession session tokens encountered: ${JSON.stringify(request)}`);
        return;
      }
      this.handleValidUpdateSession(request).then();
    } catch (err) {
      console.error(`${this.constructor.name} updateSession exception`, err);
      this.notifyError(MessageType.UPDATE_CACHE_SESSION, `exception encountered handling updateSession message`);
    }
  }

  private async handleValidUpdateSession(request: UpdateSessionData): Promise<void> {
    // update user credentials
    this.pulseVisionApiService.updateUserCredentials(this.userId, request.userToken);
    this.notifyResult(this._commId, 'update');
    // Exchange token with auth service for the real info
    await this.getExamDefintionFromTokens(request, MessageType.UPDATE_CACHE_SESSION);
  }

  /**
   * Attempt to terminate and unload all data associated with a viewing session.
   * @param request Information about the session termination, specifying the identifier of the session to terminate, which may identify the currently active session, or any suspended session.
   */
  public terminateSession(commId: CommunicationId): void {
    const request = {
      commId: commId
    };
    console.log(`${this.constructor.name} terminateSession received request to terminate cache session ${JSON.stringify(request)}`);
    LogSupport.logInfo(`${this.constructor.name} terminateSession received request to terminate cache session ${JSON.stringify(request)}`);
    if (this.invalidCommId(request.commId, MessageType.TERMINATE_CACHE_SESSION)) {
      console.error(`${this.constructor.name} terminateSession invalid commId:`, request);
      LogSupport.logError(`${this.constructor.name} terminateSession invalid commId: ${JSON.stringify(request)}`);
      return;
    }
    this.serverApi.ngOnDestroy();
    this.terminateCaching().then(() => {
      // Dispatch notifications.
      this.notifyResult(this._commId, 'terminate');
    });
  }

  public async connectToFoviaServer(hostName: URL): Promise<void> {
    const message = `${this.constructor.name} connectToFoviaServer() with ${hostName}`;
    console.info(message);
    // Trigger connection to fovia this will retry until it succeeds
    this.initFoviaSignal$$.next(false);
    await this.pulseVisionApiService.foviaInitCompleted();
    // Initial fovia connection triggered on application startup.
    // Wait for it to complete...
 }

  private async getExamDefintionFromTokens(request: StartSessionData | UpdateSessionData, mesageType: MessageType): Promise<void> {
    try {
      if (request.sessionTokens.length === 0) {
        console.warn(`${this.constructor.name} no session tokens provided:`, request);
        this.currentStudyList$$.next([]);
        return;
      }
      await this.pulseVisionApiService.foviaInitCompleted();
      const perfTime = new PerfTiming();
      console.info(`${this.constructor.name} getExamDefinitionFromTokens WAITING FOR TOKEN RESOLUTION TO COMPLETE..`);
      LogSupport.logInfo(`${this.constructor.name} getExamDefinitionFromTokens WAITING FOR TOKEN RESOLUTION TO COMPLETE..`);
      const examGroups = await this.tokenExchange(request);

      const message = `${this.constructor.name} getExamDefinitionFromTokens TOKEN RESOLUTION COMPLETE in ${perfTime.elapsedSeconds}`;
      console.info(message);
      LogSupport.logInfo(message);

      if (examGroups == null) {
        // Nothing to do.
        console.error(`${this.constructor.name} getExamDefinitionFromTokens examGroup list is null nothing to do`);
        return;
      }
      console.info(`${this.constructor.name} getTokensFromSessionData cacheList ${examGroups.allExamGroups.length}`);
      console.log(`${this.constructor.name} getTokensFromSessionData cacheList`, examGroups.allExamGroups);
      LogSupport.logInfo(`${this.constructor.name} getTokensFromSessionData cacheList ${examGroups.allExamGroups.length}`);
      // submit these studies for caching
      this.currentStudyList$$.next(examGroups.allExamGroups);

    } catch (err) {
      console.error(`${this.constructor.name} getTokensFromSessionData exception from tokenExchange`, err);
      const message = JSON.stringify(err);
      LogSupport.logError(`${this.constructor.name} getTokensFromSessionData exception from tokenExchange ${message}`);
      this.notifyError(mesageType, `${this.constructor.name} getTokensFromSessionData exception from tokenExchange ${message}`);
    }
  }

  private handleChannelMessage(ev: MessageEvent): void {
    const message = ev.data as MessageBase;
    console.log(`${this.constructor.name} handleChannelMessage `, ev);
    LogSupport.logInfo(`${this.constructor.name} handleChannelMessage ${JSON.stringify(ev)}`);
    try {
      switch (message.type) {
        case MessageType.START_CACHE_SESSION:
          {
            const data = message.data as StartSessionData;
            this.startSession(data);
          } break;
        case MessageType.UPDATE_CACHE_SESSION:
          {
            const data = message.data as UpdateSessionData;
            this.updateSession(data);
          } break;
        case MessageType.TERMINATE_CACHE_SESSION:
          {
            const data = message.data as Terminate;
            this.terminateSession(data.commId);
          } break;
        default:
          {
            console.error(`${this.constructor.name} handleChannelMessage unhandled message type ${message.type}`);
            LogSupport.logError(`${this.constructor.name} handleChannelMessage unhandled message type ${message.type}`);
          } break;
      }
    } catch (err) {
      console.error(`${this.constructor.name} handleChannelMessage Caught unhandled exception:`);
      LogSupport.logError(`${this.constructor.name} handleChannelMessage Caught unhandled exception:`);
      console.log(`${this.constructor.name} handleChannelMessage`, err);
      const info: ErrorData = new PVErrorData(this._commId, message.type, `${err}`);
      this.sendErrorMessage(info);
    }
  }

  private async tokenExchange(request: StartSessionData | UpdateSessionData): Promise<ExamGroupStore | null> {
    return new Promise<ExamGroupStore | null>(async (resolve) => {
      this.examGroupStore = new ExamGroupStore();
      const target = this.examGroupStore;
      let sessionTokens = request.sessionTokens;
      if (sessionTokens.length === 0) {
        console.error(`${this.constructor.name} Unable to resolve session tokens, no tokens were provided`);
        LogSupport.logError(`${this.constructor.name} Unable to resolve session tokens, no tokens were provided`);
        return resolve(target);
      }
      await this.pulseVisionApiService.foviaInitCompleted();
      if (this.pulseVisionApiService.foviaConnected) {
        const resolveContext = new ExamGroupAuthorizationContext(sessionTokens, target);
        const result = await this.serverApi.resolveExamGroupAccess(resolveContext);
        if (!result.allAuthorized) {
          const goodTokens = sessionTokens.filter(item => !result.unauthorizedSessionTokens.includes(item));
          if (goodTokens.length === 0) {
            console.error(`${this.constructor.name} Failed to resolve ANY exam group tokens nothing to cache`, result.unauthorizedSessionTokens);
            return resolve(null);
          }
          // Drop any exam groups that were not authorized
          sessionTokens = goodTokens;
        }
        // Install one of the sessionTokens with cache-status-service to speedup authentication
        this.serverApi.sessionToken = sessionTokens[0];
        // Ensure the examGroups are returned in Token Order.
        target.orderExamGroupsByTokenOrder(sessionTokens);

      } else {
        console.error(`${this.constructor.name} Unable to resolve session tokens, fovia is not connected`, sessionTokens);
        LogSupport.logError(`${this.constructor.name} Unable to resolve session tokens, fovia is not connected ${sessionTokens.toString()}`);
      }
      return resolve(target);
    });
  }

  private async terminateCaching(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.pulseVisionApiService.stopCaching();
      return resolve();
    });
  }

  private getURL(path: string | URL, urlID: string): URL | null {
    try {
      return new URL(path);
    } catch (err) {
      console.error(`${this.constructor.name} getURL for ${urlID} failed with ${err} `);
      LogSupport.logError(`${this.constructor.name} getURL for ${urlID} failed with ${JSON.stringify(err)} `);
    }
    return null;
  }

  private invalidCommId(commId: string, type: MessageType): boolean {
    if (this._commId == null || this._commId === '') {
      // commId not yet established, not a problem
      return false;
    }
    if (commId === '') {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} sessionId may not be empty`));
      return true;
    }
    if (commId !== this._commId) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} unexpected sessionId encountered '${commId}' vs existing '${this._commId}'`));
      return true;
    }
    return false;
  }

  private invalidUserToken(userToken: AuthenticationToken, type: MessageType): boolean {
    if (userToken == null || userToken === '') {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} userToken must be provided`));
      return true;
    }
    return false;
  }

  private invalidUserId(userId: UserId, type: MessageType): boolean {
    if (userId == null || userId < 0) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} expected userId > 0 userId was ${userId}`));
      return true;
    }
    return false;
  }

  private invalidRenderServiceURL(renderServiceURL: string | URL, type: MessageType): boolean {
    if (renderServiceURL == null || renderServiceURL === '') {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} expected renderServiceURL to be provided. Received ${renderServiceURL}`));
      return true;
    }
    const url = this.getURL(renderServiceURL, 'renderService');
    if (url == null) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} exception encountered creating renderService URL from ${renderServiceURL}`));
      return true;
    }
    this._foviaUrl = url;
    return false;
  }

  private invalidCacheStatusServiceURL(cacheStatusServiceURL: string | URL, type: MessageType): boolean {
    if (cacheStatusServiceURL == null) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} expected cacheStatusServiceURL to be provided. Recived ${cacheStatusServiceURL}`));
      return true;
    }
    if (cacheStatusServiceURL === '') {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} expected cacheStatusServiceURL to be provided. Received ${cacheStatusServiceURL}`));
      return true;
    }
    const url = this.getURL(cacheStatusServiceURL, 'cacheStatusService');
    if (url == null) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} exception encountered creating cacheStatusService URL from ${cacheStatusServiceURL}`));
      return true;
    }
    this._cacheStatusServiceUrl = cacheStatusServiceURL as string;
    return false;
  }

  private invalidAuthorizationToken(authorizationToken: AuthorizationToken[], type: MessageType): boolean {
    // Sending no session tokens is OK -- an empty list.
    if (authorizationToken == null || authorizationToken.length === 0) {
      return false;
    }
    const invalidTokens: AuthorizationToken[] = [];
    for (const token of authorizationToken) {
      if (token == null || token === '') {
        invalidTokens.push(token);
      }
    }
    if (invalidTokens.length > 0) {
      this.sendErrorMessage(new PVErrorData(this._commId, type, `message ${type} ${invalidTokens.length} invalid session tokens encountered, tokens may not be null or empty`));
      return true;
    }
    return false;
  }

  private sendErrorMessage(error: PVErrorData): void {
    if (this.channel == null) {
      return;
    }
    console.log(`${this.constructor.name} sendErrorMessage`, error);
    this.channel.port2.postMessage({
      type: MessageType.ERROR,
      data: error
    } as MessageBase);
  }

  private listenForCacheStatusUpdates(): void {
    this.cacheStatusNotifier.cacheStatusUpdated$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((b: boolean) => {
        this.notifyCacheStatusUpdated();
      });
  }
}
