
import { Subject } from 'rxjs';

import { CacheStatus, UserId } from '@idgital/cache-status-interface';

import { IExamCacheStatusEx, StudyStatus } from '@pulse-zero-api';
import { ExamGroup, IExamCacheStatus, IExamGroupCacheStatus, IExamGroupStatus } from '@server-api';

// Class to track, update and notify when the status of an exam has changed

export class ExamCacheStatus implements IExamCacheStatusEx {
  // export class ExamCacheStatus {
  private previousStatus: CacheStatus;
  private _studyStatus: StudyStatus;
  private examStatus: IExamCacheStatus;
  private lastDateTime = Date.now();
  constructor(
    private cacheStatus$$: Subject<IExamCacheStatus[]>,
  ) {
    this.examStatus = {
      studyUID: '',
      cacheStatus: CacheStatus.eNOT_CACHED,
      timeStamp: new Date(this.lastDateTime)
    };
    // initial state change needs to trigger a cache status updated
    this.previousStatus = CacheStatus.ePURGED;
    this._studyStatus = StudyStatus.eNEW;
  }

  public get studyUID(): string {
    return this.examStatus.studyUID;
  }

  public set studyUID(studyUID: string) {
    this.examStatus.studyUID = studyUID;
  }

  public get studyStatus(): StudyStatus {
    return this._studyStatus;
  }

  public set studyStatus(value: StudyStatus) {
    this._studyStatus = value;
    this.updateCacheStatus();
  }

  public get cacheStatus(): CacheStatus {
    return this.examStatus.cacheStatus;
  }

  public get timeStamp(): Date {
    return this.examStatus.timeStamp;
  }
  public set cacheStatus(value: CacheStatus) {
    this.examStatus.cacheStatus = value;
    this.notifyIfChanged();
  }

  private updateCacheStatus(): void {
    // Map StudyStatus to CacheStatus
    switch (this._studyStatus) {
      // Deliberately fall through the following
      case StudyStatus.eNEW:
      case StudyStatus.eSTARTING:
      case StudyStatus.eCACHE_INITIAL_STATS:
      case StudyStatus.eLOADING:
      case StudyStatus.eCACHING_ERROR:
        // In theory, loading can fail, so we won't consider the study to be
        // "caching" until loading completes.
        this.cacheStatus = CacheStatus.eNOT_CACHED;
        break;
      // Deliberately fall through the following
      case StudyStatus.eCACHING_MANIFEST:
      case StudyStatus.eCREATE_CACHE_LIST:
      case StudyStatus.eCACHING_IMAGES:
      case StudyStatus.eCACHING_STATS:
      case StudyStatus.eCACHE_CLEANUP:
        this.cacheStatus = CacheStatus.eCACHING_IMAGES;
        break;
      case StudyStatus.eCACHED:
        this.cacheStatus = CacheStatus.eCACHED;
        break;
      default:
        console.error(`${this.constructor.name} unhandled case statment ${this.studyStatus}`);
    }
  }
  // Emit only when the status changes
  private notifyIfChanged(): void {
    const changed = this.previousStatus !== this.cacheStatus;
    if (changed) {
      console.log(`${this.constructor.name} ${this.examStatus.studyUID} '${this.previousStatus}' -> '${this.cacheStatus}'`);
      this.lastDateTime = getUniqueDateTime(this.lastDateTime);
      this.examStatus.timeStamp = new Date(this.lastDateTime);
      const list: IExamCacheStatus[] = [this.examStatus];
      this.cacheStatus$$.next(list);
    }
    this.previousStatus = this.cacheStatus;
  }
}

interface IGroupStatus extends IExamGroupCacheStatus, IExamGroupStatus {
  examGroup: ExamCacheStatus[];
}

// class to track, update and notify when the exam groups's caching status is changed
export class ExamGroupCacheStatus {

  private groupStatus: IGroupStatus;
  private previousStatus: CacheStatus = CacheStatus.eNOT_CACHED;
  private lastDateTime = Date.now();

  constructor(
    public cacheStatus$$: Subject<IExamGroupCacheStatus>
  ) {
    this.groupStatus = { orderId: 0, userId: 0, examGroup: [], examGroupCacheStatus: CacheStatus.eNOT_CACHED, timeStamp: new Date(this.lastDateTime) };
  }

  public setexamGroup(examGroup: ExamGroup, list: ExamCacheStatus[]): void {
    this.groupStatus.orderId = examGroup.orderId;
    this.groupStatus.userId = examGroup.user.userId;
    // for (const [index, entry] of list.entries()) {
    //   console.log(`${this.constructor.name} setexamGroup  ${this.orderId} ${index}`, entry);
    // }
    this.examGroup = list;
  }

  public get orderId(): number { return this.groupStatus.orderId; }

  public get userId(): number { return this.groupStatus.userId; }

  public get examGroup(): ExamCacheStatus[] { return this.groupStatus.examGroup; }
  public get timeStamp(): Date { return this.groupStatus.timeStamp; }

  public set examGroup(value: ExamCacheStatus[]) {
    //   console.log(`${this.constructor.name} set examGroup - before ${this.orderId} '${this.examGroupCacheStatus}'`, value);
    this.groupStatus.examGroup = value;
    this.notifyIfChanged();
    //   console.log(`${this.constructor.name} set examGroup - after ${this.orderId} '${this.examGroupCacheStatus}'`, this.examGroup);
  }

  public get examGroupCacheStatus(): CacheStatus { return this.groupStatus.examGroupCacheStatus; }

  public set examGroupCacheStatus(value: CacheStatus) {
    // This may occur when an exam group is removed.
    this.previousStatus = this.groupStatus.examGroupCacheStatus;
    this.groupStatus.examGroupCacheStatus = value;
    this.notify();
  }

  // Exam Group's cache status changes when any of it's exam's cache stats
  // changes. Emit only when it changes
  public notifyIfChanged(): boolean {
    // When at least one exam is caching then exam group is caching.
    // When all exams are cached, exam group is cached.
    // When studies are purged(because higher priority exams need to be cached) then cache - status of exam - groups that are related to that study are updated to caching or not - cached

    let cachedCount = 0;
    let cachingCount = 0;
    for (const exam of this.groupStatus.examGroup) {
      cachedCount += exam.cacheStatus === CacheStatus.eCACHED ? 1 : 0;
      cachingCount += exam.cacheStatus === CacheStatus.eCACHING_IMAGES ? 1 : 0;
      //  console.log(`${this.constructor.name} notifyIfChanged ${exam.studyUID} ${this.orderId} '${exam.studyStatus}' '${exam.cacheStatus}' cached: ${cachedCount} caching: ${cachingCount}`);
    }
    if (cachedCount === 0) {
      this.groupStatus.examGroupCacheStatus = CacheStatus.eNOT_CACHED;
    }
    if (cachingCount > 0) {
      this.groupStatus.examGroupCacheStatus = CacheStatus.eCACHING_IMAGES;
    }
    if (cachedCount === this.groupStatus.examGroup.length) {
      this.groupStatus.examGroupCacheStatus = CacheStatus.eCACHED;
    }
    return this.notify();
  }

  private notify(): boolean {
    const changed = this.previousStatus !== this.examGroupCacheStatus;
    if (changed) {

      this.lastDateTime = getUniqueDateTime(this.lastDateTime);
      this.groupStatus.timeStamp = new Date(this.lastDateTime);

      if (this.previousStatus === CacheStatus.eCACHED) {
        console.log(`${this.constructor.name} CHANGING GROUP STATUS ${this.orderId} '${this.previousStatus}' -> '${this.examGroupCacheStatus}'`);
      }
      this.cacheStatus$$.next(this.groupStatus);
      this.previousStatus = this.examGroupCacheStatus;
    }
    return changed;
  }

}

function getUniqueDateTime(lastDateTime: number): number {
  let utcNow = Date.now();
  while (utcNow === lastDateTime) {
    utcNow = Date.now();
  }
  return utcNow;
}
