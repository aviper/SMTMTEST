import { CachedExamStats, KB, MB } from '@pulse-zero-api';

class TrimmedExamStats {
  constructor(public studyUID: string, public modality: string, public manifestSizeBytes: number,
    public imageCount: number, public totalImageBytes: number, public skippedImageCount: number ){
  }
}

export class ExamGroupStats {

  constructor(private orderId: number, private examGroupDetails: CachedExamStats[] ) {
  }

  public logExamGroupStats(): void {
    console.info(`STATS OrderId ${this.orderId} ${JSON.stringify(this.getExamGroupStats())} `);
  }

  private getExamGroupStats(): TrimmedExamStats[] {
    const stats: TrimmedExamStats[] = [];
    for (const exam of this.examGroupDetails) {
      const manifestSize = exam.manifestKB * KB;
      const totalImageBytes = exam.totalMB * MB - manifestSize;
      stats.push(new TrimmedExamStats(
        exam.studyUID,
        exam.modality,
        manifestSize,
        exam.totalExamImages,
        totalImageBytes,
        exam.skippedImageCount
      ))
    }
    return stats;
  }
}
