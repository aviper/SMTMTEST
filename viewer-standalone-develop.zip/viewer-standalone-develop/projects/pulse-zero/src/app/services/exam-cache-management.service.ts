import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Sort } from '@angular/material/sort';
import { BehaviorSubject, distinctUntilChanged, mergeAll, Observable, of, Subject, takeUntil } from 'rxjs';

import { ControlService } from './control.service';

import {
  CachedExamStats,
  disableLoggerOverride,
  enableLoggerOverride,
  examDetailToString,
  IDiskInfo,
  IExamDetailInformation,
  IViewerInstanceFocusMessage,
  IViewerSessionUpdateMessage,
  PulseVisionApiService,
  StudyStatus,
  STARTING_QUOTA_MB
} from '@pulse-zero-api';

import {
  DEFAULT_HANGING_PROTOCOL,
  ExamGroup,
  ExamInformation,
  ExamLoadStatus,
  LocalStorageItems,
  LogSupport,
  ServerApiService,
  UUID
} from '@server-api';

import { PerfTiming } from '@worker-compatible-api';

import { getExamDetailFromExamGroup, DEFAULT_USER } from '../utilities/exam-details';
import { ExamSessionTimesTracker } from '../models/exam-session-times-tracker';
import { PersistentObject } from '../utilities/persistent-object';
import { SingletonAppManager } from '../utilities/singleton-app-manager';
import { IExamGroupDefinition, IExamGroupExamInformation, ExamGroupId } from '@idgital/vision-auth-interface';
import { CacheStatusNotifierService } from './cache-status-notifier.service';
import { ExamGroupStats } from './types/exam-group-stats';

const QUOTA_MESSAGE_NORMAL = 'Caching studies..';
const QUOTA_MESSAGE_DROPPING = 'Dropping studies..';
const QUOTA_MESSAGE_WAITING = 'Quota exceeded, nothing to drop .. waiting for update';
const QUOTA_MESSAGE_DONE = 'Caching complete';
const DROP_ALL = true;
const SHOULD_LOG = true;

const VIEWED_PRIORITY = 1;
const NORMAL_PRIORITY = 100;
const NO_CACHING_PRIORITY = 1000000; // Identifies inactive entries in the exam cache list.

interface IViewerInstanceInfo {
  viewerInstanceID: UUID;
  primaryStudyUID: string;
  comparisonStudyUIDs: string[];
  lastUpdateMsecs: number;
}

class ExamGroupMap {

  // orderId -> ExamGroup
  private examGroupMap = new Map<number, ExamGroup>();
  // OrderId -> list of IExamDetailInformation for that order.
  private orderDetailMap = new Map<number, IExamDetailInformation[]>();
  // StudyUID -> list of all list of all exam group detail information containing this study UID
  private studyUIDMap = new Map<string, IExamDetailInformation[]>();
  private cacheList: IExamDetailInformation[] = [];
  private examGroupList: ExamGroup[] = [];

  constructor(private cacheStatusNotifier: CacheStatusNotifierService) {
  }

  // Add exam group list to a new object and assign priority.
  set examGroups(examGroupList: ExamGroup[]) {
    // Shouldn't be calling this method on an ExamGroupMap that has already been initialized.
    if (this.examGroupList.length > 0) {
      console.error(`${this.constructor.name} Unexpected - currentExamGroupList is already defined`);
      return;
    }

    // Track the exam group list that was used to create this map
    this.examGroupList = [...examGroupList];
    console.log(`${this.constructor.name} submitting new exam list`, examGroupList);
    LogSupport.logInfo(`${this.constructor.name} submitting new study list`);
    // Establish the starting priority for the new exams -- priority just needs to be > viewed exam priority
    // lower number are higher priority
    let priority = NORMAL_PRIORITY;
    for (const studyGroup of examGroupList) {
      const exmDetails: IExamDetailInformation[] = getExamDetailFromExamGroup(priority, studyGroup);
      this.examGroupMap.set(studyGroup.orderId, studyGroup);
      this.orderDetailMap.set(studyGroup.orderId, exmDetails);
      // Track the studyUID -> IExamDetailInformation for exams -- caching for one, will cache
      // for many. addOrUpdateExamGroup will also take care of comparison studies being added or removed
      const examGroupStatus = this.cacheStatusNotifier.addorUpdateExamGroup(studyGroup);
      for (const entry of exmDetails) {
        let examDetailList = this.studyUIDMap.get(entry.examInfo.studyUID);
        let isNew = false;
        // A studyUID may be in more than one exam group, assemble the exam details, associated
        // with a single studyUID, from all exam groups.
        if (examDetailList == null) {
          const details: IExamDetailInformation[] = [];
          examDetailList = details;
          this.studyUIDMap.set(entry.examInfo.studyUID, examDetailList);
          isNew = true;
        }
        entry.groupCacheStatus = examGroupStatus;
        entry.examCacheStatus = this.cacheStatusNotifier.addOrUpdateExam(entry.examInfo);
        examDetailList.push(entry);

        // We only need to cache one instance of each study, but we need to track
        // them all.
        if (isNew) {
          this.cacheList.push(entry);
        }
      }
      // All new exams are now marked with their current priority
      priority++;
    }

  }

  // Evaluate whether 'this' examGroup list is the same as another list.
  public examGroupListWillChange(examGroups: ExamGroup[]): boolean {
    if (examGroups.length !== this.examGroupList.length) {
      return true;
    }
    for (let i = 0; i < examGroups.length; i++) {
      // Same order of exam groups?
      if (examGroups[i].groupId !== this.examGroupList[i].groupId) {
        return true;
      }
      // Same Exam group contents?
      if (examGroups[i].allExams.length !== this.examGroupList[i].allExams.length) {
        return true;
      }
      // Same primary exams -- just being cautious, should be true for the same exam groupId...
      if (examGroups[i].primaryExam.studyUID !== this.examGroupList[i].primaryExam.studyUID) {
        return true;
      }
      // Same comparison exams
      if (examGroups[i].comparisonExams.length !== this.examGroupList[i].comparisonExams.length) {
        return true;
      }
      // Comparison exams in the same order
      for (let j = 0; j < examGroups[i].comparisonExams.length; j++) {
        if (examGroups[i].comparisonExams[j].studyUID !== this.examGroupList[i].comparisonExams[j].studyUID) {
          return true;
        }
      }
    }
    return false;
  }

  public examGroupCount(): number {
    return this.orderDetailMap.size;
  }

  public examListCount(): number {
    return this.cacheList.length;
  }

  public orderList(studyUID: string): string {
    const orderList: string[] = [];
    const details = this.studyUIDMap.get(studyUID);
    if (details != null) {
      for (const entry of details) {
        orderList.push(entry.examGroup.orderId.toString(10));
      }
    }
    return orderList.length === 0 ? '' : orderList.join(', ');
  }

  public resolveOrders(newOrders: ExamGroupMap): void {
    let inactiveCachedExamList: IExamDetailInformation[] = [];
    // Are there existing orders that need to be resolved with these new orders?
    if (this.orderDetailMap.size > 0) {
      // Remove any non-cached exam Groups
      this.removeNotCachedOrders(newOrders);
      // The new orders establishes the new priority for exams from the previous cache list,
      // when the exams are present in both lists. Identify the intersection of
      // the old and new lists so we can update cache info for the new list.
      const retainedExamInfo = this.retainedOrdersFromCacheList(newOrders);
      // Update the caching status for the new list from the details being retained.
      this.updateCacheStatus(newOrders, retainedExamInfo);
      // Reset remaining exams NO_PRIORITY
      // Exam groups that are no longer being actively cached will remain on the
      // list with a priority of NO_PRIORITY. We will not actively cache exams of NO_PRIORITY
      // and will use these exams as drop candidates.
      // Further, we will not actively remove NO_PRIORITY exams from cache-status monitoring.
      // Get the list remaining exams that are going inactive.
      inactiveCachedExamList = this.remainingCachedExamList(newOrders);
      this.examGroupList = newOrders.examGroupList;
    }
    this.udpateTrackingMaps(newOrders, inactiveCachedExamList);
    this.cacheList = newOrders.cacheList.concat(inactiveCachedExamList);
  }

  public getCacheList(): IExamDetailInformation[] {
    return [...this.cacheList];
  }

  public cached(cachedExam: IExamDetailInformation): void {
    this.updateCacheStatusInfoList(this.studyUIDMap.get(cachedExam.examInfo.studyUID), cachedExam);
  }

  public markCached(entry: IExamDetailInformation): void {
    if (entry.cached) {
      return;
    }
    entry.examInfo.loadStatus = ExamLoadStatus.LOADED;
    entry.cached = true;
    if (entry.examCacheStatus != null) {
      entry.examCacheStatus.studyStatus = StudyStatus.eCACHED;
    }
    console.log(`${this.constructor.name} markCached ${entry.examInfo.studyUID} '${entry.examCacheStatus?.cacheStatus}' cached: ${entry.cached} status: ${entry.examCacheStatus?.studyStatus}`);
  }

  public has(studyUID: string): boolean {
    return this.studyUIDMap.has(studyUID);
  }

  public getExamDetail(studyUID: string): IExamDetailInformation | undefined {
    const examDetails = this.studyUIDMap.get(studyUID);
    if (examDetails == null) {
      console.error(`${this.constructor.name} getExamDetail unexpected studyUID ${studyUID} not in ExamGroupMap`);
      return examDetails;
    }
    // We are caching the first one in the list of examDetails
    return examDetails[0];
  }

  public markAsNotCached(studyUID: string): boolean {
    const details = this.studyUIDMap.get(studyUID);
    if (details == null) {
      return false;
    }
    for (const entry of details) {
      this.clearCaching(entry);
    }
    console.warn(`${this.constructor.name} markAsNotCached clearing cached info from ${studyUID}`);
    return true;
  }

  // Studies may be dropped from the cache when quota limits are
  // encountered. Two use cases
  // 1. Study is part of a current ExamGroup - so we just clear it's cache status
  // 2. Study is not part of a current ExamGroup -- so we remove the study from tracking and clear it's cache status.
  public onCacheDeletion(studyUID: string): void {
    const details = this.studyUIDMap.get(studyUID);
    if (details == null || details.length === 0) {
      console.error(`${this.constructor.name} onCacheDeletion unexpected studyUID ${studyUID} not in studyUIDMap`);
      return;
    }
    const entry = details[0];
    const isInactive = entry.priority >= NO_CACHING_PRIORITY;
    this.clearCaching(entry);
    this.cacheStatusNotifier.addOrUpdateExam(entry.examInfo);
    if (isInactive) {
      // Evaluate each of the associated inactive orders to see if they can be removed too
      for (const examDetail of details) {
        this.removeOrder(examDetail.examGroup.orderId);
      }
    }
  }

  private clearCaching(entry: IExamDetailInformation): void {
    // Mark it as not cached, so cache-status is updatead for this study
    entry.cached = false;
    entry.examInfo.loadStatus = ExamLoadStatus.NOT_LOADED;
    if (entry.examCacheStatus != null) {
      entry.examCacheStatus.studyStatus = StudyStatus.eNEW;
    }
  }

  private udpateTrackingMaps(newOrderMap: ExamGroupMap, inactiveCachedExamList: IExamDetailInformation[]): void {
    // Exams & ExamGroups in the current maps need to represent the inactive & active
    // items in the cache, and active items to be cached. So merge the maps and update any missing
    // exam details as needed.
    // Note that if multiple maps have the same key, the value of the merged map will be the value of the last merging map with that key.
    this.orderDetailMap = this.orderDetailMap.size === 0 ? newOrderMap.orderDetailMap : new Map<number, IExamDetailInformation[]>([...this.orderDetailMap, ...newOrderMap.orderDetailMap]);
    // console.log(`updated orderDetailMap ${this.orderDetailMap.size} newOrderDetailMap ${newOrderMap.orderDetailMap.size} `);
    this.examGroupMap = this.examGroupMap.size === 0 ? newOrderMap.examGroupMap : new Map<number, ExamGroup>([...this.examGroupMap, ...newOrderMap.examGroupMap]);
    // console.log(`updated examGroupMap ${this.examGroupMap.size} newExamGroupMap ${newOrderMap.examGroupMap.size} `);
    this.studyUIDMap = newOrderMap.studyUIDMap;
    // Update the new studyUID map
    this.addMissingExamDetails(inactiveCachedExamList);
  }

  private addMissingExamDetails(inactiveCachedExamList: IExamDetailInformation[]): void {
    for (const entry of inactiveCachedExamList) {
      if (this.studyUIDMap.has(entry.examInfo.studyUID)) {
        continue;
      }
      console.error(`${this.constructor.name} **** addMissingExamDetails need to add  ${entry.examInfo.studyUID} to studyUIDMap`, entry);

      let examDetailList = this.studyUIDMap.get(entry.examInfo.studyUID);
      // By definition, the inactive exams should not already exist in this map
      if (examDetailList == null) {
        const details: IExamDetailInformation[] = [];
        examDetailList = details;
        this.studyUIDMap.set(entry.examInfo.studyUID, examDetailList);
        examDetailList.push(entry);
        continue;
      }
      // prepare to add the matching entry if it's not already in the studyUID map.
      console.error(`${this.constructor.name} addMissingExamDetails map inconsistency ${entry.examInfo.studyUID} is already in the studyUIDMap`, entry);
      const orderId = entry.examGroup.orderId;
      const index = examDetailList.findIndex((entry) => entry.examGroup.orderId === orderId);
      if (index < 0) {
        examDetailList.push(entry);
      } else {
        console.error(`${this.constructor.name} addMissingExamDetails ${entry.examInfo.studyUID} was already in the studyUIDMap`, entry, examDetailList[index]);
      }
    }
  }

  private updateCacheStatus(newOrders: ExamGroupMap, keptExamDetails: IExamDetailInformation[]): void {
    while (keptExamDetails.length > 0) {
      const examDetails = keptExamDetails[0];
      keptExamDetails.splice(0, 1);
      const studyUID = examDetails.examInfo.studyUID;
      const index = newOrders.cacheList.findIndex((entry) => entry.examInfo.studyUID === studyUID);
      if (index > -1) {
        this.updateCacheStatusInfo(newOrders.cacheList[index], examDetails);
        const detailList = this.studyUIDMap.get(studyUID);
        this.updateCacheStatusInfoList(detailList, examDetails);
      } else {
        console.error(`${this.constructor.name} updateCacheStatus unexpected condition ${studyUID} not found in new cacheList `);
      }
    }
  }

  // Before integrating the new cache list, give exising exams no priority --
  // List may be comprised of newly inactive exams and exams that
  // previously became inactive. The priority of previous exams should continue to
  // fall as newly inactive exams arrive.
  private assignInactivePriority(examDetails: IExamDetailInformation[]): void {
    for (let i = 0; i < examDetails.length; i++) {
      // Preserve the exising exam caching priority order by simply pushing the priority into the NO_PRIORITY range
      if (examDetails[i].priority < NO_CACHING_PRIORITY) {
        examDetails[i].priority = NO_CACHING_PRIORITY + i + 1;
        continue;
      }
      // Was previously inactive? incrementally lower it's priority as compared to newer studies
      examDetails[i].priority += NORMAL_PRIORITY;
    }
  }

  private removeNotCachedOrders(newOrder: ExamGroupMap): void {
    const newOrderIds = Array.from(newOrder.examGroupMap.keys());
    const currentOrderIds = Array.from(this.examGroupMap.keys());
    const toRemoveOrderList = currentOrderIds.filter(orderId => !newOrderIds.includes(orderId));

    console.info(`${this.constructor.name} removeNotCachedOrders evaluating ${toRemoveOrderList.length} orders`);
    for (const orderId of toRemoveOrderList) {
      // Was exam cached at all?
      if (!this.cacheStatusNotifier.examGroupIsInCache(orderId)) {
        // Nope, remove it from tracking
        this.removeOrder(orderId);
      }
    }
  }

  // Get the intersection of the new and old cache lists
  private retainedOrdersFromCacheList(newOrder: ExamGroupMap): IExamDetailInformation[] {
    const newExamCacheList = newOrder.cacheList.map(entry => entry.examInfo.studyUID);
    const retainedExams = this.cacheList.filter((value) => newExamCacheList.includes(value.examInfo.studyUID));
    return retainedExams;
  }

  // Get a prioritized list of the remaining exams. After non cached examGroups have been removed.
  private remainingCachedExamList(newOrder: ExamGroupMap): IExamDetailInformation[] {
    const newStudyUIDs = Array.from(newOrder.studyUIDMap.keys());
    const currentStudyUIDs = Array.from(this.studyUIDMap.keys());
    const remainingStudyUIDs = currentStudyUIDs.filter(studyUID => !newStudyUIDs.includes(studyUID));

    const remainingExams: IExamDetailInformation[] = [];
    for (const studyUID of remainingStudyUIDs) {

      console.info(`${this.constructor.name} remainingCachedExams ${studyUID}`);
      const details: IExamDetailInformation[] | undefined = this.studyUIDMap.get(studyUID);
      if (details == null) {
        console.error(`${this.constructor.name} unexpected condition details for ${studyUID} not in map`);
        continue;
      }
      // Any remaining orders are in the cache, migrate them to the newOrder map so
      // we can properly manage our maps and report on their caching status.
      for (const examDetail of details) {
        const orderId = examDetail.examGroup.orderId;
        if (newOrder.examGroupMap.has(orderId)) {
          continue;
        }
        console.info(`${this.constructor.name} remainingCachedExamList adding order ${orderId} for ${studyUID}`);
        const examGroup = this.examGroupMap.get(orderId);
        if (examGroup != null) {
          newOrder.examGroupMap.set(orderId, examGroup);
          this.examGroupMap.delete(orderId);
        }
        const examGroupDetails = this.orderDetailMap.get(orderId);
        if (examGroupDetails != null) {
          newOrder.orderDetailMap.set(orderId, examGroupDetails);
          this.examGroupMap.delete(orderId);
        }
      }
      newOrder.studyUIDMap.set(studyUID, details);
      this.studyUIDMap.delete(studyUID);
      // The list contains the cross reference of this study to other groups, inactive studies
      remainingExams.push(details[0]);
    }
    // Now assign an inactive priority to these exams
    this.assignInactivePriority(remainingExams);
    console.info(`${this.constructor.name} remainingCachedExamList examGroupMap ${this.examGroupMap.size} orderDetailMap ${this.orderDetailMap.size}`);
    return remainingExams;
  }

  // Remove order from our tracking
  private removeOrder(orderId: number): void {
    console.info(`${this.constructor.name} removing order ${orderId}`);
    // Stop tracking the cache status for this exam group
    this.cacheStatusNotifier.removeExamGroupFromNotification(orderId);

    // Cleanup the studies associated with this order
    const details: IExamDetailInformation[] | undefined = this.orderDetailMap.get(orderId);
    if (details == null) {
      console.error(`${this.constructor.name} unexpected condition details for ${orderId} not in map`);
      return;
    }
    for (const examDetail of details) {
      const studyUID = examDetail.examInfo.studyUID;
      const detailList: IExamDetailInformation[] | undefined = this.studyUIDMap.get(studyUID);
      if (detailList == null) {
        console.error(`${this.constructor.name} unexpected condition iterating ${orderId} ${studyUID} relationships not found in map`);
        continue;
      }
      // prepare to remove the matching entry
      const index = detailList.findIndex((entry) => entry.examGroup.orderId === orderId);
      // We cache using the first entry in this list
      // The first entry of the list of entries for this StudyUID contains
      // the caching information for this study UID. Be sure to preserve this information
      // before we remove the first entry from the list.
      const firstEntry = detailList[0];
      detailList.splice(index, 1);
      this.updateCacheStatusInfoList(detailList, firstEntry);
      if (detailList.length === 0) {
        console.info(`${this.constructor.name} removeOrders for ${orderId} no longer caching ${studyUID} `);
        this.studyUIDMap.delete(studyUID);
      }
    }
    this.orderDetailMap.delete(orderId);
    this.examGroupMap.delete(orderId);
  }

  // Assumes all entries are for the same studyUID.
  private updateCacheStatusInfoList(entries: IExamDetailInformation[] | undefined, from: IExamDetailInformation): void {
    if (entries == null) {
      return;
    }
    for (const entry of entries) {
      this.updateCacheStatusInfo(entry, from);
    }
  }

  private updateCacheStatusInfo(entry: IExamDetailInformation, from: IExamDetailInformation): void {
    if (entry.examInfo.studyUID !== from.examInfo.studyUID) {
      const studyUID = entry.examInfo.studyUID;
      const orderId = entry.examGroup.orderId;
      console.error(`${this.constructor.name} updateCacheStatusInfo invalid request for mismatching studyUIDs in ${orderId} ${studyUID} from ${from.examGroup.orderId} ${from.examInfo.studyUID}`);
    }
    entry.cached = from.cached;
    entry.examInfo.loadStatus = from.examInfo.loadStatus;
  }
}



@Injectable({
  providedIn: 'root'
})
/*
This service orchestrates OPFS Activities, using our opfs services, but does not touch
the cache directly.

OPFS Study cache may be modified through several mechanisms:
1. User pastes a list of studyUIDs into the app -- generally a development only path
2. An external request adds new studies to be cached - mechanism T.B.D
3. An end user has a UI which allows them to:
  a. see the status of the caching for each exam they have requested
  b. manually remove studies from the cache
  c. adjust the cache size
4. Each cached study contains tracking information regarding:
   a. when the study was cached
   b. who cached the study
5. Cache is trimmed:
  a. using LRC (least recently cached) order by this service when the cache exceeds its target
   size.
  b. studies cached for a different user have higher trimming priority than those for the current user
  c. requests to re-cache a study, which is already in the cache for a different user, causes the study to be
     removed from the cache before the study is re-cached.
6. An end user deletes this cache when they delete their browser cache
7. One or more other PulseVision applications is running on the same cache - launched
   from another browser window
8. We cache on a "best-efforts" basis -- meaning: if the underlying OS requires more disk space,
   the contents of this cache will be purged -- referred to as 'eviction'. Eviction is an all-or-nothing
   operation.
*/
export class ExamCacheManagementService implements OnDestroy {
  private cacheQuotaMB$$: BehaviorSubject<number>;
  private cacheQuotaMessag$$: BehaviorSubject<string>;
  private cacheReport$$ = new BehaviorSubject<string>('');
  private currentExamGroupMap: ExamGroupMap;
  private currentExams: IExamDetailInformation[] = [];    // Current cache list
  private currentSelectedExams: string[] = [];
  private currentViewerSessions = new Map<UUID, IViewerInstanceInfo>();
  private examSessionTimesTracker = new ExamSessionTimesTracker();
  private examStats: CachedExamStats[] = [];
  private isActiveAppInstance = false;
  private isCaching$$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private isDropping = false;
  private pulseVisionApiInitComplete = false;
  private singletonAppManager = new SingletonAppManager('pulseVision', this.ngZone);
  private statsTable: MatTableDataSource<CachedExamStats> | null = null;
  private unsubscribe$$ = new Subject<void>();
  private viewerInstanceWithFocus: UUID | null = null;

  public externalRequestCount = 0;

  constructor(
    private cacheStatusNotifier: CacheStatusNotifierService,
    private controlService: ControlService,
    private pulseVisionService: PulseVisionApiService,
    private serverApi: ServerApiService,
    private ngZone: NgZone) {

    this.currentExamGroupMap = new ExamGroupMap(this.cacheStatusNotifier);
    this.cacheQuotaMB$$ = new BehaviorSubject<number>(STARTING_QUOTA_MB);
    this.cacheQuotaMessag$$ = new BehaviorSubject<string>('');

    this.pulseVisionService.makeCacheSpaceAvailableFn = this.makeCacheSpaceAvailable.bind(this);
  }

  public get cacheQuotaMessage$(): Observable<string> {
    return this.cacheQuotaMessag$$;
  }

  public get isCaching$(): Observable<boolean> {
    return this.isCaching$$;
  }

  public get cacheReport$(): Observable<string> {
    return this.cacheReport$$;
  }

  public async init(): Promise<boolean> {
    const perfTime = new PerfTiming();
    this.isActiveAppInstance = await this.singletonAppManager.onAppStartup();
    if (this.isActiveAppInstance) {
      await this.examSessionTimesTracker.init();
      await this.examSessionTimesTracker.restore();
      this.testListSort();
      this.subscriptions();
    }
    console.log(`${this.constructor.name} init() complete ${perfTime.elapsedSecondsMessage()}`);
    return this.isActiveAppInstance;
  }

  public ngOnDestroy(): void {
    this.singletonAppManager.onAppShutdown();
    this.cacheStatusNotifier.ngOnDestroy();
    this.unsubscribe();
  }

  public isAppAlreadyRunning(): boolean {
    return !this.isActiveAppInstance;
  }

  public get userId(): string {
    return this.pulseVisionService.userId;
  }

  public get cacheQuotaMB$(): Observable<number> {
    return this.cacheQuotaMB$$;
  }

  public get cacheQuotaMB(): number {
    return this.cacheQuotaMB$$.value;
  }

  public set cacheQuotaMB(value: number) {
    this.cacheQuotaMB$$.next(value);
  }

  public get cacheUsageMB$(): Observable<number> {
    return this.pulseVisionService.cacheUsageMB$;
  }

  public get cacheUsageMB(): number {
    return this.pulseVisionService.cacheUsageMB;
  }

  public get cacheSpaceAvailableMB(): number {
    return this.cacheQuotaMB - this.cacheUsageMB;
  }

  public get quotaError$(): Observable<boolean> {
    return this.pulseVisionService.quotaError$;
  }

  public get opfsEvictionDetectionCount$(): Observable<number> {
    return this.pulseVisionService.opfsEvictionDetectionCount$;
  }

  public set selectedStudies(studies: string[]) {
    this.currentSelectedExams = studies;
  }

  public get selectedStudies(): string[] {
    return this.currentSelectedExams;
  }

  public get cachingPaused(): boolean {
    return this.pulseVisionService.cachingPaused;
  }

  public set stats(ref: MatTableDataSource<CachedExamStats>) {
    this.statsTable = ref;
    this.statsTable.data = this.examStats;
  }

  public get stats(): MatTableDataSource<CachedExamStats> | null {
    return this.statsTable;
  }

  public sortTable(sort: Sort): void {
    if (this.statsTable == null) {
      return;
    }
    const data = this.examStats.slice();
    if (!sort.active || sort.direction === '') {
      this.statsTable.data = data;
      return;
    }
    this.statsTable.data = this.sortDataTable(data, sort);
  }

  public async terminateFoviaConnection(): Promise<void> {
    // Ensure previous connection has completed
    await this.pulseVisionService.foviaInitCompleted();
    console.info(`${this.constructor.name} reconnectToFovia starting`);
    await this.serverApi.disconnect();
  }

  private async updateCurrentexamList(newOrders: ExamGroupMap): Promise<void> {
    try {
      // Construct a new exam list from the newly arrived orders
      this.currentExamGroupMap.resolveOrders(newOrders);
      // OK to update it any time...
      this.currentExams = this.currentExamGroupMap.getCacheList();

      // Update UI report of current cache state
      await this.getStatsFromCache(SHOULD_LOG);

      // Track the number of requests we've processed
      this.externalRequestCount++;
      // Ensure the viewed exams are properly combined with these studies. This will also resume caching
      await this.cacheExamsInActiveViewerSessionsFirst();
      // Resume caching our list if it had stopped
      this.resumeCaching();
    } catch (err) {
      console.error(`${this.constructor.name} updateCurrentexamList exception ${JSON.stringify(err)}`);
    }
  }

  public async clearExamCache(): Promise<void> {
    await this.stopCaching();
    await this.pulseVisionService.clearExamsFromCache();
    // Reset our caching state
    this.currentSelectedExams = [];
    this.currentExamGroupMap = new ExamGroupMap(this.cacheStatusNotifier);
    this.currentExams = [];
    await this.cacheStatusNotifier.reInit();
    await this.cacheStatusNotifier.updateStartupCacheStatus();
    // Wait for the next notification to resume caching
  }

  public async simulateEviction(): Promise<void> {
    await this.pulseVisionService.simulateOpfsEviction();
    await PersistentObject.clearAll();
  }

  // Deleted directly from UI
  public async deleteSelectedStudies(): Promise<void> {
    if (this.currentSelectedExams.length === 0) {
      return;
    }
    const wasCaching = this.isCaching;
    await this.stopCaching();
    for (const studyUID of this.currentSelectedExams) {
      await this.deleteExamFromCache(studyUID);
    }
    if (wasCaching) {
      this.resumeCaching();
    }
  }

  public async stopCaching(): Promise<void> {
    this.isCaching = false;
    await this.pulseVisionService.stopCaching();
  }

  public resumeCaching(): void {
    this.isCaching = true;
  }

  public async publishDiskSpaceInfo(): Promise<void> {
    await this.pulseVisionService.publishDiskInfo();
  }

  public getDiskInfo$(): Observable<IDiskInfo> {
    return this.pulseVisionService.getDiskInfo$();
  }

  public async getStudyUIDsInCache(): Promise<string[]> {
    return await this.pulseVisionService.getStudyUIDsInCache();
  }

  public async storagePersisted(): Promise<boolean> {
    return await this.pulseVisionService.storagePersisted();
  }

  public async storagePersist(): Promise<boolean> {
    return await this.pulseVisionService.storagePersist();
  }

  private set isCaching(value: boolean) {
    this.isCaching$$.next(value);
  }

  private get isCaching(): boolean {
    return this.isCaching$$.value;
  }

  private set cacheQuotaMessage(value: string) {
    this.cacheQuotaMessag$$.next(value);
  }

  private set cacheReport(value: string) {
    this.cacheReport$$.next(value);
  }

  private async waitForPulseZeroApiInitToComplete(): Promise<void> {
    return new Promise(async (resolve) => {
      await this.pulseVisionService.initComplete();
      if (!this.pulseVisionApiInitComplete) {
        // Trigger clearing and updating of current opfs cache status just once to
        // handle startup initialization
        await this.cacheStatusNotifier.updateStartupCacheStatus();
        this.pulseVisionApiInitComplete = true;
      }
      return resolve();
    });
  }

  private updateCacheReport(current: number, totalExamsToCache: number, totalCached: number): void {
    this.cacheReport = `${current}/${totalExamsToCache} Exams: (${totalCached}) ExamGroups: (${this.currentExamGroupMap.examGroupCount()})`;
  }

  private async getStatsFromCache(shouldLog: boolean = false): Promise<void> {
    if (this.statsTable == null) {
      // console.info(`${this.constructor.name} getStatsFromCache stats is null.`);
      return;
    }
    const statsTable = this.statsTable;

    // Reset selected study operations after caching notifications
    this.selectedStudies = [];

    const studyUIDs = await this.getStudyUIDsInCache();
    const examStats: CachedExamStats[] = [];
    const promises = new Array<Promise<CachedExamStats | null>>();
    let currentCacheCount = 0;
    for (const uid of studyUIDs) {
      const stats = this.getCachedExamStats(uid);
      if (this.currentExamGroupMap.has(uid)) {
        currentCacheCount++;
      }
      promises.push(stats);
    }
    const cachedStats = await Promise.all(promises);

    for (const stats of cachedStats) {
      if (stats != null) {
        stats.orders = this.currentExamGroupMap.orderList(stats.studyUID);
        examStats.push(stats);
        if (this.currentExamGroupMap.has(stats.studyUID)) {
          const exam = this.currentExamGroupMap.getExamDetail(stats.studyUID);
          if (exam != null) {
            stats.priority = exam.priority < NO_CACHING_PRIORITY ? exam.priority.toString(10) : 'none';
            if (this.externalRequestCount === 0) {
              // Establish the initial cache status, based on what we find in the cache
              this.currentExamGroupMap.markCached(exam);
            }
            this.currentExamGroupMap.cached(exam);
          }
        } else {
          // give exams that are not in an exam group a special priority, they came from the cache
          stats.priority = 'none';
        }
      }
    }

    examStats.sort((a, b): number => {
      return a.studyCacheTime < b.studyCacheTime ? -1 : 1;
    });

    // Update the UI table within the zone, so we get change detection
    this.examStats = examStats;
    this.updateCacheReport(currentCacheCount, this.currentExamGroupMap.examListCount(), studyUIDs.length);
    shouldLog ? console.info(`${this.constructor.name} getStatsFromCache table has ${this.examStats.length} entries.`) : {};
    statsTable.data = this.examStats;
  }

  private async getCachedExamStats(studyUID: string): Promise<CachedExamStats | null> {
    return this.pulseVisionService.getCachedExamStats(studyUID);
  }

  private subscriptions(): void {
    // Let OPFS service know about the user's current quota setting
    this.cacheQuotaMB$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((cacheQuotaMB: number) => {
        if (this.pulseVisionService.cacheQuotaMB !== cacheQuotaMB) {
          console.info(`${this.constructor.name} New cacheQuotaMB changing to ${cacheQuotaMB}`);
        }
        this.pulseVisionService.cacheQuotaMB = cacheQuotaMB;
      });

    // Track entire exam group caching completed
    this.cacheStatusNotifier.examGroupCacheComplete$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (orderId: number) => {
        this.ngZone.runOutsideAngular(
          (): void => this.onHandleExamGroupCachedComplete(orderId));
      });

    this.pulseVisionService.examCount$
      .pipe(
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(async (examCount: number) => {
        await this.onHandleExamCountChange(examCount);
      });

    // Stay up-to-date on the cache status after it was initialized
    this.waitForPulseZeroApiInitToComplete().then((): void => {
      console.log(`>>>>>>> Subscribing after pulseVisionService.initComplete()`);

      // Listen for OPFS service quota excursions
      this.quotaError$
        .pipe(
          // Not using distinct until changed so we can re-trigger dropping when a new exam group list arrives
          // and we still have a problem.
          takeUntil(this.unsubscribe$$)
        )
        .subscribe(async (quotaError: boolean) => {
          await this.onHandleQuotaError(quotaError);
        });
      // Listen to fovia service and signals from control service for fovia connect requests
      of(this.controlService.signalInitFovia$, this.pulseVisionService.foviaConnected$)
        .pipe(
          mergeAll(),
          // Keep trying to reconnect until we know better....
          takeUntil(this.unsubscribe$$)
        )
        .subscribe(async (connected: boolean | null) => {
          await this.onHandleFoviaConnected(connected);
        });

      this.controlService.currentExamList$
        .pipe(
          takeUntil(this.unsubscribe$$)
        )
        .subscribe(async (examGroups: ExamGroup[]) => {
          this.ngZone.runOutsideAngular(async (): Promise<void> => {
            // This entry point creates a new currentExams list for caching and then signals to begin caching
            // It does not perform caching.
            console.log(`currentExamList$ New exam group list submitted, quotaError: ${this.hasQuotaError} isDropping: ${this.isDropping}`, examGroups);
            await this.onHandleNewExamGroups(examGroups);
            console.log(`currentExamList$ New exam group list handling complete, quotaError: ${this.hasQuotaError} isDropping: ${this.isDropping}`, examGroups);
          });
        });

      this.isCaching$
        .pipe(
          distinctUntilChanged(),
          takeUntil(this.unsubscribe$$)
        )
        .subscribe(async (bShouldCache: boolean) => {
          await this.ngZone.runOutsideAngular(async (): Promise<void> => {
            // This entry point performs caching
            if (bShouldCache) {
              // The only place caching is performed start and stop with observable.
              console.info(`isCaching$ resume caching ${this.currentExams.length} exams isCaching:${this.isCaching}`);
              await this.onResumeCaching();
              console.info(`isCaching$ resume complete ${this.currentExams.length} exams remaining isCaching:${this.isCaching}`);
            } else {
              console.info(`isCaching$ stopped ${this.currentExams.length} exams isCaching:${this.isCaching}`);
            }
          });
        });

      this.opfsEvictionDetectionCount$
        .pipe(
          takeUntil(this.unsubscribe$$)
        )
        .subscribe((count: number) => {
          if (count > 0) {
            this.onCacheEvictionDetected().then();
          }
        });

      this.pulseVisionService.registerViewerSessionUpdateHandler((updateMsg) => {
        this.onViewerSessionUpdated(updateMsg);
      });

      this.pulseVisionService.registerViewerFocusUpdateHandler((focusMsg) => {
        this.onViewerFocusUpdated(focusMsg);
      });
    });
  }

  protected onHandleExamGroupCachedComplete(orderId: number): void {
    // Gather exam group stats for this order, and log the stats
    const examGroupID = orderId.toString(10);
    const stats: CachedExamStats[] = [];
    for (const examStats of this.examStats) {
      if (examStats.orders.indexOf(examGroupID) < 0) {
        continue;
      }
      stats.push(examStats);
    }
    const examGroupStats = new ExamGroupStats(orderId, stats);
    // Log all of the stats for this cached exam group
    examGroupStats.logExamGroupStats();
  }

  protected async onHandleExamCountChange(examCount: number): Promise<void> {
    try {
      if (this.statsTable == null) {
        return;
      }
      await this.getStatsFromCache();
      if (this.cacheStatusNotifier.reportStartupStats) {
        this.cacheStatusNotifier.startupStatus(this.examStats);
      }
    } catch (err) {
      console.error(`${this.constructor.name} onHandleExamCountChange exception ${JSON.stringify(err)}`);
    }
  }

  protected async onHandleQuotaError(quotaError: boolean): Promise<void> {
    const message = `${this.constructor.name} pulseVisionService.quotaError$ subscription fires ${quotaError}`;
    // Quiet logging, when quota changes, when it changes, thinking we don't want to filter these notifications, so
    // we continue to drop when required
    // quotaError ? console.error(message) : console.info(message);

    if (!quotaError) {
      // Quota is ok
      // console.log(message);
      return;
    }
    // If we're already dropping as part of a previous notification, we're good.
    if (this.isDropping) {
      console.info(`${this.constructor.name} pulseVisionService.quotaError$ already dropping exams.`);
      return;
    }
    console.info(`${this.constructor.name} pulseVisionService.quotaError$ try dropping exams.`);
    // We will stop caching when we bump up against quota and there's nothing we can drop. When this occurs,
    // we should stop and wait until the next notification resumes caching (and presumably drops some studies from the
    // cache list).
    this.isDropping = true;
    this.cacheQuotaMessage = QUOTA_MESSAGE_DROPPING;
    await this.dropStudiesFromCache();
    this.isDropping = false;
  }

  // Deliberately Re-connect to fovia using a terminate to close the previous session. This
  // seems to be the only way we can prevent memory accumulation on the server.
  protected async reconnectToFovia(): Promise<void> {
    await this.terminateFoviaConnection();
    // allow automatic reconnect
    console.info(`${this.constructor.name} reconnectToFovia waiting for reconnection`);
    await this.pulseVisionService.foviaInitCompleted();
    console.info(`${this.constructor.name} reconnectToFovia completed`);
  }

  // Handle
  // 1. initial connection to fovia
  // 2. retrying of some fovia connection failures Fova.ReturnCode.<error>
  // 3. reconnecting to fovia after disconnection notification from fovia
  // 4. reconnection at the end of caching each exam, after termination
  protected async onHandleFoviaConnected(connected: boolean | null): Promise<void> {
    try {
      // Ignore initial values
      if (connected == null) {
        return;
      }
      if (connected || this.serverApi.foviaConnected) {
        // Connection is fine, nothing to do
        console.info(`${this.constructor.name} onHandleFoviaConnected is connected count ${this.pulseVisionService.foviaConnectionCount}`);
        return;
      }
      const lastRetCode = this.serverApi.lastFoviaReturnCode;
      console.warn(` ${this.constructor.name} onHandleFoviaConnected disconnetRequested: ${this.serverApi.requestedDisconnection} lastRetCode: ${lastRetCode}`);
      // If we didn't request termination of the connection, check the results of the last connection event.

      const message = `${this.constructor.name} onHandleFoviaConnected last request failed with '${lastRetCode}' count ${this.pulseVisionService.foviaConnectionCount}/${this.pulseVisionService.foviaConnectionRequestCount}`;
      if (!this.serverApi.requestedDisconnection && this.pulseVisionService.foviaConnectionRequestCount > 0) {
        // Interrogate the fovia return code and determine whether we should retry
        // If we've never connected we won't have a return code
        // Determine whether to retry
        if (lastRetCode) {
          const retCode = Fovia.ReturnCode[lastRetCode];
          switch (lastRetCode) {
            case Fovia.ReturnCode.blocked:
            case Fovia.ReturnCode.invalidArguments:
            case Fovia.ReturnCode.invalidCallSequence:
            case Fovia.ReturnCode.longRunningTaskPending:
            case Fovia.ReturnCode.fail:
              // Try to connect again
              console.warn(`${message} retrying ....`);
              break;
            case Fovia.ReturnCode.sdkVersionMismatch: {
              // Ask FE to relaunch Application so we can move to a matching SDK.
              console.warn(`${message} SDK error, reloading ....`);
              this.controlService.notifyReloadForFoviaError();
              return;
            }
          }
        } else {
          // Our last operation failed and we didn't get an error code! Request reload.
          // Testing in 2.4/2.3 showed that some error codes are not being returned, e.g.
          // sdkVersionMismtach, so try reloading when we detect this condition.
          console.warn(`${message} Unknown Fovia error, SDK mismatch?, reloading ....`);
          this.controlService.notifyReloadForFoviaError();
          return;
        }
      } // else this is just part of normal connect/terminate operations, silently reconnect

      const wasCaching = this.isCaching;
      if (wasCaching) {
        await this.stopCaching();
      }

      // Try to connect/reconnect
      const prefix = this.pulseVisionService.foviaConnectionCount > 0 ? 're-' : '';
      if (this.pulseVisionService.foviaConnectionCount > 0) {
        console.info(`${this.constructor.name} onHandleFoviaConnected lost connection ... connecting wasCaching: ${wasCaching} sessionLost ${this.serverApi.sessionLost}`);
      }
      const connectedOK = await this.pulseVisionService.foviaInit(this.controlService.foviaUrl);
      if (connectedOK) {
        if (wasCaching || this.currentExams.length > 0) {
          this.resumeCaching();
        }
        console.info(`${this.constructor.name} onHandleFoviaConnected fovia ${prefix}connect succeeded count ${this.pulseVisionService.foviaConnectionCount}/${this.pulseVisionService.foviaConnectionRequestCount}`);
      } else {
        console.error(`${this.constructor.name} onHandleFoviaConnected fovia ${prefix}connect failed count ${this.pulseVisionService.foviaConnectionCount}/${this.pulseVisionService.foviaConnectionRequestCount}`);
      }
    }
    catch (err) {
      console.error(`${this.constructor.name} onHandleFoviaConnected exception ${JSON.stringify(err)}`);
    }
  }

  protected async onHandleNewExamGroups(examGroups: ExamGroup[]): Promise<void> {
    try {
      // update current study list from IStudyGroup info
      // a primary or comparison exam may be duplicated in the list -- that's ok,
      // the higher priority instance will be cached

      const perfTime = new PerfTiming();
      console.info(`${this.constructor.name} PulseVision-api waiting for initialization to complete..`);
      await this.waitForPulseZeroApiInitToComplete();
      console.info(`${this.constructor.name} PulseVision-api initialization complete in ${perfTime.elapsedSecondsMessage()}`);

      if (examGroups.length === 0) {
        console.info(`${this.constructor.name} currentExamList$ new exam list is empty`);
        return;
      }

      // When we have a quota error, avoid dropping and re-adding the same exam. Only continue caching
      // if quota has changed OR exam list has changed.
      if (!this.shouldContinueCaching(examGroups)) {
        console.info(`${this.constructor.name} cannot continue caching - quota error and unchanged exam group list.`);
        return;
      }

      // Reflect the user's cache quota once per update so that we can try to
      // catch any changes they may make during their session.
      this.cacheQuotaMB = this.requestedCacheQuotaMB(examGroups);
      const newOrderMap: ExamGroupMap = new ExamGroupMap(this.cacheStatusNotifier);
      newOrderMap.examGroups = examGroups;
      console.info(`${this.constructor.name} currentExamList$ new exam list with ${examGroups.length} entries`);

      await this.updateCurrentexamList(newOrderMap);
    }
    catch (err) {
      console.error(`${this.constructor.name} onHandleNewExamGroups exception ${JSON.stringify(err)}`);
    }
  }

  protected shouldContinueCaching(examGroups: ExamGroup[]): boolean {
    // No quota error at the moment
    if (!this.hasQuotaError) {
      return true;
    }
    // Quota is increasing so should try again
    if (this.cacheQuotaMB < this.requestedCacheQuotaMB(examGroups)) {
      return true;
    }
    // No Change in quota, exam groups changed?
    return this.currentExamGroupMap.examGroupListWillChange(examGroups);
  }

  protected requestedCacheQuotaMB(examGroups: ExamGroup[]): number {
    const cacheQuotaMB = examGroups[0].user.cacheQuotaGB * 1000;
    return cacheQuotaMB;
  }

  protected async onResumeCaching(): Promise<void> {
    try {
      await this.dropOldExams();
      console.info(`${this.constructor.name} onResumeCaching of ${this.currentExams.length} studies`);
      await this.pulseVisionService.resumeCaching();

      if (this.currentExams.length > 0) {
        this.cacheQuotaMessage = QUOTA_MESSAGE_NORMAL;
        await this.processExamCacheList();
        if (this.currentExams.length === 0) {
          this.cacheQuotaMessage = QUOTA_MESSAGE_DONE;
          // Only terminate our connection when we've finished caching
          await this.reconnectToFovia();
        }
      }
    }
    catch (err) {
      console.error(`${this.constructor.name} onResumeCaching exception ${JSON.stringify(err)}`);
    }
    this.isCaching = false;
  }

  // Cache one exam at a time
  protected async processExamCacheList(): Promise<void> {

    let count = 0;
    while (this.currentExams.length > 0 && this.isCaching) {
      if (!this.pulseVisionService.foviaConnected) {
        console.warn(`${this.constructor.name} processExamCacheList stopped by fovia connection failure with ${this.currentExams.length}/${this.currentExamGroupMap.examListCount()} exams remaining. `);
        break;
      }
      if (this.pulseVisionService.hasQuotaError) {
        console.warn(`${this.constructor.name} processExamCacheList stopped by quotaError with ${this.currentExams.length}/${this.currentExamGroupMap.examListCount()} exams remaining. `);
        break;
      }
      if (this.cachingPaused) {
        console.warn(`${this.constructor.name} processExamCacheList stopped by pause with ${this.currentExams.length}/${this.currentExamGroupMap.examListCount()} exams remaining. `);
        break;
      }
      // Get the top of the list to cache, we pop them off the list as we go, it's
      // ok if the list changes after we have the next item to cache.
      const examDetail = this.currentExams[0];
      // Skip exams w/o a priority
      if (examDetail == null || examDetail.priority >= NO_CACHING_PRIORITY) {
        this.currentExams.shift();
        continue;
      }
      count++;
      console.info(`${this.constructor.name} processExamCacheList caching ${count} priority ${examDetail.priority} ${examDetail.examInfo.studyUID}`);
      const result = await this.pulseVisionService.addExamToCache(examDetail);

      const index = this.currentExams.findIndex((item) => item.examInfo.studyUID === examDetail.examInfo.studyUID);
      if (result && index >= 0) {
        // Pop this one off the list, it's cached.
        this.currentExams.splice(index, 1);
        continue;
      }
      // Did the exam have a problem, we won't re-try load failures
      if (examDetail.examInfo.loadStatus === ExamLoadStatus.LOAD_FAILED && index >= 0) {
        this.currentExams.splice(index, 1);
        continue;
      }
      // report problems
      console.warn(`${this.constructor.name} processExamCacheList addExamToCache returned ${result} count ${count} ${examDetailToString(examDetail)}`);
    }
    if (this.cachingPaused || this.currentExams.length > 0) {
      console.warn(`${this.constructor.name} processExamCacheList caching stopped. Caching Enabled: ${this.isCaching}  Cached: ${count} Remaining: ${this.currentExams.length}`);
    }
  }

  protected get hasQuotaError(): boolean {
    return this.pulseVisionService.hasQuotaError;
  }

  private onViewerSessionUpdated(updateMsg: IViewerSessionUpdateMessage): void {
    console.info(`${this.constructor.name} onViewerSessionUpdated ${JSON.stringify(updateMsg)}`);

    // Apply override logger if this is an internal user
    if (updateMsg.internalUserId != null) {
      const userIdStr = updateMsg.internalUserId.toString();
      if (userIdStr === this.pulseVisionService.userId) {
        enableLoggerOverride();
      }
    } else {
      disableLoggerOverride();
    }

    if (updateMsg.primaryStudyUID === '') {
      this.currentViewerSessions.delete(updateMsg.viewerInstanceID);
      if (this.viewerInstanceWithFocus === updateMsg.viewerInstanceID) {
        this.viewerInstanceWithFocus = null;
        return;
      }
    } else {
      this.currentViewerSessions.set(updateMsg.viewerInstanceID, {
        viewerInstanceID: updateMsg.viewerInstanceID,
        primaryStudyUID: updateMsg.primaryStudyUID,
        comparisonStudyUIDs: updateMsg.comparisonStudyUIDs,
        lastUpdateMsecs: Date.now()
      });
      this.updateExamsInSessionTimes(updateMsg.primaryStudyUID, updateMsg.comparisonStudyUIDs).then();
    }
    this.cacheExamsInActiveViewerSessionsFirst().then();
  }

  private async updateExamsInSessionTimes(primaryUID: string, comparisonUIDs: string[]): Promise<void> {
    const now = Date.now();
    await this.examSessionTimesTracker.setMapItems(
      [primaryUID, ...comparisonUIDs].map(id => [id, { examUID: id, userUID: this.userId, timestamp: now }])
    );
  }

  private onViewerFocusUpdated(focusMsg: IViewerInstanceFocusMessage): void {
    console.info(`${this.constructor.name} onViewerFocusUpdated ${JSON.stringify(focusMsg)}`);
    const sessionInfo = this.currentViewerSessions.get(focusMsg.viewerInstanceID);
    if (sessionInfo) {
      sessionInfo.lastUpdateMsecs = Date.now();
    }
    if (this.viewerInstanceWithFocus === focusMsg.viewerInstanceID) {
      return;
    }
    this.viewerInstanceWithFocus = focusMsg.viewerInstanceID;
    this.cacheExamsInActiveViewerSessionsFirst().then();
  }

  private async onCacheEvictionDetected(): Promise<void> {
    this.controlService.notifyEvictionError();
  }

  private async cacheExamsInActiveViewerSessionsFirst(): Promise<void> {
    this.currentExams = this.sortExamsByActiveViewerSession(this.currentViewerSessions, this.currentExams);
  }

  private sortExamsByActiveViewerSession(viewerSessions: Map<string, IViewerInstanceInfo>, examList: IExamDetailInformation[]): IExamDetailInformation[] {
    // First sort the current viewer sessions by most recent update time.  This should correspond to the most recent user access of each viewer instance.
    // The more recent the update, the higher the priority
    const sortedSessions = Array.from(viewerSessions.values())
      .sort((a, b) => b.lastUpdateMsecs - a.lastUpdateMsecs);
    console.info(`${this.constructor.name} sortExamsByActiveViewerSession - sessions ${JSON.stringify(sortedSessions)}`);

    // Helper function to find the sorted index for the session containing a given exam.
    // Returns the first (highest priority) session that the exam is found in
    const getSortedSessionIndex = (examID: UUID | undefined): number => {
      let index = sortedSessions.findIndex(session => {
        return (session.primaryStudyUID === examID || (examID != null && session.comparisonStudyUIDs.includes(examID)));
      });
      // Give a high out-of-range number to exams that are not in a session to indicate that they have lower priority
      if (index === -1) {
        index = sortedSessions.length;
      }
      return index;
    };

    // Sort the cache queue giving priority to the exams currently in a viewer session
    const newExamList = [...examList];
    newExamList.sort((a, b): number => {
      const aSessionIndex = getSortedSessionIndex(a.examInfo.studyUID);
      const bSessionIndex = getSortedSessionIndex(b.examInfo.studyUID);

      // a and b are in different active sessions, or not in an active session
      if (aSessionIndex !== bSessionIndex || aSessionIndex === sortedSessions.length) {
        return aSessionIndex - bSessionIndex;
      }
      // a and b are in the same session.  Give priority to the Primary exam.
      const aIsPrimary = a.examInfo.studyUID === sortedSessions[aSessionIndex].primaryStudyUID;
      const bIsPrimary = b.examInfo.studyUID === sortedSessions[aSessionIndex].primaryStudyUID;
      return aIsPrimary ? -1 : bIsPrimary ? 1 : 0;  // not changing relative priority of comparison exams
    });
    this.logPriorityChanged(examList, newExamList);
    return newExamList;
  }

  private logPriorityChanged(examList: IExamDetailInformation[], sortedList: IExamDetailInformation[]): void {
    // Log when we alter the exam priority
    let samePriority = true;
    for (let i = 0; i < examList.length; i++) {
      samePriority = samePriority && examList[i].priority === sortedList[i].priority;
    }
    console.info(`${this.constructor.name} Exam list priority is ${samePriority ? 'un-' : ''}changed by ActiveViewerSession`);
    if (!samePriority) {
      console.info(`${this.constructor.name} Priority changes old v. new:`, examList, sortedList);
    }
  }

  private testListSort(): void {
    const examInfoDef: IExamGroupExamInformation = {
      studyUID: '<EXAMID>',
      examType: 'CT',
      hangingProtocol: DEFAULT_HANGING_PROTOCOL,
      dataSourceURL: '/srv/dicom/abc123'
    };
    const baseExamInfo = new ExamInformation(examInfoDef, /*isPrimary=*/true);
    const examIDs = ['exam10', 'exam9', 'exam8', 'exam7', 'exam6', 'exam5', 'exam4', 'exam3', 'exam2', 'exam1'];
    const sessionMap = new Map<string, IViewerInstanceInfo>();

    sessionMap.set('session1', { viewerInstanceID: 'viewerInst1', primaryStudyUID: 'exam1', comparisonStudyUIDs: ['exam2'], lastUpdateMsecs: 1000 });
    sessionMap.set('session2', { viewerInstanceID: 'viewerInst2', primaryStudyUID: 'exam3', comparisonStudyUIDs: ['exam4'], lastUpdateMsecs: 2000 });
    const examGroupDef: IExamGroupDefinition = {
      orderId: 1234,
      user: DEFAULT_USER,
      primary: examInfoDef,
      comparisons: []
    };
    const examGroup = new ExamGroup(/*groupId=*/'1234', /*sessionToken=*/'12345', examGroupDef);
    const examList1: IExamDetailInformation[] = examIDs.map(examID => (
      {
        examGroup: examGroup,
        examInfo: { ...baseExamInfo, studyUID: examID, loadStatus: ExamLoadStatus.NOT_LOADED },
        examCacheStatus: null,
        groupCacheStatus: null,
        priority: 1,
        cached: false
      }
    ));
    const expectedResult1 = ['exam3', 'exam4', 'exam1', 'exam2', 'exam10', 'exam9', 'exam8', 'exam7', 'exam6', 'exam5'];
    const result1 = this.sortExamsByActiveViewerSession(sessionMap, examList1).map(v => v.examInfo.studyUID);
    console.info(`${this.constructor.name} testListSort test 1 ${result1.toString() === expectedResult1.toString() ? '** PASSED **' : '-- FAILED --'}`);
  }

  // Provide the list of actively viewed exams -- to exclude them from purging activities
  private getActivelyViewedExams(): IExamDetailInformation[] {
    const activelyViewerOrders: IExamDetailInformation[] = [];
    const primaryStudyUIDs: string[] = [];
    this.currentViewerSessions.forEach((value: IViewerInstanceInfo) => primaryStudyUIDs.push(value.primaryStudyUID));
    let priority = VIEWED_PRIORITY;
    for (const uid of primaryStudyUIDs) {
      for (const exam of this.currentExams) {
        if (exam.examGroup.primaryExam.studyUID === uid) {
          exam.priority = priority;
          activelyViewerOrders.push(exam);
        }
      }
      priority++;
    }
    // Preserve the existing order
    return activelyViewerOrders;
  }

  // Returns true if caching can continue
  private async dropStudiesFromCache(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const wasCaching = this.isCaching;
      // Make sure we're operating with current stats
      await this.getStatsFromCache(SHOULD_LOG);
      const result = await this.ngZone.runOutsideAngular(async (): Promise<boolean> => {
        let canCache = !this.pulseVisionService.hasQuotaError;
        if (canCache) {
          console.warn(`${this.constructor.name} dropStudiesFromCache no longer have quota error`);
          return canCache;
        }
        await this.stopCaching();
        // Drop Studies from cache until our quota error goes away.
        // 1. Studies for a different user
        // 2. Studies that were viewed > 24hours ago
        // 3. Studies that are not in 'this' study list
        // 4. Studies that are 'lower' in the current study list
        // drop from cache and try again - be sure to avoid thrashing the current study list
        // todo: when cached images is close to our soft quota, this code
        // oscillates while trying to cache what remains in the cache list.

        let dropped = await this.dropStudiesForOtherUsers();
        if (dropped && !this.pulseVisionService.hasQuotaError) {
          if (wasCaching) {
            console.warn(`${this.constructor.name} dropStudiesFromCache dropStudiesForOtherUsers resumeCaching`);
            this.resumeCaching();
          }
          return dropped;
        }

        dropped = await this.dropStudiesNotInCurrentList();
        if (dropped && !this.pulseVisionService.hasQuotaError) {
          if (wasCaching) {
            console.warn(`${this.constructor.name} dropStudiesFromCache dropStudiesNotInCurrentList resumeCaching`);
            this.resumeCaching();
          }
          return dropped;
        }

        dropped = await this.dropInactiveStudies();
        if (dropped && !this.pulseVisionService.hasQuotaError) {
          if (wasCaching) {
            console.warn(`${this.constructor.name} dropStudiesFromCache dropInactiveStudies resumeCaching`);
            this.resumeCaching();
          }
          return dropped;
        }
        if (this.currentExams.length > 0) {
          dropped = await this.dropLowerPriorityStudies();
          if (dropped && !this.pulseVisionService.hasQuotaError) {
            // Do not resume caching from here when this happens we need to wait for
            // until we can drop something from the cache ... i.e. a new list with different study priorities.
            console.warn(`${this.constructor.name} Dropped actively cached studies, waiting for updated study list`);
            this.cacheQuotaMessage = QUOTA_MESSAGE_WAITING;
            return dropped;
          }
        }

        // Still have a quota error?
        if (this.pulseVisionService.hasQuotaError) {
          // We need to wait until study list gets updated
          this.cacheQuotaMessage = QUOTA_MESSAGE_WAITING;
          console.warn(`${this.constructor.name} No studies dropped from cache, waiting for updated study list quotaError ${this.pulseVisionService.hasQuotaError}`);
        } else {
          canCache = true;
          if (wasCaching) {
            console.warn(`${this.constructor.name} dropStudiesFromCache resumeCaching quotaError: ${this.pulseVisionService.hasQuotaError}`);
            this.resumeCaching();
          }
        }
        return canCache;
      });
      return resolve(result);
    });
  }

  private getOrderedStudyDropList(): string[] {
    return this.getDropList_StudiesForOtherUsers().concat(
      this.getDropList_StudiesNotInCurrentList(),
      this.getDropList_InactiveStudies(),
      this.getDropList_LowerPriorityStudies()
    );
  }

  private getDropList_StudiesForOtherUsers(): string[] {
      const studyUIDs: string[] = [];
      const examStats = this.examStats;
      for (const study of examStats) {
        if (study.user !== this.userId) {
          studyUIDs.push(study.studyUID);
        }
      }
    return studyUIDs;
  }

  // Compare the current user to the user who saved the studies in the
  // cache. Delete studies for a different user.
  private async dropStudiesForOtherUsers(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const studyUIDs = this.getDropList_StudiesForOtherUsers();
      const dropCount = await this.dropStudies(studyUIDs, DROP_ALL);
      console.info(`${this.constructor.name} dropStudiesForOtherUsers ${studyUIDs.length} ${dropCount} `);
      return resolve(dropCount > 0);
    });

  }

  private getDropList_StudiesNotInCurrentList(): string[] {
      const studyUIDs: string[] = [];
      const examStats = this.examStats;
      for (const exam of examStats) {
        if (this.currentExamGroupMap.has(exam.studyUID)) {
          continue;
        }
        // This exam wasn't in our list, so we can drop it
        studyUIDs.push(exam.studyUID);
      }
    return studyUIDs;
  }

  // Compare the study UIDs to the UIDs in the current cache list.
  // Delete studies that are not in our active caching list
  private async dropStudiesNotInCurrentList(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const studyUIDs = this.getDropList_StudiesNotInCurrentList();
      const dropCount = await this.dropStudies(studyUIDs);
      console.info(`${this.constructor.name} dropStudiesNotInCurrentList found ${studyUIDs.length} dropped ${dropCount} `);
      return resolve(dropCount > 0);
    });
  }

  private getDropList_InactiveStudies(): string[] {
      const studyUIDs: string[] = [];
      // Assemble a list of inactive exams that can be dropped, with the lowest priority
      // first in the list. Lower values of 'priority' field are considered 'higher priority'.
      let dropCandidates: IExamDetailInformation[] = this.currentExamGroupMap.getCacheList().toReversed();
      dropCandidates = dropCandidates.filter(entry => entry.priority >= NO_CACHING_PRIORITY);
      for (const exam of dropCandidates) {
        studyUIDs.push(exam.examInfo.studyUID);
      }
    return studyUIDs;
  }

  // Compare the study UIDs to the UIDs in the current cache list.
  // Delete studies that are not in our active caching list
  private async dropInactiveStudies(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const studyUIDs = this.getDropList_InactiveStudies();
      const dropCount = await this.dropStudies(studyUIDs);
      console.info(`${this.constructor.name} dropInactiveStudies found ${studyUIDs.length} dropped ${dropCount} `);
      return resolve(dropCount > 0);
    });
  }

  private getDropList_LowerPriorityStudies(): string[] {
      const studyUIDs: string[] = [];
      // Drop candidates list is in priority order, use reverse priority for dropping
      let dropCandidates: IExamDetailInformation[] = this.currentExamGroupMap.getCacheList().toReversed();
      const examStats = this.examStats;
      const viewedExams = this.getActivelyViewedExams();

      // Assemble a list of lower priority studies to be dropped, with the lowest priority
      // first in the list. Lower values of 'priority' field are considered 'higher priority'.
      const currentPriority = this.currentExams[0].priority;
      dropCandidates = dropCandidates.filter(entry => {
        // Exams with NO_CACHING_PRIORITY are handled by dropInactiveStudies
        if (entry.priority >= NO_CACHING_PRIORITY) {
          return false;
        }
        // Cached entry with lower priority than currently loading exam is a drop candicate
        let canDrop = (entry.examInfo.loadStatus !== ExamLoadStatus.NOT_LOADED || entry.cached) &&
          currentPriority < entry.priority;

        if (canDrop) {
          const viewedIndex = viewedExams.findIndex((exam) => exam.examInfo.studyUID === entry.examInfo.studyUID);
          // Never drop viewed exams
          canDrop = viewedIndex >= 0 ? false : canDrop;
        }
        return canDrop;
      });

      for (let i = 0; i < dropCandidates.length; i++) {
        // Select only the remaining studies from the cached studies to drop
        const index = examStats.findIndex((study) => study.studyUID === dropCandidates[i].examInfo.studyUID);
        if (index >= 0) {
          console.info(`${this.constructor.name} dropLowerPriorityStudies '${examDetailToString(dropCandidates[i])}' ${dropCandidates[i].priority} currentPriority ${currentPriority} ${i}`);
          studyUIDs.push(examStats[index].studyUID);
        }
      }
    return studyUIDs;
  }

  // Evaluate lower priority exams, inactive exams will be dropped first
  private async dropLowerPriorityStudies(): Promise<boolean> {
    return new Promise(async (resolve) => {
      const studyUIDs = this.getDropList_LowerPriorityStudies();
      const dropCount = await this.dropStudies(studyUIDs);
      if (dropCount > 0) {
        console.info(`${this.constructor.name} dropLowerPriorityStudies ${studyUIDs.length} ${dropCount} `); // lowestPriority ${dropCandidates[dropCount - 1].priority} `);
      }

      return resolve(dropCount > 0);
    });
  }

  public async makeCacheSpaceAvailable(requiredSpaceAvailableMB: number): Promise<boolean> {
    if (requiredSpaceAvailableMB <= this.cacheSpaceAvailableMB) {
      return true;
    }
    const dropCount = await this.dropStudies(this.getOrderedStudyDropList(), /*forceDropAll=*/false, requiredSpaceAvailableMB);
    console.info(`${this.constructor.name} makeCacheSpaceAvailable dropped ${dropCount} exams. requiredMB=${requiredSpaceAvailableMB}, availableMB=${this.cacheSpaceAvailableMB}`);
    return requiredSpaceAvailableMB <= this.cacheSpaceAvailableMB;
  }

  // Drop until we've hit our target or we no longer have a quota error.  Return the number of studies we dropped
  private async dropStudies(studies: string[], forceDropAll: boolean = false, targetFreeSpace?: number): Promise<number> {
    return new Promise(async (resolve) => {
      let dropCount = 0;
      if (studies.length === 0) {
        return resolve(dropCount);
      }
      console.info(`${this.constructor.name} dropStudies ${studies.length} dropall ${forceDropAll} ${studies.join(',')}`);

      for (const studyUID of studies) {
        const deleted = await this.deleteExamFromCache(studyUID);
        if (deleted) {
          dropCount++;
        }
        if (forceDropAll) {
          continue;
        }
        const success = (targetFreeSpace != null)
          ? targetFreeSpace <= this.cacheSpaceAvailableMB
          : !this.pulseVisionService.hasQuotaError;

        if (success) {
          break;
        }
      }
      return resolve(dropCount);
    });
  }

  private async dropOldExams(): Promise<void> {
    if (!LocalStorageItems.shouldPurgeOldExams) {
      return;
    }
    const hoursPerDay = 24;   // drop exams that were viewed before this long ago
    const msecsPerHour = 60 * 60 * 1000;
    const purgeCutoffTime = Date.now() - (hoursPerDay * msecsPerHour);
    const studyUIDsInCache = await this.getStudyUIDsInCache();
    const skippedStudyUIDs: string[] = [];
    const droppedStudyUIDs: string[] = [];
    // for (const studyUID of studyUIDsInCache) {   !! this 'for...of' loop statement is causing Chrome debugger to crash (works fine when not debugging)
    for (let i = 0; i < studyUIDsInCache.length; i++) {
      const studyUID = studyUIDsInCache[i];
      // don't drop the exam if it's in the current list
      if (this.currentExamGroupMap.has(studyUID)) {
        skippedStudyUIDs.push(studyUID);
        continue;
      }
      // drop the exam if was viewed before the cutoff datetime
      // or never viewed and cached before the cutoff datetime
      const lastViewedRec = await this.examSessionTimesTracker.getMapItem(studyUID);
      let needDelete = false;
      if (lastViewedRec !== null) {
        if (lastViewedRec.timestamp <= purgeCutoffTime) {
          console.log(`dropOldExams - dropping lastViewedRec for ${studyUID}`, lastViewedRec);
          needDelete = true;
        }
      } else {
        // If never viewed and cached more than a day ago, then delete.
        const examStats = this.examStats.find(value => value.studyUID === studyUID);
        if (examStats && examStats.studyCacheDate.getTime() <= purgeCutoffTime) {
          console.log(`dropOldExams - dropping purgeCutoff time${studyUID}`, purgeCutoffTime, examStats.studyCacheDate.getTime());
          needDelete = true;
        }
      }

      if (needDelete && await this.deleteExamFromCache(studyUID)) {
        droppedStudyUIDs.push(studyUID);
      }
    }

    if (droppedStudyUIDs.length > 0) {
      console.info(`${this.constructor.name} dropOldVExams - droppedExams=[${droppedStudyUIDs.join(', ')}] dropCount=${droppedStudyUIDs.length}`);
    }
    if (skippedStudyUIDs.length > 0) {
      // console.log(`dropOldExams - skipped exams`, skippedStudyUIDs);
    }

    // Housekeeping: remove entries from the session times tracker whose exams are no longer in the cache
    const allEntries = await this.examSessionTimesTracker.getAllMapItems();
    const studyUIDsNowInCache = await this.getStudyUIDsInCache();
    const removeItems = allEntries
      .filter(entry => !studyUIDsNowInCache.includes(entry.examUID))
      .map(entry => entry.examUID);
    // console.log(`dropOldExams - removing these items from session tracker`, removeItems);
    await this.examSessionTimesTracker.removeMapItems(removeItems);
  }

  private async deleteExamFromCache(studyUID: string): Promise<boolean> {
    const deleted = await this.ngZone.runOutsideAngular<Promise<boolean>>(async (): Promise<boolean> => {
      const result = await this.pulseVisionService.deleteExamFromCache(studyUID);
      if (result) {

        // Handle tracking of cache deletion for each exam
        // Studies that were already in the cache at startup are not tracked in our maps.
        if (this.currentExamGroupMap.has(studyUID)) {
          this.currentExamGroupMap.onCacheDeletion(studyUID);
        } else {
          this.cacheStatusNotifier.removeExamFromNotification(studyUID);
        }
      }
      // console.info(`${this.constructor.name} **** deleteExamFromCache completed ${studyUID} quotaError ${this.pulseVisionService.hasQuotaError}`);
      return result;
    });
    return deleted;
  }

  private sortDataTable(data: CachedExamStats[], sort: Sort): CachedExamStats[] {
    data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'ManifestSize':
          return this.compare(a.manifestKB, b.manifestKB, isAsc);
        case 'ManifestLoadTime':
          return this.compare(a.manifestCacheTimeSec, b.manifestCacheTimeSec, isAsc);
        case 'Timestamp':
          return this.compare(a.studyCacheDate.toDateString(), b.studyCacheDate.toDateString(), isAsc);
        case 'TotalImages-Frames':
          return this.compare(a.totalExamImages, b.totalExamImages, isAsc);
        case 'StudyTimeElapsed':
          return this.compare(a.studyElapsedSec, b.studyElapsedSec, isAsc);
        case 'Priority':
          return this.compare(a.priority, b.priority, isAsc);
        case 'Orders':
          return this.compare(a.orders, b.orders, isAsc);
        case 'StudyUID':
          return this.compare(a.studyUID, b.studyUID, isAsc);
        case 'User':
          return this.compare(a.user, b.user, isAsc);
        case 'MBSec':
          return this.compare(a.MBPerSec, b.MBPerSec, isAsc);
        case 'TotalMB':
          return this.compare(a.totalMB, b.totalMB, isAsc);
        case 'Status':
          return this.compare(a.studyStatus, b.studyStatus, isAsc);
        default:
          return 0;
      }
    });
    return data;
  }

  private compare(a: number | string, b: number | string, isAsc: boolean): number {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  private unsubscribe(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubscribe$$ = new Subject<void>();
  }
}
