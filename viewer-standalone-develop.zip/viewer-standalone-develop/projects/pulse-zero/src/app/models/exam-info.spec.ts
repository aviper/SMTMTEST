import { ExamInfo } from './exam-info';

describe('ExamInfo', () => {
  it('should create an instance', () => {
    expect(new ExamInfo()).toBeTruthy();
  });
});
