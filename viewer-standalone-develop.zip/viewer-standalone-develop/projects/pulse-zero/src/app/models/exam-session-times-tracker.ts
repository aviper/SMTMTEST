import { PersistentMap } from '../utilities/persistent-map';

export interface IExamLastViewedRecord {
  examUID: string;
  userUID: string;
  timestamp: number;
}

export class ExamSessionTimesTracker extends PersistentMap<IExamLastViewedRecord> {
  constructor() {
    super('ExamLastViewedTracker');
  }
}
