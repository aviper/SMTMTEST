export class ExamInfo {
  public lruDate = new Date();
  public studyDescription = '';
  public studyUID = '';
  public patientName = '';
}
export class SeriesStats {
  public numSeries = 0;
  public seriesPaths: string[] = [];
  public seriesHitCount: number[] = [];
  public seriesMissCount: number[] = [];
}
export class ImageBufferStats {
  public numImages = 0;
  public imageBufferName: string[] = [];
  public imageHitCount: number[] = [];
  public imageMissCount: number[] = [];
  public copyTime_ms: number[] = [];
}
