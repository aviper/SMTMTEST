import { AfterViewInit, Component, OnDestroy, ViewChild } from '@angular/core';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';


import { CachedExamStats } from '@pulse-zero-api';
import { ExamCacheManagementService } from '../services';

@Component({
  standalone: false,
  selector: 'app-exam-status',
  templateUrl: './exam-status.component.html',
  styleUrl: './exam-status.component.scss'
})
export class ExamStatusComponent implements OnDestroy, AfterViewInit {
  // Allow multiple selection
  protected selected: SelectionModel<CachedExamStats> = new SelectionModel<CachedExamStats>(true, []);
  private stats: MatTableDataSource<CachedExamStats> = new MatTableDataSource<CachedExamStats>();

  constructor(private examService: ExamCacheManagementService) {
    // examService keeps table updated with latest cache stat changes
    this.examService.stats = this.stats;
  }

  @ViewChild(MatSort, { static: true }) public sort: MatSort | null = null;

  public currentPage = 0;
  public get statRows(): MatTableDataSource<CachedExamStats> {
    return this.stats;
  }

  public get columnOrder(): string[] {
    return ColumnOrder;
  }

  public get selection(): SelectionModel<CachedExamStats> {
    return this.selected;
  }

  public get tableLength(): number {
    return this.examService.stats != null ? this.examService.stats.data.length : 0;
  }

  public ngOnDestroy(): void {
    this.examService.ngOnDestroy();
  }

  public ngAfterViewInit(): void {
    this.stats.sort = this.sort;
    if (this.sort != null) {
      this.sort.disableClear = true;
    }
  }

  public allSelected(): boolean {
    return this.selection.selected.length === this.stats.data.length;
  }

  public selectAllCheckboxToggle(): void {
    if (this.allSelected()) {
      this.selection.clear();
    } else {
      this.selection.select(...this.stats.data);
    }
    this.saveSelectedUIDs();
  }

  public rowCheckBoxToggle(row: CachedExamStats): void {
    this.selection.toggle(row);
    this.saveSelectedUIDs();
  }

  // Support css indication of selected rows
  public checkboxLabel(row?: CachedExamStats): string {
    if (row != null) {
      return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.studyUID}`;
    }
    return `${this.allSelected() ? 'deselect' : 'select'} all`;
  }
  public sortTable(sort: Sort): void {
    this.examService.sortTable(sort);
  }

  private saveSelectedUIDs(): void {
    const uids: string[] = [];
    this.stats.data.forEach(row => {
      if (this.selection.isSelected(row)) {
        uids.push(row.studyUID);
      }
    });
    this.examService.selectedStudies = uids;
  }
}
// Column order to show in UI
const ColumnOrder: string[] = [
  'checked',
  'StudyUID',
  'Modality',
  'Priority',
  'Orders',
  'User',
  'Timestamp',
  'Status',
  'ManifestSize',
  'ManifestLoadTime',
  'TotalImages-Frames',
  'TotalMB',
  'StudyTimeElapsed',
  'MBSec'
];
