import {
  IComputeWorker,
  IOpfsWorker,
  wrapComputeWorkerWithComLink,
  wrapOpfsWorkerWithComLink
} from "@worker-compatible-api";

// Workers have to be created within an executable module.
// Worker factory functions that live inside the executable module can be passed to services in libraries that live outside of the executable module.

export async function opfsWorkerFactory(): Promise<IOpfsWorker> {
  return wrapOpfsWorkerWithComLink(new Worker(new URL('./opfs.worker', import.meta.url)));
}

export async function computeWorkerFactory(): Promise<IComputeWorker> {
  return wrapComputeWorkerWithComLink(new Worker(new URL('./compute.worker', import.meta.url)));
}

