import * as Comlink from "comlink";
import { ComputeWorkerBase } from "@worker-compatible-api";

// The following approach keeps the worker's URL inside of the executable's module while also using shared code for the internals of the worker.
class ComputeWorker extends ComputeWorkerBase {}
Comlink.expose(ComputeWorker);
