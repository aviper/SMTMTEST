import { Component, HostListener, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';

import { PulseVisionApiService } from '@pulse-zero-api';
import { ControlService, ExamCacheManagementService } from './services';
import { LogSupport } from '@server-api';
import { PerfTiming } from '@worker-compatible-api';
import * as WorkerTimers from 'worker-timers';
import { LocalStorageItems } from '@server-api';

@Component({
  standalone: false,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnDestroy {
  protected HOST_NAME = window.origin;
  protected hostName: URL = new URL(this.HOST_NAME);
  protected perfTiming : PerfTiming = new PerfTiming;
  protected timerTestInited = false;
  readonly IS_HEADLESS: boolean = false;
  public readonly title = 'Cache Manager';

  constructor(
    protected controlService: ControlService,
    protected examCacheManagement: ExamCacheManagementService,
    protected pulseVisionApi: PulseVisionApiService) {

    this.IS_HEADLESS = new URLSearchParams(window.location.search).get('headless') === 'true' || false;
    console.log(`${this.constructor.name} Starting`);
    LogSupport.logInfo(`${this.constructor.name} Starting`);
    this.examCacheManagement.init().then(() => {
      this.controlService.init().then(() => {
        console.log(`${this.constructor.name} hasController ${this.controlService.hasController}`);
        LogSupport.logInfo(`${this.constructor.name} hasController ${this.controlService.hasController}`);
        if (this.controlService.hasController) {
          this.controlService.notifyReady();
        }
        console.info(`${this.constructor.name} app startup -> controlService ready ${this.perfTiming.elapsedSeconds}`);
      });
    });
  }

  @HostListener('window:beforeunload') async closeSession(): Promise<void> {
    if (this.controlService.commId.length) {
      const error = new Error();
      console.info(`OnBeforeUnload called ${error.stack}`);
      LogSupport.logInfo(`OnBeforeUnload called: ${error.stack}`);
      // Try to ensure session resources are released on the server before terminating
      await this.examCacheManagement.stopCaching();
      this.examCacheManagement.ngOnDestroy();
      this.controlService.terminateSession(this.controlService.commId);
    }
  }

  ngOnInit(): void {
    console.info(`${this.constructor.name} width: ${window.innerWidth} height: ${window.innerHeight}`);
    LogSupport.logInfo(`${this.constructor.name} width: ${window.innerWidth} height: ${window.innerHeight}`);
    this.initTimerTest();
  }

  ngOnDestroy(): void {
    this.controlService.ngOnDestroy();
  }

  public get connected$(): Observable<boolean | null> {
    return this.pulseVisionApi.foviaConnected$;
  }

  public isAppAlreadyRunning(): boolean {
    return this.examCacheManagement.isAppAlreadyRunning();
  }

  private initTimerTest(): void {
    if (!LocalStorageItems.backgroundTestsEnabled) {
      return;
    }
    if (this.timerTestInited) {
      return;
    }
    const delayMS: number = 500;
    let lastWorkerIntervalStart = Date.now();
    WorkerTimers.setInterval( () => {
      // console.log(`workerInterval=${Date.now() - lastWorkerIntervalStart}`);
      console.log(`workerInterval`);
      lastWorkerIntervalStart = Date.now();
    }, delayMS);

    let lastNativeIntervalStart = Date.now();
    setInterval( () => {
      console.log(`nativeInterval=${Date.now() - lastNativeIntervalStart}`);
      lastNativeIntervalStart = Date.now();
    }, delayMS);

    this.timerTestInited = true;
  }

}
