import { Component } from '@angular/core';
import { ExamCacheManagementService } from '../services';
import { PulseVisionApiService } from '@pulse-zero-api';


@Component({
  standalone: false,
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrl: './user-info.component.scss'
})
export class UserInfoComponent {
  private _currentUser = '';

  constructor(
    private examCacheManagementService: ExamCacheManagementService,
    private pulseVisionService: PulseVisionApiService) {
    this._currentUser = 'Dale';
  }
  public get currentUser(): string {
    return this.pulseVisionService.userCredentials ? this.pulseVisionService.userCredentials.userId.toString(10) : this._currentUser;
  }
}
