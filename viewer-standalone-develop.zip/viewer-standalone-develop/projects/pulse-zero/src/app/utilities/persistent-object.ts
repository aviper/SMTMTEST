import * as idbKeyVal from 'idb-keyval';
import { Mutex } from 'async-mutex';
import { LogSupport } from '@server-api';

// Base class for saving/restoring of an object from/to indexedDB browser storage.
// Derived classes need to override serialize() and deserialize() methods.
// NOTE: for a given object, there should be one and only one active instance of this class.
export class PersistentObject<T> {
    // Methods that rely on the class being initialized should 'await' on the initMutex mutex.
  // See examples in the derived PersistentMap class.
  protected initMutex = new Mutex();
  private inited = false;
  constructor(protected readonly idbKeyName: string,
              protected currentObj: T) {
    this.init().then();
  }

  public async init(): Promise<void> {
    if (!this.inited) {
      await this.initMutex.acquire();
      await this.restore();
      this.inited = true;
      this.initMutex.release();
    }
  }

  // The serialized object needs to be structuredClone()-able type (numbers, arrays, objects, dates, blobs etc)
  // https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Structured_clone_algorithm#supported_types
  protected serialize(obj: T): unknown {
    console.error('PersistentObject serialize() method must be overridden');
    LogSupport.logError('PersistentObject serialize() method must be overridden');
    return obj;
  }
  protected deserialize(serialized: unknown | undefined): T {
    console.error('PersistentObject deserialize() method must be overridden');
    LogSupport.logError('PersistentObject deserialize() method must be overridden');
    return serialized as T;
  }

  // This clears all of the storage used under 'idb-keyval.
  public static async clearAll(): Promise<void> {
    return idbKeyVal.clear()
        .catch(reason => {
          console.error(`${this.constructor.name}  idbKeyVal.clear failed`);
          LogSupport.logError(`${this.constructor.name}  idbKeyVal.clear failed`);
          console.info(`${this.constructor.name}  idbKeyVal.clear failed`, reason);
        });
  }

  public async save(): Promise<void> {
    try {
      const serialized = this.serialize(this.currentObj);
      return idbKeyVal.set(this.idbKeyName, serialized)
          .then(value => {
            console.log(`idb save`, this.currentObj, serialized);
            LogSupport.logInfo(`idb save `);
          })
          // note: this is needed to catch async errors from idb
          // currently, eviction will be detected downstream, and the app reloaded
          .catch(reason => {
            console.error(`${this.constructor.name}  idbKeyVal.set failed`);
            LogSupport.logError(`${this.constructor.name}  idbKeyVal.set failed`);
            console.info(`${this.constructor.name}  idbKeyVal.set failed`, reason, this.currentObj, serialized);
            LogSupport.logInfo(`${this.constructor.name}  idbKeyVal.set failed`);
          });
    } catch (err) {
      console.error(`${this.constructor.name}  save failed`);
      LogSupport.logError(`${this.constructor.name}  save failed`);
      console.info(`${this.constructor.name}  save failed`, err, this.currentObj);
      LogSupport.logInfo(`${this.constructor.name}  save failed`);
    }
  }

  public async restore(): Promise<void> {
    try {
      return idbKeyVal.get<[string, unknown]>(this.idbKeyName)
          .then(serialized => {
            this.currentObj = this.deserialize(serialized);
          })
          // note: this is needed to catch async errors from idb.
          // currently, eviction will be detected downstream, and the app reloaded
          .catch(reason => {
            console.error(`${this.constructor.name}  idbKeyVal.get failed`);
            LogSupport.logError(`${this.constructor.name}  idbKeyVal.get failed`);
            console.info(`${this.constructor.name}  idbKeyVal.get failed`, reason);
            LogSupport.logInfo(`${this.constructor.name}  idbKeyVal.get failed`);
          });
    } catch (err) {
      console.error(`${this.constructor.name}  restore failed`);
      console.info(`${this.constructor.name}  restore failed`, err, this.currentObj);
    }
  }
}
