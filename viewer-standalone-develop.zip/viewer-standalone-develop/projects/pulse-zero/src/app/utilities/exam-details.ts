
import {
  ExamDetailInformation,
  IExamDetailInformation
} from '@pulse-zero-api';

import {
  ExamGroup
} from '@server-api';

import {
  IExamGroupUserInformation,
} from '@idgital/vision-auth-interface';


export function getExamDetailFromExamGroup(priority: number, examGroup: ExamGroup): IExamDetailInformation[] {
  const examDetails: IExamDetailInformation[] = [];
  const primary: IExamDetailInformation = new ExamDetailInformation(
    examGroup,
    examGroup.primaryExam,
    priority);

  examDetails.push(primary);
  for (let i = 0; i < examGroup.comparisonExams.length; i++) {
    const comp: IExamDetailInformation = new ExamDetailInformation(
      examGroup,
      examGroup.comparisonExams[i],
      priority + ((i+1)/10));
    examDetails.push(comp);
  }
  return examDetails;
}

export const DEFAULT_USER: IExamGroupUserInformation = {
  userId: 5678,
  encryptionKey: new ArrayBuffer(16),
  permissions: { canEdit: true, canSave: true, canDelete: false },
  preferences: { cacheQuotaGB: 1000 },
  role: 'rad'
};

// For mocking development data only -- not to be used as part
// of any delivered encryption.
export async function generateCryptoKey(): Promise<CryptoKey> {
  return new Promise(async (resolve) => {
    return resolve(window.crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256, // can be  128, 192, or 256
      },
      true, // whether the key is extractable (i.e. can be used in exportKey)
      ['encrypt', 'decrypt'] // can "encrypt", "decrypt", "wrapKey", or "unwrapKey"
    )
    );
  });
}
