import { NgZone } from '@angular/core';
import { getAppInstanceID } from '@pulse-zero-api';
import { LogSupport } from '@server-api';
import * as WorkerTimers from 'worker-timers';

interface IAppHeartbeatRecord {
  appInstanceID: string;
  timestampMsecs: number;
  refreshIntervalMsecs: number;
}

// Help ensure that there is only one active insdtasnce of a browser app using a record written to LocalStorage
export class SingletonAppManager {
  protected static appRefreshIntervalSecs = 15;
  protected recordKey: string;
  protected appID = getAppInstanceID();
  public static readonly keyPrefix = 'appHeartbeat_';
  constructor(private appName: string, private ngZone: NgZone) {
    this.recordKey = SingletonAppManager.keyPrefix + appName;
  }

  private readAppHeartbeatRecord(): IAppHeartbeatRecord | null {
    try {
      const text = localStorage.getItem(this.recordKey);
      if (text == null) {
        return null;
      }
      const item = JSON.parse(text) as IAppHeartbeatRecord;
      // console.log(`${this.constructor.name} readAppHeartbeatRecord - read item`, item);
      return item;
    } catch (err) {
      console.error(`${this.constructor.name} readAppHeartbeatRecord - error reading localStorage data`);
      LogSupport.logError(`${this.constructor.name} readAppHeartbeatRecord - error reading localStorage data`);
      console.log(`${this.constructor.name} readAppHeartbeatRecord - error reading localStorage data`, err);
      LogSupport.logInfo(`${this.constructor.name} readAppHeartbeatRecord - error reading localStorage data`);
    }
    return null;
  }

  private writeAppHeartbeatRecord(): void {
    try {
      const rec: IAppHeartbeatRecord = {
        appInstanceID: this.appID,
        timestampMsecs: Date.now(),
        refreshIntervalMsecs: SingletonAppManager.appRefreshIntervalSecs * 1000
      };
      const json = JSON.stringify(rec);
      localStorage.setItem(this.recordKey, json);
      // console.log(`${this.constructor.name} writeAppHeartbeatRecord - set item`, rec);
    } catch (err) {
      console.error(`${this.constructor.name} writeAppHeartbeatRecord - error writing localStorage data`);
      LogSupport.logError(`${this.constructor.name} writeAppHeartbeatRecord - error writing localStorage data`);
      console.log(`${this.constructor.name} writeAppHeartbeatRecord - error writing localStorage data`, err);
      LogSupport.logInfo(`${this.constructor.name} writeAppHeartbeatRecord - error writing localStorage data`);
    }
  }

  private deleteMyAppHeartbeatRecord(): void {
    try {
      const currentRec = this.readAppHeartbeatRecord();
      if (currentRec == null || currentRec.appInstanceID !== this.appID) {
        console.log(`${this.constructor.name} deleteMyAppHeartbeatRecord - I don't have one`, currentRec);
        LogSupport.logInfo(`${this.constructor.name} deleteMyAppHeartbeatRecord - I don't have one`);
        return;
      }
      localStorage.removeItem(this.recordKey);
      console.log(`${this.constructor.name} deleteMyAppHeartbeatRecord - removed item`, currentRec);
      LogSupport.logInfo(`${this.constructor.name} deleteMyAppHeartbeatRecord - removed item`);
    } catch (err) {
      console.error(`${this.constructor.name} deleteMyAppHeartbeatRecord - error writing localStorage data`);
      LogSupport.logError(`${this.constructor.name}  deleteMyAppHeartbeatRecord - error writing localStorage data`);
      console.log(`${this.constructor.name} deleteMyAppHeartbeatRecord - error writing localStorage data`, err);
      LogSupport.logInfo(`${this.constructor.name}  deleteMyAppHeartbeatRecord - error writing localStorage data`);
    }
  }

  public async appAlreadyRunning(): Promise<boolean> {
    return new Promise<boolean>(async (resolve) => {
      let alreadyRunning = false;
      const intervalMsecs = SingletonAppManager.appRefreshIntervalSecs * 1000;  // todo: probably need a fudge factor on the interval
      const rec = this.readAppHeartbeatRecord();

      // If no heartbeat is found, or it's old, assume that no other instance of the app is running
      if (rec == null || ((Date.now() - rec.timestampMsecs) > intervalMsecs) || rec.appInstanceID === this.appID) {
        // console.log(`${this.constructor.name} appAlreadyRunning - no other instance already running (quick return)`, rec);
        return resolve(alreadyRunning);
      }
      // A new-ish heartbeat was found.  Wait for the interval and then verify that a new record was written by the active app
      console.log(`${this.constructor.name} appAlreadyRunning - new-ish heartbeat found.  waiting for a double check...`);
      LogSupport.logInfo(`${this.constructor.name} appAlreadyRunning - new-ish heartbeat found.  waiting for a double check...`);
      let timerId: any | undefined;
      await new Promise(resolve => {
        timerId = WorkerTimers.setTimeout(resolve, intervalMsecs);
      });
      WorkerTimers.clearTimeout(timerId);
      const nextRec = this.readAppHeartbeatRecord();
      alreadyRunning = (nextRec != null) && (nextRec.timestampMsecs !== rec.timestampMsecs) && (rec.appInstanceID !== this.appID);
      console.log(`${this.constructor.name} appAlreadyRunning - another instance already running = ${alreadyRunning}`, nextRec);
      LogSupport.logInfo(`${this.constructor.name} appAlreadyRunning - another instance already running = ${alreadyRunning}`);
      return resolve(alreadyRunning);
    });
  }


  public async onAppStartup(): Promise<boolean> {
    return new Promise<boolean>(async (resolve) => {
      if (await this.appAlreadyRunning()) {
        console.error(`${this.constructor.name} onAppStartup - app already running`);
        LogSupport.logError(`${this.constructor.name} onAppStartup - app already running`);
        return resolve(false);
      }
      await this.ngZone.runOutsideAngular(async (): Promise<void> => {
        this.writeAppHeartbeatRecord();

        // Write the heartbeat record periodically while the app is running
        WorkerTimers.setInterval(() => {
          const rec = this.readAppHeartbeatRecord();
          if (rec != null && rec.appInstanceID !== this.appID) {
            console.error(`${this.constructor.name} SingletonAppManager - unexpected app activity record encountered.  id=${rec.appInstanceID}`);
            LogSupport.logError(`${this.constructor.name} SingletonAppManager - unexpected app activity record encountered.  id=${rec.appInstanceID}`);
          }
          this.writeAppHeartbeatRecord();
        }, SingletonAppManager.appRefreshIntervalSecs * 1000);
      });
      return resolve(true);
    });
  }

  public onAppShutdown(): void {
    this.deleteMyAppHeartbeatRecord();
  }
}
