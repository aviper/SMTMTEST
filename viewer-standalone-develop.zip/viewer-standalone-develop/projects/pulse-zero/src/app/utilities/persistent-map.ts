import { PersistentObject } from './persistent-object';

// Manage a map of MapItems as a persistent object
export class PersistentMap<MapItem> extends PersistentObject<Map<string, MapItem>> {
  constructor(idbKeyName: string) {
    super(idbKeyName, new Map<string, MapItem>());
  }

  protected override serialize(map: Map<string, MapItem>): unknown {
    return Array.from(map.entries());
  }

  protected override deserialize(serialized: unknown): Map<string, MapItem> {
    return (serialized == null)
        ? new Map<string, MapItem>()
        : new Map<string, MapItem>(serialized as Array<[string, MapItem]>);
  }

  public async setMapItems(mapItems: Array<[string, MapItem]>): Promise<void> {
    await this.initMutex.waitForUnlock();
    for (const mapItem of mapItems) {
      const [key, item] = mapItem;
      this.currentObj.set(key, item);
    }
    return this.save();
  }

  public async getMapItem(key: string): Promise<MapItem | null> {
    await this.initMutex.waitForUnlock();
    return this.currentObj.get(key) ?? null;
  }

  public async getAllMapItems(): Promise<MapItem[]> {
    await this.initMutex.waitForUnlock();
    return Array.from(this.currentObj.values());
  }

  public async removeMapItems(examUIDs: string[]): Promise<void> {
    await this.initMutex.waitForUnlock();
    for (const id of examUIDs) {
      this.currentObj.delete(id);
    }
    return this.save();
  }

  public async removeAll(): Promise<void> {
    this.currentObj.clear();
    return this.save();
  }
}

