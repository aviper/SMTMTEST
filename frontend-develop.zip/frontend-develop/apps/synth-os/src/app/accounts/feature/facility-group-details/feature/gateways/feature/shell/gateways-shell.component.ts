import { ChangeDetectionStrategy, Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { Store } from '@ngxs/store';

import { ButtonComponent } from '@synth/ui';
import { ModalsV2Service } from '@synth/ui/modals';

import { FacilityGroupDetailsState } from '../../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { TrueTabMenuModule } from '../../../../../../../shared/ui/modules/true-tab-menu/true-tab-menu.module';
import { CreateEditGatewayDestinationModalComponent } from '../../ui/create-edit-gateway-destination-modal/create-edit-gateway-destination-modal.component';

@Component({
  selector: 'synth-gateways',
  templateUrl: './gateways-shell.component.html',
  styleUrls: ['./gateways-shell.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TrueTabMenuModule, RouterOutlet, ButtonComponent],
})
export class GatewaysShellComponent implements OnInit {
  private readonly store: Store = inject(Store);
  private readonly modalsService: ModalsV2Service = inject(ModalsV2Service);
  private readonly router: Router = inject(Router);
  private readonly route: ActivatedRoute = inject(ActivatedRoute);

  readonly TABS_MENU = [
    {
      title: 'Destinations',
      value: 'destinations',
      available: true,
      counter: null,
    },
    {
      title: 'Jobs',
      value: 'jobs',
      available: true,
      counter: null,
    },
  ];

  readonly activeTab: WritableSignal<'destinations' | 'jobs' | null> = signal<'destinations' | 'jobs' | null>(null);

  ngOnInit(): void {
    const tab = this.TABS_MENU.find((tab) =>
      this.router.isActive(this.router.createUrlTree([tab.value], { relativeTo: this.route }), {
        paths: 'exact',
        queryParams: 'ignored',
        fragment: 'ignored',
        matrixParams: 'ignored',
      })
    );
    const value: 'destinations' | 'jobs' | null = (tab?.value as 'destinations' | 'jobs') || null;

    this.activeTab.set(value);
  }

  onTabChanged(tab: 'destinations' | 'jobs'): void {
    this.activeTab.set(tab);
  }

  openCreateDestinationModal(): void {
    const facilityGroupId = this.store.selectSnapshot(FacilityGroupDetailsState.facilityGroupId);

    if (!facilityGroupId) {
      console.error('Facility Group ID is not defined');

      return;
    }

    this.modalsService.open(CreateEditGatewayDestinationModalComponent, {
      data: { facilityGroupId },
      listenBackdrop: false,
    });
  }
}
