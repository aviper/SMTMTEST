import { Component, EventEmitter, Input, Output } from '@angular/core';

import { IPagination } from '@synth/utils/feature/pagination';

import { IParser } from '../../../../../../../core/models/types/parser';

@Component({
  selector: 'app-parsers-table',
  templateUrl: './parsers-table.component.html',
  styleUrls: ['./parsers-table.component.scss'],
  standalone: false,
})
export class ParsersTableComponent {
  @Input() items: IParser[];
  @Input() isLoading: boolean;
  @Input() pagination: IPagination;
  @Input() limit: number;

  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }
}
