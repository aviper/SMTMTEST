import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../../../core/constants/endpoints';
import { FacilitiesService } from '../../../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../../../core/models/classes/userPermissions';
import { IOrderNotification } from '../../../../../../../core/models/types/notification';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityOrderNotificationActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-order-notification.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityOrderNotificationState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-order-notification.state';
import { ProfileState } from '../../../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-order-notification-shell',
  templateUrl: './facility-order-notification-shell.component.html',
  styleUrls: ['./facility-order-notification-shell.component.scss'],
  standalone: false,
})
export class FacilityOrderNotificationShellComponent implements OnInit, OnDestroy {
  readonly orderNotifications$: Observable<IOrderNotification[]> = this.store.select(
    FacilityOrderNotificationState.orderNotifications
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrderNotificationState.isLoading);
  readonly total$: Observable<number> = this.store.select(FacilityOrderNotificationState.total);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  orderNotifications: IOrderNotification[] = [];
  permissions: UserPermissions = new UserPermissions();
  facilityId: number;
  isLoading = true;
  pagination: IPagination = { ...PAGINATION };
  limit = DEFAULT_LIMIT;
  canCreateNotifications = false;
  canEditNotifications = false;
  canDeleteNotifications = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private modalsService: ModalsV2Service,
    private facilityService: FacilitiesService,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.orderNotifications$
      .pipe(
        filter((data) => !!data),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.orderNotifications = data;
      });

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
        this.getNotifications();
      });

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.permissions = permissions;
        this.canCreateNotifications = this.permissions.canCreate(ACCOUNTS_ENDPOINTS.ordersNotifications);
        this.canEditNotifications = this.permissions.canEdit(ACCOUNTS_ENDPOINTS.ordersNotifications);
        this.canDeleteNotifications = this.permissions.canDelete(ACCOUNTS_ENDPOINTS.ordersNotifications);
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading: boolean) => (this.isLoading = isLoading));

    this.total$.pipe(takeUntil(this.unsubscribe$$)).subscribe((orderNotificationTotal) => {
      this.pagination.total = orderNotificationTotal;
    });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.orderNotification }));
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.getNotifications();
  }

  getNotifications(): void {
    this.store.dispatch(
      new FacilityOrderNotificationActions.GetNotifications({
        id: this.facilityId,
        limit: this.limit,
        offset: this.pagination.offset,
      })
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new StateReset(FacilityOrderNotificationState));
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
