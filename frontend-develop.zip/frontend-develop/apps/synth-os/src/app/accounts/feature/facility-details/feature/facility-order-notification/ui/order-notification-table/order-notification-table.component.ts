import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { filter, switchMap } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../../core/constants/constants';
import { ICONS } from '../../../../../../../core/constants/icon-list';
import { FacilitiesService } from '../../../../../../../core/http-services/facilities.service';
import { IOrderNotification } from '../../../../../../../core/models/types/notification';
import { EllipsisTextModule } from '../../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { RegionsNamesPipeModule } from '../../../../../../../shared/ui/pipes/regions-names.pipe';
import { AddNotificationModalComponent } from '../../../../ui/add-notification-modal/add-notification-modal.component';

@Component({
  imports: [CommonModule, TableModule, EllipsisTextModule, RegionsNamesPipeModule],
  selector: 'app-order-notification-table',
  templateUrl: './order-notification-table.component.html',
  styleUrls: ['./order-notification-table.component.scss'],
})
export class OrderNotificationTableComponent {
  readonly ACTION_ICONS = ICONS.actionsV2;

  @Input() pagination: IPagination;
  @Input() limit = DEFAULT_LIMIT;
  @Input() isLoading = true;
  @Input() orderNotifications: IOrderNotification[] = [];
  @Input() facilityId: number;
  @Input() facilityGroupId: number;
  @Input() canEditNotifications: boolean;
  @Input() canDeleteNotifications: boolean;

  @Output() changed: EventEmitter<null> = new EventEmitter<null>();
  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();

  notificationPreview = '';

  constructor(
    private modalsService: ModalsV2Service,
    private facilityService: FacilitiesService
  ) {}

  updateNotification(notification: IOrderNotification): void {
    this.modalsService
      .open(AddNotificationModalComponent, {
        data: {
          facilityId: this.facilityId,
          groupId: this.facilityGroupId,
          notification,
        },
      })
      .subscribe((res: boolean) => res && this.changed.emit());
  }

  deleteNotification(notification: IOrderNotification): void {
    this.modalsService
      .confirm({
        title: 'Confirm delete',
        message: 'Are you sure to delete this notification?',
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        switchMap(() => this.facilityService.deleteNotification(notification.id, { autoNotifyErrors: false }))
      )
      .subscribe(
        () => {
          this.modalsService.success('Notification was deleted successfully');
          this.changed.emit();
        },
        (error) => this.modalsService.error(error.message)
      );
  }

  infinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }
}
