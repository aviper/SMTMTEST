import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityDetailsShellComponent } from './facility-details-shell.component';
import { CanLeavePageGuard } from '../../../../../core/guards/can-leave-page.guard';

const routes: Routes = [
  {
    path: '',
    component: FacilityDetailsShellComponent,
    children: [
      {
        path: '',
        redirectTo: 'departments',
        pathMatch: 'full',
      },
      {
        path: 'departments',
        loadChildren: () =>
          import('../facility-departments/feature/shell/facility-departments-shell.module').then(
            (m) => m.FacilityDepartmentsShellModule
          ),
      },
      {
        path: 'patients',
        loadChildren: () =>
          import('../facility-patients/facility-patients.module').then((m) => m.FacilityPatientsModule),
      },
      {
        path: 'radiologists',
        loadChildren: () =>
          import('../facility-radiologists/facility-radiologists.module').then((m) => m.FacilityRadiologistsModule),
      },
      {
        path: 'users',
        loadChildren: () =>
          import('../facility-users/feature/shell/facility-users-shell.module').then((m) => m.FacilityUsersShellModule),
      },
      {
        path: 'connections',
        loadChildren: () =>
          import('../facility-connections/facility-connections.module').then((m) => m.FacilityConnectionsModule),
      },
      {
        path: 'parser',
        loadChildren: () =>
          import('../facility-parser/feature/shell/facility-parser-shell.module').then(
            (m) => m.FacilityParserShellModule
          ),
      },
      {
        path: 'order-processing',
        canDeactivate: [CanLeavePageGuard],
        loadChildren: () =>
          import('../facility-order-processing/feature/shell/order-processing-shell.module').then(
            (m) => m.OrderProcessingShellModule
          ),
      },
      {
        path: 'report-header',
        loadChildren: () =>
          import('../facility-report-header/feature/shell/facility-report-header-shell.module').then(
            (m) => m.FacilityReportHeaderShellModule
          ),
      },
      {
        path: 'order-notification',
        loadChildren: () =>
          import('../facility-order-notification/feature/shell/facility-order-notification-shell.module').then(
            (m) => m.FacilityOrderNotificationShellModule
          ),
      },
      {
        path: 'directory',
        loadChildren: () =>
          import('../facility-directory/feature/shell/facility-directory-shell.module').then(
            (m) => m.FacilityDirectoryShellModule
          ),
      },
      {
        path: 'form-builder',
        loadChildren: () =>
          import('../facility-forms/feature/shell/facility-forms-shell.module').then((m) => m.FacilityFormsModule),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FacilityDetailsShellRoutingModule {}
