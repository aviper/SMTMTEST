import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';

import { ButtonComponent, IconWithAreaComponent } from '@synth/ui';

import { FacilityFormsShellRoutingModule } from './facility-forms-shell-routing.module';
import { FacilityFormsShellComponent } from './facility-forms-shell.component';
import { BasicTableActionsRefDirective } from '../../../../../../../shared/ui/components/basic-table/basic-table-actions-ref.directive';
import { BasicTableComponent } from '../../../../../../../shared/ui/components/basic-table/basic-table.component';
import { SelectComponent } from '../../../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../../../../../shared/ui/components/controls/switcher/switcher.component';
import { SynthCustomFieldsTableComponent } from '../../../../../../../shared/ui/components/custom-fields-table/custom-fields-table.component';
import { CustomFormsTableComponent } from '../../../../../../../shared/ui/components/custom-forms-table/custom-forms-table.component';
import { CustomFieldsTableModule } from '../../../../../../../shared/ui/modules/custom-fields-table/custom-fields-table.module';
import { EllipsisTextModule } from '../../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { FiltersModule } from '../../../../../../../shared/ui/modules/filters/filters.module';
import { TabMenuModule } from '../../../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { ArrayNamesPipeModule } from '../../../../../../../shared/ui/pipes/array-names.pipe';

@NgModule({
  declarations: [FacilityFormsShellComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TabMenuModule,
    TableModule,
    MatTooltipModule,
    EllipsisTextModule,
    FacilityFormsShellRoutingModule,
    CustomFieldsTableModule,
    OldSwitcherComponent,
    ArrayNamesPipeModule,
    SelectComponent,
    BasicTableComponent,
    IconWithAreaComponent,
    BasicTableActionsRefDirective,
    ButtonComponent,
    FiltersModule,
    FormsModule,
    CustomFormsTableComponent,
    SynthCustomFieldsTableComponent,
  ],
})
export class FacilityFormsModule {}
