import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterModule, Routes } from '@angular/router';

import { DepartmentsTableHeaderComponent } from './../../ui/departments-table/departments-table-header/departments-table-header.component';
import { FacilityDepartmentsShellComponent } from './facility-departments-shell.component';
import { OldInputComponent } from '../../../../../../../shared/ui/components/controls/input/input.component';
import { MaskPhoneInputComponent } from '../../../../../../../shared/ui/components/controls/mask-phone-input/mask-phone-input.component';
import { SelectComponent } from '../../../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../../../../../shared/ui/components/controls/switcher/switcher.component';
import { InlineEditBlockV2ComponentModule } from '../../../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { TableSettingsV2ComponentModule } from '../../../../../../../shared/ui/components/table-settings-v2/table-settings-v2.module';
import { ControlErrorV2DirectiveModule } from '../../../../../../../shared/ui/directives/control-error-v2.directive';
import { EllipsisTextModule } from '../../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { DepartmentReportsPipeModule } from '../../../../../../../shared/ui/pipes/department-reports.pipe';
import { PhonePipeModule } from '../../../../../../../shared/ui/pipes/phone.pipe';
import { DepartmentsTableRowComponent } from '../../ui/departments-table/departments-table-row/departments-table-row.component';
import { DepartmentsTableComponent } from '../../ui/departments-table/departments-table.component';

const routes: Routes = [
  {
    path: '',
    component: FacilityDepartmentsShellComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class FacilityDepartmentsRoutingModule {}

@NgModule({
  declarations: [
    FacilityDepartmentsShellComponent,
    DepartmentsTableComponent,
    DepartmentsTableRowComponent,
    DepartmentsTableHeaderComponent,
  ],
  imports: [
    CommonModule,
    FacilityDepartmentsRoutingModule,
    ReactiveFormsModule,
    TableModule,
    MatTooltipModule,
    ControlErrorV2DirectiveModule,
    EllipsisTextModule,
    InlineEditBlockV2ComponentModule,
    OldInputComponent,
    MaskPhoneInputComponent,
    SelectComponent,
    OldSwitcherComponent,
    PhonePipeModule,
    TableSettingsV2ComponentModule,
    DepartmentReportsPipeModule,
  ],
})
export class FacilityDepartmentsShellModule {}
