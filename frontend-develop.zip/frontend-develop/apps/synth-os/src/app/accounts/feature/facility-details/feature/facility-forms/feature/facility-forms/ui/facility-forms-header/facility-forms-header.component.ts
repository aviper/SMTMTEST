import { ChangeDetectionStrategy, Component, computed, input, InputSignal, Signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule, NgModel } from '@angular/forms';
import { Router } from '@angular/router';
import { Actions, ofActionDispatched, Store } from '@ngxs/store';
import { filter, take, takeUntil } from 'rxjs/operators';

import { ButtonComponent, SwitcherComponent } from '@synth/ui';
import { ModalsV2Service } from '@synth/ui/modals';

import { IRights, UserPermissions } from '../../../../../../../../../core/models/classes/userPermissions';
import { IFacility } from '../../../../../../../../../core/models/types/facility';
import { IFilterMapValue } from '../../../../../../../../../core/models/types/filter';
import { FacilityDetailsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityFormsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-forms.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../../../profile/data-access/state/profile/profile.state';
import { CloneFacilityFormModalComponent } from '../../../../../../../../../shared/ui/components/clone-facility-form-modal/clone-facility-form-modal.component';
import { FILTERS_STORAGE_PAGES } from '../../../../../../../../../shared/ui/modules/filters/constants/constants';
import { IFilterForApi } from '../../../../../../../../../shared/ui/modules/filters/constants/models';
import { FiltersModule } from '../../../../../../../../../shared/ui/modules/filters/filters.module';
import { FiltersApiMapperService } from '../../../../../../../../../shared/ui/modules/filters/services/filters-api-mapper';
import { FiltersInitConfig } from '../../../../../../../../../shared/ui/modules/filters/utils/model';

@Component({
  selector: 'synth-facility-forms-header',
  templateUrl: './facility-forms-header.component.html',
  styleUrls: ['./facility-forms-header.component.scss'],
  imports: [FiltersModule, ButtonComponent, FormsModule, SwitcherComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FacilityFormsHeaderComponent {
  readonly FILTERS_STORAGE_PAGES: typeof FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;

  readonly facility: Signal<IFacility> = this.store.selectSignal(FacilityDetailsState.facility);
  readonly isAnyFacilityFieldsLoading = this.store.selectSignal(FacilityDetailsState.isAnyFieldLoading);
  readonly permissions: Signal<UserPermissions> = this.store.selectSignal(ProfileState.permissions);

  readonly rights: InputSignal<IRights> = input.required<IRights>();

  readonly canCreate: Signal<boolean> = computed(() => this.rights().canCreate);
  readonly isGlobalFormsEnabled: Signal<boolean> = computed(() => this.facility()?.globalFormsEnabled ?? false);
  readonly isFacilityFormsEnabled: Signal<boolean> = computed(() => this.facility()?.formsEnabled ?? false);

  readonly filtersInitConfig: Signal<FiltersInitConfig | null> = computed(() => this.computeFiltersInitConfig());

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service,
    private readonly router: Router,
    private readonly actions: Actions
  ) {
    this.actions
      .pipe(
        ofActionDispatched(FacilityDetailsActions.PatchUpdateSuccess),
        filter((action) => this.shouldReloadFormsOnFacilityUpdate(action)),
        takeUntilDestroyed()
      )
      .subscribe(() => {
        this.store.dispatch(new FacilityFormsActions.ReloadForms());
      });
  }

  handleInitFilters(filters: IFilterMapValue): void {
    const filtersForApi = FiltersApiMapperService.getPreparedForAPIFilterMapV2(filters);

    this.store.dispatch(new FacilityFormsActions.UpdateFilters(filtersForApi));
  }

  handleFiltersChange(filters: IFilterForApi): void {
    this.store.dispatch(new FacilityFormsActions.UpdateFilters(filters));
  }

  handleFacilityPropertyChange<TKey extends keyof IFacility>(
    property: TKey,
    value: IFacility[TKey],
    model: NgModel
  ): void {
    const patchUpdateSuccess$ = this.actions.pipe(
      ofActionDispatched(FacilityDetailsActions.PatchUpdateSuccess),
      take(1)
    );

    const patchUpdateFailure$ = this.actions.pipe(
      ofActionDispatched(FacilityDetailsActions.PatchUpdateFailure),
      take(1)
    );

    patchUpdateSuccess$.pipe(takeUntil(patchUpdateFailure$)).subscribe();

    patchUpdateFailure$.pipe(takeUntil(patchUpdateSuccess$)).subscribe(() => {
      model.control.setValue(this.facility()[property], {
        emitEvent: false,
        emitModelToViewChange: true,
        emitViewToModelChange: false,
      });
    });

    this.store.dispatch(new FacilityDetailsActions.PatchUpdate({ [property]: value }));
  }

  openCreateFormPage(): void {
    const facility = this.facility();

    if (!facility) {
      return;
    }

    this.router
      .navigate(['/form-builder'], {
        queryParams: { level: 'facility', facilityId: facility.id, facilityGroupId: facility.groupId },
      })
      .then();
  }

  openCloneFacilityFormsModal(): void {
    this.modalsV2Service.createModal(CloneFacilityFormModalComponent, {
      data: {
        facilityGroupId: this.facility().groupId,
        facilityId: this.facility().id,
      },
    });
  }

  private shouldReloadFormsOnFacilityUpdate({ payload }: FacilityDetailsActions.PatchUpdateSuccess): boolean {
    return payload && ['globalFormsEnabled', 'formsEnabled'].some((prop) => prop in payload);
  }

  private computeFiltersInitConfig(): FiltersInitConfig | null {
    const permissions = this.permissions();

    if (!permissions) {
      return null;
    }

    return {
      permissions,
      customCategories: [],
    };
  }
}
