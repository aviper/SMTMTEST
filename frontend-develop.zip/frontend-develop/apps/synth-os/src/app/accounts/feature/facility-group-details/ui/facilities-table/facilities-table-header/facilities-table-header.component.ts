import { Component, Input } from '@angular/core';

import { ITableColumnWidth } from '../../../../../../core/models/types/tables';

@Component({
  selector: 'app-facilities-table-header',
  templateUrl: './facilities-table-header.component.html',
  styleUrls: ['./facilities-table-header.component.scss'],
  standalone: false,
})
export class FacilitiesTableHeaderComponent {
  @Input() columnsWidth: ITableColumnWidth = {};
  @Input() displayedColumnsMap: { [key: string]: number } = {};
}
