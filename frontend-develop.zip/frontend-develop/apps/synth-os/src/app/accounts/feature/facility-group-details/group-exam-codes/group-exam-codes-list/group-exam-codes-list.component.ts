import { AfterViewInit, Component, NgZone, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { TABLE_TYPE } from '../../../../../core/constants/table-constants';
import { TableSettingsService } from '../../../../../core/http-services/table-settings.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IListResponse, ISort } from '../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../core/models/types/dictionary';
import { ITableSetting } from '../../../../../core/models/types/tables';
import { TemplateService } from '../../../../../core/services/template.service';
import { FgCptCodesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/fg-cpt-codes.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { FgCptCodesState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/fg-cpt-codes.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { EditCptCodeComponent } from '../../../../../shared/ui/modules/cpt-codes/cpt-code-modals/edit-cpt-code/edit-cpt-code';

@Component({
  selector: 'app-group-exam-codes-list',
  templateUrl: './group-exam-codes-list.component.html',
  styleUrls: ['./group-exam-codes-list.component.scss'],
  standalone: false,
})
export class GroupExamCodesListComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly cptCodes$: Observable<ICTPCode[]> = this.store.select(FgCptCodesState.cptCodes);
  readonly isLoading$: Observable<boolean> = this.store.select(FgCptCodesState.isLoading);
  readonly sort$: Observable<ISort> = this.store.select(FgCptCodesState.sort);
  readonly query$: Observable<string> = this.store.select(FgCptCodesState.query);
  readonly pagination$: Observable<IPagination> = this.store.select(FgCptCodesState.pagination);
  readonly showExpiredExamCode$: Observable<boolean> = this.store.select(FgCptCodesState.showExpiredExamCode);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  @ViewChild('header', { static: false }) headerTemplate: TemplateRef<any>;
  @ViewChild('tabMenuRightBlock', { static: false }) tabMenuRightBlockTemplate: TemplateRef<any>;

  readonly TABLE_TYPE = TABLE_TYPE.cptCodes;

  tableSettings: ITableSetting[] = [];
  limit = DEFAULT_LIMIT;
  showExpiredExamCode = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private tableSettingsService: TableSettingsService,
    private modalsService: ModalsV2Service,
    private zone: NgZone,
    private templateService: TemplateService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.showExpiredExamCode$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((showExpiredExamCode) => (this.showExpiredExamCode = showExpiredExamCode));

    this.loadTableSettings();
  }

  ngAfterViewInit(): void {
    this.zone.onStable.pipe(take(1)).subscribe(() => {
      this.templateService.setTemplateRef(this.headerTemplate);
      this.templateService.setTabMenuRightBlockRef(this.tabMenuRightBlockTemplate);
    });
  }

  updateExpiredExamCodeStatus(status: boolean): void {
    this.store.dispatch(new FgCptCodesActions.UpdateShowExpiredExamCodeStatus(status));
  }

  sortCptCodes(sort: ISort): void {
    this.store.dispatch(new FgCptCodesActions.SortCptCodes(sort));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(new FgCptCodesActions.PaginateCodes(offset));
  }

  changeCptModality(data: { modalityId: number; cptCode: ICTPCode }): void {
    this.store.dispatch(new FgCptCodesActions.UpdateCptModality(data));
  }

  editCptCode(cptCode: ICTPCode): void {
    const groupId = this.store.selectSnapshot(FacilityGroupDetailsState.facilityGroupId);

    this.modalsService
      .open(EditCptCodeComponent, {
        listenBackdrop: false,
        data: {
          cptCode,
          groupId,
          includeGlobalRegions: true,
        },
      })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new FgCptCodesActions.Reload()));
  }

  private loadTableSettings(): void {
    this.tableSettingsService.getSettings(this.TABLE_TYPE).subscribe((res: IListResponse) => {
      this.tableSettings = res.data;
    });
  }

  ngOnDestroy(): void {
    this.templateService.setTemplateRef(null);
    this.templateService.setTabMenuRightBlockRef(null);
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
