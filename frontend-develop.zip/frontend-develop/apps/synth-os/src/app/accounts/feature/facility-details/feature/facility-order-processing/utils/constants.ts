export const RULE_RESULT_ATTRIBUTE_LABELS = {
  synthosExamCode: 'System Default Exam Code',
  priority: 'Priority',
  status: 'Status',
  readType: 'Read Type',
};

export const RULE_RESULT_ATTRIBUTE_VALUES = {
  synthosExamCode: 'synthosExamCode',
  priority: 'priority',
  status: 'status',
  readType: 'readType',
};

export const RULE_RESULT_ATTRIBUTE_OPTIONS = [
  {
    label: RULE_RESULT_ATTRIBUTE_LABELS.synthosExamCode,
    value: RULE_RESULT_ATTRIBUTE_VALUES.synthosExamCode,
  },
  {
    label: RULE_RESULT_ATTRIBUTE_LABELS.priority,
    value: RULE_RESULT_ATTRIBUTE_VALUES.priority,
  },
  {
    label: RULE_RESULT_ATTRIBUTE_LABELS.status,
    value: RULE_RESULT_ATTRIBUTE_VALUES.status,
  },
  {
    label: RULE_RESULT_ATTRIBUTE_LABELS.readType,
    value: RULE_RESULT_ATTRIBUTE_VALUES.readType,
  },
];
