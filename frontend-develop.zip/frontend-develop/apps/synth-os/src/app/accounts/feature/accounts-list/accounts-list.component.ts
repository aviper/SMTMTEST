import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, debounceTime, filter } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../core/constants/endpoints';
import { TABLE_TYPE } from '../../../core/constants/table-constants';
import { TableSettingsService } from '../../../core/http-services/table-settings.service';
import { UserPermissions } from '../../../core/models/classes/userPermissions';
import { IListResponse, ISort } from '../../../core/models/types/common';
import { IFacilityGroup } from '../../../core/models/types/facility';
import { ITableSetting } from '../../../core/models/types/tables';
import { FacilityGroupsActions } from '../../../core/store/accounts/actions/facility-group/facility-groups.actions';
import { FacilityGroupsState } from '../../../core/store/accounts/states/facility-group/facility-groups.state';
import { ProfileState } from '../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../shared/data-access/state/settings/settings.state';
import { CreateFacilityGroupComponent } from '../../ui/create-facility-group/create-facility-group.component';

@Component({
  selector: 'app-accounts-list',
  templateUrl: './accounts-list.component.html',
  styleUrls: ['./accounts-list.component.scss'],
  standalone: false,
})
export class AccountsListComponent implements OnInit, OnDestroy {
  readonly facilityGroups$: Observable<IFacilityGroup[]> = this.store.select(FacilityGroupsState.entities);
  readonly pagination$: Observable<IPagination> = this.store.select(FacilityGroupsState.pagination);
  readonly sort$: Observable<ISort> = this.store.select(FacilityGroupsState.sort);

  readonly isFacilityGroupsLoading$: Observable<boolean> = this.store.select(FacilityGroupsState.isLoading);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly TABLE_TYPE = TABLE_TYPE.accounts;

  /*
  this constant is for correct displaing of the table columns
  wile the BE part of the task is not on dev,
  when the BE part will be on the dev
  change template '[displayedColumns]="accountsDisplayedColumns"'
  to '[settings]="tableSettings"' and remove the next constant
  */

  readonly accountsDisplayedColumns = ['name', 'status', 'facilities', 'billingOwner', 'billingPhone', 'createdDate'];

  facilityGroups: IFacilityGroup[] = [];
  pagination: IPagination = { ...PAGINATION };
  limit: number;

  sorting: ISort;
  isLoading = false;
  tableSettings: ITableSetting[] = [];
  searchQuery = '';
  canCreateGroup = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private search$$: Subject<string> = new Subject();

  constructor(
    private store: Store,
    private tableSettingsService: TableSettingsService,
    private modalsV2Service: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new FacilityGroupsActions.SetLimit(this.limit));
    this.store.dispatch(new FacilityGroupsActions.GetFacilityGroups());

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (permissions: UserPermissions) => (this.canCreateGroup = permissions.canCreate(ACCOUNTS_ENDPOINTS.groups))
      );

    this.facilityGroups$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((facilityGroups) => (this.facilityGroups = facilityGroups));

    this.isFacilityGroupsLoading$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((isLoading) => (this.isLoading = isLoading));

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort) => (this.sorting = sort));

    this.search$$.pipe(debounceTime(500), takeUntil(this.unsubscribe$$)).subscribe((query: string) => {
      this.store.dispatch(new FacilityGroupsActions.UpdateSearchQuery({ key: query }));
    });
    this.loadTableSettings();
  }

  searchAccounts(query: string): void {
    this.search$$.next(query);
  }

  sortFacilityGroups(sort: ISort): void {
    this.store.dispatch(new FacilityGroupsActions.UpdateSorting(sort));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new FacilityGroupsActions.UpdatePagination({
        offset: offset,
        page: this.pagination.page + 1,
      })
    );
  }

  private loadTableSettings(): void {
    this.tableSettingsService.getSettings(this.TABLE_TYPE).subscribe((res: IListResponse) => {
      this.tableSettings = res.data;
    });
  }

  createFacilityGroup(): void {
    this.modalsV2Service.open(CreateFacilityGroupComponent).subscribe((reload: boolean) => {
      reload && this.store.dispatch(new FacilityGroupsActions.GetFacilityGroups());
    });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FacilityGroupsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
