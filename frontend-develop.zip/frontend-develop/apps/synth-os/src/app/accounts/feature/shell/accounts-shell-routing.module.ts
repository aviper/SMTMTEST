import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AccountsListComponent } from '../accounts-list/accounts-list.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: AccountsListComponent,
  },
  {
    path: 'groups/:id',
    loadChildren: () =>
      import('../facility-group-details/feature/shell/facility-group-details-shell.module').then(
        (m) => m.FacilityGroupDetailsShellModule
      ),
  },
  {
    path: 'facilities/:id',
    loadChildren: () =>
      import('../facility-details/feature/shell/facility-details-shell.module').then(
        (m) => m.FacilityDetailsShellModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AccountsShellRoutingModule {}
