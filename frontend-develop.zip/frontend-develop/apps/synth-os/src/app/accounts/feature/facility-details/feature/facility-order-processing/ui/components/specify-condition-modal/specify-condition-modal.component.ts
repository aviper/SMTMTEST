import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormBuilder, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Observable, Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import {
  ModalsV2Service,
  modalAnimation,
  CONFIRM_POPUP_RESPONSE,
  ModalOverlayRef,
  ModalClass,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../core/helpers/custom-validators';
import { IOption } from '../../../../../../../../core/models/types/common';
import {
  IOrderProcessingItemCondition,
  IOrderProcessingItemDicomCondition,
  IOrderProcessingItemHL7Condition,
  OrderProcessingConditionType,
} from '../../../../../../../../core/models/types/orders-processing';
import { OrderProcessingConditionRule } from '../../../utils/types';

@Component({
  selector: 'app-specify-condition-modal',
  templateUrl: './specify-condition-modal.component.html',
  styleUrls: ['./specify-condition-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class SpecifyConditionModalComponent extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly OrderProcessingRuleType = OrderProcessingConditionType;
  readonly OrderProcessingConditionRule = OrderProcessingConditionRule;
  readonly conditionTypeOptions: IOption[] = [
    { value: OrderProcessingConditionType.DICOM, label: 'DICOM tag' },
    { value: OrderProcessingConditionType.HL7, label: 'HL7 Field' },
  ];
  readonly conditionOptions: IOption[] = [
    { value: OrderProcessingConditionRule.CONTAINS, label: 'Contains' },
    { value: OrderProcessingConditionRule.EQUAL_TO, label: 'Equal to' },
    { value: OrderProcessingConditionRule.STARTS_WITH, label: 'Starts with' },
    { value: OrderProcessingConditionRule.DOES_NOT_CONTAIN, label: 'Does not contain' },
    { value: OrderProcessingConditionRule.DATE, label: 'Date' },
  ];
  readonly dateConditionOptions: IOption[] = [
    { value: 'more', label: 'More' },
    { value: 'fewer', label: 'Fewer' },
  ];
  readonly detailsTooltip =
    'Enter string conditions within double quotes (""). An asterisk (*) will be considered a wildcard. Separate multiple strings with || to indicate OR. Separate multiple strings with && to indicate AND.';
  readonly dateTooltip = 'Enter the number of days in the past to be used for the condition.';
  private readonly unsubscribe$$: Subject<void> = new Subject<void>();
  private readonly ALPHANUMERICAL_PATTERN = '[0-9a-zA-Z]';
  private readonly alphanumericalInputValidator = CustomValidators.patternInput(this.ALPHANUMERICAL_PATTERN);
  private readonly detailsNumericInputValidator = CustomValidators.patternInput('[0-9]');
  private readonly detailsMaxLengthValidator = Validators.maxLength(3);

  isLoading = false;
  condition: IOrderProcessingItemCondition[] = [];

  isConditionValid = false;
  isRuleActionNormalize = false;
  treeConditionsType: OrderProcessingConditionType[] = [];
  formSubscriptionMaps: Map<UntypedFormGroup, Subscription[]> = new Map();
  facilityId: number = null;

  private isConditionChanged = false;
  private _conditionForms: UntypedFormGroup[] = [];

  get conditionForms(): UntypedFormGroup[] {
    return this._conditionForms;
  }

  set conditionForms(value: UntypedFormGroup[]) {
    this._conditionForms = value;
    this.updateConditionTypeDisabledStatus();
  }

  constructor(
    public modalOverlayRef: ModalOverlayRef,
    protected _cdRef: ChangeDetectorRef,
    private modalsV2Service: ModalsV2Service,
    private fb: UntypedFormBuilder,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(_cdRef, modalOverlayRef, actionComplete$);
    this.condition = this.modalOverlayRef.data.condition;
    this.treeConditionsType = this.modalOverlayRef.data.treeConditionsType;
    this.isRuleActionNormalize = this.modalOverlayRef.data.isRuleActionNormalize;
    this.facilityId = this.modalOverlayRef.data.facilityId;
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(): void {
    if (!this.condition) {
      this.addConditionFormItem(
        this.generateForm(
          this.treeConditionsType.length ? this.treeConditionsType[0] : OrderProcessingConditionType.DICOM
        )
      );
    } else {
      this.initializeConditionsForm(this.condition);
    }
    this.updateConditionFormsValidationStatus();
  }

  closeModal(): void {
    if (this.isConditionChanged) {
      this.modalsV2Service
        .confirm({
          title: 'Wait!',
          message: 'Do you want to discard changes or keep editing?',
          cancelButton: 'Discard',
          confirmationButton: 'Keep Editing',
        })
        .subscribe((result) => {
          if (result === CONFIRM_POPUP_RESPONSE.cancel) {
            this.modalOverlayRef.close();
          }
        });
    } else {
      this.modalOverlayRef.close();
    }
  }

  specifyCondition(): void {
    const conditions = this.conditionForms.map((form) => form.getRawValue());

    this.result.emit(conditions);
    this.modalOverlayRef.close();
  }

  addConditionForm(): void {
    const firstFormRuleType = this.conditionForms[0].get('conditionType').value;

    this.addConditionFormItem(this.generateForm(firstFormRuleType));
    this.updateConditionFormsValidationStatus();
  }

  deleteConditionForm(i: number): void {
    const forms = this.conditionForms.splice(i, 1);

    this.updateConditionTypeDisabledStatus();
    this.unsubscribeFormSubscriptions(forms[0]);
    this.updateConditionFormsValidationStatus();
  }

  unsubscribeFormSubscriptions(form: UntypedFormGroup): void {
    this.formSubscriptionMaps.get(form).forEach((subscription) => {
      subscription.unsubscribe();
    });
  }

  rulesTypeChange(ruleType: OrderProcessingConditionType): void {
    this.conditionForms = [this.generateForm(ruleType)];
    this.updateConditionFormsValidationStatus();
  }

  isRadioButtonNeedToBeDisabled(index: any): boolean {
    return (
      !!index ||
      this.treeConditionsType.length > 1 ||
      (this.treeConditionsType.length === 1 && !this.condition) ||
      this.isRuleActionNormalize
    );
  }

  private generateForm(
    ruleType: OrderProcessingConditionType = OrderProcessingConditionType.DICOM,
    condition: IOrderProcessingItemCondition = null
  ): UntypedFormGroup {
    const form =
      ruleType === OrderProcessingConditionType.DICOM
        ? this.generateDICOMForm(condition as IOrderProcessingItemDicomCondition)
        : this.generateHL7Form(condition as IOrderProcessingItemHL7Condition);

    this.formSubscriptionMaps.set(form, []);

    this.addDynamicValidatorsForCustomField(form);

    const subscription = form.valueChanges.pipe(takeUntil(this.unsubscribe$$)).subscribe((values) => {
      this.updateConditionFormsValidationStatus();
      this.isConditionChanged = true;
    });

    this.addFormSubscription(form, subscription);

    return form;
  }

  private updateConditionFormsValidationStatus(): void {
    this.isConditionValid = this.isConditionFormsValid();
  }

  private addFormSubscription(form: UntypedFormGroup, subscription: Subscription): void {
    const subscriptions = this.formSubscriptionMaps.get(form);

    subscriptions.push(subscription);
  }

  private addDynamicValidatorsForCustomField(form: UntypedFormGroup): void {
    const conditionType = form.get('conditionType').value;

    if (conditionType === OrderProcessingConditionType.DICOM) {
      this.dynamicValidationHandlingForDicomCustomTag(form);
    } else if (conditionType === OrderProcessingConditionType.HL7) {
      this.dynamicValidationHandlingForHL7CustomField(form);
    }
  }

  private dynamicValidationHandlingForHL7CustomField(form: UntypedFormGroup): void {
    const subscription = form
      .get('field')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((value) => {
        if (value === 'custom') {
          form.get('segment').setValidators([CustomValidators.required, this.alphanumericalInputValidator]);
          form.get('customField').setValidators([CustomValidators.required, this.alphanumericalInputValidator]);
          form.get('name').setValidators([CustomValidators.required]);
        } else {
          form.get('segment').removeValidators([CustomValidators.required]);
          form.get('customField').removeValidators([CustomValidators.required]);
          form.get('name').removeValidators([CustomValidators.required]);
        }
        form.get('segment').updateValueAndValidity();
        form.get('customField').updateValueAndValidity();
        form.get('name').updateValueAndValidity();
      });

    const conditionSubscription = this.handleConditionDynamicValidation(form);

    subscription.add(conditionSubscription);
    this.addFormSubscription(form, subscription);
  }

  private dynamicValidationHandlingForDicomCustomTag(form: UntypedFormGroup): void {
    const customTagValidators = [CustomValidators.required, CustomValidators.exactLength(4)];

    const subscription = form
      .get('tag')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((value) => {
        if (value === 'custom') {
          form.get('customTagIdLeft').setValidators(customTagValidators);
          form.get('customTagIdRight').setValidators(customTagValidators);
          form.get('name').setValidators([CustomValidators.required]);
        } else {
          form.get('customTagIdLeft').removeValidators(customTagValidators);
          form.get('customTagIdRight').removeValidators(customTagValidators);
          form.get('name').removeValidators([CustomValidators.required]);
        }
        form.get('customTagIdLeft').updateValueAndValidity();
        form.get('customTagIdRight').updateValueAndValidity();
        form.get('name').updateValueAndValidity();
      });
    const conditionSubscription = this.handleConditionDynamicValidation(form);

    subscription.add(conditionSubscription);

    this.addFormSubscription(form, subscription);
  }

  private handleConditionDynamicValidation(form: UntypedFormGroup): Subscription {
    return form.get('condition').valueChanges.subscribe((value) => {
      const comparisonControl = form.get('comparison');
      const detailsControl = form.get('details');

      if (value === OrderProcessingConditionRule.DATE) {
        !detailsControl.hasValidator(this.detailsNumericInputValidator) &&
          detailsControl.addValidators(this.detailsNumericInputValidator);
        !detailsControl.hasValidator(this.detailsMaxLengthValidator) &&
          detailsControl.addValidators(this.detailsMaxLengthValidator);
        !comparisonControl.hasValidator(CustomValidators.required) &&
          comparisonControl.addValidators(CustomValidators.required);
      } else {
        detailsControl.hasValidator(this.detailsNumericInputValidator) &&
          detailsControl.removeValidators(this.detailsNumericInputValidator);
        detailsControl.hasValidator(this.detailsMaxLengthValidator) &&
          detailsControl.removeValidators(this.detailsMaxLengthValidator);
        comparisonControl.hasValidator(CustomValidators.required) &&
          comparisonControl.removeValidators(CustomValidators.required);
      }
      comparisonControl.updateValueAndValidity();
      detailsControl.updateValueAndValidity();
      form.updateValueAndValidity();
    });
  }

  private isConditionFormsValid(): boolean {
    return this.conditionForms.every((form) => form.valid);
  }

  private generateDICOMForm(condition: IOrderProcessingItemDicomCondition = null): UntypedFormGroup {
    return this.fb.group(
      {
        conditionType: [OrderProcessingConditionType.DICOM, [CustomValidators.required]],
        tag: [condition?.tag || null, [CustomValidators.required]],
        customTagIdLeft: [condition?.customTagIdLeft || ''],
        customTagIdRight: [condition?.customTagIdRight || ''],
        name: [condition?.name || null],
        condition: [condition?.condition || OrderProcessingConditionRule.CONTAINS, [CustomValidators.required]],
        details: [condition?.details || null, [CustomValidators.required]],
        comparison: [condition?.comparison || 'more'],
      },
      {
        validators: this.detailsValidator(),
      }
    );
  }

  private generateHL7Form(condition: IOrderProcessingItemHL7Condition = null): UntypedFormGroup {
    return this.fb.group(
      {
        conditionType: [OrderProcessingConditionType.HL7, [CustomValidators.required]],
        field: [condition?.field || null, [CustomValidators.required]],
        segment: [condition?.segment || null, [this.alphanumericalInputValidator]],
        customField: [condition?.customField || null, [this.alphanumericalInputValidator]],
        component: [condition?.component || null, [this.alphanumericalInputValidator]],
        subComponent: [condition?.subComponent || null, [this.alphanumericalInputValidator]],
        name: [condition?.name || null],
        condition: [condition?.condition || OrderProcessingConditionRule.CONTAINS, [CustomValidators.required]],
        details: [condition?.details || null, [CustomValidators.required]],
        comparison: [condition?.comparison || 'more'],
      },
      {
        validators: this.detailsValidator(),
      }
    );
  }

  private detailsValidator(): ValidatorFn {
    return (group: AbstractControl): { [key: string]: any } => {
      const detailsValue = group.get('details').value;
      const splitValues = detailsValue?.split(/\s\&\&\s|\s\|\|\s/);
      const conditionValue = group.get('condition').value;

      if (conditionValue === OrderProcessingConditionRule.DATE) {
        return null;
      }

      const regexp: RegExp = [
        OrderProcessingConditionRule.CONTAINS,
        OrderProcessingConditionRule.DOES_NOT_CONTAIN,
        OrderProcessingConditionRule.STARTS_WITH,
        OrderProcessingConditionRule.EQUAL_TO,
      ].includes(conditionValue)
        ? /^"[^&~|^"\\]*[A-Za-z0-9\s+]{1,50}[^&~|^"\\]*"$/
        : /^"[^&~|^"\\]*[A-Za-z0-9\s+]{1,50}"$/;

      const isValid = splitValues?.at(-1).length && splitValues?.every((val) => regexp.test(val));

      return isValid ? null : { details: this.detailsTooltip };
    };
  }

  private initializeConditionsForm(conditions: IOrderProcessingItemCondition[]): void {
    this.conditionForms = conditions.map((condition) => this.generateForm(condition.conditionType, condition));
  }

  private addConditionFormItem(formGroup: UntypedFormGroup): void {
    this.conditionForms.push(formGroup);
    this.updateConditionTypeDisabledStatus();
  }

  private updateConditionTypeDisabledStatus(): void {
    this.conditionForms.forEach((form, index) => {
      const conditionType = form.controls['conditionType'];

      this.isRadioButtonNeedToBeDisabled(index)
        ? conditionType.disable({ onlySelf: true })
        : conditionType.enable({ onlySelf: true });
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
