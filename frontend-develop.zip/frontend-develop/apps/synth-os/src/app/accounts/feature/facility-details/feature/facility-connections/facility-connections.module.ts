import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityConnectionsComponent } from './facility-connections.component';
import { ConnectionStatusTableModule } from '../../../../../shared/ui/components/connection-status-table/connection-status-table.component';

const routes: Routes = [
  {
    path: '',
    component: FacilityConnectionsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FacilityConnectionsRoutingModule {}

@NgModule({
  declarations: [FacilityConnectionsComponent],
  imports: [CommonModule, FacilityConnectionsRoutingModule, ConnectionStatusTableModule],
})
export class FacilityConnectionsModule {}
