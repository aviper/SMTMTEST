import { ORDERS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { TagTaskConfidentiality } from '../../../../../core/models/tags-and-tasks.model';
import { IOption } from '../../../../../core/models/types/common';

export const CONFIDENTIAL_OPTIONS: IOption[] = [
  { value: TagTaskConfidentiality.confidential, label: 'Confidential' },
  { value: TagTaskConfidentiality.open, label: 'Open' },
  { value: TagTaskConfidentiality.personal, label: 'Personal' },
  { value: TagTaskConfidentiality.secret, label: 'Secret' },
];

export const ENDPOINT_ADAPTER = {
  [TagTaskConfidentiality.confidential]: ORDERS_ENDPOINTS.confidentialTagsTasks,
  [TagTaskConfidentiality.open]: ORDERS_ENDPOINTS.openTagsTasks,
  [TagTaskConfidentiality.secret]: ORDERS_ENDPOINTS.secretTagsTasks,
  [TagTaskConfidentiality.personal]: 'personal',
};
