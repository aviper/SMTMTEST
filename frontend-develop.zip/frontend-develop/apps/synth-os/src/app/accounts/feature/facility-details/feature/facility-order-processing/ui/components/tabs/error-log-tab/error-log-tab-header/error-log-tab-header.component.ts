import { Component, Input } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter } from 'rxjs';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';

import { FacilityOrdersProcessingErrorsLogActions } from '../../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing-errors-log.actions';

@Component({
  selector: 'app-error-log-tab-header',
  templateUrl: './error-log-tab-header.component.html',
  styleUrls: ['./error-log-tab-header.component.scss'],
  standalone: false,
})
export class ErrorLogTabHeaderComponent {
  @Input() facilityId: number;

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service
  ) {}

  clearResolvedErrorsFromLog(): void {
    this.modalsV2Service
      .confirm({
        title: 'Clear resolved',
        message:
          'This will clear all resolved errors from the error log. Note that this may include errors not currently visible on your screen. This cannot be undone. Would you like to proceed? [Yes/No]',
        cancelButton: 'No',
        confirmationButton: 'Yes',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new FacilityOrdersProcessingErrorsLogActions.ClearResolvedErrorsFromLog({ facilityId: this.facilityId })
        );
      });
  }

  clearUnresolvedErrorsFromLog(): void {
    this.modalsV2Service
      .confirm({
        title: 'Clear unresolved',
        message:
          'This will clear all unresolved errors from the error log. Note that this may include errors not currently visible on your screen. This cannot be undone. Would you like to proceed? [Yes/No]',
        cancelButton: 'No',
        confirmationButton: 'Yes',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new FacilityOrdersProcessingErrorsLogActions.ClearUnresolvedErrorsFromLog({ facilityId: this.facilityId })
        );
      });
  }
}
