import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

import {
  ApiClientService,
  ApiItemResponse,
  ApiListResponse,
  GatewayDestination,
  getGatewaysDestinationsEndpoint,
  createGatewayDestinationEndpoint,
  updateGatewayDestinationEndpoint,
  updateGatewayDestinationStatusEndpoint,
} from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { GatewaysDestinationsActions } from './gateways-destinations.actions';
import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';

export interface GatewaysDestinationsStateModel {
  destinations: GatewayDestination[];
  pagination: IPagination;
  searchState: Record<string, string | string[]>;
  loading: boolean;
  limit: number;
  groupId: number | null;
  granularLoadings: Record<string, boolean>;
}

const DEFAULT_STATE: GatewaysDestinationsStateModel = {
  groupId: null,
  destinations: [],
  pagination: { ...PAGINATION },
  searchState: {},
  loading: false,
  limit: DEFAULT_LIMIT,
  granularLoadings: {},
};

@State<GatewaysDestinationsStateModel>({
  name: 'gatewaysDestinations',
  defaults: { ...DEFAULT_STATE },
})
@Injectable()
export class GatewaysDestinationsState {
  @Selector()
  static destinations(state: GatewaysDestinationsStateModel): GatewayDestination[] {
    return state.destinations;
  }

  @Selector()
  static pagination(state: GatewaysDestinationsStateModel): IPagination {
    return state.pagination;
  }

  @Selector()
  static searchState(state: GatewaysDestinationsStateModel): Record<string, string | string[]> {
    return state.searchState;
  }

  @Selector()
  static loading(state: GatewaysDestinationsStateModel): boolean {
    return state.loading;
  }

  @Selector()
  static limit(state: GatewaysDestinationsStateModel): number {
    return state.limit;
  }

  @Selector()
  static granularLoadings(state: GatewaysDestinationsStateModel): Record<string, boolean> {
    return state.granularLoadings;
  }

  constructor(
    private apiClient: ApiClientService,
    private modalService: ModalsV2Service
  ) {}

  @Action(GatewaysDestinationsActions.Init)
  init(ctx: StateContext<GatewaysDestinationsStateModel>, action: GatewaysDestinationsActions.Init): void {
    ctx.patchState({
      ...DEFAULT_STATE,
      groupId: action.payload,
    });
  }

  @Action(GatewaysDestinationsActions.Get)
  get(ctx: StateContext<GatewaysDestinationsStateModel>): Observable<ApiListResponse<GatewayDestination>> {
    const { limit, groupId, searchState, pagination } = ctx.getState();

    if (!groupId) {
      console.error('Facility Group ID is not set. Cannot fetch destinations.');

      return;
    }

    ctx.patchState({ loading: true, ...(!pagination.offset ? { destinations: [] } : {}) });

    return this.apiClient
      .exec(getGatewaysDestinationsEndpoint, {
        params: {
          facilityGroupId: groupId,
          limit,
          offset: pagination.offset,
          ...searchState,
        },
      })
      .pipe(
        tap({
          next: (response) => {
            ctx.patchState({
              destinations: pagination.offset ? ctx.getState().destinations.concat(response.data) : response.data,
              loading: false,
              pagination: {
                ...pagination,
                lastChunkSize: response.data.length,
              },
            });
          },
          error: (error) => {
            this.modalService.error(error.message);
            ctx.patchState({ loading: false });
          },
        })
      );
  }

  @Action(GatewaysDestinationsActions.Search)
  search(ctx: StateContext<GatewaysDestinationsStateModel>, action: GatewaysDestinationsActions.Search): void {
    const searchState = ctx.getState().searchState;

    ctx.patchState({
      searchState: { ...searchState, ...action.payload },
      pagination: { ...PAGINATION },
    });

    ctx.dispatch(new GatewaysDestinationsActions.Get());
  }

  @Action(GatewaysDestinationsActions.Paginate)
  paginate(ctx: StateContext<GatewaysDestinationsStateModel>, action: GatewaysDestinationsActions.Paginate): void {
    const pagination = ctx.getState().pagination;

    ctx.patchState({
      pagination: {
        ...pagination,
        offset: action.payload,
      },
    });
  }

  @Action(GatewaysDestinationsActions.CreateDestination)
  createDestination(
    ctx: StateContext<GatewaysDestinationsStateModel>,
    action: GatewaysDestinationsActions.CreateDestination
  ): Observable<ApiItemResponse<GatewayDestination>> {
    return this.apiClient.exec(createGatewayDestinationEndpoint, { body: action.payload }).pipe(
      tap({
        next: () => {
          ctx.patchState({
            pagination: { ...PAGINATION },
          });

          ctx.dispatch(new GatewaysDestinationsActions.Get());
        },
        error: (error) => {
          this.modalService.error(error.message);
        },
      })
    );
  }

  @Action(GatewaysDestinationsActions.UpdateDestination)
  updateDestination(
    ctx: StateContext<GatewaysDestinationsStateModel>,
    action: GatewaysDestinationsActions.UpdateDestination
  ): Observable<ApiItemResponse<GatewayDestination>> {
    const { original, body } = action.payload;

    ctx.patchState({
      granularLoadings: {
        ...ctx.getState().granularLoadings,
        [original.id]: true,
      },
    });

    return this.apiClient.exec(updateGatewayDestinationEndpoint, { body }).pipe(
      tap({
        next: (response) => {
          ctx.patchState({
            destinations: ctx
              .getState()
              .destinations.map((dest) => (dest.id === response.data.id ? response.data : dest)),
            granularLoadings: {
              ...ctx.getState().granularLoadings,
              [original.id]: false,
            },
          });
        },
        error: (error) => {
          this.modalService.error(error.message);
          ctx.patchState({
            granularLoadings: {
              ...ctx.getState().granularLoadings,
              [original.id]: false,
            },
          });
        },
      })
    );
  }

  @Action(GatewaysDestinationsActions.UpdateStatus)
  updateStatus(
    ctx: StateContext<GatewaysDestinationsStateModel>,
    action: GatewaysDestinationsActions.UpdateStatus
  ): Observable<ApiItemResponse<GatewayDestination>> {
    const { destination, isActive } = action.payload;

    ctx.patchState({
      granularLoadings: {
        ...ctx.getState().granularLoadings,
        [destination.id]: true,
      },
    });

    return this.apiClient
      .exec(updateGatewayDestinationStatusEndpoint, {
        body: {
          id: destination.id,
          isActive,
        },
      })
      .pipe(
        tap({
          next: (response) => {
            ctx.patchState({
              destinations: ctx
                .getState()
                .destinations.map((dest) => (dest.id === response.data.id ? response.data : dest)),
              granularLoadings: {
                ...ctx.getState().granularLoadings,
                [destination.id]: false,
              },
            });
          },
          error: (error) => {
            this.modalService.error(error.message);
            ctx.patchState({
              granularLoadings: {
                ...ctx.getState().granularLoadings,
                [destination.id]: false,
              },
            });
          },
        })
      );
  }

  @Action(GatewaysDestinationsActions.ClearData)
  clearData(ctx: StateContext<GatewaysDestinationsStateModel>): void {
    ctx.setState({ ...DEFAULT_STATE });
  }
}
