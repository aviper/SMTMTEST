import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';

import { ModalsV2Module } from '@synth/ui/modals';

import { OrderProcessingShellRoutingModule } from './order-processing-shell-routing.module';
import { OrderProcessingShellComponent } from './order-processing-shell.component';
import { OldCheckboxComponent } from '../../../../../../../shared/ui/components/controls/checkbox/checkbox/checkbox.component';
import { OldInputComponent } from '../../../../../../../shared/ui/components/controls/input/input.component';
import { OldRadioButtonComponent } from '../../../../../../../shared/ui/components/controls/radio/radio-button/radio-button.component';
import { OldRadioGroupComponent } from '../../../../../../../shared/ui/components/controls/radio/radio-group/radio-group.component';
import { SearchFieldComponent } from '../../../../../../../shared/ui/components/controls/search-field/search-field.component';
import { FacilitySelectV2Component } from '../../../../../../../shared/ui/components/controls/selects/facility-select-v2/facility-select-v2.component';
import { OrderProcessingFieldsSelectComponent } from '../../../../../../../shared/ui/components/controls/selects/order-processing-fields-select/order-processing-fields-select.component';
import { OrderProcessingTagsSelectComponent } from '../../../../../../../shared/ui/components/controls/selects/order-processing-tags-select/order-processing-tags-select.component';
import { SelectComponent } from '../../../../../../../shared/ui/components/controls/selects/select/select.component';
import { TagSelectOldComponent } from '../../../../../../../shared/ui/components/controls/selects/tag-select/tag-select-old.component';
import { OldSwitcherComponent } from '../../../../../../../shared/ui/components/controls/switcher/switcher.component';
import { OldTextAreaComponent } from '../../../../../../../shared/ui/components/controls/text-area/text-area.component';
import { OldIconComponentModule } from '../../../../../../../shared/ui/components/icon/icon.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../../../shared/ui/modules/buttons/buttons.module';
import { CollapseModule } from '../../../../../../../shared/ui/modules/collapse/collapse.component';
import { DragAndDropModule } from '../../../../../../../shared/ui/modules/drag-and-drop/drag-and-drop.module';
import { DraggableListModule } from '../../../../../../../shared/ui/modules/draggable-list/draggable-list.component';
import { EllipsisTextModule } from '../../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { LoaderModule } from '../../../../../../../shared/ui/modules/loader/loader.module';
import { TabMenuModule } from '../../../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { ConditionNamePipe } from '../../../../../../ui/pipes/condition-name.pipe';
import { ORDER_PROCESSING_UI } from '../../ui';

@NgModule({
  declarations: [...ORDER_PROCESSING_UI, OrderProcessingShellComponent],
  imports: [
    CommonModule,
    OrderProcessingShellRoutingModule,
    CdkScrollableExtendedDirectiveModule,
    DraggableListModule,
    DragDropModule,
    EllipsisTextModule,
    FormsModule,
    ReactiveFormsModule,
    CollapseModule,
    OldIconComponentModule,
    TableModule,
    MatTooltipModule,
    ButtonsModule,
    LoaderModule,
    DragAndDropModule,
    TabMenuModule,
    ReactiveFormsModule,
    ModalsV2Module,
    OldCheckboxComponent,
    SearchFieldComponent,
    OldRadioButtonComponent,
    OldRadioGroupComponent,
    OldTextAreaComponent,
    OldSwitcherComponent,
    OldInputComponent,
    SelectComponent,
    FacilitySelectV2Component,
    TagSelectOldComponent,
    ControlErrorV2DirectiveModule,
    OrderProcessingFieldsSelectComponent,
    OrderProcessingTagsSelectComponent,
    ConditionNamePipe,
  ],
})
export class OrderProcessingShellModule {}
