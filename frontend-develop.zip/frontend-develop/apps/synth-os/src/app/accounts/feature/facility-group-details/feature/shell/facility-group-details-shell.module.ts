import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideStates } from '@ngxs/store';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { ModalsV2Module } from '@synth/ui/modals';

import { FacilityGroupDetailsShellRoutingModule } from './facility-group-details-shell-routing.module';
import { FacilityGroupDetailsShellComponent } from './facility-group-details-shell.component';
import { ActionsButtonDropdownComponentModule } from '../../../../../shared/ui/components/actions-button-dropdown/actions-button-dropdown.component';
import { OldContainerBlockModule } from '../../../../../shared/ui/components/container-block/container-block.component';
import { OldCheckboxComponent } from '../../../../../shared/ui/components/controls/checkbox/checkbox/checkbox.component';
import { AppDatepickerComponent } from '../../../../../shared/ui/components/controls/datepicker/datepicker.component';
import { DayHourMinInputComponent } from '../../../../../shared/ui/components/controls/day-hour-min-input/day-hour-min-input.component';
import { DigitsInputComponent } from '../../../../../shared/ui/components/controls/digits-input/digits-input.component';
import { OldInputComponent } from '../../../../../shared/ui/components/controls/input/input.component';
import { MaskInputComponent } from '../../../../../shared/ui/components/controls/mask-input/mask-input.component';
import { MaskPhoneInputComponent } from '../../../../../shared/ui/components/controls/mask-phone-input/mask-phone-input.component';
import { OldRadioButtonComponent } from '../../../../../shared/ui/components/controls/radio/radio-button/radio-button.component';
import { SearchFieldComponent } from '../../../../../shared/ui/components/controls/search-field/search-field.component';
import { AddressSelectV2Component } from '../../../../../shared/ui/components/controls/selects/address-select-v2/address-select-v2.component';
import { SelectComponent } from '../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../../../shared/ui/components/controls/switcher/switcher.component';
import { OldTextAreaComponent } from '../../../../../shared/ui/components/controls/text-area/text-area.component';
import { DefaultFindingsTableV2Module } from '../../../../../shared/ui/components/default-findings-table-v2/default-findings-table-v2.component';
import { ExpansionBlockComponentModule } from '../../../../../shared/ui/components/expansion-block/expansion-block.component';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';
import { InlineEditBlockV2ComponentModule } from '../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { TableSettingsV2ComponentModule } from '../../../../../shared/ui/components/table-settings-v2/table-settings-v2.module';
import { WebsiteInputModule } from '../../../../../shared/ui/components/website-input/website-input.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../shared/ui/directives/control-error-v2.directive';
import { ControlErrorDirectiveModule } from '../../../../../shared/ui/directives/control-error.directive';
import { AccountUsersTableComponentModule } from '../../../../../shared/ui/modules/account-users-table/account-users-table.component';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';
import { CptCodesModule } from '../../../../../shared/ui/modules/cpt-codes/cpt-codes.module';
import { CustomFieldsTableModule } from '../../../../../shared/ui/modules/custom-fields-table/custom-fields-table.module';
import { EllipsisTextModule } from '../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { FiltersModule } from '../../../../../shared/ui/modules/filters/filters.module';
import { LoaderModule } from '../../../../../shared/ui/modules/loader/loader.module';
import { MdePopoverModule } from '../../../../../shared/ui/modules/mde-popover';
import { RadiologistsTableModule } from '../../../../../shared/ui/modules/radiologists-table/radiologists-table.module';
import { SelectCptModule } from '../../../../../shared/ui/modules/select-cpt/select-cpt.module';
import { TabMenuModule } from '../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../../../shared/ui/modules/table/table.module';
import { ArrayNamesPipeModule } from '../../../../../shared/ui/pipes/array-names.pipe';
import { AppDatePipeModule } from '../../../../../shared/ui/pipes/date.pipe';
import { PhonePipeModule } from '../../../../../shared/ui/pipes/phone.pipe';
import { GroupExamCodesListComponent } from '../../group-exam-codes/group-exam-codes-list/group-exam-codes-list.component';
import { GroupExamCodesShellComponent } from '../../group-exam-codes/shell/group-exam-codes-shell.component';
import { FACILITY_GROUP_DETAILS_UI_COMPONENTS } from '../../ui';
import { GatewaysDestinationsState } from '../gateways/data-access/gateways-destinations.state';
import { GatewaysJobsState } from '../gateways/data-access/gateways-jobs.state';
import { GroupAlgorithmsComponent } from '../group-algorithms/group-algorithms.component';
import { GroupDocumentTypesComponent } from '../group-document-types/group-document-types.component';
import { GroupFacilitiesComponent } from '../group-facilities/group-facilities.component';
import { GroupFieldsLibraryComponent } from '../group-fields-library/group-fields-library.component';
import { GroupTemplatesComponent } from '../group-templates/group-templates.component';
import { GroupUsersComponent } from '../group-users/group-users.component';

@NgModule({
  declarations: [
    ...FACILITY_GROUP_DETAILS_UI_COMPONENTS,
    GroupTemplatesComponent,
    GroupUsersComponent,
    GroupFieldsLibraryComponent,
    FacilityGroupDetailsShellComponent,
    GroupDocumentTypesComponent,
    GroupFacilitiesComponent,
    GroupAlgorithmsComponent,
    GroupExamCodesShellComponent,
    GroupExamCodesListComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FacilityGroupDetailsShellRoutingModule,
    TabMenuModule,
    RadiologistsTableModule,
    OldIconComponentModule,
    OldContainerBlockModule,
    ExpansionBlockComponentModule,
    EllipsisTextModule,
    MdePopoverModule,
    ButtonsModule,
    MatTooltipModule,
    OldCheckboxComponent,
    SearchFieldComponent,
    MaskInputComponent,
    MaskPhoneInputComponent,
    OldRadioButtonComponent,
    OldTextAreaComponent,
    OldSwitcherComponent,
    AddressSelectV2Component,
    InlineEditBlockV2ComponentModule,
    CdkScrollableExtendedDirectiveModule,
    ControlErrorV2DirectiveModule,
    LoaderModule,
    PhonePipeModule,
    TableSettingsV2ComponentModule,
    WebsiteInputModule,
    FiltersModule,
    ActionsButtonDropdownComponentModule,
    ControlErrorDirectiveModule,
    AppDatePipeModule,
    DigitsInputComponent,
    CustomFieldsTableModule,
    DefaultFindingsTableV2Module,
    AccountUsersTableComponentModule,
    ArrayNamesPipeModule,
    TableModule,
    ModalsV2Module,
    InfiniteScrollModule,
    DragDropModule,
    A11yModule,
    MatMenuModule,
    AppDatepickerComponent,
    DayHourMinInputComponent,
    OldInputComponent,
    SelectComponent,
    SelectCptModule,
    CptCodesModule,
  ],
  providers: [provideStates([GatewaysJobsState, GatewaysDestinationsState])],
})
export class FacilityGroupDetailsShellModule {}
