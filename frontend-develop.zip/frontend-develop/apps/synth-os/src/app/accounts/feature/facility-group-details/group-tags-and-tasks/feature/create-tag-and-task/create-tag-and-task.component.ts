import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MatTooltip } from '@angular/material/tooltip';
import { Actions, ofActionDispatched, Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Subject } from 'rxjs';
import { filter, finalize, takeUntil } from 'rxjs/operators';

import { IconButtonComponent, IconComponent, InputComponent } from '@synth/ui';
import { CheckboxComponent } from '@synth/ui';
import { ICONS } from '@synth/utils';

import { CustomValidators } from '../../../../../../core/helpers/custom-validators';
import { TagsAndTasksService } from '../../../../../../core/http-services/tags-and-tasks.service';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { TagTaskConfidentiality } from '../../../../../../core/models/tags-and-tasks.model';
import { IOption } from '../../../../../../core/models/types/common';
import { FormService } from '../../../../../../core/services/form.service';
import { FacilityGroupDetailsState } from '../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { SynthSelectComponent } from '../../../../../../shared/ui/components/controls/selects/synth-select/select.component';
import { ControlErrorV2DirectiveModule } from '../../../../../../shared/ui/directives/control-error-v2.directive';
import { TableModule } from '../../../../../../shared/ui/modules/table/table.module';
import { GroupTagsAndTasksActions } from '../../data-access/group-tags-and-tasks.actions';
import { GroupTagsAndTasksState } from '../../data-access/group-tags-and-tasks.state';
import { CONFIDENTIAL_OPTIONS, ENDPOINT_ADAPTER } from '../../utils/constants';

@Component({
  selector: 'synth-create-tag-and-task',
  templateUrl: './create-tag-and-task.component.html',
  styleUrls: ['./create-tag-and-task.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    TableModule,
    SynthSelectComponent,
    IconComponent,
    CheckboxComponent,
    ReactiveFormsModule,
    ControlErrorV2DirectiveModule,
    IconButtonComponent,
    InputComponent,
    MatTooltip,
  ],
})
export class CreateTagAndTaskComponent implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly permissions$ = this.store.select(ProfileState.permissions);
  readonly ENDPOINT_ADAPTER = ENDPOINT_ADAPTER;

  confOptions: IOption[] = CONFIDENTIAL_OPTIONS;
  createTagTaskForm: UntypedFormGroup;
  isNameChecking = false;

  private facilityGroupId: number;
  private readonly unsubscribe$$ = new Subject<void>();

  constructor(
    private readonly store: Store,
    private readonly tagsAndTasksService: TagsAndTasksService,
    private fb: UntypedFormBuilder,
    private actions: Actions
  ) {}

  ngOnInit(): void {
    this.facilityGroupId = this.store.selectSnapshot(FacilityGroupDetailsState.facilityGroupId);
    this.actions
      .pipe(ofActionDispatched(GroupTagsAndTasksActions.GroupTagAndTaskCreated), takeUntil(this.unsubscribe$$))
      .subscribe(() => {
        this.createTagTaskForm.reset(
          { name: null, confidentiality: null, isTask: false, active: false },
          { emitEvent: false }
        );
      });

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.confOptions = [
          ...CONFIDENTIAL_OPTIONS.filter((option: IOption) =>
            permissions.canCreate(this.ENDPOINT_ADAPTER[option.value])
          ),
          { value: TagTaskConfidentiality.personal, label: 'Personal' },
        ];
      });

    this.createForm();
  }

  addItem(): void {
    const value = FormService.trimValues(this.createTagTaskForm.getRawValue());

    this.store.dispatch(new GroupTagsAndTasksActions.CreateGroupTagAndTask(value));
  }

  private createForm(): void {
    this.createTagTaskForm = this.fb.group({
      name: [
        null,
        [CustomValidators.required],
        [
          CustomValidators.inputExistanceChecker(
            (nameControlValue) => {
              this.isNameChecking = true;

              return this.tagsAndTasksService
                .getGroupTagsAndTasks(this.facilityGroupId, { name: nameControlValue.query.trim() })
                .pipe(finalize(() => (this.isNameChecking = false)));
            },
            'name',
            'This name already exists.'
          ),
        ],
      ],
      confidentiality: [null, [CustomValidators.required]],
      isTask: [false],
      active: [false],
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new StateReset(GroupTagsAndTasksState));
  }
}
