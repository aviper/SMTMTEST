import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ALLOWED_PICTURE_TYPES_AVATAR } from '../../../../../core/constants/constants';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { FileProxyService } from '../../../../../core/services/file-proxy.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { SynthDateWrapper } from '../../../../../core/wrappers/synth-date-wrapper';

@Component({
  selector: 'app-group-picture-block',
  templateUrl: './group-picture-block.component.html',
  styleUrls: ['./group-picture-block.component.scss'],
  standalone: false,
})
export class GroupPictureBlockComponent implements OnInit, OnDestroy {
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);
  readonly isPageLoading$: Observable<boolean> = this.store.select(FacilityGroupDetailsState.isLoading);
  readonly ICONS = ICONS;

  facilityGroup: IFacilityGroup;
  isLoading = false;
  logoUrl: string;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsV2Service: ModalsV2Service,
    private fileProxy: FileProxyService
  ) {}

  ngOnInit(): void {
    this.facilityGroup$
      .pipe(
        filter((group) => !!group?.id),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((group: IFacilityGroup) => {
        this.facilityGroup = group;

        if (this.facilityGroup.logo?.id) {
          this.logoUrl = this.getLogo(this.facilityGroup.logo.id);
        } else {
          this.logoUrl = null;
        }
      });

    this.isPageLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((loading: boolean) => (this.isLoading = loading));
  }

  private getLogo(fileId: number): string {
    return this.fileProxy.getLogoByFileId(fileId) + `&timestamp=${+SynthDateWrapper.now(true)}`;
  }

  uploadGroupPicture(event: Event): void {
    const uploadedFiles = [].slice.call(event.target['files']);
    const oldLogoId = this.facilityGroup.logo?.id?.toString() || null;

    if (!uploadedFiles.length) {
      return;
    }

    if (this.isUploadedPicturesAllowed(uploadedFiles)) {
      this.store.dispatch(
        new FacilityGroupDetailsActions.UpdateGroupPicture({
          file: uploadedFiles[0],
          facilityGroupName: this.facilityGroup.name,
          oldLogoId,
        })
      );
    } else {
      this.modalsV2Service.error('Not allowed picture type');
    }
  }

  deleteGroupPicture(): void {
    this.store.dispatch(
      new FacilityGroupDetailsActions.DeleteGroupPicture({
        fileId: this.facilityGroup.logoFileId,
      })
    );
  }

  private isUploadedPicturesAllowed(uploadedPictures: File[]): boolean {
    return uploadedPictures.every((uploadedPicture: File) => {
      const pictureType = uploadedPicture.type.split('/');

      return Boolean(ALLOWED_PICTURE_TYPES_AVATAR.indexOf(pictureType[pictureType.length - 1]) !== -1);
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
