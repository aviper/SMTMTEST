import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'synth-facility-fields-shell',
  templateUrl: './facility-forms-shell.component.html',
  styleUrls: ['./facility-forms-shell.component.scss'],
  standalone: true,
  imports: [RouterOutlet],
})
export class FacilityFormsShellComponent {}
