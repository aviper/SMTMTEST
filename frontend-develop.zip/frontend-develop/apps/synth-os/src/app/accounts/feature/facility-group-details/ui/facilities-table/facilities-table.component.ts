import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';

import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { TABLE_TYPE } from '../../../../../core/constants/table-constants';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { TableSettingsService } from '../../../../../core/http-services/table-settings.service';
import { TableSetting } from '../../../../../core/models/classes/table-setting';
import { IOption, ISort } from '../../../../../core/models/types/common';
import { IFacility } from '../../../../../core/models/types/facility';
import { ITableColumnWidth, ITableSetting } from '../../../../../core/models/types/tables';
import { FacilitiesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facilities.actions';
import { FG_TABLE_COLUMNS_SETTINGS } from '../../utils/constants';

@Component({
  selector: 'app-fg-facilities-table',
  templateUrl: './facilities-table.component.html',
  styleUrls: ['./facilities-table.component.scss'],
  standalone: false,
})
export class FacilitiesTableComponent {
  @Input() set facilities(facilities: IFacility[]) {
    this.data = facilities;
  }

  @Input() set settings(settings: ITableSetting[]) {
    this.tableSettings = TableSetting.excludeColumns(settings, ['actions']);
    this.updateDisplayedColumnsMap(TableSetting.calculateVisibleColumns(this.tableSettings));
  }

  @Input() isLoading = false;
  @Input() enableResize = false;

  @Input() pagination: IPagination;
  @Input() limit = 20;
  @Input() sort: ISort;
  @Input() paginationStrategy: PaginationStrategiesNames = PaginationStrategiesNames.weak;
  @Input() contractHolderOptions: IOption[];
  @Input() canUpdateFacility: boolean;

  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() sortChanged: EventEmitter<ISort | {}> = new EventEmitter<ISort | {}>();

  readonly TABLE_COLUMNS_SETTINGS = FG_TABLE_COLUMNS_SETTINGS;
  readonly TABLE_TYPE = TABLE_TYPE.facilities;

  tableSettings: ITableSetting[] = [];
  displayedColumnsMap = {};
  columnsWidth: ITableColumnWidth = {};
  data: IFacility[] = [];

  constructor(
    private tableSettingsService: TableSettingsService,
    private router: Router,
    private facilitiesService: FacilitiesService,
    private store: Store
  ) {}

  private updateDisplayedColumnsMap(settings: ITableSetting[]): void {
    this.displayedColumnsMap = TableSetting.getDisplayedColumnsMapFromSettings(settings);
  }

  setColumnsWidth(columnsWidth: ITableColumnWidth): void {
    this.columnsWidth = { ...columnsWidth };
  }

  hideColumn(columnKey: string): void {
    const columnForHide = this.tableSettings.find((setting) => setting.key === columnKey);

    if (columnForHide) {
      columnForHide.value = false;
    }
    this.updateSettings(this.tableSettings);
  }

  updateSettings(newSettings: ITableSetting[]): void {
    this.tableSettingsService.updateSettings(this.TABLE_TYPE, { values: newSettings }).subscribe(() => {
      this.tableSettings = TableSetting.excludeColumns([...newSettings], ['actions']);
      this.updateDisplayedColumnsMap(this.tableSettings);
    });
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }

  onSort(sort: ISort): void {
    this.sort = sort.direction ? sort : {};
    this.sortChanged.emit(this.sort);
  }

  onClick(facility: IFacility): void {
    this.router.navigate(['/accounts/facilities/', facility.id]);
  }

  updateContractHolder(facility: IFacility, event: number): void {
    this.facilitiesService.patchFacility(facility.id, { contractHolderId: event }).subscribe({
      next: () => this.store.dispatch(new FacilitiesActions.GetFacilities()),
      error: () => this.store.dispatch(new FacilitiesActions.GetFacilities()),
    });
  }
}
