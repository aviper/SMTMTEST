import { Routes } from '@angular/router';

import { FacilityFieldsShellComponent } from './facility-fields-shell.component';

export const ROUTES: Routes = [
  {
    path: '',
    component: FacilityFieldsShellComponent,
    children: [
      {
        path: '',
        loadComponent: () =>
          import('../facility-fields-list/facility-fields-list.component').then((c) => c.FacilityFieldsListComponent),
      },
    ],
  },
];
