import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { asyncScheduler, BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import {
  concatMap,
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  observeOn,
  switchMap,
  takeUntil,
} from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { SHEETS_TYPES } from '../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS, MENU_PERMISSIONS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { User } from '../../../../../core/models/classes/user';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IHumanErrorBody } from '../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { TemplateService } from '../../../../../core/services/template.service';
import { AlgorithmsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/algorithms.actions';
import { FacilitiesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facilities.actions';
import { GroupFieldsLibraryActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/group-fields-library.actions';
import { TemplateActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/template.action';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { CreateFieldModalComponent } from '../../../../../shared/ui/components/create-field-modal/create-field-modal.component';
import { createFieldModalData } from '../../../../../shared/ui/components/create-field-modal/create-field-modal.types';
import { DocumentTypeFormPopupComponent } from '../../../../../shared/ui/components/document-type-form-popup/document-type-form-popup.component';
import { UploadSheetsComponent } from '../../../../../shared/ui/components/upload-sheets/upload-sheets.component';
import { FILTERS_STORAGE_PAGES } from '../../../../../shared/ui/modules/filters/constants/constants';
import { FiltersComponent } from '../../../../../shared/ui/modules/filters/filters.component';
import { CptPopupV2Component } from '../../../../../shared/ui/modules/select-cpt/components/cpt-popup-v2/cpt-popup-v2.component';
import { ConfigureDefaultTemplateModalComponent } from '../../../../ui/configure-default-template-modal/configure-default-template-modal.component';
import { CreateFacilityComponent } from '../../../../ui/create-facility/create-facility.component';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';
import { CreateAlgorithmModalComponent } from '../create-algorithm-modal/create-algorithm-modal.component';

@Component({
  selector: 'app-facility-group-header',
  templateUrl: './facility-group-header.component.html',
  styleUrls: ['./facility-group-header.component.scss'],
  standalone: false,
})
export class FacilityGroupHeaderComponent implements OnInit, OnDestroy {
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly selectedTab$: Observable<string> = this.store.select(FacilityGroupDetailsState.selectedTab);

  @ViewChild(FiltersComponent, { static: false }) filtersComp: FiltersComponent;

  readonly ICONS = ICONS;
  readonly FACILITY_GROUP_TABS = FACILITY_GROUP_TABS;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;
  readonly MENU_PERMISSIONS = MENU_PERMISSIONS;

  private readonly tabsWithFilter = [FACILITY_GROUP_TABS.groupFieldLibrary];
  private readonly tabsWithSearch = [FACILITY_GROUP_TABS.groupFieldLibrary, FACILITY_GROUP_TABS.templates];

  user: User;
  facilityGroup: IFacilityGroup;
  selectedTab = FACILITY_GROUP_TABS.facility;

  facilityGroupHeaderPermissions: IPermissionsConfig = {
    canRead: {
      [MENU_PERMISSIONS.accounts]: false,
      [ACCOUNTS_ENDPOINTS.configureDefaultTemplate]: false,
    },
    canCreate: {
      [ACCOUNTS_ENDPOINTS.algorithms]: false,
      [ACCOUNTS_ENDPOINTS.templates]: false,
      [ACCOUNTS_ENDPOINTS.groupFormFields]: false,
    },
    canEdit: {
      [ACCOUNTS_ENDPOINTS.configureDefaultTemplate]: false,
    },
  };

  filterAvailable = false;
  searchAvailable = false;
  searchPlaceholder = '';

  searchQuery$: Observable<string>;
  private readonly search$$ = new BehaviorSubject<{ [key: string]: string }>({});
  private readonly unsubscribe$$: Subject<void> = new Subject();

  get selectedTabFiltersPage(): string {
    switch (this.selectedTab) {
      case FACILITY_GROUP_TABS.groupFieldLibrary:
        return FILTERS_STORAGE_PAGES.groupFieldLibrary;
      default:
        return null;
    }
  }

  isFacilityGroupAdmin = false;

  constructor(
    private router: Router,
    private modalsService: ModalsV2Service,
    private facilitiesService: FacilitiesService,
    private store: Store,
    public templateService: TemplateService
  ) {}

  ngOnInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.facilityGroupHeaderPermissions = PermissionsClass.updatePermissions(
          permissions,
          this.facilityGroupHeaderPermissions
        );
        this.isFacilityGroupAdmin = permissions.isFacilityGroupAdmin();
      });

    this.facilityGroup$
      .pipe(
        filter((data) => data !== null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.facilityGroup = response;
      });

    this.searchQuery$ = this.search$$.pipe(
      debounceTime(500),
      map((search) => search[this.selectedTab] ?? ''),
      distinctUntilChanged()
    );

    this.search$$
      .pipe(
        debounceTime(500),
        map((search) => search[this.selectedTab] || ''),
        distinctUntilChanged(),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((query: string) => {
        switch (this.selectedTab) {
          case FACILITY_GROUP_TABS.facility: {
            this.store.dispatch(new FacilitiesActions.UpdateQuery({ query }));
            break;
          }

          case FACILITY_GROUP_TABS.groupFieldLibrary: {
            this.store.dispatch(new GroupFieldsLibraryActions.UpdateSearchQuery({ query }));
            break;
          }

          case FACILITY_GROUP_TABS.templates: {
            this.store.dispatch(new TemplateActions.UpdateSearchQuery({ query }));
            break;
          }
        }
      });

    this.selectedTab$.pipe(takeUntil(this.unsubscribe$$)).subscribe((tab) => {
      this.filterAvailable = this.tabsWithFilter.includes(tab);
      this.selectedTab = tab;

      if (this.tabsWithSearch.includes(tab)) {
        this.searchAvailable = true;
        this.searchPlaceholder = this.getSearchFieldPlaceholder(tab);
      } else {
        this.searchAvailable = false;
      }
    });

    combineLatest([this.permissions$, this.selectedTab$])
      .pipe(
        filter(([permissions]) => !!permissions && this.filterAvailable),
        observeOn(asyncScheduler),
        concatMap(([permissions]) => this.filtersComp.init(permissions)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.updateSelectedFilters(this.filtersComp.currentFilters);
      });
  }

  back(): void {
    this.router.navigate(['/accounts']);
  }

  openUploadCPTTemplateModal(): void {
    this.modalsService
      .open(UploadSheetsComponent, {
        listenBackdrop: false,
        data: {
          type: SHEETS_TYPES.groupTemplates,
          findingType: 'facilityGroup',
          groupId: this.facilityGroup.id,
        },
      })
      .subscribe(() => this.reloadDefaultTemplates());
  }

  openConfigureDefaultTemplateModal(): void {
    this.modalsService
      .open(ConfigureDefaultTemplateModalComponent, {
        listenBackdrop: false,
        data: {
          canEdit:
            this.isFacilityGroupAdmin ||
            this.facilityGroupHeaderPermissions.canEdit[ACCOUNTS_ENDPOINTS.configureDefaultTemplate],
        },
      })
      .subscribe(() => this.reloadDefaultTemplates());
  }

  search(query: string): void {
    this.search$$.next({
      ...this.search$$.value,
      [this.selectedTab]: query,
    });
  }

  openModalAddFacility(): void {
    this.modalsService
      .open(CreateFacilityComponent, {
        data: {
          facilityGroupId: this.facilityGroup.id,
        },
      })
      .subscribe(() => {
        this.store.dispatch(new FacilitiesActions.GetFacilities());
      });
  }

  createDefaultFindingsTemplate(): void {
    this.modalsService
      .open(CptPopupV2Component, {
        data: {
          isSelectionMode: true,
          excludeAttachedTemplates: true,
          groupId: this.facilityGroup.id,
          btnsName: ['Cancel'],
          canAddTemplate: true,
          fullRequest: true,
        },
      })
      .pipe(
        filter((response) => Boolean(response)),
        switchMap((selectedCptCode) =>
          this.facilitiesService.createFacilityGroupDefaultFindings(
            this.facilityGroup.id,
            {
              name: selectedCptCode.templateName,
              cptCodeIds: selectedCptCode.examCodes,
              defaultFindings: selectedCptCode.template,
              reportFields: selectedCptCode.reportFields,
              gridLines: selectedCptCode.hideTableGridLines,
            },
            { autoNotifyErrors: false }
          )
        )
      )
      .subscribe(
        () => this.reloadDefaultTemplates(),
        (error: IHumanErrorBody) => this.modalsService.error(error.message)
      );
  }

  createDocumentType(): void {
    this.modalsService.createModal(DocumentTypeFormPopupComponent, {
      data: {
        facilityGroupId: this.facilityGroup.id,
      },
    });
  }

  openCreateFieldModal(): void {
    this.modalsService.open(CreateFieldModalComponent, {
      listenBackdrop: false,
      data: createFieldModalData({
        level: 'facilityGroup',
        facilityGroupId: this.facilityGroup.id,
      }),
    });
  }

  updateSelectedFilters(selectedFilters: IFilterMapValue): void {
    switch (this.selectedTab) {
      case FACILITY_GROUP_TABS.groupFieldLibrary: {
        this.store.dispatch(new GroupFieldsLibraryActions.UpdateFilters(selectedFilters));
        break;
      }
    }
  }

  private reloadDefaultTemplates(): void {
    this.store.dispatch(new TemplateActions.GetTemplates({ id: this.facilityGroup.id }));
  }

  openModalAddAlgorithm(): void {
    this.modalsService
      .open(CreateAlgorithmModalComponent, { data: { facilityGroupId: this.facilityGroup.id } })
      .pipe(filter((reload) => !!reload))
      .subscribe(() => this.store.dispatch(new AlgorithmsActions.GetAlgorithms({ id: this.facilityGroup.id })));
  }

  getSearchFieldPlaceholder(placeholder: string): string {
    switch (placeholder) {
      case FACILITY_GROUP_TABS.groupFieldLibrary:
        return 'Search by Field Name, Display Name, Category.';
      case FACILITY_GROUP_TABS.templates:
        return 'Search by exam code, template name.';
      default:
        return `Search ${placeholder}...`;
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
