import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { ICONS } from '../../../../../core/constants/icon-list';
import { ACTION_COLUMN_WIDTH } from '../../../../../core/constants/table-constants';
import { IDocumentType } from '../../../../../core/models/types/documentType';
import { DocumentTypeActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/document-type.actions';
import { DocumentTypeFormPopupComponent } from '../../../../../shared/ui/components/document-type-form-popup/document-type-form-popup.component';

@Component({
  selector: 'app-document-type-table',
  templateUrl: './document-type-table.component.html',
  styleUrls: ['./document-type-table.component.scss'],
  standalone: false,
})
export class DocumentTypeTableComponent {
  @Input() data: IDocumentType[] = [];
  @Input() isLoading = false;
  @Input() pagination: IPagination;
  @Input() paginationStrategy: PaginationStrategiesNames = PaginationStrategiesNames.weak;
  @Input() limit: number;
  @Input() facilityGroupId: number;

  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();

  readonly ACTION_COLUMN_WIDTH = ACTION_COLUMN_WIDTH;
  readonly ICONS = ICONS;

  otherDocumentTypeDisabledTooltip = '"Other" option can\'t be changed';

  constructor(
    private modalsV2Service: ModalsV2Service,
    private store: Store
  ) {}

  editDocumentType(item: DocumentType): void {
    this.modalsV2Service.open(DocumentTypeFormPopupComponent, {
      data: {
        documentType: item,
        facilityGroupId: this.facilityGroupId,
      },
    });
  }

  deleteDocumentType(item: DocumentType): void {
    this.modalsV2Service
      .confirm({
        title: `Are you sure you want to delete “${item.name}” document type?`,
        message: '',
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(filter((response: string) => response === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe((_) => {
        this.store
          .dispatch(
            new DocumentTypeActions.DeleteDocumentTypes({ facilityGroupId: this.facilityGroupId, documentType: item })
          )
          .subscribe(() => this.modalsV2Service.success('Document type was deleted successfully'));
      });
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }
}
