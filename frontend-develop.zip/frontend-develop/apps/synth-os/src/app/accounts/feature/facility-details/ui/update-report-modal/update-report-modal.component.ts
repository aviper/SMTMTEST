import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Store } from '@ngxs/store';
import { finalize, Observable, Subject, takeUntil } from 'rxjs';

import { ModalClass, modalAnimation, ModalOverlayRef, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { IFacilityDepartment } from '../../../../../core/models/types/facility';
import { FacilityDepartmentsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/departments.actions';

@Component({
  selector: 'app-update-report-modal',
  templateUrl: './update-report-modal.component.html',
  styleUrls: ['./update-report-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class UpdateReportModalComponent extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly DEPARTMENT_RESPONCES = {
    email: 'email',
    fax: 'fax',
    oru: 'oru',
    ftp: 'ftp',
  };

  department: IFacilityDepartment;
  reportsForm: UntypedFormGroup;
  responseValuesForm: UntypedFormGroup;
  isLoading = false;
  responcessMap: { [key: string]: boolean } = {};
  isCheckedFtp: boolean;
  canShowFtp = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected cdRef: ChangeDetectorRef,
    public overlayRef: ModalOverlayRef,
    private fb: UntypedFormBuilder,
    private store: Store,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, overlayRef, actionComplete$);
    this.department = this.overlayRef.data.department;
  }

  ngOnInit(): void {
    this.department.departmentsResponses.map((item) => {
      this.responcessMap[item.key] = item.value;
    });

    this.isCheckedFtp = this.responcessMap[this.DEPARTMENT_RESPONCES.ftp];
    this.createReportsForm();
  }

  addFtpServer(isCheckedFtp: boolean): void {
    this.isCheckedFtp = isCheckedFtp;
    this.canShowFtp = isCheckedFtp;
  }

  private createReportsForm(): void {
    this.reportsForm = this.fb.group({
      responseValues: this.fb.group({
        email: [this.responcessMap[this.DEPARTMENT_RESPONCES.email], [CustomValidators.email]],
        fax: this.responcessMap[this.DEPARTMENT_RESPONCES.fax],
        oru: this.responcessMap[this.DEPARTMENT_RESPONCES.oru],
        ftp: this.responcessMap[this.DEPARTMENT_RESPONCES.ftp],
      }),
      ftpServer: null,
    });

    this.responseValuesForm = this.reportsForm.get('responseValues') as UntypedFormGroup;
  }

  configureFtpServer(): void {
    this.canShowFtp = !this.canShowFtp;
  }

  updateDepartment(): void {
    if (this.reportsForm.pristine) {
      this.closeModal();

      return;
    }

    this.isLoading = true;
    const body = {
      ...JSON.parse(JSON.stringify(this.department)),
      ftpServers: this.reportsForm.get('ftpServer').dirty
        ? [this.reportsForm.get('ftpServer').value]
        : this.department.ftpServers,
    };

    const newValues = this.reportsForm.value.responseValues;

    for (const key in newValues) {
      const responseOption = body.departmentsResponses.find((res) => res.key === key);

      responseOption && (responseOption.value = newValues[key]);
    }

    body.fax = this.department.fdFax || null;
    body.phone = this.department.fdPhone || null;

    if (
      this.overlayRef.data.enableAutoDelivery &&
      body.departmentsResponses.some((departmentsResponse) => departmentsResponse.value)
    ) {
      body.autoDelivery = true;
    }

    this.store
      .dispatch(
        new FacilityDepartmentsActions.UpdateFacilityDepartment({
          id: this.department.id,
          department: body,
        })
      )
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.closeModal());
  }

  closeModal(): void {
    this.overlayRef.close();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
