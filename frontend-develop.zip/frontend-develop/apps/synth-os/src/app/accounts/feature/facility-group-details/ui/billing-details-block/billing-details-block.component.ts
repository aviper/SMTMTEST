import { Component, Input } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { FacilityGroupsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { finalize } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupEditableBlockClass } from '../../../../utils/editable-block.class';

@Component({
  selector: 'app-billing-details-block',
  templateUrl: './billing-details-block.component.html',
  styleUrls: ['./billing-details-block.component.scss'],
  standalone: false,
})
export class BillingDetailsBlockComponent extends FacilityGroupEditableBlockClass {
  isLoadingBlock = false;
  @Input() canEdit = false;

  constructor(
    protected fb: UntypedFormBuilder,
    protected store: Store,
    protected modalsService: ModalsV2Service
  ) {
    super(fb, store, modalsService);
  }

  protected createForm(): void {
    this.form = this.fb.group({
      accounterName: [
        null,
        [
          CustomValidators.patternInput(FacilityGroupsPatterns.accounterName.pattern),
          Validators.maxLength(FacilityGroupsPatterns.accounterName.maxLength),
        ],
      ],
      email: [null, [CustomValidators.required, CustomValidators.email]],
      facilityGroupPhone: [null, [CustomValidators.invalidPhoneNumber]],
    });
  }

  submit(fieldName: string): void {
    const fieldToUpdate = this.form.get(fieldName);

    if (fieldToUpdate.valid) {
      this.isLoadingBlock = true;
      this.store
        .dispatch(
          new FacilityGroupDetailsActions.Update({
            id: this.facilityGroup.id,
            body: { [fieldName]: fieldToUpdate.value },
          })
        )
        .pipe(finalize(() => (this.isLoadingBlock = false)))
        .subscribe(
          () => {},
          () => this.updateForm(this.facilityGroup) // reset form to initial state after not successful update
        );
    } else {
      this.updateForm(this.facilityGroup);
    }
  }

  protected updateForm(facilityGroup: IFacilityGroup): void {
    this.form.patchValue({
      accounterName: facilityGroup.accounterName,
      phone: facilityGroup.facilityGroupPhone,
      email: facilityGroup.email,
    });
  }
}
