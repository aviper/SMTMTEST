import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { FacilitiesPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';

import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { IFacility } from '../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityEditableBlockClass } from '../../../../utils/facility-editable-block.class';

@Component({
  selector: 'app-facility-notes-block',
  templateUrl: './facility-notes-block.component.html',
  styleUrls: ['./facility-notes-block.component.scss'],
  standalone: false,
})
export class FacilityNotesBlockComponent extends FacilityEditableBlockClass implements OnInit {
  readonly ICONS = ICONS.actionsV2;
  isEditing = false;

  @Input() canEdit = false;

  constructor(
    protected fb: UntypedFormBuilder,
    protected store: Store
  ) {
    super();
  }

  ngOnInit(): void {
    super.ngOnInit();
  }

  protected createForm(): void {
    this.form = this.fb.group({
      note: [
        null,
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilitiesPatterns.note.pattern),
          Validators.maxLength(FacilitiesPatterns.note.maxLength),
        ],
      ],
    });
  }

  submit(): void {
    if (this.form.dirty && this.form.valid) {
      this.store.dispatch(new FacilityDetailsActions.PatchUpdate(this.form.value));
      this.isEditing = false;
    }
  }

  protected updateForm(facility: IFacility): void {
    this.form.patchValue({
      note: facility.note,
    });
  }

  startEditing(): void {
    if (!this.canEdit) {
      return;
    }
    this.form.setValue({ note: this.facility.note });
    this.isEditing = true;
  }

  cancelEditMode(): void {
    this.form.reset();
    this.isEditing = false;
  }
}
