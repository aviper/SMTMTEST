import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { FacilityGroupsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { finalize } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupEditableBlockClass } from '../../../../utils/editable-block.class';

@Component({
  selector: 'app-notes-block',
  templateUrl: './notes-block.component.html',
  styleUrls: ['./notes-block.component.scss'],
  standalone: false,
})
export class NotesBlockComponent extends FacilityGroupEditableBlockClass implements OnInit {
  readonly ICONS = ICONS.actionsV2;
  isEditing = false;
  isLoadingBlock = false;

  @Input() canEdit = false;

  constructor(
    protected fb: UntypedFormBuilder,
    protected store: Store,
    protected modalsService: ModalsV2Service
  ) {
    super(fb, store, modalsService);
  }

  protected createForm(): void {
    this.form = this.fb.group({
      note: [
        null,
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilityGroupsPatterns.note.pattern),
          Validators.maxLength(FacilityGroupsPatterns.note.maxLength),
        ],
      ],
    });
  }

  submit(): void {
    if (this.form.dirty && this.form.valid) {
      this.isLoadingBlock = true;
      this.store
        .dispatch(
          new FacilityGroupDetailsActions.Update({
            id: this.facilityGroup.id,
            body: this.form.value,
          })
        )
        .pipe(
          finalize(() => {
            this.isLoadingBlock = false;
            this.isEditing = false;
          })
        )
        .subscribe(
          () => {},
          () => this.updateForm(this.facilityGroup) // reset form to initial state after not successful update
        );
    }
  }

  protected updateForm(facilityGroup: IFacilityGroup): void {
    this.form.patchValue({
      note: facilityGroup.note,
    });
  }

  startEditing(): void {
    if (!this.canEdit) {
      return;
    }
    this.form.setValue({ note: this.facilityGroup.note });
    this.isEditing = true;
  }

  cancelEditMode(): void {
    this.form.reset();
    this.isEditing = false;
  }
}
