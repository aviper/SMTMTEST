import {
  IGroupTagAndTask,
  IGroupTagAndTaskCreatePayload,
  IGroupTagAndTaskSearchParams,
  IGroupTagAndTaskUpdatePayload,
} from '../../../../../core/models/tags-and-tasks.model';
import { ISort } from '../../../../../core/models/types/common';

export namespace GroupTagsAndTasksActions {
  export class SetParams {
    static readonly type = '[Group Tags and Tasks] Set Facility Group Id';

    constructor(readonly payload: { facilityGroupId: number; limit: number }) {}
  }

  export class LoadGroupTagAndTasks {
    static readonly type = '[Group Tags and Tasks] Load Group Tags And Tasks';
  }

  export class SetSearchConfig {
    static readonly type = '[Group Tags and Tasks] Set Search Config';
    constructor(readonly payload: { searchConfig: IGroupTagAndTaskSearchParams }) {}
  }

  export class SetSorting {
    static readonly type = '[Group Tags and Tasks] Set Sorting';
    constructor(readonly payload: { sort: ISort }) {}
  }

  export class CreateGroupTagAndTask {
    static readonly type = '[Group Tags and Tasks] Create Group Exam Tag';

    constructor(readonly payload: IGroupTagAndTaskCreatePayload) {}
  }

  export class DeleteGroupTagAndTask {
    static readonly type = '[Group Tags and Tasks] Delete Group Exam Tag';

    constructor(readonly payload: { tag: IGroupTagAndTask }) {}
  }

  export class UpdateGroupTagAndTaskName {
    static readonly type = '[Group Tags and Tasks] Update Group Exam Tag Name';

    constructor(readonly payload: IGroupTagAndTaskUpdatePayload) {}
  }

  export class PaginateGroupTagsAndTasks {
    static readonly type = '[Group Tags and Tasks] Paginate tags and tasks';

    constructor(readonly payload: number) {}
  }

  export class ResetPagination {
    static readonly type = '[Group Tags and Tasks] Reset pagination';
  }

  export class GroupTagAndTaskCreated {
    static readonly type = '[Group Tags and Tasks] Tag And Task Created';
  }
}
