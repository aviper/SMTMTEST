import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';

import { IPagination } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { IDocumentType } from '../../../../../core/models/types/documentType';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { DocumentTypeActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/document-type.actions';
import { DocumentTypeState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/document-type.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-document-types',
  templateUrl: './group-document-types.component.html',
  styleUrls: ['./group-document-types.component.scss'],
  standalone: false,
})
export class GroupDocumentTypesComponent implements OnInit, OnDestroy {
  readonly isLoading$: Observable<boolean> = this.store.select(DocumentTypeState.isLoading);
  readonly documentTypes$: Observable<IDocumentType[]> = this.store.select(DocumentTypeState.documentTypes);
  readonly pagination$: Observable<IPagination> = this.store.select(DocumentTypeState.pagination);

  facilityGroupId: number;
  limit = DEFAULT_LIMIT;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.facilityGroupId = this.activatedRoute.snapshot.parent.params.id;
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.documentType }));

    this.loadDocumentType();
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new DocumentTypeActions.UpdatePagination({
        groupId: this.facilityGroupId,
        offset,
      })
    );
  }

  private loadDocumentType(): void {
    this.store.dispatch(new DocumentTypeActions.GetDocumentTypes(this.facilityGroupId));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new DocumentTypeActions.ClearDocumentTypes());
  }
}
