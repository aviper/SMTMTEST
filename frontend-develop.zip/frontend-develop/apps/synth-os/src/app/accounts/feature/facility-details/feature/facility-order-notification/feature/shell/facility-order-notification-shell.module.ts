import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FacilityOrderNotificationShellComponent } from './facility-order-notification-shell.component';
import { OrderNotificationTableComponent } from '../../ui/order-notification-table/order-notification-table.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: FacilityOrderNotificationShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FacilityOrderNotificationShellRoutingModule {}

@NgModule({
  imports: [CommonModule, FacilityOrderNotificationShellRoutingModule, OrderNotificationTableComponent],
  declarations: [FacilityOrderNotificationShellComponent],
})
export class FacilityOrderNotificationShellModule {}
