import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FacilityUsersShellComponent } from './facility-users-shell.component';
import { AccountUsersTableComponentModule } from '../../../../../../../shared/ui/modules/account-users-table/account-users-table.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: FacilityUsersShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FacilityUsersShellRoutingModule {}

@NgModule({
  imports: [CommonModule, FacilityUsersShellRoutingModule, AccountUsersTableComponentModule],
  declarations: [FacilityUsersShellComponent],
})
export class FacilityUsersShellModule {}
