import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, skip, takeUntil } from 'rxjs/operators';

import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { PageSavingFeatureClass } from '../../../../../../../core/helpers/page-saving-feature.class';
import { IHistoryState, ISort } from '../../../../../../../core/models/types/common';
import { IUser } from '../../../../../../../core/models/types/user';
import { RoutingService } from '../../../../../../../core/services/routing.service';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityUsersActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-users.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityUsersState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-users.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-users-shell',
  templateUrl: './facility-users-shell.component.html',
  styleUrls: ['./facility-users-shell.component.scss'],
  standalone: false,
})
export class FacilityUsersShellComponent extends PageSavingFeatureClass implements OnInit, OnDestroy {
  readonly users$: Observable<{ users: IUser[]; isLoading: boolean; total: number }> = this.store.select(
    FacilityUsersState.users
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityUsersState.isLoading);
  readonly sort$: Observable<ISort> = this.store.select(FacilityUsersState.sort);
  readonly reload$: Observable<boolean> = this.store.select(FacilityUsersState.reload);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);

  data: IUser[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = false;

  protected historyStateForSaving: IHistoryState = {};
  private unsubscribe$$: Subject<void> = new Subject<void>();
  private facilityId: number;

  constructor(
    protected routingService: RoutingService,
    protected store: Store
  ) {
    super(routingService, store);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
        this.getEmployees(this.pagination.offset);
      });

    this.users$
      .pipe(
        skip(1),
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.users;
        this.pagination.total = data.total || 0;

        if (!this.wasLoadedDataFirstTime) {
          this.normalizePaginationAfterLoadData();
        }
        this.wasLoadedDataFirstTime = true;
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading: boolean) => (this.isLoading = isLoading));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort: ISort) => (this.sorting = sort));

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetHistoryState();

        if (this.facilityId) {
          this.getEmployees();
        }
      });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.users }));
  }

  getEmployees(offset?: number): void {
    this.store.dispatch(
      new FacilityUsersActions.GetUsers({
        id: this.facilityId,
        limit: this.limit,
        offset: offset || 0,
      })
    );
  }

  sortEmployees(sort: ISort): void {
    this.historyStateForSaving.sorting = sort;
    this.store.dispatch(new FacilityUsersActions.UpdateSorting(sort));
    this.resetHistoryState();
    this.store.dispatch(new FacilityUsersActions.ReloadUsers());
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    ++this.pagination.page;
    this.historyStateForSaving.page = this.pagination.page;
    this.getEmployees(this.pagination.offset);
  }

  onScroll(scroll: number): void {
    this.historyStateForSaving.scroll = scroll;
    this.scrolledDistance = 0;
  }

  protected initPageMetaData(): void {
    super.initPageMetaData();
    this.store.dispatch(new FacilityUsersActions.UpdateSorting(this.sorting));
  }

  private resetHistoryState(): void {
    this.pagination = { ...PAGINATION };

    if (this.wasLoadedDataFirstTime) {
      this.scrolledDistance = 0;
      this.historyStateForSaving.scroll = 0;
      this.historyStateForSaving.page = 1;
    }
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FacilityUsersActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
