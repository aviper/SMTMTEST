import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../../core/constants/constants';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { DirectoryActions } from '../../../../../../../shared/data-access/state/directory/directory.actions';
import { SettingsState } from '../../../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-directory-shell',
  templateUrl: './facility-directory-shell.component.html',
  styleUrls: ['./facility-directory-shell.component.scss'],
  standalone: false,
})
export class FacilityDirectoryShellComponent implements OnInit, OnDestroy {
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);

  facilityId: number;
  limit = DEFAULT_LIMIT;
  pagination = { ...PAGINATION };

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
        this.store.dispatch(
          new DirectoryActions.GetDirectoryItems({
            facilityId: this.facilityId,
            limit: this.limit,
            offset: this.pagination.offset,
          })
        );
      });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.directory }));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
