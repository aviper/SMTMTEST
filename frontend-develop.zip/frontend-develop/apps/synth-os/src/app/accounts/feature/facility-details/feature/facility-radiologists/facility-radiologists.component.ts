import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { Radiologist } from '../../../../../core/models/classes/radiologist';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { ISort } from '../../../../../core/models/types/common';
import { IRadiologist } from '../../../../../core/models/types/radiologist';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityRadiologistsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-radiologists.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityRadiologistsState } from '../../../../../core/store/accounts/states/facility/facility-tabs/facility-radiologists.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_DETAILS_TABS } from '../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-radiologists',
  templateUrl: './facility-radiologists.component.html',
  styleUrls: ['./facility-radiologists.component.scss'],
  standalone: false,
})
export class FacilityRadiologistsComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly radiologists$: Observable<Radiologist[]> = this.store.select(FacilityRadiologistsState.radiologists);
  readonly isRadiologistsLoading$: Observable<boolean> = this.store.select(FacilityRadiologistsState.isLoading);
  readonly query$: Observable<string> = this.store.select(FacilityRadiologistsState.query);
  readonly sort$: Observable<ISort> = this.store.select(FacilityRadiologistsState.sort);
  readonly reload$: Observable<boolean> = this.store.select(FacilityRadiologistsState.reload);

  radiologists: Radiologist[] = [];
  isLoading: boolean;
  sorting: ISort;
  pagination: IPagination = { ...PAGINATION };
  limit = 20;
  scrolledDistance = 0;

  permissions: UserPermissions = new UserPermissions();

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private modalService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new FacilityRadiologistsActions.SetLimit({ limit: this.limit }));

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => (this.permissions = permissions));

    this.radiologists$.pipe(takeUntil(this.unsubscribe$$)).subscribe((response) => {
      this.radiologists = response;
      this.pagination.total = this.store.selectSnapshot(FacilityRadiologistsState.total);
    });

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetPageData();
        this.store.dispatch(new FacilityRadiologistsActions.GetRadiologists({ offset: 0 }));
      });

    this.isRadiologistsLoading$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((isLoading) => (this.isLoading = isLoading));

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.loadRadiologists();
      });

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort) => (this.sorting = sort));

    this.query$.pipe(takeUntil(this.unsubscribe$$)).subscribe(() => this.resetPageData());

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.radiologists }));
  }

  updateSorting(sorting: ISort): void {
    this.store.dispatch(new FacilityRadiologistsActions.UpdateSorting({ sorting }));
  }

  deleteRadiologistFromFacility(radiologist: IRadiologist): void {
    this.modalService
      .confirm({
        title: 'Delete',
        message: `Are you sure to delete ${radiologist.fullName} from facility?`,
        cancelButton: 'No',
        confirmationButton: 'Delete',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new FacilityRadiologistsActions.DeleteRadiologistFromFacility({
            radiologistId: radiologist.id,
          })
        );
        this.resetPageData();
      });
  }

  infinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.pagination.page++;
    this.loadRadiologists();
  }

  private loadRadiologists(): void {
    this.store.dispatch(
      new FacilityRadiologistsActions.GetRadiologists({
        offset: this.pagination.offset,
      })
    );
  }

  private resetPageData(): void {
    this.pagination = { ...PAGINATION };
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FacilityRadiologistsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
