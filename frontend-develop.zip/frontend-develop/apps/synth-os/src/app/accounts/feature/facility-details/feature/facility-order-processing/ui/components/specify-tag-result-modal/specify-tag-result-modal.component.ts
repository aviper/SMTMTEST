import { ChangeDetectorRef, Component, inject, Inject } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { TagTitlePattern } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs';

import { ModalClass, MODAL_ACTION_COMPLETE, modalAnimation, ModalOverlayRef } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../core/helpers/custom-validators';
import { IOption } from '../../../../../../../../core/models/types/common';
import { FacilityDetailsState } from '../../../../../../../../core/store/accounts/states/facility/facility-details.state';

@Component({
  selector: 'app-specify-tag-result-modal',
  templateUrl: './specify-tag-result-modal.component.html',
  styleUrls: ['./specify-tag-result-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class SpecifyTagResultModalComponent extends ModalClass {
  private readonly store: Store = inject(Store);

  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityDetailsState.facilityGroupId);

  readonly tagNameValidators = [Validators.required, CustomValidators.patternInput(TagTitlePattern.pattern)];
  readonly ICONS = ICONS;
  readonly form = this.fb.group({
    tag: [null, [Validators.required]],
  });
  private readonly tagControl = this.form.get('tag') as FormControl;
  private selectedOption: IOption = null;
  readonly preselectedTag: string | null;

  constructor(
    private readonly fb: FormBuilder,
    cdRef: ChangeDetectorRef,
    modalOverlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
    const valueEntity = modalOverlayRef.data?.valueEntity;

    if (valueEntity) {
      this.preselectedTag = valueEntity.name;
      this.tagControl.setValue(valueEntity.id);
    }
  }

  closeModal(data?: any): void {
    this.result.next(data);
    this.modalOverlayRef.close();
  }

  closeAfterConfirm(): void {
    this.closeModal();
  }

  submit(): void {
    if (this.form.invalid) {
      return;
    }

    const tagId = this.selectedOption.value;
    const tagName = this.selectedOption.label;

    this.closeModal({
      attribute: 'tag',
      value: tagId,
      valueEntity: {
        id: tagId,
        name: tagName,
      },
    });
  }

  selected(option: IOption): void {
    this.selectedOption = option;
  }
}
