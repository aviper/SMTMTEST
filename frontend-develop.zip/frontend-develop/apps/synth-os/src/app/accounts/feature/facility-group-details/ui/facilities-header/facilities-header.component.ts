import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { FacilitiesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facilities.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { FacilitiesState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/facilities.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { CreateFacilityComponent } from '../../../../ui/create-facility/create-facility.component';

@Component({
  selector: 'app-facilities-header',
  templateUrl: './facilities-header.component.html',
  styleUrls: ['./facilities-header.component.scss'],
  standalone: false,
})
export class FacilitiesHeaderComponent implements OnInit, OnDestroy {
  readonly query$: Observable<string> = this.store.select(FacilitiesState.query);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly groupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  canCreateFacility = false;

  private groupId: number = null;
  private search$$: Subject<string> = new Subject<string>();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.search$$
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((query: string) => {
        this.store.dispatch(new FacilitiesActions.UpdateQuery({ query }));
      });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (permissions: UserPermissions) =>
          (this.canCreateFacility = permissions.canCreate(ACCOUNTS_ENDPOINTS.facilities))
      );

    this.groupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((groupId) => (this.groupId = groupId));
  }

  searchFacilities(query: string): void {
    this.search$$.next(query);
  }

  openModalAddFacility(): void {
    this.modalsService
      .open(CreateFacilityComponent, {
        data: {
          facilityGroupId: this.groupId,
        },
      })
      .subscribe(() => this.store.dispatch(new FacilitiesActions.GetFacilities()));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
