import { Component, EventEmitter, inject, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable, Subject, takeUntil, withLatestFrom } from 'rxjs';

import { IOrdersProcessingErrorsLog } from '../../../../../../../../../../core/models/types/orders-processing-errors-log';
import { ITableColumnWidth } from '../../../../../../../../../../core/models/types/tables';
import { FacilityOrdersProcessingErrorsLogState } from '../../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing-errors-log.state';

@Component({
  selector: 'app-errors-log-tab-table-header',
  templateUrl: './errors-log-tab-table-header.component.html',
  styleUrls: ['./errors-log-tab-table-header.component.scss'],
  standalone: false,
})
export class ErrorsLogTabTableHeaderComponent implements OnDestroy, OnInit {
  private readonly store: Store = inject(Store);

  readonly data$: Observable<IOrdersProcessingErrorsLog[]> = this.store.select(
    FacilityOrdersProcessingErrorsLogState.data
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrdersProcessingErrorsLogState.isLoading);

  @Input() columnsWidth: ITableColumnWidth = {};
  @Output() resolvedChanged = new EventEmitter<boolean>();

  readonly unsubscribe$$ = new Subject<void>();
  readonly control = new UntypedFormControl(false);

  isLoading = false;

  ngOnInit(): void {
    this.isLoading$.pipe(withLatestFrom(this.data$), takeUntil(this.unsubscribe$$)).subscribe(([isLoading, data]) => {
      this.isLoading = isLoading;
      this.control.setValue(data.every((item) => item.resolved));
      this.control.updateValueAndValidity();
    });
  }

  onResolvedChange(value: boolean): void {
    this.resolvedChanged.emit(value);
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
