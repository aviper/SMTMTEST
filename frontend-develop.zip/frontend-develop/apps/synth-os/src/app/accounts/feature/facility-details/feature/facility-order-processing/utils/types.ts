import { IOption } from '../../../../../../core/models/types/common';

export enum OrderProcessingConditionRule {
  CONTAINS = 'contains',
  EQUAL_TO = 'equal_to',
  STARTS_WITH = 'starts_with',
  DOES_NOT_CONTAIN = 'does_not_contain',
  DATE = 'date',
}

export const ROOT_GROUP_FORM_INDEX = 0;

export enum RULE_ACTION {
  SET = 'set',
  NORMALIZE = 'normalize',
  ADD_TAG = 'addTag',
}

export const RULE_ACTION_LABELS = {
  [RULE_ACTION.SET]: 'Set',
  [RULE_ACTION.NORMALIZE]: 'Normalize',
  [RULE_ACTION.ADD_TAG]: 'Add tag',
};

export const RULE_ACTION_OPTIONS: IOption[] = [
  { value: RULE_ACTION.SET, label: RULE_ACTION_LABELS[RULE_ACTION.SET] },
  { value: RULE_ACTION.NORMALIZE, label: RULE_ACTION_LABELS[RULE_ACTION.NORMALIZE] },
  { value: RULE_ACTION.ADD_TAG, label: RULE_ACTION_LABELS[RULE_ACTION.ADD_TAG] },
];

export enum OrderProcessingTabs {
  ERROR_LOG = 'error-log',
  RULE_CONFIGURATION = 'rule-configuration',
}
