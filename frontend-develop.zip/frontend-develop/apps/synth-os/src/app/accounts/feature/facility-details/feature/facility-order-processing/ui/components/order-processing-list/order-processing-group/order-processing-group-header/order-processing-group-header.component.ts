import { Component, Input, OnDestroy, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, takeUntil } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE, PopoverTriggerDirective } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../../../../../core/constants/icon-list';
import { UserPermissions } from '../../../../../../../../../../core/models/classes/userPermissions';
import {
  IOrderProcessingItemCondition,
  IOrdersProcessingGroup,
  OrderProcessingConditionType,
} from '../../../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingActions } from '../../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../../../../profile/data-access/state/profile/profile.state';
import { TABLE_IDGITAL_THEME } from '../../../../../../../../../../shared/ui/modules/table/utils/table.themes';
import { AddOrderProcessingGroupOrSubgroupComponent } from '../../../add-order-processing-group-subgroup/add-order-processing-group-subgroup.component';

@Component({
  selector: 'app-order-processing-group-header',
  templateUrl: './order-processing-group-header.component.html',
  styleUrls: ['./order-processing-group-header.component.scss'],
  standalone: false,
})
export class OrderProcessingGroupHeaderComponent implements OnInit, OnDestroy {
  @ViewChild(PopoverTriggerDirective) popoverTrigger: PopoverTriggerDirective;

  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  @Input() group: IOrdersProcessingGroup;
  @Input() canAdd = false;
  @Input() canDeleteGroup = false;
  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() showDragHandle = true;
  @Input() level = 1;

  @Output() readonly groupAdded = new EventEmitter<void>();

  readonly ICONS = ICONS;
  readonly TABLE_IDGITAL_THEME = TABLE_IDGITAL_THEME;
  private readonly unsubscribe$$: Subject<void> = new Subject();

  facilityId: number = null;

  constructor(
    private store: Store,
    private readonly _modalV2Service: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
      });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.canDeleteGroup = permissions.canDelete(ACCOUNTS_ENDPOINTS.orderProcessing);
        this.canAdd = permissions.canCreate(ACCOUNTS_ENDPOINTS.orderProcessing);
      });
  }

  addSubgroup(): void {
    this._modalV2Service
      .open(AddOrderProcessingGroupOrSubgroupComponent, {
        hasBackdrop: false,
        data: {
          parentId: this.group._id,
        },
      })
      .subscribe((response) => {
        if (response) {
          this.groupAdded.next();
        }
      });
  }

  addRule(): void {
    this.store.dispatch(
      new FacilityOrdersProcessingActions.EnableAddRuleForm({ enabledAddRuleFormIndex: this.group._id })
    );
    this.popoverTrigger.close();
  }

  deleteGroup(): void {
    this._modalV2Service
      .confirm({
        title: `Delete ${!this.group.parentId ? 'Group' : 'Subgroup'}`,
        message: `This will remove the <b>${this.group.name}</b> group and all items contained within. This cannot be undone. Would you like to proceed?`,
        cancelButton: 'Cancel',
        confirmationButton: 'Proceed',
      })
      .pipe(
        filter((res) => res === CONFIRM_POPUP_RESPONSE.submit),
        switchMap(() =>
          this.store.dispatch(
            new FacilityOrdersProcessingActions.DeleteOrdersProcessingGroup({
              facilityId: this.facilityId,
              groupId: this.group._id,
            })
          )
        ),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe({
        next: () => this._modalV2Service.success(`${!this.group.parentId ? 'Group' : 'Subgroup'} was deleted`),
        error: (error) => this._modalV2Service.error(error.message),
      });
  }

  changeCondition(event: IOrderProcessingItemCondition[]): void {
    this.store.dispatch(
      new FacilityOrdersProcessingActions.UpdateOrdersProcessingGroup({
        facilityId: this.facilityId,
        groupId: this.group._id,
        name: this.group.name,
        condition: { data: event },
      })
    );
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
