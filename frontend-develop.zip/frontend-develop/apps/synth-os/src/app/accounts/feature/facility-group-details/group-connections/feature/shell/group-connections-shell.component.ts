import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import {
  IConnectionColumnBase,
  IConnectionColumnButton,
  IConnectionMSStatus,
  IConnectionNames,
  IEnvironmentCreationStatus,
} from '../../../../../../core/models/types/connection';
import { CONNECTION_COLUMN_TYPE } from '../../../../../../core/models/types/enums';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { WebsocketService } from '../../../../../../core/services/websocket.service';
import { FacilityGroupDetailsActions } from '../../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FGConnectionsActions } from '../../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/connections.actions';
import { FacilityGroupDetailsState } from '../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ConnectionsState } from '../../../../../../core/store/accounts/states/facility-group/facility-group-tabs/connections.state';
import { ENV_CONNECTION_STATUS, FACILITY_GROUP_TABS } from '../../../../../utils/constants';

@Component({
  selector: 'app-group-connections-shell',
  templateUrl: './group-connections-shell.component.html',
  styleUrls: ['./group-connections-shell.component.scss'],
  standalone: false,
})
export class GroupConnectionsShellComponent implements OnInit, OnDestroy {
  readonly environmentCreationStatuses$: Observable<IEnvironmentCreationStatus[]> = this.store.select(
    ConnectionsState.environmentCreationStatuses
  );
  readonly environmentMSStatuses$: Observable<IConnectionMSStatus[]> = this.store.select(
    ConnectionsState.environmentMSStatuses
  );
  readonly groupMSStatuses$: Observable<IConnectionMSStatus[]> = this.store.select(ConnectionsState.groupMSStatuses);
  readonly names$: Observable<IConnectionNames[]> = this.store.select(ConnectionsState.names);
  readonly isLoading$: Observable<boolean> = this.store.select(ConnectionsState.isLoading);
  readonly isMSStatusesLoading$: Observable<{
    isEnvironmentMSStatusesReloading: boolean;
    isGroupMSStatusesReloading: boolean;
  }> = this.store.select(ConnectionsState.isMSStatusesLoading);
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  environmentCreationStatuses: {
    data: IEnvironmentCreationStatus[];
    columns: (IConnectionColumnBase | IConnectionColumnButton)[];
  } = {
    data: [],
    columns: [
      { title: 'Title', key: 'title', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 150 },
      { title: 'Type', key: 'type', colType: CONNECTION_COLUMN_TYPE.TEXT, width: 120 },
      { title: 'Status', key: 'status', colType: CONNECTION_COLUMN_TYPE.STATUS, width: 110 },
      {
        buttonId: 'restart',
        title: '',
        key: 'status',
        colType: CONNECTION_COLUMN_TYPE.BUTTON,
        width: 32,
        disabled: (item, key) =>
          ENV_CONNECTION_STATUS[item[key]].key === ENV_CONNECTION_STATUS['success'].key ||
          ENV_CONNECTION_STATUS[item[key]].key === ENV_CONNECTION_STATUS['in_progress'].key,
        value: (item, key) => ENV_CONNECTION_STATUS[item[key]].btnTitle,
      },
    ],
  };

  environmentMSStatuses: { data: IConnectionMSStatus[]; columns: (IConnectionColumnBase | IConnectionColumnButton)[] } =
    {
      data: [],
      columns: [
        { title: 'Name', key: 'name', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 150 },
        { title: 'Status', key: 'status', colType: CONNECTION_COLUMN_TYPE.TEXT, width: 110 },
        { title: 'Working Pods', key: 'workingPods', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 110 },
        { title: 'Timestamp', key: 'timestamp', colType: CONNECTION_COLUMN_TYPE.TEXT, width: 110 },
        {
          title: 'Version',
          key: 'version',
          colType: CONNECTION_COLUMN_TYPE.TEXT,
          type: 'grow',
          width: 110,
          value: this.getConnectionReleaseAndVersion,
        },
      ],
    };

  groupMSStatuses: { data: IConnectionMSStatus[]; columns: (IConnectionColumnBase | IConnectionColumnButton)[] } = {
    data: [],
    columns: [
      { title: 'Name', key: 'name', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 150 },
      { title: 'Status', key: 'status', colType: CONNECTION_COLUMN_TYPE.TEXT, width: 110 },
      { title: 'Working Pods', key: 'workingPods', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 110 },
      { title: 'Timestamp', key: 'timestamp', colType: CONNECTION_COLUMN_TYPE.TEXT, width: 110 },
      {
        title: 'Version',
        key: 'version',
        colType: CONNECTION_COLUMN_TYPE.TEXT,
        type: 'grow',
        width: 110,
        value: this.getConnectionReleaseAndVersion,
      },
    ],
  };

  names: { data: IConnectionNames[]; columns: IConnectionColumnBase[] } = {
    data: [],
    columns: [
      { title: 'Title', key: 'title', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 250 },
      { title: 'Value', key: 'value', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 250 },
    ],
  };

  isLoading = false;
  isMSStatusesLoading = { isGroupMSStatusesReloading: false, isEnvironmentMSStatusesReloading: false };
  private facilityGroupUniqueName: string;
  private groupId: number;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private wsService: WebsocketService
  ) {}

  ngOnInit(): void {
    this.facilityGroup$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityGroup) => {
        this.groupId = facilityGroup.id;
        this.facilityGroupUniqueName = facilityGroup.uniqueName;
        this.loadFacilityGroupConnection();
      });

    this.environmentCreationStatuses$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((response) => (this.environmentCreationStatuses.data = response));

    this.environmentMSStatuses$
      .pipe(
        filter((environmentMSStatuses) => !!environmentMSStatuses.length),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.environmentMSStatuses.data = response;
      });

    this.groupMSStatuses$
      .pipe(
        filter((groupMSStatuses) => !!groupMSStatuses.length),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.groupMSStatuses.data = response;
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.isMSStatusesLoading$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((isMSStatusesLoading) => (this.isMSStatusesLoading = isMSStatusesLoading));

    this.names$.pipe(takeUntil(this.unsubscribe$$)).subscribe((response) => (this.names.data = response));

    this.listenStatusUpdates();
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.connections }));
  }

  restartConnection(connection: IEnvironmentCreationStatus): void {
    this.store.dispatch(
      new FGConnectionsActions.RestartConnection({ groupId: this.groupId, connectionId: connection.id })
    );
  }

  deleteConnection(connection: IEnvironmentCreationStatus): void {
    this.store.dispatch(
      new FGConnectionsActions.RemoveConnection({
        groupId: this.groupId,
        connectionId: connection.id,
      })
    );
  }

  listenStatusUpdates(): void {
    this.wsService
      .on<IEnvironmentCreationStatus>('facility_group_env_status_updated')
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((res: IEnvironmentCreationStatus) => {
        this.store.dispatch(new FGConnectionsActions.UpdateConnection(res));
      });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FGConnectionsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }

  reloadEnvironmentMSStatusesConnection(): void {
    this.environmentMSStatuses.data = [];
    this.store.dispatch(
      new FGConnectionsActions.GetMSConnections({
        key: this.facilityGroupUniqueName,
        isMsLoading: { isEnvironmentMSStatusesReloading: true, isGroupMSStatusesReloading: false },
      })
    );
  }

  reloadGroupMSStatusesConnection(): void {
    this.groupMSStatuses.data = [];
    this.store.dispatch(
      new FGConnectionsActions.GetMSConnections({
        key: this.facilityGroupUniqueName,
        isMsLoading: { isEnvironmentMSStatusesReloading: false, isGroupMSStatusesReloading: true },
      })
    );
  }

  private loadFacilityGroupConnection(): void {
    this.environmentMSStatuses.data = [];
    this.groupMSStatuses.data = [];
    this.store.dispatch(new FGConnectionsActions.GetConnections(this.groupId));
    this.store.dispatch(
      new FGConnectionsActions.GetMSConnections({
        key: this.facilityGroupUniqueName,
        isMsLoading: { isEnvironmentMSStatusesReloading: true, isGroupMSStatusesReloading: true },
      })
    );
  }

  private getConnectionReleaseAndVersion(connection: IConnectionMSStatus): string {
    return typeof connection.release === 'number'
      ? `${connection.release} - ${connection.version}`
      : `${connection.release}`;
  }
}
