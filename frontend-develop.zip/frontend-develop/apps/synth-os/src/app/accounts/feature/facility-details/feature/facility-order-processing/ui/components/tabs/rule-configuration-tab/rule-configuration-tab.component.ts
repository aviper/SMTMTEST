import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject, takeUntil } from 'rxjs';

import {
  convertFromGroupsAndRulesToModel,
  IOrdersProcessingGroup,
  IOrdersProcessingModel,
  IOrdersProcessingRule,
} from '../../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityOrdersProcessingState } from '../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing.state';

@Component({
  selector: 'app-rule-configuration-tab',
  templateUrl: './rule-configuration-tab.component.html',
  styleUrls: ['./rule-configuration-tab.component.scss'],
  standalone: false,
})
export class OrderConfigurationTabComponent implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);
  private readonly unsubscribe$$ = new Subject<void>();

  readonly data$: Observable<(IOrdersProcessingGroup | IOrdersProcessingRule)[]> = this.store.select(
    FacilityOrdersProcessingState.data
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isLoading);
  readonly isFiltering$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isFiltering);

  items: IOrdersProcessingModel[] = [];
  isLoading: boolean;
  isFiltering: boolean;

  ngOnInit(): void {
    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.data$.pipe(takeUntil(this.unsubscribe$$)).subscribe((data) => {
      if (!data) {
        this.items = [];

        return;
      }

      this.items = convertFromGroupsAndRulesToModel(data);
    });

    this.isFiltering$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isFiltering) => (this.isFiltering = isFiltering));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new FacilityOrdersProcessingActions.ClearData());
  }
}
