import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../../core/constants/constants';
import { IFacility } from '../../../../../../../core/models/types/facility';
import { IParser } from '../../../../../../../core/models/types/parser';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityParsersActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/parsers.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityParsersState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/parsers.state';
import { SettingsState } from '../../../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-parser-shell',
  templateUrl: './facility-parser-shell.component.html',
  styleUrls: ['./facility-parser-shell.component.scss'],
  standalone: false,
})
export class FacilityParserShellComponent implements OnInit, OnDestroy {
  readonly parsers$: Observable<IParser[]> = this.store.select(FacilityParsersState.parsers);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityParsersState.isLoading);
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  parsers: IParser[] = [];
  isLoading = true;
  pagination: IPagination = { ...PAGINATION };
  limit = DEFAULT_LIMIT;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.loadParsers());

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.parsers$.pipe(takeUntil(this.unsubscribe$$)).subscribe((res) => {
      this.parsers = res;
      this.pagination.total = this.store.selectSnapshot(FacilityParsersState.total);
    });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.parser }));
    this.store.dispatch(new FacilityParsersActions.GetParserActions());
  }

  private loadParsers(): void {
    this.store.dispatch(
      new FacilityParsersActions.GetFacilityParsers({
        limit: this.limit,
        offset: this.pagination.offset,
      })
    );
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.pagination.page++;
    this.loadParsers();
  }

  ngOnDestroy(): void {
    this.store.dispatch(new StateReset(FacilityParsersState));
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
