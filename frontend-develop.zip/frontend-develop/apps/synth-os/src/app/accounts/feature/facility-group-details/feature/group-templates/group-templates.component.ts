import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PaginationStrategiesNames, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IHumanErrorBody } from '../../../../../core/models/types/common';
import { IDefaultFinding } from '../../../../../core/models/types/dictionary';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { TemplateActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/template.action';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { TemplateState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/template.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { CptTemplatePopupComponent } from '../../../../../shared/ui/components/cpt-template-popup/cpt-template-popup.component';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-templates',
  templateUrl: './group-templates.component.html',
  styleUrls: ['./group-templates.component.scss'],
  standalone: false,
})
export class GroupTemplatesComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly templates$: Observable<IDefaultFinding[]> = this.store.select(TemplateState.templates);
  readonly isLoading$: Observable<boolean> = this.store.select(TemplateState.isLoading);
  readonly pagination$: Observable<IPagination> = this.store.select(TemplateState.pagination);
  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);

  @Input() paginationStrategy: PaginationStrategiesNames = PaginationStrategiesNames.weak;

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  defaultFindings: IDefaultFinding[] = [];
  pagination: IPagination = { ...PAGINATION };
  limit = DEFAULT_LIMIT;
  isLoading = false;
  permissions = new UserPermissions();

  private facilityGroupId: number;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private facilitiesService: FacilitiesService,
    private modalsService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.templates }));
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new TemplateActions.SetLimit({ limit: this.limit }));

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => (this.permissions = permissions));

    this.templates$.pipe(takeUntil(this.unsubscribe$$)).subscribe((defaultFindings) => {
      this.defaultFindings = defaultFindings;
    });

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));

    this.facilityGroupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((groupId) => {
      this.facilityGroupId = groupId;

      if (groupId) {
        this.store.dispatch(new TemplateActions.GetTemplates({ id: groupId }));
      }
    });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));
  }

  onDefaultFindingsScroll(offset: number): void {
    this.store.dispatch(
      new TemplateActions.UpdatePagination({
        offset: offset,
        page: this.pagination.page + 1,
      })
    );
  }

  updateFindings(defaultFinding: IDefaultFinding): void {
    this.modalsService
      .open(CptTemplatePopupComponent, {
        data: {
          nameBtn: 'Cancel',
          title: 'Edit template',
          defaultFinding: defaultFinding,
          groupId: this.facilityGroupId,
          cptCodes: defaultFinding.cptCodes,
          fullRequest: true,
        },
      })
      .pipe(
        filter((response) => Boolean(response)),
        switchMap((response) =>
          this.store.dispatch(
            new TemplateActions.UpdateGroupTemplate({
              groupId: this.facilityGroupId,
              findingId: defaultFinding.id,
              finding: {
                reportFields: response.reportFields,
                name: response.templateName,
                cptCodeIds: response.examCodes,
                defaultFindings: response.template,
                gridLines: response.hideTableGridLines,
              },
            })
          )
        )
      )
      .subscribe({
        error: (error: IHumanErrorBody) => this.modalsService.error(error.message),
      });
  }

  deleteFindings(defaultFinding: IDefaultFinding): void {
    this.facilitiesService.deleteFacilityGroupDefaultFindings(this.facilityGroupId, defaultFinding.id).subscribe(() => {
      this.reloadDefaultTemplates();
      this.modalsService.success(
        'Template for ' +
          (defaultFinding.cptCodes ?? []).map(({ codeWithModifier }) => codeWithModifier).join(', ') +
          ' has been removed'
      );
    });
  }

  private reloadDefaultTemplates(): void {
    this.store.dispatch(
      new TemplateActions.UpdatePagination({
        offset: 0,
        page: 1,
      })
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new TemplateActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
