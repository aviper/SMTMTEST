import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { GroupReportHeaderShellComponent } from './group-report-header-shell.component';
import { ReportPreviewModule } from '../../../../../../../shared/ui/modules/report-preview/report-preview.module';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: GroupReportHeaderShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class GroupReportHeaderShellRoutingModule {}

@NgModule({
  declarations: [GroupReportHeaderShellComponent],
  imports: [CommonModule, ReportPreviewModule, GroupReportHeaderShellRoutingModule],
})
export class GroupReportHeaderShellModule {}
