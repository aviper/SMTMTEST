import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { ColumnPriority } from '../../../../../../../core/constants/constants';
import { TABLE_TYPE } from '../../../../../../../core/constants/table-constants';
import { ContractHoldersService } from '../../../../../../../core/http-services/contract-holders.service';
import { TableSettingsService } from '../../../../../../../core/http-services/table-settings.service';
import { TableSetting } from '../../../../../../../core/models/classes/table-setting';
import { IListResponse } from '../../../../../../../core/models/types/common';
import { IContractHolder, IFacility, IFacilityDepartment } from '../../../../../../../core/models/types/facility';
import { ITableColumnWidth, ITableSetting } from '../../../../../../../core/models/types/tables';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';

@Component({
  selector: 'app-departments-table',
  templateUrl: './departments-table.component.html',
  styleUrls: ['./departments-table.component.scss'],
  standalone: false,
})
export class DepartmentsTableComponent implements OnInit {
  private store: Store = inject(Store);
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  @Input() set departments(departments: IFacilityDepartment[]) {
    this.data = departments;
  }

  @Input() pagination: IPagination;
  @Input() limit = 20;
  @Input() isLoading = false;
  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() changed = new EventEmitter<IFacilityDepartment>();

  data: IFacilityDepartment[] = [];
  tableSettings: ITableSetting[] = [];
  displayedColumnsMap = {};
  contractHoldersData: { isContactHolderRequired: boolean; data: IContractHolder[] } = {
    isContactHolderRequired: true,
    data: [],
  };
  columnsWidth: ITableColumnWidth = {};
  enableResize = true;

  readonly PaginationStrategiesNames = PaginationStrategiesNames;
  readonly TABLE_TYPE = TABLE_TYPE;
  readonly TABLE_COLUMNS_SETTINGS = {
    id: {
      minWidth: 50,
      priority: ColumnPriority.none,
    },
    name: {
      minWidth: 100,
      priority: ColumnPriority.none,
    },
    isMain: {
      minWidth: 50,
      priority: ColumnPriority.none,
    },
    email: {
      minWidth: 120,
      priority: ColumnPriority.none,
    },
    fdPhone: {
      minWidth: 100,
      priority: ColumnPriority.none,
    },
    fdFax: {
      minWidth: 180,
      priority: ColumnPriority.none,
    },
    departmentsResponses: {
      minWidth: 100,
      priority: ColumnPriority.none,
    },
    contractHolderId: {
      minWidth: 120,
      priority: ColumnPriority.none,
    },
    autoDelivery: {
      minWidth: 130,
      priority: ColumnPriority.none,
    },
    notes: {
      minWidth: 100,
      priority: ColumnPriority.none,
    },
  };

  columns = Object.keys(this.TABLE_COLUMNS_SETTINGS);

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private contractHoldersService: ContractHoldersService,
    protected tableSettingsService: TableSettingsService
  ) {}

  ngOnInit(): void {
    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.contractHoldersService
          .getHolders({
            facilityGroupId: facility.groupId,
            limit: 100,
          })
          .subscribe(
            (response) =>
              (this.contractHoldersData = {
                data: response.data,
                isContactHolderRequired: this.contractHoldersData?.isContactHolderRequired,
              })
          );

        this.contractHoldersData = {
          data: this.contractHoldersData.data,
          isContactHolderRequired: !!facility.group?.isContractHolderRequired,
        };
      });

    this.loadTableSettings();
  }

  hideColumn(columnKey: string): void {
    const columnForHide = this.tableSettings.find((setting) => setting.key === columnKey);

    if (columnForHide) {
      columnForHide.value = false;
    }
    this.updateSettings(this.tableSettings);
  }

  updateSettings(newSettings: ITableSetting[]): void {
    this.tableSettingsService
      .updateSettings(TABLE_TYPE.facilityDetailsDepartment, { values: newSettings })
      .subscribe(() => {
        this.tableSettings = [...newSettings];
        this.updateDisplayedColumnsMap(TableSetting.calculateVisibleColumns(this.tableSettings));
      });
  }

  setColumnsWidth(columnsWidth: ITableColumnWidth): void {
    this.columnsWidth = { ...columnsWidth };
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }

  private loadTableSettings(): void {
    this.tableSettingsService.getSettings(TABLE_TYPE.facilityDetailsDepartment).subscribe((res: IListResponse) => {
      this.tableSettings = res.data;
      this.updateDisplayedColumnsMap(TableSetting.calculateVisibleColumns(this.tableSettings));
    });
  }

  private updateDisplayedColumnsMap(settings: ITableSetting[]): void {
    this.displayedColumnsMap = TableSetting.getDisplayedColumnsMapFromSettings(settings);
  }
}
