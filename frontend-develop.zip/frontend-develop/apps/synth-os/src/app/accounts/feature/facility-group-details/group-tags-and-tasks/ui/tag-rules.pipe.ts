import { Pipe, PipeTransform } from '@angular/core';

import { IGroupTagAndTaskRule } from '../../../../../core/models/tags-and-tasks.model';

@Pipe({
  name: 'tagRules',
})
export class TagRulesPipe implements PipeTransform {
  transform(rules: IGroupTagAndTaskRule[]): { name: string }[] {
    return rules.map((rule: IGroupTagAndTaskRule) => ({ name: `${rule._id}: ${rule.name}` }));
  }
}
