import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/internal/operators/takeUntil';
import { filter } from 'rxjs/operators';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../../../core/models/classes/userPermissions';
import { IFacility, IReportHeaderTemplate } from '../../../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityGroupDetailsActions } from '../../../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../profile/data-access/state/profile/profile.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-report-header-shell',
  templateUrl: './facility-report-header-shell.component.html',
  styleUrls: ['./facility-report-header-shell.component.scss'],
  host: { class: 'custom-scroll' },
  standalone: false,
})
export class FacilityReportHeaderShellComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  facility: IFacility;
  permissions: UserPermissions = new UserPermissions();
  isLoading = true;
  isUpdating = false;
  canEdit = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.facility$
      .pipe(
        filter((facilitiy) => !!facilitiy),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.facility = facility;
      });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.canEdit = permissions.canEdit(ACCOUNTS_ENDPOINTS.facilities);
      });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.reportHeader }));
  }

  onReportUploaded(reportHeader: IReportHeaderTemplate): void {
    this.store.dispatch(new FacilityGroupDetailsActions.UpdateReportHeader({ reportHeader }));
  }

  onReportDeleted(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.UpdateReportHeader({ reportHeader: null }));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
