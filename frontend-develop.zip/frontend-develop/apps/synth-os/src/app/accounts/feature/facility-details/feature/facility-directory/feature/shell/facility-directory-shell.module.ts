import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FacilityDirectoryShellComponent } from './facility-directory-shell.component';
import { DirectoryTableComponentModule } from '../../../../../../../shared/ui/components/directory/directory-table.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: FacilityDirectoryShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FacilityDirectoryShellRoutingModule {}

@NgModule({
  imports: [CommonModule, FacilityDirectoryShellRoutingModule, DirectoryTableComponentModule],
  declarations: [FacilityDirectoryShellComponent],
})
export class FacilityDirectoryShellModule {}
