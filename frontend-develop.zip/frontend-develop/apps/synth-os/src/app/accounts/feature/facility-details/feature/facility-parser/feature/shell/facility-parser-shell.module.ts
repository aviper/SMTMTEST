import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { ModalsV2Module } from '@synth/ui/modals';

import { FacilityParserShellComponent } from './facility-parser-shell.component';
import { OldInputComponent } from '../../../../../../../shared/ui/components/controls/input/input.component';
import { SelectComponent } from '../../../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldIconComponentModule } from '../../../../../../../shared/ui/components/icon/icon.component';
import { InlineEditBlockV2ComponentModule } from '../../../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { ButtonsModule } from '../../../../../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { ParsersTableHeaderComponent } from '../../ui/parsers-table/parsers-table-header/parsers-table-header.component';
import { ParsersTableRowComponent } from '../../ui/parsers-table/parsers-table-row/parsers-table-row.component';
import { ParsersTableComponent } from '../../ui/parsers-table/parsers-table.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: FacilityParserShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FacilityParserShellRoutingModule {}

@NgModule({
  imports: [
    CommonModule,
    FacilityParserShellRoutingModule,
    TableModule,
    SelectComponent,
    EllipsisTextModule,
    ButtonsModule,
    OldIconComponentModule,
    InlineEditBlockV2ComponentModule,
    OldInputComponent,
    ReactiveFormsModule,
    ModalsV2Module,
  ],
  declarations: [
    FacilityParserShellComponent,
    ParsersTableComponent,
    ParsersTableRowComponent,
    ParsersTableHeaderComponent,
  ],
})
export class FacilityParserShellModule {}
