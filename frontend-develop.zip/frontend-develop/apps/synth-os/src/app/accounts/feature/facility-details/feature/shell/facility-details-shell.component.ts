import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Subject, Observable, withLatestFrom } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { ITabMenuItem } from '../../../../../core/models/types/common';
import { IFacility } from '../../../../../core/models/types/facility';
import { TabMenuService } from '../../../../../core/services/tab-menu.service';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { FACILITY_DETAILS_TABS } from '../../../..../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-details-shell',
  templateUrl: './facility-details-shell.component.html',
  styleUrls: ['./facility-details-shell.component.scss'],
  standalone: false,
})
export class FacilityDetailsShellComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  readonly SIDEBAR_ICONS = ICONS.sideBar;

  canEditFacility = false;
  isCollapsedRightAside = false;
  facilityDetailsMenu: ITabMenuItem[] = [];
  selectedTab = FACILITY_DETAILS_TABS.departments;
  permissions = new UserPermissions();
  facility: IFacility;

  private facilityId: number;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private activatedRoute: ActivatedRoute,
    private tabMenuService: TabMenuService,
    private facilitiesService: FacilitiesService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.pipe(takeUntil(this.unsubscribe$$)).subscribe((paramMap: ParamMap) => {
      this.facilityId = parseInt(paramMap.get('id'), 10);
      this.store.dispatch(new FacilityDetailsActions.SetFacilityIdParam(this.facilityId));
      this.store.dispatch(new FacilityDetailsActions.GetFacility(this.facilityId));
    });

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => (this.facility = facility));

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.permissions = permissions;
        this.canEditFacility = permissions.canEdit(ACCOUNTS_ENDPOINTS.facilities);
        this.initTabMenu();
      });

    this.facilitiesService
      .onAccountUpdated()
      .pipe(
        withLatestFrom(this.store.select(FacilityDetailsState.loadingFields)),
        filter(
          ([data, loadingFields]) =>
            data.type === 'facility' && data.id === this.facilityId && !Object.values(loadingFields).some((v) => !!v)
        ),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.store.dispatch(new FacilityDetailsActions.GetFacility(this.facilityId));
      });
  }

  toggleAside(): void {
    this.isCollapsedRightAside = !this.isCollapsedRightAside;
  }

  private initTabMenu(): void {
    this.facilityDetailsMenu = this.tabMenuService.getFacilityDetailsTabs(this.permissions);
  }

  tabChanged(selectedTab: string): void {
    this.selectedTab = FACILITY_DETAILS_TABS[selectedTab];
  }

  ngOnDestroy(): void {
    this.store.dispatch(new StateReset(FacilityDetailsState));
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
