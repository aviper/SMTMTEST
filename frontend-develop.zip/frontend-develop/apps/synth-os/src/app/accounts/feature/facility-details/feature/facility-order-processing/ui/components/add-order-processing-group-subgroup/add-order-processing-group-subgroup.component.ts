import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, take, takeUntil } from 'rxjs';

import { ModalsV2Service, MODAL_ACTION_COMPLETE, ModalOverlayRef, modalAnimation, ModalClass } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { FacilityOrdersProcessingActions } from '../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityOrdersProcessingState } from '../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing.state';

@Component({
  selector: 'app-add-order-processing-group-subgroup',
  templateUrl: './add-order-processing-group-subgroup.component.html',
  styleUrls: ['./add-order-processing-group-subgroup.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddOrderProcessingGroupOrSubgroupComponent extends ModalClass implements OnInit, OnDestroy {
  private readonly unsubscribe$$: Subject<void> = new Subject<void>();
  readonly ICONS = ICONS;
  readonly parentId = this.modalOverlayRef.data?.parentId;
  readonly form = this.fb.group({
    name: ['', Validators.required],
  });

  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isLoading);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);

  facilityId: number;

  constructor(
    private readonly fb: UntypedFormBuilder,
    private readonly store: Store,
    private readonly modalService: ModalsV2Service,
    cdRef: ChangeDetectorRef,
    modalOverlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.facilityId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((facilityId) => (this.facilityId = facilityId));
  }

  closeBeforeConfirm(): void {
    if (!this.form.value?.name) {
      this.modalService
        .confirm({
          title: 'Wait!',
          message: 'Groups and Subgroups cannot be created without a name. Would you like to continue?',
          confirmationButton: 'Yes',
          cancelButton: 'No',
        })
        .pipe(filter((value) => value === 'submit'))
        .subscribe(() => this.closeModal(true));

      return;
    }

    this.closeModal(false);
  }

  createGroupOrSubgroup(): void {
    this.form.updateValueAndValidity();

    if (this.form.invalid) {
      return;
    }

    this.store
      .dispatch(
        new FacilityOrdersProcessingActions.CreateOrdersProcessingGroup({
          ...this.form.value,
          facilityId: this.facilityId,
          parentId: this.parentId,
        })
      )
      .pipe(take(1))
      .subscribe(() => this.closeModal(true));
  }

  closeModal(reload: boolean): void {
    this.result.emit(true);
    this.modalOverlayRef.close();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
