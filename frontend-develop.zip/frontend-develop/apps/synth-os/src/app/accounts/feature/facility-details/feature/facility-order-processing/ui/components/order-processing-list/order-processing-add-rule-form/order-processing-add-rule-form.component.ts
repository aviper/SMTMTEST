import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, takeUntil } from 'rxjs';

import { ModalsV2Service, PopoverTriggerDirective } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../../core/helpers/custom-validators';
import { IOption } from '../../../../../../../../../core/models/types/common';
import { IFacility } from '../../../../../../../../../core/models/types/facility';
import { OrderProcessingConditionType } from '../../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { DisableNavigationActions } from '../../../../../../../../../shared/data-access/state/disable-navigation/disable-navigation.actions';
import { TABLE_IDGITAL_THEME } from '../../../../../../../../../shared/ui/modules/table/utils/table.themes';
import { ConditionNamePipe } from '../../../../../../../../ui/pipes/condition-name.pipe';
import { RULE_ACTION, RULE_ACTION_OPTIONS } from '../../../../utils/types';
import { SpecifyConditionModalComponent } from '../../specify-condition-modal/specify-condition-modal.component';
import { SpecifyRuleResultModalComponent } from '../../specify-rule-result-modal/specify-rule-result-modal.component';
import { SpecifyTagResultModalComponent } from '../../specify-tag-result-modal/specify-tag-result-modal.component';

@Component({
  selector: 'app-order-processing-add-rule-form',
  templateUrl: './order-processing-add-rule-form.component.html',
  styleUrls: ['./order-processing-add-rule-form.component.scss'],
  providers: [ConditionNamePipe],
  standalone: false,
})
export class OrderProcessingAddRuleFormComponent implements OnInit, OnDestroy {
  @ViewChild(PopoverTriggerDirective, { static: false }) popoverController: PopoverTriggerDirective;

  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() groupId: number;

  @Output() readonly ruleAdded = new EventEmitter<void>();

  readonly ACTION_ICONS = ICONS.actionsV2;
  readonly TABLE_IDGITAL_THEME = TABLE_IDGITAL_THEME;

  isRuleActionNormalize = false;
  actionsOptions: IOption[] = RULE_ACTION_OPTIONS;
  ruleForm: UntypedFormGroup;

  private readonly unsubscribe$$: Subject<void> = new Subject();
  private facility: IFacility;

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service,
    private readonly fb: UntypedFormBuilder,
    private readonly conditionNamePipe: ConditionNamePipe
  ) {}

  ngOnInit(): void {
    this.store.dispatch(
      new DisableNavigationActions.Disable({
        message:
          'Required fields have not been populated for all rules. Changes will be lost if you leave this page. Would you like to continue?',
        action: () =>
          this.store.dispatch(new FacilityOrdersProcessingActions.EnableAddRuleForm({ enabledAddRuleFormIndex: null })),
      })
    );

    this.jumpToFormPosition();

    this.ruleForm = this.fb.group({
      condition: [null, [CustomValidators.required]],
      action: [RULE_ACTION.SET, [CustomValidators.required]],
      result: [null, [CustomValidators.required]],
    });

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.facility = facility;
      });

    this.ruleForm.valueChanges.pipe(takeUntil(this.unsubscribe$$)).subscribe((res) => {
      this.isRuleActionNormalize = RULE_ACTION.NORMALIZE === res.action;

      this.removeResultRequireValidatorIfActionIsEqualNormalize(res.action);

      if (this.ruleForm.valid) {
        this.store
          .dispatch(
            new FacilityOrdersProcessingActions.CreateOrdersProcessingRule({
              facilityId: this.facility.id,
              orderProcessingGroupsId: this.groupId,
              name: this.conditionNamePipe.transform(res.condition),
              action: res.action !== RULE_ACTION.NORMALIZE ? { ...res.result, name: res.action } : { name: res.action },
              condition: { data: res.condition },
            })
          )
          .subscribe({
            next: () => {
              this.ruleAdded.next();
              this.hideAddRuleForm();
            },
            error: (error) => this.modalsV2Service.error(error.message),
          });
      }
    });
  }

  private removeResultRequireValidatorIfActionIsEqualNormalize(action: RULE_ACTION): void {
    const resultFormControl = this.ruleForm.get('result');

    if (action === RULE_ACTION.NORMALIZE && !!resultFormControl.validator) {
      resultFormControl.removeValidators([CustomValidators.required]);
      this.ruleForm.get('result').updateValueAndValidity({ emitEvent: false });
    } else if (action !== RULE_ACTION.NORMALIZE && !resultFormControl.validator) {
      resultFormControl.setValidators([CustomValidators.required]);
      this.ruleForm.get('result').updateValueAndValidity({ emitEvent: false });
    }
  }

  hideAddRuleForm(closePopover: boolean = false): void {
    closePopover && this.popoverController?.close();
    this.store.dispatch(new FacilityOrdersProcessingActions.EnableAddRuleForm({ enabledAddRuleFormIndex: null }));
  }

  changeCondition(): void {
    this.modalsV2Service
      .open(SpecifyConditionModalComponent, {
        data: {
          condition: this.ruleForm.get('condition').value,
          treeConditionsType: this.conditionsType,
          isRuleActionNormalize: this.isRuleActionNormalize,
          facilityId: this.facility.id,
        },
      })
      .subscribe((result) => this.ruleForm.get('condition').setValue(result));
  }

  changeResult(): void {
    const action = this.ruleForm.getRawValue().action;

    switch (action) {
      case RULE_ACTION.SET:
        this.openSpecifyRuleResultModal();
        break;
      case RULE_ACTION.ADD_TAG:
        this.openSpecifyTagResultModal();
        break;
    }
  }

  private openSpecifyTagResultModal(): void {
    this.modalsV2Service
      .open(SpecifyTagResultModalComponent, {
        listenBackdrop: false,
        data: {
          ...this.ruleForm.get('result').value,
          groupId: this.facility.groupId,
        },
      })
      .subscribe((res) => {
        if (!res) {
          return;
        }
        this.ruleForm.get('result').setValue(res);
      });
  }

  private openSpecifyRuleResultModal(): void {
    this.modalsV2Service
      .open(SpecifyRuleResultModalComponent, {
        listenBackdrop: false,
        data: {
          ...this.ruleForm.get('result').value,
          groupId: this.facility.groupId,
        },
      })
      .subscribe((res) => {
        if (!res) {
          return;
        }
        this.ruleForm.get('result').setValue(res);
      });
  }

  private jumpToFormPosition(): void {
    const formRowElement = document.getElementById('addRuleForm');
    const topPos = formRowElement.offsetTop;
    const mainBlockWrapperElement = document.getElementsByClassName('main-block-container-wrap')?.[0];

    if (mainBlockWrapperElement) {
      mainBlockWrapperElement.scrollTop = topPos;
    }
  }

  ngOnDestroy(): void {
    this.store.dispatch(new DisableNavigationActions.Enable());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
