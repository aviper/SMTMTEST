import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ACTION_COLUMN_WIDTH } from '../../../../../../core/constants/table-constants';
import { IOption } from '../../../../../../core/models/types/common';
import { IFacility } from '../../../../../../core/models/types/facility';
import { ITableColumnWidth } from '../../../../../../core/models/types/tables';

@Component({
  selector: 'app-facilities-table-row',
  templateUrl: './facilities-table-row.component.html',
  styleUrls: ['./facilities-table-row.component.scss'],
  standalone: false,
})
export class FacilitiesTableRowComponent {
  readonly ACTION_COLUMN_WIDTH = ACTION_COLUMN_WIDTH;

  @Input() facility: IFacility;
  @Input() columnsWidth: ITableColumnWidth = {};
  @Input() displayedColumnsMap: { [key: string]: number } = {};
  @Input() contractHolderOptions: IOption[];
  @Input() canUpdateFacility: boolean;

  @Output() onSetContractHolder: EventEmitter<number> = new EventEmitter<number>();

  updateContractHolder(event: IOption): void {
    this.onSetContractHolder.emit(event.value);
  }
}
