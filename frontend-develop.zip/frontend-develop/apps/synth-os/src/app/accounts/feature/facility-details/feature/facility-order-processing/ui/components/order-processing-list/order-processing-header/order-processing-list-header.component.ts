import { Component } from '@angular/core';

@Component({
  selector: 'app-order-processing-list-header',
  templateUrl: './order-processing-list-header.component.html',
  styleUrls: ['./order-processing-list-header.component.scss'],
  standalone: false,
})
export class OrderProcessingListHeaderComponent {}
