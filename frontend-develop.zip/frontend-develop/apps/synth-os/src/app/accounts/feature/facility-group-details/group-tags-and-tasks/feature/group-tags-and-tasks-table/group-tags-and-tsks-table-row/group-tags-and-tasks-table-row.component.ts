import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, input, Input, InputSignal, OnInit, Signal } from '@angular/core';
import { ReactiveFormsModule, UntypedFormBuilder, UntypedFormControl } from '@angular/forms';
import { MatTooltip } from '@angular/material/tooltip';
import { Store } from '@ngxs/store';
import { finalize } from 'rxjs/operators';

import { CheckboxComponent, IconComponent, InputComponent } from '@synth/ui';
import { ICONS } from '@synth/utils';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { TagsAndTasksService } from '../../../../../../../core/http-services/tags-and-tasks.service';
import { IGroupTagAndTask, TagTaskConfidentiality } from '../../../../../../../core/models/tags-and-tasks.model';
import { IOption } from '../../../../../../../core/models/types/common';
import { FacilityGroupDetailsState } from '../../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { SynthSelectComponent } from '../../../../../../../shared/ui/components/controls/selects/synth-select/select.component';
import { OldIconComponentModule } from '../../../../../../../shared/ui/components/icon/icon.component';
import { InlineEditBlockV2ComponentModule } from '../../../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { ControlErrorV2DirectiveModule } from '../../../../../../../shared/ui/directives/control-error-v2.directive';
import { ControlErrorDirectiveModule } from '../../../../../../../shared/ui/directives/control-error.directive';
import { TableModule } from '../../../../../../../shared/ui/modules/table/table.module';
import { ArrayNamesPipeModule } from '../../../../../../../shared/ui/pipes/array-names.pipe';
import { TooltipListPipe } from '../../../../../../../shared/ui/pipes/multiline-tooltip.pipe';
import { GroupTagsAndTasksActions } from '../../../data-access/group-tags-and-tasks.actions';
import { TagRulesPipe } from '../../../ui/tag-rules.pipe';

@Component({
  selector: 'synth-group-tags-and-tasks-table-row',
  templateUrl: './group-tags-and-tasks-table-row.component.html',
  styleUrls: ['./group-tags-and-tasks-table-row.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    TableModule,
    OldIconComponentModule,
    IconComponent,
    CheckboxComponent,
    ArrayNamesPipeModule,
    TooltipListPipe,
    SynthSelectComponent,
    InlineEditBlockV2ComponentModule,
    ControlErrorV2DirectiveModule,
    ControlErrorDirectiveModule,
    ReactiveFormsModule,
    TagRulesPipe,
    InputComponent,
    MatTooltip,
  ],
})
export class GroupTagsAndTasksTableRowComponent implements OnInit {
  @Input() canEdit = false;
  @Input() canDelete = false;

  readonly confidentialOptions: InputSignal<IOption[]> = input([]);
  readonly tagAndTask: InputSignal<IGroupTagAndTask> = input();
  readonly facilityGroupId$ = this.store.select(FacilityGroupDetailsState.facilityGroupId);
  readonly ICONS = ICONS;
  readonly filteredConfidentialOptions: Signal<IOption[]> = computed(() => this.computeConfidentialOptions());
  readonly tagAndTaskInUse: Signal<boolean> = computed(
    () => this.tagAndTask().usedInDuty || this.tagAndTask().usedInOPR || this.tagAndTask().usedInOrders
  );

  isNameChecking = false;
  control: UntypedFormControl;

  private facilityGroupId: number;

  constructor(
    private readonly store: Store,
    private readonly tagsAndTasksService: TagsAndTasksService,
    private fb: UntypedFormBuilder
  ) {}

  ngOnInit(): void {
    this.facilityGroupId = this.store.selectSnapshot(FacilityGroupDetailsState.facilityGroupId);

    this.control = this.fb.control(
      this.tagAndTask().name,
      [CustomValidators.required],
      [
        CustomValidators.inputExistanceChecker(
          (nameControlValue) => {
            this.isNameChecking = true;

            return this.tagsAndTasksService
              .getGroupTagsAndTasks(this.facilityGroupId, { name: nameControlValue.query.trim() })
              .pipe(finalize(() => (this.isNameChecking = false)));
          },
          'name',
          'This name already exists.'
        ),
      ]
    );
  }

  updateItem(tagId: number, property: string, value: string | boolean): void {
    this.store.dispatch(new GroupTagsAndTasksActions.UpdateGroupTagAndTaskName({ tagId, property, value }));
  }

  deleteItem(tag: IGroupTagAndTask): void {
    this.store.dispatch(new GroupTagsAndTasksActions.DeleteGroupTagAndTask({ tag }));
  }

  private computeConfidentialOptions(): IOption[] {
    if (this.tagAndTask().usedInDuty || this.tagAndTask().usedInOPR) {
      const options = this.confidentialOptions().filter(
        (option: IOption) => option.value !== TagTaskConfidentiality.personal
      );

      return options;
    }

    return this.confidentialOptions();
  }
}
