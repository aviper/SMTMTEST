import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { IFacilityDepartment } from '../../../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityDepartmentsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/departments.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityDepartmentsState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/departments.state';
import { SettingsState } from '../../../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-departments-shell',
  templateUrl: './facility-departments-shell.component.html',
  styleUrls: ['./facility-departments-shell.component.scss'],
  standalone: false,
})
export class FacilityDepartmentsShellComponent implements OnInit, OnDestroy {
  readonly departments$: Observable<IFacilityDepartment[]> = this.store.select(FacilityDepartmentsState.departments);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityDepartmentsState.isLoading);
  readonly query$: Observable<string> = this.store.select(FacilityDepartmentsState.query);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);

  departments: IFacilityDepartment[] = [];
  isLoading = true;
  pagination: IPagination = { ...PAGINATION };
  limit = 20;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new FacilityDepartmentsActions.SetLimit({ limit: this.limit }));

    this.departments$
      .pipe(
        filter((data) => data !== null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.departments = response;
        this.pagination.lastChunkSize = response.length;
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.loadDepartments();
      });

    this.query$.pipe(takeUntil(this.unsubscribe$$)).subscribe(() => this.resetPageData());

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.departments }));
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.loadDepartments();
  }

  private loadDepartments(): void {
    this.store.dispatch(
      new FacilityDepartmentsActions.GetFacilityDepartments({
        offset: this.pagination.offset,
      })
    );
  }

  resetPageData(): void {
    this.pagination = { ...PAGINATION };
  }

  ngOnDestroy(): void {
    this.store.dispatch(new StateReset(FacilityDepartmentsState));
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
