import { ChangeDetectionStrategy, Component, inject, input, InputSignal } from '@angular/core';

import { GatewayDestination } from '@synth/api';
import { ButtonComponent } from '@synth/ui';
import { ModalsV2Service } from '@synth/ui/modals';

import { GatewayDestinationDetailsModalComponent } from '../gateway-destination-details-modal/gateway-destination-details-modal.component';

@Component({
  selector: 'synth-gateway-destination-details-cell',
  template: `
    <synth-button
      [disabled]="rowLoading()"
      (onClick)="openDetails()">
      View details
    </synth-button>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ButtonComponent],
})
export class GatewayDestinationDetailsCellComponent {
  private readonly modalsService: ModalsV2Service = inject(ModalsV2Service);

  readonly item: InputSignal<GatewayDestination> = input.required<GatewayDestination>();
  readonly rowLoading: InputSignal<boolean> = input<boolean>(false);

  openDetails(): void {
    this.modalsService.open(GatewayDestinationDetailsModalComponent, { data: { destination: this.item() } });
  }
}
