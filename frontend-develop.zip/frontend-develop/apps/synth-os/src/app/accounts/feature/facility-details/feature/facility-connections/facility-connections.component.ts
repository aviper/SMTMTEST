import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';

import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import {
  IConnectionColumnBase,
  IConnectionColumnButton,
  IConnectionNames,
  IEnvironmentCreationStatus,
} from '../../../../../core/models/types/connection';
import { CONNECTION_COLUMN_TYPE } from '../../../../../core/models/types/enums';
import { WebsocketService } from '../../../../../core/services/websocket.service';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityConnectionsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-connections.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityConnectionsState } from '../../../../../core/store/accounts/states/facility/facility-tabs/facility-connections.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { FACILITY_DETAILS_TABS } from '../../../../../shared/utils/constants';
import { ENV_CONNECTION_STATUS } from '../../../../utils/constants';

@Component({
  selector: 'app-facility-connections',
  templateUrl: './facility-connections.component.html',
  styleUrls: ['./facility-connections.component.scss'],
  standalone: false,
})
export class FacilityConnectionsComponent implements OnInit, OnDestroy {
  readonly ENV_CONNECTION_STATUS = ENV_CONNECTION_STATUS;

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly facilityCreationStatuses$: Observable<IEnvironmentCreationStatus[]> = this.store.select(
    FacilityConnectionsState.facilityCreationStatuses
  );
  readonly names$: Observable<IConnectionNames[]> = this.store.select(FacilityConnectionsState.names);

  constructor(
    private facilityService: FacilitiesService,
    private wsService: WebsocketService,
    private store: Store
  ) {}

  permissions: UserPermissions = new UserPermissions();
  facilityId: number;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  facilityCreationStatuses: {
    data: IEnvironmentCreationStatus[];
    columns: (IConnectionColumnBase | IConnectionColumnButton)[];
  } = {
    data: [],
    columns: [
      { title: 'Title', key: 'title', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 150 },
      { title: 'Status', key: 'status', colType: CONNECTION_COLUMN_TYPE.STATUS, width: 110 },
      {
        buttonId: 'restart',
        title: 'Action',
        key: 'status',
        colType: CONNECTION_COLUMN_TYPE.BUTTON,
        width: 110,
        disabled: (item, key) =>
          ENV_CONNECTION_STATUS[item[key]].key === ENV_CONNECTION_STATUS['success'].key ||
          ENV_CONNECTION_STATUS[item[key]].key === ENV_CONNECTION_STATUS['in_progress'].key,
        value: (item, key) => ENV_CONNECTION_STATUS[item[key]].btnTitle,
      },
    ],
  };

  names: { data: IConnectionNames[]; columns: IConnectionColumnBase[] } = {
    data: [],
    columns: [
      { title: 'Title', key: 'title', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 150 },
      { title: 'Value', key: 'value', colType: CONNECTION_COLUMN_TYPE.TEXT, type: 'grow', width: 300 },
    ],
  };

  ngOnInit(): void {
    this.permissions$.pipe(takeUntil(this.unsubscribe$$)).subscribe((permissions: UserPermissions) => {
      this.permissions = permissions;
    });

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
        this.store.dispatch(new FacilityConnectionsActions.GetConnections(this.facilityId));
      });

    this.facilityCreationStatuses$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((statuses) => (this.facilityCreationStatuses.data = statuses));

    this.names$.pipe(takeUntil(this.unsubscribe$$)).subscribe((names) => (this.names.data = names));

    this.listenStatusUpdates();
    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.connections }));
  }

  restartFacilityConnection(connection: IEnvironmentCreationStatus): void {
    this.store.dispatch(
      new FacilityConnectionsActions.RestartFacilityConnection({
        facilityId: connection.facilityId,
        connectionId: connection.id,
      })
    );
  }

  listenStatusUpdates(): void {
    this.wsService
      .on<IEnvironmentCreationStatus>('facility_env_status_updated')
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((res: IEnvironmentCreationStatus) => {
        this.store.dispatch(new FacilityConnectionsActions.UpdateFacilityConnection(res));
      });

    this.wsService
      .on<IEnvironmentCreationStatus>('facility_group_env_status_updated')
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((res: IEnvironmentCreationStatus) => {
        this.store.dispatch(new FacilityConnectionsActions.UpdateProjectConnection(res));
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
