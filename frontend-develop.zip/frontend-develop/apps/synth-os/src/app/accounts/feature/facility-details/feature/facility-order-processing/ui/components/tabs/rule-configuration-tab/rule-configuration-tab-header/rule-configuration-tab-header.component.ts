import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, takeUntil } from 'rxjs';

import { ModalsV2Service } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../../../../../core/constants/icon-list';
import { UserPermissions } from '../../../../../../../../../../core/models/classes/userPermissions';
import { IFacility } from '../../../../../../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityOrdersProcessingActions } from '../../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../../../../profile/data-access/state/profile/profile.state';
import { ROOT_GROUP_FORM_INDEX } from '../../../../../utils/types';
import { AddOrderProcessingGroupOrSubgroupComponent } from '../../../add-order-processing-group-subgroup/add-order-processing-group-subgroup.component';
import { CloneProcessingRulesModalComponent } from '../../../clone-processing-rules-modal/clone-processing-rules-modal.component';

@Component({
  selector: 'app-rule-configuration-tab-header',
  templateUrl: './rule-configuration-tab-header.component.html',
  styleUrls: ['./rule-configuration-tab-header.component.scss'],
  standalone: false,
})
export class RuleConfigurationTabHeaderComponent implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly unsubscribe$$ = new Subject<void>();

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);
  readonly procedureNormalization$: Observable<boolean> = this.store.select(
    FacilityDetailsState.procedureNormalization
  );

  procedureNormalization = false;
  facility: IFacility;
  canAdd = false;

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.procedureNormalization$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((procedureNormalization) => (this.procedureNormalization = procedureNormalization));

    this.facility$.pipe(takeUntil(this.unsubscribe$$)).subscribe((facility) => (this.facility = facility));

    this.permissions$
      .pipe(
        takeUntil(this.unsubscribe$$),
        filter((permissions) => !!permissions)
      )
      .subscribe((permissions) => {
        this.canAdd = permissions.canCreate(ACCOUNTS_ENDPOINTS.orderProcessing);
      });
  }

  openCreateOrderProcessingGroupModal(): void {
    this.modalsV2Service.createModal(AddOrderProcessingGroupOrSubgroupComponent, { hasBackdrop: false });
  }

  openCloneProcessingRulesModal(): void {
    this.modalsV2Service.createModal(CloneProcessingRulesModalComponent, {
      data: {
        facility: this.facility,
      },
    });
  }

  addOrderProcessingRule(): void {
    this.store.dispatch(
      new FacilityOrdersProcessingActions.EnableAddRuleForm({ enabledAddRuleFormIndex: ROOT_GROUP_FORM_INDEX })
    );
  }

  onProcedureNormalizationChanged(procedureNormalization: boolean): void {
    this.store.dispatch(new FacilityDetailsActions.PatchUpdate({ procedureNormalization }));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
