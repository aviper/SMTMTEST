import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  DestroyRef,
  Inject,
  OnInit,
  signal,
  WritableSignal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';

import {
  DICOM_TYPES_OPTIONS,
  GatewayDestination,
  GatewayDestinationType,
  SOP_CLASS_OPTIONS,
  TRANSFER_SYNTAX_OPTIONS,
} from '@synth/api';
import { ButtonComponent, IconWithAreaComponent, InputComponent } from '@synth/ui';
import {
  CONFIRM_POPUP_RESPONSE,
  DEFAULT_CONFIRM_DATA,
  MODAL_ACTION_COMPLETE,
  modalAnimation,
  ModalClass,
  ModalOverlayRef,
  ModalsV2Service,
} from '@synth/ui/modals';
import { ICONS } from '@synth/utils';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { SynthSelectComponent } from '../../../../../../../shared/ui/components/controls/selects/synth-select/select.component';
import { ControlErrorV2DirectiveModule } from '../../../../../../../shared/ui/directives/control-error-v2.directive';
import { LoaderModule } from '../../../../../../../shared/ui/modules/loader/loader.module';
import { GatewaysDestinationsActions } from '../../data-access/gateways-destinations.actions';

interface GatewayDestinationFormModel {
  name: FormControl<string>;
  type: FormControl<GatewayDestinationType>;
  host: FormControl<string>;
  port: FormControl<string>;
  calledTitle: FormControl<string>;
  callingTitle: FormControl<string>;
  transferSyntax: FormControl<string>;
  excludedSOPClasses: FormControl<string[]>;
}

@Component({
  selector: 'synth-create-edit-gateway-destination-modal',
  templateUrl: './create-edit-gateway-destination-modal.component.html',
  styleUrls: ['./create-edit-gateway-destination-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [modalAnimation],
  imports: [
    IconWithAreaComponent,
    ButtonComponent,
    LoaderModule,
    ReactiveFormsModule,
    InputComponent,
    ControlErrorV2DirectiveModule,
    SynthSelectComponent,
  ],
})
export class CreateEditGatewayDestinationModalComponent extends ModalClass implements OnInit {
  readonly DICOM_TYPES_OPTIONS = DICOM_TYPES_OPTIONS;
  readonly SOP_CLASS_OPTIONS = SOP_CLASS_OPTIONS;
  readonly TRANSFER_SYNTAX_OPTIONS = TRANSFER_SYNTAX_OPTIONS;
  readonly ICONS = ICONS;

  readonly destination: GatewayDestination;
  readonly facilityGroupId: number;
  readonly destinationForm: FormGroup<GatewayDestinationFormModel>;
  readonly RESTRICTED_SPACE = new RegExp(/\s/);
  readonly RESTRICTED_SPACE_ERROR = 'Spaces are not allowed';

  readonly loading: WritableSignal<boolean> = signal<boolean>(false);

  constructor(
    protected cdRef: ChangeDetectorRef,
    public overlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>,
    private fb: FormBuilder,
    private destroyRef: DestroyRef,
    private modalsService: ModalsV2Service,
    private store: Store
  ) {
    super(cdRef, overlayRef, actionComplete$);

    this.destination = this.overlayRef.data.destination;
    this.facilityGroupId = this.overlayRef.data.facilityGroupId;

    this.destinationForm = this.createForm();
  }

  ngOnInit(): void {
    this.modalOverlayRef.backdropClick
      .pipe(
        filter(() => !this.loading()),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(() => this.closeAfterConfirm());
  }

  createForm(): FormGroup<GatewayDestinationFormModel> {
    return this.fb.group<GatewayDestinationFormModel>({
      name: this.fb.control(this.destination ? this.destination.name : '', { validators: CustomValidators.required }),
      type: this.fb.control(this.destination ? this.destination.type : GatewayDestinationType.dicom, {
        validators: CustomValidators.required,
      }),
      host: this.fb.control(this.destination ? this.destination.configuration.host : '', {
        validators: CustomValidators.required,
      }),
      port: this.fb.control(this.destination ? this.destination.configuration.port : '', {
        validators: CustomValidators.required,
      }),
      calledTitle: this.fb.control(this.destination ? this.destination.configuration.calledTitle : '', {
        validators: [
          CustomValidators.required,
          CustomValidators.restrictInput(this.RESTRICTED_SPACE, this.RESTRICTED_SPACE_ERROR),
          Validators.maxLength(16),
        ],
      }),
      callingTitle: this.fb.control(this.destination ? this.destination.configuration.callingTitle : '', {
        validators: [
          CustomValidators.required,
          CustomValidators.restrictInput(this.RESTRICTED_SPACE, this.RESTRICTED_SPACE_ERROR),
          Validators.maxLength(16),
        ],
      }),
      transferSyntax: this.fb.control(this.destination ? this.destination.configuration.transferSyntax : ''),
      excludedSOPClasses: this.fb.control(this.destination ? this.destination.configuration.excludedSOPClasses : []),
    });
  }

  save(): void {
    if (this.destinationForm.invalid) {
      return;
    }

    let action$: Observable<any>;

    if (this.destination) {
      const body: Omit<GatewayDestination, 'isActive'> = {
        id: this.destination.id,
        facilityGroupId: this.destination.facilityGroupId,
        name: this.destinationForm.value.name,
        type: this.destinationForm.value.type,
        configuration: {
          host: this.destinationForm.value.host,
          port: this.destinationForm.value.port,
          calledTitle: this.destinationForm.value.calledTitle,
          callingTitle: this.destinationForm.value.callingTitle,
          transferSyntax: this.destinationForm.value.transferSyntax || '',
          excludedSOPClasses: this.destinationForm.value.excludedSOPClasses,
        },
      };

      action$ = this.store.dispatch(
        new GatewaysDestinationsActions.UpdateDestination({ original: this.destination, body: body })
      );
    } else {
      action$ = this.store.dispatch(
        new GatewaysDestinationsActions.CreateDestination({
          facilityGroupId: this.facilityGroupId,
          name: this.destinationForm.value.name,
          type: this.destinationForm.value.type,
          configuration: {
            host: this.destinationForm.value.host,
            port: this.destinationForm.value.port,
            calledTitle: this.destinationForm.value.calledTitle,
            callingTitle: this.destinationForm.value.callingTitle,
            transferSyntax: this.destinationForm.value.transferSyntax || '',
            excludedSOPClasses: this.destinationForm.value.excludedSOPClasses,
          },
        })
      );
    }

    this.loading.set(true);
    action$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => {
        this.loading.set(false);
        this.closeModal();
      },
      error: () => {
        this.loading.set(false);
      },
    });
  }

  closeAfterConfirm(): void {
    if (this.destinationForm.dirty) {
      this.modalsService.confirm(DEFAULT_CONFIRM_DATA).subscribe((result) => {
        if (result === CONFIRM_POPUP_RESPONSE.cancel) {
          this.closeModal();
        }
      });
    } else {
      this.closeModal();
    }
  }

  closeModal(): void {
    this.modalOverlayRef.close();
  }
}
