import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';

import { AutoFocusDirective } from '@synth/ui';

import { FacilityDetailsShellRoutingModule } from './facility-details-shell-routing.module';
import { FacilityDetailsShellComponent } from './facility-details-shell.component';
import { ActionsButtonDropdownComponentModule } from '../../../../../shared/ui/components/actions-button-dropdown/actions-button-dropdown.component';
import { OldContainerBlockModule } from '../../../../../shared/ui/components/container-block/container-block.component';
import { OldCheckboxComponent } from '../../../../../shared/ui/components/controls/checkbox/checkbox/checkbox.component';
import { OldInputComponent } from '../../../../../shared/ui/components/controls/input/input.component';
import { MaskInputComponent } from '../../../../../shared/ui/components/controls/mask-input/mask-input.component';
import { MaskPhoneInputComponent } from '../../../../../shared/ui/components/controls/mask-phone-input/mask-phone-input.component';
import { OldRadioButtonComponent } from '../../../../../shared/ui/components/controls/radio/radio-button/radio-button.component';
import { OldRadioGroupComponent } from '../../../../../shared/ui/components/controls/radio/radio-group/radio-group.component';
import { SearchFieldComponent } from '../../../../../shared/ui/components/controls/search-field/search-field.component';
import { AddressSelectV2Component } from '../../../../../shared/ui/components/controls/selects/address-select-v2/address-select-v2.component';
import { CitySelectComponent } from '../../../../../shared/ui/components/controls/selects/city-select.component/city-select.component';
import { FacilityTypeSelectV2Component } from '../../../../../shared/ui/components/controls/selects/facility-type-select-v2/facility-type-select-v2.component';
import { ModalitySelectV2Component } from '../../../../../shared/ui/components/controls/selects/modality-select-v2/modality-select-v2.component';
import { OrderProcessingFieldsSelectComponent } from '../../../../../shared/ui/components/controls/selects/order-processing-fields-select/order-processing-fields-select.component';
import { OrderProcessingTagsSelectComponent } from '../../../../../shared/ui/components/controls/selects/order-processing-tags-select/order-processing-tags-select.component';
import { RegionSelectV2Component } from '../../../../../shared/ui/components/controls/selects/region-select-v2/region-select-v2.component';
import { SelectComponent } from '../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../../../shared/ui/components/controls/switcher/switcher.component';
import { OldTextAreaComponent } from '../../../../../shared/ui/components/controls/text-area/text-area.component';
import { DirectoryTableComponentModule } from '../../../../../shared/ui/components/directory/directory-table.component';
import { ExpansionBlockComponentModule } from '../../../../../shared/ui/components/expansion-block/expansion-block.component';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';
import { InfoComponentModule } from '../../../../../shared/ui/components/info/info.component';
import { InlineEditBlockV2ComponentModule } from '../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { TableSettingsV2ComponentModule } from '../../../../../shared/ui/components/table-settings-v2/table-settings-v2.module';
import { WebsiteInputModule } from '../../../../../shared/ui/components/website-input/website-input.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../shared/ui/directives/control-error-v2.directive';
import { ControlErrorDirectiveModule } from '../../../../../shared/ui/directives/control-error.directive';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { FiltersModule } from '../../../../../shared/ui/modules/filters/filters.module';
import { LoaderModule } from '../../../../../shared/ui/modules/loader/loader.module';
import { MdePopoverModule } from '../../../../../shared/ui/modules/mde-popover';
import { RadiologistsTableModule } from '../../../../../shared/ui/modules/radiologists-table/radiologists-table.module';
import { TabMenuModule } from '../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../../../shared/ui/modules/table/table.module';
import { DepartmentReportsPipeModule } from '../../../../../shared/ui/pipes/department-reports.pipe';
import { FormControlPipeModule } from '../../../../../shared/ui/pipes/form-control.pipe';
import { IsFieldLoadingPipe } from '../../../../../shared/ui/pipes/is-field-loading.pipe';
import { PhonePipeModule } from '../../../../../shared/ui/pipes/phone.pipe';
import { RegionsNamesPipeModule } from '../../../../../shared/ui/pipes/regions-names.pipe';
import { AccountsShellModule } from '../../../shell/accounts-shell.module';
import { FACILITY_DETAILS_UI_COMPONENTS } from '../../ui';
import { FacilityConnectionsModule } from '../facility-connections/facility-connections.module';
import { FacilityFormsModule } from '../facility-forms/feature/shell/facility-forms-shell.module';
import { OrderProcessingShellModule } from '../facility-order-processing/feature/shell/order-processing-shell.module';

@NgModule({
  declarations: [...FACILITY_DETAILS_UI_COMPONENTS, FacilityDetailsShellComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FacilityDetailsShellRoutingModule,
    TabMenuModule,
    OrderProcessingShellModule,
    FacilityFormsModule,
    FacilityConnectionsModule,
    RadiologistsTableModule,
    OldIconComponentModule,
    OldContainerBlockModule,
    ExpansionBlockComponentModule,
    InfoComponentModule,
    TableModule,
    EllipsisTextModule,
    MdePopoverModule,
    DirectoryTableComponentModule,
    ButtonsModule,
    FormControlPipeModule,
    MatTooltipModule,
    OldCheckboxComponent,
    SearchFieldComponent,
    MaskInputComponent,
    MaskPhoneInputComponent,
    OldRadioButtonComponent,
    OldRadioGroupComponent,
    OldTextAreaComponent,
    OldSwitcherComponent,
    OldInputComponent,
    SelectComponent,
    AddressSelectV2Component,
    CitySelectComponent,
    FacilityTypeSelectV2Component,
    ModalitySelectV2Component,
    OrderProcessingFieldsSelectComponent,
    RegionSelectV2Component,
    InlineEditBlockV2ComponentModule,
    AccountsShellModule,
    CdkScrollableExtendedDirectiveModule,
    ControlErrorV2DirectiveModule,
    LoaderModule,
    PhonePipeModule,
    DepartmentReportsPipeModule,
    TableSettingsV2ComponentModule,
    WebsiteInputModule,
    FiltersModule,
    ActionsButtonDropdownComponentModule,
    RegionsNamesPipeModule,
    ControlErrorDirectiveModule,
    OrderProcessingTagsSelectComponent,
    IsFieldLoadingPipe,
    AutoFocusDirective,
  ],
})
export class FacilityDetailsShellModule {}
