import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Store } from '@ngxs/store';
import { noop, Observable, Subject } from 'rxjs';
import { finalize, takeUntil, filter } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../../../../core/http-services/facilities.service';
import { IHumanErrorBody, IItemResponse } from '../../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { FacilityGroupDetailsState } from '../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';

@Component({
  selector: 'app-facility-group-gsps',
  templateUrl: './facility-group-gsps.component.html',
  styleUrls: ['./facility-group-gsps.component.scss'],
  standalone: false,
})
export class FacilityGroupGspsComponent implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);

  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  form: UntypedFormGroup;
  disabledForm = true;
  isLoading = false;
  enableGSPSControl: UntypedFormControl;

  private facilityGroup: IFacilityGroup;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private fb: UntypedFormBuilder,
    private facilityService: FacilitiesService,
    private modalsV2Service: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.enableGSPSControl = this.fb.control(false);
    this.facilityGroup$
      .pipe(
        filter((facilityGroup) => !!facilityGroup),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityGroup) => {
        this.facilityGroup = facilityGroup;
        this.getFacilityGspsConfig();
        this.enableGSPSControl.setValue(this.facilityGroup.gspsEnabled);
      });

    this.form = this.fb.group({
      port: [null, [CustomValidators.required, Validators.maxLength(100)]],
      title: [null, [CustomValidators.required, Validators.maxLength(100)]],
      ip: [null, [CustomValidators.required, Validators.maxLength(100)]],
    });
  }

  saveGSPS(): void {
    this.isLoading = true;
    this.disabledForm = true;
    this.facilityService
      .saveGSPS(this.facilityGroup.id, this.form.value, { autoNotifyErrors: false })
      .pipe(
        finalize(() => {
          this.isLoading = false;
          this.disabledForm = false;
        }),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        () => this.modalsV2Service.success('Deployment of the export adapter will take a time'),
        (error) => this.modalsV2Service.error(error.message)
      );
  }

  toggleEnableSwitcher(event: boolean): void {
    this.disabledForm = !event;
    this.facilityService
      .toggleGSPS(this.facilityGroup.id, { mode: event }, { autoNotifyErrors: false })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(noop, (error) => this.modalsV2Service.error(error.message));
  }

  private getFacilityGspsConfig(): void {
    this.facilityService
      .getFacilityGroupGsps(this.facilityGroup.id, { autoNotifyErrors: false })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(
        (res: IItemResponse) => {
          this.form.patchValue({
            port: res.data.port,
            title: res.data.title,
            ip: res.data.ip,
          });
        },
        (error: IHumanErrorBody) => this.modalsV2Service.error(error.message)
      );
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
