import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, skip, takeUntil } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { PageSavingFeatureClass } from '../../../../../core/helpers/page-saving-feature.class';
import { IHistoryState, ISort } from '../../../../../core/models/types/common';
import { ICustomFormField } from '../../../../../core/models/types/custom-fields-and-forms';
import { RoutingService } from '../../../../../core/services/routing.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { GroupFieldsLibraryActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/group-fields-library.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { GroupFieldsLibraryState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/group-fields-library.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { CloneFieldModalComponent } from '../../../../../shared/ui/components/clone-field-modal/clone-field-modal.component';
import { CreateFieldModalComponent } from '../../../../../shared/ui/components/create-field-modal/create-field-modal.component';
import { createFieldModalData } from '../../../../../shared/ui/components/create-field-modal/create-field-modal.types';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-fields-library',
  templateUrl: './group-fields-library.component.html',
  styleUrls: ['./group-fields-library.component.scss'],
  standalone: false,
})
export class GroupFieldsLibraryComponent extends PageSavingFeatureClass implements OnInit, OnDestroy {
  readonly fields$: Observable<{ fields: ICustomFormField[]; isLoading: boolean; total: number }> = this.store.select(
    GroupFieldsLibraryState.fields
  );
  readonly isLoading$: Observable<boolean> = this.store.select(GroupFieldsLibraryState.isLoading);
  readonly sort$: Observable<ISort> = this.store.select(GroupFieldsLibraryState.sort);
  readonly reload$: Observable<boolean> = this.store.select(GroupFieldsLibraryState.reload);
  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  data: ICustomFormField[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = false;
  facilityGroupId: number;
  scrolledDistance = 0;
  sorting: ISort = null;
  limit = DEFAULT_LIMIT;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  protected wasLoadedDataFirstTime = false;
  protected historyStateForSaving: IHistoryState = {};

  constructor(
    protected routingService: RoutingService,
    protected store: Store,
    private modalService: ModalsV2Service
  ) {
    super(routingService, store);
  }

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.groupFieldLibrary }));

    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.fields$
      .pipe(
        skip(1),
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.fields;
        this.pagination.total = data.total || 0;

        if (!this.wasLoadedDataFirstTime) {
          this.normalizePaginationAfterLoadData();
        }
        this.wasLoadedDataFirstTime = true;
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.facilityGroupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((facilityGroupId) => {
      this.facilityGroupId = facilityGroupId;

      if (this.facilityGroupId) {
        this.getFacilityFields(this.pagination.offset);
      }
    });

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort: ISort) => (this.sorting = sort));

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetHistoryState();
        this.getFacilityFields();
      });
  }

  getFacilityFields(offset?: number): void {
    this.store.dispatch(
      new GroupFieldsLibraryActions.GetFields({
        facilityGroupId: this.facilityGroupId,
        limit: this.limit,
        offset: offset || 0,
      })
    );
  }

  sortFields(sort: ISort): void {
    this.historyStateForSaving.sorting = sort;
    this.store.dispatch(new GroupFieldsLibraryActions.UpdateSorting(sort));
    this.resetHistoryState();
    this.store.dispatch(new GroupFieldsLibraryActions.ReloadFields());
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.pagination.page++;
    this.historyStateForSaving.page = this.pagination.page;
    this.getFacilityFields(offset);
  }

  onScroll(scroll: number): void {
    this.historyStateForSaving.scroll = scroll;
    this.scrolledDistance = 0;
  }

  private resetHistoryState(): void {
    this.pagination = { ...PAGINATION };

    if (this.wasLoadedDataFirstTime) {
      this.scrolledDistance = 0;
      this.historyStateForSaving.scroll = 0;
      this.historyStateForSaving.page = 1;
    }
  }

  protected initPageMetaData(): void {
    super.initPageMetaData();
    this.store.dispatch(new GroupFieldsLibraryActions.UpdateSorting(this.sorting));
  }

  handleStatusChange(field: ICustomFormField): void {
    this.store.dispatch(new GroupFieldsLibraryActions.UpdateField(field));
  }

  handleCloneField(field: ICustomFormField): void {
    this.modalService
      .open(CloneFieldModalComponent, {
        listenBackdrop: false,
        data: {
          field: field,
        },
      })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => {
        this.store.dispatch(new GroupFieldsLibraryActions.ReloadFields());
      });
  }

  handleEditField(field: ICustomFormField): void {
    this.modalService
      .open(CreateFieldModalComponent, {
        listenBackdrop: false,
        data: createFieldModalData({
          level: 'facilityGroup',
          field: field,
        }),
      })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => {
        this.store.dispatch(new GroupFieldsLibraryActions.ReloadFields());
      });
  }

  handleDeleteField(field: ICustomFormField): void {
    this.modalService
      .confirm({
        title: 'Delete',
        message: `Are you sure you want to delete this field ${field.label} ?`,
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new GroupFieldsLibraryActions.DeleteField({
            id: field.id,
          })
        );
      });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new GroupFieldsLibraryActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
