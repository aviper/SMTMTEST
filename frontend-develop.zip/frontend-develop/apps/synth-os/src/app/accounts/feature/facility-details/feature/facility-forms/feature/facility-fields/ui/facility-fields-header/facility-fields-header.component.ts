import { ChangeDetectionStrategy, Component, computed, input, InputSignal, Signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngxs/store';

import { ButtonComponent } from '@synth/ui';
import { ModalsV2Service } from '@synth/ui/modals';

import { IRights, UserPermissions } from '../../../../../../../../../core/models/classes/userPermissions';
import { IFacility } from '../../../../../../../../../core/models/types/facility';
import { IFilterMapValue } from '../../../../../../../../../core/models/types/filter';
import { FacilityFieldsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-fields.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../../../profile/data-access/state/profile/profile.state';
import { CreateFieldModalComponent } from '../../../../../../../../../shared/ui/components/create-field-modal/create-field-modal.component';
import { createFieldModalData } from '../../../../../../../../../shared/ui/components/create-field-modal/create-field-modal.types';
import { FILTERS_STORAGE_PAGES } from '../../../../../../../../../shared/ui/modules/filters/constants/constants';
import { IFilterForApi } from '../../../../../../../../../shared/ui/modules/filters/constants/models';
import { FiltersModule } from '../../../../../../../../../shared/ui/modules/filters/filters.module';
import { FiltersApiMapperService } from '../../../../../../../../../shared/ui/modules/filters/services/filters-api-mapper';

@Component({
  selector: 'synth-facility-fields-header',
  templateUrl: './facility-fields-header.component.html',
  styleUrls: ['./facility-fields-header.component.scss'],
  imports: [FiltersModule, FormsModule, ButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FacilityFieldsHeaderComponent {
  readonly FILTERS_STORAGE_PAGES: typeof FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;

  readonly facility: Signal<IFacility> = this.store.selectSignal(FacilityDetailsState.facility);
  readonly permissions: Signal<UserPermissions> = this.store.selectSignal(ProfileState.permissions);

  readonly rights: InputSignal<IRights> = input.required<IRights>();

  readonly canCreate: Signal<boolean> = computed(() => this.rights().canCreate);

  readonly filtersInitConfig = computed(() => {
    const permissions = this.permissions();

    if (!permissions) {
      return null;
    }

    return {
      permissions,
    };
  });

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service
  ) {}

  handleInitFilters(filters: IFilterMapValue): void {
    const filtersForApi = FiltersApiMapperService.getPreparedForAPIFilterMapV2(filters);

    this.store.dispatch(new FacilityFieldsActions.UpdateFilters(filtersForApi));
  }

  handleFiltersChange(filters: IFilterForApi): void {
    this.store.dispatch(new FacilityFieldsActions.UpdateFilters(filters));
  }

  openCreateFieldModal(): void {
    const facility = this.facility();

    if (!facility) {
      return;
    }

    this.modalsV2Service.open(CreateFieldModalComponent, {
      listenBackdrop: false,
      data: createFieldModalData({
        level: 'facility',
        facilityId: facility.id,
        facilityGroupId: facility.groupId,
      }),
    });
  }
}
