import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, takeUntil } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../../../../core/constants/icon-list';
import { UserPermissions } from '../../../../../../../../../core/models/classes/userPermissions';
import { IOption } from '../../../../../../../../../core/models/types/common';
import { IFacility } from '../../../../../../../../../core/models/types/facility';
import {
  ICreateOrUpdateOrdersProcessingRule,
  IOrderProcessingItemCondition,
  IOrdersProcessingRule,
  OrderProcessingConditionType,
} from '../../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../../../../../profile/data-access/state/profile/profile.state';
import { TABLE_IDGITAL_THEME } from '../../../../../../../../../shared/ui/modules/table/utils/table.themes';
import { ConditionNamePipe } from '../../../../../../../../ui/pipes/condition-name.pipe';
import { RULE_ACTION, RULE_ACTION_OPTIONS } from '../../../../utils/types';
import { SpecifyRuleResultModalComponent } from '../../specify-rule-result-modal/specify-rule-result-modal.component';
import { SpecifyTagResultModalComponent } from '../../specify-tag-result-modal/specify-tag-result-modal.component';

@Component({
  selector: 'app-order-processing-rule',
  templateUrl: './order-processing-rule.component.html',
  styleUrls: ['./order-processing-rule.component.scss'],
  providers: [ConditionNamePipe],
  standalone: false,
})
export class OrderProcessingRuleComponent implements OnInit, OnDestroy {
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  @Input() rule: IOrdersProcessingRule;
  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() showDragHandle = true;
  @Input() level = 1;

  isLoading = false;
  canAdd = true;
  canDeleteRule = true;
  actionsOptions: IOption[] = RULE_ACTION_OPTIONS;
  facility: IFacility;

  readonly TABLE_IDGITAL_THEME = TABLE_IDGITAL_THEME;
  readonly ACTION_ICONS = ICONS.actionsV2;
  readonly RULE_ACTION = RULE_ACTION;
  readonly ICONS = ICONS;
  readonly unsubscribe$$ = new Subject<void>();
  readonly form = this.fb.group({
    action: ['', Validators.required],
    condition: ['', Validators.required],
    result: ['', Validators.required],
  });

  constructor(
    private readonly fb: UntypedFormBuilder,
    private modalV2Service: ModalsV2Service,
    private conditionNamePipe: ConditionNamePipe,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.form.patchValue(this.rule);

    if (this.rule && this.rule.action) {
      this.form.get('action').setValue(this.rule.action.name);
    }

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.facility = facility;
      });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.canDeleteRule = permissions.canDelete(ACCOUNTS_ENDPOINTS.orderProcessing);
        this.canAdd = permissions.canCreate(ACCOUNTS_ENDPOINTS.orderProcessing);
      });
  }

  submit(property: RULE_ACTION): void {
    if ([RULE_ACTION.SET, RULE_ACTION.ADD_TAG].includes(property)) {
      this.rule = { ...this.rule, action: { name: property } };
      this.changeResult();

      return;
    }

    const data: { facilityId: number; ruleId: number } & ICreateOrUpdateOrdersProcessingRule = {
      facilityId: this.facility.id,
      ruleId: this.rule._id,
      name: this.rule.name,
      action: property === RULE_ACTION.NORMALIZE ? { name: property } : { ...this.rule.action, name: property },
      condition: this.rule.condition,
    };

    this.store.dispatch(new FacilityOrdersProcessingActions.UpdateOrdersProcessingRule(data));
  }

  deleteRule(): void {
    this.modalV2Service
      .confirm({
        title: 'Delete Rule',
        message: 'This will remove the selected rule. This cannot be undone. Would you like to proceed?',
        cancelButton: 'Cancel',
        confirmationButton: 'Proceed',
      })
      .pipe(
        filter((res) => res === CONFIRM_POPUP_RESPONSE.submit),
        switchMap(() =>
          this.store.dispatch(
            new FacilityOrdersProcessingActions.DeleteOrdersProcessingRule({
              facilityId: this.facility.id,
              ruleId: this.rule._id,
            })
          )
        ),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe({
        next: () => this.modalV2Service.success('Rule was deleted'),
        error: (error) => this.modalV2Service.error(error.message),
      });
  }

  changeResult(): void {
    if (!this.canAdd) {
      return;
    }

    switch (this.rule.action.name) {
      case RULE_ACTION.SET:
        this.openSpecifyRuleResultModal();
        break;
      case RULE_ACTION.ADD_TAG:
        this.openSpecifyTagResultModal();
        break;
    }
  }

  changeCondition(event: IOrderProcessingItemCondition[]): void {
    const data: { facilityId: number; ruleId: number } & ICreateOrUpdateOrdersProcessingRule = {
      facilityId: this.facility.id,
      ruleId: this.rule._id,
      name: this.conditionNamePipe.transform(event),
      action: this.rule.action,
      condition: { data: event },
    };

    this.store.dispatch(new FacilityOrdersProcessingActions.UpdateOrdersProcessingRule(data));
  }

  updateStatus(event: boolean): void {
    const data: { facilityId: number; ruleId: number } & ICreateOrUpdateOrdersProcessingRule = {
      facilityId: this.facility.id,
      ruleId: this.rule._id,
      status: event,
    };

    this.store.dispatch(new FacilityOrdersProcessingActions.UpdateOrdersProcessingRule(data));
  }

  private openSpecifyRuleResultModal(): void {
    this.modalV2Service
      .open(SpecifyRuleResultModalComponent, {
        listenBackdrop: false,
        data: {
          ...this.rule.action,
          groupId: this.facility.groupId,
        },
      })
      .subscribe((res) => {
        if (!res) {
          return;
        }

        const data: { facilityId: number; ruleId: number } & ICreateOrUpdateOrdersProcessingRule = {
          facilityId: this.facility.id,
          ruleId: this.rule._id,
          name: this.rule.name,
          action: { ...res, name: this.rule.action.name },
          condition: this.rule.condition,
        };

        this.store.dispatch(new FacilityOrdersProcessingActions.UpdateOrdersProcessingRule(data));
      });
  }

  private openSpecifyTagResultModal(): void {
    this.modalV2Service
      .open(SpecifyTagResultModalComponent, {
        listenBackdrop: false,
        data: {
          ...this.rule.action,
          groupId: this.facility.groupId,
        },
      })
      .subscribe((res) => {
        if (!res) {
          return;
        }

        const data: { facilityId: number; ruleId: number } & ICreateOrUpdateOrdersProcessingRule = {
          facilityId: this.facility.id,
          ruleId: this.rule._id,
          name: this.rule.name,
          action: { ...res, name: this.rule.action.name },
          condition: this.rule.condition,
        };

        this.store.dispatch(new FacilityOrdersProcessingActions.UpdateOrdersProcessingRule(data));
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
