import { ChangeDetectorRef, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import {
  ModalsV2Service,
  CONFIRM_POPUP_RESPONSE,
  ModalOverlayRef,
  ModalClass,
  modalAnimation,
  DEFAULT_CONFIRM_DATA,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ReadType } from '../../../../../../../../core/constants/constants';
import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../core/helpers/custom-validators';
import { OrdersService } from '../../../../../../../../core/http-services/orders.service';
import { IOption } from '../../../../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../../../../core/models/types/dictionary';
import { Select } from '../../../../../../../../shared/ui/components/controls/selects/select.class';
import { CptPopupV2Component } from '../../../../../../../../shared/ui/modules/select-cpt/components/cpt-popup-v2/cpt-popup-v2.component';
import { RULE_RESULT_ATTRIBUTE_OPTIONS, RULE_RESULT_ATTRIBUTE_VALUES } from '../../../utils/constants';

@Component({
  selector: 'app-specify-rule-result-modal',
  templateUrl: './specify-rule-result-modal.component.html',
  styleUrls: ['./specify-rule-result-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class SpecifyRuleResultModalComponent extends ModalClass implements OnInit {
  @ViewChild('valueSelector', { static: false }) valueSelector: Select;

  readonly ICONS = ICONS;
  readonly ATTRIBUTE_OPTIONS: IOption[] = RULE_RESULT_ATTRIBUTE_OPTIONS;
  readonly ATTRIBUTE_VALUES = RULE_RESULT_ATTRIBUTE_VALUES;

  readonly readTypeOptions: IOption[] = [
    {
      label: ReadType.Preliminary,
      value: ReadType.Preliminary,
    },
    {
      label: ReadType.Final,
      value: ReadType.Final,
    },
  ];
  preselectedCptOption = '';
  prioritiesOptions: IOption[] = [];
  orderStatusesListForProcessingRuleResult: IOption[] = [];
  form: UntypedFormGroup = null;
  selectedCpt: ICTPCode;
  groupId: number;

  constructor(
    private cdRef: ChangeDetectorRef,
    private ordersService: OrdersService,
    private modalsService: ModalsV2Service,
    public modalOverlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.preselectedCptOption = this.modalOverlayRef.data?.valueEntity?.name || '';
    this.groupId = this.modalOverlayRef.data?.groupId || null;

    this.form = new UntypedFormGroup({
      attribute: new UntypedFormControl(this.modalOverlayRef.data?.attribute || null, [CustomValidators.required]),
      value: new UntypedFormControl(this.modalOverlayRef.data?.value || null, [CustomValidators.required]),
    });

    !this.form.get('attribute').value && this.form.get('value').disable();

    this.form
      .get('attribute')
      .valueChanges.pipe(takeUntil(this.modalOverlayRef.beforeClosed()))
      .subscribe(() => {
        this.form.get('value').enable();
        this.form.get('value').reset();
        this.preselectedCptOption = null;
      });

    this.getPrioritiesList();
    this.getOrderStatusesListForProcessingRuleResult();

    this.modalOverlayRef.backdropClick
      .pipe(takeUntil(this.modalOverlayRef.beforeClosed()))
      .subscribe(() => this.closeAfterConfirm());
  }

  submit(): void {
    if (this.form.invalid) {
      this.modalsService.error('Fill up all required fields');

      return;
    }

    const selectedOption = this.valueSelector?.getSelectedOptions().pop();

    const valueEntity = [
      this.ATTRIBUTE_VALUES.priority,
      this.ATTRIBUTE_VALUES.status,
      this.ATTRIBUTE_VALUES.readType,
    ].includes(this.form.get('attribute').value)
      ? {
          id: selectedOption.value,
          name: selectedOption.label,
        }
      : {
          id: this.selectedCpt.id,
          name: this.selectedCpt.code + '-' + this.selectedCpt.shortName,
        };

    this.closeModal({
      ...this.form.value,
      valueEntity,
    });
  }

  openCptPopup(event: Event, withoutFiltering: boolean = false): void {
    (event.target as HTMLInputElement).blur();

    this.modalsService
      .open(CptPopupV2Component, {
        data: {
          groupId: this.groupId,
          isGlobalCptNeedToBeShown: true,
          searchWithoutFilters: withoutFiltering,
        },
      })
      .subscribe((res) => {
        if (res) {
          this.selectedCpt = res;
          this.preselectedCptOption = this.selectedCpt.code + '-' + this.selectedCpt.shortName;
          this.form.get('value').setValue(this.selectedCpt.id);
        }
      });
  }

  closeModal(data: any = null): void {
    this.result.emit(data);
    this.modalOverlayRef.close();
  }

  closeAfterConfirm(): void {
    if (!this.form.dirty) {
      this.closeModal();

      return;
    }

    this.modalsService
      .confirm(DEFAULT_CONFIRM_DATA)
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.cancel))
      .subscribe((result) => this.closeModal());
  }

  private getPrioritiesList(): void {
    this.ordersService
      .getPriorities()
      .pipe(takeUntil(this.modalOverlayRef.beforeClosed()))
      .subscribe((res) => {
        this.prioritiesOptions = res.data.map((p) => ({ value: p.id, label: p.name }));
      });
  }

  private getOrderStatusesListForProcessingRuleResult(): void {
    this.ordersService
      .getOrderStatusesListForProcessingRuleResult()
      .pipe(takeUntil(this.modalOverlayRef.beforeClosed()))
      .subscribe((res) => {
        this.orderStatusesListForProcessingRuleResult = res.data.map((p) => ({ value: p.id, label: p.name }));
      });
  }
}
