import { Component, OnInit, Input } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { Store } from '@ngxs/store';
import { debounceTime, Subject, takeUntil } from 'rxjs';

import { FacilityOrdersProcessingActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';

@Component({
  selector: 'app-order-processing-filter',
  templateUrl: './order-processing-filter.component.html',
  styleUrls: ['./order-processing-filter.component.scss'],
  standalone: false,
})
export class OrderProcessingFilterComponent implements OnInit {
  private readonly unsubscribe$$ = new Subject<void>();

  readonly form = this._formBuilder.group({
    id: [],
    condition: [],
    action: [],
    result: [],
  });

  @Input() facilityId: number;

  constructor(
    private readonly _formBuilder: UntypedFormBuilder,
    private readonly _store: Store
  ) {}

  ngOnInit(): void {
    this.form.valueChanges.pipe(takeUntil(this.unsubscribe$$), debounceTime(300)).subscribe((filter) => {
      this._store.dispatch(
        new FacilityOrdersProcessingActions.GetOrdersProcessing({ facilityId: this.facilityId, filter })
      );
    });
  }
}
