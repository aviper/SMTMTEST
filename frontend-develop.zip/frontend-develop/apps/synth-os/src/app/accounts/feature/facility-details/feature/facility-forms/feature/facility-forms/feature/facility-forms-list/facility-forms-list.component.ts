import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  input as fromQueryParameter,
  InputSignal,
  OnInit,
  Signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Actions, ofActionDispatched, Store } from '@ngxs/store';
import { Observable, of, switchMap } from 'rxjs';
import { filter } from 'rxjs/operators';

import { CONFIRM_POPUP_RESPONSE, ModalsV2Service } from '@synth/ui/modals';
import { IPagination, WeakPaginationStrategy } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../../core/constants/endpoints';
import { IRights, UserPermissions } from '../../../../../../../../../core/models/classes/userPermissions';
import { ISort } from '../../../../../../../../../core/models/types/common';
import {
  ICustomForm,
  ICustomFormDTO,
  ICustomFormsTableQuery,
} from '../../../../../../../../../core/models/types/custom-fields-and-forms';
import { IFacility } from '../../../../../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityFormsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-forms.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import {
  FACILITY_FORMS_DEFAULT_SORT,
  FacilityFormsState,
} from '../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-forms.state';
import { ProfileState } from '../../../../../../../../../profile/data-access/state/profile/profile.state';
import { FormBuilderService } from '../../../../../../../../../shared/data-access/services/create-form.service';
import { SettingsState } from '../../../../../../../../../shared/data-access/state/settings/settings.state';
import { ItemChangeEvent } from '../../../../../../../../../shared/ui/components/basic-table/basic-table.types';
import { CloneFacilityFormModalComponent } from '../../../../../../../../../shared/ui/components/clone-facility-form-modal/clone-facility-form-modal.component';
import { CustomFormsTableComponent } from '../../../../../../../../../shared/ui/components/custom-forms-table/custom-forms-table.component';
import { FACILITY_DETAILS_TABS } from '../../../../../../../../../shared/utils/constants';
import { FacilityFormsHeaderComponent } from '../../ui/facility-forms-header/facility-forms-header.component';

@Component({
  selector: 'synth-facility-forms',
  templateUrl: './facility-forms-list.component.html',
  styleUrls: ['./facility-forms-list.component.scss'],
  providers: [FormBuilderService],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CustomFormsTableComponent, FacilityFormsHeaderComponent],
})
export class FacilityFormsListComponent implements OnInit {
  readonly DEFAULT_SORT: ISort = FACILITY_FORMS_DEFAULT_SORT;
  readonly PaginationStrategy = new WeakPaginationStrategy();

  readonly id: InputSignal<number> = fromQueryParameter<number>();

  readonly permissions: Signal<UserPermissions> = this.store.selectSignal(ProfileState.permissions);
  readonly forms: Signal<ICustomForm[]> = this.store.selectSignal(FacilityFormsState.forms);
  readonly isLoading: Signal<boolean> = this.store.selectSignal(FacilityFormsState.isLoading);
  readonly granularLoadings: Signal<Record<string, boolean>> = this.store.selectSignal(
    FacilityFormsState.granularLoadings
  );
  readonly sort: Signal<ISort> = this.store.selectSignal(FacilityFormsState.sort);
  readonly pagination: Signal<IPagination> = this.store.selectSignal(FacilityFormsState.pagination);
  readonly facility: Signal<IFacility> = this.store.selectSignal(FacilityDetailsState.facility);
  readonly limit: Signal<number> = this.store.selectSignal(SettingsState.limit);
  readonly scrolledDistance: Signal<number> = this.store.selectSignal(FacilityFormsState.scrolledDistance);
  readonly query: Signal<ICustomFormsTableQuery> = this.store.selectSignal(FacilityFormsState.query);
  readonly rights: Signal<IRights> = computed(() => this.computeRights());

  constructor(
    private readonly store: Store,
    private readonly modalsService: ModalsV2Service,
    private readonly router: Router,
    private readonly destroyRef: DestroyRef,
    private readonly actions: Actions
  ) {
    this.actions.pipe(ofActionDispatched(FacilityFormsActions.ReloadForms), takeUntilDestroyed()).subscribe({
      next: () => {
        this.getFacilityForms();
      },
    });

    destroyRef.onDestroy(() => {
      this.store.dispatch(new FacilityFormsActions.ClearData());
    });
  }

  ngOnInit(): void {
    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.formBuilder }));
  }

  getFacilityForms(offset?: number): void {
    this.store.dispatch(
      new FacilityFormsActions.GetForms({
        id: this.id(),
        limit: this.limit(),
        offset,
      })
    );
  }

  handleSortChange(sort: ISort): void {
    this.store.dispatch(new FacilityFormsActions.UpdateSorting(sort));
  }

  handleInfinityScroll(offset: number): void {
    this.getFacilityForms(offset);
  }

  handleScrolledDistanceChange(scroll: number): void {
    this.store.dispatch(new FacilityFormsActions.UpdateScrolledDistance(scroll));
  }

  handleFormChange({ item, value, control, key }: ItemChangeEvent<ICustomForm>): void {
    const HANDLERS = {
      ifActive: () => this.handleStatusChange(item, value as boolean, control),
      isSync: () => this.handleSyncChange(item, control),
      placeInReport: () => this.handlePlaceInReportChange(item, value as string, control),
    };

    HANDLERS[key]?.call();
  }

  handleEditForm(form: ICustomForm): void {
    const facility = this.facility();

    if (!facility) {
      return;
    }

    const queryParams = {
      level: 'facility',
      facilityId: facility.id,
      facilityGroupId: facility.groupId,
      formId: form.id,
    };

    this.router.navigate(['/form-builder'], { queryParams }).then();
  }

  handleCloneForm(form: ICustomForm): void {
    const facility = this.facility();

    if (!facility) {
      return;
    }

    this.modalsService
      .open(CloneFacilityFormModalComponent, {
        data: {
          form,
          facilityGroupId: facility.groupId,
          facilityId: facility.id,
        },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.getFacilityForms());
  }

  handleDeleteForm(form: ICustomForm): void {
    this.modalsService
      .confirm({
        title: 'Delete',
        message: `Are you sure you want to delete this form ${form.name} ?`,
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new FacilityFormsActions.DeleteForm({
            id: form.id,
          })
        );
      });
  }

  handleQueryChange(query: ICustomFormsTableQuery): void {
    this.store.dispatch(new FacilityFormsActions.UpdateQuery(query));
  }

  private handleStatusChange(form: ICustomForm, ifActive: boolean, control: FormControl): void {
    const changeConfig = {
      emitViewToModelChange: false,
      emitModelToViewChange: true,
      emitEvent: false,
    };

    const revertIfActiveToggle: () => void = () => control.setValue(form.ifActive, changeConfig);

    if (!form.facilityId) {
      const facility = this.facility();

      this.store
        .dispatch(
          new FacilityFormsActions.EnableGlobalForm({ formId: form.id, facilityId: facility.id, enabled: ifActive })
        )
        .subscribe({
          error: () => revertIfActiveToggle(),
        });

      return;
    }

    of(form.clonesCount)
      .pipe(
        switchMap(() => {
          if (form.isSync) {
            return this.modalsService.confirm({
              title: 'Save changes',
              message: 'The changes will be saved to all of the copies of this form in other facilities',
              cancelButton: 'Cancel',
              confirmationButton: 'Save',
            });
          }

          return of(CONFIRM_POPUP_RESPONSE.submit);
        })
      )
      .subscribe({
        next: (result) => {
          if (result !== CONFIRM_POPUP_RESPONSE.submit) {
            revertIfActiveToggle();

            return;
          }

          this.updateForm({ ...form, ifActive }).subscribe({
            error: () => revertIfActiveToggle(),
          });
        },
      });
  }

  private handlePlaceInReportChange(form: ICustomForm, placeInReport: string, control: FormControl): void {
    const changeConfig = {
      emitViewToModelChange: false,
      emitModelToViewChange: true,
      emitEvent: false,
    };

    const revertPlaceInReportValue: () => void = () => control.setValue(form.placeInReport, changeConfig);

    of(form.clonesCount)
      .pipe(
        switchMap(() => {
          if (form.isSync) {
            return this.modalsService.confirm({
              title: 'Save changes',
              message: 'The changes will be saved to all of the copies of this form in other facilities',
              cancelButton: 'Cancel',
              confirmationButton: 'Save',
            });
          }

          return of(CONFIRM_POPUP_RESPONSE.submit);
        })
      )
      .subscribe({
        next: (result) => {
          if (result !== CONFIRM_POPUP_RESPONSE.submit) {
            revertPlaceInReportValue();

            return;
          }

          this.updateForm({ ...form, placeInReport }).subscribe({
            error: () => revertPlaceInReportValue(),
          });
        },
      });
  }

  private handleSyncChange(form: ICustomForm, control: FormControl): void {
    const changeConfig = {
      emitViewToModelChange: false,
      emitModelToViewChange: true,
      emitEvent: false,
    };

    const revertSyncToggle: () => void = () => control.setValue(form.isSync, changeConfig);

    this.modalsService
      .confirm({
        title: 'Disable sync',
        message:
          'Once synchronization is disabled, it will not be possible to synchronize this form again. Would you like to proceed?',
        cancelButton: 'Cancel',
        confirmationButton: 'Proceed',
      })
      .subscribe({
        next: (result) => {
          if (result !== CONFIRM_POPUP_RESPONSE.submit) {
            revertSyncToggle();

            return;
          }

          this.store.dispatch(new FacilityFormsActions.ToggleSync(form.id)).subscribe({
            error: () => revertSyncToggle(),
          });
        },
      });
  }

  private updateForm(form: ICustomForm): Observable<void> {
    form = this.mapFormRegions(form);

    const groupId = this.store.selectSnapshot(FacilityDetailsState.facility).groupId;

    const body: ICustomFormDTO = {
      ifActive: form.ifActive,
      name: form.name,
      modalitiesIds: form.modalities.map((modality) => modality.id),
      cptCodesIds: form.cptCodes.map((cptCode) => cptCode.id),
      placeInReport: form.placeInReport,
      regions: form.regions,
      groupId,
    };

    return this.store.dispatch(new FacilityFormsActions.UpdateForm({ formId: form.id, body }));
  }

  private mapFormRegions(form: ICustomForm): ICustomForm {
    return {
      ...form,
      regions: form.regions?.map((r) => r.name) || [],
    };
  }

  private computeRights(): IRights {
    const permissions = this.permissions();

    if (!permissions) {
      return {};
    }

    return permissions.rights(ACCOUNTS_ENDPOINTS.facilityFormsAndFields);
  }
}
