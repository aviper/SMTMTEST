import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { MODAL_ACTION_COMPLETE, ModalClass, ModalOverlayRef, modalAnimation } from '@synth/ui/modals';

import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { AlgorithmService } from '../../../../../core/http-services/algorithm.service';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { OrdersService } from '../../../../../core/http-services/orders.service';
import { IAlgorithm } from '../../../../../core/models/types/algorithm';
import { IItemResponse, IListResponse, IOption } from '../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../core/models/types/dictionary';

@Component({
  selector: 'app-create-algorithm-modal',
  templateUrl: './create-algorithm-modal.component.html',
  styleUrls: ['./create-algorithm-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class CreateAlgorithmModalComponent extends ModalClass implements OnInit {
  readonly CLOSE_ICONS = ICONS.close;

  algorithm: IAlgorithm;
  facilityGroupId: number;
  algorithmForm: UntypedFormGroup;

  isLoading = false;
  cptCodes: IOption[] = [];
  algorithmOptions: IOption[] = [
    {
      value: 'pneumothorax',
      label: 'Pneumothorax',
    },
    {
      value: 'intracranial_hemorrhage',
      label: 'Intracranial Hemorrhage',
    },
  ];

  constructor(
    private dictionaryService: DictionaryService,
    private algorithmService: AlgorithmService,
    private fb: UntypedFormBuilder,
    protected _cdRef: ChangeDetectorRef,
    public overlayRef: ModalOverlayRef,
    private readonly ordersService: OrdersService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(_cdRef, overlayRef, actionComplete$);
    this.facilityGroupId = this.overlayRef.data.facilityGroupId;
    this.algorithm = this.overlayRef.data.algorithm || null;
  }

  ngOnInit(): void {
    this.createForm();
  }

  private createForm(): void {
    const selectedCodes = this.algorithm ? this.algorithm.algorithmsCptCodes.map((item) => item.cptCode.id) : [];

    this.cptCodes = this.algorithm
      ? this.algorithm.algorithmsCptCodes.map((CPTCodeData) => this.getCPTCodeOptions(CPTCodeData.cptCode))
      : [];

    this.algorithmForm = this.fb.group({
      algorithm: [this.algorithm ? this.algorithm.name : null],
      cptCodes: [selectedCodes, CustomValidators.required],
      ageFrom: [
        this.algorithm ? this.algorithm.ageFrom : 0,
        [CustomValidators.numbersOnly, Validators.min(0), Validators.max(150), CustomValidators.required],
      ],
      ageTo: [
        this.algorithm ? this.algorithm.ageTo : 0,
        [CustomValidators.numbersOnly, Validators.min(0), Validators.max(150), CustomValidators.required],
      ],
    });

    if (this.algorithm) {
      this.algorithmForm.get('algorithm').disable();
    }
  }

  private getCPTCodeOptions(cptCode: ICTPCode): IOption {
    return {
      value: cptCode.id,
      label: `${cptCode.code} - ${cptCode.shortName}`,
    };
  }

  searchByCptCodes(query: string): void {
    if (!query) {
      return;
    }
    this.ordersService.getCPTCodes({ query }).subscribe((response: IListResponse) => {
      this.cptCodes = response.data.map((CPTCode) => this.getCPTCodeOptions(CPTCode));
    });
  }

  submit(): void {
    const afterUpdate$ = this.algorithm ? this.editAlgorithm() : this.createAlgorithm();

    this.isLoading = true;
    afterUpdate$.pipe(finalize(() => (this.isLoading = false))).subscribe(() => this.closeModal(true));
  }

  private createAlgorithm(): Observable<IItemResponse> {
    return this.algorithmService.saveAlgorithm({
      facilityGroupId: this.facilityGroupId,
      ...this.getFormValue(),
    });
  }

  private editAlgorithm(): Observable<IItemResponse> {
    return this.algorithmService.updateAlgorithm({
      id: this.algorithm.id,
      ...this.getFormValue(),
    });
  }

  private getFormValue(): any {
    return {
      ...this.algorithmForm.value,
      ageFrom: +this.algorithmForm.value.ageFrom,
      ageTo: +this.algorithmForm.value.ageTo,
    };
  }

  closeModal(reload?: any): void {
    this.result.emit(reload);
    this.overlayRef.close();
  }
}
