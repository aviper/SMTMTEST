import { Component, OnInit, ChangeDetectorRef, OnDestroy, ViewChild, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { OrdersNotificationsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Subject, Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { ModalsV2Service, modalAnimation, ModalOverlayRef, ModalClass, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { NOTIFICATION_TYPES } from '../../../../../core/constants/constants';
import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { IItemResponse } from '../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../core/models/types/dictionary';
import { IOrderNotification } from '../../../../../core/models/types/notification';
import { Select } from '../../../../../shared/ui/components/controls/selects/select.class';
import { CptPopupV2Component } from '../../../../../shared/ui/modules/select-cpt/components/cpt-popup-v2/cpt-popup-v2.component';

interface INotificationFromModel {
  name: string;
  content: string;
  type: string;
  modalityId: number | null;
  regions: number[];
  cptCodeId: number | null;
}

@Component({
  selector: 'app-add-notification-modal',
  templateUrl: './add-notification-modal.component.html',
  styleUrls: ['./add-notification-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddNotificationModalComponent extends ModalClass implements OnInit, OnDestroy {
  @ViewChild('regionSelect', { static: false }) regionSelect: Select;
  readonly ICONS = ICONS;

  readonly NOTIFICATION_TYPES = NOTIFICATION_TYPES;
  readonly TOOLTIPS = {
    alert: 'Alerts are shown in the OPS notes section AND displayed as a pop-up when the exam is opened',
    memo: 'Memos are displayed in the OPS notes section',
  };

  isAlert = true;
  isLoading = false;
  notificationForm: UntypedFormGroup;
  preselectedRegion = null;
  notification: IOrderNotification;
  selectedBodyRegions: string[] = [];
  selectedModality: string;
  selectedCptCodeWithModifier: string;
  regionId: number;
  groupId: number;

  private facilityId: number;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    private fb: UntypedFormBuilder,
    private modalsService: ModalsV2Service,
    private facilityService: FacilitiesService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.facilityId = this.modalOverlayRef.data.facilityId;
    this.groupId = this.modalOverlayRef.data.facilityGroupId;
    this.notification = this.modalOverlayRef.data.notification;
    this.createForm();
  }

  openCptPopup(event: Event, withoutFiltering: boolean = false): void {
    (event.target as HTMLInputElement).blur();

    this.modalsService
      .open(CptPopupV2Component, {
        data: {
          modalityId: this.notificationForm.value.modalityId,
          bodyRegionId: this.notificationForm.value.regions,
          facilityId: this.facilityId,
          fullRequest: true,
        },
      })
      .subscribe((res) => {
        if (res) {
          const cpt: ICTPCode = res;

          this.notificationForm.get('modalityId').setValue(cpt.modalityId);
          this.notificationForm.get('regions').setValue(cpt.bodyRegions?.map((el) => el.id) ?? []);
          this.notificationForm.get('cptCodeId').setValue(cpt.id);
          this.selectedBodyRegions = cpt.bodyRegions?.map((el) => el.region) ?? [];
          this.selectedModality = cpt.modality?.name || '';
          this.selectedCptCodeWithModifier = cpt.codeWithModifier;
        }
      });
  }

  closeModal(reload: boolean = false): void {
    this.result.emit({ reload });
    this.modalOverlayRef.close();
  }

  private afterChangeModality(modalityId: number): void {
    if (!this.preselectedRegion && this.notificationForm.get('cptCodeId')) {
      this.notificationForm.get('cptCodeId').reset();
      this.selectedModality = '';
      this.selectedCptCodeWithModifier = '';
    }

    if (modalityId) {
      this.preselectedRegion = null;
    }
  }

  private afterChangeRegion(regionIds: number | number[]): void {
    if (this.notificationForm.get('cptCodeId')) {
      if (regionIds) {
        if (!this.notificationForm.value.modalityId) {
          this.preselectedRegion = regionIds;
        }
      }
      this.notificationForm.get('cptCodeId').reset();
      this.selectedCptCodeWithModifier = null;
    }
    this.selectedBodyRegions = this.regionSelect?.selectedOptions.map((el) => el.label);
  }

  private createForm(): void {
    const model: INotificationFromModel = {
      name: this.notification?.name || '',
      content: this.notification?.content || '',
      type: this.notification?.type || this.NOTIFICATION_TYPES.alert,
      modalityId: this.notification?.modality?.id || null,
      regions: this.notification?.regions?.map((el) => el.id) || [],
      cptCodeId: this.notification?.cptCode?.id || null,
    };

    if (this.notification?.type === this.NOTIFICATION_TYPES.memo) {
      this.createMemoForm(model);
    } else {
      this.createAlertForm(model);
    }

    if (this.notification) {
      this.selectedBodyRegions = this.notification.regions?.map((el) => el.region);
      this.selectedModality = this.notification.modality?.name;
      this.selectedCptCodeWithModifier = this.notification.cptCode?.codeWithModifier;
    }
  }

  addNotification(): void {
    if (!this.notificationForm.dirty) {
      this.closeModal(false);

      return;
    }

    const body = {
      facilityId: this.facilityId,
      ...this.notificationForm.value,
      regions: this.selectedBodyRegions,
    };

    const request$: Observable<IItemResponse> = this.notification
      ? this.facilityService.updateNotification(this.notification.id, body, { autoNotifyErrors: false })
      : this.facilityService.createNotification(body, { autoNotifyErrors: false });

    request$.pipe(takeUntil(this.unsubscribe$$)).subscribe(
      () => this.closeModal(true),
      (error) => this.modalsService.error(error.message)
    );
  }

  private createAlertForm(model: INotificationFromModel): void {
    this.unsubscribe$$.next();
    this.isAlert = true;
    this.notificationForm = this.fb.group({
      name: [
        model.name,
        [
          CustomValidators.required,
          CustomValidators.patternInput(OrdersNotificationsPatterns.name.pattern),
          Validators.maxLength(OrdersNotificationsPatterns.name.maxLength),
        ],
      ],
      content: [
        model.content,
        [
          CustomValidators.required,
          CustomValidators.patternInput(OrdersNotificationsPatterns.content.pattern),
          Validators.maxLength(OrdersNotificationsPatterns.content.maxLength),
        ],
      ],
      type: [model.type || this.NOTIFICATION_TYPES.alert, [CustomValidators.required]],
      modalityId: [model.modalityId, [CustomValidators.required]],
      regions: [model.regions, [CustomValidators.required]],
      cptCodeId: [model.cptCodeId, [CustomValidators.required]],
    });

    this.initSubscriptions();
  }

  private createMemoForm(model: INotificationFromModel): void {
    this.unsubscribe$$.next();
    this.isAlert = false;
    this.notificationForm = this.fb.group({
      name: [
        model.name,
        [
          CustomValidators.required,
          CustomValidators.patternInput(OrdersNotificationsPatterns.name.pattern),
          Validators.maxLength(OrdersNotificationsPatterns.name.maxLength),
        ],
      ],
      content: [
        model.content,
        [
          CustomValidators.required,
          CustomValidators.patternInput(OrdersNotificationsPatterns.content.pattern),
          Validators.maxLength(OrdersNotificationsPatterns.content.maxLength),
        ],
      ],
      type: [model.type || this.NOTIFICATION_TYPES.alert, [CustomValidators.required]],
      modalityId: [model.modalityId, [CustomValidators.required]],
      regions: [model.regions],
      cptCodeId: [model.cptCodeId],
    });

    this.initSubscriptions();
  }

  initSubscriptions(): void {
    this.notificationForm
      .get('type')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((formValue) => {
        const model = {
          ...this.notificationForm.value,
          type: formValue,
        };

        if (formValue === this.NOTIFICATION_TYPES.alert) {
          this.createAlertForm(model);
        } else {
          this.createMemoForm(model);
        }
        this.notificationForm.markAsDirty();
      });

    this.notificationForm
      .get('modalityId')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((modalityId) => this.afterChangeModality(modalityId));

    this.notificationForm
      .get('regions')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((regionIds) => this.afterChangeRegion(regionIds));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
