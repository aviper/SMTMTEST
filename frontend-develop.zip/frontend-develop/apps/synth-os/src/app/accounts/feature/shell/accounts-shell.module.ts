import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { ModalsV2Module } from '@synth/ui/modals';

import { AccountsShellRoutingModule } from './accounts-shell-routing.module';
// import { CustomFieldsTableModule } from '../../../shared/ui/modules/custom-fields-table/custom-fields-table.module';
// import { DigitsInputComponent } from '../../../shared/ui/components/controls/digits-input/digits-input.component';
import { CurrentFormsTabModule } from '../../../exams/feature/exams-detail/feature/exam-tabs';
import { ActionsButtonDropdownComponentModule } from '../../../shared/ui/components/actions-button-dropdown/actions-button-dropdown.component';
import { OldCheckboxComponent } from '../../../shared/ui/components/controls/checkbox/checkbox/checkbox.component';
import { AppDatepickerComponent } from '../../../shared/ui/components/controls/datepicker/datepicker.component';
import { FormErrorV2Component } from '../../../shared/ui/components/controls/form-error-v2/form-error-v2.component';
import { OldInputComponent } from '../../../shared/ui/components/controls/input/input.component';
import { MaskInputComponent } from '../../../shared/ui/components/controls/mask-input/mask-input.component';
import { MaskPhoneInputComponent } from '../../../shared/ui/components/controls/mask-phone-input/mask-phone-input.component';
import { OldRadioButtonComponent } from '../../../shared/ui/components/controls/radio/radio-button/radio-button.component';
import { OldRadioGroupComponent } from '../../../shared/ui/components/controls/radio/radio-group/radio-group.component';
import { SearchFieldComponent } from '../../../shared/ui/components/controls/search-field/search-field.component';
import { AddressSelectV2Component } from '../../../shared/ui/components/controls/selects/address-select-v2/address-select-v2.component';
import { CategorySelectComponent } from '../../../shared/ui/components/controls/selects/category-select/category-select';
import { CitySelectComponent } from '../../../shared/ui/components/controls/selects/city-select.component/city-select.component';
import { ModalitySelectV2Component } from '../../../shared/ui/components/controls/selects/modality-select-v2/modality-select-v2.component';
import { RegionSelectV2Component } from '../../../shared/ui/components/controls/selects/region-select-v2/region-select-v2.component';
import { SelectComponent } from '../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../shared/ui/components/controls/switcher/switcher.component';
import { OldTextAreaComponent } from '../../../shared/ui/components/controls/text-area/text-area.component';
import { UploadFileAreaV2Component } from '../../../shared/ui/components/controls/upload-file-area-v2/upload-file-area-v2.component';
import { CustomFormRendererComponentModule } from '../../../shared/ui/components/custom-form-renderer/custom-form-renderer.module';
import { FileItemBlockComponentModule } from '../../../shared/ui/components/file-item-block/file-item-block.component';
import { FormErrorComponentModule } from '../../../shared/ui/components/form-error/form-error.component';
import { GoBackComponent } from '../../../shared/ui/components/go-back/go-back.component';
import { OldIconComponentModule } from '../../../shared/ui/components/icon/icon.component';
import { InfoComponentModule } from '../../../shared/ui/components/info/info.component';
import { InlineEditBlockV2ComponentModule } from '../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';
import { TableSettingsV2ComponentModule } from '../../../shared/ui/components/table-settings-v2/table-settings-v2.module';
import { CdkScrollableExtendedDirectiveModule } from '../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../shared/ui/directives/control-error-v2.directive';
import { ControlErrorDirectiveModule } from '../../../shared/ui/directives/control-error.directive';
import { NamedTemplateDirectiveModule } from '../../../shared/ui/directives/named-template/named-template.module';
import { StopPropagationDirectiveModule } from '../../../shared/ui/directives/stop-propagation.directive';
import { ButtonsModule } from '../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { LoaderModule } from '../../../shared/ui/modules/loader/loader.module';
import { MdePopoverModule } from '../../../shared/ui/modules/mde-popover';
import { SelectCptModule } from '../../../shared/ui/modules/select-cpt/select-cpt.module';
import { TabMenuModule } from '../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../shared/ui/modules/table/table.module';
import { TemplateSectionsFormModule } from '../../../shared/ui/modules/template-sections-form/template-sections-form.component';
import { AppDatePipeModule } from '../../../shared/ui/pipes/date.pipe';
import { IncludesPipeModule } from '../../../shared/ui/pipes/includes.pipe';
import { ObjectKeysPipeModule } from '../../../shared/ui/pipes/object-keys.pipe';
import { PhonePipeModule } from '../../../shared/ui/pipes/phone.pipe';
import { RegionsNamesPipeModule } from '../../../shared/ui/pipes/regions-names.pipe';
import { ACCOUNTS_UI } from '../../ui';
import { CreateFtpComponent } from '../../ui/create-ftp/create-ftp.component';
import { AccountsListComponent } from '../accounts-list/accounts-list.component';

@NgModule({
  declarations: [...ACCOUNTS_UI, AccountsListComponent],
  exports: [CreateFtpComponent],
  imports: [
    CommonModule,
    AccountsShellRoutingModule,
    ButtonsModule,
    TabMenuModule,
    TableModule,
    EllipsisTextModule,
    MdePopoverModule,
    OldIconComponentModule,
    LoaderModule,
    ReactiveFormsModule,
    FormsModule,
    ActionsButtonDropdownComponentModule,
    InlineEditBlockV2ComponentModule,
    MatTooltipModule,
    PhonePipeModule,
    CdkScrollableExtendedDirectiveModule,
    FormErrorComponentModule,
    ControlErrorDirectiveModule,
    TableSettingsV2ComponentModule,
    ModalsV2Module,
    InfiniteScrollModule,
    IncludesPipeModule,
    NamedTemplateDirectiveModule,
    CustomFormRendererComponentModule,
    DragDropModule,
    AppDatePipeModule,
    InfoComponentModule,
    A11yModule,
    ObjectKeysPipeModule,
    FileItemBlockComponentModule,
    RegionsNamesPipeModule,
    FormErrorV2Component,
    AppDatepickerComponent,
    SearchFieldComponent,
    MaskInputComponent,
    MaskPhoneInputComponent,
    OldRadioButtonComponent,
    OldRadioGroupComponent,
    OldTextAreaComponent,
    UploadFileAreaV2Component,
    OldSwitcherComponent,
    OldInputComponent,
    SelectComponent,
    AddressSelectV2Component,
    CategorySelectComponent,
    CitySelectComponent,
    ModalitySelectV2Component,
    RegionSelectV2Component,
    SelectCptModule,
    OldCheckboxComponent,
    ControlErrorV2DirectiveModule,
    StopPropagationDirectiveModule,
    TemplateSectionsFormModule,
    CurrentFormsTabModule,
    GoBackComponent,
  ],
})
export class AccountsShellModule {}
