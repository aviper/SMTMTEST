import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityFormsShellComponent } from './facility-forms-shell.component';

const routes: Routes = [
  {
    path: '',
    component: FacilityFormsShellComponent,
    children: [
      {
        path: '',
        redirectTo: 'forms',
        pathMatch: 'full',
      },
      {
        path: 'forms',
        loadChildren: () => import('../facility-forms/feature/shell/facility-forms-shell.routes').then((c) => c.ROUTES),
      },
      {
        path: 'fields',
        loadChildren: () =>
          import('../facility-fields/feature/shell/facility-fields-shell.routes').then((c) => c.ROUTES),
      },
      {
        path: 'builder',
        loadChildren: () =>
          import('../../../../../../../form-builder/shell/form-builder-shell.module').then(
            (c) => c.FormBuilderShellModule
          ),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FacilityFormsShellRoutingModule {}
