import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { GroupConnectionsShellRoutingModule } from './group-connections-shell-routing.module';
import { GroupConnectionsShellComponent } from './group-connections-shell.component';
import { ConnectionStatusTableModule } from '../../../../../../shared/ui/components/connection-status-table/connection-status-table.component';
import { OldSwitcherComponent } from '../../../../../../shared/ui/components/controls/switcher/switcher.component';
import { ExpansionBlockComponentModule } from '../../../../../../shared/ui/components/expansion-block/expansion-block.component';
import { LoaderModule } from '../../../../../../shared/ui/modules/loader/loader.module';
import { FacilityGroupGspsComponent } from '../../ui/facility-group-gsps/facility-group-gsps.component';

@NgModule({
  declarations: [GroupConnectionsShellComponent, FacilityGroupGspsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ExpansionBlockComponentModule,
    GroupConnectionsShellRoutingModule,
    ConnectionStatusTableModule,
    OldSwitcherComponent,
    LoaderModule,
  ],
})
export class GroupConnectionsShellModule {}
