import { Component, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { finalize, takeUntil } from 'rxjs/operators';

import { TIME_OPTIONS } from '../../../../../core/constants/constants';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { IOption } from '../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { AppDatePipe } from '../../../../../shared/ui/pipes/date.pipe';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-order-data-export',
  templateUrl: './group-order-data-export.component.html',
  styleUrls: ['./group-order-data-export.component.scss'],
  standalone: false,
})
export class GroupOrderDataExportComponent implements OnInit, OnDestroy {
  readonly AVAILABLE_TIME_OPTIONS = ['TODAY', 'YESTERDAY', 'LAST_3_DAYS', 'LAST_7_DAYS', 'THIS_MONTH', 'LAST_MONTH'];
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  isLoading = false;
  form: UntypedFormGroup;
  group: IFacilityGroup;
  fieldsOptions: IOption[] = [];

  readonly TIME_OPTIONS = Object.values(TIME_OPTIONS)
    .filter((option) => this.AVAILABLE_TIME_OPTIONS.includes(option.value))
    .map((opt) => ({
      label: opt.label,
      value: opt.value,
      dateEnd: opt.endDate().toISO(),
      dateStart: opt.startDate().toISO(),
    }));
  readonly DEFAULT_SELECTED_FIELDS = ['facilityGroup', 'facility', 'dos'];

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private fb: UntypedFormBuilder,
    private facilitiesService: FacilitiesService
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.orderDataExport }));

    this.form = this.fb.group(
      {
        facilityIds: [[]],
        dateStart: [null, [CustomValidators.required]],
        dateEnd: [null, [CustomValidators.required]],
        fields: [this.DEFAULT_SELECTED_FIELDS, [CustomValidators.required]],
      },
      { validators: [CustomValidators.dateRange('dateStart', 'dateEnd', { range: 'month' })] }
    );

    this.facilityGroup$.pipe(takeUntil(this.unsubscribe$$)).subscribe((fg) => (this.group = fg));

    this.getFieldsOptions();
  }

  getFieldsOptions(): void {
    this.facilitiesService
      .getOrderExportFields()
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((res) => {
        this.fieldsOptions = res.data;
        this.form.patchValue({
          fields: this.fieldsOptions.map((o) => o.value),
        });
      });
  }

  exportOrders(): void {
    this.isLoading = true;

    const body = this.form.value;

    this.facilitiesService
      .exportOrders(this.group.id, body)
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe((res) => {
        const csvBlob = new Blob([res], { type: 'text/csv' });
        const link = document.createElement('a');
        const fileName = [
          this.group.name,
          new AppDatePipe().transform(body.dateStart, { utc: true }),
          new AppDatePipe().transform(body.dateEnd, { utc: true }),
        ].join('_');

        link.href = window.URL.createObjectURL(csvBlob);
        link.download = `${fileName}.csv`;
        link.target = '_blank';
        link.click();
      });
  }

  selectTimePreset(option: { dateEnd: string; dateStart: string; label: string; value: string }): void {
    this.form.patchValue({
      dateStart: option.dateStart,
      dateEnd: option.dateEnd,
    });
  }

  resetForm(): void {
    this.form.reset({
      facilityIds: [],
      dateStart: null,
      dateEnd: null,
      fields: this.fieldsOptions.length ? this.fieldsOptions.map((o) => o.value) : this.DEFAULT_SELECTED_FIELDS,
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
