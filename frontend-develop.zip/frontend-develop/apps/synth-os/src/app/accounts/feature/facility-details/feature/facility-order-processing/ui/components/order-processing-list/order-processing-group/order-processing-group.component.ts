import { Component, inject, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';

import {
  IOrdersProcessingGroup,
  IOrdersProcessingModel,
  IOrdersProcessingRule,
  OrderProcessingConditionType,
} from '../../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingState } from '../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing.state';

@Component({
  selector: 'app-order-processing-group',
  templateUrl: './order-processing-group.component.html',
  styleUrls: ['./order-processing-group.component.scss'],
  standalone: false,
})
export class OrderProcessingGroupComponent implements OnInit, OnChanges, OnDestroy {
  private store: Store = inject(Store);
  readonly enabledAddRuleFormIndex$: Observable<number | null> = this.store.select(
    FacilityOrdersProcessingState.enabledAddRuleFormIndex
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isLoading);
  readonly isFiltering$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isFiltering);

  @Input() model: IOrdersProcessingModel;
  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() level = 1;

  isFiltering = false;
  isLoading = false;

  private readonly unsubscribe$$ = new Subject<void>();

  ngOnInit(): void {
    this.updateConditionType();

    this.isLoading$
      .pipe(distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((isLoading) => (this.isLoading = isLoading));

    this.isFiltering$
      .pipe(distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((isFiltering) => (this.isFiltering = isFiltering));
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.model) {
      !this.model.group.parentId && (this.conditionsType = []);
      this.updateConditionType();
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }

  private updateConditionType(): void {
    this.conditionsType = !!this.conditionsType.length ? this.conditionsType : this.getConditionType();
  }

  private getConditionType(): OrderProcessingConditionType[] {
    return this.getConditionContentType(this.model).filter((condition) => !!condition);
  }

  private getConditionContentType(data: IOrdersProcessingModel): OrderProcessingConditionType[] {
    switch (data.type) {
      case 'group':
        const parentGroup = data as IOrdersProcessingGroup;

        return [
          parentGroup.condition?.data?.[0]?.conditionType,
          ...(parentGroup.contain?.flatMap((item) => {
            switch (item.type) {
              case 'group':
                const group = item as IOrdersProcessingGroup;

                return this.getConditionContentType(group);
              case 'rule':
                const rule = item as IOrdersProcessingRule;

                return rule.condition?.data?.[0]?.conditionType;
            }
          }) || []),
        ];
      case 'rule':
        const rule = data as IOrdersProcessingRule;

        return [rule.condition?.data?.[0]?.conditionType];
    }
  }
}
