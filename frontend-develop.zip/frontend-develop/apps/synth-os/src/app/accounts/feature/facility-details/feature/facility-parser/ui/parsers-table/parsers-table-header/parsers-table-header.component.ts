import { Component } from '@angular/core';

@Component({
  selector: 'app-parsers-table-header',
  templateUrl: './parsers-table-header.component.html',
  styleUrls: ['./parsers-table-header.component.scss'],
  standalone: false,
})
export class ParsersTableHeaderComponent {}
