import { BillingDetailsBlockComponent } from './billing-details-block/billing-details-block.component';
import { CreateAlgorithmModalComponent } from './create-algorithm-modal/create-algorithm-modal.component';
import { DocumentTypeTableComponent } from './document-type-table/document-type-table.component';
import { FacilitiesHeaderComponent } from './facilities-header/facilities-header.component';
import { FacilitiesTableHeaderComponent } from './facilities-table/facilities-table-header/facilities-table-header.component';
import { FacilitiesTableRowComponent } from './facilities-table/facilities-table-row/facilities-table-row.component';
import { FacilitiesTableComponent } from './facilities-table/facilities-table.component';
import { FacilityGroupHeaderComponent } from './facility-group-header/facility-group-header.component';
import { FacilityGroupSettingsBlockComponent } from './facility-group-settings-block/facility-group-settings-block.component';
import { GroupDetailsBlockComponent } from './group-details-block/group-details-block.component';
import { GroupExamCodesHeaderComponent } from './group-exam-codes-header/group-exam-codes-header.component';
import { GroupPictureBlockComponent } from './group-picture-block/group-picture-block.component';
import { GroupUsersHeaderComponent } from './group-users-header/group-users-header.component';
import { NotesBlockComponent } from './notes-block/notes-block.component';

export const FACILITY_GROUP_DETAILS_UI_COMPONENTS: any[] = [
  NotesBlockComponent,
  GroupPictureBlockComponent,
  GroupDetailsBlockComponent,
  FacilityGroupSettingsBlockComponent,
  FacilityGroupHeaderComponent,
  BillingDetailsBlockComponent,
  CreateAlgorithmModalComponent,
  FacilitiesHeaderComponent,
  GroupUsersHeaderComponent,
  GroupExamCodesHeaderComponent,
  FacilitiesTableComponent,
  FacilitiesTableHeaderComponent,
  FacilitiesTableRowComponent,
  BillingDetailsBlockComponent,
  GroupDetailsBlockComponent,
  DocumentTypeTableComponent,
];
