import { AddOrderProcessingGroupOrSubgroupComponent } from './components/add-order-processing-group-subgroup/add-order-processing-group-subgroup.component';
import { CloneProcessingRulesModalComponent } from './components/clone-processing-rules-modal/clone-processing-rules-modal.component';
import { OrderProcessingAddRuleFormComponent } from './components/order-processing-list/order-processing-add-rule-form/order-processing-add-rule-form.component';
import { OrderProcessingConditionComponent } from './components/order-processing-list/order-processing-condition/order-processing-condition.component';
import { OrderProcessingFilterComponent } from './components/order-processing-list/order-processing-filter/order-processing-filter.component';
import { OrderProcessingGroupHeaderComponent } from './components/order-processing-list/order-processing-group/order-processing-group-header/order-processing-group-header.component';
import { OrderProcessingGroupComponent } from './components/order-processing-list/order-processing-group/order-processing-group.component';
import { OrderProcessingListHeaderComponent } from './components/order-processing-list/order-processing-header/order-processing-list-header.component';
import { OrderProcessingListComponent } from './components/order-processing-list/order-processing-list.component';
import { OrderProcessingRuleComponent } from './components/order-processing-list/order-processing-rule/order-processing-rule.component';
import { SpecifyConditionModalComponent } from './components/specify-condition-modal/specify-condition-modal.component';
import { SpecifyRuleResultModalComponent } from './components/specify-rule-result-modal/specify-rule-result-modal.component';
import { SpecifyTagResultModalComponent } from './components/specify-tag-result-modal/specify-tag-result-modal.component';
import { ErrorLogTabHeaderComponent } from './components/tabs/error-log-tab/error-log-tab-header/error-log-tab-header.component';
import { ErrorLogTabComponent } from './components/tabs/error-log-tab/error-log-tab.component';
import { ErrorsLogTabTableHeaderComponent } from './components/tabs/error-log-tab/errors-log-tab-table-header/errors-log-tab-table-header.component';
import { ErrorsLogTabTableRowComponent } from './components/tabs/error-log-tab/errors-log-tab-table-row/errors-log-tab-table-row.component';
import { RuleConfigurationTabHeaderComponent } from './components/tabs/rule-configuration-tab/rule-configuration-tab-header/rule-configuration-tab-header.component';
import { OrderConfigurationTabComponent } from './components/tabs/rule-configuration-tab/rule-configuration-tab.component';

export const ORDER_PROCESSING_UI: any[] = [
  AddOrderProcessingGroupOrSubgroupComponent,
  CloneProcessingRulesModalComponent,
  SpecifyConditionModalComponent,
  SpecifyRuleResultModalComponent,
  OrderProcessingListComponent,
  OrderProcessingRuleComponent,
  OrderProcessingListHeaderComponent,
  OrderProcessingGroupComponent,
  OrderProcessingGroupHeaderComponent,
  OrderProcessingFilterComponent,
  OrderProcessingConditionComponent,
  OrderProcessingAddRuleFormComponent,
  OrderConfigurationTabComponent,
  RuleConfigurationTabHeaderComponent,
  ErrorLogTabComponent,
  ErrorsLogTabTableRowComponent,
  ErrorsLogTabTableHeaderComponent,
  ErrorLogTabHeaderComponent,
  SpecifyTagResultModalComponent,
];
