import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { SHEETS_TYPES } from '../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { FgCptCodesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/fg-cpt-codes.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { FgCptCodesState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/fg-cpt-codes.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { UploadSheetsComponent } from '../../../../../shared/ui/components/upload-sheets/upload-sheets.component';
import { CreateStandardCptComponent } from '../../../../../shared/ui/modules/cpt-codes/cpt-code-modals/create-cpt-code/create-standard-cpt/create-standard-cpt.component';
import { FILTERS_STORAGE_PAGES } from '../../../../../shared/ui/modules/filters/constants/constants';
import { FiltersComponent } from '../../../../../shared/ui/modules/filters/filters.component';

@Component({
  selector: 'app-group-exam-codes-header',
  templateUrl: './group-exam-codes-header.component.html',
  styleUrls: ['./group-exam-codes-header.component.scss'],
  standalone: false,
})
export class GroupExamCodesHeaderComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly groupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);
  readonly query$: Observable<string> = this.store.select(FgCptCodesState.query);

  @ViewChild(FiltersComponent, { static: false }) filtersComp: FiltersComponent;

  readonly FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;
  readonly SHEETS_TYPES = SHEETS_TYPES;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  groupId: number = null;
  searchQuery = '';
  groupExamCodesPermissions: IPermissionsConfig = {
    canCreate: {
      [ACCOUNTS_ENDPOINTS.groupExamCodes]: false,
    },
  };

  private search$$: Subject<string> = new Subject<string>();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service,
    private dictionaryService: DictionaryService
  ) {}

  ngOnInit(): void {
    this.groupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((id) => (this.groupId = id));

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.groupExamCodesPermissions = PermissionsClass.updatePermissions(
          permissions,
          this.groupExamCodesPermissions
        );
      });

    this.query$.pipe(takeUntil(this.unsubscribe$$)).subscribe((query) => (this.searchQuery = query));

    this.search$$
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((query: string) => {
        this.store.dispatch(new FgCptCodesActions.SearchCptCodes(query));
        this.searchQuery = query;
      });
  }

  ngAfterViewInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        switchMap((permissions) => this.filtersComp.init(permissions)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.updateSelectedFilters(this.filtersComp.currentFilters);
      });
  }

  searchCpts(query: string): void {
    this.search$$.next(query);
  }

  updateSelectedFilters(selectedFilters: IFilterMapValue): void {
    this.store.dispatch(new FgCptCodesActions.UpdateCptFilters(selectedFilters));
  }

  openUploadModal(sheetType: string): void {
    this.modalsService
      .open(UploadSheetsComponent, {
        listenBackdrop: false,
        data: { type: sheetType, findingType: 'global', groupId: this.groupId },
      })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new FgCptCodesActions.Reload()));
  }

  openCreateCptModal(): void {
    this.modalsService
      .open(CreateStandardCptComponent, {
        listenBackdrop: false,
        data: {
          groupId: this.groupId,
          includeGlobalRegions: true,
        },
      })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new FgCptCodesActions.Reload()));
  }

  downloadGroupExamCodes(): void {
    const filters = this.store.selectSnapshot(FgCptCodesState.filters);
    const query = this.store.selectSnapshot(FgCptCodesState.query);

    this.dictionaryService
      .downloadExamCodes({
        groupId: this.groupId,
        ...filters,
        query,
      })
      .subscribe((res) => {
        const link = document.createElement('a');

        link.href = window.URL.createObjectURL(res.blob);
        link.download = res.fileName;
        link.target = '_blank';
        link.click();
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
