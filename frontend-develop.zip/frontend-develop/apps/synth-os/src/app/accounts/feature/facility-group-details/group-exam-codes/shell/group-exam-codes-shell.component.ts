import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngxs/store';

import { ITabMenuItem } from '../../../../../core/models/types/common';
import { TabMenuService } from '../../../../../core/services/tab-menu.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FgCptCodesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/fg-cpt-codes.actions';
import { FgModalitiesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/fg-modalities.actions';
import { FgRegionsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/fg-regions.actions';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-exam-codes-shell',
  templateUrl: './group-exam-codes-shell.component.html',
  styleUrls: ['./group-exam-codes-shell.component.scss'],
  standalone: false,
})
export class GroupExamCodesShellComponent implements OnInit, OnDestroy {
  cptTabs: ITabMenuItem[] = [];

  constructor(
    private store: Store,
    private route: ActivatedRoute,
    private tabMenuService: TabMenuService
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.cptCodes }));
    this.store.dispatch(new FacilityGroupDetailsActions.SetGroupId(+this.route.snapshot.parent.params['id']));
    this.getCptTabs();
  }

  private getCptTabs(): void {
    this.cptTabs = this.tabMenuService.getExamCodesTabs();
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FgCptCodesActions.ClearData());
    this.store.dispatch(new FgRegionsActions.ClearData());
    this.store.dispatch(new FgModalitiesActions.ClearData());
  }
}
