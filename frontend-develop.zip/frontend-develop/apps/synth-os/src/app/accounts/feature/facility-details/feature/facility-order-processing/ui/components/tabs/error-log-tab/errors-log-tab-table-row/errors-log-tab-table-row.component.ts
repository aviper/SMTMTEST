import { Component, EventEmitter, Input, Output } from '@angular/core';

import { IOrdersProcessingErrorsLog } from '../../../../../../../../../../core/models/types/orders-processing-errors-log';
import { ITableColumnWidth } from '../../../../../../../../../../core/models/types/tables';

@Component({
  selector: 'app-errors-log-tab-table-row',
  templateUrl: './errors-log-tab-table-row.component.html',
  styleUrls: ['./errors-log-tab-table-row.component.scss'],
  standalone: false,
})
export class ErrorsLogTabTableRowComponent {
  @Input() columnsWidth: ITableColumnWidth = {};
  @Input() item: IOrdersProcessingErrorsLog;
  @Output() resolvedChanged = new EventEmitter<boolean>();

  onResolvedChange(value: boolean): void {
    this.resolvedChanged.emit(value);
  }
}
