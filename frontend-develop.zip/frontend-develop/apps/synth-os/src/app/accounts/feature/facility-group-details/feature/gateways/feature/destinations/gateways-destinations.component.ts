import { ChangeDetectionStrategy, Component, DestroyRef, inject, Signal, OnInit, OnDestroy } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store } from '@ngxs/store';
import { take } from 'rxjs/operators';

import { DICOM_TYPES_LABELS, GatewayDestination } from '@synth/api';
import { IconWithAreaComponent } from '@synth/ui';
import { ModalsV2Service } from '@synth/ui/modals';
import { ICONS } from '@synth/utils';
import { WeakPaginationStrategy } from '@synth/utils/feature/pagination';

import { BasicTableActionsRefDirective } from '../../../../../../../shared/ui/components/basic-table/basic-table-actions-ref.directive';
import { BasicTableComponent } from '../../../../../../../shared/ui/components/basic-table/basic-table.component';
import {
  ColumnsConfig,
  ColumnType,
  ItemChangeEvent,
  SearchType,
} from '../../../../../../../shared/ui/components/basic-table/basic-table.types';
import { GatewaysDestinationsActions } from '../../data-access/gateways-destinations.actions';
import { GatewaysDestinationsState } from '../../data-access/gateways-destinations.state';
import { CreateEditGatewayDestinationModalComponent } from '../../ui/create-edit-gateway-destination-modal/create-edit-gateway-destination-modal.component';
import { GatewayDestinationDetailsCellComponent } from '../../ui/gateway-destination-details-cell/gateway-destination-details-cell.component';

@Component({
  selector: 'synth-gateways-destinations',
  templateUrl: './gateways-destinations.component.html',
  styleUrls: ['./gateways-destinations.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [BasicTableComponent, BasicTableActionsRefDirective, IconWithAreaComponent],
})
export class GatewaysDestinationsComponent implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly PAGINATION_STRATEGY = new WeakPaginationStrategy();
  readonly COLUMN_CONFIG: ColumnsConfig<GatewayDestination> = [
    {
      key: 'name',
      label: 'Name',
      type: ColumnType.text,
      width: 'grow',
      search: {
        type: SearchType.text,
        key: 'name',
        placeholder: '',
      },
      transform: (value) => value.name.toString(),
    },
    {
      key: 'type',
      label: 'Type',
      type: ColumnType.text,
      width: 'grow',
      transform: (value) => DICOM_TYPES_LABELS[value.type],
    },
    {
      key: 'configuration',
      label: 'Configuration',
      type: ColumnType.component,
      width: 130,
      component: GatewayDestinationDetailsCellComponent,
    },
    {
      key: 'isActive',
      label: 'Active',
      type: ColumnType.switcher,
      width: 100,
      editable: (field, isRowLoading) => !isRowLoading,
      transform: (value) => value.isActive,
    },
  ];

  private readonly store: Store = inject(Store);
  private readonly modalsService: ModalsV2Service = inject(ModalsV2Service);
  private readonly activatedRoute: ActivatedRoute = inject(ActivatedRoute);
  private readonly destroyRef: DestroyRef = inject(DestroyRef);

  readonly destinations: Signal<GatewayDestination[]> = this.store.selectSignal(GatewaysDestinationsState.destinations);
  readonly pagination: Signal<any> = this.store.selectSignal(GatewaysDestinationsState.pagination);
  readonly loading: Signal<boolean> = this.store.selectSignal(GatewaysDestinationsState.loading);
  readonly searchState: Signal<Record<string, string | string[]>> = this.store.selectSignal(
    GatewaysDestinationsState.searchState
  );
  readonly limit: Signal<number> = this.store.selectSignal(GatewaysDestinationsState.limit);
  readonly granularLoadings: Signal<Record<string, boolean>> = this.store.selectSignal(
    GatewaysDestinationsState.granularLoadings
  );

  ngOnInit(): void {
    this.activatedRoute.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((paramMap: ParamMap) => {
      const facilityGroupId = parseInt(paramMap.get('id'), 10);

      this.store.dispatch(new GatewaysDestinationsActions.Init(facilityGroupId));
      this.store.dispatch(new GatewaysDestinationsActions.Get());
    });
  }

  handleInfinityScroll(offset: number): void {
    this.store.dispatch(new GatewaysDestinationsActions.Paginate(offset));
  }

  handleQueryChange(query: Record<string, string | string[]>): void {
    this.store.dispatch(new GatewaysDestinationsActions.Search(query));
  }

  handleDestinationChange(event: ItemChangeEvent<GatewayDestination>): void {
    if (event.key === 'isActive') {
      const changeConfig = {
        emitEvent: false,
        emitViewToModelChange: false,
        emitModelToViewChange: true,
      };

      this.store
        .dispatch(
          new GatewaysDestinationsActions.UpdateStatus({ destination: event.item, isActive: event.value as boolean })
        )
        .pipe(take(1), takeUntilDestroyed(this.destroyRef))
        .subscribe({
          error: () => {
            event.control.setValue(event.item.isActive, changeConfig);
          },
        });
    }
  }

  handleEditDestination(destination: GatewayDestination): void {
    this.modalsService.open(CreateEditGatewayDestinationModalComponent, {
      data: { destination: destination },
      listenBackdrop: false,
    });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new GatewaysDestinationsActions.ClearData());
  }
}
