import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityPatientsComponent } from './facility-patients.component';
import { PatientsTableModule } from '../../../../../shared/ui/modules/patients-table/patients-table.module';

const routes: Routes = [
  {
    path: '',
    component: FacilityPatientsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class FacilityPatientsRoutingModule {}

@NgModule({
  declarations: [FacilityPatientsComponent],
  imports: [CommonModule, FacilityPatientsRoutingModule, PatientsTableModule],
})
export class FacilityPatientsModule {}
