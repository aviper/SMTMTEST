import { AsyncPipe, NgClass, NgIf } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, signal, WritableSignal } from '@angular/core';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { SearchFieldComponent } from '@synth/ui';
import { PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { GroupTagsAndTasksTableRowComponent } from './group-tags-and-tsks-table-row/group-tags-and-tasks-table-row.component';
import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS, ORDERS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { IPermissionsConfig, PermissionsClass } from '../../../../../../core/helpers/permissions.class';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { IOption, ISort } from '../../../../../../core/models/types/common';
import { FacilityGroupDetailsState } from '../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../../shared/data-access/state/settings/settings.state';
import { OldIconComponentModule } from '../../../../../../shared/ui/components/icon/icon.component';
import { LoaderModule } from '../../../../../../shared/ui/modules/loader/loader.module';
import { TableModule } from '../../../../../../shared/ui/modules/table/table.module';
import { ITableLoaderConfig } from '../../../../../../shared/ui/modules/table/true-table/true-table.component';
import { GroupTagsAndTasksActions } from '../../data-access/group-tags-and-tasks.actions';
import { GroupTagsAndTasksState } from '../../data-access/group-tags-and-tasks.state';
import { CONFIDENTIAL_OPTIONS, ENDPOINT_ADAPTER } from '../../utils/constants';
import { CreateTagAndTaskComponent } from '../create-tag-and-task/create-tag-and-task.component';

@Component({
  selector: 'synth-group-tags-and-tasks-table',
  templateUrl: './group-tags-and-tasks-table.component.html',
  styleUrls: ['./group-tags-and-tasks-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    NgIf,
    NgClass,
    TableModule,
    AsyncPipe,
    LoaderModule,
    OldIconComponentModule,
    SearchFieldComponent,
    CreateTagAndTaskComponent,
    GroupTagsAndTasksTableRowComponent,
  ],
})
export class GroupTagsAndTasksTableComponent implements OnInit, OnDestroy {
  readonly LOADERS_CONFIG: ITableLoaderConfig = {
    rowsConfig: [30, 20, 30, 8, 8, 4],
    smallAmount: 2,
    defaultAmount: 5,
    responsive: true,
  };
  readonly facilityGroupId$ = this.store.select(FacilityGroupDetailsState.facilityGroupId);
  readonly isLoading$ = this.store.select(GroupTagsAndTasksState.isLoading);
  readonly pagination$ = this.store.select(GroupTagsAndTasksState.pagination);
  readonly groupTagsAndTasks$ = this.store.select(GroupTagsAndTasksState.groupTagsAndTasks);
  readonly permissions$ = this.store.select(ProfileState.permissions);
  readonly sort$ = this.store.select(GroupTagsAndTasksState.sort);
  readonly ORDERS_ENDPOINTS = ORDERS_ENDPOINTS;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;
  readonly DEFAULT_SORTING = { direction: 'asc', sortField: 'name' };
  readonly searchState: WritableSignal<{ name: string; confidentiality: string; oprRules: string }> = signal({
    name: '',
    confidentiality: '',
    oprRules: '',
  });

  confidentialOptions: IOption[] = CONFIDENTIAL_OPTIONS;
  readonly ENDPOINT_ADAPTER = ENDPOINT_ADAPTER;
  readonly PaginationStrategiesNames = PaginationStrategiesNames;
  readonly CONFIDENTIALITY_ENDPOINTS = [
    ORDERS_ENDPOINTS.openTagsTasks,
    ORDERS_ENDPOINTS.secretTagsTasks,
    ORDERS_ENDPOINTS.confidentialTagsTasks,
  ];

  limit = DEFAULT_LIMIT;
  deleteTagsTasksPermissions: { [key: string]: boolean } = {
    [ORDERS_ENDPOINTS.openTagsTasks]: false,
    [ORDERS_ENDPOINTS.secretTagsTasks]: false,
    [ORDERS_ENDPOINTS.confidentialTagsTasks]: false,
    personal: true, // always permited
  };
  editTagsTasksPermissions: { [key: string]: boolean } = {
    [ORDERS_ENDPOINTS.openTagsTasks]: false,
    [ORDERS_ENDPOINTS.secretTagsTasks]: false,
    [ORDERS_ENDPOINTS.confidentialTagsTasks]: false,
    personal: true, // always permited
  };

  facilityGroupTagsAndTasksPermissions: IPermissionsConfig = {
    canCreate: {
      [ACCOUNTS_ENDPOINTS.groupTagsAndTasks]: false,
    },
    canEdit: {
      [ACCOUNTS_ENDPOINTS.groupTagsAndTasks]: false,
    },
    canDelete: {
      [ACCOUNTS_ENDPOINTS.groupTagsAndTasks]: false,
    },
  };

  private readonly unsubscribe$$ = new Subject<void>();

  constructor(private readonly store: Store) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.facilityGroupId$
      .pipe(
        filter((id) => !!id),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe({
        next: (id: number) => {
          this.store.dispatch(new GroupTagsAndTasksActions.SetParams({ facilityGroupId: id, limit: this.limit }));
        },
      });

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.facilityGroupTagsAndTasksPermissions = PermissionsClass.updatePermissions(
          permissions,
          this.facilityGroupTagsAndTasksPermissions
        );

        this.CONFIDENTIALITY_ENDPOINTS.forEach((endpoint) => {
          this.deleteTagsTasksPermissions[endpoint] = permissions.canDelete(endpoint);
          this.editTagsTasksPermissions[endpoint] = permissions.canEdit(endpoint);
        });

        this.confidentialOptions = [
          ...CONFIDENTIAL_OPTIONS.filter((option: IOption) =>
            permissions.canCreate(this.ENDPOINT_ADAPTER[option.value])
          ),
          { value: 'Personal', label: 'Personal' },
        ];
      });
  }

  applySort(sort: ISort): void {
    this.store.dispatch(new GroupTagsAndTasksActions.ResetPagination());
    this.store.dispatch(new GroupTagsAndTasksActions.SetSorting({ sort }));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(new GroupTagsAndTasksActions.PaginateGroupTagsAndTasks(offset));
  }

  searchByColumn(value: string, key: string): void {
    this.searchState.update((state) => ({ ...state, [key]: value }));
    this.store.dispatch(new GroupTagsAndTasksActions.ResetPagination());
    this.store.dispatch(new GroupTagsAndTasksActions.SetSearchConfig({ searchConfig: this.searchState() }));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new StateReset(GroupTagsAndTasksState));
  }
}
