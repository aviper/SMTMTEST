import { AfterViewInit, Component, NgZone, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';

import { IPagination } from '@synth/utils/feature/pagination';

import { FACILITY_GROUP_TABS } from '../../../../../core/constants/constants';
import { ISort } from '../../../../../core/models/types/common';
import { IUser } from '../../../../../core/models/types/user';
import { TemplateService } from '../../../../../core/services/template.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupUsersActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facility-group-users.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { FacilityGroupUsersState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/facility-group-users.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';

@Component({
  selector: 'app-group-users',
  templateUrl: './group-users.component.html',
  styleUrls: ['./group-users.component.scss'],
  standalone: false,
})
export class GroupUsersComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly users$: Observable<IUser[]> = this.store.select(FacilityGroupUsersState.users);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityGroupUsersState.isLoading);
  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);
  readonly pagination$: Observable<IPagination> = this.store.select(FacilityGroupUsersState.pagination);
  readonly sort$: Observable<ISort> = this.store.select(FacilityGroupUsersState.sort);

  @ViewChild('header', { static: false }) headerTemplate: TemplateRef<any>;

  limit: number;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private zone: NgZone,
    private templateService: TemplateService
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.employee }));

    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new FacilityGroupUsersActions.SetLimit({ limit: this.limit }));

    this.facilityGroupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((groupId) => {
      if (groupId) {
        this.store.dispatch(new FacilityGroupUsersActions.GetGroupUsers({ id: groupId }));
      }
    });
  }

  ngAfterViewInit(): void {
    this.zone.onStable.pipe(take(1)).subscribe(() => this.templateService.setTemplateRef(this.headerTemplate));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new FacilityGroupUsersActions.UpdatePagination({
        offset: offset,
      })
    );
  }

  sortEmployees(sort: ISort): void {
    this.store.dispatch(new FacilityGroupUsersActions.UpdateSorting(sort));
  }

  ngOnDestroy(): void {
    this.templateService.setTemplateRef(null);
    this.store.dispatch(new FacilityGroupUsersActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
