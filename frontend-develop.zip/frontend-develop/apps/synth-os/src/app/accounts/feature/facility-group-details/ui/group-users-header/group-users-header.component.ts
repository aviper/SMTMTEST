import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

import { FacilityGroupUsersActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facility-group-users.actions';
import { FacilityGroupUsersState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/facility-group-users.state';

@Component({
  selector: 'app-group-users-header',
  templateUrl: './group-users-header.component.html',
  styleUrls: ['./group-users-header.component.scss'],
  standalone: false,
})
export class GroupUsersHeaderComponent implements OnInit, OnDestroy {
  readonly query$: Observable<string> = this.store.select(FacilityGroupUsersState.query);

  private search$$: Subject<string> = new Subject<string>();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.search$$
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((query: string) => {
        this.store.dispatch(new FacilityGroupUsersActions.UpdateQuery(query));
      });
  }

  searchUsers(query: string): void {
    this.search$$.next(query);
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
