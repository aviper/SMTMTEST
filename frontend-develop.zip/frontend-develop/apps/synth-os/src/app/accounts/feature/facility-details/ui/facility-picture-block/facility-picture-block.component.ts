import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ALLOWED_PICTURE_TYPES_AVATAR } from '../../../../../core/constants/constants';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IFacility } from '../../../../../core/models/types/facility';
import { FileProxyService } from '../../../../../core/services/file-proxy.service';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { SynthDateWrapper } from '../../../../../core/wrappers/synth-date-wrapper';

@Component({
  selector: 'app-facility-picture-block',
  templateUrl: './facility-picture-block.component.html',
  styleUrls: ['./facility-picture-block.component.scss'],
  standalone: false,
})
export class FacilityPictureBlockComponent implements OnInit, OnDestroy {
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityDetailsState.isLoading);

  readonly ICONS = ICONS;

  facility: IFacility;
  isLoading = false;
  logoUrl: string;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsV2Service: ModalsV2Service,
    private fileProxy: FileProxyService
  ) {}

  ngOnInit(): void {
    this.facility$
      .pipe(
        filter((facility) => !!facility?.id),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility: IFacility) => {
        this.facility = facility;

        if (this.facility.logo?.id) {
          this.logoUrl = this.getLogo(this.facility.logo.id);
        } else {
          this.logoUrl = null;
        }
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((loading: boolean) => (this.isLoading = loading));
  }

  private getLogo(fileId: number): string {
    return this.fileProxy.getLogoByFileId(fileId) + `&timestamp=${+SynthDateWrapper.now(true)}`;
  }

  uploadFacilityPicture(event: Event): void {
    const uploadedFiles = [].slice.call(event.target['files']);
    const oldLogoId = this.facility.logo?.id.toString() || null;

    if (!uploadedFiles.length) {
      return;
    }

    if (this.isUploadedPicturesAllowed(uploadedFiles)) {
      this.store.dispatch(
        new FacilityDetailsActions.UpdateFacilityPicture({
          file: uploadedFiles[0],
          facilityName: this.facility.name,
          oldLogoId,
        })
      );
    } else {
      this.modalsV2Service.error('Not allowed picture type');
    }
  }

  deleteFacilityPicture(): void {
    this.store.dispatch(
      new FacilityDetailsActions.DeleteFacilityPicture({
        fileId: this.facility.logo.id,
      })
    );
  }

  private isUploadedPicturesAllowed(uploadedPictures: File[]): boolean {
    return uploadedPictures.every((uploadedPicture: File) => {
      const pictureType = uploadedPicture.type.split('/');

      return Boolean(ALLOWED_PICTURE_TYPES_AVATAR.indexOf(pictureType[pictureType.length - 1]) !== -1);
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
