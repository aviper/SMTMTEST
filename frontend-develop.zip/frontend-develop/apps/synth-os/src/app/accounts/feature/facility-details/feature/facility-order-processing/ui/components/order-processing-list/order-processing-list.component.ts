import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, inject, Input, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, take, takeUntil } from 'rxjs';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../../../../core/models/classes/userPermissions';
import {
  IOrdersProcessingModel,
  IOrdersProcessingPriority,
  OrderProcessingConditionType,
} from '../../../../../../../../core/models/types/orders-processing';
import { FacilityOrdersProcessingActions } from '../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityOrdersProcessingState } from '../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing.state';
import { ProfileState } from '../../../../../../../../profile/data-access/state/profile/profile.state';
import { ROOT_GROUP_FORM_INDEX } from '../../../utils/types';

@Component({
  selector: 'app-order-processing-list',
  templateUrl: './order-processing-list.component.html',
  styleUrls: ['./order-processing-list.component.scss'],
  standalone: false,
})
export class OrderProcessingListComponent implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);

  readonly isPrioritizing$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isPrioritizing);
  readonly isFiltering$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isFiltering);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly enabledAddRuleFormIndex$: Observable<number | null> = this.store.select(
    FacilityOrdersProcessingState.enabledAddRuleFormIndex
  );
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  @Input() items: IOrdersProcessingModel[];
  @Input() hasHeader = false;
  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() level = 0;

  canAdd = false;
  canDelete = false;
  isFiltering = false;
  isPrioritizing = false;
  facilityId: number;

  readonly ROOT_GROUP_FORM_INDEX = ROOT_GROUP_FORM_INDEX;

  private readonly unsubscribe$$ = new Subject<void>();

  trackBy = (_: number, item: IOrdersProcessingModel) => item?._id;

  constructor(private readonly _store: Store) {}

  ngOnInit(): void {
    this.facilityId$
      .pipe(
        takeUntil(this.unsubscribe$$),
        filter((facilityId) => !!facilityId)
      )
      .subscribe((facilityId) => (this.facilityId = facilityId));

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.canDelete = permissions.canDelete(ACCOUNTS_ENDPOINTS.orderProcessing);
        this.canAdd = permissions.canCreate(ACCOUNTS_ENDPOINTS.orderProcessing);
      });

    this.isPrioritizing$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((isPrioritizing) => (this.isPrioritizing = isPrioritizing));

    this.isFiltering$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isFiltering) => (this.isFiltering = isFiltering));
  }

  listDropped(event: CdkDragDrop<any>): void {
    if (event.previousContainer === event.container && event.previousIndex !== event.currentIndex) {
      const data = [...event.container.data] as IOrdersProcessingModel[];

      moveItemInArray(data, event.previousIndex, event.currentIndex);

      const prioritization = data.map((item, index) => {
        switch (item.type) {
          case 'group':
            return {
              type: 'group',
              _id: item.group._id,
              parentId: item.group.parentId,
              priority: index + 1,
            } as IOrdersProcessingPriority;
          case 'rule':
            return {
              type: 'rule',
              _id: item.rule._id,
              orderProcessingGroupsId: item.rule.orderProcessingGroupsId,
              priority: index + 1,
            } as IOrdersProcessingPriority;
        }
      });

      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);

      this._store
        .dispatch(
          new FacilityOrdersProcessingActions.PrioritizeOrdersProcessingRulesAndGroups({
            facilityId: this.facilityId,
            data: prioritization,
          })
        )
        .pipe(take(1))
        .subscribe({
          error: () => {
            moveItemInArray(event.container.data, event.currentIndex, event.previousIndex);
          },
        });
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
