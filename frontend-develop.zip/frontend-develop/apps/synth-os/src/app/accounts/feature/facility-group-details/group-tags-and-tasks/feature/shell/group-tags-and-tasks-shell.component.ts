import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';

import { FacilityGroupDetailsActions } from '../../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FACILITY_GROUP_TABS } from '../../../../../utils/constants';
import { GroupTagsAndTasksTableComponent } from '../group-tags-and-tasks-table/group-tags-and-tasks-table.component';

@Component({
  selector: 'app-group-tags-and-tasks-shell',
  templateUrl: './group-tags-and-tasks-shell.component.html',
  imports: [GroupTagsAndTasksTableComponent],
})
export class GroupTagsAndTasksShellComponent implements OnInit {
  constructor(private readonly store: Store) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.groupTagsAndTasks }));
  }
}
