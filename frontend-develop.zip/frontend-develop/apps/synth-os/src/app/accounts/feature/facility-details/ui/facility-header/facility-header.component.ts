import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IFacility } from '../../../../../core/models/types/facility';
import { RoutingService } from '../../../../../core/services/routing.service';
import { FacilityDepartmentsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/departments.actions';
import { FacilityOrderNotificationActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-order-notification.actions';
import { FacilityPatientsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-patients.actions';
import { FacilityRadiologistsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-radiologists.actions';
import { FacilityUsersActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-users.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { FILTERS_STORAGE_PAGES } from '../../../../../shared/ui/modules/filters/constants/constants';
import { FACILITY_DETAILS_TABS } from '../../../../../shared/utils/constants';
import { AddDepartmentComponent } from '../../../../ui/add-department/add-department.component';
import { AddContactModalComponent } from '../add-contact-modal/add-contact-modal.component';
import { AddNotificationModalComponent } from '../add-notification-modal/add-notification-modal.component';

@Component({
  selector: 'app-facility-header',
  templateUrl: './facility-header.component.html',
  styleUrls: ['./facility-header.component.scss'],
  standalone: false,
})
export class FacilityHeaderComponent implements OnInit, OnDestroy {
  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);
  readonly selectedTab$: Observable<string> = this.store.select(FacilityDetailsState.selectedTab);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly ICONS = ICONS;
  readonly FACILITY_DETAILS_TABS = FACILITY_DETAILS_TABS;
  readonly FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;
  private readonly tabsWithSearch = [
    FACILITY_DETAILS_TABS.radiologists,
    FACILITY_DETAILS_TABS.patients,
    FACILITY_DETAILS_TABS.users,
    FACILITY_DETAILS_TABS.departments,
  ];

  facility: IFacility;
  searchQuery = '';
  searchPlaceholder = '';
  searchAvailable = false;
  selectedTab: string;
  pagination: IPagination = { ...PAGINATION };
  previousRoute = '';
  limit: number;
  canCreateFormsFields = false;

  private search$$: Subject<string> = new Subject();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsV2Service: ModalsV2Service,
    private router: Router,
    private routingService: RoutingService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.previousRoute = this.routingService.getPreviousUrl();
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.facility$
      .pipe(
        filter((data) => data !== null),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.facility = response;
      });

    this.search$$.pipe(debounceTime(500), takeUntil(this.unsubscribe$$)).subscribe((query: string) => {
      this.searchQuery = query;

      switch (this.selectedTab) {
        case FACILITY_DETAILS_TABS.departments: {
          this.store.dispatch(new FacilityDepartmentsActions.UpdateSearchQuery({ query }));
          break;
        }

        case FACILITY_DETAILS_TABS.radiologists: {
          this.store.dispatch(new FacilityRadiologistsActions.UpdateSearchQuery({ query }));
          break;
        }

        case FACILITY_DETAILS_TABS.users: {
          this.store.dispatch(new FacilityUsersActions.UpdateSearchQuery({ query }));
          break;
        }

        case FACILITY_DETAILS_TABS.patients: {
          this.store.dispatch(new FacilityPatientsActions.UpdateSearchQuery({ query }));
          break;
        }
      }
    });

    this.selectedTab$.pipe(takeUntil(this.unsubscribe$$)).subscribe((tab) => {
      this.selectedTab = tab;
      this.searchQuery = '';

      if (this.tabsWithSearch.includes(tab)) {
        this.searchAvailable = true;
        this.searchPlaceholder = this.getSearchFieldPlaceholder(tab);
      } else {
        this.searchAvailable = false;
      }
    });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (permissions) => (this.canCreateFormsFields = permissions.canCreate(ACCOUNTS_ENDPOINTS.facilityFormsAndFields))
      );
  }

  search(query: string): void {
    this.search$$.next(query);
  }

  back(): void {
    if (this.facility.groupId) {
      this.router.navigateByUrl(`/accounts/groups/${this.facility.groupId}`);

      return;
    }

    const route =
      this.previousRoute && this.routingService.getCurrentUrl() === this.previousRoute
        ? '/accounts'
        : this.previousRoute;

    if (!route) {
      this.location.back();
    }

    this.router.navigateByUrl(route);
  }

  openAddDepartmentsModal(): void {
    this.modalsV2Service
      .createModal(AddDepartmentComponent, { data: { id: this.facility.id } })
      .result.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((reload: boolean) => {
        if (reload) {
          this.store.dispatch(
            new FacilityDepartmentsActions.GetFacilityDepartments({
              offset: this.pagination.offset,
            })
          );
        }
      });
  }

  openAddNotificationModal(): void {
    this.modalsV2Service
      .createModal(AddNotificationModalComponent, {
        data: {
          facilityId: this.facility.id,
          groupId: this.facility.groupId,
        },
      })
      .result.pipe(takeUntil(this.unsubscribe$$))
      .subscribe(
        (res: boolean) =>
          res &&
          this.store.dispatch(
            new FacilityOrderNotificationActions.GetNotifications({
              id: this.facility.id,
              limit: this.limit,
              offset: this.pagination.offset,
            })
          )
      );
  }

  openAddContactModal(): void {
    this.modalsV2Service.open(AddContactModalComponent, {
      data: { facilityId: this.facility.id },
    });
  }

  getSearchFieldPlaceholder(placeholder: string): string {
    switch (placeholder) {
      case FACILITY_DETAILS_TABS.formBuilder:
        return 'Search by ID, Name, Modality, Region or Exam code.';
      case FACILITY_DETAILS_TABS.fieldBuilder:
        return 'Search by Field Name, Display Name, Category.';
      default:
        return `Search ${placeholder}...`;
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
