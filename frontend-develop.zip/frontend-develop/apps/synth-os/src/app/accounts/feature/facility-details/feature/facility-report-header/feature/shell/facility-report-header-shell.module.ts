import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FacilityReportHeaderShellComponent } from './facility-report-header-shell.component';
import { ReportPreviewModule } from '../../../../../../../shared/ui/modules/report-preview/report-preview.module';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: FacilityReportHeaderShellComponent,
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FacilityReportHeaderShellRoutingModule {}

@NgModule({
  declarations: [FacilityReportHeaderShellComponent],
  imports: [CommonModule, ReportPreviewModule, FacilityReportHeaderShellRoutingModule],
})
export class FacilityReportHeaderShellModule {}
