import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject } from '@angular/core';
import { SOP_CLASSES } from '@idgital/idgital-validator/dist/src/entities/SOPClasses';
import { TRANSFER_SYNTAXES } from '@idgital/idgital-validator/dist/src/entities/TransferSyntaxes';
import { Observable } from 'rxjs';

import { GatewayDestination } from '@synth/api';
import { IconWithAreaComponent } from '@synth/ui';
import { MODAL_ACTION_COMPLETE, modalAnimation, ModalClass, ModalOverlayRef } from '@synth/ui/modals';
import { ICONS } from '@synth/utils';

@Component({
  selector: 'synth-gateway-destination-details-modal',
  templateUrl: './gateway-destination-details-modal.component.html',
  styleUrls: ['./gateway-destination-details-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [modalAnimation],
  imports: [IconWithAreaComponent],
})
export class GatewayDestinationDetailsModalComponent extends ModalClass {
  readonly ICONS = ICONS;

  readonly destination: GatewayDestination;
  readonly excludedSOPClasses: string = '';
  readonly transferSyntax: string = '';

  constructor(
    protected cdRef: ChangeDetectorRef,
    public overlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, overlayRef, actionComplete$);

    this.destination = this.overlayRef.data.destination;
    this.excludedSOPClasses = this.destination.configuration.excludedSOPClasses?.length
      ? this.destination.configuration.excludedSOPClasses
          .map((sopValue) => SOP_CLASSES.find((sop) => sop.value === sopValue)?.label || null)
          .filter((label) => label !== null)
          .join(', ')
      : '-';

    const syntax = TRANSFER_SYNTAXES.find((ts) => ts.value === this.destination.configuration.transferSyntax);

    this.transferSyntax = syntax?.label || '-';
  }

  closeModal(): void {
    this.modalOverlayRef.close();
  }
}
