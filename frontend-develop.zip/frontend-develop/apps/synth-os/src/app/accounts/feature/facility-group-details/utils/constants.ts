import { ColumnPriority } from '../../../../core/constants/constants';

export const FG_TABLE_COLUMNS_SETTINGS = {
  select: {
    minWidth: 20,
    priority: ColumnPriority.none,
  },
  id: {
    minWidth: 80,
    priority: ColumnPriority.small,
  },
  name: {
    minWidth: 120,
    priority: ColumnPriority.large,
  },
  process: {
    minWidth: 100,
    priority: ColumnPriority.small,
  },
  status: {
    minWidth: 100,
    priority: ColumnPriority.small,
  },
  type: {
    minWidth: 120,
    priority: ColumnPriority.large,
  },
  address: {
    minWidth: 150,
    priority: ColumnPriority.medium,
  },
  phone: {
    minWidth: 120,
    priority: ColumnPriority.large,
  },
  contractHolder: {
    minWidth: 120,
    priority: ColumnPriority.medium,
  },
  actions: {
    minWidth: 22,
    priority: ColumnPriority.small,
  },
};
