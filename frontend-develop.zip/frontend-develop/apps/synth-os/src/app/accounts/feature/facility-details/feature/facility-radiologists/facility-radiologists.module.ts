import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityRadiologistsComponent } from './facility-radiologists.component';
import { RadiologistsTableModule } from '../../../../../shared/ui/modules/radiologists-table/radiologists-table.module';

const routes: Routes = [
  {
    path: '',
    component: FacilityRadiologistsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class FacilityRadiologistsRoutingModule {}

@NgModule({
  declarations: [FacilityRadiologistsComponent],
  imports: [CommonModule, FacilityRadiologistsRoutingModule, RadiologistsTableModule],
})
export class FacilityRadiologistsModule {}
