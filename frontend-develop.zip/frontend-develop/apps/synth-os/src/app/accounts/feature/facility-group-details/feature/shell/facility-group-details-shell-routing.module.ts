import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FacilityGroupDetailsShellComponent } from './facility-group-details-shell.component';
import { GroupExamCodesListComponent } from '../../group-exam-codes/group-exam-codes-list/group-exam-codes-list.component';
import { GroupExamCodesShellComponent } from '../../group-exam-codes/shell/group-exam-codes-shell.component';
import { GroupTagsAndTasksShellComponent } from '../../group-tags-and-tasks/feature/shell/group-tags-and-tasks-shell.component';
import { GatewaysDestinationsComponent } from '../gateways/feature/destinations/gateways-destinations.component';
import { GatewaysJobsComponent } from '../gateways/feature/jobs/gateways-jobs.component';
import { GatewaysShellComponent } from '../gateways/feature/shell/gateways-shell.component';
import { GroupAlgorithmsComponent } from '../group-algorithms/group-algorithms.component';
import { GroupDocumentTypesComponent } from '../group-document-types/group-document-types.component';
import { GroupFacilitiesComponent } from '../group-facilities/group-facilities.component';
import { GroupFieldsLibraryComponent } from '../group-fields-library/group-fields-library.component';
import { GroupTemplatesComponent } from '../group-templates/group-templates.component';
import { GroupUsersComponent } from '../group-users/group-users.component';

const routes: Routes = [
  {
    path: '',
    component: FacilityGroupDetailsShellComponent,
    children: [
      {
        path: '',
        redirectTo: 'group-facilities',
        pathMatch: 'full',
      },
      {
        path: 'group-facilities',
        component: GroupFacilitiesComponent,
      },
      {
        path: 'users',
        component: GroupUsersComponent,
      },
      {
        path: 'templates',
        component: GroupTemplatesComponent,
      },
      {
        path: 'connections',
        loadChildren: () =>
          import('../../group-connections/feature/shell/group-connections-shell.module').then(
            (m) => m.GroupConnectionsShellModule
          ),
      },
      {
        path: 'algorithms',
        component: GroupAlgorithmsComponent,
      },
      {
        path: 'report-header',
        loadChildren: () =>
          import('../group-report-header/feature/shell/group-report-header-shell.module').then(
            (m) => m.GroupReportHeaderShellModule
          ),
      },
      {
        path: 'exam-codes',
        component: GroupExamCodesShellComponent,
        children: [
          {
            path: '',
            component: GroupExamCodesListComponent,
          },
        ],
      },
      {
        path: 'fields-library',
        component: GroupFieldsLibraryComponent,
      },
      {
        path: 'document-types',
        component: GroupDocumentTypesComponent,
      },
      {
        path: 'order-data-export',
        loadChildren: () =>
          import('../group-order-data-export/group-order-data-export.module').then((m) => m.GroupOrderDataExportModule),
      },
      {
        path: 'tags-and-tasks',
        component: GroupTagsAndTasksShellComponent,
      },
      {
        path: 'gateways',
        component: GatewaysShellComponent,
        children: [
          {
            path: '',
            redirectTo: 'destinations',
            pathMatch: 'full',
          },
          {
            path: 'destinations',
            component: GatewaysDestinationsComponent,
          },
          {
            path: 'jobs',
            component: GatewaysJobsComponent,
          },
        ],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FacilityGroupDetailsShellRoutingModule {}
