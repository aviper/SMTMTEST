import { ChangeDetectionStrategy, Component, computed, inject, input, InputSignal, Signal } from '@angular/core';
import { Store } from '@ngxs/store';

import { GATEWAY_JOB_STATE_LABELS, GatewayJob, GatewayJobState } from '@synth/api';
import { IconWithAreaComponent } from '@synth/ui';
import { ICONS } from '@synth/utils';

import { GatewaysJobsActions } from '../../data-access/gateways-jobs.actions';

@Component({
  selector: 'synth-gateway-job-state-cell',
  templateUrl: './gateway-job-state-cell.component.html',
  styleUrls: ['./gateway-job-state-cell.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconWithAreaComponent],
})
export class GatewayJobStateCellComponent {
  private readonly store: Store = inject(Store);

  readonly REFRESH_ICON = ICONS.refresh;

  readonly item: InputSignal<GatewayJob> = input.required<GatewayJob>();
  readonly rowLoading: InputSignal<boolean> = input.required<boolean>();

  readonly state: Signal<string> = computed(() => GATEWAY_JOB_STATE_LABELS[this.item().state] || this.item().state);
  readonly retryAvailable: Signal<boolean> = computed(() => this.item().state === GatewayJobState.FAILED);

  retryJob(): void {
    if (this.rowLoading()) {
      return;
    }

    this.store.dispatch(new GatewaysJobsActions.RetryJob(this.item().id));
  }
}
