import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { IFacilityGroup, IMpi } from '../../../../../core/models/types/facility';
import { ConverterService } from '../../../../../core/services/converter.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';

@Component({
  selector: 'app-facility-group-settings-block',
  templateUrl: './facility-group-settings-block.component.html',
  styleUrls: ['./facility-group-settings-block.component.scss'],
  standalone: false,
})
export class FacilityGroupSettingsBlockComponent implements OnInit, OnDestroy {
  @Input() canUpdate = false;

  readonly isLoading$: Observable<boolean> = this.store.select(FacilityGroupDetailsState.loading);
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  readonly FORM_CONTROLS = {
    timeout: 'timeout',
    protect: 'protect',
    isMfaEnabled: 'isMfaEnabled',
    isTwoFaEnabled: 'isTwoFaEnabled',
    externalLinkExpiration: 'externalLinkExpiration',
    mpi: 'mpiPattern',
    signatureInHl7: 'signatureInHl7',
    isPeerReviewPrescreen: 'isPeerReviewPrescreen',
  };

  readonly LABEL_TOOLTIPS = {
    deletionProtect: 'This option prevents the group from being deleted',
    mfa: 'One-time password with two-factor authentication app',
  };

  isLoading = false;
  form: UntypedFormGroup;
  mpi: IMpi;
  timeToLogout: string;
  humanizedExternalLinkExpiration: string;
  mpiFacilityIds: number[];
  facilityGroup: IFacilityGroup;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private fb: UntypedFormBuilder,
    private modalsService: ModalsV2Service,
    private facilitiesService: FacilitiesService,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.facilityGroup = this.store.selectSnapshot(FacilityGroupDetailsState.facilityGroup);

    this.facilityGroup$
      .pipe(
        takeUntil(this.unsubscribe$$),
        filter((facilityGroup) => !!facilityGroup)
      )
      .subscribe((facilityGroup) => {
        this.facilityGroup = facilityGroup;
        this.updateSettingsPlaceholders();
        this.updateForm();
        this.getMpiFacilities(this.facilityGroup.id);
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((loading: boolean) => (this.isLoading = loading));
  }

  changeGroupSetting(field: string, event: boolean): void {
    this.form.get(field).setValue(event);
    this.updateGroupSettings(field);
  }

  getMpiFacilities(id: number): void {
    this.facilitiesService.getGroupFacilities(id, { limit: 100 }, { autoNotifyErrors: false }).subscribe({
      next: (res) => {
        this.mpiFacilityIds = res.data.filter((el) => el.isMPIAutogenerationEnabled).map((el) => el.id);
      },
      error: (error) => {
        this.modalsService.error(error.message);
      },
    });
  }

  updateGroupSettings(control: string): void {
    const body: { [key: string]: any } = {};

    if (control === this.FORM_CONTROLS.externalLinkExpiration) {
      if (this.form.value.externalLinkExpiration === this.facilityGroup.externalLinkExpiration) {
        return;
      }

      this.humanizedExternalLinkExpiration = ConverterService.humanizeDuration(this.form.value.externalLinkExpiration);
      body[control] = this.form.value.externalLinkExpiration;
    } else if (control === this.FORM_CONTROLS.timeout) {
      if (this.form.value.timeout === this.timeToLogout) {
        return;
      }

      this.timeToLogout = this.form.value.timeout;
      body[control] = ConverterService.minutesAndSecondsStringToMilliseconds(this.form.value.timeout);
    } else if (
      control === this.FORM_CONTROLS.isMfaEnabled &&
      this.form.value.isTwoFaEnabled &&
      this.form.value.isMfaEnabled
    ) {
      body[control] = this.form.value[control];
      body.isTwoFaEnabled = false;
      this.form.get('isTwoFaEnabled').patchValue(false);
    } else if (
      control === this.FORM_CONTROLS.isTwoFaEnabled &&
      this.form.value.isTwoFaEnabled &&
      this.form.value.isMfaEnabled
    ) {
      body[control] = this.form.value[control];
      body.isMfaEnabled = false;
      this.form.get('isMfaEnabled').patchValue(false);
    } else {
      body[control] = this.form.value[control];
    }

    this.isLoading = true;

    this.store
      .dispatch(new FacilityGroupDetailsActions.UpdateGroupSettings({ id: this.facilityGroup.id, body }))
      .subscribe({
        next: () => {},
        error: () => this.updateForm(),
      });
  }

  private createForm(): void {
    this.form = this.fb.group({
      timeout: [
        null,
        [
          CustomValidators.timeout,
          CustomValidators.required,
          CustomValidators.min('05:00', (value: string) =>
            ConverterService.minutesAndSecondsStringToMilliseconds(value)
          ),
        ],
      ],
      protect: [null],
      isMfaEnabled: [null],
      isTwoFaEnabled: null,
      externalLinkExpiration: [null],
      signatureInHl7: [null],
      isPeerReviewPrescreen: [null],
    });
  }

  private updateForm(): void {
    this.facilityGroup &&
      this.form.patchValue({
        timeout: this.timeToLogout,
        protect: this.facilityGroup.protect,
        isMfaEnabled: this.facilityGroup.isMfaEnabled,
        isTwoFaEnabled: this.facilityGroup.isTwoFaEnabled,
        externalLinkExpiration: this.facilityGroup.externalLinkExpiration,
        signatureInHl7: this.facilityGroup.signatureInHl7,
        isPeerReviewPrescreen: this.facilityGroup.isPeerReviewPrescreen,
      });
  }

  private updateSettingsPlaceholders(): void {
    if (this.facilityGroup) {
      this.timeToLogout =
        this.facilityGroup.logoutConfig &&
        ConverterService.millisecondsToMinutesAndSeconds(this.facilityGroup.logoutConfig.timeout);
      this.humanizedExternalLinkExpiration = ConverterService.humanizeDuration(
        this.facilityGroup.externalLinkExpiration
      );
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
