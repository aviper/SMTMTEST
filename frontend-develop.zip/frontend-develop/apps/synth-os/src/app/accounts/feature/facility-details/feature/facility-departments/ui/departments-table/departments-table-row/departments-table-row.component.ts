import { Component, Input, OnInit, OnDestroy, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { FacilitiesPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { UpdateReportModalComponent } from '../../../../../../../../accounts/feature/facility-details/ui/update-report-modal/update-report-modal.component';
import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../core/helpers/custom-validators';
import { UserPermissions } from '../../../../../../../../core/models/classes/userPermissions';
import { IOption } from '../../../../../../../../core/models/types/common';
import { IContractHolder, IFacilityDepartment } from '../../../../../../../../core/models/types/facility';
import { ITableColumnWidth } from '../../../../../../../../core/models/types/tables';
import { FormService } from '../../../../../../../../core/services/form.service';
import { FacilityDepartmentsActions } from '../../../../../../../../core/store/accounts/actions/facility/facility-tabs/departments.actions';
import { FacilityDepartmentsState } from '../../../../../../../../core/store/accounts/states/facility/facility-tabs/departments.state';
import { ProfileState } from '../../../../../../../../profile/data-access/state/profile/profile.state';

@Component({
  selector: 'app-departments-table-row',
  templateUrl: './departments-table-row.component.html',
  styleUrls: ['./departments-table-row.component.scss'],
  standalone: false,
})
export class DepartmentsTableRowComponent implements OnInit, OnChanges, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityDepartmentsState.isLoading);

  readonly ACTION_ICONS = ICONS.actionsV2;

  @Input() department: IFacilityDepartment;
  @Input() contractHolderData: { isContactHolderRequired: boolean; data: IContractHolder[] } = {
    isContactHolderRequired: true,
    data: [],
  };
  @Input() displayedColumnsMap: { [key: string]: number } = {};
  @Input() columnsWidth: ITableColumnWidth = {};
  @Output() changed = new EventEmitter<IFacilityDepartment>();

  isLoading = false;
  canEditDepartments = false;
  canDeleteDepartments = false;
  departmentForm: UntypedFormGroup;
  contractHolderOptions: IOption[] = [];
  isDepartmentResponseChosen: boolean;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private permissions = new UserPermissions();

  constructor(
    private store: Store,
    private fb: UntypedFormBuilder,
    protected modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.createForm();

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.permissions = permissions;
        this.canEditDepartments = this.permissions.canEdit(ACCOUNTS_ENDPOINTS.departments);
        this.canDeleteDepartments = this.permissions.canDelete(ACCOUNTS_ENDPOINTS.departments);

        if (!this.canEditDepartments) {
          this.disableDepartmentForm();
        }
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading: boolean) => (this.isLoading = isLoading));
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.contractHolderOptions = [
      { value: null, label: 'Not selected' },
      ...this.contractHolderData.data.map((it) => ({ value: it.id, label: it.name })),
    ];
    !changes?.department?.firstChange && this.updateDepartmentForm();
  }

  changeDefaultState(department: IFacilityDepartment, value: boolean): void {
    const body = JSON.parse(JSON.stringify(department));

    body.isMain = value;
    body.fax = department.fdFax || null;
    body.phone = department.fdPhone || null;
    this.store.dispatch(
      new FacilityDepartmentsActions.UpdateFacilityDepartment({ id: department.id, department: body })
    );
  }

  deleteDepartment(department: IFacilityDepartment): void {
    this.store.dispatch(new FacilityDepartmentsActions.DeleteFacilityDepartment(department.id));
    this.changed.emit();
  }

  openReportsModal(department: IFacilityDepartment, enableAutoDelivery: boolean = false): void {
    if (this.departmentForm.valid) {
      this.modalsService.createModal(UpdateReportModalComponent, { data: { department, enableAutoDelivery } });
    } else {
      this.showValidateError();
    }
  }

  private createForm(): void {
    this.departmentForm = this.fb.group({
      name: [
        this.department.name,
        [
          CustomValidators.patternInput(FacilitiesPatterns.name.pattern),
          Validators.minLength(FacilitiesPatterns.name.minLength),
          Validators.maxLength(FacilitiesPatterns.name.maxLength),
        ],
      ],
      email: [this.department.email, [CustomValidators.email]],
      fax: [this.department.fdFax, CustomValidators.invalidPhoneNumber],
      phone: [this.department.fdPhone, [CustomValidators.invalidPhoneNumber]],
      notes: [
        this.department.notes,
        [
          CustomValidators.patternInput(FacilitiesPatterns.note.pattern),
          Validators.maxLength(FacilitiesPatterns.note.maxLength),
        ],
      ],
      contractHolderId: [
        this.department.contractHolderId,
        this.contractHolderData.isContactHolderRequired ? [CustomValidators.required] : [],
      ],
      isMain: this.department.isMain,
      autoDelivery: this.department.autoDelivery,
      departmentsResponses: [this.department.departmentsResponses],
      ftpServers: [this.department.ftpServers],
    });
    this.setIsDepartmentResponseChosen();
  }

  private updateDepartmentForm(): void {
    this.departmentForm.patchValue({
      name: this.department.name,
      email: this.department.email,
      fax: this.department.fdFax,
      phone: this.department.fdPhone,
      notes: this.department.notes,
      contractHolderId: this.department.contractHolderId,
      isMain: this.department.isMain,
      autoDelivery: this.department.autoDelivery,
      departmentsResponses: this.department.departmentsResponses,
      ftpServers: this.department.ftpServers,
    });
    this.setIsDepartmentResponseChosen();
  }

  private setIsDepartmentResponseChosen(): void {
    this.isDepartmentResponseChosen = this.department.departmentsResponses.some(
      (departmentsResponse) => departmentsResponse.value
    );
  }

  clickOnAutoDelivery(): boolean {
    if (!this.departmentForm.valid) {
      this.showValidateError();

      return false;
    }

    if (!this.isDepartmentResponseChosen) {
      this.openReportsModal(this.department, true);

      return false;
    }

    return true;
  }

  submit(fieldName: string): void {
    switch (fieldName) {
      case 'fax':
        this.checkPhoneNumbers(this.department.fdFax, this.departmentForm.controls[fieldName].value) &&
          this.updateDepartment(this.departmentForm.value);
        break;
      case 'phone':
        this.checkPhoneNumbers(this.department.fdPhone, this.departmentForm.controls[fieldName].value) &&
          this.updateDepartment(this.departmentForm.value);
        break;
      default:
        this.department[fieldName] !== this.departmentForm.controls[fieldName].value &&
          this.updateDepartment(this.departmentForm.value);
        break;
    }
  }

  private checkPhoneNumbers(
    number: { countryCode: string; number: string },
    formNumber: { countryCode: string; number: string }
  ): boolean {
    const isNumberFilled = !!(formNumber?.countryCode + formNumber?.number);
    const isNumberChanged = number?.countryCode + number?.number !== formNumber?.countryCode + formNumber?.number;

    return isNumberFilled && isNumberChanged;
  }

  private updateDepartment(departmentFormValue: IFacilityDepartment): void {
    if (this.departmentForm.valid) {
      const body = FormService.trimValues(departmentFormValue);

      if (!body.fax?.countryCode && !body.fax?.number) {
        body.fax = null;
      }

      if (!body.phone?.countryCode && !body.phone?.number) {
        body.phone = null;
      }

      this.store.dispatch(
        new FacilityDepartmentsActions.UpdateFacilityDepartment({ id: this.department.id, department: body })
      );
    } else {
      this.showValidateError();
    }
  }

  private showValidateError(): void {
    this.modalsService.error('Fill up all needed fields');
    this.departmentForm.enable();
  }

  private disableDepartmentForm(): void {
    this.departmentForm.disable();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
