import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, Subject, takeUntil, tap, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { ApiItemResponse, ApiListResponse } from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { GroupTagsAndTasksActions } from './group-tags-and-tasks.actions';
import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { Helper } from '../../../../../core/helpers/helper';
import { TagsAndTasksService } from '../../../../../core/http-services/tags-and-tasks.service';
import { IGroupTagAndTask, IGroupTagAndTaskSearchParams } from '../../../../../core/models/tags-and-tasks.model';
import { ISort } from '../../../../../core/models/types/common';

export interface IGroupTagsAndTasksState {
  facilityGroupId: number;
  groupTagsAndTasks: IGroupTagAndTask[];
  searchConfig: IGroupTagAndTaskSearchParams;
  sort: ISort;
  pagination: IPagination;
  isLoading: boolean;
  limit: number;
}

@State<IGroupTagsAndTasksState>({
  name: 'groupTagsAndTasks',
  defaults: {
    facilityGroupId: null,
    groupTagsAndTasks: [],
    isLoading: false,
    limit: DEFAULT_LIMIT,
    searchConfig: {},
    sort: {
      sortField: 'name',
      direction: 'asc',
    },
    pagination: { ...PAGINATION },
  },
})
@Injectable()
export class GroupTagsAndTasksState {
  private readonly unsubscribeFromLoadGroupTagAndTasksRequest$$ = new Subject<void>();

  @Selector()
  static groupTagsAndTasks(state: IGroupTagsAndTasksState): IGroupTagAndTask[] {
    return state.groupTagsAndTasks;
  }

  @Selector()
  static isLoading(state: IGroupTagsAndTasksState): boolean {
    return state.isLoading;
  }

  @Selector()
  static filter(state: IGroupTagsAndTasksState): IGroupTagAndTaskSearchParams {
    return state.searchConfig;
  }

  @Selector()
  static pagination(state: IGroupTagsAndTasksState): IPagination {
    return state.pagination;
  }

  @Selector()
  static sort(state: IGroupTagsAndTasksState): ISort {
    return state.sort;
  }

  constructor(
    private readonly modalsService: ModalsV2Service,
    private readonly tagsAndTasksService: TagsAndTasksService
  ) {}

  @Action(GroupTagsAndTasksActions.SetParams)
  setFacilityGroupId(
    ctx: StateContext<IGroupTagsAndTasksState>,
    { payload: { facilityGroupId, limit } }: GroupTagsAndTasksActions.SetParams
  ): void {
    ctx.patchState({
      facilityGroupId,
      limit,
    });

    ctx.dispatch(new GroupTagsAndTasksActions.LoadGroupTagAndTasks());
  }

  @Action(GroupTagsAndTasksActions.LoadGroupTagAndTasks)
  loadGroupTagAndTasks(ctx: StateContext<IGroupTagsAndTasksState>): Observable<ApiListResponse<IGroupTagAndTask>> {
    this.unsubscribeFromLoadGroupTagAndTasksRequest$$.next();

    ctx.patchState({
      isLoading: true,
    });

    const { facilityGroupId, sort, searchConfig, pagination, limit } = ctx.getState();

    const query = {
      ...sort,
      ...searchConfig,
      limit,
      offset: pagination.offset,
    };

    return this.tagsAndTasksService.getGroupTagsAndTasks(facilityGroupId, query).pipe(
      finalize(() => {
        ctx.patchState({
          isLoading: false,
        });
      }),
      takeUntil(this.unsubscribeFromLoadGroupTagAndTasksRequest$$),
      tap((response) => {
        const { groupTagsAndTasks, pagination } = ctx.getState();

        ctx.patchState({
          groupTagsAndTasks: pagination.offset ? groupTagsAndTasks.concat(response.data) : response.data,
          pagination: {
            ...pagination,
            lastChunkSize: response.data.length,
          },
        });
      }),
      catchError((error) => {
        this.modalsService.error(error.message);

        return throwError(() => error);
      })
    );
  }

  @Action(GroupTagsAndTasksActions.SetSearchConfig)
  setFilters(
    ctx: StateContext<IGroupTagsAndTasksState>,
    { payload: { searchConfig } }: GroupTagsAndTasksActions.SetSearchConfig
  ): void {
    ctx.patchState({
      searchConfig,
    });

    ctx.dispatch(new GroupTagsAndTasksActions.LoadGroupTagAndTasks());
  }

  @Action(GroupTagsAndTasksActions.SetSorting)
  setSorting(
    ctx: StateContext<IGroupTagsAndTasksState>,
    { payload: { sort } }: GroupTagsAndTasksActions.SetSorting
  ): void {
    ctx.patchState({
      sort,
    });

    ctx.dispatch(new GroupTagsAndTasksActions.LoadGroupTagAndTasks());
  }

  @Action(GroupTagsAndTasksActions.CreateGroupTagAndTask)
  createGroupTagAndTask(
    ctx: StateContext<IGroupTagsAndTasksState>,
    { payload }: GroupTagsAndTasksActions.CreateGroupTagAndTask
  ): Observable<ApiItemResponse<IGroupTagAndTask>> {
    ctx.patchState({
      isLoading: true,
    });

    const { facilityGroupId } = ctx.getState();

    return this.tagsAndTasksService.createGroupTagAndTask({ ...payload, groupId: facilityGroupId }).pipe(
      finalize(() => {
        ctx.patchState({
          isLoading: false,
        });
      }),
      tap(() => {
        ctx.patchState({
          isLoading: false,
        });
        ctx.dispatch(new GroupTagsAndTasksActions.GroupTagAndTaskCreated());
        ctx.dispatch(new GroupTagsAndTasksActions.ResetPagination());
        ctx.dispatch(new GroupTagsAndTasksActions.LoadGroupTagAndTasks());

        this.modalsService.success('Tag was successfully created');
      }),
      catchError((error) => {
        this.modalsService.error(error.message);

        return throwError(() => error);
      })
    );
  }

  @Action(GroupTagsAndTasksActions.DeleteGroupTagAndTask)
  deleteGroupTagAndTask(
    ctx: StateContext<IGroupTagsAndTasksState>,
    action: GroupTagsAndTasksActions.DeleteGroupTagAndTask
  ): Observable<ApiItemResponse<IGroupTagAndTask>> {
    const deletingTagId = action.payload.tag.id;

    return this.tagsAndTasksService.deleteGroupTagAndTask(deletingTagId).pipe(
      tap(() => {
        const filteredTags = ctx
          .getState()
          .groupTagsAndTasks.filter((tag: IGroupTagAndTask) => tag.id !== deletingTagId);

        ctx.patchState({
          groupTagsAndTasks: filteredTags,
        });
        this.modalsService.success('Tag was successfully deleted');
      }),
      catchError((error) => {
        this.modalsService.error(error.message);

        return throwError(() => error);
      })
    );
  }

  @Action(GroupTagsAndTasksActions.UpdateGroupTagAndTaskName)
  updateGroupTagAndTaskName(
    ctx: StateContext<IGroupTagsAndTasksState>,
    { payload }: GroupTagsAndTasksActions.UpdateGroupTagAndTaskName
  ): Observable<ApiItemResponse<IGroupTagAndTask>> {
    const { tagId, property, value } = payload;
    const tagsAndTasks = Helper.cloneDeep(ctx.getState().groupTagsAndTasks);
    const indexOfTag = tagsAndTasks.findIndex((el: IGroupTagAndTask) => el.id === tagId);

    if (tagsAndTasks[indexOfTag][property] === value) {
      return;
    }

    return this.tagsAndTasksService.updateGroupTagAndTask(tagId, { [property]: value }).pipe(
      tap(() => {
        tagsAndTasks[indexOfTag][property] = value;

        ctx.patchState({
          groupTagsAndTasks: tagsAndTasks,
        });

        this.modalsService.success('Tag was successfully updated');
      }),
      catchError((error) => {
        ctx.patchState({
          groupTagsAndTasks: [],
        });
        // return prev value to table if error
        ctx.patchState({
          groupTagsAndTasks: [...tagsAndTasks],
        });

        this.modalsService.error(error.message);

        return throwError(() => error);
      })
    );
  }

  @Action(GroupTagsAndTasksActions.PaginateGroupTagsAndTasks)
  updateGroupTagAndTasksPagination(
    ctx: StateContext<IGroupTagsAndTasksState>,
    action: GroupTagsAndTasksActions.PaginateGroupTagsAndTasks
  ): void {
    const pagination = ctx.getState().pagination;

    ctx.patchState({
      pagination: {
        ...pagination,
        offset: action.payload,
      },
    });

    ctx.dispatch(new GroupTagsAndTasksActions.LoadGroupTagAndTasks());
  }

  @Action(GroupTagsAndTasksActions.ResetPagination)
  resetPagination(ctx: StateContext<IGroupTagsAndTasksState>): void {
    ctx.patchState({
      groupTagsAndTasks: [],
      pagination: { ...PAGINATION },
    });
  }
}
