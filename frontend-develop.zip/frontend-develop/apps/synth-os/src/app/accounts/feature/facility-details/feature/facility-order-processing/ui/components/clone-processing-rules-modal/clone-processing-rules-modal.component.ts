import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize, takeUntil } from 'rxjs/operators';

import { modalAnimation, MODAL_ACTION_COMPLETE, ModalOverlayRef, ModalClass } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../../../core/helpers/custom-validators';
import { FacilityOrderProcessingService } from '../../../../../../../../core/http-services/facilities-order-processing.service';
import { IFacility } from '../../../../../../../../core/models/types/facility';
import { FacilityOrdersProcessingActions } from '../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';

@Component({
  selector: 'app-clone-processing-rules-modal',
  templateUrl: './clone-processing-rules-modal.component.html',
  styleUrls: ['./clone-processing-rules-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class CloneProcessingRulesModalComponent extends ModalClass implements OnInit {
  readonly ICONS = ICONS;

  cloneFromId = new UntypedFormControl(null, CustomValidators.required);
  isLoading = false;
  facility: IFacility;
  cloneFromInfo: {
    facilityName: string;
    rulesCount: number;
  } = null;

  constructor(
    private store: Store,
    private cdRef: ChangeDetectorRef,
    private facilityOrderProcessingService: FacilityOrderProcessingService,
    public modalOverlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.facility = this.modalOverlayRef.data.facility || null;

    this.cloneFromId.valueChanges.pipe(takeUntil(this.modalOverlayRef.beforeClosed())).subscribe((value) => {
      this.getCloneFromFacilityDetails();
    });
  }

  cloneRules(): void {
    if (this.cloneFromId.invalid) {
      return;
    }

    this.isLoading = true;

    this.facilityOrderProcessingService
      .cloneFacilityOrderProcessing(this.facility.id, {
        facilityId: this.cloneFromId.value,
      })
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe(() => {
        this.store.dispatch(new FacilityOrdersProcessingActions.GetOrdersProcessing({ facilityId: this.facility.id }));
        this.closeModal();
      });
  }

  getCloneFromFacilityDetails(): void {
    this.isLoading = true;
    this.cloneFromInfo = null;

    this.facilityOrderProcessingService
      .getFacilityProcessingRulesCount(this.cloneFromId.value)
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.modalOverlayRef.beforeClosed())
      )
      .subscribe((res) => {
        this.cloneFromInfo = res.data;
      });
  }

  closeModal(reload: boolean = false): void {
    this.result.emit(true);
    this.modalOverlayRef.close();
  }
}
