import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject, takeUntil } from 'rxjs';

import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../../../../core/constants/constants';
import { FacilityOrderProcessingErrorsLogService } from '../../../../../../../../../core/http-services/facilities-order-processing-errors-log.service';
import { ISort } from '../../../../../../../../../core/models/types/common';
import { IOrdersProcessingErrorsLog } from '../../../../../../../../../core/models/types/orders-processing-errors-log';
import { ITableColumnWidth } from '../../../../../../../../../core/models/types/tables';
import { FacilityOrdersProcessingErrorsLogActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing-errors-log.actions';
import { FacilityOrdersProcessingErrorsLogState } from '../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing-errors-log.state';
import { SettingsState } from '../../../../../../../../../shared/data-access/state/settings/settings.state';

@Component({
  selector: 'app-error-log-tab',
  templateUrl: './error-log-tab.component.html',
  styleUrls: ['./error-log-tab.component.scss'],
  standalone: false,
})
export class ErrorLogTabComponent implements OnInit, OnDestroy {
  private readonly unsubscribe$$ = new Subject<void>();
  readonly PaginationStrategiesNames = PaginationStrategiesNames;
  readonly columnsWidth: ITableColumnWidth = {
    errorType: 200,
    errorDateTime: 200,
    resolved: 120,
    message: 200,
  };

  readonly data$: Observable<IOrdersProcessingErrorsLog[]> = this.store.select(
    FacilityOrdersProcessingErrorsLogState.data
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityOrdersProcessingErrorsLogState.isLoading);
  readonly pagination$: Observable<IPagination> = this.store.select(FacilityOrdersProcessingErrorsLogState.pagination);
  readonly sort$: Observable<ISort> = this.store.select(FacilityOrdersProcessingErrorsLogState.sort);

  items: IOrdersProcessingErrorsLog[] = [];
  isLoading: boolean;
  pagination: IPagination;
  sort: ISort;
  limit = DEFAULT_LIMIT;

  @Input() facilityId: number;

  constructor(
    private readonly store: Store,
    private readonly service: FacilityOrderProcessingErrorsLogService
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.data$.pipe(takeUntil(this.unsubscribe$$)).subscribe((data) => {
      this.items = data || [];
    });

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => {
      this.pagination = pagination;
    });

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort) => {
      this.sort = sort;
    });

    this.service
      .onFacilityErrorLogCountUpdated(this.facilityId)
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((unresolvedErrorsCount) => {
        this.store.dispatch(
          new FacilityOrdersProcessingErrorsLogActions.UpdateUnresolvedErrorsCount({
            unresolvedErrorsCount,
          })
        );
      });

    this.store.dispatch(
      new FacilityOrdersProcessingErrorsLogActions.GetOrdersProcessingErrorsLog({ facilityId: this.facilityId })
    );
  }

  onSortChanged(sort: ISort): void {
    this.store.dispatch(
      new FacilityOrdersProcessingErrorsLogActions.ApplySort({
        facilityId: this.facilityId,
        ...sort,
      })
    );
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new FacilityOrdersProcessingErrorsLogActions.GetOrdersProcessingErrorsLog({
        facilityId: this.facilityId,
        offset,
      })
    );
  }

  onHeaderResolvedChange(resolved: boolean): void {
    if (resolved) {
      this.store.dispatch(
        new FacilityOrdersProcessingErrorsLogActions.MarkErrorsLogAsResolved({
          facilityId: this.facilityId,
          idsToBeResolved: this.items.map(({ _id }) => _id),
        })
      );
    } else {
      this.store.dispatch(
        new FacilityOrdersProcessingErrorsLogActions.MarkErrorsLogAsUnresolved({
          facilityId: this.facilityId,
          idsToBeUnresolved: this.items.map(({ _id }) => _id),
        })
      );
    }
  }

  onRowResolvedChange(_id: string, resolved: boolean): void {
    if (resolved) {
      this.store.dispatch(
        new FacilityOrdersProcessingErrorsLogActions.MarkErrorsLogAsResolved({
          facilityId: this.facilityId,
          idsToBeResolved: [_id],
        })
      );
    } else {
      this.store.dispatch(
        new FacilityOrdersProcessingErrorsLogActions.MarkErrorsLogAsUnresolved({
          facilityId: this.facilityId,
          idsToBeUnresolved: [_id],
        })
      );
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new FacilityOrdersProcessingErrorsLogActions.ResetState());
  }
}
