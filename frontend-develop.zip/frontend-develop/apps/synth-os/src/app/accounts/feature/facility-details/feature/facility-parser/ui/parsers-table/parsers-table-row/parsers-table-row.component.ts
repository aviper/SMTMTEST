import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { PopoverTriggerDirective } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../core/constants/icon-list';
import { IOption } from '../../../../../../../../core/models/types/common';
import { IParser } from '../../../../../../../../core/models/types/parser';
import { FacilityParsersActions } from '../../../../../../../../core/store/accounts/actions/facility/facility-tabs/parsers.actions';
import { FacilityParsersState } from '../../../../../../../../core/store/accounts/states/facility/facility-tabs/parsers.state';

@Component({
  selector: 'app-parsers-table-row',
  templateUrl: './parsers-table-row.component.html',
  styleUrls: ['./parsers-table-row.component.scss'],
  standalone: false,
})
export class ParsersTableRowComponent implements OnInit, OnDestroy {
  readonly actions$: Observable<string[]> = this.store.select(FacilityParsersState.actions);
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityParsersState.isLoading);

  @ViewChild(PopoverTriggerDirective, { static: false }) popoverController: PopoverTriggerDirective;

  @Input() item: IParser;

  readonly PARSER_FIELDS = {
    required: 'required',
    source: 'source',
    path: 'path',
    action: 'action',
    separator: 'separator',
  };
  readonly sourceOptions: IOption[] = [
    { value: 'study', label: 'study' },
    { value: 'series', label: 'series' },
  ];
  readonly pathTypes: IOption[] = [
    { value: 'string', label: 'String' },
    { value: 'number', label: 'Number' },
  ];
  readonly requiredItemOptions: IOption[] = [
    { value: 'true', label: 'True' },
    { value: 'false', label: 'False' },
  ];
  readonly EDIT_ICON = ICONS.actionsV2.edit;
  readonly DELETE_ICON = ICONS.actionsV2.delete;

  form: UntypedFormGroup;
  pathForms: UntypedFormGroup;
  loadingField: string = null;
  actionsOptions: IOption[] = [];
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private fb: UntypedFormBuilder,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.createPathForm();

    this.actions$.pipe(takeUntil(this.unsubscribe$$)).subscribe((actions) => {
      this.actionsOptions = actions.map((value) => ({
        value,
        label: value,
      }));
    });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((loading) => {
      if (this.loadingField && !loading) {
        this.loadingField = null;
      }
    });
  }

  private createForm(): void {
    this.form = this.fb.group({
      name: [this.item.name],
      required: [this.item.required.toString()],
      source: [this.item.source],
      path: [this.item.path || ''],
      action: [this.item.action],
      separator: [this.item.separator],
      type: [this.item.type],
    });
  }

  private createPathForm(): void {
    this.pathForms = this.fb.group({
      items: this.fb.array([]),
      newType: 'string',
      newValue: '',
    });
    this.pathStringToList().forEach((item) =>
      this.pathFormsItems.push(
        this.fb.group({
          type: item.type,
          value: item.value,
        })
      )
    );
  }

  private pathStringToList(): { type: string; value: number | string }[] {
    if (!this.item.path) {
      return [];
    }

    return this.item.path.split('->').map((value) => {
      if (value[0] === '"') {
        return {
          type: 'string',
          value: value.slice(1, -1),
        };
      }

      return {
        type: 'number',
        value: parseInt(value),
      };
    });
  }

  private pathListToString(): string {
    return this.pathForms.value.items
      .map((item) => (item.type === 'string' ? `"${item.value}"` : `${item.value}`))
      .join('->');
  }

  get pathFormsItems(): UntypedFormArray {
    return this.pathForms.get('items') as UntypedFormArray;
  }

  removePathItem(index: number): void {
    this.pathFormsItems.removeAt(index);
  }

  addPathItem(): void {
    const { newType, newValue } = this.pathForms.value;

    if (newType && newValue) {
      this.pathFormsItems.push(
        this.fb.group({
          type: newType,
          value: newValue,
        })
      );
      this.pathForms.patchValue({
        newType: 'string',
        newValue: '',
      });
    }
  }

  savePath(): void {
    const path = this.pathListToString();

    if (this.form.value.path !== path) {
      this.form.get('path').setValue(path);
      this.update('path');
    }
  }

  update(field: string): void {
    if (this.form.dirty || field === 'path') {
      this.loadingField = field;
      this.store.dispatch(
        new FacilityParsersActions.UpdateFacilityParser({
          parserId: this.item.id,
          body: {
            ...this.form.value,
            required: this.form.value.required === 'true',
          },
        })
      );
    }
  }

  togglePathDropdown(state: boolean): void {
    this.popoverController.updateDisableClosing = state;
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
