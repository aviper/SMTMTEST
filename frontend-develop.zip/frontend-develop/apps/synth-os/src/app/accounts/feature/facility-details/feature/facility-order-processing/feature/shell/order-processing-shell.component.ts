import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, Subject, takeUntil } from 'rxjs';

import { ModalsV2Service } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../../core/constants/icon-list';
import { UserPermissions } from '../../../../../../../core/models/classes/userPermissions';
import { ITabMenuItem } from '../../../../../../../core/models/types/common';
import { FacilityDetailsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityOrdersProcessingErrorsLogActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing-errors-log.actions';
import { FacilityOrdersProcessingActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-orders-processing.actions';
import { FacilityDetailsState } from '../../../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityOrdersProcessingErrorsLogState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing-errors-log.state';
import { FacilityOrdersProcessingState } from '../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-orders-processing.state';
import { ProfileState } from '../../../../../../../profile/data-access/state/profile/profile.state';
import { FACILITY_DETAILS_TABS } from '../../../../../../../shared/utils/constants';
import { OrderProcessingTabs } from '../../utils/types';

@Component({
  selector: 'app-facility-details-order-processing',
  templateUrl: './order-processing-shell.component.html',
  styleUrls: ['./order-processing-shell.component.scss'],
  standalone: false,
})
export class OrderProcessingShellComponent implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly OrderProcessingTabs = OrderProcessingTabs;

  private readonly unsubscribe$$ = new Subject<void>();

  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly procedureNormalization$: Observable<boolean> = this.store.select(
    FacilityDetailsState.procedureNormalization
  );
  readonly unresolvedCount$: Observable<number> = this.store.select(
    FacilityOrdersProcessingErrorsLogState.unresolvedErrorsCount
  );
  readonly isFiltering$: Observable<boolean> = this.store.select(FacilityOrdersProcessingState.isFiltering);

  facilityGroupPageTabMenu: ITabMenuItem[] = [
    {
      title: 'Rule configuration',
      value: OrderProcessingTabs.RULE_CONFIGURATION,
      available: true,
    },
    {
      title: 'Error log',
      value: OrderProcessingTabs.ERROR_LOG,
      available: true,
    },
  ];

  procedureNormalization = false;
  selectedTab = OrderProcessingTabs.RULE_CONFIGURATION;
  facilityId: number;
  canAdd = false;
  isFiltering = false;
  permissions: UserPermissions;

  constructor(
    private readonly store: Store,
    private readonly modalsV2Service: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.store.dispatch(new FacilityOrdersProcessingActions.GetOrdersProcessing({ facilityId }));
        this.store.dispatch(new FacilityOrdersProcessingErrorsLogActions.GetUnresolvedErrorsLogCount({ facilityId }));
        this.facilityId = facilityId;
      });

    this.store.dispatch(
      new FacilityDetailsActions.SetCurrentTab({
        tab: FACILITY_DETAILS_TABS.orderProcessing,
      })
    );

    this.procedureNormalization$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((procedureNormalization) => (this.procedureNormalization = procedureNormalization));

    this.permissions$
      .pipe(
        takeUntil(this.unsubscribe$$),
        filter((permissions) => !!permissions)
      )
      .subscribe((permissions) => {
        this.canAdd = permissions.canCreate(ACCOUNTS_ENDPOINTS.orderProcessing);
      });

    this.unresolvedCount$.pipe(takeUntil(this.unsubscribe$$)).subscribe((unresolvedCount) => {
      const errorsLogMenuCount = this.facilityGroupPageTabMenu.find(
        (tab) => tab.value === OrderProcessingTabs.ERROR_LOG
      );

      errorsLogMenuCount.counter = unresolvedCount > 0 ? unresolvedCount : null;
    });

    this.isFiltering$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isFiltering) => (this.isFiltering = isFiltering));
  }

  setSelectedTab(tab: OrderProcessingTabs): void {
    this.selectedTab = tab;

    if (this.selectedTab === OrderProcessingTabs.RULE_CONFIGURATION) {
      this.store.dispatch(new FacilityOrdersProcessingActions.GetOrdersProcessing({ facilityId: this.facilityId }));
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
