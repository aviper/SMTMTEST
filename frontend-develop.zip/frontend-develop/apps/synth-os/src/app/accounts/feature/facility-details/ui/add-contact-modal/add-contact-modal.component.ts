import { Component, OnInit, ChangeDetectorRef, Inject } from '@angular/core';
import { UntypedFormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { FacilityDirectoriesPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs';

import {
  ModalsV2Service,
  modalAnimation,
  CONFIRM_POPUP_RESPONSE,
  ModalOverlayRef,
  ModalClass,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ICONS } from '../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { DirectoryActions } from '../../../../../shared/data-access/state/directory/directory.actions';

@Component({
  selector: 'app-add-contact-modal',
  templateUrl: './add-contact-modal.component.html',
  styleUrls: ['./add-contact-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddContactModalComponent extends ModalClass implements OnInit {
  readonly ICONS = ICONS;

  isLoading = false;
  addContactForm: UntypedFormGroup;

  private facilityId: number;

  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    private modalsService: ModalsV2Service,
    private fb: UntypedFormBuilder,
    private store: Store,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.facilityId = this.modalOverlayRef.data.facilityId;
    this.createForm();
  }

  addContact(): void {
    this.store.dispatch(
      new DirectoryActions.AddDirectoryItem({ facilityId: this.facilityId, body: this.addContactForm.value })
    );
    this.closeModal();
  }

  closeAfterConfirm(): void {
    if (this.addContactForm.dirty && this.addContactForm.invalid) {
      this.modalsService
        .confirm({
          title: 'Wait!',
          message: 'Do you want to discard changes or keep editing?',
          cancelButton: 'Discard',
          confirmationButton: 'Keep Editing',
        })
        .subscribe((result) => {
          if (result === CONFIRM_POPUP_RESPONSE.cancel) {
            this.closeModal();
          }
        });
    } else {
      this.closeModal();
    }
  }

  closeModal(reload: boolean = false): void {
    this.result.emit({ reload });
    this.modalOverlayRef.close();
  }

  private createForm(): void {
    this.addContactForm = this.fb.group({
      name: [
        '',
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilityDirectoriesPatterns.name.pattern),
          Validators.maxLength(FacilityDirectoriesPatterns.name.maxLength),
        ],
      ],
      primaryPhone: ['', [CustomValidators.patternInput(FacilityDirectoriesPatterns.primaryPhone.pattern)]],
      secondaryPhone: ['', CustomValidators.patternInput(FacilityDirectoriesPatterns.secondaryPhone.pattern)],
      email: ['', [CustomValidators.email]],
      faxNumber: ['', [CustomValidators.patternInput(FacilityDirectoriesPatterns.faxNumber.pattern)]],
    });
  }
}
