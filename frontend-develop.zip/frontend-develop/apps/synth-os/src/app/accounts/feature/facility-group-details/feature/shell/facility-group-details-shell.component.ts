import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store } from '@ngxs/store';
import { StateReset } from 'ngxs-reset-plugin';
import { Subject, Observable } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { ITabMenuItem } from '../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { TabMenuService } from '../../../../../core/services/tab-menu.service';
import { TemplateService } from '../../../../../core/services/template.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';

@Component({
  selector: 'app-facility-group-details-shell',
  templateUrl: './facility-group-details-shell.component.html',
  styleUrls: ['./facility-group-details-shell.component.scss'],
  standalone: false,
})
export class FacilityGroupDetailsShellComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly SIDEBAR_ICONS = ICONS.sideBar;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  isCollapsedRightAside = false;
  facilityGroup: IFacilityGroup;
  facilityGroupPageTabMenu: ITabMenuItem[] = [];
  permissions = new UserPermissions();

  facilityGroupDetailsPermissions: IPermissionsConfig = {
    canRead: {
      [ACCOUNTS_ENDPOINTS.groupSettings]: false,
    },
    canEdit: {
      [ACCOUNTS_ENDPOINTS.groups]: false,
      [ACCOUNTS_ENDPOINTS.groupSettings]: false,
    },
  };

  private facilityGroupId: number;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private activatedRoute: ActivatedRoute,
    private tabMenuService: TabMenuService,
    private facilitiesService: FacilitiesService,
    public templateService: TemplateService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.pipe(takeUntil(this.unsubscribe$$)).subscribe((paramMap: ParamMap) => {
      this.facilityGroupId = parseInt(paramMap.get('id'), 10);
      this.store.dispatch(new FacilityGroupDetailsActions.GetFacilityGroup(this.facilityGroupId));
    });

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.permissions = permissions;
        this.initTabMenu();
        this.facilityGroupDetailsPermissions = PermissionsClass.updatePermissions(
          this.permissions,
          this.facilityGroupDetailsPermissions
        );
      });

    this.facilitiesService
      .onAccountUpdated()
      .pipe(
        filter((data) => data.type === 'facilityGroup' && data.id === this.facilityGroupId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.store.dispatch(new FacilityGroupDetailsActions.GetFacilityGroup(this.facilityGroupId));
      });
  }

  toggleAside(): void {
    this.isCollapsedRightAside = !this.isCollapsedRightAside;
  }

  private initTabMenu(): void {
    this.facilityGroupPageTabMenu = this.tabMenuService.getFacilityGroupPageTabs(this.permissions);
  }

  ngOnDestroy(): void {
    this.store.dispatch(new StateReset(FacilityGroupDetailsState));
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
