const ACTION_SCOPE = '[Gateways Jobs]';

export namespace GatewaysJobsActions {
  export class Init {
    static readonly type = `${ACTION_SCOPE} Init`;
    constructor(public payload: number) {}
  }

  export class Get {
    static readonly type = `${ACTION_SCOPE} Get`;
  }

  export class Search {
    static readonly type = `${ACTION_SCOPE} Search`;
    constructor(public payload: Record<string, string | string[]>) {}
  }

  export class Paginate {
    static readonly type = `${ACTION_SCOPE} Paginate`;
    constructor(public payload: number) {}
  }

  export class RetryJob {
    static readonly type = `${ACTION_SCOPE} Retry Job`;
    constructor(public payload: number) {}
  }

  export class ClearData {
    static readonly type = `${ACTION_SCOPE} Clear Data`;
  }
}
