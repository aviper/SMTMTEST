import { Routes } from '@angular/router';

import { FacilityFormsShellComponent } from './facility-forms-shell.component';

export const ROUTES: Routes = [
  {
    path: '',
    component: FacilityFormsShellComponent,
    children: [
      {
        path: '',
        loadComponent: () =>
          import('../facility-forms-list/facility-forms-list.component').then((c) => c.FacilityFormsListComponent),
      },
    ],
  },
];
