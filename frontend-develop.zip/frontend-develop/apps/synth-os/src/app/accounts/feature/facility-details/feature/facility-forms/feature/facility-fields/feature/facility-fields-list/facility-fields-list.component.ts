import { Component, computed, DestroyRef, OnInit, Signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Actions, ofActionDispatched, Store } from '@ngxs/store';
import { filter } from 'rxjs';

import { CONFIRM_POPUP_RESPONSE, ModalsV2Service } from '@synth/ui/modals';
import { IPagination } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../../../../../../../core/constants/endpoints';
import { IRights, UserPermissions } from '../../../../../../../../../core/models/classes/userPermissions';
import { ISort } from '../../../../../../../../../core/models/types/common';
import {
  ICustomFieldsTableQuery,
  ICustomFormField,
} from '../../../../../../../../../core/models/types/custom-fields-and-forms';
import { FacilityDetailsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityFieldsActions } from '../../../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-fields.actions';
import { FacilityDetailsState } from '../../../../../../../../../core/store/accounts/states/facility/facility-details.state';
import {
  FACILITY_FIELDS_DEFAULT_SORT,
  FacilityFieldsState,
} from '../../../../../../../../../core/store/accounts/states/facility/facility-tabs/facility-fields.state';
import { ProfileState } from '../../../../../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../../../../../shared/data-access/state/settings/settings.state';
import { ItemChangeEvent } from '../../../../../../../../../shared/ui/components/basic-table/basic-table.types';
import { CloneFieldModalComponent } from '../../../../../../../../../shared/ui/components/clone-field-modal/clone-field-modal.component';
import { CreateFieldModalComponent } from '../../../../../../../../../shared/ui/components/create-field-modal/create-field-modal.component';
import { createFieldModalData } from '../../../../../../../../../shared/ui/components/create-field-modal/create-field-modal.types';
import { SynthCustomFieldsTableComponent } from '../../../../../../../../../shared/ui/components/custom-fields-table/custom-fields-table.component';
import { FACILITY_DETAILS_TABS } from '../../../../../../../../../shared/utils/constants';
import { FacilityFieldsHeaderComponent } from '../../ui/facility-fields-header/facility-fields-header.component';

@Component({
  selector: 'synth-facility-fields-list',
  templateUrl: './facility-fields-list.component.html',
  styleUrls: ['./facility-fields-list.component.scss'],
  imports: [SynthCustomFieldsTableComponent, FacilityFieldsHeaderComponent],
})
export class FacilityFieldsListComponent implements OnInit {
  readonly DEFAULT_SORT: ISort = FACILITY_FIELDS_DEFAULT_SORT;

  readonly fields: Signal<ICustomFormField[]> = this.store.selectSignal(FacilityFieldsState.fields);
  readonly isLoading: Signal<boolean> = this.store.selectSignal(FacilityFieldsState.isLoading);
  readonly granularLoadings: Signal<Record<string, boolean>> = this.store.selectSignal(
    FacilityFieldsState.granularLoadings
  );
  readonly sort: Signal<ISort> = this.store.selectSignal(FacilityFieldsState.sort);
  readonly pagination: Signal<IPagination> = this.store.selectSignal(FacilityFieldsState.pagination);
  readonly scrolledDistance: Signal<number> = this.store.selectSignal(FacilityFieldsState.scrolledDistance);
  readonly limit: Signal<number> = this.store.selectSignal(SettingsState.limit);
  readonly facilityId: Signal<number> = this.store.selectSignal(FacilityDetailsState.facilityId);
  readonly permissions: Signal<UserPermissions> = this.store.selectSignal(ProfileState.permissions);
  readonly rights: Signal<IRights> = computed(
    () => this.permissions()?.rights(ACCOUNTS_ENDPOINTS.facilityFormsAndFields) || {}
  );
  readonly query: Signal<ICustomFieldsTableQuery> = this.store.selectSignal(FacilityFieldsState.query);

  constructor(
    private readonly store: Store,
    private readonly modalService: ModalsV2Service,
    private readonly destroyRef: DestroyRef,
    private readonly actions: Actions
  ) {
    this.actions.pipe(ofActionDispatched(FacilityFieldsActions.ReloadFields), takeUntilDestroyed()).subscribe(() => {
      this.getFacilityFields();
    });

    destroyRef.onDestroy(() => {
      this.store.dispatch(new FacilityFieldsActions.ClearData());
    });
  }

  ngOnInit(): void {
    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.fieldBuilder }));
  }

  getFacilityFields(offset?: number): void {
    this.store.dispatch(
      new FacilityFieldsActions.GetFields({
        id: this.facilityId(),
        limit: this.limit(),
        offset: offset || 0,
      })
    );
  }

  handleSortChange(sort: ISort): void {
    this.store.dispatch(new FacilityFieldsActions.UpdateSort(sort));
  }

  handleInfinityScroll(offset: number): void {
    this.getFacilityFields(offset);
  }

  handleScrolledDistanceChange(scrolledDistance: number): void {
    this.store.dispatch(new FacilityFieldsActions.UpdateScrolledDistance(scrolledDistance));
  }

  handleQueryChange(query: ICustomFieldsTableQuery): void {
    this.store.dispatch(new FacilityFieldsActions.UpdateQuery(query));
  }

  handleFieldChange({ item, key, value, control }: ItemChangeEvent<ICustomFormField>): void {
    const changeConfig = {
      emitViewToModelChange: false,
      emitModelToViewChange: true,
      emitEvent: false,
    };

    const field: ICustomFormField = {
      ...item,
      [key]: value,
    };

    this.store.dispatch(new FacilityFieldsActions.UpdateField(field)).subscribe({
      error: () => {
        control.setValue(item[key], changeConfig);
      },
    });
  }

  handleCloneField(field: ICustomFormField): void {
    this.modalService
      .open(CloneFieldModalComponent, {
        listenBackdrop: false,
        data: {
          field: field,
        },
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.store.dispatch(new FacilityFieldsActions.ReloadFields());
      });
  }

  handleEditField(field: ICustomFormField): void {
    this.modalService
      .open(CreateFieldModalComponent, {
        listenBackdrop: false,
        data: createFieldModalData({
          level: 'facility',
          field: field,
        }),
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.store.dispatch(new FacilityFieldsActions.ReloadFields());
      });
  }

  handleDeleteField(field: ICustomFormField): void {
    this.modalService
      .confirm({
        title: 'Delete',
        message: `Are you sure you want to delete this field ${field.label} ?`,
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(
          new FacilityFieldsActions.DeleteField({
            id: field.id,
          })
        );
      });
  }
}
