import { Component, Input } from '@angular/core';

import { ITableColumnWidth } from '../../../../../../../../core/models/types/tables';

@Component({
  selector: 'app-departments-table-header',
  templateUrl: './departments-table-header.component.html',
  styleUrls: ['./departments-table-header.component.scss'],
  standalone: false,
})
export class DepartmentsTableHeaderComponent {
  @Input() displayedColumnsMap: { [key: string]: number } = {};
  @Input() columnsWidth: ITableColumnWidth = {};
}
