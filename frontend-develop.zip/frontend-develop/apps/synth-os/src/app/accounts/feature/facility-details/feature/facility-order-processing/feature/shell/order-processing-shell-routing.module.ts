import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { OrderProcessingShellComponent } from './order-processing-shell.component';

const routes: Routes = [
  {
    path: '',
    component: OrderProcessingShellComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrderProcessingShellRoutingModule {}
