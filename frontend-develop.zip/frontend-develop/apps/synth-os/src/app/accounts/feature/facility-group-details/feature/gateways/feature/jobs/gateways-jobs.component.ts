import { ChangeDetectionStrategy, Component, DestroyRef, inject, OnInit, Signal, OnDestroy } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store } from '@ngxs/store';

import { GATEWAY_JOB_STATE_OPTIONS, GatewayJob } from '@synth/api';
import { IPagination, WeakPaginationStrategy } from '@synth/utils/feature/pagination';

import { BasicTableComponent } from '../../../../../../../shared/ui/components/basic-table/basic-table.component';
import {
  ColumnsConfig,
  ColumnType,
  SearchType,
} from '../../../../../../../shared/ui/components/basic-table/basic-table.types';
import { AppDatePipe } from '../../../../../../../shared/ui/pipes/date.pipe';
import { FullNamePipe } from '../../../../../../../shared/ui/pipes/full-name.pipe';
import { GatewaysJobsActions } from '../../data-access/gateways-jobs.actions';
import { GatewaysJobsState } from '../../data-access/gateways-jobs.state';
import { GatewayJobStateCellComponent } from '../../ui/gateway-job-state-cell/gateway-job-state-cell.component';

@Component({
  selector: 'synth-gateways-jobs',
  templateUrl: './gateways-jobs.component.html',
  styleUrls: ['./gateways-jobs.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [BasicTableComponent],
})
export class GatewaysJobsComponent implements OnInit, OnDestroy {
  private readonly fullNamePipe = new FullNamePipe();
  private readonly datePipe = new AppDatePipe();
  readonly PAGINATION_STRATEGY = new WeakPaginationStrategy();
  readonly COLUMN_CONFIG: ColumnsConfig<GatewayJob> = [
    {
      key: 'mrn',
      label: 'MRN',
      type: ColumnType.text,
      width: 'grow',
      search: {
        type: SearchType.text,
        key: 'mrn',
        placeholder: '',
      },
      transform: (value) => value.mrn.toString(),
    },
    {
      key: 'acc',
      label: 'Accession',
      type: ColumnType.text,
      width: 'grow',
      search: {
        type: SearchType.text,
        key: 'acc',
        placeholder: '',
      },
      transform: (value) => value.acc.toString(),
    },
    {
      key: 'patientName',
      label: 'Patient Name',
      type: ColumnType.text,
      width: 'grow',
      search: {
        type: SearchType.text,
        key: 'patientName',
        placeholder: '',
      },
      transform: (value) => this.fullNamePipe.transform(value.patient),
    },
    {
      key: 'queuedDate',
      label: 'Queued Date',
      type: ColumnType.text,
      width: 130,
      search: {
        type: SearchType.date,
        key: 'queuedDate',
        placeholder: '',
      },
      transform: (value) => this.datePipe.transform(value.queuedDate),
    },
    {
      key: 'startedDate',
      label: 'Started Date',
      type: ColumnType.text,
      width: 130,
      search: {
        type: SearchType.date,
        key: 'startedDate',
        placeholder: '',
      },
      transform: (value) => this.datePipe.transform(value.startedDate),
    },
    {
      key: 'completedDate',
      label: 'Completed Date',
      type: ColumnType.text,
      width: 130,
      search: {
        type: SearchType.date,
        key: 'completedDate',
        placeholder: '',
      },
      transform: (value) => this.datePipe.transform(value.completedDate),
    },
    {
      key: 'studyId',
      label: 'Study Instance UID',
      type: ColumnType.text,
      width: 'grow',
      search: {
        type: SearchType.text,
        key: 'studyId',
        placeholder: '',
      },
      transform: (value) => value.studyId.toString(),
    },
    {
      key: 'facilityName',
      label: 'Facility',
      type: ColumnType.text,
      width: 200,
      search: {
        type: SearchType.text,
        key: 'facilityName',
        placeholder: '',
      },
      transform: (value) => value.facility.name.toString(),
    },
    {
      key: 'destination',
      label: 'Destination',
      type: ColumnType.text,
      width: 200,
      search: {
        type: SearchType.text,
        key: 'destination',
        placeholder: '',
      },
      transform: (value) => value.gatewayDestination.name.toString(),
    },
    {
      key: 'state',
      label: 'State',
      type: ColumnType.component,
      width: 130,
      search: {
        type: SearchType.select,
        multiple: true,
        options: GATEWAY_JOB_STATE_OPTIONS,
        key: 'state',
        placeholder: ' ',
      },
      component: GatewayJobStateCellComponent,
    },
  ];

  private readonly store: Store = inject(Store);
  private readonly activatedRoute: ActivatedRoute = inject(ActivatedRoute);
  private readonly destroyRef: DestroyRef = inject(DestroyRef);

  readonly jobs: Signal<GatewayJob[]> = this.store.selectSignal(GatewaysJobsState.jobs);
  readonly pagination: Signal<IPagination> = this.store.selectSignal(GatewaysJobsState.pagination);
  readonly loading: Signal<boolean> = this.store.selectSignal(GatewaysJobsState.loading);
  readonly searchState: Signal<Record<string, string | string[]>> = this.store.selectSignal(
    GatewaysJobsState.searchState
  );
  readonly limit: Signal<number> = this.store.selectSignal(GatewaysJobsState.limit);
  readonly granularLoadings: Signal<Record<string, boolean>> = this.store.selectSignal(
    GatewaysJobsState.granularLoadings
  );

  ngOnInit(): void {
    this.activatedRoute.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((paramMap: ParamMap) => {
      const facilityGroupId = parseInt(paramMap.get('id'), 10);

      this.store.dispatch(new GatewaysJobsActions.Init(facilityGroupId));
      this.store.dispatch(new GatewaysJobsActions.Get());
    });
  }

  handleInfinityScroll(offset: number): void {
    this.store.dispatch(new GatewaysJobsActions.Paginate(offset));
  }

  handleQueryChange(query: Record<string, string | string[]>): void {
    this.store.dispatch(new GatewaysJobsActions.Search(query));
  }

  ngOnDestroy(): void {
    this.store.dispatch(new GatewaysJobsActions.ClearData());
  }
}
