import { GatewayDestination } from '@synth/api';

const ACTION_SCOPE = '[Gateways Destinations]';

export namespace GatewaysDestinationsActions {
  export class Init {
    static readonly type = `${ACTION_SCOPE} Init`;
    constructor(public payload: number) {}
  }

  export class Get {
    static readonly type = `${ACTION_SCOPE} Get`;
  }

  export class Search {
    static readonly type = `${ACTION_SCOPE} Search`;
    constructor(public payload: Record<string, string | string[]>) {}
  }

  export class Paginate {
    static readonly type = `${ACTION_SCOPE} Paginate`;
    constructor(public payload: number) {}
  }

  export class UpdateStatus {
    static readonly type = `${ACTION_SCOPE} Update Status`;
    constructor(public payload: { destination: any; isActive: boolean }) {}
  }

  export class CreateDestination {
    static readonly type = `${ACTION_SCOPE} Create Destination`;
    constructor(public payload: Omit<GatewayDestination, 'id' | 'isActive'>) {}
  }

  export class UpdateDestination {
    static readonly type = `${ACTION_SCOPE} Update Destination`;
    constructor(public payload: { original: GatewayDestination; body: Omit<GatewayDestination, 'isActive'> }) {}
  }

  export class ClearData {
    static readonly type = `${ACTION_SCOPE} Clear Data`;
  }
}
