import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { GroupOrderDataExportComponent } from './group-order-data-export.component';
import { AppDatepickerComponent } from '../../../../../shared/ui/components/controls/datepicker/datepicker.component';
import { OldRadioButtonComponent } from '../../../../../shared/ui/components/controls/radio/radio-button/radio-button.component';
import { FacilitySelectV2Component } from '../../../../../shared/ui/components/controls/selects/facility-select-v2/facility-select-v2.component';
import { SelectComponent } from '../../../../../shared/ui/components/controls/selects/select/select.component';
import { ControlErrorV2DirectiveModule } from '../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';

const routes: Routes = [
  {
    path: '',
    component: GroupOrderDataExportComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class OrderDataExportRoutingModule {}

@NgModule({
  declarations: [GroupOrderDataExportComponent],
  imports: [
    CommonModule,
    OrderDataExportRoutingModule,
    ReactiveFormsModule,
    ButtonsModule,
    AppDatepickerComponent,
    SelectComponent,
    FacilitySelectV2Component,
    ControlErrorV2DirectiveModule,
    OldRadioButtonComponent,
  ],
})
export class GroupOrderDataExportModule {}
