import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination, PaginationStrategiesNames, PAGINATION } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { AlgorithmService } from '../../../../../core/http-services/algorithm.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IAlgorithm } from '../../../../../core/models/types/algorithm';
import { ISort } from '../../../../../core/models/types/common';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { AlgorithmsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/algorithms.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { AlgorithmsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/algorithms.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';
import { CreateAlgorithmModalComponent } from '../../ui/create-algorithm-modal/create-algorithm-modal.component';

@Component({
  selector: 'app-group-algorithms',
  templateUrl: './group-algorithms.component.html',
  styleUrls: ['./group-algorithms.component.scss'],
  standalone: false,
})
export class GroupAlgorithmsComponent implements OnInit, OnDestroy {
  readonly ACTION_ICONS = ICONS.actionsV2;
  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly algorithms$: Observable<IAlgorithm[]> = this.store.select(AlgorithmsState.algorithms);
  readonly isAlgorithmsLoading$: Observable<boolean> = this.store.select(AlgorithmsState.isLoading);
  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);
  readonly pagination$: Observable<IPagination> = this.store.select(AlgorithmsState.pagination);
  readonly sort$: Observable<ISort> = this.store.select(AlgorithmsState.sort);

  @Input() paginationStrategy: PaginationStrategiesNames = PaginationStrategiesNames.weak;

  groupId: number;
  algorithms: IAlgorithm[] = [];
  isLoading: boolean;
  pagination: IPagination = PAGINATION;
  sorting: ISort;
  limit = 20;

  canShowActions: boolean;

  groupAlgorithmsPermissions: IPermissionsConfig = {
    canEdit: {
      [ACCOUNTS_ENDPOINTS.algorithms]: false,
    },
    canDelete: {
      [ACCOUNTS_ENDPOINTS.algorithms]: false,
    },
  };

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private algorithmService: AlgorithmService,
    private modalsService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.algorithm }));
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new AlgorithmsActions.SetLimit({ limit: this.limit }));

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.canShowActions =
          permissions.canEdit(ACCOUNTS_ENDPOINTS.algorithms) || permissions.canDelete(ACCOUNTS_ENDPOINTS.algorithms);
        this.groupAlgorithmsPermissions = PermissionsClass.updatePermissions(
          permissions,
          this.groupAlgorithmsPermissions
        );
      });

    this.algorithms$.pipe(takeUntil(this.unsubscribe$$)).subscribe((response) => {
      this.algorithms = response;
    });

    this.isAlgorithmsLoading$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((isLoading) => (this.isLoading = isLoading));

    this.facilityGroupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((groupId) => {
      this.groupId = groupId;

      if (groupId) {
        this.store.dispatch(new AlgorithmsActions.GetAlgorithms({ id: groupId }));
      }
    });

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort) => (this.sorting = sort));
  }

  confirmAlgorithmDeletion(id: number): void {
    this.modalsService
      .confirm({
        title: 'Delete',
        message: 'Are you sure to delete algorithm?',
        cancelButton: 'No',
        confirmationButton: 'Delete',
      })
      .pipe(filter((result) => result === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => this.deleteAlgorithm(id));
  }

  private deleteAlgorithm(id: number): void {
    this.algorithmService.deleteAlgorithm(id, { autoNotifyErrors: false }).subscribe(
      () => this.store.dispatch(new AlgorithmsActions.GetAlgorithms({ id: this.groupId })),
      (error) => this.modalsService.error(error.message)
    );
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new AlgorithmsActions.UpdatePagination({
        offset: offset,
        page: this.pagination.page + 1,
      })
    );
  }

  sortAlgorithms(sort: ISort): void {
    this.store.dispatch(new AlgorithmsActions.UpdateSorting(sort));
  }

  openModalEditAlgorithm(algorithm: IAlgorithm): void {
    this.modalsService
      .open(CreateAlgorithmModalComponent, {
        data: {
          facilityGroupId: this.groupId,
          algorithm,
        },
      })
      .pipe(filter((reload) => !!reload))
      .subscribe(() => this.store.dispatch(new AlgorithmsActions.GetAlgorithms({ id: this.groupId })));
  }

  ngOnDestroy(): void {
    this.store.dispatch(new AlgorithmsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
