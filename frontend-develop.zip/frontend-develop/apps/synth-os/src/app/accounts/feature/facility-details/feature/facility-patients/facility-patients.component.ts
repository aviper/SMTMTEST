import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, skip, takeUntil } from 'rxjs/operators';

import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { PageSavingFeatureClass } from '../../../../../core/helpers/page-saving-feature.class';
import { Patient } from '../../../../../core/models/classes/patient';
import { IHistoryState, ISort } from '../../../../../core/models/types/common';
import { RoutingService } from '../../../../../core/services/routing.service';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityPatientsActions } from '../../../../../core/store/accounts/actions/facility/facility-tabs/facility-patients.actions';
import { FacilityDetailsState } from '../../../../../core/store/accounts/states/facility/facility-details.state';
import { FacilityPatientsState } from '../../../../../core/store/accounts/states/facility/facility-tabs/facility-patients.state';
import { FACILITY_DETAILS_TABS } from '../../../../../shared/utils/constants';

@Component({
  selector: 'app-facility-patients',
  templateUrl: './facility-patients.component.html',
  styleUrls: ['./facility-patients.component.scss'],
  standalone: false,
})
export class FacilityPatientsComponent extends PageSavingFeatureClass implements OnInit, OnDestroy {
  readonly displayedColumns = ['name', 'ssn', 'mrn', 'dob', 'sex'];

  readonly patients$: Observable<{ patients: Patient[]; total: number; isLoading: boolean }> = this.store.select(
    FacilityPatientsState.patients
  );
  readonly isLoading$: Observable<boolean> = this.store.select(FacilityPatientsState.isLoading);
  readonly sort$: Observable<ISort> = this.store.select(FacilityPatientsState.sort);
  readonly reload$: Observable<boolean> = this.store.select(FacilityPatientsState.reload);
  readonly facilityId$: Observable<number> = this.store.select(FacilityDetailsState.facilityId);

  data: Patient[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = false;

  protected historyStateForSaving: IHistoryState = {};
  private unsubscribe$$: Subject<void> = new Subject<void>();
  private facilityId: number;

  constructor(
    protected routingService: RoutingService,
    protected store: Store
  ) {
    super(routingService, store);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.facilityId$
      .pipe(
        filter((facilityId) => !!facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilityId) => {
        this.facilityId = facilityId;
        this.getEmployees(this.pagination.offset);
      });

    this.patients$
      .pipe(
        skip(1),
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.patients;
        this.pagination.total = data.total;

        if (!this.wasLoadedDataFirstTime) {
          this.normalizePaginationAfterLoadData();
        }
        this.wasLoadedDataFirstTime = true;
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading: boolean) => (this.isLoading = isLoading));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort: ISort) => (this.sorting = sort));

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload && !!this.facilityId),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetHistoryState();
        this.getEmployees();
      });

    this.store.dispatch(new FacilityDetailsActions.SetCurrentTab({ tab: FACILITY_DETAILS_TABS.patients }));
  }

  getEmployees(offset?: number): void {
    this.store.dispatch(
      new FacilityPatientsActions.GetPatients({
        id: this.facilityId,
        limit: this.limit,
        offset: offset || 0,
      })
    );
  }

  sortEmployees(sort: ISort): void {
    this.historyStateForSaving.sorting = sort;
    this.store.dispatch(new FacilityPatientsActions.UpdateSorting(sort));
    this.resetHistoryState();
    this.store.dispatch(new FacilityPatientsActions.ReloadPatients());
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    ++this.pagination.page;
    this.historyStateForSaving.page = this.pagination.page;
    this.getEmployees(this.pagination.offset);
  }

  onScroll(scroll: number): void {
    this.historyStateForSaving.scroll = scroll;
    this.scrolledDistance = 0;
  }

  protected initPageMetaData(): void {
    super.initPageMetaData();
    this.store.dispatch(new FacilityPatientsActions.UpdateSorting(this.sorting));
  }

  private resetHistoryState(): void {
    this.pagination = { ...PAGINATION };

    if (this.wasLoadedDataFirstTime) {
      this.scrolledDistance = 0;
      this.historyStateForSaving.scroll = 0;
      this.historyStateForSaving.page = 1;
    }
  }

  ngOnDestroy(): void {
    this.store.dispatch(new FacilityPatientsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
