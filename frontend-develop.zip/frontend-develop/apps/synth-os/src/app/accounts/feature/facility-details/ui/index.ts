import { AddContactModalComponent } from './add-contact-modal/add-contact-modal.component';
import { AddNotificationModalComponent } from './add-notification-modal/add-notification-modal.component';
import { FacilityDetailsBlockComponent } from './facility-details-block/facility-details-block.component';
import { FacilityHeaderComponent } from './facility-header/facility-header.component';
import { FacilityNotesBlockComponent } from './facility-notes-block/facility-notes-block.component';
import { FacilityPictureBlockComponent } from './facility-picture-block/facility-picture-block.component';
import { SlaSettingsBlockComponent } from './sla-settings-block/sla-settings-block.component';
import { UpdateReportModalComponent } from './update-report-modal/update-report-modal.component';

export const FACILITY_DETAILS_UI_COMPONENTS: any[] = [
  UpdateReportModalComponent,
  FacilityDetailsBlockComponent,
  FacilityHeaderComponent,
  FacilityNotesBlockComponent,
  FacilityPictureBlockComponent,
  SlaSettingsBlockComponent,
  AddNotificationModalComponent,
  AddContactModalComponent,
];
