import { Component, OnInit, OnDestroy, Input, ViewChild, TemplateRef, AfterViewInit, NgZone } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';

import { IPagination, PaginationStrategiesNames, PAGINATION } from '@synth/utils/feature/pagination';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { TABLE_TYPE } from '../../../../../core/constants/table-constants';
import { ContractHoldersService } from '../../../../../core/http-services/contract-holders.service';
import { TableSettingsService } from '../../../../../core/http-services/table-settings.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IListResponse, IOption, ISort } from '../../../../../core/models/types/common';
import { IFacility } from '../../../../../core/models/types/facility';
import { ITableSetting } from '../../../../../core/models/types/tables';
import { TemplateService } from '../../../../../core/services/template.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilitiesActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facilities.actions';
import { FacilityGroupDetailsState } from '../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { FacilitiesState } from '../../../../../core/store/accounts/states/facility-group/facility-group-tabs/facilities.state';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { FACILITY_GROUP_TABS } from '../../../../utils/constants';

@Component({
  selector: 'app-group-facilities',
  templateUrl: './group-facilities.component.html',
  styleUrls: ['./group-facilities.component.scss'],
  standalone: false,
})
export class GroupFacilitiesComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly facilities$: Observable<IFacility[]> = this.store.select(FacilitiesState.facilities);
  readonly isFacilityLoading$: Observable<boolean> = this.store.select(FacilitiesState.isLoading);
  readonly pagination$: Observable<IPagination> = this.store.select(FacilitiesState.pagination);
  readonly sort$: Observable<ISort> = this.store.select(FacilitiesState.sort);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facilityGroupId$: Observable<number> = this.store.select(FacilityGroupDetailsState.facilityGroupId);

  @ViewChild('header', { static: false }) headerTemplate: TemplateRef<any>;

  @Input() paginationStrategy: PaginationStrategiesNames = PaginationStrategiesNames.weak;

  readonly TABLE_TYPE = TABLE_TYPE.facilities;
  data: IFacility[] = [];
  isLoading = true;
  pagination: IPagination = { ...PAGINATION };
  tableSettings: ITableSetting[] = [];
  limit: number;
  sorting: ISort;
  contractHolderOptions: IOption[];
  canUpdateFacility = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private tableSettingsService: TableSettingsService,
    private store: Store,
    private zone: NgZone,
    private templateService: TemplateService,
    private contractHoldersService: ContractHoldersService
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.facility }));

    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(new FacilitiesActions.SetLimit(this.limit));

    this.facilities$.pipe(takeUntil(this.unsubscribe$$)).subscribe((response) => {
      this.data = response;
    });

    this.isFacilityLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.facilityGroupId$.pipe(takeUntil(this.unsubscribe$$)).subscribe((groupId) => {
      if (groupId) {
        this.store.dispatch(new FacilitiesActions.GetFacilities());
        this.getGroupContractHolders(groupId);
      }
    });

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort) => (this.sorting = sort));

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (permissions: UserPermissions) => (this.canUpdateFacility = permissions.canEdit(ACCOUNTS_ENDPOINTS.facilities))
      );

    this.loadTableSettings();
  }

  ngAfterViewInit(): void {
    this.zone.onStable.pipe(take(1)).subscribe(() => this.templateService.setTemplateRef(this.headerTemplate));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new FacilitiesActions.UpdatePagination({
        offset: offset,
        page: this.pagination.page + 1,
      })
    );
  }

  sortFacilities(sort: ISort): void {
    this.store.dispatch(new FacilitiesActions.UpdateSorting(sort));
  }

  private loadTableSettings(): void {
    this.tableSettingsService.getSettings(this.TABLE_TYPE).subscribe((res: IListResponse) => {
      this.tableSettings = res.data;
    });
  }

  private getGroupContractHolders(groupId: number): void {
    this.contractHoldersService
      .getHolders({
        facilityGroupId: groupId,
        limit: 100,
      })
      .subscribe((response: IListResponse) => {
        this.contractHolderOptions = [
          { value: null, label: 'Not selected' },
          ...response.data.map((option) => ({ value: option.id, label: option.name })),
        ];
      });
  }

  ngOnDestroy(): void {
    this.templateService.setTemplateRef(null);
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
