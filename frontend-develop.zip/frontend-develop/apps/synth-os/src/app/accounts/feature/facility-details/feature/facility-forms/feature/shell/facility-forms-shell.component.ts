import { Component, OnDestroy } from '@angular/core';
import { Store } from '@ngxs/store';

import { ITabMenuItem } from '../../../../../../../core/models/types/common';
import { FacilityFieldsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-fields.actions';
import { FacilityFormsActions } from '../../../../../../../core/store/accounts/actions/facility/facility-tabs/facility-forms.actions';

@Component({
  selector: 'app-facility-forms-shell',
  templateUrl: './facility-forms-shell.component.html',
  styleUrls: ['./facility-forms-shell.component.scss'],
  standalone: false,
})
export class FacilityFormsShellComponent implements OnDestroy {
  readonly formBuilderTabs: ITabMenuItem[] = [
    {
      title: 'Forms',
      value: 'forms',
      available: true,
      counter: null,
    },
    {
      title: 'Fields',
      value: 'fields',
      available: true,
      counter: null,
    },
  ];

  constructor(private readonly store: Store) {}

  ngOnDestroy(): void {
    this.store.dispatch(new FacilityFieldsActions.ClearData());
    this.store.dispatch(new FacilityFormsActions.ClearData());
  }
}
