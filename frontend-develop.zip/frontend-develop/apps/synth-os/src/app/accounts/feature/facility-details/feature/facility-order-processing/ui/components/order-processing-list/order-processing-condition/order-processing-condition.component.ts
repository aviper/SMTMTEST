import { Component, EventEmitter, Input, Output } from '@angular/core';
import { filter } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../../../core/constants/icon-list';
import {
  IOrderProcessingItemCondition,
  OrderProcessingConditionType,
} from '../../../../../../../../../core/models/types/orders-processing';
import { SpecifyConditionModalComponent } from '../../specify-condition-modal/specify-condition-modal.component';

@Component({
  selector: 'app-order-processing-condition',
  templateUrl: './order-processing-condition.component.html',
  styleUrls: ['./order-processing-condition.component.scss'],
  standalone: false,
})
export class OrderProcessingConditionComponent {
  ICON_PEN = ICONS.pen;
  @Input() mode: 'header' | 'body' = 'body';
  @Input() condition: IOrderProcessingItemCondition[];
  @Input() canAdd = false;
  @Input() conditionsType: OrderProcessingConditionType[] = [];
  @Input() isRuleActionNormalize = false;
  @Input() facilityId: number = null;

  @Output() conditionChange: EventEmitter<IOrderProcessingItemCondition[]> = new EventEmitter<
    IOrderProcessingItemCondition[]
  >();

  constructor(private modalsV2Service: ModalsV2Service) {}

  changeCondition(): void {
    this.canAdd &&
      this.modalsV2Service
        .open(SpecifyConditionModalComponent, {
          data: {
            condition: this.condition,
            treeConditionsType: this.conditionsType,
            isRuleActionNormalize: this.isRuleActionNormalize,
            facilityId: this.facilityId,
          },
        })
        .pipe(filter((data) => !!data))
        .subscribe((res) => this.conditionChange.emit(res));
  }
}
