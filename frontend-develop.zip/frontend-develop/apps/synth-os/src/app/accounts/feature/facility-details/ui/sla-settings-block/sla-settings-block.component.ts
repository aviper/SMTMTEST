import { Component } from '@angular/core';
import { AbstractControl, UntypedFormArray, UntypedFormBuilder, UntypedFormControl, Validators } from '@angular/forms';
import { Store } from '@ngxs/store';

import { ModalsV2Service } from '@synth/ui/modals';

import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { IFacility, ITat, ITatForAPI } from '../../../../../core/models/types/facility';
import { ConverterService } from '../../../../../core/services/converter.service';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityEditableBlockClass } from '../../../../utils/facility-editable-block.class';

@Component({
  selector: 'app-sla-settings-block',
  templateUrl: './sla-settings-block.component.html',
  styleUrls: ['./sla-settings-block.component.scss'],
  standalone: false,
})
export class SlaSettingsBlockComponent extends FacilityEditableBlockClass {
  slaFormArray: UntypedFormArray;
  applyAVDelayControl: UntypedFormControl;
  tats: (ITat & { correctTime: string; correctAutoValidationDelay: string })[] = [];

  constructor(
    private fb: UntypedFormBuilder,
    private facilityService: FacilitiesService,
    private modalsService: ModalsV2Service,
    private store: Store
  ) {
    super();
  }

  protected createForm(params?: any): void {
    this.form = this.fb.group({
      sla: this.fb.array([]),
      applyAVDelay: [false, [Validators.required]],
    });
    this.slaFormArray = this.form.get('sla') as UntypedFormArray;
    this.applyAVDelayControl = this.form.get('applyAVDelay') as UntypedFormControl;
  }

  submit(fieldName?: string): void {
    if (!fieldName) {
      return;
    }

    const value = this.form.get(fieldName).value;

    this.store.dispatch(new FacilityDetailsActions.PatchUpdate({ [fieldName]: value }));
  }

  submitSLA(): void {
    const preparedTats = this.prepareTats(this.slaFormArray.value);

    if (!this.slaFormArray.valid || !this.isValueChanged(preparedTats)) {
      this.createControlsFromTats();

      return;
    }

    this.store.dispatch(new FacilityDetailsActions.PatchUpdate({ sla: preparedTats }));
  }

  protected updateForm(facility: IFacility): void {
    this.tats = facility.sla.map((tat) => ({
      ...tat,
      correctTime: this.correctTatTime(tat.value),
      correctAutoValidationDelay: this.correctAutoAVDelayTime(tat.autoValidationDelay),
    }));
    this.createControlsFromTats();
    this.applyAVDelayControl.setValue(facility.applyAVDelay);
  }

  private createControlsFromTats(): void {
    this.slaFormArray.clear();
    this.tats.forEach((tat) => {
      this.slaFormArray.push(
        this.fb.group({
          slaTime: this.fb.control(tat.correctTime),
          autoValidationDelay: this.fb.control(tat.correctAutoValidationDelay ?? '00:01', [Validators.required]),
        })
      );
    });
  }

  private prepareTats(formTats: { slaTime: string; autoValidationDelay: string }[]): ITat[] {
    return formTats.map(({ slaTime, autoValidationDelay }, i) => ({
      ...this.tats[i],
      correctTime: undefined,
      correctAutoValidationDelay: undefined,
      value: slaTime ? ConverterService.hoursAndMinutesStringToSeconds(slaTime) : null,
      autoValidationDelay: autoValidationDelay
        ? ConverterService.minutesAndSecondsStringToMilliseconds(autoValidationDelay)
        : null,
    }));
  }

  private correctAutoAVDelayTime(milliseconds: number): string {
    const seconds = milliseconds / 1000;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${this.pad(minutes)}:${this.pad(remainingSeconds)}`;
  }

  private correctTatTime(secs: number): string {
    let minutes = Math.ceil(secs / 60);
    const hours = Math.floor(minutes / 60);

    minutes = minutes % 60;

    return `${this.pad(hours)}:${this.pad(minutes)}`;
  }

  private pad(num: number): string {
    return ('0' + num).slice(-2);
  }

  private isValueChanged(preparedTats: ITatForAPI[]): boolean {
    for (let i = 0; i < this.tats.length; ++i) {
      if (
        this.tats[i].value !== preparedTats[i].value ||
        this.tats[i].autoValidationDelay !== preparedTats[i].autoValidationDelay
      ) {
        return true;
      }
    }

    return false;
  }

  toFormControl(control: AbstractControl): UntypedFormControl {
    return control as UntypedFormControl;
  }
}
