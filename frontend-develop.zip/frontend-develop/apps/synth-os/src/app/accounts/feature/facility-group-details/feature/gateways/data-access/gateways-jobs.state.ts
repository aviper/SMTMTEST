import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import {
  ApiClientService,
  ApiItemResponse,
  ApiListResponse,
  GatewayJob,
  getGatewayJobsEndpoint,
  retryGatewayJobEndpoint,
} from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { GatewaysJobsActions } from './gateways-jobs.actions';
import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';

export interface GatewaysJobsStateModel {
  jobs: GatewayJob[];
  pagination: IPagination;
  searchState: Record<string, string | string[]>;
  loading: boolean;
  limit: number;
  groupId: number | null;
  granularLoadings: Record<string, boolean>;
}

const DEFAULT_STATE: GatewaysJobsStateModel = {
  groupId: null,
  jobs: [],
  pagination: { ...PAGINATION },
  searchState: {},
  loading: false,
  limit: DEFAULT_LIMIT,
  granularLoadings: {},
};

@State<GatewaysJobsStateModel>({
  name: 'gatewaysJobs',
  defaults: { ...DEFAULT_STATE },
})
@Injectable()
export class GatewaysJobsState {
  @Selector()
  static jobs(state: GatewaysJobsStateModel): GatewayJob[] {
    return state.jobs;
  }

  @Selector()
  static pagination(state: GatewaysJobsStateModel): IPagination {
    return state.pagination;
  }

  @Selector()
  static searchState(state: GatewaysJobsStateModel): Record<string, string | string[]> {
    return state.searchState;
  }

  @Selector()
  static loading(state: GatewaysJobsStateModel): boolean {
    return state.loading;
  }

  @Selector()
  static limit(state: GatewaysJobsStateModel): number {
    return state.limit;
  }

  @Selector()
  static granularLoadings(state: GatewaysJobsStateModel): Record<string, boolean> {
    return state.granularLoadings;
  }

  constructor(
    private apiClient: ApiClientService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(GatewaysJobsActions.Init)
  init(ctx: StateContext<GatewaysJobsStateModel>, action: GatewaysJobsActions.Init): void {
    ctx.patchState({ ...DEFAULT_STATE, groupId: action.payload });
  }

  @Action(GatewaysJobsActions.Get)
  get(ctx: StateContext<GatewaysJobsStateModel>): Observable<ApiListResponse<GatewayJob>> {
    const { limit, pagination, groupId } = ctx.getState();

    if (!groupId) {
      console.error('Facility Group ID is not set. Cannot fetch gateway jobs.');

      return of(null);
    }

    ctx.patchState({ loading: true, ...(!pagination.offset ? { jobs: [] } : {}) });

    return this.apiClient
      .exec(getGatewayJobsEndpoint, {
        params: {
          facilityGroupId: groupId,
          limit,
          offset: pagination.offset,
          ...ctx.getState().searchState,
        },
      })
      .pipe(
        tap({
          next: (response) => {
            ctx.patchState({
              jobs: pagination.offset ? ctx.getState().jobs.concat(response.data) : response.data,
              loading: false,
              pagination: {
                ...pagination,
                lastChunkSize: response.data.length,
              },
            });
          },
          error: (error) => {
            this.modalsService.error(error.message);
            ctx.patchState({ loading: false, jobs: [] });
          },
        })
      );
  }

  @Action(GatewaysJobsActions.Search)
  search(ctx: StateContext<GatewaysJobsStateModel>, action: GatewaysJobsActions.Search): void {
    const searchState = ctx.getState().searchState;

    ctx.patchState({
      searchState: {
        ...searchState,
        ...action.payload,
      },
      pagination: { ...PAGINATION },
    });

    ctx.dispatch(new GatewaysJobsActions.Get());
  }

  @Action(GatewaysJobsActions.Paginate)
  paginate(ctx: StateContext<GatewaysJobsStateModel>, action: GatewaysJobsActions.Paginate): void {
    const pagination = ctx.getState().pagination;

    ctx.patchState({
      pagination: {
        ...pagination,
        offset: action.payload,
      },
    });

    ctx.dispatch(new GatewaysJobsActions.Get());
  }

  @Action(GatewaysJobsActions.RetryJob)
  retryJob(
    ctx: StateContext<GatewaysJobsStateModel>,
    action: GatewaysJobsActions.RetryJob
  ): Observable<ApiItemResponse<GatewayJob>> {
    ctx.patchState({
      granularLoadings: {
        ...ctx.getState().granularLoadings,
        [action.payload]: true,
      },
    });

    return this.apiClient.exec(retryGatewayJobEndpoint, { params: { jobId: action.payload } }).pipe(
      tap({
        next: (response) => {
          const jobs = ctx.getState().jobs;

          ctx.patchState({
            jobs: jobs.map((job) => (job.id === response.data.id ? response.data : job)),
            granularLoadings: {
              ...ctx.getState().granularLoadings,
              [action.payload]: false,
            },
          });
        },
        error: (error) => {
          this.modalsService.error(error.message);
          ctx.patchState({
            granularLoadings: {
              ...ctx.getState().granularLoadings,
              [action.payload]: false,
            },
          });
        },
      })
    );
  }

  @Action(GatewaysJobsActions.ClearData)
  clearData(ctx: StateContext<GatewaysJobsStateModel>): void {
    ctx.patchState({ ...DEFAULT_STATE });
  }
}
