import { Component, OnDestroy, OnInit } from '@angular/core';
import { Actions, ofActionDispatched, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/internal/operators/takeUntil';
import { filter } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { CACHE_KEYS } from '../../../../../../../core/constants/caching-keys';
import { FACILITY_GROUP_TABS } from '../../../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../../../core/constants/endpoints';
import { FacilitiesService } from '../../../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../../../core/models/classes/userPermissions';
import { IFacilityGroup, IReportHeaderTemplate } from '../../../../../../../core/models/types/facility';
import { CachingService } from '../../../../../../../core/services/caching.service';
import { AccountsCommonActions } from '../../../../../../../core/store/accounts/actions/common.actions';
import { FacilityGroupDetailsActions } from '../../../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { FacilityGroupDetailsState } from '../../../../../../../core/store/accounts/states/facility-group/facility-group-details.state';
import { ProfileState } from '../../../../../../../profile/data-access/state/profile/profile.state';

@Component({
  selector: 'app-group-report-header',
  templateUrl: './group-report-header-shell.component.html',
  styleUrls: ['./group-report-header-shell.component.scss'],
  host: { class: 'custom-scroll' },
  standalone: false,
})
export class GroupReportHeaderShellComponent implements OnInit, OnDestroy {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  facilityGroup: IFacilityGroup;
  permissions: UserPermissions = new UserPermissions();
  canEdit = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected facilitiesService: FacilitiesService,
    protected modalsService: ModalsV2Service,
    protected actions: Actions,
    protected cachingService: CachingService,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.SetCurrentTab({ tab: FACILITY_GROUP_TABS.reportHeader }));

    this.facilityGroup$
      .pipe(
        filter((facilityGroup) => !!facilityGroup),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facilitiyGroup) => {
        this.facilityGroup = facilitiyGroup;
      });

    this.actions
      .pipe(ofActionDispatched(AccountsCommonActions.FGUpdated), takeUntil(this.unsubscribe$$))
      .subscribe(() => {
        this.cachingService.cleanCacheForKeys(CACHE_KEYS.reportHeader);
      });

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => (this.canEdit = permissions.canEdit(ACCOUNTS_ENDPOINTS.groups)));
  }

  onReportUploaded(reportHeader: IReportHeaderTemplate): void {
    this.store.dispatch(new FacilityGroupDetailsActions.UpdateReportHeader({ reportHeader }));
  }

  onReportDeleted(): void {
    this.store.dispatch(new FacilityGroupDetailsActions.UpdateReportHeader({ reportHeader: null }));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
