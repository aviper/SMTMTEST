import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, Validators } from '@angular/forms';
import { FacilitiesPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { isEqual } from 'lodash-es';
import { Observable, Subject } from 'rxjs';
import { debounceTime, filter, finalize, takeUntil } from 'rxjs/operators';

import { CONFIRM_POPUP_RESPONSE, ModalsV2Service } from '@synth/ui/modals';

import { buildEnvironment } from '../../../../../../environments/environment';
import {
  CLIENT_EXTERNAL_REPORTING_OPTIONS,
  EXTERNAL_REPORTING_OPTIONS,
  FACILITY_REQUESTED_READ_TYPE_OPTIONS,
  HL7_RESEND_REPORT_TYPE,
} from '../../../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IOption } from '../../../../../core/models/types/common';
import { REPORT_PROCEDURE_TYPE } from '../../../../../core/models/types/enums';
import { IFacility } from '../../../../../core/models/types/facility';
import { FacilityDetailsActions } from '../../../../../core/store/accounts/actions/facility/facility-details.actions';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { FacilityEditableBlockClass } from '../../../../utils/facility-editable-block.class';

@Component({
  selector: 'app-facility-details-block',
  templateUrl: './facility-details-block.component.html',
  styleUrls: ['./facility-details-block.component.scss'],
  standalone: false,
})
export class FacilityDetailsBlockComponent extends FacilityEditableBlockClass implements OnInit {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;
  readonly LABEL_TOOLTIPS = {
    hl7: 'Move orders directly to inflight upon receipt of tech complete HL7 message.',
    protect: 'This option will allow to block deleting of Facility',
    fuzzyComparison: 'When enabled, comparisons will be shown from patients with the same name and date of birth.',
  };

  readonly procedureTypesOptions = [
    {
      label: 'Client Exam Type',
      value: REPORT_PROCEDURE_TYPE.clientProcedureType,
    },
    {
      label: 'Platform Exam Type',
      value: REPORT_PROCEDURE_TYPE.synthOsProcedureType,
    },
    {
      label: REPORT_PROCEDURE_TYPE.both,
      value: REPORT_PROCEDURE_TYPE.both,
    },
  ];

  readonly ianHl7MessageSecondsDelayOption: IOption[] = [
    { label: '30s', value: 30 },
    { label: '60s', value: 60 },
    { label: '120s', value: 120 },
    { label: '150s', value: 150 },
  ];

  readonly readTypeOptions = FACILITY_REQUESTED_READ_TYPE_OPTIONS;
  externalReportingOptions: IOption[];

  isUpdating = false;
  isAcceptExternalMPITriggered = false;
  hl7ReportDeliveryOptionsObj = {
    [HL7_RESEND_REPORT_TYPE.ADDENDUM]: 'Addendum Only',
    [HL7_RESEND_REPORT_TYPE.ALL]: 'Addendum + Original Report',
  };
  hl7ReportDeliveryOptionsArr: IOption[] = Object.keys(this.hl7ReportDeliveryOptionsObj).map((key) => ({
    label: this.hl7ReportDeliveryOptionsObj[key],
    value: key,
  }));
  timeToAssign: UntypedFormControl;

  facilityDetailsBlockPermissions: IPermissionsConfig = {
    canRead: {
      [ACCOUNTS_ENDPOINTS.facilityFormsActivation]: false,
    },
    canEdit: {
      [ACCOUNTS_ENDPOINTS.facilityFormsActivation]: false,
    },
  };

  private switchFlag$$: Subject<void> = new Subject<void>();
  private switchAutoAssign$$: Subject<boolean> = new Subject<boolean>();
  private prevValue: object | null = null;

  constructor(
    private fb: UntypedFormBuilder,
    private store: Store,
    private modalService: ModalsV2Service
  ) {
    super();
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.initSwitchersSubscriptions();

    this.permissions$
      .pipe(
        filter((p) => !!p),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.facilityDetailsBlockPermissions = PermissionsClass.updatePermissions(
          permissions,
          this.facilityDetailsBlockPermissions
        );
      });

    this.externalReportingOptions = EXTERNAL_REPORTING_OPTIONS.filter((o: IOption) =>
      CLIENT_EXTERNAL_REPORTING_OPTIONS[buildEnvironment.client].includes(o.value)
    );
  }

  protected createForm(params?: any): void {
    this.form = this.fb.group({
      name: [
        null,
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilitiesPatterns.name.pattern),
          Validators.minLength(FacilitiesPatterns.name.minLength),
          Validators.maxLength(FacilitiesPatterns.name.maxLength),
        ],
      ],
      typeId: [null, [CustomValidators.required]],
      address: [null, [CustomValidators.required]],
      phone: [null, [CustomValidators.invalidPhoneNumber]],
      email: [null, [CustomValidators.email]],
      website: [null],
      mobile: [null],
      customParser: [null],
      isHeaderOfReportFromGroup: [null],
      outFaxNumber: [null, [CustomValidators.invalidPhoneNumber]],
      autoRadAssign: [null],
      patientOrderAutoAssignment: [null],
      criticalCall: [null],
      protect: [null],
      formsEnabled: [null],
      globalFormsEnabled: [null],
      orderProcessing: [null],
      hl7ReportDelivery: [null],
      autoValidate: [null],
      acceptExternalMpi: [null],
      fuzzyComparisonMatching: [null],
      reportOrderProcedureType: [null],
      sendForms: [null],
      requestedReadType: [null],
      timezoneRegionCity: [null, [CustomValidators.required]],
      externalReporting: [null],
      sendOutboundORMs: [null],
      allowManualQueryRetrieve: [null],
      ianHl7Message: [null],
      ianHl7MessageSecondsDelay: [null],
      externalWorklist: [null],
      adtMessageEnabled: [null],
    });

    this.timeToAssign = new UntypedFormControl(null);
  }

  protected updateForm(facility: IFacility): void {
    const facilityAddress = {
      description: facility?.addressDescription || null,
      addressLine1: facility?.address || null,
      cityId: facility?.cityId || null,
      countryId: facility?.countryId || null,
      postCode: facility?.zipCode || null,
      stateId: facility?.stateId || null,
    };

    this.form.patchValue(
      {
        name: facility.name,
        typeId: facility.typeId,
        address: facilityAddress,
        phone: facility.facilityPhone,
        email: facility.email,
        mobile: facility.mobile,
        customParser: facility.customParser,
        isHeaderOfReportFromGroup: facility.isHeaderOfReportFromGroup,
        autoRadAssign: facility.autoRadAssign,
        patientOrderAutoAssignment: facility.patientOrderAutoAssignment,
        outFaxNumber: facility.outFaxNumber,
        criticalCall: facility.criticalCall,
        protect: facility.protect,
        formsEnabled: facility.formsEnabled,
        globalFormsEnabled: facility.globalFormsEnabled,
        orderProcessing: facility.orderProcessing,
        autoValidate: facility.autoValidate,
        reportOrderProcedureType: facility.reportOrderProcedureType,
        acceptExternalMpi: facility.acceptExternalMpi,
        fuzzyComparisonMatching: facility.fuzzyComparisonMatching,
        website: facility.website,
        sendForms: facility.sendForms,
        requestedReadType: facility.requestedReadType,
        timezoneRegionCity: facility.timezoneRegionCity,
        externalReporting: facility.externalReporting,
        sendOutboundORMs: facility.sendOutboundORMs,
        allowManualQueryRetrieve: facility.allowManualQueryRetrieve,
        ianHl7Message: facility.ianHl7Message,
        ianHl7MessageSecondsDelay: facility.ianHl7MessageSecondsDelay,
        externalWorklist: facility.externalWorklist,
        adtMessageEnabled: facility.adtMessageEnabled,
      },
      { emitEvent: false }
    );

    this.prevValue = this.form.getRawValue();
    this.timeToAssign.patchValue(facility.maxTimeAcceptRequest);
  }

  submit(): void {
    if (!this.prevValue) {
      return;
    }

    const value = this.form.getRawValue();

    const differences = this.getDifferences(this.prevValue, value);

    if (!differences.length) {
      return;
    }

    const isInvalid = differences.some((key) => !!this.form.get(key)?.invalid);

    if (isInvalid) {
      this.updateForm(this.facility);

      return;
    }

    const payload = Object.fromEntries(differences.map((key) => [key, value[key]]));

    if (!!payload.address) {
      this.changeTimeZoneIfAddressWasChanged(payload.address.timezone);
    }
    this.store.dispatch(new FacilityDetailsActions.PatchUpdate(payload));
  }

  private getDifferences(prevValue: object, newValue: object): string[] {
    return Object.keys(prevValue).filter((key) => !isEqual(prevValue[key], newValue[key]));
  }

  private initSwitchersSubscriptions(): void {
    const FIELDS = [
      'mobile',
      'customParser',
      'isHeaderOfReportFromGroup',
      'autoRadAssign',
      'criticalCall',
      'protect',
      'formsEnabled',
      'globalFormsEnabled',
      'patientOrderAutoAssignment',
      'orderProcessing',
      'autoValidate',
      'acceptExternalMpi',
      'fuzzyComparisonMatching',
      'sendForms',
      'externalReporting',
      'sendOutboundORMs',
      'allowManualQueryRetrieve',
      'ianHl7Message',
      'externalWorklist',
      'adtMessageEnabled',
    ];

    FIELDS.forEach((field) => {
      this.form
        .get(field)
        .valueChanges.pipe(takeUntil(this.unsubscribe$$))
        .subscribe(() => this.switchFlag$$.next());
    });

    this.switchFlag$$
      .asObservable()
      .pipe(debounceTime(1000), takeUntil(this.unsubscribe$$))
      .subscribe(() => this.submit());

    this.switchAutoAssign$$
      .asObservable()
      .pipe(debounceTime(500), takeUntil(this.unsubscribe$$))
      .subscribe((checked) => this.changeAutoAssign(checked));
  }

  createFaxNumber(): void {
    this.store.dispatch(new FacilityDetailsActions.GenerateFaxNumber());
  }

  triggerAutoAssign(checked: boolean): void {
    this.switchAutoAssign$$.next(checked);
  }

  changeAutoAssignTime(): void {
    this.store.dispatch(new FacilityDetailsActions.ChangeAutoAssignTime(+this.timeToAssign.value));
  }

  acceptExternalMpi(): void {
    this.isAcceptExternalMPITriggered = true;

    this.modalService
      .confirm({
        title: 'Warning',
        message:
          'Turning this feature on will indicate that we are receiving Patient IDs from your MPI for your patients from an external system. Support will need to be contacted if you wish to disable this feature. Would you like to continue?',
        cancelButton: 'No',
        confirmationButton: 'Yes',
      })
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        finalize(() => (this.isAcceptExternalMPITriggered = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.form.markAsDirty();
        this.form.get('acceptExternalMpi').setValue(true);
      });
  }

  private changeAutoAssign(checked: boolean): void {
    this.store.dispatch(new FacilityDetailsActions.ChangeAutoAssign(checked));
  }

  private changeTimeZoneIfAddressWasChanged(timezone: { timeZoneId: string; status: string }): void {
    if (timezone.status === 'OK') {
      this.store.dispatch(new FacilityDetailsActions.PatchUpdate({ timezoneRegionCity: timezone.timeZoneId }));
    }
  }
}
