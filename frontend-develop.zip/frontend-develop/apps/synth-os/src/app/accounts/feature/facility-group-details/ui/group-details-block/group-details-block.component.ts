import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { FacilityGroupsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { filter, finalize, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { ACCOUNTS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { FormService } from '../../../../../core/services/form.service';
import { FacilityGroupDetailsActions } from '../../../../../core/store/accounts/actions/facility-group/facility-group-details.actions';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { FacilityGroupEditableBlockClass } from '../../../../utils/editable-block.class';

@Component({
  selector: 'app-group-details-block',
  templateUrl: './group-details-block.component.html',
  styleUrls: ['./group-details-block.component.scss'],
  standalone: false,
})
export class GroupDetailsBlockComponent extends FacilityGroupEditableBlockClass implements OnInit {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;

  isLoading = false;
  permissions: UserPermissions = new UserPermissions();

  constructor(
    protected fb: UntypedFormBuilder,
    protected store: Store,
    protected modalsService: ModalsV2Service,
    private formService: FormService
  ) {
    super(fb, store, modalsService);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => (this.permissions = permissions));
  }

  protected createForm(): void {
    this.form = this.fb.group({
      name: [
        null,
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilityGroupsPatterns.name.pattern),
          Validators.maxLength(FacilityGroupsPatterns.name.maxLength),
        ],
      ],
      address: [null],
      website: [null],
    });
  }

  updateForm(facilityGroup: IFacilityGroup): void {
    const facilityGroupAddress = {
      description: facilityGroup.addressDescription ? facilityGroup.addressDescription : null,
      addressLine1: facilityGroup.addressLine1 ? facilityGroup.addressLine1 : null,
      cityId: facilityGroup.city ? facilityGroup.cityId : null,
      countryId: facilityGroup.countryId ? facilityGroup.countryId : null,
      postCode: null,
      stateId: facilityGroup.state ? facilityGroup.stateId : null,
    };

    this.form.patchValue(
      {
        name: facilityGroup.name,
        address: facilityGroupAddress,
        website: facilityGroup.website,
      },
      { emitEvent: false }
    );
  }

  submit(): void {
    if (!this.form.dirty && this.form.invalid) {
      this.formService.submitForm();

      return;
    }
    this.store
      .dispatch(
        new FacilityGroupDetailsActions.Update({
          id: this.facilityGroup.id,
          body: this.form.value,
        })
      )
      .pipe(
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe(
        () => {},
        () => this.updateForm(this.facilityGroup)
      );
  }

  // ToDo uncomment when the task 6983 will be on the dev
  // changeHolderInfo(event: boolean): void {
  //   this.submit();
  // }
}
