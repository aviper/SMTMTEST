import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';

import { CustomValidators } from '../../../core/helpers/custom-validators';
import { ITableLoaderConfig, TableDragEvent } from '../../../shared/ui/modules/table/table/table.component';

export interface ReportHeaderTableRow {
  row: string;
  value: string;
  checked: boolean;
}

@Component({
  selector: 'app-report-header-table',
  templateUrl: './report-header-table.component.html',
  styleUrls: ['./report-header-table.component.scss'],
  standalone: false,
})
export class ReportHeaderTableComponent implements OnChanges {
  readonly SKELETON_CONFIG: Partial<ITableLoaderConfig> = {
    defaultAmount: 7,
    rowsConfig: [15, 20, 65],
    responsive: true,
  };

  @Input() detailsType: 'Group details' | 'Facility details';
  @Input() data: Array<ReportHeaderTableRow | ReportHeaderTableRow[]> = [];
  @Input() isLoading = false;
  @Input() isUpdating = false;
  @Input() editable = false;

  @Output() reportTitleChanged: EventEmitter<string> = new EventEmitter<string>();
  @Output() faxChanged: EventEmitter<string> = new EventEmitter<string>();
  @Output() changedItem: EventEmitter<{ row: string; checked: boolean }> = new EventEmitter<{
    row: string;
    checked: boolean;
  }>();
  @Output() dropped: EventEmitter<TableDragEvent> = new EventEmitter<TableDragEvent>();

  titleControl: UntypedFormControl = new UntypedFormControl('');
  faxControl: UntypedFormControl = new UntypedFormControl(null, CustomValidators.invalidPhoneNumber);

  changeItem(item: ReportHeaderTableRow, newItemState: boolean): void {
    this.changedItem.emit({ row: item.row, checked: newItemState });
  }

  submit(): void {
    if (this.titleControl.touched) {
      this.reportTitleChanged.emit(this.titleControl.value);
      this.titleControl.markAsUntouched();
    }

    if (!this.faxControl.pristine) {
      this.faxChanged.emit(this.faxControl.value);
      this.faxControl.markAsPristine();
    }
  }

  onDrop(event: TableDragEvent): void {
    this.dropped.emit(event);
  }

  ngOnChanges(): void {
    if (!!this.data.length) {
      const reportTitleRow: ReportHeaderTableRow = <ReportHeaderTableRow>(
        (<ReportHeaderTableRow[]>this.data.filter((item) => !Array.isArray(item))).find(
          (item) => item.row === 'Report title'
        )
      );
      const contactRows: ReportHeaderTableRow[] = <ReportHeaderTableRow[]>this.data.find((item) => Array.isArray(item));
      const faxRow = contactRows.find((item: ReportHeaderTableRow) => item.row === 'Fax');

      this.titleControl.patchValue(reportTitleRow?.value || '');
      this.faxControl.patchValue(faxRow?.value || null);
    }
  }
}
