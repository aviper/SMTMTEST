import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';

import { IPagination } from '@synth/utils/feature/pagination';

import { TABLE_TYPE } from '../../../core/constants/table-constants';
import { TableSettingsService } from '../../../core/http-services/table-settings.service';
import { TableSetting } from '../../../core/models/classes/table-setting';
import { ISort } from '../../../core/models/types/common';
import { IFacilityGroup } from '../../../core/models/types/facility';
import { ITableColumnWidth, ITableSetting } from '../../../core/models/types/tables';
import { ACCOUNT_TABLE_COLUMNS_SETTINGS } from '../../utils/constants';

@Component({
  selector: 'app-facility-group-table',
  templateUrl: './facility-group-table.component.html',
  styleUrls: ['./facility-group-table.component.scss'],
  standalone: false,
})
export class FacilityGroupTableComponent {
  @Input() set groups(groups: IFacilityGroup[]) {
    this.data = groups;
  }

  @Input() set settings(settings: ITableSetting[]) {
    this.tableSettings = settings;
    this.updateDisplayedColumnsMap(TableSetting.calculateVisibleColumns(this.tableSettings));
  }

  @Input() set displayedColumns(columns: string[]) {
    this.columns = columns;
    this.calculateDisplayColumnsFromArray(columns);
  }

  @Input() sort: ISort | {} = {};
  @Input() enableResize = false;
  @Input() isLoading: boolean;

  @Input() pagination: IPagination;
  @Input() limit = 20;

  @Output() sortChanged: EventEmitter<ISort | {}> = new EventEmitter<ISort | {}>();
  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();

  readonly TABLE_TYPE = TABLE_TYPE.accounts;
  readonly TABLE_COLUMNS_SETTINGS = ACCOUNT_TABLE_COLUMNS_SETTINGS;

  tableSettings: ITableSetting[] = [];
  columns: string[] = [];
  displayedColumnsMap = {};
  columnsWidth: ITableColumnWidth = {};
  data: IFacilityGroup[] = [];

  constructor(
    private tableSettingsService: TableSettingsService,
    private router: Router
  ) {}

  applySort(sort: ISort): void {
    this.sort = sort.direction ? sort : {};
    this.sortChanged.emit(this.sort);
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }

  updateSettings(newSettings: ITableSetting[]): void {
    this.tableSettingsService.updateSettings(this.TABLE_TYPE, { values: newSettings }).subscribe(() => {
      this.tableSettings = [...newSettings];
      this.updateDisplayedColumnsMap(newSettings);
    });
  }

  private calculateDisplayColumnsFromArray(columns: string[]): void {
    this.displayedColumnsMap = TableSetting.getDisplayedColumnsMap(columns);
  }

  private updateDisplayedColumnsMap(settings: ITableSetting[]): void {
    this.displayedColumnsMap = TableSetting.getDisplayedColumnsMapFromSettings(settings);
  }

  setColumnsWidth(columnsWidth: ITableColumnWidth): void {
    this.columnsWidth = { ...columnsWidth };
  }

  hideColumn(columnKey: string): void {
    const columnForHide = this.tableSettings.find((setting) => setting.key === columnKey);

    if (columnForHide) {
      columnForHide.value = false;
    }
    this.updateSettings(this.tableSettings);
  }

  onClick(facilityGroup: IFacilityGroup): void {
    this.router.navigate(['/accounts/groups/', facilityGroup.id]);
  }
}
