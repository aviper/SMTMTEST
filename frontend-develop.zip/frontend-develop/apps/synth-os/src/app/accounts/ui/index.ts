import { AddDepartmentComponent } from './add-department/add-department.component';
import { ConfigureDefaultTemplateModalComponent } from './configure-default-template-modal/configure-default-template-modal.component';
import { CreateDepartmentComponent } from './create-department/create-department.component';
import { CreateFacilityComponent } from './create-facility/create-facility.component';
import { CreateFacilityGroupComponent } from './create-facility-group/create-facility-group.component';
import { CreateFtpComponent } from './create-ftp/create-ftp.component';
import { FacilityGroupTableHeaderComponent } from './facility-group-table/facility-group-table-header/facility-group-table-header.component';
import { FacilityGroupTableRowComponent } from './facility-group-table/facility-group-table-row/facility-group-table-row.component';
import { FacilityGroupTableComponent } from './facility-group-table/facility-group-table.component';
import { ReportHeaderTableComponent } from './report-header-table/report-header-table.component';

export const ACCOUNTS_UI: any[] = [
  CreateFtpComponent,
  CreateFacilityComponent,
  CreateDepartmentComponent,
  CreateFacilityGroupComponent,
  AddDepartmentComponent,
  ReportHeaderTableComponent,
  FacilityGroupTableComponent,
  FacilityGroupTableRowComponent,
  FacilityGroupTableHeaderComponent,
  ConfigureDefaultTemplateModalComponent,
];
