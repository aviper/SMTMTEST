import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  forwardRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import {
  ControlValueAccessor,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  NG_VALUE_ACCESSOR,
  Validators,
} from '@angular/forms';
import { UserPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { of, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { CONTROL_ERROR, ControlError } from '@synth/utils';

import { CustomValidators } from '../../../core/helpers/custom-validators';
import { ProfileService } from '../../../core/http-services/profile.service';
import { IItemResponse } from '../../../core/models/types/common';
import { IFtpServer } from '../../../core/models/types/facility';
import { FormService } from '../../../core/services/form.service';

@Component({
  selector: 'app-create-ftp',
  templateUrl: './create-ftp.component.html',
  styleUrls: ['./create-ftp.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CreateFtpComponent),
      multi: true,
    },
    {
      provide: CONTROL_ERROR,
      useExisting: forwardRef(() => CreateFtpComponent),
    },
  ],
  standalone: false,
})
export class CreateFtpComponent
  implements OnInit, OnChanges, AfterViewInit, ControlValueAccessor, OnDestroy, ControlError
{
  readonly ALLOWED_CERT_TYPES = ['pem'];

  ftpForm: UntypedFormGroup;
  error: string;
  file: File;
  fileName: string;
  isSubmitting = false;
  isEditingForm = true;
  pathTooltip = '';

  private isFilePathEmpty = false;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  @Input() facilityId = 0;
  @Input() server: IFtpServer = null;
  @Input() departmentName: string;
  @Output() isFormInvalid: EventEmitter<boolean> = new EventEmitter<boolean>(true);

  constructor(
    private fb: UntypedFormBuilder,
    private profileService: ProfileService,
    private modalsV2Service: ModalsV2Service,
    private formService: FormService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.isFormInvalid.emit(true);
  }

  private createForm(): void {
    if (this.server && this.server.ftpCertificate) {
      this.fileName = this.server.ftpCertificate.name + '.' + this.server.ftpCertificate.format;
    }

    this.ftpForm = this.fb.group({
      url: [this.server?.url || null, [CustomValidators.required]],
      username: [
        this.server?.username || null,
        [
          CustomValidators.required,
          CustomValidators.patternInput(UserPatterns.userFullName.pattern),
          Validators.minLength(UserPatterns.userFullName.minLength),
          Validators.maxLength(UserPatterns.userFullName.maxLength),
        ],
      ],
      port: [this.server?.port || null, [CustomValidators.required]],
      certificateFileId: [this.server?.certificateFileId || null],
      filePath: [this.server?.filePath || '', [CustomValidators.invalidFtpPath]],
      filePrefix: [this.server?.filePrefix || ''],
      id: [this.server?.id || null],
    });

    this.isFilePathEmpty && this.ftpForm.get('filePath').setValue('/upload/', { emitEvent: false });
  }

  ngAfterViewInit(): void {
    this.ftpForm.controls['filePath'].updateValueAndValidity();
    this.cdr.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.departmentName?.currentValue === 'LHI') {
      this.isFilePathEmpty = !changes.server?.currentValue?.filePath;
      this.pathTooltip = 'For LHI use /upload/facility_name';
    }
  }

  uploadFile(file: File[]): void {
    this.file = file[0];
    this.fileName = this.file.name;
  }

  deleteUploadedFile(): void {
    this.file = null;
    this.fileName = '';
  }

  createRequestForFile(): void {
    if (this.isEditingForm) {
      this.isSubmitting = true;
      this.ftpForm.disable();
      this.formService.submitForm();
      const isFileError = !(this.file || (this.server && this.server.ftpCertificate));

      if (this.ftpForm.invalid || isFileError) {
        return;
      }

      let value = FormService.trimValues(this.ftpForm.value);

      const requestForFile$ =
        this.file || !(this.server && this.server.ftpCertificate)
          ? this.profileService.uploadFile(
              this.file,
              'ftpCertificates',
              'facility',
              this.facilityId && this.facilityId.toString(),
              undefined,
              { autoNotifyErrors: false }
            )
          : of({ data: this.server.ftpCertificate, message: '' });

      requestForFile$
        .pipe(
          map((res: IItemResponse) => {
            value.certificateFileId = res.data.id;
            value.ftpCertificate = res.data;

            if (this.server && this.server.id) {
              value = {
                ...this.server,
                ...value,
              };
            }

            return value;
          }),
          takeUntil(this.unsubscribe$$)
        )
        .subscribe(
          (res) => {
            this.onChange(res);
            this.isSubmitting = false;
            this.isEditingForm = false;
            this.isFormInvalid.emit(false);
          },
          (error) => this.modalsV2Service.error(error.message)
        );
    } else {
      this.isFormInvalid.emit(true);
      this.isEditingForm = true;
      this.ftpForm.enable();
    }
  }

  validateForm({ value }: UntypedFormControl): {} {
    return this.ftpForm.invalid && { invalid: true };
  }

  writeValue(value: IFtpServer): void {
    if (value) {
      this.server = value[0];
    }
  }

  onChange: any = () => {};
  onTouched: any = () => {};

  registerOnChange(fn: Function): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onTouched = fn;
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
