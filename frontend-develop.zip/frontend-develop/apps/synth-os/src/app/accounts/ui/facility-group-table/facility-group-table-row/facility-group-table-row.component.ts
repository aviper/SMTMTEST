import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { IEnvironmentCreationStatus } from '../../../../core/models/types/connection';
import { IFacilityGroup } from '../../../../core/models/types/facility';
import { ITableColumnWidth } from '../../../../core/models/types/tables';
import { WebsocketService } from '../../../../core/services/websocket.service';

@Component({
  selector: 'app-facility-group-table-row',
  templateUrl: './facility-group-table-row.component.html',
  styleUrls: ['./facility-group-table-row.component.scss'],
  standalone: false,
})
export class FacilityGroupTableRowComponent implements OnInit, OnDestroy {
  @Input() facilityGroup: IFacilityGroup;
  @Input() columnsWidth: ITableColumnWidth = {};
  @Input() displayedColumnsMap: { [key: string]: number } = {};

  isFacilityGroupActive: boolean;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private wsService: WebsocketService) {}

  ngOnInit(): void {
    this.isFacilityGroupActive = this.facilityGroup.active;

    this.wsService
      .on<IEnvironmentCreationStatus>('facility_group_env_status_updated')
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((res: IEnvironmentCreationStatus) => {
        if (res.groupId === this.facilityGroup.id) {
          this.isFacilityGroupActive = res.active;
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
