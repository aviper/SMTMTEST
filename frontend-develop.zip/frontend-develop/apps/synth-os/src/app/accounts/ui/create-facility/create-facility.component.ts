import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { FacilitiesPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Observable, Subject } from 'rxjs';
import { finalize, switchMap, takeUntil } from 'rxjs/operators';

import {
  modalAnimation,
  ModalsV2Service,
  CONFIRM_POPUP_RESPONSE,
  ModalOverlayRef,
  ModalClass,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ALLOWED_PICTURE_TYPES_AVATAR } from '../../../core/constants/constants';
import { ICONS } from '../../../core/constants/icon-list';
import { CustomValidators } from '../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../core/http-services/facilities.service';
import { ProfileService } from '../../../core/http-services/profile.service';
import { IItemResponse, IOption } from '../../../core/models/types/common';
import { IFacilityType } from '../../../core/models/types/facility';
import { FormService } from '../../../core/services/form.service';

@Component({
  selector: 'app-create-facility',
  templateUrl: './create-facility.component.html',
  styleUrls: ['./create-facility.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class CreateFacilityComponent extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly ALLOWED_PICTURE_TYPES_AVATAR = ALLOWED_PICTURE_TYPES_AVATAR;

  facilityForm: UntypedFormGroup;
  facilityTypes: IOption[] = [];
  isLoading = false;
  groupId: number;
  previewLogo: string | ArrayBuffer;
  logoFile: File;
  uploadError = '';

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected cdRef: ChangeDetectorRef,
    public overlayRef: ModalOverlayRef,
    private fb: UntypedFormBuilder,
    private formService: FormService,
    private facilityService: FacilitiesService,
    private modalsService: ModalsV2Service,
    private profileService: ProfileService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, overlayRef, actionComplete$);
    this.groupId = overlayRef.data.facilityGroupId;
  }

  ngOnInit(): void {
    this.createForm();
    this.getFacilityTypes();
  }

  closeAfterConfirm(): void {
    if (this.facilityForm.dirty && this.facilityForm.invalid) {
      this.modalsService
        .confirm({
          title: 'Wait!',
          message: 'Do you want to discard changes or keep editing?',
          cancelButton: 'Discard',
          confirmationButton: 'Keep Editing',
        })
        .subscribe((result) => {
          if (result === CONFIRM_POPUP_RESPONSE.cancel) {
            this.closeModal();
          }
        });
    } else {
      this.closeModal();
    }
  }

  closeModal(reload: boolean = false): void {
    this.result.emit(reload);
    this.overlayRef.close();
  }

  getFacilityTypes(query?: string): void {
    this.facilityService
      .getFacilityTypes({ query })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((facilityTypesResponse: any) => {
        this.facilityTypes = facilityTypesResponse.data.map((facilityType: IFacilityType) => ({
          value: facilityType.id,
          label: facilityType.name,
        }));
      });
  }

  createForm(): void {
    this.facilityForm = this.fb.group({
      name: [
        '',
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilitiesPatterns.name.pattern),
          Validators.minLength(FacilitiesPatterns.name.minLength),
          Validators.maxLength(FacilitiesPatterns.name.maxLength),
        ],
      ],
      groupId: [this.groupId],
      typeId: ['', CustomValidators.required],
      phone: [null, [CustomValidators.required, CustomValidators.invalidPhoneNumber]],
      outFaxNumber: [null, [CustomValidators.invalidPhoneNumber]],
      address: [null, [CustomValidators.required]],
      autoRadAssign: [true],
    });
  }

  submit(): void {
    this.formService.submitForm();
    this.isLoading = true;

    const createRequest$: Observable<IItemResponse> = this.facilityService.createFacility(this.facilityForm.value, {
      autoNotifyErrors: false,
    });
    const createWithLogoRequest$: Observable<IItemResponse> = this.profileService
      .uploadFile(this.logoFile, 'logo', 'facility', this.facilityForm.get('name').value, undefined, {
        autoNotifyErrors: false,
      })
      .pipe(
        switchMap((uploadedImageResponse: IItemResponse) => {
          const formValue = this.facilityForm.value;

          formValue.logoFileId = uploadedImageResponse.data.id;

          return this.facilityService.createFacility(formValue, { autoNotifyErrors: false });
        })
      );

    const createFacility$ = this.logoFile ? createWithLogoRequest$ : createRequest$;

    createFacility$
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (res: IItemResponse) => {
          this.closeModal(true);
          this.modalsService.success('Facility created!');
        },
        (error) => {
          this.closeModal();
          this.modalsService.error(error.message);
        }
      );
  }

  removeLogo(): void {
    this.logoFile = null;
    this.previewLogo = null;
  }

  setLogoRawFile(event: Event): void {
    this.logoFile = event.target['files'][0];

    if (this.logoFile) {
      this.uploadError = '';
      const reader: FileReader = new FileReader();

      reader.readAsDataURL(this.logoFile);

      reader.onload = () => {
        this.previewLogo = reader.result;
      };
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
