import { ChangeDetectorRef, Component, DestroyRef, ElementRef, Inject, OnInit, Signal, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, UntypedFormBuilder } from '@angular/forms';
import { Store } from '@ngxs/store';
import { delay, finalize, Observable, of } from 'rxjs';

import { ModalsV2Service, ModalClass, ModalOverlayRef, modalAnimation, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { ICONS } from '../../../core/constants/icon-list';
import {
  convertToField,
  DEFAULT_SECTION_OPTIONS,
  FINDINGS_SECTION,
  IMPRESSION_SECTION,
  PRE_FINDINGS_SECTION,
} from '../../../core/constants/template-sections';
import { CustomValidators } from '../../../core/helpers/custom-validators';
import { FacilityGroupDefaultTemplatesService } from '../../../core/http-services/facility-groups-default-template.service';
import { IItemResponse } from '../../../core/models/types/common';
import { FacilityGroupDetailsState } from '../../../core/store/accounts/states/facility-group/facility-group-details.state';

@Component({
  selector: 'app-configure-default-template-modal',
  templateUrl: './configure-default-template-modal.component.html',
  styleUrls: ['./configure-default-template-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class ConfigureDefaultTemplateModalComponent extends ModalClass implements OnInit {
  @ViewChild('scrollContainer', { static: true }) scrollableContainer: ElementRef<HTMLElement>;

  readonly groupId: Signal<number> = this.store.selectSignal(FacilityGroupDetailsState.facilityGroupId);
  readonly ICONS = ICONS;
  readonly sectionOptions = DEFAULT_SECTION_OPTIONS;
  readonly form = this.fb.group(
    {
      reportFields: [[], [CustomValidators.required]],
    },
    { validators: [CustomValidators.uniqueFieldsKeysForTemplate()] }
  );
  readonly reportFieldsControl = this.form.get('reportFields') as FormControl;
  readonly canEdit: boolean;

  isLoading = false;
  hideTableGridLines = false;
  templateId?: number;
  isFilled: boolean;

  constructor(
    private readonly fb: UntypedFormBuilder,
    private readonly facilityGroupDefaultTemplateService: FacilityGroupDefaultTemplatesService,
    private readonly modalsService: ModalsV2Service,
    private readonly store: Store,
    private readonly destroyRef: DestroyRef,
    cdRef: ChangeDetectorRef,
    modalOverlayRef: ModalOverlayRef,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
    this.canEdit = modalOverlayRef.data.canEdit;
  }

  ngOnInit(): void {
    this.loadFacilityGroupDefaultTemplate();
  }

  save(): void {
    if (this.form.invalid) {
      return;
    }

    this.isLoading = true;

    this.prepareRequest().subscribe({
      next: () => this.closeModal(true),
      error: (error) => {
        this.modalsService.error(error.message);
        this.isLoading = false;
      },
      complete: () => (this.isLoading = false),
    });
  }

  applyDefaultTemplate(defaultTemplate?: { id: number; reportFields: []; hideTableGridLines: boolean }): void {
    this.templateId = defaultTemplate?.id;
    this.hideTableGridLines = defaultTemplate?.hideTableGridLines ?? false;
    defaultTemplate
      ? this.reportFieldsControl.setValue(defaultTemplate.reportFields)
      : this.reportFieldsControl.setValue([
          convertToField(PRE_FINDINGS_SECTION),
          convertToField(FINDINGS_SECTION),
          convertToField(IMPRESSION_SECTION),
        ]);

    of(null)
      .pipe(delay(100))
      .subscribe(() => {
        this.scrollableContainer.nativeElement.scrollTop = 0;
        this.isFilled = true;
      });
  }

  onHideTableGridLinesChange(hideTableGridLines: boolean): void {
    this.hideTableGridLines = hideTableGridLines;
  }

  closeModal(data?: any): void {
    this.result.next(data);
    this.modalOverlayRef.close();
  }

  private prepareRequest(): Observable<IItemResponse> {
    const payload = {
      ...this.form.value,
      hideTableGridLines: this.hideTableGridLines,
    };

    return this.templateId
      ? this.facilityGroupDefaultTemplateService.updateFacilityGroupsDefaultTemplate(this.groupId(), payload, {
          autoNotifyErrors: false,
        })
      : this.facilityGroupDefaultTemplateService.createFacilityGroupsDefaultTemplate(this.groupId(), payload, {
          autoNotifyErrors: false,
        });
  }

  private loadFacilityGroupDefaultTemplate(): void {
    const facilityGroupId = this.groupId();

    if (!facilityGroupId) {
      return;
    }

    this.isLoading = true;
    this.facilityGroupDefaultTemplateService
      .getFacilityGroupsDefaultTemplate(facilityGroupId)
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (response) => this.applyDefaultTemplate(response.data),
        error: () => this.applyDefaultTemplate(),
      });
  }
}
