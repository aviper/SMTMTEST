import { Pipe, PipeTransform } from '@angular/core';

import {
  IOrderProcessingItemCondition,
  OrderProcessingConditionType,
} from '../../../core/models/types/orders-processing';

@Pipe({
  standalone: true,
  name: 'conditionName',
})
export class ConditionNamePipe implements PipeTransform {
  transform(conditions: IOrderProcessingItemCondition[]): string {
    if (!conditions) {
      return '';
    }

    return conditions
      .map((condition) => {
        if (condition.condition === 'date') {
          const conditionName =
            condition.conditionType === OrderProcessingConditionType.DICOM ? condition.tag : condition.field;

          return `${conditionName} - date is ${condition.details} days or ${condition.comparison === 'more' ? 'more' : 'less'} in the past`;
        }

        const conditionName =
          condition.conditionType === OrderProcessingConditionType.DICOM ? condition.tag : condition.field;
        const conditionType = condition.condition.replace('_', ' ');

        return `${conditionName === 'custom' ? condition.name : conditionName} - ${conditionType} ${condition.details}`;
      })
      .join(' AND ');
  }
}
