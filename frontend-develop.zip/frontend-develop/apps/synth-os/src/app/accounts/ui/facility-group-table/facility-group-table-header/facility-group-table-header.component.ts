import { Component, Input } from '@angular/core';

import { ITableColumnWidth } from '../../../../core/models/types/tables';

@Component({
  selector: 'app-facility-group-table-header',
  templateUrl: './facility-group-table-header.component.html',
  styleUrls: ['./facility-group-table-header.component.scss'],
  standalone: false,
})
export class FacilityGroupTableHeaderComponent {
  @Input() columnsWidth: ITableColumnWidth = {};
  @Input() displayedColumnsMap: { [key: string]: number } = {};
}
