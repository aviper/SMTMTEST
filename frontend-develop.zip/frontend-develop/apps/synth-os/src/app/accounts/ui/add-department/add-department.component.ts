import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { finalize, takeUntil } from 'rxjs/operators';

import {
  ModalsV2Service,
  CONFIRM_POPUP_RESPONSE,
  modalAnimation,
  ModalOverlayRef,
  ModalClass,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ICONS } from '../../../core/constants/icon-list';
import { FacilitiesService } from '../../../core/http-services/facilities.service';

@Component({
  selector: 'app-add-department',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddDepartmentComponent extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;

  departmentForm: UntypedFormGroup;
  isLoading = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected cdRef: ChangeDetectorRef,
    private fb: UntypedFormBuilder,
    private overlayRef: ModalOverlayRef,
    private modalsV2Service: ModalsV2Service,
    private facilitiesService: FacilitiesService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, overlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(): void {
    this.departmentForm = this.fb.group({
      facilityDepartment: null,
    });
  }

  addDepartment(): void {
    if (this.departmentForm.invalid) {
      this.modalsV2Service.error('Fill up required fields!');

      return;
    }

    this.isLoading = true;
    const body = {
      ...this.departmentForm.value.facilityDepartment,
      facilityId: this.overlayRef.data.id,
    };

    this.facilitiesService
      .addFacilityDepartment(body, { autoNotifyErrors: false })
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe({
        next: () => {
          this.modalsV2Service.success('Department added successfully!');
          this.closeModal(true);
        },
        error: (error) => {
          this.modalsV2Service.error(error.message);
        },
      });
  }

  closeAfterConfirm(): void {
    if (this.departmentForm.dirty) {
      this.modalsV2Service
        .confirm({
          title: 'Wait!',
          message: 'Do you want to discard changes or keep editing?',
          cancelButton: 'Discard',
          confirmationButton: 'Keep Editing',
        })
        .subscribe((result) => {
          if (result === CONFIRM_POPUP_RESPONSE.cancel) {
            this.closeModal();
          }
        });
    } else {
      this.closeModal();
    }
  }

  closeModal(reload: boolean = false): void {
    this.result.emit(reload);
    this.overlayRef.close();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
