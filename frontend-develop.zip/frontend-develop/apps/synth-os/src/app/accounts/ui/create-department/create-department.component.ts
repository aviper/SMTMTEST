import { Component, forwardRef, OnInit, Output, EventEmitter, OnDestroy, Input, Self, inject } from '@angular/core';
import {
  AbstractControl,
  ControlValueAccessor,
  UntypedFormArray,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  NgControl,
  Validators,
} from '@angular/forms';
import { FacilitiesDepartmentsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Observable, Subject } from 'rxjs';
import { debounceTime, filter, takeUntil } from 'rxjs/operators';

import { CONTROL_ERROR, ControlError } from '@synth/utils';

import { REPORT_TYPE } from '../../../core/constants/constants';
import { ICONS } from '../../../core/constants/icon-list';
import { CustomValidators } from '../../../core/helpers/custom-validators';
import { ContractHoldersService } from '../../../core/http-services/contract-holders.service';
import { IOption } from '../../../core/models/types/common';
import { IFacility, IFacilityDepartment } from '../../../core/models/types/facility';
import { FacilityDetailsState } from '../../../core/store/accounts/states/facility/facility-details.state';
import { Store } from '@ngxs/store';

@Component({
  selector: 'app-create-department',
  templateUrl: './create-department.component.html',
  styleUrls: ['./create-department.component.scss'],
  providers: [
    {
      provide: CONTROL_ERROR,
      useExisting: forwardRef(() => CreateDepartmentComponent),
    },
  ],
  standalone: false,
})
export class CreateDepartmentComponent implements OnInit, ControlValueAccessor, OnDestroy, ControlError {
  private readonly store: Store = inject(Store);

  readonly ICONS = ICONS;

  departmentForm: UntypedFormGroup;
  departmentsResponsesForm: UntypedFormGroup;
  preparedDepartmentForm;
  isEmailValid = false;
  isFaxValid = false;
  error: string;
  isShowError = false;
  department: IFacilityDepartment;
  contractHolderOptions: IOption[] = [];
  isDepartmentsResponsesDisabled = false;
  isContractHolderRequired = false;

  @Input() facilityId: number;
  @Input() isMain = false;
  @Input() isMultipleDepartments = false;
  @Output() closed: EventEmitter<null> = new EventEmitter();

  readonly facility$: Observable<IFacility> = this.store.select(FacilityDetailsState.facility);

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private _isFtpFormInvalid = false;

  get isFtpFormInvalid(): boolean {
    return this._isFtpFormInvalid;
  }

  set isFtpFormInvalid(value: boolean) {
    this._isFtpFormInvalid = value;
    this.controlDirective.control.updateValueAndValidity();
  }

  constructor(
    private fb: UntypedFormBuilder,
    private contractHoldersService: ContractHoldersService,
    @Self() private controlDirective: NgControl
  ) {
    controlDirective.valueAccessor = this;
  }

  ngOnInit(): void {
    this.createForm();
    this.addFtpServers(this.departmentForm.value.departmentsResponses.ftp);
    this.controlDirective.control.setValidators([this.validateForm.bind(this)]);
    this.controlDirective.control.updateValueAndValidity();

    this.departmentsResponseValidationHandling();

    this.departmentForm.valueChanges.pipe(debounceTime(500), takeUntil(this.unsubscribe$$)).subscribe((res) => {
      this.isShowError = this.departmentForm.controls.departmentsResponses.invalid;
      this.preparedDepartmentForm = this.departmentForm.value;
      this.preparedDepartmentForm.departmentsResponses = this.transformToArray(
        this.preparedDepartmentForm.departmentsResponses
      );
      this.onChange(this.preparedDepartmentForm);
    });

    this.departmentForm
      .get('fax')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.checkFaxValid());

    this.departmentForm
      .get('email')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.checkEmailValid());

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.isContractHolderRequired = facility.group.isContractHolderRequired;
        this.departmentForm.controls.contractHolderId.setValidators(
          this.isContractHolderRequired ? [CustomValidators.required] : []
        );

        this.contractHoldersService
          .getHolders({
            facilityGroupId: facility.groupId,
            limit: 100,
          })
          .subscribe((response) => {
            this.contractHolderOptions = [...response.data.map((it) => ({ value: it.id, label: it.name }))];
          });
      });
  }

  createForm(): void {
    this.departmentForm = this.fb.group({
      name: [
        this.department && this.department.name,
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilitiesDepartmentsPatterns.name.pattern),
          Validators.minLength(FacilitiesDepartmentsPatterns.name.minLength),
          Validators.maxLength(FacilitiesDepartmentsPatterns.name.maxLength),
        ],
      ],
      email: [this.department && this.department.email, [CustomValidators.email]],
      phone: [this.department && this.department.fdPhone, [CustomValidators.invalidPhoneNumber]],
      notes: [
        this.department && this.department.notes,
        [
          CustomValidators.patternInput(FacilitiesDepartmentsPatterns.notes.pattern),
          Validators.maxLength(FacilitiesDepartmentsPatterns.notes.maxLength),
        ],
      ],
      contractHolderId: [this.department && this.department.contractHolderId],
      fax: [this.department && this.department.fdFax],
      isMain: [this.department ? this.department.isMain : true],
      autoDelivery: [this.department ? this.department.autoDelivery : true],
      departmentsResponses: this.fb.group(
        {
          email: false,
          fax: false,
          oru: false,
          ftp: false,
        },
        { validator: CustomValidators.requiredCheckedOptionObject }
      ),
      ftpServers: this.fb.array([]),
    });

    this.departmentsResponsesForm = this.departmentForm.get('departmentsResponses') as UntypedFormGroup;

    if (this.isMain && !this.department) {
      this.departmentForm.get('isMain').patchValue(true);
    }

    if (this.department) {
      this.departmentForm
        .get('departmentsResponses')
        .patchValue(this.transformToObj(this.department.departmentsResponses));
    }
    this.checkFaxValid();
    this.checkEmailValid();
  }

  checkFaxValid(): void {
    if (this.departmentForm.controls.fax.value) {
      this.isFaxValid =
        this.departmentForm.controls.fax.valid &&
        !!this.departmentForm.controls.fax.value.number &&
        !!this.departmentForm.controls.fax.value.countryCode;
    }
  }

  checkEmailValid(): void {
    this.isEmailValid = this.departmentForm.controls.email.valid && !!this.departmentForm.controls.email.value;
  }

  transformToArray(value: {}): { key: string; value: boolean }[] {
    return REPORT_TYPE.map((type) => ({ key: type, value: value[type] }));
  }

  transformToObj(value: { key: string; value: boolean }[]): {} {
    const obj = {};

    value.forEach((item) => (obj[item.key] = item.value));

    return obj;
  }

  validateForm({ value }: AbstractControl): {} {
    return (this.isFtpFormInvalid || this.departmentForm.invalid) && { invalid: true };
  }

  get ftpFormArray(): UntypedFormArray {
    return this.departmentForm.get('ftpServers') as UntypedFormArray;
  }

  addFtpServers(isCheckedFtp: boolean): void {
    isCheckedFtp ? this.ftpFormArray.push(new UntypedFormControl()) : this.ftpFormArray.removeAt(0);

    this.isFtpFormInvalid = isCheckedFtp && this.isFtpFormInvalid;
  }

  writeValue(value: any): void {
    if (value) {
      this.department = value;
    }
  }

  onChange: any = () => {};
  onTouched: any = () => {};

  registerOnChange(fn: Function): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onTouched = fn;
  }

  removeDepartment(event: Event): void {
    this.closed.emit();
  }

  private departmentsResponseValidationHandling(): void {
    this.departmentForm
      .get('autoDelivery')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((it) => {
        this.isDepartmentsResponsesDisabled = !it;
        this.departmentForm.controls.departmentsResponses.setValidators(
          this.isDepartmentsResponsesDisabled ? [] : [CustomValidators.requiredCheckedOptionObject]
        );
        this.departmentForm.controls.departmentsResponses.enable();
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
