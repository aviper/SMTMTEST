import { ChangeDetectorRef, Component, inject, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { FacilityGroupsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, finalize, switchMap, takeUntil } from 'rxjs/operators';

import { ENV_NAMES } from '@synth/api';
import {
  ModalsV2Service,
  modalAnimation,
  CONFIRM_POPUP_RESPONSE,
  ModalOverlayRef,
  ModalClass,
  MODAL_ACTION_COMPLETE,
} from '@synth/ui/modals';

import { ALLOWED_PICTURE_TYPES_AVATAR } from '../../../core/constants/constants';
import { ACCOUNTS_ENDPOINTS } from '../../../core/constants/endpoints';
import { ICONS } from '../../../core/constants/icon-list';
import { CustomValidators } from '../../../core/helpers/custom-validators';
import { FacilitiesService } from '../../../core/http-services/facilities.service';
import { ProfileService } from '../../../core/http-services/profile.service';
import { UserPermissions } from '../../../core/models/classes/userPermissions';
import { IHumanErrorBody, IItemResponse } from '../../../core/models/types/common';
import { ConverterService } from '../../../core/services/converter.service';
import { EnvironmentLoaderService } from '../../../core/services/environment-loader.service';
import { FormService } from '../../../core/services/form.service';
import { ProfileState } from '../../../profile/data-access/state/profile/profile.state';

@Component({
  selector: 'app-create-facility-group',
  templateUrl: './create-facility-group.component.html',
  styleUrls: ['./create-facility-group.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class CreateFacilityGroupComponent extends ModalClass implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly ACCOUNTS_ENDPOINTS = ACCOUNTS_ENDPOINTS;
  readonly ALLOWED_PICTURE_TYPES_AVATAR = ALLOWED_PICTURE_TYPES_AVATAR;
  readonly ICONS = ICONS;

  isLoading = false;
  form: UntypedFormGroup;
  uploadError = '';
  logoFile: File;
  previewLogo: string | ArrayBuffer;
  permissions: UserPermissions = new UserPermissions();
  mfa = { isTwoFaEnabled: false, isMfaEnabled: false };
  projectLocations = [];
  projectLocationControl: UntypedFormControl;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    protected formService: FormService,
    protected facilityService: FacilitiesService,
    protected modalsV2Service: ModalsV2Service,
    private fb: UntypedFormBuilder,
    private profileService: ProfileService,
    private els: EnvironmentLoaderService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => (this.permissions = permissions));

    const canadaOption = {
      value: 'northamerica-northeast1',
      label: 'northamerica-northeast1',
    };

    const usCentralOption = {
      value: 'us-central1',
      label: 'us-central1',
    };

    let defaultProjectLocation: string;

    switch (this.els.getEnvironment().name) {
      case ENV_NAMES.caProd:
        this.projectLocations = [canadaOption];
        defaultProjectLocation = canadaOption.value;
        break;
      case ENV_NAMES.usProd:
        this.projectLocations = [usCentralOption];
        defaultProjectLocation = usCentralOption.value;
        break;
      case ENV_NAMES.preprod:
        this.projectLocations = [canadaOption];
        defaultProjectLocation = canadaOption.value;
        break;
      default:
        this.projectLocations = [usCentralOption];
        defaultProjectLocation = usCentralOption.value;
        break;
    }

    this.createForm(defaultProjectLocation);
  }

  private createForm(defaultProjectLocation?: string): void {
    this.form = this.fb.group({
      name: [
        '',
        [
          CustomValidators.required,
          CustomValidators.patternInput(FacilityGroupsPatterns.name.pattern),
          Validators.maxLength(FacilityGroupsPatterns.name.maxLength),
        ],
      ],
      address: [null],
      phone: [null, CustomValidators.invalidPhoneNumber],
      accounterName: [
        '',
        [
          CustomValidators.patternInput(FacilityGroupsPatterns.accounterName.pattern),
          Validators.maxLength(FacilityGroupsPatterns.accounterName.maxLength),
        ],
      ],
      timeout: ['60:00', CustomValidators.timeout],
      email: [null, [CustomValidators.email]],
      isMfaEnabled: [false],
      protect: [false],
      isTwoFaEnabled: [false],
      projectLocation: [
        { value: defaultProjectLocation, disabled: !!defaultProjectLocation },
        [CustomValidators.required, Validators.pattern(FacilityGroupsPatterns.projectLocation.pattern)],
      ],
    });

    this.projectLocationControl = this.form.get('projectLocation') as UntypedFormControl;
  }

  createFacilityGroup(): void {
    if (this.isLoading) {
      return;
    }

    this.formService.submitForm();

    if (this.form.invalid) {
      this.modalsV2Service.error('Fill up all required fields');

      return;
    }

    this.isLoading = true;

    this.form.value.timeout = ConverterService.minutesAndSecondsStringToMilliseconds(this.form.value.timeout);

    const createWithLogoRequest$: Observable<IItemResponse> = this.profileService
      .uploadFile(this.logoFile, 'logo', 'facilityGroup', this.form.get('name').value, undefined, {
        autoNotifyErrors: false,
      })
      .pipe(
        switchMap((uploadedImageResponse: IItemResponse) => {
          const formValue = this.form.value;

          formValue.logoFileId = uploadedImageResponse.data.id;

          return this.facilityService.createFacilityGroup({
            ...formValue,
            projectLocation: this.projectLocationControl.value,
          });
        })
      );

    const createRequest$: Observable<IItemResponse> = this.facilityService.createFacilityGroup(
      {
        ...this.form.value,
        projectLocation: this.projectLocationControl.value,
      },
      { autoNotifyErrors: false }
    );

    const createFacilityGroup$ = this.logoFile ? createWithLogoRequest$ : createRequest$;

    createFacilityGroup$
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe({
        next: () => {
          this.modalsV2Service.success('Facility group created!');
          this.closeModal(true);
        },
        error: (error: IHumanErrorBody) => {
          this.modalsV2Service.error(error.message);
          this.closeModal();
        },
      });
  }

  closeModal(reload: boolean = false): void {
    this.result.emit({ reload });
    this.modalOverlayRef.close();
  }

  removeLogo(): void {
    this.logoFile = null;
    this.previewLogo = null;
  }

  setLogoRawFile(event: Event): void {
    this.logoFile = event.target['files'][0];

    if (this.logoFile) {
      this.uploadError = '';
      const reader: FileReader = new FileReader();

      reader.readAsDataURL(this.logoFile);

      reader.onload = () => {
        this.previewLogo = reader.result;
      };
    }
  }

  closeAfterConfirm(): void {
    if (this.form.dirty && this.form.invalid) {
      this.modalsV2Service
        .confirm({
          title: 'Wait!',
          message: 'Do you want to discard changes or keep editing?',
          cancelButton: 'Discard',
          confirmationButton: 'Keep Editing',
        })
        .subscribe((result) => {
          if (result === CONFIRM_POPUP_RESPONSE.cancel) {
            this.closeModal();
          }
        });
    } else {
      this.closeModal();
    }
  }

  changeTwoFactorAuth(event: boolean): void {
    this.mfa.isTwoFaEnabled = event;

    if (event) {
      this.mfa.isMfaEnabled = false;
      this.form.get('isMfaEnabled').setValue(false);
    }
  }

  changeSequrityQuestionsAuth(event: boolean): void {
    this.mfa.isMfaEnabled = event;

    if (event) {
      this.mfa.isTwoFaEnabled = false;
      this.form.get('isTwoFaEnabled').setValue(false);
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
