import { ColumnPriority } from '../../core/constants/constants';

export const FACILITY_GROUP_TABS = {
  facility: 'facility',
  employee: 'emploee',
  templates: 'templates',
  connections: 'connections',
  algorithm: 'algorithm',
  reportHeader: 'reportHeader',
  cptCodes: 'cptCodes',
  groupFieldLibrary: 'groupFieldLibrary',
  documentType: 'documentType',
  orderDataExport: 'orderDataExport',
  groupTagsAndTasks: 'groupTagsAndTasks',
};

export const ENV_CONNECTION_STATUS = {
  not_started: { title: 'Not started', color: 'gray', key: 'not_started', btnTitle: 'Start' },
  in_progress: { title: 'In progress', color: 'yellow', key: 'in_progress', btnTitle: 'Restart' },
  success: { title: 'Success', color: 'green', key: 'success', btnTitle: 'Restart' },
  error: { title: 'Error', color: 'red', key: 'error', btnTitle: 'Restart' },
};

export const ACCOUNT_TABLE_COLUMNS_SETTINGS = {
  id: {
    minWidth: 50,
    priority: ColumnPriority.none,
  },
  select: {
    minWidth: 20,
    priority: ColumnPriority.none,
  },
  name: {
    minWidth: 120,
    priority: ColumnPriority.large,
  },
  status: {
    minWidth: 100,
    priority: ColumnPriority.small,
  },
  billingAddress: {
    minWidth: 150,
    priority: ColumnPriority.large,
  },
  facilities: {
    minWidth: 80,
    priority: ColumnPriority.small,
  },
  billingOwner: {
    minWidth: 120,
    priority: ColumnPriority.large,
  },
  billingPhone: {
    minWidth: 120,
    priority: ColumnPriority.medium,
  },
  billingEmail: {
    minWidth: 130,
    priority: ColumnPriority.medium,
  },
  createdDate: {
    minWidth: 130,
    priority: ColumnPriority.small,
  },
};
