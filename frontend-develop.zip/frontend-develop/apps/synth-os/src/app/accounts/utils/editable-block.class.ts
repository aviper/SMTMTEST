import { OnDestroy, OnInit, Input, Directive } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { IFacilityGroup } from '../../core/models/types/facility';
import { FacilityGroupDetailsState } from '../../core/store/accounts/states/facility-group/facility-group-details.state';

@Directive()
// tslint:disable-next-line: directive-class-suffix
export abstract class FacilityGroupEditableBlockClass implements OnInit, OnDestroy {
  readonly isPageLoading$: Observable<boolean> = this.store.select(FacilityGroupDetailsState.loading);
  readonly facilityGroup$: Observable<IFacilityGroup> = this.store.select(FacilityGroupDetailsState.facilityGroup);

  @Input() canEdit = true;

  facilityGroup: IFacilityGroup;
  form: UntypedFormGroup;

  protected unsubscribe$$: Subject<void> = new Subject<void>();

  protected abstract updateForm(facilityGroup: IFacilityGroup): void;

  protected abstract createForm(params?: any): void;

  abstract submit(fieldName?: string): void;

  isReadingByAnotherUser: boolean;
  isLoadingDetailsPage = false;

  protected constructor(
    protected fb: UntypedFormBuilder,
    protected store: Store,
    protected modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.createForm();

    this.facilityGroup$.subscribe((facilityGroup) => {
      this.facilityGroup = facilityGroup;

      if (this.facilityGroup) {
        this.updateForm(this.facilityGroup);
      }
    });

    this.isPageLoading$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((loading: boolean) => (this.isLoadingDetailsPage = loading));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
