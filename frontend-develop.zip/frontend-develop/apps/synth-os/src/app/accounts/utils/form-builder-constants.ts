export const LIBRARY_AREA_ID = 'fieldsLibraryArea';
export const SECTION_AREA_ID_PREFIX = 'section_';

export const CUSTOM_ELEMENTS_AREA_ID = 'customElementsArea';

export const AREA_IDS = {
  singleArea: 'singleDropArea',
  twoAreasLeft: 'leftDropArea',
  twoAreasRight: 'rightDropRight',
  sectionArea: 'sectionArea',
};

export enum SECTION_ACTIONS_TYPE {
  DELETE_SECTION_ACTION,
  DELETE_SECTION_ELEMENT_ACTION,
  SECTION_ONDROP_ACTION,
  SECTION_ELEMENT_REQUIRED_CHANGE_ACTION,
  SECTION_COMPONENT_CHANGE_VALUE_ACTION,
  SECTION_ELEMENT_HIDE_NAME_CHANGE_ACTION,
}
