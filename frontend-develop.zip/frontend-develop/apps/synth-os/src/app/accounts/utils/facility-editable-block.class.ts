import { Directive, inject, Input, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Actions, ofActionCompleted, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { IFacility } from '../../core/models/types/facility';
import { FacilityDetailsActions } from '../../core/store/accounts/actions/facility/facility-details.actions';
import { FacilityDetailsState } from '../../core/store/accounts/states/facility/facility-details.state';

@Directive()
export abstract class FacilityEditableBlockClass implements OnInit, OnDestroy {
  private readonly ngxsStore: Store = inject(Store);
  private readonly actions = inject(Actions);

  readonly isLoading$: Observable<boolean> = this.ngxsStore.select(FacilityDetailsState.isLoading);
  readonly facility$: Observable<IFacility> = this.ngxsStore.select(FacilityDetailsState.facility);
  readonly loadingFields$: Observable<{ [key: string]: boolean }> = this.ngxsStore.select(
    FacilityDetailsState.loadingFields
  );

  @Input() canEdit = true;

  protected abstract updateForm(facility: IFacility): void;

  protected abstract createForm(params?: any): void;

  abstract submit(fieldName?: string): void;

  facility: IFacility;
  form: UntypedFormGroup;
  isDetailsLoading = false;

  protected unsubscribe$$: Subject<void> = new Subject<void>();

  ngOnInit(): void {
    this.createForm();

    this.facility$
      .pipe(
        filter((facility) => !!facility),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.facility = facility;
        this.updateForm(this.facility);
      });

    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isDetailsLoading = isLoading));

    this.actions
      .pipe(ofActionCompleted(FacilityDetailsActions.PatchUpdateFailure))
      .subscribe(() => this.updateForm(this.facility));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
