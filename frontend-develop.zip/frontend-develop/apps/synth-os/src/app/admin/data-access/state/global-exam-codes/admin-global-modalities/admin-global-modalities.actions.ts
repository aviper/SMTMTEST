import { IModality } from '../../../../../core/models/types/dictionary';
import { IPaginationPayload } from '../../../../../core/models/types/tables';

export namespace AdminGlobalModalitiesActions {
  export class GetModalities {
    static readonly type = '[Modalities] get modalities';
    constructor(public payload: IPaginationPayload & { query: string }) {}
  }

  export class CreateModality {
    static readonly type = '[Modalities] create modality';
    constructor(public payload: { name: string }) {}
  }

  export class UpdateModality {
    static readonly type = '[Modalities] update modality';
    constructor(public payload: { modalityId: number; modality: IModality }) {}
  }

  export class RequestReload {
    static readonly type = '[Modalities] reload modalities';
  }

  export class DeleteModality {
    static readonly type = '[Modalities] delete modality';
    constructor(public payload: { modalityId: number }) {}
  }

  export class ClearData {
    static readonly type = '[Modalities] clear state';
  }
}
