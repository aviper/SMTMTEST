import {
  ComparisonRule,
  ComparisonRuleGroup,
} from '../../../../feature/admin-tools/tools-comparison-rules/utils/model';

export namespace DefaultComparisonRulesActions {
  export class GetDefaultRules {
    static readonly type = '[Default Comparison Rules] Get Default Rules';
  }

  export class StartEditing {
    static readonly type = '[Default Comparison Rules] Start Editing';
  }

  export class CancelEditing {
    static readonly type = '[Default Comparison Rules] Cancel Editing';
  }

  export class SaveChanges {
    static readonly type = '[Default Comparison Rules] Save Changes';
  }

  export class PendingCreateRule {
    static readonly type = '[Default Comparison Rules] Pending Create Rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        creationData: ComparisonRule;
      }
    ) {}
  }

  export class PendingDeleteRule {
    static readonly type = '[Default Comparison Rules] Pending Delete Rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        index: number;
      }
    ) {}
  }

  export class PendingUpdateRule {
    static readonly type = '[Default Comparison Rules] Pending Update Rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        index: number;
        payload: ComparisonRule;
      }
    ) {}
  }

  export class ClearState {
    static readonly type = '[Default Comparison Rules] Clear State';
  }
}
