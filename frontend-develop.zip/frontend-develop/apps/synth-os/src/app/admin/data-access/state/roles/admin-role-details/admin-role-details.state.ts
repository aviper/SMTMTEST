import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { AdminRoleDetailsActions, UpdateRolePermissionPayload } from './admin-role-details.actions';
import { AdminService } from '../../../../../core/http-services/admin.service';
import {
  IRoleDetails,
  IRolePermission,
  IRolePermissionGroup,
  PermissionAction,
} from '../../../../../core/models/types/acl';
import { IItemResponse } from '../../../../../core/models/types/common';

export interface IAdminRoleDetailsState {
  role: IRoleDetails;
  entitiesInProcess: { entity: IRolePermission; updatingStatuses: { [key in PermissionAction]: boolean } }[];
  permissions: IRolePermissionGroup[];
  query: string;
}

@State<IAdminRoleDetailsState>({
  name: 'roleDetails',
  defaults: {
    role: null,
    entitiesInProcess: [],
    permissions: [],
    query: '',
  },
})
@Injectable()
export class AdminRoleDetailsState {
  @Selector()
  static role(state: IAdminRoleDetailsState): IRoleDetails {
    return state.role;
  }

  @Selector()
  static permissions(state: IAdminRoleDetailsState): IRolePermissionGroup[] {
    return state.permissions;
  }

  @Selector()
  static entitiesInProcess(
    state: IAdminRoleDetailsState
  ): { entity: IRolePermission; updatingStatuses: { [key in PermissionAction]: boolean } }[] {
    return state.entitiesInProcess;
  }

  @Selector()
  static searchPemissions(state: IAdminRoleDetailsState): string {
    return state.query;
  }

  constructor(
    private adminService: AdminService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(AdminRoleDetailsActions.GetRoleDetails, { cancelUncompleted: true })
  getDetails(
    ctx: StateContext<IAdminRoleDetailsState>,
    action: AdminRoleDetailsActions.GetRoleDetails
  ): Observable<IItemResponse> {
    return this.adminService
      .getRoleById(action.payload, { filter: ctx.getState().query }, { autoNotifyErrors: false })
      .pipe(
        tap(
          (res) => {
            ctx.patchState({ role: res.data, permissions: res.data.permissions });
          },
          (error) => this.modalsService.error(error.message)
        )
      );
  }

  @Action(AdminRoleDetailsActions.SearchRolePermissons)
  searchPermissions(
    ctx: StateContext<IAdminRoleDetailsState>,
    action: AdminRoleDetailsActions.SearchRolePermissons
  ): void {
    ctx.patchState({ query: action.payload.query });
    ctx.dispatch(new AdminRoleDetailsActions.GetRoleDetails(action.payload.roleId));
  }

  @Action(AdminRoleDetailsActions.UpdateRolePermission)
  updatePermission(
    ctx: StateContext<IAdminRoleDetailsState>,
    action: AdminRoleDetailsActions.UpdateRolePermission
  ): Observable<IItemResponse> {
    this.pushToEntitiesInProcess(ctx, action.payload);

    const permissionData = { ...action.payload.entity };

    permissionData[action.payload.actionToUpdate] = action.payload.newActionState;

    return this.adminService
      .updateRolePermission(ctx.getState().role.id, permissionData, { autoNotifyErrors: false })
      .pipe(
        tap(
          (res) => {
            ctx.patchState({ permissions: this.findEndReplaceEntity(ctx.getState().permissions, permissionData) });
            this.removeFromEntitiesInProcess(ctx, action.payload);
          },
          (error) => {
            this.removeFromEntitiesInProcess(ctx, action.payload);
            this.modalsService.error(error.message);
          }
        )
      );
  }

  @Action(AdminRoleDetailsActions.ClearData)
  clear(ctx: StateContext<IAdminRoleDetailsState>, _: AdminRoleDetailsActions.ClearData): void {
    ctx.patchState({ role: null, entitiesInProcess: [], permissions: [], query: '' });
  }

  private removeFromEntitiesInProcess(
    ctx: StateContext<IAdminRoleDetailsState>,
    payload: UpdateRolePermissionPayload
  ): void {
    const entitiesInProcess = ctx.getState().entitiesInProcess;
    let processingEntity = entitiesInProcess.find((e) => e.entity.id === payload.entity.id);

    if (processingEntity) {
      processingEntity = {
        ...processingEntity,
        updatingStatuses: { ...processingEntity.updatingStatuses, [payload.actionToUpdate]: false },
      };
      const newEntitiesInProcess = entitiesInProcess.filter((e) => e.entity.id !== payload.entity.id);

      !this.isAllStatusesFalse(processingEntity.updatingStatuses) && newEntitiesInProcess.push(processingEntity);

      ctx.patchState({ entitiesInProcess: newEntitiesInProcess });
    }
  }

  private pushToEntitiesInProcess(
    ctx: StateContext<IAdminRoleDetailsState>,
    payload: UpdateRolePermissionPayload
  ): void {
    const entitiesInProcess = ctx.getState().entitiesInProcess;
    let processingEntity = entitiesInProcess.find((e) => e.entity.id === payload.entity.id);

    if (processingEntity) {
      processingEntity = {
        ...processingEntity,
        updatingStatuses: { ...processingEntity.updatingStatuses, [payload.actionToUpdate]: true },
      };
      ctx.patchState({
        entitiesInProcess: [...entitiesInProcess.filter((e) => e.entity.id !== payload.entity.id), processingEntity],
      });
    } else {
      processingEntity = {
        entity: payload.entity,
        updatingStatuses: {
          read: false,
          create: false,
          update: false,
          delete: false,
        },
      };
      processingEntity.updatingStatuses[payload.actionToUpdate] = true;

      ctx.patchState({
        entitiesInProcess: [...entitiesInProcess, processingEntity],
      });
    }
  }

  private isAllStatusesFalse(statuses: { [key in PermissionAction]: boolean }): boolean {
    return !statuses.delete && !statuses.update && !statuses.read && !statuses.create;
  }

  private findEndReplaceEntity(entities: IRolePermissionGroup[], newEntity: IRolePermission): IRolePermissionGroup[] {
    return entities.map((group) => {
      const mappedEntities = group.data.map((entity) => (entity.id === newEntity.id ? newEntity : entity));

      return { ...group, data: mappedEntities };
    });
  }
}
