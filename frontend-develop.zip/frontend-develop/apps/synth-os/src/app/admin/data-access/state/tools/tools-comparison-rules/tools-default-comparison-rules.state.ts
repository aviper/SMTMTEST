import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { forkJoin, Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { DefaultComparisonRulesActions } from './tools-default-comparison-rules.actions';
import { Helper } from '../../../../../core/helpers/helper';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { ComparisonRulesService } from '../../../../feature/admin-tools/tools-comparison-rules/data-access/comparison-rules.service';
import {
  createRule,
  deleteRule,
  mapRuleChangesIntoApiCalls,
  updateRule,
} from '../../../../feature/admin-tools/tools-comparison-rules/utils/default-comparison-rules-change.helpers';
import { ComparisonRuleGroup } from '../../../../feature/admin-tools/tools-comparison-rules/utils/model';

export interface ToolsDefaultComparisonRulesState {
  rules: ComparisonRuleGroup[];
  editingRules: ComparisonRuleGroup[];
  loading: boolean;
  editing: boolean;
  saving: boolean;
}

@State<ToolsDefaultComparisonRulesState>({
  name: 'defaultComparisonRules',
  defaults: {
    rules: [],
    editingRules: [],
    loading: false,
    editing: false,
    saving: false,
  },
})
@Injectable()
export class DefaultComparisonRulesState {
  @Selector()
  static rules(state: ToolsDefaultComparisonRulesState): ComparisonRuleGroup[] {
    return state.editing ? state.editingRules : state.rules;
  }

  @Selector()
  static loading(state: ToolsDefaultComparisonRulesState): boolean {
    return state.loading;
  }

  @Selector()
  static editing(state: ToolsDefaultComparisonRulesState): boolean {
    return state.editing;
  }

  @Selector()
  static saving(state: ToolsDefaultComparisonRulesState): boolean {
    return state.saving;
  }

  constructor(
    private comparisonRulesService: ComparisonRulesService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(DefaultComparisonRulesActions.GetDefaultRules)
  getDefaultRules(ctx: StateContext<ToolsDefaultComparisonRulesState>): Observable<IListResponse> {
    ctx.patchState({
      loading: true,
      rules: [],
    });

    return this.comparisonRulesService.getDefaultRules().pipe(
      tap({
        next: (res) => {
          ctx.patchState({
            rules: res.data,
            loading: false,
          });
        },
        error: () => {
          ctx.patchState({
            loading: false,
          });
        },
      })
    );
  }

  @Action(DefaultComparisonRulesActions.StartEditing)
  startEditing(ctx: StateContext<ToolsDefaultComparisonRulesState>): void {
    ctx.patchState({
      editingRules: Helper.cloneDeep(ctx.getState().rules),
      editing: true,
    });
  }

  @Action(DefaultComparisonRulesActions.CancelEditing)
  cancelEditing(ctx: StateContext<ToolsDefaultComparisonRulesState>): void {
    ctx.patchState({
      editingRules: [],
      editing: false,
    });
  }

  @Action(DefaultComparisonRulesActions.SaveChanges)
  saveChanges(ctx: StateContext<ToolsDefaultComparisonRulesState>): Observable<IItemResponse[]> {
    ctx.patchState({
      saving: true,
    });

    const actions: {
      createActions: Array<Observable<IItemResponse>>;
      updateActions: Array<Observable<IItemResponse>>;
      deleteActions: Array<Observable<IItemResponse>>;
    } = mapRuleChangesIntoApiCalls(ctx.getState().rules, ctx.getState().editingRules, this.comparisonRulesService);

    const mappedActions: Observable<IItemResponse>[] = []
      .concat(actions.createActions.map((action) => this.appendErrorHandling(action)))
      .concat(actions.updateActions.map((action) => this.appendErrorHandling(action)))
      .concat(actions.deleteActions.map((action) => this.appendErrorHandling(action)));

    if (!mappedActions.length) {
      ctx.patchState({
        editingRules: [],
        editing: false,
        saving: false,
      });
      this.modalsService.success('No changes to save');

      return of([]);
    }

    return forkJoin(mappedActions).pipe(
      tap({
        next: (responses) => {
          const errors = responses.filter((response) => !!response?.data?.error);

          if (errors.length) {
            const templateError = errors.map((error) => error.data.error).join('<br/>');

            this.modalsService.error(`Some changes were not saved:<br/>${templateError}`, true, 5000);
          } else {
            this.modalsService.success('Changes saved');
          }

          ctx.patchState({
            editingRules: [],
            editing: false,
            saving: false,
          });
          ctx.dispatch(new DefaultComparisonRulesActions.GetDefaultRules());
        },
      })
    );
  }

  @Action(DefaultComparisonRulesActions.PendingCreateRule)
  pendingCreateRule(
    ctx: StateContext<ToolsDefaultComparisonRulesState>,
    action: DefaultComparisonRulesActions.PendingCreateRule
  ): void {
    const editingRules = Helper.cloneDeep(ctx.getState().editingRules);

    ctx.patchState({
      editingRules: createRule(editingRules, action.payload),
    });
  }

  @Action(DefaultComparisonRulesActions.PendingDeleteRule)
  pendingDeleteRule(
    ctx: StateContext<ToolsDefaultComparisonRulesState>,
    action: DefaultComparisonRulesActions.PendingDeleteRule
  ): void {
    const editingRules = Helper.cloneDeep(ctx.getState().editingRules);

    ctx.patchState({
      editingRules: deleteRule(editingRules, action.payload),
    });
  }

  @Action(DefaultComparisonRulesActions.PendingUpdateRule)
  pendingUpdateRule(
    ctx: StateContext<ToolsDefaultComparisonRulesState>,
    action: DefaultComparisonRulesActions.PendingUpdateRule
  ): void {
    const editingRules = Helper.cloneDeep(ctx.getState().editingRules);

    ctx.patchState({
      editingRules: updateRule(editingRules, action.payload),
    });
  }

  @Action(DefaultComparisonRulesActions.ClearState)
  clearState(ctx: StateContext<ToolsDefaultComparisonRulesState>): void {
    ctx.patchState({
      rules: [],
      editingRules: [],
      loading: false,
      editing: false,
      saving: false,
    });
  }

  private appendErrorHandling(observable: Observable<IItemResponse>): Observable<IItemResponse> {
    return observable.pipe(
      catchError((error) =>
        of({
          data: {
            error: error.message,
          },
        })
      )
    );
  }
}
