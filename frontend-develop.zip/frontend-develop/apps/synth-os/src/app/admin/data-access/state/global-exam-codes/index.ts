import { AdminGlobalExamCodesListState } from './admin-global-exam-codes-list/admin-global-exam-codes-list.state';
import { AdminGlobalModalitiesState } from './admin-global-modalities/admin-global-modalities.state';
import { AdminGlobalRegionsState } from './admin-global-regions/admin-global-regions.state';

export const ADMIN_GLOBAL_EXAM_CODES_STATES: any[] = [
  AdminGlobalExamCodesListState,
  AdminGlobalModalitiesState,
  AdminGlobalRegionsState,
];
