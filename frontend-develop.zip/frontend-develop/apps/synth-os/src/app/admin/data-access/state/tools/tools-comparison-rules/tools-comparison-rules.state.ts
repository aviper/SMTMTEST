import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import { IFacilityWithDefaultPriorRelevancyRule } from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';

import { ComparisonRulesActions } from './tools-comparison-rules.actions';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { FacilitiesService } from '../../../../../core/http-services/facilities.service';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { IModality } from '../../../../../core/models/types/dictionary';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { ComparisonRulesService } from '../../../../feature/admin-tools/tools-comparison-rules/data-access/comparison-rules.service';
import { ComparisonRuleGroup } from '../../../../feature/admin-tools/tools-comparison-rules/utils/model';

export interface IComparisonRulesState {
  facilityGroup: IFacilityGroup;
  facility: IFacilityWithDefaultPriorRelevancyRule;
  rules: ComparisonRuleGroup[];
  isLoading: boolean;
  modalities: IModality[];
  modalitiesLoading: boolean;
}

@State<IComparisonRulesState>({
  name: 'comparisonRules',
  defaults: {
    facilityGroup: null,
    facility: null,
    rules: [],
    isLoading: false,
    modalities: [],
    modalitiesLoading: false,
  },
})
@Injectable()
export class ComparisonRulesState {
  @Selector()
  static facilityGroup(state: IComparisonRulesState): IFacilityGroup {
    return state.facilityGroup;
  }

  @Selector()
  static facility(state: IComparisonRulesState): IFacilityWithDefaultPriorRelevancyRule {
    return state.facility;
  }

  @Selector()
  static isLoading(state: IComparisonRulesState): boolean {
    return state.isLoading;
  }

  @Selector()
  static rules(state: IComparisonRulesState): ComparisonRuleGroup[] {
    const shouldFilter = state.facility?.defaultPriorRelevancyRule;

    return shouldFilter ? state.rules.filter((r) => r.type === 'default') : state.rules;
  }

  @Selector()
  static modalities(state: IComparisonRulesState): IModality[] {
    return state.modalities;
  }

  @Selector()
  static modalitiesLoading(state: IComparisonRulesState): boolean {
    return state.modalitiesLoading;
  }

  constructor(
    private comparisonRulesService: ComparisonRulesService,
    private facilityService: FacilitiesService,
    private dictionaryService: DictionaryService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(ComparisonRulesActions.SetFacilityGroup)
  setFacilityGroup(ctx: StateContext<IComparisonRulesState>, action: ComparisonRulesActions.SetFacilityGroup): void {
    ctx.patchState({ facilityGroup: action.payload });
  }

  @Action(ComparisonRulesActions.SetFacility)
  selectFacility(ctx: StateContext<IComparisonRulesState>, action: ComparisonRulesActions.SetFacility): void {
    ctx.patchState({
      facility: action.payload,
    });
  }

  @Action(ComparisonRulesActions.GetRules)
  getRules(ctx: StateContext<IComparisonRulesState>): Observable<IListResponse> {
    if (!ctx.getState().facility?.id) {
      return of(null);
    }

    ctx.patchState({ isLoading: true, rules: [] });

    return this.comparisonRulesService.getRules(ctx.getState().facility.id).pipe(
      tap({
        next: (res) => {
          ctx.patchState({
            rules: res.data,
            isLoading: false,
          });
        },
        error: () => ctx.patchState({ isLoading: false }),
      })
    );
  }

  @Action(ComparisonRulesActions.DeleteRule)
  deleteRule(
    ctx: StateContext<IComparisonRulesState>,
    action: ComparisonRulesActions.DeleteRule
  ): Observable<IItemResponse> {
    return this.comparisonRulesService
      .deleteCustomRuleController(ctx.getState().facility.id, action.payload, { autoNotifyErrors: false })
      .pipe(
        tap({
          next: () => ctx.dispatch(new ComparisonRulesActions.GetRules()),
          error: (error) => this.modalsService.error(error.message),
        })
      );
  }

  @Action(ComparisonRulesActions.UpdateRule)
  updateRule(
    ctx: StateContext<IComparisonRulesState>,
    action: ComparisonRulesActions.UpdateRule
  ): Observable<IItemResponse> {
    return this.comparisonRulesService
      .updateCustomRuleController(ctx.getState().facility.id, action.payload, { autoNotifyErrors: false })
      .pipe(
        tap({
          next: () => ctx.dispatch(new ComparisonRulesActions.GetRules()),
          error: (error) => this.modalsService.error(error.message),
        })
      );
  }

  @Action(ComparisonRulesActions.CreateRule)
  createRule(
    ctx: StateContext<IComparisonRulesState>,
    action: ComparisonRulesActions.CreateRule
  ): Observable<IItemResponse> {
    return this.comparisonRulesService
      .createCustomRuleController(ctx.getState().facility.id, action.payload, { autoNotifyErrors: false })
      .pipe(
        tap({
          next: () => ctx.dispatch(new ComparisonRulesActions.GetRules()),
          error: (error) => this.modalsService.error(error.message),
        })
      );
  }

  @Action(ComparisonRulesActions.GetModalities)
  getModalities(ctx: StateContext<IComparisonRulesState>): Observable<IListResponse> {
    ctx.patchState({
      modalitiesLoading: true,
    });

    return this.dictionaryService
      .getModalities({
        limit: 100,
        offset: 0,
      })
      .pipe(
        tap({
          next: (res) => {
            ctx.patchState({
              modalities: res.data,
              modalitiesLoading: false,
            });
          },
          error: (error) => {
            this.modalsService.error(error.message);
            ctx.patchState({
              modalitiesLoading: false,
            });
          },
        })
      );
  }

  @Action(ComparisonRulesActions.ClearState)
  clearState(ctx: StateContext<IComparisonRulesState>, _: ComparisonRulesActions.ClearState): void {
    ctx.patchState({
      facilityGroup: null,
      facility: null,
      rules: [],
      isLoading: false,
    });
  }
}
