import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

import { ApiListResponse } from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { PlayBookFormsActions } from './playbook-forms.actions';
import { PlayBookService } from '../../../../../core/http-services/playbook.service';
import { IHumanErrorBody, IItemResponse, ISort } from '../../../../../core/models/types/common';
import { ICustomForm, ICustomFormsTableQuery } from '../../../../../core/models/types/custom-fields-and-forms';
import { IFilterMap } from '../../../../../core/models/types/filter';

export interface IPlayBookFormsState {
  forms: ICustomForm[];
  filters: IFilterMap;
  isLoading: boolean;
  sort: ISort;
  query: ICustomFormsTableQuery;
  pagination: IPagination;
  scrolledDistance: number;
  granularLoadings: Record<string, boolean>;
}

export const PLAYBOOK_FORMS_DEFAULT_SORT: ISort = {
  sortField: 'name',
  direction: 'asc',
};

@State<IPlayBookFormsState>({
  name: 'playBookForms',
  defaults: {
    forms: [],
    filters: {},
    isLoading: false,
    sort: { ...PLAYBOOK_FORMS_DEFAULT_SORT },
    query: {},
    pagination: { ...PAGINATION },
    scrolledDistance: 0,
    granularLoadings: {},
  },
})
@Injectable()
export class PlayBookFormsState {
  @Selector()
  static forms(state: IPlayBookFormsState): ICustomForm[] {
    return state.forms;
  }

  @Selector()
  static isLoading(state: IPlayBookFormsState): boolean {
    return state.isLoading;
  }

  @Selector()
  static sort(state: IPlayBookFormsState): ISort {
    return state.sort;
  }

  @Selector()
  static pagination(state: IPlayBookFormsState): IPagination {
    return state.pagination;
  }

  @Selector()
  static scrolledDistance(state: IPlayBookFormsState): number {
    return state.scrolledDistance;
  }

  @Selector()
  static query(state: IPlayBookFormsState): ICustomFormsTableQuery {
    return state.query;
  }

  @Selector()
  static filters(state: IPlayBookFormsState): IFilterMap {
    return state.filters;
  }

  @Selector()
  static granularLoadings(state: IPlayBookFormsState): Record<string, boolean> {
    return state.granularLoadings;
  }

  constructor(
    private playbookService: PlayBookService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(PlayBookFormsActions.GetForms)
  getForms(
    ctx: StateContext<IPlayBookFormsState>,
    { payload }: PlayBookFormsActions.GetForms
  ): Observable<IItemResponse> {
    ctx.patchState({
      isLoading: true,
    });

    const state = ctx.getState();

    return this.playbookService
      .getPlayBookForms({
        limit: payload.limit,
        offset: payload.offset,
        ...state.query,
        ...state.sort,
        ...state.filters,
      })
      .pipe(
        finalize(() => ctx.patchState({ isLoading: false })),
        tap({
          next: ({ data, count }: ApiListResponse<ICustomForm>) => {
            const pagination = payload.offset
              ? {
                  ...state.pagination,
                  page: state.pagination.page + 1,
                  lastChunkSize: data.length,
                  offset: payload.offset,
                  total: count,
                }
              : {
                  ...PAGINATION,
                  lastChunkSize: data.length,
                  total: count,
                };

            ctx.patchState({
              forms: payload.offset ? state.forms.concat(data) : data,
              pagination,
            });
          },
          error: (error: IHumanErrorBody) => {
            this.modalsService.error(error.message);
            ctx.patchState({
              forms: [],
              pagination: { ...PAGINATION },
            });
          },
        })
      );
  }

  @Action(PlayBookFormsActions.UpdateForm)
  updateCustomForm(
    ctx: StateContext<IPlayBookFormsState>,
    { payload: { id, body } }: PlayBookFormsActions.UpdateForm
  ): Observable<IItemResponse> {
    ctx.dispatch(new PlayBookFormsActions.PatchGranularLoadings({ [id]: true }));

    return this.playbookService.editCustomForm(id, body).pipe(
      finalize(() => ctx.dispatch(new PlayBookFormsActions.PatchGranularLoadings({ [id]: false }))),
      tap({
        next: ({ data }) => {
          const forms = [...ctx.getState().forms];
          const formIndex = forms.findIndex((f) => f.id === id);

          if (formIndex !== -1) {
            forms[formIndex] = {
              ...forms[formIndex],
              ...data,
            };
          }

          ctx.patchState({
            forms,
          });
          this.modalsService.success(`Form ${body.name} was successfully edited`);
        },
        error: (err: IHumanErrorBody) => {
          this.modalsService.error(err.message);
        },
      })
    );
  }

  @Action(PlayBookFormsActions.DeleteForm)
  deleteForm(
    ctx: StateContext<IPlayBookFormsState>,
    action: PlayBookFormsActions.DeleteForm
  ): Observable<IItemResponse> {
    const state = ctx.getState();

    return this.playbookService.deletePlayBookForm(action.payload.id).pipe(
      tap({
        next: () => {
          const deletedForm = state.forms.find((f) => f.id === action.payload.id);

          this.modalsService.success(`Form ${deletedForm.name} was successfully deleted`);
          ctx.dispatch(new PlayBookFormsActions.ReloadForms());
        },
        error: (error) => {
          this.modalsService.error(error.message);
        },
      })
    );
  }

  @Action(PlayBookFormsActions.UpdateSorting)
  updateSorting(ctx: StateContext<IPlayBookFormsState>, action: PlayBookFormsActions.UpdateSorting): void {
    ctx.patchState({
      sort: action.payload,
    });

    ctx.dispatch(new PlayBookFormsActions.ReloadForms());
  }

  @Action(PlayBookFormsActions.UpdateQuery)
  updateQuery(ctx: StateContext<IPlayBookFormsState>, action: PlayBookFormsActions.UpdateQuery): void {
    ctx.patchState({
      query: action.payload,
    });

    ctx.dispatch(new PlayBookFormsActions.ReloadForms());
  }

  @Action(PlayBookFormsActions.UpdateFilters)
  updateFilters(ctx: StateContext<IPlayBookFormsState>, action: PlayBookFormsActions.UpdateFilters): void {
    const { status, ...filters } = action.payload;

    ctx.patchState({
      filters: {
        ...filters,
        ifActive: status,
      },
    });

    ctx.dispatch(new PlayBookFormsActions.ReloadForms());
  }

  @Action(PlayBookFormsActions.UpdateScrolledDistance)
  updateScrollDistance(
    ctx: StateContext<IPlayBookFormsState>,
    action: PlayBookFormsActions.UpdateScrolledDistance
  ): void {
    ctx.patchState({
      scrolledDistance: action.payload,
    });
  }

  @Action(PlayBookFormsActions.PatchGranularLoadings)
  patchGranularLoadings(
    ctx: StateContext<IPlayBookFormsState>,
    action: PlayBookFormsActions.PatchGranularLoadings
  ): void {
    const state = ctx.getState();

    ctx.patchState({
      granularLoadings: {
        ...state.granularLoadings,
        ...action.payload,
      },
    });
  }

  @Action(PlayBookFormsActions.ClearData)
  clearData(ctx: StateContext<IPlayBookFormsState>, _action: PlayBookFormsActions.ClearData): void {
    ctx.setState({
      forms: [],
      isLoading: false,
      sort: { ...PLAYBOOK_FORMS_DEFAULT_SORT },
      query: {},
      pagination: { ...PAGINATION },
      scrolledDistance: 0,
      filters: {},
      granularLoadings: {},
    });
  }
}
