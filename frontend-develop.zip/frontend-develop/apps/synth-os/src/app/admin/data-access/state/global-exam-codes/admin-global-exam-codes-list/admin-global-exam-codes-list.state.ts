import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { AdminGlobalExamCodesListActions } from './admin-global-exam-codes-list.actions';
import { CPT_CODE_STAGE } from '../../../../../core/constants/constants';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { IItemResponse, IListResponse, ISort } from '../../../../../core/models/types/common';
import { ICTPCode, IDefaultFinding } from '../../../../../core/models/types/dictionary';
import { IFilterMapValue } from '../../../../../core/models/types/filter';

export interface IAdminGlobalExamCodesListState {
  cptCodes: ICTPCode[];
  isLoading: boolean;
  shouldBeReloaded: boolean;
  lastChunkSize: number;
  sort: object;
  filters: IFilterMapValue;
  showExpiredExamCode: boolean;
  query: string;
}

@State<IAdminGlobalExamCodesListState>({
  name: 'globalExamCodesList',
  defaults: {
    cptCodes: [],
    isLoading: false,
    shouldBeReloaded: false,
    lastChunkSize: 0,
    sort: {},
    filters: {},
    showExpiredExamCode: false,
    query: '',
  },
})
@Injectable()
export class AdminGlobalExamCodesListState {
  @Selector()
  static reload(state: IAdminGlobalExamCodesListState): boolean {
    return state.shouldBeReloaded;
  }

  @Selector()
  static isLoading(state: IAdminGlobalExamCodesListState): boolean {
    return state.isLoading;
  }

  @Selector()
  static showExpiredExamCode(state: IAdminGlobalExamCodesListState): boolean {
    return state.showExpiredExamCode;
  }

  @Selector()
  static cptCodes(state: IAdminGlobalExamCodesListState): {
    cptCodes: ICTPCode[];
    isLoading: boolean;
    lastChunkSize: number;
  } {
    return { cptCodes: state.cptCodes, lastChunkSize: state.lastChunkSize, isLoading: state.isLoading };
  }

  @Selector()
  static sort(state: IAdminGlobalExamCodesListState): ISort | {} {
    return state.sort;
  }

  @Selector()
  static filters(state: IAdminGlobalExamCodesListState): IFilterMapValue {
    return state.filters;
  }

  @Selector()
  static query(state: IAdminGlobalExamCodesListState): string {
    return state.query;
  }

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private dictionaryService: DictionaryService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(AdminGlobalExamCodesListActions.GetCptCodes)
  getCptCodes(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.GetCptCodes
  ): Observable<IListResponse> {
    const state = ctx.getState();

    ctx.patchState({ isLoading: true });
    this.unsubscribe$$.next();

    return this.dictionaryService
      .getCTPCodes({
        limit: action.payload.limit,
        offset: action.payload.offset,
        ...state.sort,
        ...state.filters,
        query: state.query,
        fromAdmin: true,
        global: true,
        showExpiredExamCode: state.showExpiredExamCode,
      })
      .pipe(
        takeUntil(this.unsubscribe$$),
        tap((res) => {
          ctx.patchState({
            cptCodes: action.payload.offset ? state.cptCodes.concat(res.data) : res.data,
            lastChunkSize: res.data.length,
            isLoading: false,
            shouldBeReloaded: false,
          });
        })
      );
  }

  @Action(AdminGlobalExamCodesListActions.UpdateCptModality)
  updateModality(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.UpdateCptModality
  ): Observable<IItemResponse> {
    return this.dictionaryService
      .setModalityToCtpCode(action.payload.cptCode.id, {
        modalityId: action.payload.modalityId,
      })
      .pipe(
        tap((res) => {
          const updatedCpt: ICTPCode = res.data;
          const cptCodes = ctx.getState().cptCodes.map((cptCode) => {
            if (cptCode.id === updatedCpt.id) {
              return updatedCpt;
            }

            return cptCode;
          });

          ctx.patchState({ cptCodes });
        })
      );
  }

  @Action(AdminGlobalExamCodesListActions.SortCptCodes)
  sortCptCodes(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.SortCptCodes
  ): void {
    ctx.patchState({ sort: action.payload });
  }

  @Action(AdminGlobalExamCodesListActions.SearchCptCodes)
  searchCpts(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.SearchCptCodes
  ): void {
    ctx.patchState({ query: action.payload });

    ctx.dispatch(new AdminGlobalExamCodesListActions.RequestReload());
  }

  @Action(AdminGlobalExamCodesListActions.RequestReload)
  ReloadCptCodes(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    _: AdminGlobalExamCodesListActions.RequestReload
  ): void {
    ctx.patchState({ shouldBeReloaded: true });
  }

  @Action(AdminGlobalExamCodesListActions.DeleteCptDefaultFindings)
  deleteCptFindings(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.DeleteCptDefaultFindings
  ): void {
    const globalDefaultFindings = action.payload.cptCodesFindings.find(
      (findings: IDefaultFinding) => findings.type === CPT_CODE_STAGE.global
    );

    if (!globalDefaultFindings) {
      return;
    }

    this.dictionaryService.deleteCptCode(action.payload.id, globalDefaultFindings.id).pipe(
      tap(() => {
        this.modalsService.success('Default findings deleted');
        ctx.dispatch(new AdminGlobalExamCodesListActions.RequestReload());
      })
    );
  }

  @Action(AdminGlobalExamCodesListActions.UpdateCptFilters)
  updateFilters(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.UpdateCptFilters
  ): void {
    ctx.patchState({ filters: action.payload });

    ctx.dispatch(new AdminGlobalExamCodesListActions.RequestReload());
  }

  @Action(AdminGlobalExamCodesListActions.UpdateShowExpiredExamCodeStatus)
  updateShowExpiredExamCodeStatus(
    ctx: StateContext<IAdminGlobalExamCodesListState>,
    action: AdminGlobalExamCodesListActions.UpdateShowExpiredExamCodeStatus
  ): void {
    ctx.patchState({ showExpiredExamCode: action.payload });

    ctx.dispatch(new AdminGlobalExamCodesListActions.RequestReload());
  }

  @Action(AdminGlobalExamCodesListActions.ClearData)
  clearData(ctx: StateContext<IAdminGlobalExamCodesListState>, _: AdminGlobalExamCodesListActions.ClearData): void {
    ctx.patchState({
      cptCodes: [],
      lastChunkSize: 0,
      isLoading: false,
      shouldBeReloaded: false,
      sort: {},
      filters: {},
      showExpiredExamCode: false,
      query: '',
    });
    this.unsubscribe$$.next();
  }
}
