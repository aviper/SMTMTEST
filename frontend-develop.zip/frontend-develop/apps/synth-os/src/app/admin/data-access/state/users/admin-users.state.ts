import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { AdminUsersActions } from './admin-users.actions';
import { ROLE_TYPES } from '../../../../core/constants/constants';
import { UserService } from '../../../../core/http-services/user.service';
import { IItemResponse, IListResponse, ISort } from '../../../../core/models/types/common';
import { IFilterMapValue } from '../../../../core/models/types/filter';
import { ISimpleUser } from '../../../../core/models/types/user';
import { ProfileState } from '../../../../profile/data-access/state/profile/profile.state';
import { USERS_PAGE_TABS } from '../../../utils/constants';

// tslint:disable-next-line: no-empty-interface
export interface IAdminUsersState {
  users: ISimpleUser[];
  isLoading: boolean;
  shouldBeReloaded: boolean;
  lastChunkSize: number;
  type: string;
  sort: object;
  filters: IFilterMapValue;
}

@State<IAdminUsersState>({
  name: 'adminUsers',
  defaults: {
    users: [],
    type: null,
    isLoading: false,
    shouldBeReloaded: false,
    lastChunkSize: 0,
    sort: {},
    filters: {},
  },
})
@Injectable()
export class AdminUsersState {
  @Selector()
  static reload(state: IAdminUsersState): boolean {
    return state.shouldBeReloaded;
  }

  @Selector()
  static isLoading(state: IAdminUsersState): boolean {
    return state.isLoading;
  }

  @Selector()
  static users(state: IAdminUsersState): { users: ISimpleUser[]; isLoading: boolean; lastChunkSize: number } {
    return { users: state.users, lastChunkSize: state.lastChunkSize, isLoading: state.isLoading };
  }

  @Selector()
  static sort(state: IAdminUsersState): ISort | {} {
    return state.sort;
  }

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private userService: UserService,
    private store: Store
  ) {}

  @Action(AdminUsersActions.GetUsers)
  getUsers(ctx: StateContext<IAdminUsersState>, action: AdminUsersActions.GetUsers): Observable<IListResponse> {
    const state = ctx.getState();
    const currentUser = this.store.selectSnapshot(ProfileState.user);
    const newType = action.payload.type || state.type;

    ctx.patchState({
      type: newType,
      isLoading: true,
      shouldBeReloaded: false,
    });

    this.unsubscribe$$.next(); // Unsubscribe from prev request if user click fast sorting

    return this.getUsersRequest(newType, {
      limit: action.payload.limit,
      offset: action.payload.offset,
      query: action.payload.query,
      ...state.sort,
      ...state.filters,
      ...(currentUser.role.type === ROLE_TYPES.groupLocal && { ownGroups: true }),
    }).pipe(
      takeUntil(this.unsubscribe$$),
      tap((res) => {
        ctx.patchState({
          users: action.payload.offset ? state.users.concat(res.data) : res.data,
          lastChunkSize: res.data.length,
          isLoading: false,
        });
      })
    );
  }

  @Action(AdminUsersActions.SortUsers)
  sortCptCodes(ctx: StateContext<IAdminUsersState>, action: AdminUsersActions.SortUsers): void {
    ctx.patchState({ sort: action.payload });
  }

  @Action(AdminUsersActions.RequestReload)
  ReloadCptCodes(ctx: StateContext<IAdminUsersState>, _: AdminUsersActions.RequestReload): void {
    ctx.patchState({ shouldBeReloaded: true });
  }

  @Action(AdminUsersActions.UpdateUsersFilters)
  updateFilters(ctx: StateContext<IAdminUsersState>, action: AdminUsersActions.UpdateUsersFilters): void {
    ctx.patchState({ filters: action.payload });

    ctx.dispatch(new AdminUsersActions.RequestReload());
  }

  private getUsersRequest(type: string, params: any): Observable<IListResponse> {
    switch (type) {
      case USERS_PAGE_TABS.current:
        return this.userService.getUsers(params);
      case USERS_PAGE_TABS.invited:
        return this.userService.getInvitedUsers(params);
      case USERS_PAGE_TABS.deleted:
        return this.userService.getUsers({
          ...params,
          deleted: 'true',
        });
      case USERS_PAGE_TABS.locked:
        return this.userService.getUsers({
          ...params,
          isLocked: 'true',
        });
      case USERS_PAGE_TABS.unknown:
        return this.userService.getUsers({
          ...params,
          alias: 'unknown',
        });
    }
  }

  @Action(AdminUsersActions.UnlockUser)
  unlockUser(ctx: StateContext<IAdminUsersState>, action: AdminUsersActions.UnlockUser): Observable<IItemResponse> {
    const state = ctx.getState();
    const userId = action.payload.userId;

    ctx.patchState({
      users: [],
      isLoading: true,
    });

    return this.userService.unlockUser(userId).pipe(
      tap(() => {
        const filteredUsers = state.users.filter((user) => user.id !== userId);

        ctx.patchState({
          users: filteredUsers,
          isLoading: false,
        });
      })
    );
  }

  @Action(AdminUsersActions.ClearState)
  clearStore(ctx: StateContext<IAdminUsersState>): void {
    ctx.setState({
      users: [],
      lastChunkSize: 0,
      type: null,
      isLoading: false,
      shouldBeReloaded: false,
      sort: {},
      filters: {},
    });
    this.unsubscribe$$.next();
  }
}
