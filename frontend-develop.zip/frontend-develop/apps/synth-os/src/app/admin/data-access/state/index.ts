import { ADMIN_GLOBAL_EXAM_CODES_STATES } from './global-exam-codes';
import { ADMIN_PLAYBOOK_STATES } from './playbook';
import { ADMIN_ROLES_STATES } from './roles';
import { ADMIN_TOOLS_STATES } from './tools';
import { AdminUsersState } from './users/admin-users.state';

export const ADMIN_PANEL_STATES: any[] = [
  AdminUsersState,
  ...ADMIN_ROLES_STATES,
  ...ADMIN_GLOBAL_EXAM_CODES_STATES,
  ...ADMIN_TOOLS_STATES,
  ...ADMIN_PLAYBOOK_STATES,
];
