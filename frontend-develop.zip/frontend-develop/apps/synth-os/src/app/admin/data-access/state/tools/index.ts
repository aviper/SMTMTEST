import { ComparisonRulesState } from './tools-comparison-rules/tools-comparison-rules.state';
import { DefaultComparisonRulesState } from './tools-comparison-rules/tools-default-comparison-rules.state';
import { ToolsConfigurePresetsState } from './tools-configure-presets/tools-configure-presets.state';

export const ADMIN_TOOLS_STATES: any[] = [
  ToolsConfigurePresetsState,
  ComparisonRulesState,
  DefaultComparisonRulesState,
];
