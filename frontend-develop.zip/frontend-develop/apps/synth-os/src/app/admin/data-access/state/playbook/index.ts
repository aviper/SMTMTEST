import { PlayBookFieldsState } from './playbook-fields/playbook-fields.state';
import { PlayBookFormsState } from './playbook-forms/playbook-forms.state';

export const ADMIN_PLAYBOOK_STATES: any[] = [PlayBookFieldsState, PlayBookFormsState];
