import { Injectable } from '@angular/core';

import { PERMISSIONS_ENDPOINTS } from '../../core/constants/endpoints';
import { UserPermissions } from '../../core/models/classes/userPermissions';

@Injectable({
  providedIn: 'root',
})
export class AdminToolsCheckingService {
  canReadBlockUpload(permissions: UserPermissions): boolean {
    return (
      permissions.canRead(PERMISSIONS_ENDPOINTS.uploadDicoms) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.uploadH7) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.uploadMobileApp)
    );
  }

  canReadBlockRemove(permissions: UserPermissions): boolean {
    return (
      permissions.canRead(PERMISSIONS_ENDPOINTS.removeFacilities) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.removeOrder)
    );
  }

  canReadBlockOther(permissions: UserPermissions): boolean {
    return (
      permissions.canRead(PERMISSIONS_ENDPOINTS.ordersDlq) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.searchStudy) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.banners) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.generateDicom) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.contractHolder) ||
      permissions.canRead(PERMISSIONS_ENDPOINTS.servicesManagement)
    );
  }
}
