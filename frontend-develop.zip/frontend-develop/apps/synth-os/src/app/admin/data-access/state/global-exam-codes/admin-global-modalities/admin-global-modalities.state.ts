import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { AdminGlobalModalitiesActions } from './admin-global-modalities.actions';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { IModality } from '../../../../../core/models/types/dictionary';

export interface IAdminGlobalModalitiesState {
  modalities: IModality[];
  isLoading: boolean;
  shouldBeReloaded: boolean;
  lastChunkSize: number;
}

@State<IAdminGlobalModalitiesState>({
  name: 'globalModalities',
  defaults: {
    modalities: [],
    isLoading: false,
    shouldBeReloaded: false,
    lastChunkSize: 0,
  },
})
@Injectable()
export class AdminGlobalModalitiesState {
  @Selector()
  static reload(state: IAdminGlobalModalitiesState): boolean {
    return state.shouldBeReloaded;
  }

  @Selector()
  static isLoading(state: IAdminGlobalModalitiesState): boolean {
    return state.isLoading;
  }

  @Selector()
  static modalities(state: IAdminGlobalModalitiesState): {
    modalities: IModality[];
    isLoading: boolean;
    lastChunkSize: number;
  } {
    return { modalities: state.modalities, lastChunkSize: state.lastChunkSize, isLoading: state.isLoading };
  }

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private dictionaryService: DictionaryService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(AdminGlobalModalitiesActions.GetModalities)
  getModalities(
    ctx: StateContext<IAdminGlobalModalitiesState>,
    action: AdminGlobalModalitiesActions.GetModalities
  ): Observable<IListResponse> {
    const state = ctx.getState();

    ctx.patchState({ isLoading: true });
    this.unsubscribe$$.next();

    return this.dictionaryService
      .getModalities({
        limit: action.payload.limit,
        offset: action.payload.offset,
        query: action.payload.query,
        filter: 'all',
      })
      .pipe(
        takeUntil(this.unsubscribe$$),
        tap((res) => {
          ctx.patchState({
            modalities: action.payload.offset ? state.modalities.concat(res.data) : res.data,
            lastChunkSize: res.data.length,
            isLoading: false,
            shouldBeReloaded: false,
          });
        })
      );
  }

  @Action(AdminGlobalModalitiesActions.CreateModality)
  createModality(
    ctx: StateContext<IAdminGlobalModalitiesState>,
    action: AdminGlobalModalitiesActions.CreateModality
  ): Observable<IItemResponse> {
    const name = action.payload.name;

    return this.dictionaryService.createModality({ name }, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          this.modalsService.success('Modality was created successfully');
          ctx.dispatch(new AdminGlobalModalitiesActions.RequestReload());
        },
        (error) => this.modalsService.error(error.message)
      )
    );
  }

  @Action(AdminGlobalModalitiesActions.UpdateModality)
  updateModality(
    ctx: StateContext<IAdminGlobalModalitiesState>,
    action: AdminGlobalModalitiesActions.UpdateModality
  ): Observable<IItemResponse> {
    return this.dictionaryService
      .updateModality(
        action.payload.modality.id,
        {
          name: action.payload.modality.name,
        },
        { autoNotifyErrors: false }
      )
      .pipe(
        tap(
          () => {
            ctx.dispatch(new AdminGlobalModalitiesActions.RequestReload());
          },
          (error) => this.modalsService.error(error.message)
        )
      );
  }

  @Action(AdminGlobalModalitiesActions.RequestReload)
  reloadModalities(
    ctx: StateContext<IAdminGlobalModalitiesState>,
    _: AdminGlobalModalitiesActions.RequestReload
  ): void {
    ctx.patchState({ shouldBeReloaded: true });
  }

  @Action(AdminGlobalModalitiesActions.DeleteModality)
  deleteModality(
    ctx: StateContext<IAdminGlobalModalitiesState>,
    action: AdminGlobalModalitiesActions.DeleteModality
  ): Observable<IItemResponse> {
    const id = action.payload.modalityId;

    return this.dictionaryService.deleteModality(id, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          const modalitiesLeft = ctx.getState().modalities.filter((modality) => modality.id !== id);

          ctx.patchState({ modalities: modalitiesLeft });
          this.modalsService.success('Modality deleted');
        },
        (error) => this.modalsService.error(error.message)
      )
    );
  }

  @Action(AdminGlobalModalitiesActions.ClearData)
  clearData(ctx: StateContext<IAdminGlobalModalitiesState>, _: AdminGlobalModalitiesActions.ClearData): void {
    ctx.patchState({
      modalities: [],
      lastChunkSize: 0,
      isLoading: false,
      shouldBeReloaded: false,
    });
    this.unsubscribe$$.next();
  }
}
