import { ISort } from '../../../../../core/models/types/common';
import { ICustomFormDTO, ICustomFormsTableQuery } from '../../../../../core/models/types/custom-fields-and-forms';
import { IFilterMapValue } from '../../../../../core/models/types/filter';

export namespace PlayBookFormsActions {
  export class GetForms {
    static readonly type = '[PlayBook Form] get forms';

    constructor(public payload: { limit: number; offset?: number }) {}
  }

  export class UpdateForm {
    static readonly type = '[PlayBook Form] update form';

    constructor(public payload: { id: number; body: ICustomFormDTO }) {}
  }

  export class UpdateSorting {
    static readonly type = '[PlayBook Form] update sorting for forms';

    constructor(public payload: ISort) {}
  }

  export class UpdateQuery {
    static readonly type = '[PlayBook Form] update query';

    constructor(public payload: ICustomFormsTableQuery) {}
  }

  export class UpdateFilters {
    static readonly type = '[PlayBook Form] update filters';

    constructor(public payload: IFilterMapValue) {}
  }

  export class ReloadForms {
    static readonly type = '[PlayBook Form] reload forms';

    constructor() {}
  }

  export class UpdateScrolledDistance {
    static readonly type = '[PlayBook Form] update scrolled distance';

    constructor(public payload: number) {}
  }

  export class DeleteForm {
    static readonly type = '[PlayBook Form] delete form';

    constructor(public payload: { id: number }) {}
  }

  export class PatchGranularLoadings {
    static readonly type = '[PlayBook Form] patch granular loadings';

    constructor(public payload: Record<string, boolean>) {}
  }

  export class ClearData {
    static readonly type = '[PlayBook Form] clear data';
  }
}
