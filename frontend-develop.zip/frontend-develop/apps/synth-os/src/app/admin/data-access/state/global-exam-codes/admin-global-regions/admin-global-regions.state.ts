import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { AdminGlobalRegionsActions } from './admin-global-regions.actions';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { IRegion } from '../../../../../core/models/types/dictionary';

export interface IAdminGlobalRegionsState {
  regions: IRegion[];
  isLoading: boolean;
  shouldBeReloaded: boolean;
  lastChunkSize: number;
}

@State<IAdminGlobalRegionsState>({
  name: 'adminGlobalRegions',
  defaults: {
    regions: [],
    isLoading: false,
    shouldBeReloaded: false,
    lastChunkSize: 0,
  },
})
@Injectable()
export class AdminGlobalRegionsState {
  @Selector()
  static reload(state: IAdminGlobalRegionsState): boolean {
    return state.shouldBeReloaded;
  }

  @Selector()
  static isLoading(state: IAdminGlobalRegionsState): boolean {
    return state.isLoading;
  }

  @Selector()
  static regions(state: IAdminGlobalRegionsState): { regions: IRegion[]; isLoading: boolean; lastChunkSize: number } {
    return { regions: state.regions, lastChunkSize: state.lastChunkSize, isLoading: state.isLoading };
  }

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private dictionaryService: DictionaryService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(AdminGlobalRegionsActions.GetRegions)
  getRegions(
    ctx: StateContext<IAdminGlobalRegionsState>,
    action: AdminGlobalRegionsActions.GetRegions
  ): Observable<IListResponse> {
    const state = ctx.getState();

    ctx.patchState({ isLoading: true });
    this.unsubscribe$$.next();

    return this.dictionaryService
      .getRegions({
        limit: action.payload.limit,
        offset: action.payload.offset,
        query: action.payload.query,
      })
      .pipe(
        takeUntil(this.unsubscribe$$),
        tap((res) => {
          ctx.patchState({
            regions: action.payload.offset ? state.regions.concat(res.data) : res.data,
            lastChunkSize: res.data.length,
            isLoading: false,
            shouldBeReloaded: false,
          });
        })
      );
  }

  @Action(AdminGlobalRegionsActions.CreateRegion)
  createRegion(
    ctx: StateContext<IAdminGlobalRegionsState>,
    action: AdminGlobalRegionsActions.CreateRegion
  ): Observable<IItemResponse> {
    const region = action.payload.region;

    return this.dictionaryService.createRegion({ region }, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          this.modalsService.success('Region was created successfully');
          ctx.dispatch(new AdminGlobalRegionsActions.RequestReload());
        },
        (error) => this.modalsService.error(error.message)
      )
    );
  }

  @Action(AdminGlobalRegionsActions.UpdateRegion)
  updateRegion(
    ctx: StateContext<IAdminGlobalRegionsState>,
    action: AdminGlobalRegionsActions.UpdateRegion
  ): Observable<IItemResponse> {
    return this.dictionaryService
      .updateRegion(
        action.payload.region.id,
        {
          region: action.payload.region.region,
        },
        { autoNotifyErrors: false }
      )
      .pipe(
        tap(
          () => {
            ctx.dispatch(new AdminGlobalRegionsActions.RequestReload());
          },
          (error) => this.modalsService.error(error.message)
        )
      );
  }

  @Action(AdminGlobalRegionsActions.RequestReload)
  reloadRegions(ctx: StateContext<IAdminGlobalRegionsState>, _: AdminGlobalRegionsActions.RequestReload): void {
    ctx.patchState({ shouldBeReloaded: true });
  }

  @Action(AdminGlobalRegionsActions.DeleteRegion)
  deleteRegion(
    ctx: StateContext<IAdminGlobalRegionsState>,
    action: AdminGlobalRegionsActions.DeleteRegion
  ): Observable<IItemResponse> {
    const id = action.payload.regionId;

    return this.dictionaryService.deleteRegion(action.payload.regionId, undefined, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          const regionsLeft = ctx.getState().regions.filter((modality) => modality.id !== id);

          ctx.patchState({ regions: regionsLeft });
          this.modalsService.success('Region deleted');
        },
        (error) => this.modalsService.error(error.message)
      )
    );
  }

  @Action(AdminGlobalRegionsActions.ClearData)
  clearData(ctx: StateContext<IAdminGlobalRegionsState>, _: AdminGlobalRegionsActions.ClearData): void {
    ctx.patchState({
      regions: [],
      lastChunkSize: 0,
      isLoading: false,
      shouldBeReloaded: false,
    });
    this.unsubscribe$$.next();
  }
}
