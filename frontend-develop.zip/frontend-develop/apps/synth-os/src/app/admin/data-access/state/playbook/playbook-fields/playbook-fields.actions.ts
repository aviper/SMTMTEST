import { ISort } from '../../../../../core/models/types/common';
import { ICustomFieldsTableQuery, ICustomFormField } from '../../../../../core/models/types/custom-fields-and-forms';

export namespace PlayBookFieldsActions {
  export class GetFields {
    static readonly type = '[PlayBook Field] get fields';

    constructor(public payload: { limit: number; offset: number }) {}
  }

  export class UpdateSorting {
    static readonly type = '[PlayBook Field] update sorting';

    constructor(public payload: ISort | null) {}
  }

  export class UpdateField {
    static readonly type = '[PlayBook Field] update field';

    constructor(public payload: ICustomFormField) {}
  }

  export class UpdateQuery {
    static readonly type = '[PlayBook Field] update filters';

    constructor(public payload: ICustomFieldsTableQuery) {}
  }

  export class ReloadFields {
    static readonly type = '[PlayBook Field] reload fields';

    constructor() {}
  }

  export class UpdateScrolledDistance {
    static readonly type = '[PlayBook Field] update scroll distance';

    constructor(public payload: number) {}
  }

  export class DeleteField {
    static readonly type = '[PlayBook Field] delete field';

    constructor(public payload: { id: number }) {}
  }

  export class PatchGranularLoadings {
    static readonly type = '[PlayBook Field] patch granular loadings';

    constructor(public payload: Record<string, boolean>) {}
  }

  export class ClearData {
    static readonly type = '[PlayBook Field] clear data';
  }
}
