import { IRegion } from '../../../../../core/models/types/dictionary';
import { IPaginationPayload } from '../../../../../core/models/types/tables';

export namespace AdminGlobalRegionsActions {
  export class GetRegions {
    static readonly type = '[Regions] get regions';
    constructor(public payload: IPaginationPayload & { query: string }) {}
  }

  export class CreateRegion {
    static readonly type = '[Regions] create region';
    constructor(public payload: { region: string }) {}
  }

  export class UpdateRegion {
    static readonly type = '[Regions] update region';
    constructor(public payload: { regionId: number; region: IRegion }) {}
  }

  export class RequestReload {
    static readonly type = '[Regions] reload regions';
  }

  export class DeleteRegion {
    static readonly type = '[Regions] delete region';
    constructor(public payload: { regionId: number }) {}
  }

  export class ClearData {
    static readonly type = '[Regions] clear state';
  }
}
