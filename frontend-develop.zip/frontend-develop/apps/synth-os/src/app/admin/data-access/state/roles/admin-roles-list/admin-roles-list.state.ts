import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { AdminRolesListActions } from './admin-roles-list.actions';
import { ROLE_TYPES } from '../../../../../core/constants/constants';
import { AdminService } from '../../../../../core/http-services/admin.service';
import { IRole } from '../../../../../core/models/types/acl';
import { IListResponse, ISort } from '../../../../../core/models/types/common';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';

export interface IAdminRolesListState {
  roles: IRole[];
  isLoading: boolean;
  shouldBeReloaded: boolean;
  total: number;
  sort: ISort;
  filters: IFilterMapValue;
}

@State<IAdminRolesListState>({
  name: 'rolesList',
  defaults: {
    roles: [],
    isLoading: false,
    shouldBeReloaded: false,
    total: 0,
    sort: {},
    filters: {},
  },
})
@Injectable()
export class AdminRolesListState {
  @Selector()
  static reload(state: IAdminRolesListState): boolean {
    return state.shouldBeReloaded;
  }

  @Selector()
  static isLoading(state: IAdminRolesListState): boolean {
    return state.isLoading;
  }

  @Selector()
  static roles(state: IAdminRolesListState): { roles: IRole[]; isLoading: boolean; total: number } {
    return { roles: state.roles, total: state.total, isLoading: state.isLoading };
  }

  @Selector()
  static sort(state: IAdminRolesListState): ISort | {} {
    return state.sort;
  }

  constructor(
    private modalsService: ModalsV2Service,
    private adminService: AdminService,
    private store: Store
  ) {}

  @Action(AdminRolesListActions.GetRoles, { cancelUncompleted: true })
  getRoles(ctx: StateContext<IAdminRolesListState>, action: AdminRolesListActions.GetRoles): Observable<IListResponse> {
    const state = ctx.getState();
    const { type, facilityGroupId } = this.getUserData();

    ctx.patchState({ isLoading: true });

    return this.adminService
      .getRoles(
        {
          limit: action.payload.limit,
          offset: action.payload.offset,
          ...(type === ROLE_TYPES.groupLocal && { type: type, facilityGroupId: facilityGroupId }),
          query: action.payload.query,
          ...state.sort,
          ...state.filters,
        },
        { autoNotifyErrors: false }
      )
      .pipe(
        finalize(() => {
          ctx.patchState({
            isLoading: false,
            shouldBeReloaded: false,
          });
        }),
        tap(
          (res) => {
            ctx.patchState({
              roles: action.payload.offset ? state.roles.concat(res.data) : res.data,
              total: res.count,
            });
          },
          (error) => {
            this.modalsService.error(error.message);
          }
        )
      );
  }

  @Action(AdminRolesListActions.SortRoles)
  sortRoles(ctx: StateContext<IAdminRolesListState>, action: AdminRolesListActions.SortRoles): void {
    ctx.patchState({ sort: action.payload });
  }

  @Action(AdminRolesListActions.UpdateFilters)
  updateFilters(ctx: StateContext<IAdminRolesListState>, action: AdminRolesListActions.UpdateFilters): void {
    ctx.patchState({ filters: action.payload });
    ctx.dispatch(new AdminRolesListActions.RequestReload());
  }

  @Action(AdminRolesListActions.RequestReload)
  ReloadRoles(ctx: StateContext<IAdminRolesListState>, _: AdminRolesListActions.RequestReload): void {
    ctx.patchState({ shouldBeReloaded: true });
  }

  @Action(AdminRolesListActions.ClearData)
  clearData(ctx: StateContext<IAdminRolesListState>, _: AdminRolesListActions.ClearData): void {
    ctx.patchState({
      roles: [],
      total: 0,
      isLoading: false,
      shouldBeReloaded: false,
      sort: {},
      filters: {},
    });
  }

  private getUserData(): { type: string; facilityGroupId: number } {
    const currentUser = this.store.selectSnapshot(ProfileState.user);
    const groupId = currentUser.facilityGroups[0]?.id || currentUser.facilities[0]?.groupId;

    return {
      type: currentUser.role.type,
      facilityGroupId: groupId,
    };
  }
}
