import { ISort } from '../../../../core/models/types/common';
import { IFilterMapValue } from '../../../../core/models/types/filter';

export interface IGetUserActionPayload {
  type?: string;
  limit: number;
  offset: number;
  query: string;
}

export namespace AdminUsersActions {
  export class GetUsers {
    static readonly type = '[Users page] get Users';
    constructor(public payload: IGetUserActionPayload) {}
  }

  export class SortUsers {
    static readonly type = '[Users page] apply sorting';
    constructor(public payload: ISort) {}
  }
  export class RequestReload {
    static readonly type = '[Users page] reload users';
  }

  export class UpdateUsersFilters {
    static readonly type = '[Users page] update filters';
    constructor(public payload: IFilterMapValue) {}
  }

  export class UnlockUser {
    static readonly type = '[Users page] unlock user';
    constructor(public payload: { userId: number }) {}
  }

  export class ClearState {
    static readonly type = '[Users page API] clear state';
  }
}
