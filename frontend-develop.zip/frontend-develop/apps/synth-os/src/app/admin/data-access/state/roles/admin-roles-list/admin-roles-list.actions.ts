import { ISort } from '../../../../../core/models/types/common';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { IRequestPayload } from '../../../../../core/models/types/tables';

export namespace AdminRolesListActions {
  export class GetRoles {
    static readonly type = '[Roles] get roles';
    constructor(public payload: IRequestPayload) {}
  }

  export class SortRoles {
    static readonly type = '[Roles] apply sorting';
    constructor(public payload: ISort) {}
  }

  export class UpdateFilters {
    static readonly type = '[Roles] Update roles filters';
    constructor(public payload: IFilterMapValue) {}
  }

  export class RequestReload {
    static readonly type = '[Roles] reload roles';
  }

  export class ClearData {
    static readonly type = '[Roles] clear state';
  }
}
