import { AdminRoleDetailsState } from './admin-role-details/admin-role-details.state';
import { AdminRolesListState } from './admin-roles-list/admin-roles-list.state';

export const ADMIN_ROLES_STATES: any[] = [AdminRoleDetailsState, AdminRolesListState];
