import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { IChangedPresetInfo, IFilterMap, IPresetAdmin } from '../../../../../core/models/types/filter';

export namespace ToolsConfigurePresetsActions {
  export class GetAdminConfigurePresets {
    static readonly type = '[Configure admin presets] get presets';
    constructor(public payload: IFacilityGroup) {}
  }

  export class DeletePreset {
    static readonly type = '[Configure admin presets] delete preset';
    constructor(public payload: number) {}
  }

  export class TogglePresetStatus {
    static readonly type = '[Configure admin presets] toggle preset status';
    constructor(public payload: { preset: IPresetAdmin }) {}
  }

  export class CreatePreset {
    static readonly type = '[Configure admin presets] create preset';
    constructor(public payload: IPresetAdmin) {}
  }

  export class UpdatePreset {
    static readonly type = '[Configure admin presets] update preset';
    constructor(
      public id: number,
      public body: IPresetAdmin
    ) {}
  }

  export class GetFacilityGroupRolesForPreset {
    static readonly type = '[Configure admin presets] get facility Group Role For Preset';
    constructor(public payload: number) {}
  }

  export class SearchPresets {
    static readonly type = '[Configure admin presets] search presets';
    constructor(public payload: string) {}
  }

  export class UpdateFilters {
    static readonly type = '[Configure admin presets] update filters';
    constructor(public payload: IFilterMap) {}
  }

  export class PaginateAdminPresets {
    static readonly type = '[Configure admin presets] pagination for Preset';
    constructor(public offset: number) {}
  }

  export class AdminPresetWasChanged {
    static readonly type = '[Configure admin presets] Preset was changed';
    constructor(public payload: IChangedPresetInfo) {}
  }

  export class ClearData {
    static readonly type = '[Configure admin presets] clear data';
  }
}
