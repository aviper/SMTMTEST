import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

import { ApiListResponse } from '@synth/api';
import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { PlayBookFieldsActions } from './playbook-fields.actions';
import { PlayBookService } from '../../../../../core/http-services/playbook.service';
import { IHumanErrorBody, IItemResponse, ISort } from '../../../../../core/models/types/common';
import { ICustomFieldsTableQuery, ICustomFormField } from '../../../../../core/models/types/custom-fields-and-forms';

export interface IPlayBookFieldsState {
  fields: ICustomFormField[];
  isLoading: boolean;
  sort: ISort;
  pagination: IPagination;
  scrolledDistance: number;
  query: ICustomFieldsTableQuery;
  granularLoadings: Record<string, boolean>;
}

export const PLAYBOOK_FIELDS_DEFAULT_SORT: ISort = {
  sortField: 'label',
  direction: 'asc',
};

@State<IPlayBookFieldsState>({
  name: 'playbookFields',
  defaults: {
    fields: [],
    query: {},
    isLoading: false,
    sort: { ...PLAYBOOK_FIELDS_DEFAULT_SORT },
    pagination: { ...PAGINATION },
    scrolledDistance: 0,
    granularLoadings: {},
  },
})
@Injectable()
export class PlayBookFieldsState {
  @Selector()
  static fields(state: IPlayBookFieldsState): ICustomFormField[] {
    return state.fields;
  }

  @Selector()
  static isLoading(state: IPlayBookFieldsState): boolean {
    return state.isLoading;
  }

  @Selector()
  static sort(state: IPlayBookFieldsState): ISort {
    return state.sort;
  }

  @Selector()
  static query(state: IPlayBookFieldsState): ICustomFieldsTableQuery {
    return state.query;
  }

  @Selector()
  static pagination(state: IPlayBookFieldsState): IPagination {
    return state.pagination;
  }

  @Selector()
  static scrolledDistance(state: IPlayBookFieldsState): number {
    return state.scrolledDistance;
  }

  @Selector()
  static granularLoadings(state: IPlayBookFieldsState): Record<string, boolean> {
    return state.granularLoadings;
  }

  constructor(
    private playbookService: PlayBookService,
    private modalsService: ModalsV2Service
  ) {}

  @Action(PlayBookFieldsActions.GetFields)
  getFields(
    ctx: StateContext<IPlayBookFieldsState>,
    { payload: { limit, offset } }: PlayBookFieldsActions.GetFields
  ): Observable<IItemResponse> {
    ctx.patchState({
      isLoading: true,
    });

    const state = ctx.getState();

    return this.playbookService
      .getFormFields({
        limit: limit,
        offset: offset ?? 0,
        ...state.sort,
        ...state.query,
      })
      .pipe(
        finalize(() => ctx.patchState({ isLoading: false })),
        tap({
          next: ({ data, count }: ApiListResponse<ICustomFormField>) => {
            const pagination = offset
              ? {
                  ...state.pagination,
                  lastChunkSize: data.length,
                  offset: offset,
                  page: state.pagination.page + 1,
                  total: count,
                }
              : {
                  ...PAGINATION,
                  lastChunkSize: data.length,
                  total: count,
                };

            ctx.patchState({
              pagination,
              fields: offset ? state.fields.concat(data) : data,
            });
          },
          error: (error: IHumanErrorBody) => {
            this.modalsService.error(error.message);
            ctx.patchState({
              fields: [],
              pagination: { ...PAGINATION },
            });
          },
        })
      );
  }

  @Action(PlayBookFieldsActions.UpdateField)
  updateCustomField(
    ctx: StateContext<IPlayBookFieldsState>,
    { payload }: PlayBookFieldsActions.UpdateField
  ): Observable<IItemResponse> {
    delete payload.facilityGroupId;
    delete payload.facilityId;

    const { id, ...updatePayload } = payload;

    delete updatePayload['cptCodeId'];

    ctx.dispatch(new PlayBookFieldsActions.PatchGranularLoadings({ [id]: true }));

    return this.playbookService.editPlayBookField(id, updatePayload).pipe(
      finalize(() => ctx.dispatch(new PlayBookFieldsActions.PatchGranularLoadings({ [id]: false }))),
      tap({
        next: ({ data }) => {
          const fields = [...ctx.getState().fields];
          const index = fields.findIndex((f) => f.id === data.id);

          if (index !== -1) {
            fields[index] = {
              ...fields[index],
              ...data,
            };
          }
          ctx.patchState({
            fields,
          });
          this.modalsService.success('Field was successfully edited');
        },
        error: (error: IHumanErrorBody) => {
          this.modalsService.error(error.message);
        },
      })
    );
  }

  @Action(PlayBookFieldsActions.DeleteField)
  deleteField(
    ctx: StateContext<IPlayBookFieldsState>,
    action: PlayBookFieldsActions.DeleteField
  ): Observable<IItemResponse> {
    const state = ctx.getState();

    return this.playbookService.deletePlayBookField(action.payload.id).pipe(
      tap({
        next: () => {
          ctx.patchState({
            fields: state.fields.filter((f) => f.id !== action.payload.id),
          });
          this.modalsService.success('Field was successfully deleted');
        },
        error: (error) => {
          this.modalsService.error(error.message);
        },
      })
    );
  }

  @Action(PlayBookFieldsActions.UpdateSorting)
  updateSorting(ctx: StateContext<IPlayBookFieldsState>, action: PlayBookFieldsActions.UpdateSorting): void {
    ctx.patchState({
      sort: action.payload,
    });

    ctx.dispatch(new PlayBookFieldsActions.ReloadFields());
  }

  @Action(PlayBookFieldsActions.UpdateQuery)
  updateFilters(ctx: StateContext<IPlayBookFieldsState>, { payload }: PlayBookFieldsActions.UpdateQuery): void {
    ctx.patchState({
      query: payload,
    });

    ctx.dispatch(new PlayBookFieldsActions.ReloadFields());
  }

  @Action(PlayBookFieldsActions.UpdateScrolledDistance)
  updateScrollDistance(
    ctx: StateContext<IPlayBookFieldsState>,
    action: PlayBookFieldsActions.UpdateScrolledDistance
  ): void {
    ctx.patchState({
      scrolledDistance: action.payload,
    });
  }

  @Action(PlayBookFieldsActions.PatchGranularLoadings)
  patchGranularLoadings(
    ctx: StateContext<IPlayBookFieldsState>,
    action: PlayBookFieldsActions.PatchGranularLoadings
  ): void {
    const state = ctx.getState();

    ctx.patchState({
      granularLoadings: {
        ...state.granularLoadings,
        ...action.payload,
      },
    });
  }

  @Action(PlayBookFieldsActions.ClearData)
  clearData(ctx: StateContext<IPlayBookFieldsState>, _action: PlayBookFieldsActions.ClearData): void {
    ctx.setState({
      fields: [],
      query: {},
      isLoading: false,
      sort: { ...PLAYBOOK_FIELDS_DEFAULT_SORT },
      pagination: { ...PAGINATION },
      scrolledDistance: 0,
      granularLoadings: {},
    });
  }
}
