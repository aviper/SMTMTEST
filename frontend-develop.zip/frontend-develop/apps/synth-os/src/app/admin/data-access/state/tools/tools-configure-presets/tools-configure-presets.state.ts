import { Injectable } from '@angular/core';
import { Action, Selector, State, StateContext, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { ToolsConfigurePresetsActions } from './tools-configure-presets.actions';
import { AdminPresetService } from '../../../../../core/http-services/admin-preset.service';
import { IRole } from '../../../../../core/models/types/acl';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { IChangedPresetInfo, IFilterMap, IPresetAdmin } from '../../../../../core/models/types/filter';
import { CachingService } from '../../../../../core/services/caching.service';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';

export interface IToolsConfigurePresetsState {
  presets: IPresetAdmin[];
  isLoading: boolean;
  pagination: IPagination;
  facilityGroup: IFacilityGroup;
  facilityGroupRoles: IRole[];
  changedPresetInfo: IChangedPresetInfo;
  query: string;
  filters: IFilterMap;
}

@State<IToolsConfigurePresetsState>({
  name: 'toolsConfigurePresets',
  defaults: {
    presets: [],
    isLoading: false,
    facilityGroup: null,
    facilityGroupRoles: [],
    query: '',
    filters: null,
    pagination: { ...PAGINATION },
    changedPresetInfo: null,
  },
})
@Injectable()
export class ToolsConfigurePresetsState {
  @Selector()
  static presets(state: IToolsConfigurePresetsState): IPresetAdmin[] {
    return state.presets;
  }

  @Selector()
  static isLoading(state: IToolsConfigurePresetsState): boolean {
    return state.isLoading;
  }

  @Selector()
  static activeFacilityGroup(state: IToolsConfigurePresetsState): IFacilityGroup {
    return state.facilityGroup;
  }

  @Selector()
  static facilityGroupRoles(state: IToolsConfigurePresetsState): IRole[] {
    return state.facilityGroupRoles;
  }

  @Selector()
  static pagination(state: IToolsConfigurePresetsState): IPagination {
    return state.pagination;
  }

  @Selector()
  static searchQuery(state: IToolsConfigurePresetsState): string {
    return state.query;
  }

  @Selector()
  static changedAdminPresetInfo(state: IToolsConfigurePresetsState): IChangedPresetInfo {
    return state.changedPresetInfo;
  }

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private adminPresetService: AdminPresetService,
    private cachingService: CachingService,
    private modalService: ModalsV2Service,
    private store: Store
  ) {}

  @Action(ToolsConfigurePresetsActions.GetAdminConfigurePresets)
  getPresets(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.GetAdminConfigurePresets
  ): Observable<IListResponse> {
    if (!action.payload?.id) {
      return null;
    }

    this.unsubscribe$$.next();
    const state = ctx.getState();

    ctx.patchState({
      presets: [],
      isLoading: true,
      facilityGroup: action.payload,
    });

    return this.adminPresetService
      .getPresetsByFacilityGroupId(action.payload.id, {
        limit: this.store.selectSnapshot(SettingsState.limit),
        offset: state.pagination.offset,
        search: state.query,
        ...state.filters,
      })
      .pipe(
        takeUntil(this.unsubscribe$$),
        tap((res) => {
          ctx.patchState({
            presets: state.pagination.offset ? state.presets.concat(res.data) : res.data,
            isLoading: false,
            pagination: {
              ...state.pagination,
              lastChunkSize: res.data.length,
            },
          });
        })
      );
  }

  @Action(ToolsConfigurePresetsActions.DeletePreset)
  deletePreset(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.DeletePreset
  ): Observable<IListResponse> {
    const presets = ctx.getState().presets;

    return this.adminPresetService.deleteAdminPreset(action.payload, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          this.modalService.success('Preset was deleted successfully');
          ctx.patchState({
            presets: presets.filter((preset) => preset.id !== action.payload),
          });
        },
        (error) => this.modalService.error(error.message)
      )
    );
  }

  @Action(ToolsConfigurePresetsActions.CreatePreset)
  createPreset(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.CreatePreset
  ): Observable<IListResponse> {
    return this.adminPresetService.createAdminPreset(action.payload, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          this.modalService.success('Preset was created successfully');
          this.store.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(ctx.getState().facilityGroup));
        },
        (error) => this.modalService.error(error.message)
      )
    );
  }

  @Action(ToolsConfigurePresetsActions.UpdatePreset)
  updatePreset(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.UpdatePreset
  ): Observable<IListResponse> {
    return this.adminPresetService.updateAdminPreset(action.id, action.body, { autoNotifyErrors: false }).pipe(
      tap(
        () => {
          this.modalService.success('Preset was updated successfully');
          this.store.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(ctx.getState().facilityGroup));
        },
        (error) => this.modalService.error(error.message)
      )
    );
  }

  @Action(ToolsConfigurePresetsActions.GetFacilityGroupRolesForPreset)
  getFacilityGroupRolesForPreset(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.GetFacilityGroupRolesForPreset
  ): Observable<IListResponse> {
    return this.adminPresetService.getFacilityGroupRolesForPreset(action.payload, { autoNotifyErrors: false }).pipe(
      tap(
        (res) => {
          ctx.patchState({
            facilityGroupRoles: res.data,
          });
        },
        (error) => this.modalService.error(error.message)
      )
    );
  }

  @Action(ToolsConfigurePresetsActions.TogglePresetStatus)
  togglePresetStatus(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.TogglePresetStatus
  ): Observable<IItemResponse> {
    const presetId = action.payload.preset.id;

    return this.adminPresetService.togglePresetStatus(presetId).pipe(
      tap((res) => {
        const presets = ctx.getState().presets.map((preset) => {
          if (preset.id === presetId) {
            return { ...preset, status: res.data.status };
          }

          return preset;
        });

        ctx.patchState({
          presets,
        });
        this.modalService.success('Preset status was successfully changed');
      })
    );
  }

  @Action(ToolsConfigurePresetsActions.PaginateAdminPresets)
  paginatePresets(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.PaginateAdminPresets
  ): void {
    ctx.patchState({
      pagination: {
        ...ctx.getState().pagination,
        offset: action.offset,
      },
    });
    this.store.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(ctx.getState().facilityGroup));
  }

  @Action(ToolsConfigurePresetsActions.SearchPresets)
  searchPresets(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.SearchPresets
  ): void {
    this.resetPagination(ctx, { query: action.payload });
    ctx.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(ctx.getState().facilityGroup));
  }

  @Action(ToolsConfigurePresetsActions.UpdateFilters)
  updateFilters(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.UpdateFilters
  ): void {
    this.resetPagination(ctx, { filters: action.payload });
    ctx.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(ctx.getState().facilityGroup));
  }

  @Action(ToolsConfigurePresetsActions.AdminPresetWasChanged)
  adminPresetWasChanged(
    ctx: StateContext<IToolsConfigurePresetsState>,
    action: ToolsConfigurePresetsActions.AdminPresetWasChanged
  ): void {
    ctx.patchState({ changedPresetInfo: action.payload });
  }

  @Action(ToolsConfigurePresetsActions.ClearData)
  clearData(ctx: StateContext<IToolsConfigurePresetsState>, action: ToolsConfigurePresetsActions.ClearData): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    ctx.patchState({
      presets: [],
      isLoading: false,
      facilityGroup: null,
      facilityGroupRoles: [],
      changedPresetInfo: null,
    });
  }

  private resetPagination(ctx: StateContext<IToolsConfigurePresetsState>, payload?: Record<string, any>): void {
    ctx.patchState({
      pagination: { ...PAGINATION },
      presets: [],
      ...payload,
    });
  }
}
