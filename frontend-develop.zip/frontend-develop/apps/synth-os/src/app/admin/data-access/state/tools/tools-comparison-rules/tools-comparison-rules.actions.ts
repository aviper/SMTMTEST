import { IFacilityWithDefaultPriorRelevancyRule } from '@synth/api';

import { IFacilityGroup } from '../../../../../core/models/types/facility';
import {
  ComparisonRule,
  ComparisonRuleGroup,
} from '../../../../feature/admin-tools/tools-comparison-rules/utils/model';

export namespace ComparisonRulesActions {
  export class SetFacilityGroup {
    static readonly type = '[Comparison Rules] select facility group';
    constructor(public payload: IFacilityGroup) {}
  }

  export class SetFacility {
    static readonly type = '[Comparison Rules] select facility';
    constructor(public payload: IFacilityWithDefaultPriorRelevancyRule) {}
  }

  export class GetRules {
    static readonly type = '[Comparison Rules] get rules';
  }

  export class UpdateRule {
    static readonly type = '[Comparison Rules] update rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        index: number;
        payload: ComparisonRule;
      }
    ) {}
  }

  export class CreateRule {
    static readonly type = '[Comparison Rules] create rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        creationData: ComparisonRule;
      }
    ) {}
  }

  export class DeleteRule {
    static readonly type = '[Comparison Rules] delete rule';
    constructor(
      public payload: {
        item: ComparisonRuleGroup;
        index: number;
      }
    ) {}
  }

  export class GetModalities {
    static readonly type = '[Comparison Rules] get modalities';
  }

  export class ClearState {
    static readonly type = '[Comparison Rules] clear state';
    constructor() {}
  }
}
