import { IRolePermission, PermissionAction } from '../../../../../core/models/types/acl';

export interface UpdateRolePermissionPayload {
  entity: IRolePermission;
  actionToUpdate: PermissionAction;
  newActionState: boolean;
}

export namespace AdminRoleDetailsActions {
  export class GetRoleDetails {
    static readonly type = '[Role Details] get details';
    constructor(public payload: number) {}
  }

  export class UpdateRolePermission {
    static readonly type = '[Role Details] update permission';
    constructor(public payload: UpdateRolePermissionPayload) {}
  }

  export class SearchRolePermissons {
    static readonly type = '[Role Details] search permissions';
    constructor(public payload: { query: string; roleId: number }) {}
  }

  export class ClearData {
    static readonly type = '[Role Details] clear state';
  }
}
