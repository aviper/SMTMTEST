import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiItemResponse } from '@synth/api';

import { HttpService } from '../../core/helpers/http.service';
import { EnvironmentLoaderService } from '../../core/services/environment-loader.service';

@Injectable({
  providedIn: 'root',
})
export class ClearCacheService extends HttpService {
  constructor(
    private els: EnvironmentLoaderService,
    private http: HttpClient
  ) {
    super();
  }

  clearCache(): Observable<ApiItemResponse<{ success: boolean }>> {
    return this.http.post<ApiItemResponse<{ success: boolean }>>(
      `${this.els.getEnvironment().apiV2URL}/admin/clearCache`,
      {}
    );
  }
}
