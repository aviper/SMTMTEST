import { ISort } from '../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../core/models/types/dictionary';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { IPaginationPayload } from '../../../../../core/models/types/tables';

export namespace AdminGlobalExamCodesListActions {
  export class GetCptCodes {
    static readonly type = '[CPT Codes] get cpt codes';
    constructor(public payload: IPaginationPayload) {}
  }

  export class UpdateCptModality {
    static readonly type = '[CPT Codes] update cpt code modality';
    constructor(public payload: { modalityId: number; cptCode: ICTPCode }) {}
  }

  export class SortCptCodes {
    static readonly type = '[CPT Codes] apply sorting';
    constructor(public payload: ISort) {}
  }

  export class SearchCptCodes {
    static readonly type = '[CPT Codes] search codes';
    constructor(public payload: string) {}
  }

  export class RequestReload {
    static readonly type = '[CPT Codes] reload codes';
  }

  export class DeleteCptDefaultFindings {
    static readonly type = '[CPT Codes] delete cpt default findings';
    constructor(public payload: ICTPCode) {}
  }

  export class UpdateCptFilters {
    static readonly type = '[CPT Codes] update filters';
    constructor(public payload: IFilterMapValue) {}
  }

  export class UpdateShowExpiredExamCodeStatus {
    static readonly type = '[CPT Codes] update show expired code state';
    constructor(public payload: boolean) {}
  }

  export class ClearData {
    static readonly type = '[CPT Codes] clear state';
  }
}
