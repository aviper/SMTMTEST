import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';

import { ICONS } from '../../../../../../../core/constants/icon-list';
import { IBannerTheme } from '../../../../../../../core/models/types/admin';

@Component({
  selector: 'app-banner-theme-dropdown',
  templateUrl: './banner-theme-dropdown.component.html',
  styleUrls: ['./banner-theme-dropdown.component.scss'],
  standalone: false,
})
export class BannerThemeDropdownComponent implements OnChanges {
  readonly DROPDOWN_ICON = ICONS.dropdownTriangleSmall;
  @Input() bannerTheme: string;
  @Input() themes: IBannerTheme[];
  @Output() selected: EventEmitter<IBannerTheme> = new EventEmitter<IBannerTheme>();

  isActive = false;
  selectedTheme: IBannerTheme;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.bannerTheme) {
      this.selectedTheme =
        this.themes.find((condition) => condition.value === changes.bannerTheme.currentValue) || this.themes[0];
    }
  }

  selectTheme(theme: IBannerTheme): void {
    this.selected.emit(theme);
  }

  toggle(): void {
    this.isActive = !this.isActive;
  }
}
