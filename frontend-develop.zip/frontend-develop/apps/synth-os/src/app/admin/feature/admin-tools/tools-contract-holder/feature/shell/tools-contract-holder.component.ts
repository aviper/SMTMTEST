import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { ContractHoldersService } from '../../../../../../core/http-services/contract-holders.service';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { ISort } from '../../../../../../core/models/types/common';
import { IContractHolder, IGroupContractHolder } from '../../../../../../core/models/types/facility';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { CreateContractHolderModalComponent } from '../../ui/create-contract-holder/create-contract-holder-modal.component';

@Component({
  selector: 'app-tools-contract-holder',
  templateUrl: './tools-contract-holder.component.html',
  styleUrls: ['./tools-contract-holder.component.scss', '../../../styles/tool-common-styles.scss'],
  standalone: false,
})
export class ToolsContractHolderComponent implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly LIMIT = DEFAULT_LIMIT;

  contractHolders: IGroupContractHolder[] = [];
  isLoading = false;
  permissions = new UserPermissions();
  pagination = { ...PAGINATION };
  sort: ISort = { sortField: 'facilityGroupId', direction: 'asc' };

  private contractHoldersGroupMap: { [key: number]: IGroupContractHolder } = {};
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private modalsService: ModalsV2Service,
    private contractHoldersService: ContractHoldersService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.permissions = permissions;
      });

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions && !!permissions.userId),
        takeUntil(this.unsubscribe$$),
        take(1)
      )
      .subscribe((permissions: UserPermissions) => {
        const currentEndpoint = this.route.snapshot.data?.tab;

        if (!permissions.canRead(currentEndpoint)) {
          this.router.navigateByUrl('adminPanel/users');

          return;
        }
      });

    this.getHolders();
  }

  onSort(sort: ISort): void {
    this.sort = sort.direction
      ? { sortField: sort.sortField, direction: sort.direction }
      : { sortField: 'facilityGroupId', direction: 'asc' };
    this.resetDataTable();
    this.getHolders();
  }

  createContractHolder(): void {
    this.modalsService
      .open(CreateContractHolderModalComponent, {
        listenBackdrop: false,
      })
      .pipe(takeUntil(this.unsubscribe$$), filter(Boolean))
      .subscribe(() => this.reloadData());
  }

  reloadData(): void {
    this.resetDataTable();
    this.getHolders();
  }

  getHolders(): void {
    this.isLoading = true;
    this.contractHoldersService
      .getHolders({
        limit: this.LIMIT,
        offset: this.pagination.offset,
        ...this.sort,
      })
      .subscribe((res) => {
        this.contractHolders = this.groupedHoldersByFacilityGroupId(res.data);
        this.pagination.total = res.count;
        this.isLoading = false;
      });
  }

  sortDataTable(sort: Sort): void {
    this.sort = sort.direction
      ? { sortField: sort.active, direction: sort.direction }
      : { sortField: 'facilityGroupId', direction: 'asc' };
    this.resetDataTable();
    this.getHolders();
  }

  resetDataTable(): void {
    this.pagination = { ...PAGINATION };
    this.contractHolders = [];
    this.contractHoldersGroupMap = {};
  }

  onScroll(offset: number): void {
    this.pagination.offset = offset;
    this.getHolders();
  }

  private groupedHoldersByFacilityGroupId(holders: IContractHolder[]): IGroupContractHolder[] {
    let order = 1;

    holders.forEach((item) => {
      if (!item.facilityGroupId) {
        return;
      }

      if (!this.contractHoldersGroupMap[item.facilityGroupId]) {
        this.contractHoldersGroupMap[item.facilityGroupId] = {
          order,
          group: item.facilityGroup,
          contractHolders: [],
        };
        order++;
      }
      this.contractHoldersGroupMap[item.facilityGroupId].contractHolders.push(item);
    });

    return Object.values(this.contractHoldersGroupMap).sort((item, next) => item.order - next.order);
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
