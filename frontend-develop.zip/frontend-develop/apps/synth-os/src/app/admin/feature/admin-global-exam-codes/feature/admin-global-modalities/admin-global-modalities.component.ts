import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, skip, Subject, takeUntil } from 'rxjs';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { GLOBAL_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IModality } from '../../../../../core/models/types/dictionary';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { RegionModalityModalsComponent } from '../../../../../shared/ui/modules/cpt-codes/region-modality-modals/region-modality-modals.component';
import { AdminGlobalModalitiesActions } from '../../../../data-access/state/global-exam-codes/admin-global-modalities/admin-global-modalities.actions';
import { AdminGlobalModalitiesState } from '../../../../data-access/state/global-exam-codes/admin-global-modalities/admin-global-modalities.state';

@Component({
  selector: 'app-admin-global-modalities',
  templateUrl: './admin-global-modalities.component.html',
  styleUrls: ['./admin-global-modalities.component.scss'],
  standalone: false,
})
export class AdminGlobalModalitiesComponent implements OnInit, OnDestroy {
  readonly reload$: Observable<boolean> = this.store.select(AdminGlobalModalitiesState.reload);
  readonly isLoading$: Observable<boolean> = this.store.select(AdminGlobalModalitiesState.isLoading);
  readonly modalities$: Observable<{ modalities: IModality[]; lastChunkSize: number; isLoading: boolean }> =
    this.store.select(AdminGlobalModalitiesState.modalities);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  limit = DEFAULT_LIMIT;
  searchQuery = '';
  data: IModality[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = true;
  canEditModality: boolean;
  canDeleteModality: boolean;
  canCreateModality: boolean;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(
      new AdminGlobalModalitiesActions.GetModalities({
        limit: this.limit,
        offset: 0,
        query: this.searchQuery,
      })
    );

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.canCreateModality = permissions.canCreate(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
        this.canEditModality = permissions.canEdit(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
        this.canDeleteModality = permissions.canDelete(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
      });

    this.modalities$
      .pipe(
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.modalities;
        this.pagination.lastChunkSize = data.lastChunkSize;
        this.isLoading = data.isLoading;
      });

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.pagination = { ...PAGINATION };

        this.store.dispatch(
          new AdminGlobalModalitiesActions.GetModalities({
            limit: this.limit,
            offset: 0,
            query: this.searchQuery,
          })
        );
      });

    this.isLoading$
      .pipe(skip(1), takeUntil(this.unsubscribe$$))
      .subscribe((isLoading: boolean) => (this.isLoading = isLoading));
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    ++this.pagination.page;

    this.store.dispatch(
      new AdminGlobalModalitiesActions.GetModalities({
        limit: this.limit,
        offset,
        query: this.searchQuery,
      })
    );
  }

  editModality(modality: IModality): void {
    this.modalsService.open(RegionModalityModalsComponent, {
      data: {
        action: 'edit',
        type: 'modality',
        entity: modality,
      },
    });
  }

  deleteModality(modality: IModality): void {
    this.store.dispatch(new AdminGlobalModalitiesActions.DeleteModality({ modalityId: modality.id }));
  }

  onSearch(text: string): void {
    this.searchQuery = text;
    this.reload();
  }

  reload(): void {
    this.store.dispatch(new AdminGlobalModalitiesActions.RequestReload());
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
