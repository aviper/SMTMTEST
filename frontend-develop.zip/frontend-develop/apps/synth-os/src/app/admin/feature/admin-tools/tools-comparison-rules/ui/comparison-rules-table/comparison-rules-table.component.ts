import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ComparisonRule, ComparisonRuleGroup } from '../../utils/model';

@Component({
  selector: 'synth-comparison-rules-table',
  templateUrl: './comparison-rules-table.component.html',
  styleUrls: ['./comparison-rules-table.component.scss'],
  standalone: false,
})
export class ComparisonRulesTableComponent {
  @Input() rules: ComparisonRuleGroup[] = [];
  @Input() isLoading = false;
  @Input() canCreate = false;
  @Input() canEdit = false;
  @Input() canDelete = false;
  @Input() debounceValue = 1500;

  @Output() createRule: EventEmitter<{
    item: ComparisonRuleGroup;
    creationData: ComparisonRule;
  }> = new EventEmitter();
  @Output() editRule: EventEmitter<{ item: ComparisonRuleGroup; index: number; payload: ComparisonRule }> =
    new EventEmitter();
  @Output() deleteRule: EventEmitter<{ item: ComparisonRuleGroup; index: number }> = new EventEmitter();

  onCreateRule(item: ComparisonRuleGroup, creationData: ComparisonRule): void {
    this.createRule.emit({ item, creationData });
  }

  onEditRule(item: ComparisonRuleGroup, data: { index: number; payload: ComparisonRule }): void {
    this.editRule.emit({ item, ...data });
  }

  onDeleteRule(item: ComparisonRuleGroup, index: number): void {
    this.deleteRule.emit({ item, index });
  }
}
