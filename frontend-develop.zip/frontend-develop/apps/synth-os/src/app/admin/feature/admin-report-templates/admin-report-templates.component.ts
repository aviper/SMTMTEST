import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../core/constants/constants';
import { AdminService } from '../../../core/http-services/admin.service';
import { UserPermissions } from '../../../core/models/classes/userPermissions';
import { IHumanErrorBody } from '../../../core/models/types/common';
import { IDefaultFinding } from '../../../core/models/types/dictionary';
import { TemplateActions } from '../../../core/store/accounts/actions/facility-group/facility-group-tabs/template.action';
import { TemplateState } from '../../../core/store/accounts/states/facility-group/facility-group-tabs/template.state';
import { ProfileState } from '../../../profile/data-access/state/profile/profile.state';
import { CptTemplatePopupComponent } from '../../../shared/ui/components/cpt-template-popup/cpt-template-popup.component';

@Component({
  selector: 'app-admin-report-templates',
  templateUrl: './admin-report-templates.component.html',
  styleUrls: ['./admin-report-templates.component.scss'],
  standalone: false,
})
export class AdminReportTemplatesComponent implements OnInit, OnDestroy {
  readonly templates$: Observable<IDefaultFinding[]> = this.store.select(TemplateState.templates);
  readonly isLoading$: Observable<boolean> = this.store.select(TemplateState.isLoading);
  readonly pagination$: Observable<IPagination> = this.store.select(TemplateState.pagination);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  data: IDefaultFinding[] = [];
  pagination: IPagination = { ...PAGINATION };

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private adminService: AdminService,
    private modalsService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.loadReportTemplates();

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));
  }

  private loadReportTemplates(): void {
    this.store.dispatch(new TemplateActions.SetLimit({ limit: DEFAULT_LIMIT }));
    this.store.dispatch(new TemplateActions.GetAdminTemplates());
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(
      new TemplateActions.UpdateAdminTemplatePagination({
        offset: offset,
        page: this.pagination.page + 1,
      })
    );
  }

  updateTemplate(template: IDefaultFinding): void {
    this.modalsService
      .open(CptTemplatePopupComponent, {
        data: {
          nameBtn: 'Cancel',
          title: 'Edit template',
          defaultFinding: template,
          groupId: null,
          cptCodes: template.cptCodes,
          level: 'global',
        },
      })
      .pipe(
        filter((response) => Boolean(response)),
        switchMap((response) =>
          this.store.dispatch(
            new TemplateActions.UpdateAdminTemplate({
              findingId: template.id,
              finding: {
                reportFields: response.reportFields,
                name: response.templateName,
                cptCodeIds: response.examCodes,
                defaultFindings: response.template,
                gridLines: response.hideTableGridLines,
              },
            })
          )
        )
      )
      .subscribe({
        error: (error: IHumanErrorBody) => this.modalsService.error(error.message),
      });
  }

  deleteTemplate(template: IDefaultFinding): void {
    this.adminService.deleteAdminTemplateById(template.id).subscribe(() => {
      this.loadReportTemplates();
      this.modalsService.success(
        'Template for ' +
          (template.cptCodes ?? []).map(({ codeWithModifier }) => codeWithModifier).join(', ') +
          ' has been removed'
      );
    });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new TemplateActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
