import { Component, EventEmitter, Input, Output } from '@angular/core';

import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { IBanner } from '../../../../../../core/models/types/admin';
import { ISort } from '../../../../../../core/models/types/common';

@Component({
  selector: 'app-banners-table',
  templateUrl: './banners-table.component.html',
  styleUrls: ['./banners-table.component.scss'],
  standalone: false,
})
export class BannersTableComponent {
  readonly PaginationStrategiesNames = PaginationStrategiesNames;

  @Input() banners: IBanner[] = [];
  @Input() isLoading = false;
  @Input() sort: ISort | {} = {};
  @Input() pagination: IPagination;
  @Input() limit = DEFAULT_LIMIT;
  @Input() currentTab: string;
  @Input() canEditBanner: boolean;

  @Output() sortChanged: EventEmitter<ISort | {}> = new EventEmitter<ISort | {}>();
  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() reload: EventEmitter<void> = new EventEmitter<void>();

  applySort(sort: ISort): void {
    this.sort = sort.direction ? sort : {};
    this.sortChanged.emit(this.sort);
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }

  reloadRequested(): void {
    this.reload.emit();
  }
}
