import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ICONS } from '@synth/utils';

import { ComparisonRule, ComparisonRuleGroup } from '../../../utils/model';

@Component({
  selector: 'synth-comparison-rules-table-row',
  templateUrl: './comparison-rules-table-row.component.html',
  styleUrls: ['./comparison-rules-table-row.component.scss'],
  standalone: false,
})
export class ComparisonRulesTableRowComponent {
  @Input() data: ComparisonRuleGroup;
  @Input() canEdit = false;
  @Input() canDelete = false;
  @Input() canCreate = false;
  @Input() debounceValue = 1500;
  @Output() createRule: EventEmitter<ComparisonRule> = new EventEmitter();
  @Output() editRule: EventEmitter<{ index: number; payload: ComparisonRule }> = new EventEmitter<{
    index: number;
    payload: ComparisonRule;
  }>();
  @Output() deleteRule: EventEmitter<number> = new EventEmitter<number>();

  readonly ICONS = ICONS;

  creationRow = false;

  createNewRuleRow(): void {
    this.creationRow = true;
  }

  onCreateRule(data: ComparisonRule): void {
    this.creationRow = false;
    this.createRule.emit(data);
  }

  onEdit(payload: ComparisonRule, index: number): void {
    this.editRule.emit({ payload, index });
  }

  onDelete(index: number): void {
    this.deleteRule.emit(index);
  }

  onCancelCreation(): void {
    this.creationRow = false;
  }
}
