import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { MODAL_ACTION_COMPLETE, ModalClass, ModalOverlayRef, modalAnimation } from '@synth/ui/modals';

import { ICONS } from '../../../../../../core/constants/icon-list';
import { OrdersService } from '../../../../../../core/http-services/orders.service';
import { IPreset } from '../../../../../../core/models/types/filter';
import { FiltersV2Service } from '../../../../../../shared/ui/modules/filters/services/filters-v2.service';

interface IFilterService {
  service: FiltersV2Service;
  isCollapsed: boolean;
  data: any;
  showOnlySelectedFilters?: boolean;
  counter: number;
}

@Component({
  selector: 'app-configure-preset-preview-modal',
  templateUrl: './configure-preset-preview-modal.component.html',
  styleUrls: ['./configure-preset-preview-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class ConfigurePresetPreviewModalComponent extends ModalClass implements OnInit {
  readonly ICONS = ICONS;

  preset: IPreset = null;
  filterServices: IFilterService[] = [];

  constructor(
    public overlayRef: ModalOverlayRef,
    protected _cdRef: ChangeDetectorRef,
    private ordersService: OrdersService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(_cdRef, overlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.preset = this.overlayRef.data.preset || null;
    this.ordersService.getUsersFiltersPresetInfoById(this.preset?.id).subscribe((res) => {
      this.filterServices = res.data.filterGroups.map((filter) => ({
        service: null,
        isCollapsed: false,
        data: filter,
        showOnlySelectedFilters: true,
      }));
    });
  }

  closeModal(): void {
    this.overlayRef.close();
  }

  collapseAction(action: { filter: { service: FiltersV2Service; isCollapsed: boolean }; status: boolean }): void {
    action.filter.isCollapsed = action.status;
  }
}
