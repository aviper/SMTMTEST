import { Observable } from 'rxjs';

import { ComparisonRule, ComparisonRuleGroup } from './model';
import { IItemResponse } from '../../../../../core/models/types/common';
import { ComparisonRulesService } from '../data-access/comparison-rules.service';

export const createRule = (
  groups: ComparisonRuleGroup[],
  data: {
    item: ComparisonRuleGroup;
    creationData: Partial<ComparisonRule>;
  }
): ComparisonRuleGroup[] => {
  const isNewGroup = !groups.some((group) => group.dcmModalityId === data.item.dcmModalityId);

  if (isNewGroup) {
    return groups.concat({
      ...data.item,
      rules: [
        {
          excludesModalities: data.creationData.excludesModalities || [],
          excludesRegions: data.creationData.excludesRegions || [],
          includesModalities: data.creationData.includesModalities || [],
          includesRegions: data.creationData.includesRegions,
          priorModality: data.creationData.priorModality,
          priorModalityId: data.creationData.priorModalityId,
          numberOfExams: data.creationData.numberOfExams,
          includeOldest: data.creationData.includeOldest,
          edited: true,
        },
      ],
    });
  }

  return groups.map((group) => {
    if (group.dcmModalityId !== data.item.dcmModalityId) {
      return group;
    }

    return {
      ...group,
      rules: group.rules.concat({
        excludesModalities: data.creationData.excludesModalities || [],
        excludesRegions: data.creationData.excludesRegions || [],
        includesModalities: data.creationData.includesModalities || [],
        includesRegions: data.creationData.includesRegions,
        priorModality: data.creationData.priorModality,
        priorModalityId: data.creationData.priorModalityId,
        numberOfExams: data.creationData.numberOfExams,
        includeOldest: data.creationData.includeOldest,
        edited: true,
      }),
    };
  });
};

export const deleteRule = (
  groups: ComparisonRuleGroup[],
  data: {
    item: ComparisonRuleGroup;
    index: number;
  }
): ComparisonRuleGroup[] =>
  groups.map((group) => {
    if (group.dcmModalityId !== data.item.dcmModalityId) {
      return group;
    }

    return {
      ...group,
      rules: group.rules.filter((_, index) => index !== data.index),
    };
  });

export const updateRule = (
  groups: ComparisonRuleGroup[],
  data: {
    item: ComparisonRuleGroup;
    index: number;
    payload: Partial<ComparisonRule>;
  }
): ComparisonRuleGroup[] =>
  groups.map((group) => {
    if (group.dcmModalityId !== data.item.dcmModalityId) {
      return group;
    }

    return {
      ...group,
      rules: group.rules.map((rule, index) => {
        if (index !== data.index) {
          return rule;
        }

        return {
          ...rule,
          ...data.payload,
          edited: true,
        };
      }),
    };
  });

export const mapRuleChangesIntoApiCalls = (
  originalGroups: ComparisonRuleGroup[],
  groups: ComparisonRuleGroup[],
  service: ComparisonRulesService
): {
  createActions: Array<Observable<IItemResponse>>;
  updateActions: Array<Observable<IItemResponse>>;
  deleteActions: Array<Observable<IItemResponse>>;
} => {
  const cleanGroups = groups.filter((group) => !(group.id === -1 && group.rules.length === 0));

  const createActions = cleanGroups
    .filter((group) => group.id === -1)
    .map((group) =>
      service.createDefaultRule(
        {
          dcmModalityId: group.dcmModalityId,
          type: 'default',
          rules: group.rules.map((rule) => ({
            excludesModalities: rule.excludesModalities || [],
            excludesRegions: rule.excludesRegions || [],
            includesModalities: rule.includesModalities || [],
            includesRegions: rule.includesRegions,
            priorModality: rule.priorModality,
            priorModalityId: rule.priorModalityId,
            numberOfExams: rule.numberOfExams,
            includeOldest: rule.includeOldest,
          })),
        },
        { autoNotifyErrors: false }
      )
    );

  const deleteActions = cleanGroups
    .filter((group) => group.id !== -1 && group.rules.length === 0)
    .map((group) => service.deleteRule(group.id));

  const updateActions = cleanGroups
    .filter((group) => {
      const originalGroup = originalGroups.find((g) => g.dcmModalityId === group.dcmModalityId);
      const originalGroupRules = originalGroup?.rules || [];

      return (
        group.id !== -1 &&
        group.rules.length > 0 &&
        (group.rules.some((rule) => rule.edited) || originalGroupRules.length !== group.rules.length)
      );
    })
    .map((group) =>
      service.updateRule(group.id, {
        dcmModalityId: group.dcmModalityId,
        type: group.type,
        rules: group.rules.map((rule) => ({
          excludesModalities: rule.excludesModalities || [],
          excludesRegions: rule.excludesRegions || [],
          includesModalities: rule.includesModalities || [],
          includesRegions: rule.includesRegions,
          priorModality: rule.priorModality,
          priorModalityId: rule.priorModalityId,
          numberOfExams: rule.numberOfExams,
          includeOldest: rule.includeOldest,
        })),
      })
    );

  return {
    createActions,
    updateActions,
    deleteActions,
  };
};
