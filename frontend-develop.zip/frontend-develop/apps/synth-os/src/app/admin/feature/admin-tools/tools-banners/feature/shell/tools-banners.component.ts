import { ComponentType } from '@angular/cdk/portal';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, Observable, combineLatest } from 'rxjs';
import { filter, switchMap, takeUntil, debounceTime, tap, retryWhen } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { AdminService } from '../../../../../../core/http-services/admin.service';
import { User } from '../../../../../../core/models/classes/user';
import { IBanner } from '../../../../../../core/models/types/admin';
import { IListResponse, ISort, ITabMenuItem } from '../../../../../../core/models/types/common';
import { IFilterMapValue } from '../../../../../../core/models/types/filter';
import { TabMenuService } from '../../../../../../core/services/tab-menu.service';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { FILTERS_STORAGE_PAGES } from '../../../../../../shared/ui/modules/filters/constants/constants';
import { FiltersComponent } from '../../../../../../shared/ui/modules/filters/filters.component';
import { AdminToolsClass } from '../../../../../utils/admin-tools.class';
import { BANNERS_TOOL_TABS } from '../../../../../utils/constants';
import { AddBannerModal } from '../../ui/add-banner/add-banner-modal.class';
import { AddInternalBannerComponent } from '../../ui/add-banner/add-internal-banner/add-internal-banner.component';
import { AddSystemWideBannerComponent } from '../../ui/add-banner/add-system-wide-banner/add-system-wide-banner.component';

@Component({
  selector: 'app-tools-banners',
  templateUrl: './tools-banners.component.html',
  styleUrls: ['./tools-banners.component.scss'],
  standalone: false,
})
export class ToolsBannersComponent extends AdminToolsClass implements OnInit, AfterViewInit {
  readonly LIMIT = DEFAULT_LIMIT;
  readonly BANNERS_TOOL_TABS = BANNERS_TOOL_TABS;

  user$: Observable<User> = this.ngxsStore.select(ProfileState.user);

  @ViewChild(FiltersComponent, { static: false }) filtersComp: FiltersComponent;

  tabMenu: ITabMenuItem[] = [];
  currentTab: string;
  searchQuery = '';
  filterPage = FILTERS_STORAGE_PAGES.banners;
  pagination = { ...PAGINATION };
  banners: IBanner[] = [];
  sort = {};
  canCreateBanner: boolean;
  canEditBanner: boolean;
  currentInternalFilters = {};

  private search$$: Subject<string> = new Subject();
  private loadBanners$$: Subject<void> = new Subject<void>();
  private selectedFilters = {};
  private user: User;

  constructor(
    private adminService: AdminService,
    private tabMenuService: TabMenuService,
    protected route: ActivatedRoute,
    protected router: Router,
    private modalsV2Service: ModalsV2Service
  ) {
    super(route, router);
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.loadBanners$$
      .pipe(
        tap(() => (this.isLoading = true)),
        switchMap(() =>
          this.adminService
            .getBanners(
              {
                source: this.currentTab,
                limit: this.LIMIT,
                offset: this.pagination.offset,
                query: this.searchQuery,
                ...this.sort,
                ...this.selectedFilters,
              },
              { autoNotifyErrors: false }
            )
            .pipe(
              retryWhen((errors) =>
                errors.pipe(
                  tap((error) => this.modalsV2Service.error(error.message)),
                  debounceTime(5000)
                )
              )
            )
        ),
        takeUntil(this.unsubscribeFromSearchStream$$)
      )
      .subscribe((res: IListResponse) => {
        this.isLoading = false;
        this.banners = this.banners.concat(res.data);
        this.pagination.lastChunkSize = res.data.length;
      });

    this.search$$.pipe(debounceTime(500), takeUntil(this.unsubscribe$$)).subscribe((query: string) => {
      this.searchQuery = query;
      this.updateFilters();
    });
  }

  ngAfterViewInit(): void {
    combineLatest([this.permissions$, this.user$])
      .pipe(
        filter(([permissions, _]) => !!permissions),
        switchMap(([permissions, user]) => {
          this.user = user;
          this.canCreateBanner = permissions.isAdmin();
          this.canEditBanner = this.calculatePermissions();

          return this.filtersComp.init(permissions);
        }),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.currentInternalFilters = this.permissions.isFacilityGroupAdmin()
          ? {
              ...this.filtersComp.currentFilters,
              facilityGroupId: this.user.facilityGroups.length
                ? this.user.facilityGroups[0].id
                : this.user.facilities[0].groupId,
            }
          : this.filtersComp.currentFilters;
        this.updateFilters(this.currentInternalFilters);
        this.getTabMenu();
      });
  }

  setCurrentTab(val: string): void {
    this.currentTab = val;
    this.canEditBanner = this.calculatePermissions();
    this.resetData();
    this.selectedFilters = this.currentTab === this.BANNERS_TOOL_TABS.internal ? this.currentInternalFilters : {};
    this.loadBanners$$.next();
  }

  openBannerCreateModal(type: string): void {
    let bannerModalClass: ComponentType<AddBannerModal> = null;

    switch (type) {
      case this.BANNERS_TOOL_TABS.systemWide: {
        bannerModalClass = AddSystemWideBannerComponent;
        break;
      }

      case this.BANNERS_TOOL_TABS.internal: {
        bannerModalClass = AddInternalBannerComponent;
        break;
      }
    }

    this.modalsV2Service
      .open(bannerModalClass, { data: { bannerLevel: type } })
      .subscribe((res: boolean) => res && this.reloadBanners());
  }

  searchBanners(query: string): void {
    this.search$$.next(query);
  }

  updateFilters(selectedFilters: IFilterMapValue = {}): void {
    if (this.currentTab === this.BANNERS_TOOL_TABS.internal) {
      this.currentInternalFilters = selectedFilters;
    }
    this.selectedFilters = this.currentTab === this.BANNERS_TOOL_TABS.internal ? selectedFilters : {};
    this.resetData();
    this.loadBanners$$.next();
  }

  reloadBanners(): void {
    this.resetData();
    this.loadBanners$$.next();
  }

  sortBanners(sort: ISort): void {
    this.sort = sort.direction ? { sortField: sort.sortField, direction: sort.direction } : {};
    this.resetData();
    this.loadBanners$$.next();
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    this.loadBanners$$.next();
  }

  resetData(): void {
    this.pagination = { ...PAGINATION };
    this.banners = [];
  }

  private getTabMenu(): void {
    this.tabMenu = this.tabMenuService.getBannersTabMenu(this.permissions);
    const tabIndex = this.tabMenu.findIndex((item: ITabMenuItem) => item.available);

    this.setCurrentTab(this.tabMenu[tabIndex].value);
  }

  private calculatePermissions(): boolean {
    if (this.currentTab === this.BANNERS_TOOL_TABS.systemWide) {
      return this.permissions.canEdit(PERMISSIONS_ENDPOINTS.bannersSystemWide);
    }

    if (this.currentTab === this.BANNERS_TOOL_TABS.internal) {
      return this.permissions.canRead(PERMISSIONS_ENDPOINTS.bannersInternal);
    }
  }
}
