import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AdminGlobalExamCodesShellRoutingModule } from './admin-global-exam-codes-shell-routing.module';
import { AdminGlobalExamCodesShellComponent } from './admin-global-exam-codes-shell.component';
import { OldCheckboxComponent } from '../../../../../shared/ui/components/controls/checkbox/checkbox/checkbox.component';
import { CptCodesModule } from '../../../../../shared/ui/modules/cpt-codes/cpt-codes.module';
import { TabMenuModule } from '../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { EditExamCodeNegativeTemplateComponent } from '../../ui/edit-exam-code-negative-template/edit-exam-code-negative-template.component';
import { ExamCodesHeaderComponent } from '../../ui/exam-codes-header/exam-codes-header.component';
import { AdminGlobalExamCodesListComponent } from '../admin-global-exam-codes-list/admin-global-exam-codes-list.component';
import { AdminGlobalModalitiesComponent } from '../admin-global-modalities/admin-global-modalities.component';
import { AdminGlobalRegionsComponent } from '../admin-global-regions/admin-global-regions.component';

@NgModule({
  imports: [
    CommonModule,
    AdminGlobalExamCodesShellRoutingModule,
    TabMenuModule,
    CptCodesModule,
    ExamCodesHeaderComponent,
    EditExamCodeNegativeTemplateComponent,
    OldCheckboxComponent,
  ],
  declarations: [
    AdminGlobalExamCodesShellComponent,
    AdminGlobalExamCodesListComponent,
    AdminGlobalModalitiesComponent,
    AdminGlobalRegionsComponent,
  ],
})
export class AdminGlobalExamCodesShellModule {}
