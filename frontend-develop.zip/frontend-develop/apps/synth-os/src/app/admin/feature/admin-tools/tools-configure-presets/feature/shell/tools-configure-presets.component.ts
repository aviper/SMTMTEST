import { Component } from '@angular/core';

@Component({
  selector: 'app-tools-configure-presets',
  templateUrl: './tools-configure-presets.component.html',
  styleUrls: ['./tools-configure-presets.component.scss'],
  standalone: false,
})
export class ToolsConfigurePresetsComponent {}
