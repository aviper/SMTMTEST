import { Component, Input, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';

import { ICONS } from '../../../../../../../core/constants/icon-list';
import { IBannerType } from '../../../../../../../core/models/types/admin';

@Component({
  selector: 'app-banner-type-dropdown',
  templateUrl: './banner-type-dropdown.component.html',
  styleUrls: ['./banner-type-dropdown.component.scss'],
  standalone: false,
})
export class BannerTypeDropdownComponent implements OnChanges {
  readonly DROPDOWN_ICON = ICONS.dropdownTriangleSmall;
  @Input() bannerType: string;
  @Input() types: IBannerType[];
  @Output() selected: EventEmitter<IBannerType> = new EventEmitter<IBannerType>();

  isActive = false;
  selectedType: IBannerType;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.bannerType) {
      this.selectedType =
        this.types.find((condition) => condition.value === changes.bannerType.currentValue) || this.types[0];
    }
  }

  selectType(type: IBannerType): void {
    this.selected.emit(type);
  }

  toggle(): void {
    this.isActive = !this.isActive;
  }
}
