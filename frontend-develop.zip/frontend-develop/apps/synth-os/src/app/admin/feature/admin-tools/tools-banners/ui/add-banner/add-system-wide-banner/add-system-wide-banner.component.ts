import { Component, ChangeDetectorRef, Inject } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { BannersPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { ModalsV2Service, ModalOverlayRef, modalAnimation, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { AdminService } from '../../../../../../../core/http-services/admin.service';
import { IItemResponse } from '../../../../../../../core/models/types/common';
import { ConverterService } from '../../../../../../../core/services/converter.service';
import { FormService } from '../../../../../../../core/services/form.service';
import { AddBannerModal } from '../add-banner-modal.class';

@Component({
  selector: 'app-add-system-wide-banner',
  templateUrl: '../add-banner-modal.html',
  styleUrls: ['../add-banner-modal.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddSystemWideBannerComponent extends AddBannerModal {
  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    protected formService: FormService,
    protected modalsService: ModalsV2Service,
    private fb: UntypedFormBuilder,
    protected adminService: AdminService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, formService, modalsService, adminService, actionComplete$);
  }

  protected createForm(): void {
    this.bannerForm = this.fb.group({
      duration: [
        this.banner ? ConverterService.secondsToMilliseconds(this.banner.duration) : this.DEFAULT_DURATION,
        [CustomValidators.required, CustomValidators.numbersOnly, Validators.max(this.MAX_DURATION)],
      ],
      content: [
        this.banner?.content || '',
        [
          CustomValidators.maxLengthWithoutHTML(BannersPatterns.content.maxLength),
          CustomValidators.patternInput(BannersPatterns.content.pattern),
          CustomValidators.required,
        ],
      ],
    });
  }

  createBanner(): void {
    this.isLoading = true;
    const body = {
      ...this.bannerForm.value,
      duration: ConverterService.millisecondsToSeconds(this.bannerForm.get('duration').value),
      type: this.bannerType.value,
      theme: this.bannerTheme.value,
      source: this.bannerLevel,
    };

    const request$: Observable<IItemResponse> = this.banner
      ? this.adminService.updateBanner(this.banner.id, body, { autoNotifyErrors: false })
      : this.adminService.createBanner(body, { autoNotifyErrors: false });

    request$.pipe(finalize(() => (this.isLoading = false))).subscribe(
      () => this.closeModal(true),
      (error) => this.modalsService.error(error.message)
    );
  }
}
