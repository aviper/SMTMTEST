import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { Subject, of } from 'rxjs';
import { filter, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';
import { IPagination } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { ICONS } from '../../../../../../core/constants/icon-list';
import { ContractHoldersService } from '../../../../../../core/http-services/contract-holders.service';
import { FacilitiesService } from '../../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { IHumanErrorBody, ISort } from '../../../../../../core/models/types/common';
import { IContractHolder, IGroupContractHolder } from '../../../../../../core/models/types/facility';
import { CreateContractHolderModalComponent } from '../create-contract-holder/create-contract-holder-modal.component';

@Component({
  selector: 'app-contract-holder-table',
  templateUrl: './contract-holder-table.component.html',
  styleUrls: ['./contract-holder-table.component.scss'],
  standalone: false,
})
export class ContractHolderTableComponent implements OnChanges {
  readonly ACTION_ICONS = ICONS.actionsV2;
  private readonly DEFAULT_SCROLL_DISTANCE = 2;

  @Input() data: IGroupContractHolder[];
  @Input() pagination: IPagination;
  @Input() limit = DEFAULT_LIMIT;
  @Input() isLoading = false;
  @Input() permission = new UserPermissions();
  @Input() sorting: ISort;

  @Output() sortChanged: EventEmitter<ISort | {}> = new EventEmitter<ISort | {}>();
  @Output() infinityScrollEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() scrollEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() changed: EventEmitter<null> = new EventEmitter<null>();

  scrollOffset = 2;
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private modalsService: ModalsV2Service,
    private contractHoldersService: ContractHoldersService,
    private facilitiesService: FacilitiesService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data']) {
      this.scrollOffset = this.DEFAULT_SCROLL_DISTANCE + changes['data'].currentValue.length / 10; // 1 item === 1%;
    }
  }

  delete(holder: IContractHolder): void {
    const confirmSubscription$ = holder.invoiceInProcess
      ? this.modalsService.confirm({
          title: 'Confirm delete',
          message: 'Note: Deletion of contract holder information could impact generation of invoices.',
          cancelButton: 'No',
          confirmationButton: 'Yes',
        })
      : of(CONFIRM_POPUP_RESPONSE.submit);

    confirmSubscription$
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        switchMap((_) => this.contractHoldersService.delete(holder.id))
      )
      .subscribe((_) => {
        this.modalsService.success('Contact holder successfully deleted');
        this.changed.emit();
      });
  }

  edit(holder: IContractHolder): void {
    this.modalsService
      .open(CreateContractHolderModalComponent, {
        listenBackdrop: false,
        data: { holder },
      })
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => {
        this.changed.emit();
      });
  }

  toggleRequired(group: { name: string; id: number; isContractHolderRequired: boolean }): void {
    this.facilitiesService
      .editHolderRequirement(
        group.id,
        { isContractHolderRequired: !group.isContractHolderRequired },
        { autoNotifyErrors: false }
      )
      .subscribe(
        () => {
          this.modalsService.success('Requirement was changed!');
          this.changed.emit();
        },
        (err: IHumanErrorBody) => this.modalsService.error(err.message)
      );
  }

  applySort(sort: ISort): void {
    this.sorting = sort;
    this.sortChanged.next(sort);
  }

  onInfinityScroll(offset: number): void {
    this.infinityScrollEvent.emit(offset);
  }

  onScroll(offset: number): void {
    this.scrollEvent.emit(offset);
  }

  trackBy(index: number, item: IContractHolder): number {
    return item.id;
  }
}
