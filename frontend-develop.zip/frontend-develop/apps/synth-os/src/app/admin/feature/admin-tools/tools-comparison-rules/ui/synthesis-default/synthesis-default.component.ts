import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { combineLatest, Observable, Subject } from 'rxjs';
import { filter, map, takeUntil } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';

import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { IModality } from '../../../../../../core/models/types/dictionary';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { ComparisonRulesActions } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.actions';
import { ComparisonRulesState } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.state';
import { DefaultComparisonRulesActions } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-default-comparison-rules.actions';
import { DefaultComparisonRulesState } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-default-comparison-rules.state';
import { ComparisonRule, ComparisonRuleGroup } from '../../utils/model';

@Component({
  selector: 'synth-synthesis-default',
  templateUrl: './synthesis-default.component.html',
  styleUrls: ['./synthesis-default.component.scss'],
  standalone: false,
})
export class SynthesisDefaultComponent implements OnInit, OnDestroy {
  readonly loading$: Observable<boolean> = this.store.select(DefaultComparisonRulesState.loading);
  readonly editing$: Observable<boolean> = this.store.select(DefaultComparisonRulesState.editing);
  readonly saving$: Observable<boolean> = this.store.select(DefaultComparisonRulesState.saving);
  readonly rules$: Observable<ComparisonRuleGroup[]> = this.store.select(DefaultComparisonRulesState.rules);
  readonly modalities$: Observable<IModality[]> = this.store.select(ComparisonRulesState.modalities);

  canEdit$: Observable<boolean> = this.store.select(ProfileState.permissions).pipe(
    filter((permissions) => !!permissions),
    map((permissions) => permissions.canEdit(PERMISSIONS_ENDPOINTS.defaultComparisonRules))
  );

  canSave$: Observable<boolean> = combineLatest([
    this.store.select(DefaultComparisonRulesState.editing),
    this.store.select(DefaultComparisonRulesState.saving),
    this.store.select(DefaultComparisonRulesState.loading),
  ]).pipe(map(([editing, saving, loading]) => editing && !saving && !loading));

  debounceValue = 300;
  rules: ComparisonRuleGroup[] = [];
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.store.dispatch(new ComparisonRulesActions.GetModalities());
    this.store.dispatch(new DefaultComparisonRulesActions.GetDefaultRules());

    combineLatest([this.modalities$, this.rules$, this.loading$])
      .pipe(
        map(([modalities, rules, loading]) => {
          if (loading) {
            return [];
          }

          const modalitiesWithoutRules = modalities.filter(
            (modality) => !rules.some((rule) => rule.dcmModalityId === modality.id)
          );

          return rules.concat(
            modalitiesWithoutRules.map((modality) => ({
              id: -1,
              dcmModalityId: modality.id,
              modality: modality,
              facilityId: null,
              facilityGroupId: null,
              rules: [],
              type: 'default',
            }))
          );
        }),
        map((rules) => rules.sort((a, b) => a.modality.name.localeCompare(b.modality.name))),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((rules) => {
        this.rules = rules;
      });
  }

  startEditing(): void {
    this.store.dispatch(new DefaultComparisonRulesActions.StartEditing());
  }

  cancelEditing(): void {
    this.store.dispatch(new DefaultComparisonRulesActions.CancelEditing());
  }

  saveChanges(): void {
    this.modalsService
      .confirm({
        title: 'Save changes',
        message: 'This will affect all subscribers to the System Default, are you sure?',
        cancelButton: 'Cancel',
        confirmationButton: 'Save',
      })
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.store.dispatch(new DefaultComparisonRulesActions.SaveChanges());
      });
  }

  onCreateRule(data: { item: ComparisonRuleGroup; creationData: ComparisonRule }): void {
    this.store.dispatch(new DefaultComparisonRulesActions.PendingCreateRule(data));
  }

  onEditRule(data: { item: ComparisonRuleGroup; index: number; payload: ComparisonRule }): void {
    this.store.dispatch(new DefaultComparisonRulesActions.PendingUpdateRule(data));
  }

  onDeleteRule(data: { item: ComparisonRuleGroup; index: number }): void {
    this.modalsService
      .confirm({
        title: 'Delete',
        message: 'Are you sure you want to delete this rule?',
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.store.dispatch(new DefaultComparisonRulesActions.PendingDeleteRule(data));
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new DefaultComparisonRulesActions.ClearState());
  }
}
