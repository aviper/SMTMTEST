import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import { buildHttpContext, HttpContextOptions } from '@synth/api';

import { CACHE_KEYS } from '../../../../../core/constants/caching-keys';
import { HttpService } from '../../../../../core/helpers/http.service';
import { IItemResponse, IListResponse } from '../../../../../core/models/types/common';
import { CachingService } from '../../../../../core/services/caching.service';
import { EnvironmentLoaderService } from '../../../../../core/services/environment-loader.service';
import { ComparisonRule, ComparisonRuleGroup } from '../utils/model';

@Injectable({ providedIn: 'root' })
export class ComparisonRulesService extends HttpService {
  constructor(
    private http: HttpClient,
    private cachingService: CachingService,
    private els: EnvironmentLoaderService
  ) {
    super();
  }

  toggleFacilityCustomRules(
    facilityId: number,
    enableDefaultRules: boolean,
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    return this.http
      .post<IItemResponse>(
        `${this.els.getEnvironment().apiV2URL}facility/${facilityId}/enableDefaultPriors`,
        { enableDefaultRules },
        { context: buildHttpContext(contextOptions) }
      )
      .pipe(tap(() => this.cachingService.cleanCacheForKeys(CACHE_KEYS.adminRelevancyTool)));
  }

  getRules(facilityId: number, contextOptions?: HttpContextOptions): Observable<IListResponse> {
    return this.http.get<IItemResponse>(
      `${this.els.getEnvironment().apiV2URL}priorsRelevancy/rules/facility/${facilityId}`,
      { context: buildHttpContext(contextOptions) }
    );
  }

  getDefaultRules(contextOptions?: HttpContextOptions): Observable<IListResponse> {
    return this.http.get<IListResponse>(`${this.els.getEnvironment().apiV2URL}priorsRelevancy/defaultRules`, {
      context: buildHttpContext(contextOptions),
    });
  }

  updateRule(
    ruleId: number,
    body: Partial<ComparisonRuleGroup>,
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    return this.http
      .put<IItemResponse>(`${this.els.getEnvironment().apiV2URL}priorsRelevancy/rules/${ruleId}`, body, {
        context: buildHttpContext(contextOptions),
      })
      .pipe(tap(() => this.cachingService.cleanCacheForKeys(CACHE_KEYS.adminRelevancyTool)));
  }

  createRule(
    facilityId: number,
    body: Partial<ComparisonRuleGroup>,
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    return this.http
      .post<IItemResponse>(`${this.els.getEnvironment().apiV2URL}priorsRelevancy/rules/facility/${facilityId}`, body, {
        context: buildHttpContext(contextOptions),
      })
      .pipe(tap(() => this.cachingService.cleanCacheForKeys(CACHE_KEYS.adminRelevancyTool)));
  }

  deleteRule(ruleId: number, contextOptions?: HttpContextOptions): Observable<IItemResponse> {
    return this.http
      .delete<IItemResponse>(`${this.els.getEnvironment().apiV2URL}priorsRelevancy/rules/${ruleId}`, {
        context: buildHttpContext(contextOptions),
      })
      .pipe(tap(() => this.cachingService.cleanCacheForKeys(CACHE_KEYS.adminRelevancyTool)));
  }

  createDefaultRule(
    body: Partial<ComparisonRuleGroup>,
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    return this.http
      .post<IItemResponse>(`${this.els.getEnvironment().apiV2URL}priorsRelevancy/rules/facility/null`, body, {
        context: buildHttpContext(contextOptions),
      })
      .pipe(tap(() => this.cachingService.cleanCacheForKeys(CACHE_KEYS.adminRelevancyTool)));
  }

  createCustomRuleController(
    facilityId: number,
    data: {
      item: ComparisonRuleGroup;
      creationData: ComparisonRule;
    },
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    if (data.item.id === -1) {
      // if rule group doesn't exist
      return this.createRule(
        facilityId,
        {
          dcmModalityId: data.item.dcmModalityId,
          type: 'custom',
          rules: [
            {
              excludesModalities: data.creationData.excludesModalities,
              excludesRegions: data.creationData.excludesRegions,
              includesModalities: data.creationData.includesModalities,
              includesRegions: data.creationData.includesRegions,
              priorModality: data.creationData.priorModality,
              priorModalityId: data.creationData.priorModalityId,
              numberOfExams: data.creationData.numberOfExams,
              includeOldest: data.creationData.includeOldest,
            },
          ],
        },
        contextOptions
      );
    }

    if (data.item.type !== 'custom') {
      // if rule group is default
      const mappedRules = data.item.rules.map((rule) => ({
        excludesModalities: rule.excludesModalities || [],
        excludesRegions: rule.excludesRegions || [],
        includesModalities: rule.includesModalities || [],
        includesRegions: rule.includesRegions,
        priorModality: rule.priorModality,
        priorModalityId: rule.priorModalityId,
        numberOfExams: rule.numberOfExams,
        includeOldest: rule.includeOldest,
      }));

      return this.createRule(
        facilityId,
        {
          dcmModalityId: data.item.dcmModalityId,
          type: 'custom',
          rules: mappedRules.concat({
            excludesModalities: data.creationData.excludesModalities,
            excludesRegions: data.creationData.excludesRegions,
            includesModalities: data.creationData.includesModalities,
            includesRegions: data.creationData.includesRegions,
            priorModality: data.creationData.priorModality,
            priorModalityId: data.creationData.priorModalityId,
            numberOfExams: data.creationData.numberOfExams,
            includeOldest: data.creationData.includeOldest,
          }),
        },
        contextOptions
      );
    }

    // add new rule to existing custom rules group
    const updatePayload: Partial<ComparisonRuleGroup> = {
      facilityId,
      dcmModalityId: data.item.dcmModalityId,
      type: data.item.type,
      rules: data.item.rules.concat({
        excludesModalities: data.creationData.excludesModalities,
        excludesRegions: data.creationData.excludesRegions,
        includesModalities: data.creationData.includesModalities,
        includesRegions: data.creationData.includesRegions,
        priorModality: data.creationData.priorModality,
        priorModalityId: data.creationData.priorModalityId,
        numberOfExams: data.creationData.numberOfExams,
        includeOldest: data.creationData.includeOldest,
      }),
    };

    return this.updateRule(data.item.id, updatePayload, contextOptions);
  }

  updateCustomRuleController(
    facilityId: number,
    data: {
      item: ComparisonRuleGroup;
      index: number;
      payload: ComparisonRule;
    },
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    if (data.item.type !== 'custom') {
      const createPayload: Partial<ComparisonRuleGroup> = {
        dcmModalityId: data.item.dcmModalityId,
        type: 'custom',
        rules: data.item.rules.map((rule, i) => {
          if (i !== data.index) {
            return {
              excludesModalities: rule.excludesModalities,
              excludesRegions: rule.excludesRegions,
              includesModalities: rule.includesModalities,
              includesRegions: rule.includesRegions,
              priorModality: rule.priorModality,
              priorModalityId: rule.priorModalityId,
              numberOfExams: rule.numberOfExams,
              includeOldest: rule.includeOldest,
            };
          }

          return {
            excludesModalities: data.payload.excludesModalities,
            excludesRegions: data.payload.excludesRegions,
            includesModalities: data.payload.includesModalities,
            includesRegions: data.payload.includesRegions,
            priorModality: data.payload.priorModality,
            priorModalityId: data.payload.priorModalityId,
            numberOfExams: data.payload.numberOfExams,
            includeOldest: data.payload.includeOldest,
          };
        }),
      };

      return this.createRule(facilityId, createPayload, contextOptions);
    }

    const updatePayload: Partial<ComparisonRuleGroup> = {
      dcmModalityId: data.item.dcmModalityId,
      type: data.item.type,
      facilityId,
      rules: data.item.rules.map((rule, i) => {
        if (i !== data.index) {
          return rule;
        }

        return {
          ...rule,
          ...data.payload,
        };
      }),
    };

    return this.updateRule(data.item.id, updatePayload, contextOptions);
  }

  deleteCustomRuleController(
    facilityId: number,
    data: {
      item: ComparisonRuleGroup;
      index: number;
    },
    contextOptions?: HttpContextOptions
  ): Observable<IItemResponse> {
    if (data.item.type !== 'custom') {
      return of(null);
    }

    if (data.item.rules?.length === 1) {
      return this.deleteRule(data.item.id);
    }

    const updatePayload: Partial<ComparisonRuleGroup> = {
      facilityId,
      dcmModalityId: data.item.dcmModalityId,
      type: data.item.type,
      rules: data.item.rules.filter((_, i) => i !== data.index),
    };

    return this.updateRule(data.item.id, updatePayload, contextOptions);
  }
}
