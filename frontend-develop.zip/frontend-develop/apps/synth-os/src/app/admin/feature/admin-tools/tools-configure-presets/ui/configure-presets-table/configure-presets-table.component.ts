import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { CONFIRM_POPUP_RESPONSE, ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PaginationStrategiesNames } from '@synth/utils/feature/pagination';

import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../../core/constants/icon-list';
import { ACTION_COLUMN_WIDTH } from '../../../../../../core/constants/table-constants';
import { IPermissionsConfig, PermissionsClass } from '../../../../../../core/helpers/permissions.class';
import { Profile } from '../../../../../../core/models/classes/profile';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { IPresetAdmin } from '../../../../../../core/models/types/filter';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../../shared/data-access/state/settings/settings.state';
import { ToolsConfigurePresetsActions } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.actions';
import { ToolsConfigurePresetsState } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.state';
import { ORDER_STATUS_OPTIONS } from '../../../../../utils/constants';
import { ConfigurePresetFormModalComponent } from '../configure-preset-form-modal/configure-preset-form-modal.component';
import { ConfigurePresetPreviewModalComponent } from '../configure-preset-preview-modal/configure-preset-preview-modal.component';

@Component({
  selector: 'app-configure-presets-table',
  templateUrl: './configure-presets-table.component.html',
  styleUrls: ['./configure-presets-table.component.scss'],
  standalone: false,
})
export class ConfigurePresetsTableComponent implements OnInit, OnDestroy {
  readonly isLoading$: Observable<boolean> = this.store.select(ToolsConfigurePresetsState.isLoading);
  readonly presets$: Observable<IPresetAdmin[]> = this.store.select(ToolsConfigurePresetsState.presets);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  readonly profile$: Observable<Profile> = this.store.select(ProfileState.profile);
  readonly pagination$: Observable<IPagination> = this.store.select(ToolsConfigurePresetsState.pagination);

  readonly ORDER_STATUS_OPTIONS = ORDER_STATUS_OPTIONS.reduce((previousValue, currentValue) => {
    previousValue[currentValue.value] = currentValue.label;

    return previousValue;
  }, {});
  readonly PaginationStrategiesNames = PaginationStrategiesNames;
  readonly ACTION_COLUMN_WIDTH = ACTION_COLUMN_WIDTH;
  readonly ICONS = ICONS;
  readonly PERMISSIONS_ENDPOINTS = PERMISSIONS_ENDPOINTS;

  data: IPresetAdmin[] = [];
  isLoading = false;
  limit = this.store.selectSnapshot(SettingsState.limit);
  pagination: IPagination;
  configurePresetsTablePermissions: IPermissionsConfig = {
    canEdit: {
      [PERMISSIONS_ENDPOINTS.adminToolsConfigurePresets]: false,
    },
    canDelete: {
      [PERMISSIONS_ENDPOINTS.adminToolsConfigurePresets]: false,
    },
  };

  private unsubscribe$$: Subject<void> = new Subject<void>();
  profile: Profile;

  constructor(
    private modalService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.isLoading$.pipe(takeUntil(this.unsubscribe$$)).subscribe((isLoading) => (this.isLoading = isLoading));

    this.presets$.pipe(takeUntil(this.unsubscribe$$)).subscribe((presets) => (this.data = presets));

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.configurePresetsTablePermissions = PermissionsClass.updatePermissions(
          permissions,
          this.configurePresetsTablePermissions
        );
      });

    this.profile$
      .pipe(
        filter((profile) => !!profile),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((profile) => (this.profile = profile));

    this.pagination$.pipe(takeUntil(this.unsubscribe$$)).subscribe((pagination) => (this.pagination = pagination));
  }

  deletePreset(item: IPresetAdmin): void {
    this.modalService
      .confirm({
        title: 'Delete Preset',
        message: 'If you delete this preset, you will not be able to restore it',
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
        size: 'medium',
      })
      .pipe(filter((response: string) => response === CONFIRM_POPUP_RESPONSE.submit))
      .subscribe(() => {
        this.store.dispatch(new ToolsConfigurePresetsActions.DeletePreset(item.id));
      });
  }

  editPreset(item: IPresetAdmin): void {
    this.modalService.createModal(ConfigurePresetFormModalComponent, {
      data: {
        preset: item,
      },
    });
  }

  viewDetails(item: IPresetAdmin): void {
    this.modalService.createModal(ConfigurePresetPreviewModalComponent, {
      data: {
        preset: item,
      },
    });
  }

  changePresetStatus(status: boolean, preset: IPresetAdmin): void {
    this.store.dispatch(new ToolsConfigurePresetsActions.TogglePresetStatus({ preset }));
  }

  onInfinityScroll(offset: number): void {
    this.store.dispatch(new ToolsConfigurePresetsActions.PaginateAdminPresets(offset));
  }

  ngOnDestroy(): void {
    this.store.dispatch(new ToolsConfigurePresetsActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
