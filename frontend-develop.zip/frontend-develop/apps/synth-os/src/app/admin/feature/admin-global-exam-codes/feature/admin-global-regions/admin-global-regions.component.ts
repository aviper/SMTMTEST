import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { filter, Observable, skip, Subject, takeUntil } from 'rxjs';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../core/constants/constants';
import { GLOBAL_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IRegion } from '../../../../../core/models/types/dictionary';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { SettingsState } from '../../../../../shared/data-access/state/settings/settings.state';
import { RegionModalityModalsComponent } from '../../../../../shared/ui/modules/cpt-codes/region-modality-modals/region-modality-modals.component';
import { AdminGlobalRegionsActions } from '../../../../data-access/state/global-exam-codes/admin-global-regions/admin-global-regions.actions';
import { AdminGlobalRegionsState } from '../../../../data-access/state/global-exam-codes/admin-global-regions/admin-global-regions.state';

@Component({
  selector: 'app-admin-global-regions',
  templateUrl: './admin-global-regions.component.html',
  styleUrls: ['./admin-global-regions.component.scss'],
  standalone: false,
})
export class AdminGlobalRegionsComponent implements OnInit, OnDestroy {
  readonly reload$: Observable<boolean> = this.store.select(AdminGlobalRegionsState.reload);
  readonly isLoading$: Observable<boolean> = this.store.select(AdminGlobalRegionsState.isLoading);
  readonly regions$: Observable<{ regions: IRegion[]; lastChunkSize: number; isLoading: boolean }> = this.store.select(
    AdminGlobalRegionsState.regions
  );
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  limit = DEFAULT_LIMIT;
  searchQuery = '';
  data: IRegion[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = true;
  canCreateRegion: boolean;
  canEditRegion: boolean;
  canDeleteRegion: boolean;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.limit = this.store.selectSnapshot(SettingsState.limit);
    this.store.dispatch(
      new AdminGlobalRegionsActions.GetRegions({
        limit: this.limit,
        offset: 0,
        query: this.searchQuery,
      })
    );

    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.canCreateRegion = permissions.canCreate(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
        this.canEditRegion = permissions.canEdit(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
        this.canDeleteRegion = permissions.canDelete(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes);
      });

    this.regions$
      .pipe(
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.regions;
        this.pagination.lastChunkSize = data.lastChunkSize;
        this.isLoading = data.isLoading;
      });

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.pagination = { ...PAGINATION };

        this.store.dispatch(
          new AdminGlobalRegionsActions.GetRegions({
            limit: this.limit,
            offset: 0,
            query: this.searchQuery,
          })
        );
      });

    this.isLoading$
      .pipe(skip(1), takeUntil(this.unsubscribe$$))
      .subscribe((isLoading: boolean) => (this.isLoading = isLoading));
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    ++this.pagination.page;

    this.store.dispatch(
      new AdminGlobalRegionsActions.GetRegions({
        limit: this.limit,
        offset,
        query: this.searchQuery,
      })
    );
  }

  editRegion(region: IRegion): void {
    this.modalsService.open(RegionModalityModalsComponent, {
      data: {
        action: 'edit',
        type: 'region',
        entity: region,
      },
    });
  }

  deleteRegion(region: IRegion): void {
    this.store.dispatch(new AdminGlobalRegionsActions.DeleteRegion({ regionId: region.id }));
  }

  onSearch(text: string): void {
    this.searchQuery = text;
    this.reload();
  }

  reload(): void {
    this.store.dispatch(new AdminGlobalRegionsActions.RequestReload());
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
