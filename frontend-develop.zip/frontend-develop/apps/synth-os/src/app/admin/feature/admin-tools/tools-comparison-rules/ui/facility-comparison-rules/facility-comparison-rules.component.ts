import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { combineLatest, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, filter, map, takeUntil } from 'rxjs/operators';

import { IFacilityWithDefaultPriorRelevancyRule } from '@synth/api';
import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';

import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { IModality } from '../../../../../../core/models/types/dictionary';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { ComparisonRulesActions } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.actions';
import { ComparisonRulesState } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.state';
import { ComparisonRule, ComparisonRuleGroup } from '../../utils/model';

@Component({
  selector: 'synth-facility-comparison-rules',
  templateUrl: './facility-comparison-rules.component.html',
  styleUrls: ['./facility-comparison-rules.component.scss'],
  standalone: false,
})
export class FacilityComparisonRulesComponent implements OnInit, OnDestroy {
  readonly facility$: Observable<IFacilityWithDefaultPriorRelevancyRule> = this.store.select(
    ComparisonRulesState.facility
  );
  readonly rules$: Observable<ComparisonRuleGroup[]> = this.store.select(ComparisonRulesState.rules);
  readonly modalities$: Observable<IModality[]> = this.store.select(ComparisonRulesState.modalities);

  private unsubscribe$$: Subject<void> = new Subject<void>();

  loading$: Observable<boolean> = combineLatest([
    this.store.select(ComparisonRulesState.isLoading),
    this.store.select(ComparisonRulesState.modalitiesLoading),
  ]).pipe(map(([r, m]) => r || m));

  permissionsAndFacility$ = combineLatest([
    this.store.select(ProfileState.permissions),
    this.store.select(ComparisonRulesState.facility),
  ]).pipe(
    filter(([p, f]) => !!p && !!f),
    takeUntil(this.unsubscribe$$)
  );

  canCreate$: Observable<boolean> = this.permissionsAndFacility$.pipe(
    map(([p, f]) => !f.defaultPriorRelevancyRule && p.canCreate(PERMISSIONS_ENDPOINTS.comparisonRules))
  );

  canEdit$: Observable<boolean> = this.permissionsAndFacility$.pipe(
    map(([p, f]) => !f.defaultPriorRelevancyRule && p.canEdit(PERMISSIONS_ENDPOINTS.comparisonRules))
  );

  canDelete$: Observable<boolean> = this.permissionsAndFacility$.pipe(
    map(([p, f]) => !f.defaultPriorRelevancyRule && p.canDelete(PERMISSIONS_ENDPOINTS.comparisonRules))
  );

  rules: ComparisonRuleGroup[] = [];
  activeFacility: IFacilityWithDefaultPriorRelevancyRule;

  constructor(
    private store: Store,
    private modalsService: ModalsV2Service
  ) {}

  ngOnInit(): void {
    this.facility$
      .pipe(
        filter((facility) => !!facility),
        distinctUntilChanged(),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((facility) => {
        this.activeFacility = facility;
        this.store.dispatch(new ComparisonRulesActions.GetModalities());
        this.store.dispatch(new ComparisonRulesActions.GetRules());
      });

    combineLatest([this.modalities$, this.rules$, this.loading$])
      .pipe(
        map(([modalities, rules, loading]) => {
          if (loading) {
            return [];
          }

          const modalitiesWithoutRules = modalities.filter(
            (modality) => !rules.some((rule) => rule.dcmModalityId === modality.id)
          );

          return rules.concat(
            modalitiesWithoutRules.map((modality) => ({
              id: -1,
              dcmModalityId: modality.id,
              modality: modality,
              facilityId: null,
              facilityGroupId: null,
              rules: [],
              type: 'custom',
            }))
          );
        }),
        map((rules) => rules.sort((a, b) => a.modality.name.localeCompare(b.modality.name))),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((rules) => {
        this.rules = rules;
      });
  }

  onCreateRule(data: { item: ComparisonRuleGroup; creationData: ComparisonRule }): void {
    this.store.dispatch(new ComparisonRulesActions.CreateRule(data));
  }

  onDeleteRule(data: { item: ComparisonRuleGroup; index: number }): void {
    this.modalsService
      .confirm({
        title: 'Delete',
        message: 'Are you sure you want to delete this rule?',
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(
        filter((result) => result === CONFIRM_POPUP_RESPONSE.submit),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.store.dispatch(new ComparisonRulesActions.DeleteRule(data));
      });
  }

  onEditRule(data: { item: ComparisonRuleGroup; index: number; payload: ComparisonRule }): void {
    this.store.dispatch(new ComparisonRulesActions.UpdateRule(data));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
