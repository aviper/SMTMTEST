import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { ToolsContractHolderComponent } from './tools-contract-holder.component';
import { OldInputComponent } from '../../../../../../shared/ui/components/controls/input/input.component';
import { FacilityGroupSelectV2Component } from '../../../../../../shared/ui/components/controls/selects/faciliy-group-select-v2/facility-group-select-v2.component';
import { OldIconComponentModule } from '../../../../../../shared/ui/components/icon/icon.component';
import { ControlErrorV2DirectiveModule } from '../../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { TableModule } from '../../../../../../shared/ui/modules/table/table.module';
import { AdminToolDetailsHeaderComponentModule } from '../../../feature/admin-tool-details-header/admin-tool-details-header.component';
import { ContractHolderTableComponent } from '../../ui/contract-holder-table/contract-holder-table.component';
import { CreateContractHolderModalComponent } from '../../ui/create-contract-holder/create-contract-holder-modal.component';

const routes: Routes = [
  {
    path: '',
    component: ToolsContractHolderComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class ToolsContractHolderRoutingModule {}

@NgModule({
  declarations: [ToolsContractHolderComponent, ContractHolderTableComponent, CreateContractHolderModalComponent],
  imports: [
    CommonModule,
    TableModule,
    ReactiveFormsModule,
    AdminToolDetailsHeaderComponentModule,
    ButtonsModule,
    ToolsContractHolderRoutingModule,
    EllipsisTextModule,
    OldIconComponentModule,
    FacilityGroupSelectV2Component,
    OldInputComponent,
    ControlErrorV2DirectiveModule,
  ],
})
export class ToolsContractHolderModule {}
