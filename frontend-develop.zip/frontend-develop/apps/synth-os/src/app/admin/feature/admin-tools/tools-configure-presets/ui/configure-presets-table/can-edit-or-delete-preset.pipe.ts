import { Pipe, PipeTransform } from '@angular/core';

import { Profile } from '../../../../../../core/models/classes/profile';
import { IPresetAdmin } from '../../../../../../core/models/types/filter';
import { ROLE_LEVELS } from '../../../../../utils/constants';

@Pipe({
  name: 'canEditOrDeletePreset',
  standalone: false,
})
export class CanEditOrDeletePresetPipe implements PipeTransform {
  transform(preset: IPresetAdmin, profile: Profile): boolean {
    if (!profile || !profile.user || !preset) {
      return false;
    }

    const roleTypes = preset.roles?.map((role) => role.type) ?? [];
    const facilityGroups = preset.user?.facilityGroups?.map((group) => group) ?? [];

    return (
      profile.user.role.type !== ROLE_LEVELS.local ||
      (!roleTypes.includes(ROLE_LEVELS.global) &&
        !!facilityGroups &&
        !facilityGroups.some((id) => id !== preset.facilityGroupId))
    );
  }
}
