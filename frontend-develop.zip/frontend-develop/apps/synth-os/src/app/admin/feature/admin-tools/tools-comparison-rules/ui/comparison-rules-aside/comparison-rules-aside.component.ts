import { Component, OnDestroy, OnInit, TrackByFunction } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { BehaviorSubject, filter, Observable, Subject } from 'rxjs';
import { finalize, switchMap, takeUntil } from 'rxjs/operators';

import {
  ApiClientService,
  IFacilityWithDefaultPriorRelevancyRule,
  getFacilityByIdWithPriorRelevancyRule,
} from '@synth/api';
import { ICONS } from '@synth/utils';

import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { FacilitiesService } from '../../../../../../core/http-services/facilities.service';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { ComparisonRulesActions } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.actions';
import { ComparisonRulesState } from '../../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.state';
import { ComparisonRulesService } from '../../data-access/comparison-rules.service';

interface ComparisonRulesItem {
  group: IFacilityGroup;
  facilities: IFacilityWithDefaultPriorRelevancyRule[];
}
@Component({
  selector: 'synth-comparison-rules-aside',
  templateUrl: './comparison-rules-aside.component.html',
  styleUrls: ['./comparison-rules-aside.component.scss'],
  standalone: false,
})
export class ComparisonRulesAsideComponent implements OnInit, OnDestroy {
  readonly facility$: Observable<IFacilityWithDefaultPriorRelevancyRule> = this.store.select(
    ComparisonRulesState.facility
  );
  readonly group$: Observable<IFacilityGroup> = this.store.select(ComparisonRulesState.facilityGroup);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  readonly ICONS = ICONS;

  facilityGroups: IFacilityGroup[] = [];
  loadersArray = new Array(10);
  groupsLoading = false;
  facilitiesLoading: number[] = [];

  readonly items$$: BehaviorSubject<ComparisonRulesItem[]> = new BehaviorSubject<ComparisonRulesItem[]>([]);
  readonly items$ = this.items$$.asObservable();

  readonly trackByGroupId: TrackByFunction<ComparisonRulesItem> = (_: number, item: ComparisonRulesItem) =>
    item.group.id;
  readonly trackByFacilityId: TrackByFunction<IFacilityWithDefaultPriorRelevancyRule> = (_: number, item: IFacilityWithDefaultPriorRelevancyRule) => item.id;

  activeGroup: IFacilityGroup;
  activeFacility: IFacilityWithDefaultPriorRelevancyRule;
  canToggleCustomRules = false;
  canSeeDefault = false;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    private facilitiesService: FacilitiesService,
    private comparisonRulesService: ComparisonRulesService,
    private router: Router,
    private store: Store,
    private readonly apiClient: ApiClientService
  ) {}

  ngOnInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions) => {
        this.canToggleCustomRules = permissions.canEdit(PERMISSIONS_ENDPOINTS.comparisonRules);
        this.canSeeDefault = permissions.canRead(PERMISSIONS_ENDPOINTS.defaultComparisonRules);
      });

    this.facility$.pipe(takeUntil(this.unsubscribe$$)).subscribe((facility) => {
      this.activeFacility = facility;
    });

    this.group$.pipe(takeUntil(this.unsubscribe$$)).subscribe((group) => {
      this.activeGroup = group;
    });

    this.getGroups();
  }

  getGroups(): void {
    this.groupsLoading = true;

    this.facilitiesService
      .getGroups({
        offset: 0,
        limit: 1000,
      })
      .pipe(
        finalize(() => (this.groupsLoading = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        this.items$$.next(response.data.map((group) => ({ group, facilities: [] })));

        if (!this.activeGroup) {
          return;
        }

        const groupInResponse = response.data.find((group) => group.id === this.activeGroup?.id);

        if (!groupInResponse) {
          this.store.dispatch(new ComparisonRulesActions.SetFacilityGroup(null));
          this.store.dispatch(new ComparisonRulesActions.SetFacility(null));

          return;
        }

        this.store.dispatch(new ComparisonRulesActions.SetFacilityGroup(groupInResponse));
        this.getFacilitiesForGroup(groupInResponse.id);
      });
  }

  getFacilitiesForGroup(id: number): void {
    this.facilitiesLoading.push(id);

    this.facilitiesService
      .getGroupFacilities(id, {
        offset: 0,
        limit: 1000,
      })
      .pipe(
        finalize(() => (this.facilitiesLoading = this.facilitiesLoading.filter((facilityId) => facilityId !== id))),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((response) => {
        const items = this.items$$.getValue();
        const groupIndex = items.findIndex((item) => item.group.id === id);

        if (groupIndex !== -1) {
          items[groupIndex].facilities = response.data;
          this.items$$.next(items);
        }

        if (!this.activeFacility) {
          return;
        }

        const facilityInResponse = response.data.find((facility) => facility.id === this.activeFacility?.id);

        this.store.dispatch(new ComparisonRulesActions.SetFacility(facilityInResponse ? facilityInResponse : null));
      });
  }

  toggleCustomRules(value: boolean, facility: IFacilityWithDefaultPriorRelevancyRule, group: IFacilityGroup): void {
    this.comparisonRulesService
      .toggleFacilityCustomRules(facility.id, !value)
      .pipe(
        switchMap(() => this.apiClient.exec(getFacilityByIdWithPriorRelevancyRule, { id: facility.id })),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((res) => {
        const items = this.items$$.getValue();
        const groupIndex = items.findIndex((item) => item.group.id === group.id);

        if (groupIndex === -1) {
          return;
        }

        items[groupIndex].facilities = items[groupIndex].facilities.map((f) => (f.id === res.data.id ? res.data : f));

        this.items$$.next([...items]);

        if (res.data.id === this.activeFacility?.id) {
          this.store.dispatch(new ComparisonRulesActions.SetFacility(res.data));
        }
      });
  }

  back(): void {
    this.router.navigate(['/adminPanel/tools']);
  }

  selectGroup(group: IFacilityGroup): void {
    if (this.activeGroup?.id === group.id) {
      this.store.dispatch(new ComparisonRulesActions.SetFacility(null));
      this.store.dispatch(new ComparisonRulesActions.SetFacilityGroup(null));

      return;
    }

    const item = this.items$$.getValue().find((item) => item.group.id === group.id);

    if (item.facilities.length === 0) {
      this.getFacilitiesForGroup(group.id);
    }

    this.store.dispatch(new ComparisonRulesActions.SetFacility(null));
    this.store.dispatch(new ComparisonRulesActions.SetFacilityGroup(group));
  }

  selectFacility(facility: IFacilityWithDefaultPriorRelevancyRule): void {
    if (this.activeFacility?.id === facility.id) {
      return;
    }

    this.store.dispatch(new ComparisonRulesActions.SetFacility(facility));
  }

  selectDefault(): void {
    this.store.dispatch(new ComparisonRulesActions.SetFacility(null));
    this.store.dispatch(new ComparisonRulesActions.SetFacilityGroup(null));
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
