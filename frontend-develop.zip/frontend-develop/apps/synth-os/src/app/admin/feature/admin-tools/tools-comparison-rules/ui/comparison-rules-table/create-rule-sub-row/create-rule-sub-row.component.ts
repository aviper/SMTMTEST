import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Actions, ofActionDispatched } from '@ngxs/store';
import { Subject } from 'rxjs';
import { debounceTime, filter, takeUntil } from 'rxjs/operators';

import { ICONS } from '@synth/utils';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { IOption } from '../../../../../../../core/models/types/common';
import { DefaultComparisonRulesActions } from '../../../../../../data-access/state/tools/tools-comparison-rules/tools-default-comparison-rules.actions';
import { ComparisonRule, ComparisonRuleGroup } from '../../../utils/model';

@Component({
  selector: 'synth-create-comparison-rule-sub-row',
  templateUrl: './create-rule-sub-row.component.html',
  styleUrls: ['./create-rule-sub-row.component.scss'],
  standalone: false,
})
export class CreateRuleSubRowComponent implements OnInit, OnDestroy {
  @Input() rulesGroup: ComparisonRuleGroup;

  @Output() cancel: EventEmitter<void> = new EventEmitter<void>();
  @Output() readyToCreate: EventEmitter<ComparisonRule> = new EventEmitter<ComparisonRule>();

  readonly ICONS = ICONS;

  additionalRegionsOptions: IOption[] = [
    { label: 'Any', value: 'Any regions' },
    { label: 'Same', value: 'Related regions' },
  ];

  modalitiesControl = new FormControl<string[]>([], CustomValidators.required);
  regionsControl = new FormControl<string[]>([], CustomValidators.required);
  numberOfExamsControl = new FormControl<number>(null, [
    CustomValidators.required,
    Validators.min(1),
    Validators.max(9),
  ]);
  includeOldest = false;
  excludeModalitiesOptions: string[] = [];
  regionsOpened = false;
  modalitiesOpened = false;

  private validateChanges$$: Subject<void> = new Subject<void>();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(private actions: Actions) {}

  ngOnInit(): void {
    this.actions
      .pipe(ofActionDispatched(DefaultComparisonRulesActions.CancelEditing), takeUntil(this.unsubscribe$$))
      .subscribe(() => this.cancelCreation());

    this.validateChanges$$
      .asObservable()
      .pipe(
        debounceTime(1500),
        filter(() => !this.regionsOpened && !this.modalitiesOpened),
        filter(() => this.modalitiesControl.valid && this.regionsControl.valid && this.numberOfExamsControl.valid),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.readyToCreate.emit({
          priorModality: this.rulesGroup?.modality?.name,
          priorModalityId: this.rulesGroup.dcmModalityId,
          excludesModalities: [],
          excludesRegions: [],
          includesModalities: this.modalitiesControl.value,
          includesRegions: this.regionsControl.value,
          numberOfExams: this.numberOfExamsControl.value,
          includeOldest: this.includeOldest,
        });
      });

    this.numberOfExamsControl.valueChanges
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.validateChanges$$.next());

    this.excludeModalitiesOptions = this.rulesGroup.rules
      .map((rule) => rule.includesModalities)
      .filter((items) => items && items.length)
      .flat();
  }

  onRegionsOpen(): void {
    this.regionsOpened = true;
  }

  onModalitiesOpen(): void {
    this.modalitiesOpened = true;
  }

  onModalityChange(selectedOptions: IOption[]): void {
    this.modalitiesOpened = false;
    this.validateChanges$$.next();
  }

  onRegionsChange(selectedOptions: IOption[]): void {
    const value = this.regionsControl.value;

    this.additionalRegionsOptions.forEach((option) => {
      if (value.length && value.includes(option.value)) {
        this.regionsControl.setValue([option.value]);
      }
    });

    this.regionsOpened = false;
    this.validateChanges$$.next();
  }

  onOptionClick(option: IOption): void {
    const currentValue = this.regionsControl.value;

    if (option.value.toLowerCase() === 'any regions' || option.value.toLowerCase() === 'related regions') {
      this.regionsControl.setValue([option.value]);
    } else {
      this.regionsControl.setValue(
        currentValue.filter(
          (value) => value.toLowerCase() !== 'any regions' && value.toLowerCase() !== 'related regions'
        )
      );
    }
  }

  changeIncludeOldest(includeOldest: boolean): void {
    this.includeOldest = includeOldest;
  }

  cancelCreation(): void {
    this.cancel.emit();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
