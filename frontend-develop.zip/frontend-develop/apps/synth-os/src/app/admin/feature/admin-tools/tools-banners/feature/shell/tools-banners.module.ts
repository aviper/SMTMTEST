import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { SanitizePipe } from '@synth/ui';

import { ToolsBannersComponent } from './tools-banners.component';
import { ActionsButtonDropdownComponentModule } from '../../../../../../shared/ui/components/actions-button-dropdown/actions-button-dropdown.component';
import { DayHourMinInputComponent } from '../../../../../../shared/ui/components/controls/day-hour-min-input/day-hour-min-input.component';
import { SearchFieldComponent } from '../../../../../../shared/ui/components/controls/search-field/search-field.component';
import { FacilitySelectV2Component } from '../../../../../../shared/ui/components/controls/selects/facility-select-v2/facility-select-v2.component';
import { FacilityGroupSelectV2Component } from '../../../../../../shared/ui/components/controls/selects/faciliy-group-select-v2/facility-group-select-v2.component';
import { RolesSelectComponent } from '../../../../../../shared/ui/components/controls/selects/roles-select/roles-select.component';
import { OldIconComponentModule } from '../../../../../../shared/ui/components/icon/icon.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../../shared/ui/modules/buttons/buttons.module';
import { EditorModule } from '../../../../../../shared/ui/modules/editor/editor.module';
import { EllipsisTextModule } from '../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { FiltersModule } from '../../../../../../shared/ui/modules/filters/filters.module';
import { LoaderModule } from '../../../../../../shared/ui/modules/loader/loader.module';
import { MdePopoverModule } from '../../../../../../shared/ui/modules/mde-popover';
import { TabMenuModule } from '../../../../../../shared/ui/modules/tab-menu/tab-menu.module';
import { TableModule } from '../../../../../../shared/ui/modules/table/table.module';
import { ArrayNamesPipeModule } from '../../../../../../shared/ui/pipes/array-names.pipe';
import { HumanizedDurationPipeModule } from '../../../../../../shared/ui/pipes/humanized-duration.pipe';
import { TextOnlyPipeModule } from '../../../../../../shared/ui/pipes/text-only.pipe';
import { AdminToolDetailsHeaderComponentModule } from '../../../feature/admin-tool-details-header/admin-tool-details-header.component';
import { AddInternalBannerComponent } from '../../ui/add-banner/add-internal-banner/add-internal-banner.component';
import { AddSystemWideBannerComponent } from '../../ui/add-banner/add-system-wide-banner/add-system-wide-banner.component';
import { BannerThemeDropdownComponent } from '../../ui/add-banner/banner-theme-dropdown/banner-theme-dropdown.component';
import { BannerTypeDropdownComponent } from '../../ui/add-banner/banner-type-dropdown/banner-type-dropdown.component';
import { BannersTableHeaderComponent } from '../../ui/banners-table/banners-table-header/banners-table-header.component';
import { BannersTableRowComponent } from '../../ui/banners-table/banners-table-row/banners-table-row.component';
import { BannersTableComponent } from '../../ui/banners-table/banners-table.component';

const routes: Routes = [
  {
    path: '',
    component: ToolsBannersComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class ToolsBannersRoutingModule {}

@NgModule({
  declarations: [
    ToolsBannersComponent,
    BannersTableComponent,
    BannersTableHeaderComponent,
    BannersTableRowComponent,
    BannerTypeDropdownComponent,
    BannerThemeDropdownComponent,
    AddSystemWideBannerComponent,
    AddInternalBannerComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ToolsBannersRoutingModule,
    AdminToolDetailsHeaderComponentModule,
    FiltersModule,
    SearchFieldComponent,
    ActionsButtonDropdownComponentModule,
    TableModule,
    EllipsisTextModule,
    ArrayNamesPipeModule,
    HumanizedDurationPipeModule,
    TextOnlyPipeModule,
    OldIconComponentModule,
    DayHourMinInputComponent,
    EditorModule,
    ButtonsModule,
    MdePopoverModule,
    LoaderModule,
    RolesSelectComponent,
    FacilitySelectV2Component,
    FacilityGroupSelectV2Component,
    TabMenuModule,
    CdkScrollableExtendedDirectiveModule,
    ControlErrorV2DirectiveModule,
    SanitizePipe,
  ],
})
export class ToolsBannersModule {}
