import { ComponentType } from '@angular/cdk/portal';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { filter, switchMap } from 'rxjs/operators';

import { ModalsV2Service, CONFIRM_POPUP_RESPONSE } from '@synth/ui/modals';

import { ICONS } from '../../../../../../../core/constants/icon-list';
import { AdminService } from '../../../../../../../core/http-services/admin.service';
import { IBanner } from '../../../../../../../core/models/types/admin';
import { BANNERS_TOOL_TABS } from '../../../../../../utils/constants';
import { AddBannerModal } from '../../add-banner/add-banner-modal.class';
import { AddInternalBannerComponent } from '../../add-banner/add-internal-banner/add-internal-banner.component';
import { AddSystemWideBannerComponent } from '../../add-banner/add-system-wide-banner/add-system-wide-banner.component';

@Component({
  selector: 'app-banners-table-row',
  templateUrl: './banners-table-row.component.html',
  styleUrls: ['./banners-table-row.component.scss'],
  standalone: false,
})
export class BannersTableRowComponent implements OnInit {
  readonly ACTIONS = ICONS.actionsV2;
  readonly BANNERS_TOOL_TABS = BANNERS_TOOL_TABS;

  @Input() banner: IBanner;
  @Input() currentTab: string;
  @Input() canEditBanner: boolean;

  @Output() changed: EventEmitter<void> = new EventEmitter<void>();

  isEnableDisplay: boolean;

  constructor(
    private modalsService: ModalsV2Service,
    private adminService: AdminService
  ) {}

  ngOnInit(): void {
    this.isEnableDisplay = this.banner.status === 'enabled' ? true : false;
  }

  deleteBanner(banner: IBanner): void {
    this.modalsService
      .confirm({
        title: 'Wait!',
        message: `Are you sure to delete this banner? ID: ${banner.id}`,
        cancelButton: 'Cancel',
        confirmationButton: 'Delete',
      })
      .pipe(
        filter((res) => res === CONFIRM_POPUP_RESPONSE.submit),
        switchMap(() => this.adminService.deleteBanner(banner.id, { autoNotifyErrors: false }))
      )
      .subscribe(
        () => {
          this.modalsService.success('Banner deleted');
          this.changed.emit();
        },
        (error) => this.modalsService.error(error.message)
      );
  }

  toggleBannerStatus(banner: IBanner, enabled: boolean): void {
    const newStatus = enabled ? 'enabled' : 'disabled';

    this.adminService.updateBanner(banner.id, { status: newStatus }, { autoNotifyErrors: false }).subscribe(
      () => {
        this.modalsService.success('Banner updated');
        this.changed.emit();
      },
      (error) => this.modalsService.error(error.message)
    );
  }

  editBanner(banner: IBanner): void {
    let bannerModalClass: ComponentType<AddBannerModal> = null;

    switch (banner.source) {
      case this.BANNERS_TOOL_TABS.systemWide: {
        bannerModalClass = AddSystemWideBannerComponent;
        break;
      }

      case this.BANNERS_TOOL_TABS.internal: {
        bannerModalClass = AddInternalBannerComponent;
        break;
      }
    }

    this.modalsService
      .open(bannerModalClass, { data: { bannerLevel: banner.source, banner } })
      .subscribe((res: boolean) => res && this.changed.emit());
  }
}
