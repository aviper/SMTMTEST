import { Component, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, debounceTime } from 'rxjs/operators';

import { ICONS } from '../../../core/constants/icon-list';
import { IRoleDetails, IRolePermission, IRolePermissionGroup, PermissionAction } from '../../../core/models/types/acl';
import { RoutingService } from '../../../core/services/routing.service';
import { ExpansionBlockComponent } from '../../../shared/ui/components/expansion-block/expansion-block.component';
import { AdminRoleDetailsActions } from '../../data-access/state/roles/admin-role-details/admin-role-details.actions';
import { AdminRoleDetailsState } from '../../data-access/state/roles/admin-role-details/admin-role-details.state';

@Component({
  selector: 'app-admin-role-details',
  templateUrl: './admin-role-details.component.html',
  styleUrls: ['./admin-role-details.component.scss'],
  standalone: false,
})
export class AdminRoleDetailsComponent implements OnInit, OnDestroy {
  readonly ICONS = ICONS;

  readonly role$: Observable<IRoleDetails> = this.store.select(AdminRoleDetailsState.role);
  readonly rolePermissions$: Observable<IRolePermissionGroup[]> = this.store.select(AdminRoleDetailsState.permissions);
  readonly entitiesInProcess$: Observable<
    { entity: IRolePermission; updatingStatuses: { [key in PermissionAction]: boolean } }[]
  > = this.store.select(AdminRoleDetailsState.entitiesInProcess);
  readonly permissionsSearch$: Observable<string> = this.store.select(AdminRoleDetailsState.searchPemissions);
  @ViewChildren(ExpansionBlockComponent) private collapsableBlocks: QueryList<ExpansionBlockComponent>;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private search$$: Subject<string> = new Subject<string>();
  private previousRoute: string;
  private roleId: number;
  role: IRoleDetails = null;
  rolePermissions: IRolePermissionGroup[] = [];
  entitiesInProcess = [];
  searchQuery = '';

  constructor(
    private activatedRoute: ActivatedRoute,
    private routingService: RoutingService,
    private router: Router,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.pipe(takeUntil(this.unsubscribe$$)).subscribe((paramMap: ParamMap) => {
      this.previousRoute = this.routingService.getPreviousUrl();
      this.roleId = parseInt(paramMap.get('id'), 10);
      this.store.dispatch(new AdminRoleDetailsActions.GetRoleDetails(this.roleId));
    });

    this.role$.pipe(takeUntil(this.unsubscribe$$)).subscribe((role) => (this.role = role));

    this.rolePermissions$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((permissions) => (this.rolePermissions = permissions));

    this.entitiesInProcess$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((entities) => (this.entitiesInProcess = entities));

    this.permissionsSearch$.pipe(takeUntil(this.unsubscribe$$)).subscribe((query) => (this.searchQuery = query));

    this.search$$
      .pipe(debounceTime(500), takeUntil(this.unsubscribe$$))
      .subscribe((query) =>
        this.store.dispatch(new AdminRoleDetailsActions.SearchRolePermissons({ query, roleId: this.roleId }))
      );
  }

  searchPermissions(query: string): void {
    this.search$$.next(query);
  }

  back(): void {
    this.router.navigate([this.previousRoute || 'adminPanel/roles']);
  }

  collapseAll(): void {
    const newBlocksState = !this.isAllCollapsed();

    this.collapsableBlocks.forEach((block) => block.changeState(newBlocksState));
  }

  private isAllCollapsed(): boolean {
    let isAllCollapsed = true;

    this.collapsableBlocks.forEach((block) => {
      if (!block.isCollapsed) {
        isAllCollapsed = false;
      }
    });

    return isAllCollapsed;
  }

  trackByFn(index: number, item: IRolePermission): number {
    return item.id;
  }

  groupsTrackBy(index: number): number {
    return index;
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.store.dispatch(new AdminRoleDetailsActions.ClearData());
  }
}
