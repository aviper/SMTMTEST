import { NgIf } from '@angular/common';
import { AfterViewInit, Component, Input, OnDestroy, OnInit, Output, ViewChild, EventEmitter } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, switchMap, takeUntil, tap } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { SHEETS_TYPES } from '../../../../../core/constants/constants';
import { GLOBAL_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { IFilterMapValue } from '../../../../../core/models/types/filter';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { ActionsButtonDropdownComponentModule } from '../../../../../shared/ui/components/actions-button-dropdown/actions-button-dropdown.component';
import { SearchFieldComponent } from '../../../../../shared/ui/components/controls/search-field/search-field.component';
import { UploadSheetsComponent } from '../../../../../shared/ui/components/upload-sheets/upload-sheets.component';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';
import { CreateStandardCptComponent } from '../../../../../shared/ui/modules/cpt-codes/cpt-code-modals/create-cpt-code/create-standard-cpt/create-standard-cpt.component';
import { FILTERS_STORAGE_PAGES } from '../../../../../shared/ui/modules/filters/constants/constants';
import { FiltersComponent } from '../../../../../shared/ui/modules/filters/filters.component';
import { FiltersModule } from '../../../../../shared/ui/modules/filters/filters.module';
import { AdminGlobalExamCodesListActions } from '../../../../data-access/state/global-exam-codes/admin-global-exam-codes-list/admin-global-exam-codes-list.actions';
import { AdminGlobalExamCodesListState } from '../../../../data-access/state/global-exam-codes/admin-global-exam-codes-list/admin-global-exam-codes-list.state';

@Component({
  imports: [ActionsButtonDropdownComponentModule, ButtonsModule, FiltersModule, SearchFieldComponent, NgIf],
  selector: 'app-exam-codes-header',
  templateUrl: './exam-codes-header.component.html',
  styleUrls: ['./exam-codes-header.component.scss'],
})
export class ExamCodesHeaderComponent implements OnInit, OnDestroy, AfterViewInit {
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);
  @ViewChild(FiltersComponent, { static: false }) filtersComp: FiltersComponent;

  @Input() searchQuery = '';
  @Output() search: EventEmitter<string> = new EventEmitter<string>();

  canCreateExamCode = false;

  readonly FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;
  readonly SHEETS_TYPES = SHEETS_TYPES;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private search$$: Subject<string> = new Subject<string>();

  constructor(
    private modalsService: ModalsV2Service,
    private store: Store,
    private dictionaryService: DictionaryService
  ) {}

  openCreateCptModal(): void {
    this.modalsService
      .open(CreateStandardCptComponent, { listenBackdrop: false })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new AdminGlobalExamCodesListActions.RequestReload()));
  }

  openUploadModal(sheetType: string): void {
    this.modalsService
      .open(UploadSheetsComponent, {
        listenBackdrop: false,
        data: { type: sheetType, findingType: 'global' },
      })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new AdminGlobalExamCodesListActions.RequestReload()));
  }

  ngOnInit(): void {
    this.search$$
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((query: string) => this.search.emit(query));
  }

  ngAfterViewInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        tap(
          (permissions: UserPermissions) =>
            (this.canCreateExamCode = permissions.canCreate(GLOBAL_ENDPOINTS.modalitiesRegionsExamCodes))
        ),
        switchMap((permissions) => this.filtersComp.init(permissions)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.updateSelectedFilters(this.filtersComp.currentFilters);
      });
  }

  updateSelectedFilters(selectedFilters: IFilterMapValue): void {
    this.store.dispatch(new AdminGlobalExamCodesListActions.UpdateCptFilters(selectedFilters));
  }

  searchCpts(query: string): void {
    this.search$$.next(query);
  }

  downloadExamCodes(): void {
    const filters = this.store.selectSnapshot(AdminGlobalExamCodesListState.filters);
    const query = this.store.selectSnapshot(AdminGlobalExamCodesListState.query);

    this.dictionaryService
      .downloadExamCodes({
        ...filters,
        query,
        fromAdmin: true,
      })
      .subscribe((res) => {
        const link = document.createElement('a');

        link.href = window.URL.createObjectURL(res.blob);
        link.download = res.fileName;
        link.target = '_blank';
        link.click();
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
