import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AdminToolsShellRoutingModule } from './admin-tools-shell-routing.module';
import { AdminToolsShellComponent } from './admin-tools-shell.component';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';
import { ToolTileComponent } from '../../../../ui/tool-tile/tool-tile.component';

@NgModule({
  declarations: [AdminToolsShellComponent, ToolTileComponent],
  imports: [CommonModule, AdminToolsShellRoutingModule, OldIconComponentModule],
})
export class AdminToolsShellModule {}
