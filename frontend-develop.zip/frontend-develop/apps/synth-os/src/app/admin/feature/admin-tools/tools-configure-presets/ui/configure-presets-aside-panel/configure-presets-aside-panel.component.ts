import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { Subject } from 'rxjs';
import { debounceTime, finalize, takeUntil } from 'rxjs/operators';

import { DefaultPaginationStrategy, PaginationStrategy, PAGINATION } from '@synth/utils/feature/pagination';

import { DEFAULT_LIMIT } from '../../../../../../core/constants/constants';
import { ICONS } from '../../../../../../core/constants/icon-list';
import { FacilitiesService } from '../../../../../../core/http-services/facilities.service';
import { IListResponse } from '../../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { FacilityGroupUsersActions } from '../../../../../../core/store/accounts/actions/facility-group/facility-group-tabs/facility-group-users.actions';
import { ToolsConfigurePresetsActions } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.actions';

@Component({
  selector: 'app-configure-presets-aside-panel',
  templateUrl: './configure-presets-aside-panel.component.html',
  styleUrls: ['./configure-presets-aside-panel.component.scss'],
  standalone: false,
})
export class ConfigurePresetsAsidePanelComponent implements OnInit, OnDestroy {
  @ViewChild('scrollContainer', { static: false }) scrollContainer: ElementRef;

  readonly ICONS = ICONS;

  facilityGroups: IFacilityGroup[] = [];
  isLoading = false;
  isScroll = false;
  pagination = { ...PAGINATION };
  selectedFG: IFacilityGroup;
  loadersArray = new Array(20);

  private limit = DEFAULT_LIMIT;
  private searchQuery = '';
  private search$$: Subject<void> = new Subject<void>();
  private unsubscribe$$: Subject<void> = new Subject<void>();
  private unsubFromPreviousRequest$$ = new Subject<void>();
  private paginationStrategy: PaginationStrategy = new DefaultPaginationStrategy();

  constructor(
    private router: Router,
    private facilitiesService: FacilitiesService,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.search$$.pipe(debounceTime(500), takeUntil(this.unsubscribe$$)).subscribe((_) => {
      this.facilityGroups = [];
      this.getFacilityGroups();
    });

    this.getFacilityGroups();
  }

  getFacilityGroups(): void {
    this.isLoading = true;
    this.unsubFromPreviousRequest$$.next();

    this.facilitiesService
      .getGroups({
        offset: this.pagination.offset,
        limit: this.limit,
        name: this.searchQuery,
      })
      .pipe(
        finalize(() => (this.isLoading = false)),
        takeUntil(this.unsubFromPreviousRequest$$)
      )
      .subscribe((res: IListResponse) => {
        this.facilityGroups = this.facilityGroups.concat(res.data);
        this.pagination.total = res.count;

        if (!this.selectedFG) {
          this.selectFacilityGroup(this.facilityGroups[0]);
        }

        if (this.scrollContainer) {
          const nativeEl = this.scrollContainer.nativeElement;

          // 54 - chat card height + chat card margin
          this.isScroll = this.facilityGroups.length * 54 > nativeEl.clientHeight;
        }
      });
  }

  back(): void {
    this.router.navigate(['/adminPanel/tools']);
  }

  search(text: string): void {
    this.searchQuery = text;
    this.search$$.next();
  }

  selectFacilityGroup(facilityGroup: IFacilityGroup): void {
    this.selectedFG = facilityGroup;
    this.store.dispatch(new ToolsConfigurePresetsActions.GetAdminConfigurePresets(this.selectedFG));
    this.store.dispatch(new FacilityGroupUsersActions.GetGroupUsers({ id: this.selectedFG.id }));
    this.store.dispatch(new ToolsConfigurePresetsActions.GetFacilityGroupRolesForPreset(this.selectedFG.id));
  }

  onInfinityScroll(): void {
    const newOffset = this.paginationStrategy.paginate(this.pagination, this.limit);

    if (newOffset !== null) {
      this.pagination.offset = newOffset;
      this.getFacilityGroups();
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
    this.unsubFromPreviousRequest$$.next();
    this.unsubFromPreviousRequest$$.complete();
  }
}
