import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { PERMISSIONS_ENDPOINTS } from '../../../../../../core/constants/endpoints';
import { UserPermissions } from '../../../../../../core/models/classes/userPermissions';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { IFilterMapValue } from '../../../../../../core/models/types/filter';
import { ProfileState } from '../../../../../../profile/data-access/state/profile/profile.state';
import { FILTERS_STORAGE_PAGES } from '../../../../../../shared/ui/modules/filters/constants/constants';
import { FiltersComponent } from '../../../../../../shared/ui/modules/filters/filters.component';
import { ToolsConfigurePresetsActions } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.actions';
import { ToolsConfigurePresetsState } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.state';
import { ConfigurePresetFormModalComponent } from '../configure-preset-form-modal/configure-preset-form-modal.component';

@Component({
  selector: 'app-configure-presets-header',
  templateUrl: './configure-presets-header.component.html',
  styleUrls: ['./configure-presets-header.component.scss'],
  standalone: false,
})
export class ConfigurePresetsHeaderComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly FILTERS_STORAGE_PAGES = FILTERS_STORAGE_PAGES;

  @ViewChild(FiltersComponent, { static: false }) filtersComp: FiltersComponent;

  readonly activeFacilityGroup$: Observable<IFacilityGroup> = this.store.select(
    ToolsConfigurePresetsState.activeFacilityGroup
  );
  readonly searchQuery$: Observable<string> = this.store.select(ToolsConfigurePresetsState.searchQuery);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  private selectedFilters = {};
  activeFacilityGroup: IFacilityGroup;
  searchQuery = '';
  canCreatePreset = false;

  private search$$: Subject<string> = new Subject();
  private unsubscribe$$ = new Subject<void>();

  constructor(
    private modalService: ModalsV2Service,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.activeFacilityGroup$.subscribe((activeFacilityGroup) => (this.activeFacilityGroup = activeFacilityGroup));
    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        (permissions: UserPermissions) =>
          (this.canCreatePreset = permissions.canCreate(PERMISSIONS_ENDPOINTS.adminToolsConfigurePresets))
      );

    this.search$$
      .pipe(debounceTime(500), distinctUntilChanged(), takeUntil(this.unsubscribe$$))
      .subscribe((query: string) => {
        this.searchQuery = query;
        this.store.dispatch(new ToolsConfigurePresetsActions.SearchPresets(query));
      });
  }

  ngAfterViewInit(): void {
    this.permissions$
      .pipe(
        filter((permissions) => !!permissions),
        switchMap((permissions) => this.filtersComp.init(permissions)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.updateSelectedFilters(this.filtersComp.currentFilters);
      });
  }

  updateSelectedFilters(selectedFilters: IFilterMapValue): void {
    this.selectedFilters = { ...selectedFilters };
    this.store.dispatch(new ToolsConfigurePresetsActions.UpdateFilters(this.selectedFilters));
  }

  searchPresets(query: string): void {
    this.search$$.next(query);
  }

  createPreset(): void {
    this.modalService.createModal(ConfigurePresetFormModalComponent);
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
