import { Component, ChangeDetectorRef, Inject } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { BannersPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { ModalsV2Service, ModalOverlayRef, modalAnimation, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { AdminService } from '../../../../../../../core/http-services/admin.service';
import { IItemResponse, IListParams } from '../../../../../../../core/models/types/common';
import { ConverterService } from '../../../../../../../core/services/converter.service';
import { FormService } from '../../../../../../../core/services/form.service';
import { AddBannerModal } from '../add-banner-modal.class';

@Component({
  selector: 'app-add-internal-banner',
  templateUrl: '../add-banner-modal.html',
  styleUrls: ['../add-banner-modal.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class AddInternalBannerComponent extends AddBannerModal {
  rolesParams: IListParams = {};
  disabledRolesSelect = false;

  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    protected formService: FormService,
    protected modalsService: ModalsV2Service,
    private fb: UntypedFormBuilder,
    protected adminService: AdminService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, formService, modalsService, adminService, actionComplete$);
  }

  protected createForm(): void {
    this.bannerForm = this.fb.group({
      facilityGroupIds: [this.banner?.facilityGroups.map((group) => group.id) || null, [CustomValidators.required]],
      facilityIds: [this.banner?.facilities.map((facility) => facility.id) || null],
      roleIds: [this.banner?.roles.map((role) => role.id) || null],
      duration: [
        this.banner ? ConverterService.secondsToMilliseconds(this.banner.duration) : this.DEFAULT_DURATION,
        [CustomValidators.required, CustomValidators.numbersOnly, Validators.max(this.MAX_DURATION)],
      ],
      content: [
        this.banner?.content || '',
        [
          CustomValidators.maxLengthWithoutHTML(BannersPatterns.content.maxLength),
          CustomValidators.patternInput(BannersPatterns.content.pattern),
          CustomValidators.required,
        ],
      ],
    });

    if (this.banner) {
      this.preparePreselectedOptions();
    }
  }

  createBanner(): void {
    this.isLoading = true;
    const body = {
      duration: ConverterService.millisecondsToSeconds(this.bannerForm.get('duration').value),
      facilityGroupIds: this.bannerForm.get('facilityGroupIds').value,
      type: this.bannerType.value,
      theme: this.bannerTheme.value,
      source: this.bannerLevel,
      content: this.bannerForm.get('content').value,
      facilityIds: this.bannerForm.get('facilityIds').value,
      roleIds: this.bannerForm.get('roleIds').value,
    };

    const request$: Observable<IItemResponse> = this.banner
      ? this.adminService.updateBanner(this.banner.id, body, { autoNotifyErrors: false })
      : this.adminService.createBanner(body, { autoNotifyErrors: false });

    request$.pipe(finalize(() => (this.isLoading = false))).subscribe(
      () => this.closeModal(true),
      (error) => this.modalsService.error(error.message)
    );
  }

  private preparePreselectedOptions(): void {
    this.bannerFacilities = this.banner.facilities.map((item) => {
      const option = { value: item.id, label: item.name };

      return option;
    });

    this.bannerGroups = this.banner.facilityGroups.map((item) => {
      const option = { value: item.id, label: item.name };

      return option;
    });

    this.bannerRoles = this.banner.roles.map((item) => {
      const option = { value: item.id, label: item.name };

      return option;
    });
  }
}
