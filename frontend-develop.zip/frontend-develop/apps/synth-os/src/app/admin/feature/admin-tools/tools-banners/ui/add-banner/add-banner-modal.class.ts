import { ChangeDetectorRef, Directive, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { ModalsV2Service, MODAL_ACTION_COMPLETE, ModalOverlayRef, ModalClass } from '@synth/ui/modals';

import { ICONS } from '../../../../../../core/constants/icon-list';
import { AdminService } from '../../../../../../core/http-services/admin.service';
import { IBanner, IBannerTheme, IBannerType } from '../../../../../../core/models/types/admin';
import { IOption } from '../../../../../../core/models/types/common';
import { FormService } from '../../../../../../core/services/form.service';
import {
  BANNERS_TOOL_TABS,
  BANNER_BLUE_THEME,
  BANNER_ISSUE_ALLERT_TYPE,
  BANNER_THEMES,
  BANNER_TYPES,
} from '../../../../../utils/constants';

@Directive()
// tslint:disable-next-line: directive-class-suffix
export abstract class AddBannerModal extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;
  readonly BANNERS_TOOL_TABS = BANNERS_TOOL_TABS;
  readonly bannerThemes = BANNER_THEMES;
  readonly bannerTypes = BANNER_TYPES;
  readonly DEFAULT_DURATION = 86400000;
  readonly MAX_DURATION = 604800000;

  protected unsubscribe$$: Subject<void> = new Subject<void>();

  protected abstract createForm(): void;

  bannerLevel: 'Internal' | 'System-Wide';
  bannerType = BANNER_ISSUE_ALLERT_TYPE;
  bannerTheme = BANNER_BLUE_THEME;
  textFieldStyles = { 'background-color': 'var(--main-blue-v2)', color: 'var(--white-v2)' };
  isLoading = false;
  bannerForm: UntypedFormGroup;
  banner: IBanner;
  bannerRoles: IOption[] = [];
  bannerFacilities: IOption[] = [];
  bannerGroups: IOption[] = [];

  protected constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    protected formService: FormService,
    protected modalsService: ModalsV2Service,
    protected adminService: AdminService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.bannerLevel = this.modalOverlayRef.data.bannerLevel;
    this.banner = this.modalOverlayRef.data.banner;
    this.createForm();

    if (this.banner) {
      this.bannerType = this.bannerTypes.find((bannerType) => bannerType.value === this.banner.type);
      this.bannerTheme = this.bannerThemes.find((bannerTheme) => bannerTheme.value === this.banner.theme);
      this.textFieldStyles = { 'background-color': this.bannerTheme.color, color: this.bannerTheme.textColor };
    }

    this.modalOverlayRef.backdropClick.pipe(takeUntil(this.unsubscribe$$)).subscribe(() => this.closeModal());
  }

  closeModal(reload: boolean = false): void {
    this.result.emit({ reload });
    this.modalOverlayRef.close();
  }

  selectBannerTheme(theme: IBannerTheme): void {
    this.bannerTheme = theme;
    this.textFieldStyles = { 'background-color': theme.color, color: theme.textColor };
  }

  selectBannerType(type: IBannerType): void {
    this.bannerType = type;
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
