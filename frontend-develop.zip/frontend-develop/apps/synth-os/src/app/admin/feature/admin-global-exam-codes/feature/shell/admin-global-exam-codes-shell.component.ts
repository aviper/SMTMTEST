import { Component, OnInit } from '@angular/core';

import { ITabMenuItem } from '../../../../../core/models/types/common';
import { TabMenuService } from '../../../../../core/services/tab-menu.service';

@Component({
  selector: 'app-global-exam-codes-shell',
  templateUrl: './admin-global-exam-codes-shell.component.html',
  styleUrls: ['./admin-global-exam-codes-shell.component.scss'],
  standalone: false,
})
export class AdminGlobalExamCodesShellComponent implements OnInit {
  cptTabs: ITabMenuItem[] = [];

  constructor(private tabMenuService: TabMenuService) {}

  ngOnInit(): void {
    this.getCptTabs();
  }

  private getCptTabs(): void {
    this.cptTabs = this.tabMenuService.getAdminExamCodesTabs();
  }
}
