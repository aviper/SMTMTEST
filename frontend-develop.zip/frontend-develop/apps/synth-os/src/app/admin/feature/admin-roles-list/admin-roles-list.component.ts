import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, skip, takeUntil } from 'rxjs/operators';

import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { PageSavingFeatureClass } from '../../../core/helpers/page-saving-feature.class';
import { UserPermissions } from '../../../core/models/classes/userPermissions';
import { IRole } from '../../../core/models/types/acl';
import { IHistoryState, ISort } from '../../../core/models/types/common';
import { RoutingService } from '../../../core/services/routing.service';
import { ProfileState } from '../../../profile/data-access/state/profile/profile.state';
import { AdminRolesListActions } from '../../data-access/state/roles/admin-roles-list/admin-roles-list.actions';
import { AdminRolesListState } from '../../data-access/state/roles/admin-roles-list/admin-roles-list.state';

@Component({
  selector: 'app-admin-roles-list',
  templateUrl: './admin-roles-list.component.html',
  styleUrls: ['./admin-roles-list.component.scss'],
  standalone: false,
})
export class AdminRolesListComponent extends PageSavingFeatureClass implements OnInit, OnDestroy {
  readonly roles$: Observable<{ roles: IRole[]; total: number; isLoading: boolean }> = this.store.select(
    AdminRolesListState.roles
  );
  readonly isLoading$: Observable<boolean> = this.store.select(AdminRolesListState.isLoading);
  readonly sort$: Observable<ISort> = this.store.select(AdminRolesListState.sort);
  readonly reload$: Observable<boolean> = this.store.select(AdminRolesListState.reload);
  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  data: IRole[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = true;

  permissions = new UserPermissions();

  protected historyStateForSaving: IHistoryState = {};
  private unsubscribe$$: Subject<void> = new Subject<void>();

  constructor(
    protected routingService: RoutingService,
    protected store: Store
  ) {
    super(routingService, store);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.roles$
      .pipe(
        skip(1),
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.roles;
        this.pagination.total = data.total;

        if (!this.wasLoadedDataFirstTime) {
          this.normalizePaginationAfterLoadData();
        }
        this.wasLoadedDataFirstTime = true;
      });

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => (this.permissions = permissions));

    this.isLoading$
      .pipe(skip(1), takeUntil(this.unsubscribe$$))
      .subscribe((isLoading: boolean) => (this.isLoading = isLoading));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort: ISort) => (this.sorting = sort));

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetHistoryState();
        this.store.dispatch(
          new AdminRolesListActions.GetRoles({
            limit: this.limit,
            offset: 0,
            query: this.searchQuery,
          })
        );
      });
  }

  sortRoles(sort: ISort): void {
    this.historyStateForSaving.sorting = sort;
    this.store.dispatch(new AdminRolesListActions.SortRoles(sort));
    this.resetHistoryState();
    this.store.dispatch(
      new AdminRolesListActions.GetRoles({
        limit: this.limit,
        offset: 0,
        query: this.searchQuery,
      })
    );
  }

  onInfinityScroll(offset: number): void {
    if (this.pagination.offset < this.pagination.total && this.data.length < this.pagination.total) {
      this.pagination.offset = offset;
      ++this.pagination.page;
      this.historyStateForSaving.page = this.pagination.page;
      this.store.dispatch(
        new AdminRolesListActions.GetRoles({
          offset: this.pagination.offset,
          limit: this.limit,
        })
      );
    }
  }

  onScroll(scroll: number): void {
    this.historyStateForSaving.scroll = scroll;
    this.scrolledDistance = 0;
  }

  private resetHistoryState(): void {
    this.data = [];
    this.pagination = { ...PAGINATION };

    if (this.wasLoadedDataFirstTime) {
      this.scrolledDistance = 0;
      this.historyStateForSaving.scroll = 0;
      this.historyStateForSaving.page = 1;
    }
  }

  reloadRoles(): void {
    this.store.dispatch(new AdminRolesListActions.RequestReload());
  }

  searchRoles(query: string): void {
    this.searchQuery = this.historyStateForSaving.query = query;
    this.reloadRoles();
  }

  ngOnDestroy(): void {
    this.store.dispatch(new AdminRolesListActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
