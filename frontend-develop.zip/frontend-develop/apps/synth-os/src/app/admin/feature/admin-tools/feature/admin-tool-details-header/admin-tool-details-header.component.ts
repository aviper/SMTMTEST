import { CommonModule } from '@angular/common';
import { Component, Input, NgModule } from '@angular/core';
import { Router } from '@angular/router';

import { ICONS } from '../../../../../core/constants/icon-list';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';

@Component({
  selector: 'app-admin-tool-details-header',
  templateUrl: './admin-tool-details-header.component.html',
  styleUrls: ['./admin-tool-details-header.component.scss'],
  standalone: false,
})
export class AdminToolDetailsHeaderComponent {
  readonly ICONS = ICONS;

  @Input() title: string;

  constructor(private router: Router) {}

  back(): void {
    this.router.navigate(['/adminPanel/tools']);
  }
}

@NgModule({
  declarations: [AdminToolDetailsHeaderComponent],
  exports: [AdminToolDetailsHeaderComponent],
  imports: [CommonModule, OldIconComponentModule],
})
export class AdminToolDetailsHeaderComponentModule {}
