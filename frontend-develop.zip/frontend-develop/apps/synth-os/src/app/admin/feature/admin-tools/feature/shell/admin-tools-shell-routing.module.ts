import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminToolsShellComponent } from './admin-tools-shell.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: AdminToolsShellComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminToolsShellRoutingModule {}
