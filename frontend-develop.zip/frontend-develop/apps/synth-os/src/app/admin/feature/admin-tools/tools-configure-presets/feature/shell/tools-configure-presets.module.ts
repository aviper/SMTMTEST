import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { ToolsConfigurePresetsComponent } from './tools-configure-presets.component';
import { OldInputComponent } from '../../../../../../shared/ui/components/controls/input/input.component';
import { SearchFieldComponent } from '../../../../../../shared/ui/components/controls/search-field/search-field.component';
import { FacilityGroupUsersSelectComponent } from '../../../../../../shared/ui/components/controls/selects/faciliy-group-users-select/facility-group-users-select.component';
import { RolesSelectComponent } from '../../../../../../shared/ui/components/controls/selects/roles-select/roles-select.component';
import { SelectComponent } from '../../../../../../shared/ui/components/controls/selects/select/select.component';
import { OldSwitcherComponent } from '../../../../../../shared/ui/components/controls/switcher/switcher.component';
import { OldIconComponentModule } from '../../../../../../shared/ui/components/icon/icon.component';
import { ControlErrorV2DirectiveModule } from '../../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { FiltersModule } from '../../../../../../shared/ui/modules/filters/filters.module';
import { FiltersGroupModule } from '../../../../../../shared/ui/modules/filters-group/filters-group.module';
import { LoaderModule } from '../../../../../../shared/ui/modules/loader/loader.module';
import { TableModule } from '../../../../../../shared/ui/modules/table/table.module';
import { RolesNameLabelPipeModule } from '../../../../../../shared/ui/pipes/roles-name-label.pipe';
import { UsersNameLabelPipeModule } from '../../../../../../shared/ui/pipes/users-name-label.pipe';
import { ConfigurePresetFormModalComponent } from '../../ui/configure-preset-form-modal/configure-preset-form-modal.component';
import { ConfigurePresetPreviewModalComponent } from '../../ui/configure-preset-preview-modal/configure-preset-preview-modal.component';
import { ConfigurePresetsAsidePanelComponent } from '../../ui/configure-presets-aside-panel/configure-presets-aside-panel.component';
import { ConfigurePresetsHeaderComponent } from '../../ui/configure-presets-header/configure-presets-header.component';
import { CanEditOrDeletePresetPipe } from '../../ui/configure-presets-table/can-edit-or-delete-preset.pipe';
import { ConfigurePresetsTableComponent } from '../../ui/configure-presets-table/configure-presets-table.component';

const routes: Routes = [
  {
    path: '',
    component: ToolsConfigurePresetsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class ToolsConfigurePresetsRoutingModule {}

@NgModule({
  declarations: [
    ToolsConfigurePresetsComponent,
    ConfigurePresetFormModalComponent,
    ConfigurePresetPreviewModalComponent,
    ConfigurePresetsAsidePanelComponent,
    ConfigurePresetsHeaderComponent,
    ConfigurePresetsTableComponent,
    CanEditOrDeletePresetPipe,
  ],
  imports: [
    CommonModule,
    ToolsConfigurePresetsRoutingModule,
    ReactiveFormsModule,
    OldIconComponentModule,
    RolesSelectComponent,
    FacilityGroupUsersSelectComponent,
    SelectComponent,
    FiltersGroupModule,
    ButtonsModule,
    LoaderModule,
    SearchFieldComponent,
    FiltersModule,
    TableModule,
    EllipsisTextModule,
    RolesNameLabelPipeModule,
    UsersNameLabelPipeModule,
    OldSwitcherComponent,
    OldInputComponent,
    InfiniteScrollModule,
    ControlErrorV2DirectiveModule,
  ],
})
export class ToolsConfigurePresetsModule {}
