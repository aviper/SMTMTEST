import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { ContractHoldersPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Observable, Subject } from 'rxjs';

import { ModalsV2Service, modalAnimation, ModalOverlayRef, ModalClass, MODAL_ACTION_COMPLETE } from '@synth/ui/modals';

import { ICONS } from '../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../core/helpers/custom-validators';
import { ContractHoldersService } from '../../../../../../core/http-services/contract-holders.service';
import { IHumanErrorBody } from '../../../../../../core/models/types/common';
import { IContractHolder } from '../../../../../../core/models/types/facility';
import { FormService } from '../../../../../../core/services/form.service';
import { Select } from '../../../../../../shared/ui/components/controls/selects/select.class';
import { InlineEditBlockV2Component } from '../../../../../../shared/ui/components/inline-edit-block-v2/inline-edit-block-v2.component';

@Component({
  selector: 'app-create-contract-holder',
  templateUrl: './create-contract-holder-modal.component.html',
  styleUrls: ['./create-contract-holder-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class CreateContractHolderModalComponent extends ModalClass implements OnInit, OnDestroy {
  readonly ICONS = ICONS;

  form: UntypedFormGroup;
  contractHolder: IContractHolder;
  action: string;

  private unsubscribe$$: Subject<void> = new Subject<void>();

  @ViewChild('regionSelect', { static: false }) regionSelect: Select;
  @ViewChild('cptCodeInlineEditBlock', { static: false }) cptCodeInlineEditBlock: InlineEditBlockV2Component;

  constructor(
    protected cdRef: ChangeDetectorRef,
    protected fb: UntypedFormBuilder,
    public overlayRef: ModalOverlayRef,
    private modalsService: ModalsV2Service,
    private contractHoldersService: ContractHoldersService,
    private formService: FormService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, overlayRef, actionComplete$);
  }

  ngOnInit(): void {
    this.contractHolder = this.overlayRef.data.holder;
    this.action = this.contractHolder ? 'Edit' : 'Add';
    this.createForm();
  }

  protected createForm(): void {
    this.form = this.fb.group({
      facilityGroupId: [this.contractHolder?.facilityGroup.id, [CustomValidators.required]],
      name: [
        this.contractHolder?.name,
        [
          CustomValidators.required,
          CustomValidators.patternInput(ContractHoldersPatterns.name.pattern),
          Validators.maxLength(ContractHoldersPatterns.name.maxLength),
        ],
      ],
    });
  }

  submit(): void {
    this.formService.submitForm();

    if (this.form.invalid) {
      this.modalsService.error('Fill up all required fields');

      return;
    }
    const request$ = this.contractHolder
      ? this.contractHoldersService.editHolder(this.contractHolder.id, this.form.value, { autoNotifyErrors: false })
      : this.contractHoldersService.createHolder(this.form.value, { autoNotifyErrors: false });

    request$.subscribe(
      (_) => {
        this.modalsService.success('Contact holder successfully created');
        this.closeModal(true);
      },
      (error: IHumanErrorBody) => this.modalsService.error(error.message)
    );
  }

  closeModal(reload: boolean = false): void {
    this.result.emit(reload);
    this.overlayRef.close();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
