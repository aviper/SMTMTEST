import { Component, Input } from '@angular/core';

import { BANNERS_TOOL_TABS } from '../../../../../../utils/constants';

@Component({
  selector: 'app-banners-table-header',
  templateUrl: './banners-table-header.component.html',
  styleUrls: ['./banners-table-header.component.scss'],
  standalone: false,
})
export class BannersTableHeaderComponent {
  readonly BANNERS_TOOL_TABS = BANNERS_TOOL_TABS;

  @Input() currentTab: string;
}
