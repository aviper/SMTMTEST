import { IModality } from '../../../../../core/models/types/dictionary';

export interface ComparisonRuleGroup {
  id: number;
  facilityId: number;
  facilityGroupId: number;
  type: 'custom' | 'default'; // I believe this should be moved into 'rules' prop
  dcmModalityId: number;
  modality: IModality;
  rules: ComparisonRule[];
}

export interface ComparisonRule {
  priorModality: string;
  priorModalityId: number;
  includesRegions: string[];
  excludesRegions: string[];
  includesModalities: string[];
  excludesModalities: string[];
  numberOfExams: number;
  includeOldest: boolean;
  edited?: boolean;
}
