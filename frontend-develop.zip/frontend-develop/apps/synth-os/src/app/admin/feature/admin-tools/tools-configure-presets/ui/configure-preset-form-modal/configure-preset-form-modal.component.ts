import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { UsersFilterPresetsPatterns } from '@idgital/idgital-validator/dist/src/validationRulesInfo';
import { Store } from '@ngxs/store';
import { interval, Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { MODAL_ACTION_COMPLETE, ModalClass, ModalOverlayRef, modalAnimation } from '@synth/ui/modals';

import { ICONS } from '../../../../../../core/constants/icon-list';
import { CustomValidators } from '../../../../../../core/helpers/custom-validators';
import { OrdersService } from '../../../../../../core/http-services/orders.service';
import { IOption } from '../../../../../../core/models/types/common';
import { IFacilityGroup } from '../../../../../../core/models/types/facility';
import { IPreset } from '../../../../../../core/models/types/filter';
import { FiltersV2Service } from '../../../../../../shared/ui/modules/filters/services/filters-v2.service';
import { ToolsConfigurePresetsActions } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.actions';
import { ToolsConfigurePresetsState } from '../../../../../data-access/state/tools/tools-configure-presets/tools-configure-presets.state';
import { ORDER_STATUS_OPTIONS } from '../../../../../utils/constants';

@Component({
  selector: 'app-configure-preset-form-modal',
  templateUrl: './configure-preset-form-modal.component.html',
  styleUrls: ['./configure-preset-form-modal.component.scss'],
  animations: [modalAnimation],
  standalone: false,
})
export class ConfigurePresetFormModalComponent extends ModalClass implements OnInit, OnDestroy {
  readonly activeFacilityGroup$: Observable<IFacilityGroup> = this.store.select(
    ToolsConfigurePresetsState.activeFacilityGroup
  );

  readonly ICONS = ICONS;

  preset: IPreset = null;
  isLoading = false;
  form: UntypedFormGroup;
  filterServices: { service: FiltersV2Service; isCollapsed: boolean; data: any; counter: number }[] = [];
  filterPage = '';
  activeFacilityGroup: IFacilityGroup;
  isFiltersValid = false;
  selectedRolesLabel = '';
  selectedUsersLabel = '';
  selectedRolesAliases: string[] = [];

  readonly ENABLE_TIME_OPTIONS: boolean = true;

  private unsubscribe$$: Subject<void> = new Subject<void>();
  private orderStatusSearchQuery = '';

  get orderStatusOptions(): IOption[] {
    return ORDER_STATUS_OPTIONS.filter((option) =>
      option.label.toLocaleLowerCase().includes(this.orderStatusSearchQuery)
    );
  }

  constructor(
    public overlayRef: ModalOverlayRef,
    protected _cdRef: ChangeDetectorRef,
    private fb: UntypedFormBuilder,
    private ordersService: OrdersService,
    private store: Store,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(_cdRef, overlayRef, actionComplete$);
    this.preset = overlayRef.data.preset || null;
    this.selectedRolesLabel = this.preset?.roles?.map((role) => role.name).join(', ') || '';
    this.selectedUsersLabel = this.preset?.users?.map((user) => `${user.firstName} ${user.lastName}`).join(', ') || '';
  }

  ngOnInit(): void {
    this.activeFacilityGroup$.subscribe((activeFacilityGroup) => (this.activeFacilityGroup = activeFacilityGroup));

    this.form = this.fb.group({
      name: [
        this.preset?.name || '',
        [
          CustomValidators.required,
          CustomValidators.patternInput(UsersFilterPresetsPatterns.name.pattern),
          Validators.minLength(UsersFilterPresetsPatterns.name.minLength),
          Validators.maxLength(UsersFilterPresetsPatterns.name.maxLength),
        ],
      ],
      roleIds: [this.preset?.roleIds || []],
      userIds: [this.preset?.userIds || []],
      page: [this.preset?.page || '', CustomValidators.required],
    });

    if (!!this.preset) {
      this.filterPage = this.preset.page;
      this.ordersService.getUsersFiltersPresetInfoById(this.preset.id).subscribe((res) => {
        this.filterServices = res.data.filterGroups.map((filter, index) => ({
          service: null,
          isCollapsed: index !== 0,
          data: filter,
        }));
      });
      this.selectedRolesAliases = [...new Set(this.preset.roles.map((role) => role.alias))];
    } else {
      this.filterServices = [{ service: null, isCollapsed: false, data: null, counter: 0 }];
    }

    this.form
      .get('page')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((it) => {
        this.resetFilters();
        this.filterPage = it;
      });

    this.form
      .get('roleIds')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((_) => {
        this.selectedRolesLabel = '';
        this.resetSelectedUser();
      });

    this.form
      .get('userIds')
      .valueChanges.pipe(takeUntil(this.unsubscribe$$))
      .subscribe((_) => {
        this.selectedUsersLabel = '';
      });

    interval(500)
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.isFiltersChosen());
  }

  isFiltersChosen(): void {
    this.isFiltersValid =
      !!this.filterServices.length &&
      this.filterServices.every((filter) => {
        const filters = filter.service?.getFilters();

        return !!filters && Object.keys(filters).some((filterKey) => !!filters[filterKey]);
      });
  }

  closeModal(data?: any): void {
    this.overlayRef.close();
  }

  createPreset(): void {
    this.store
      .dispatch(
        new ToolsConfigurePresetsActions.CreatePreset({
          ...this.form.value,
          facilityGroupId: this.activeFacilityGroup.id,
          filterGroups: this.filterServices.map((filter, index) => ({
            name: `Filter ${index + 1}`,
            sort: index,
            value: filter.service.getFiltersConfig(),
          })),
        })
      )
      .subscribe(() => {
        this.closeModal();
      });
  }

  updatePreset(): void {
    this.store
      .dispatch(
        new ToolsConfigurePresetsActions.UpdatePreset(this.preset.id, {
          ...this.form.value,
          filterGroups: this.filterServices.map((filter, index) => ({
            name: `Filter ${index + 1}`,
            sort: index,
            value: filter.service.getFiltersConfig(),
          })),
        })
      )
      .subscribe(() => {
        this.closeModal();
      });
  }

  addFilter(): void {
    this.filterServices.forEach((filter) => (filter.isCollapsed = true));
    this.filterServices.push({ service: null, isCollapsed: false, data: null, counter: 0 });
  }

  deleteFilter(filterId: number): void {
    this.filterServices.splice(filterId, 1);
  }

  collapseAction(action: { filter: { service: FiltersV2Service; isCollapsed: boolean }; status: boolean }): void {
    this.filterServices.forEach((filter) => {
      if (!action.status) {
        filter === action.filter ? (filter.isCollapsed = action.status) : (filter.isCollapsed = true);
      }
    });
  }

  resetFilters(): void {
    this.filterServices = [];
    this.filterServices.push({ service: null, isCollapsed: false, data: null, counter: 0 });
  }

  resetSelectedUser(): void {
    this.form.get('userIds').patchValue([]);
  }

  setOrderStatusSearchQuery(query: string): void {
    this.orderStatusSearchQuery = query.toLocaleLowerCase();
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }

  roleMultiSelectionAction(selections: { label: string }[]): void {
    this.selectedRolesAliases = [...new Set(selections.map((selection) => selection.label))];
  }
}
