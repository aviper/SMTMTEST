import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';

import { PERMISSIONS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { ICONS } from '../../../../../core/constants/icon-list';
import { IPermissionsConfig, PermissionsClass } from '../../../../../core/helpers/permissions.class';
import { UserPermissions } from '../../../../../core/models/classes/userPermissions';
import { ProfileState } from '../../../../../profile/data-access/state/profile/profile.state';
import { AdminToolsCheckingService } from '../../../../data-access/admin-tools.service';

@Component({
  selector: 'app-admin-tools-shell',
  templateUrl: './admin-tools-shell.component.html',
  styleUrls: ['./admin-tools-shell.component.scss'],
  standalone: false,
})
export class AdminToolsShellComponent implements OnInit, OnDestroy {
  private readonly store: Store = inject(Store);

  readonly ICONS = ICONS;
  readonly PERMISSIONS_ENDPOINTS = PERMISSIONS_ENDPOINTS;

  canReadBlockUpload = false;
  canReadBlockRemove = false;
  canReadBlockOther = false;

  adminToolsPermissions: IPermissionsConfig = {
    canRead: {
      [PERMISSIONS_ENDPOINTS.uploadDicoms]: false,
      [PERMISSIONS_ENDPOINTS.uploadH7]: false,
      [PERMISSIONS_ENDPOINTS.uploadMobileApp]: false,
      [PERMISSIONS_ENDPOINTS.removeFacilities]: false,
      [PERMISSIONS_ENDPOINTS.removeOrder]: false,
      [PERMISSIONS_ENDPOINTS.ordersDlq]: false,
      [PERMISSIONS_ENDPOINTS.searchStudy]: false,
      [PERMISSIONS_ENDPOINTS.generateDicom]: false,
      [PERMISSIONS_ENDPOINTS.contractHolder]: false,
      [PERMISSIONS_ENDPOINTS.banners]: false,
      [PERMISSIONS_ENDPOINTS.servicesManagement]: false,
      [PERMISSIONS_ENDPOINTS.comparisonRules]: false,
      [PERMISSIONS_ENDPOINTS.adminToolsConfigurePresets]: false,
      [PERMISSIONS_ENDPOINTS.dropReadingUsers]: false,
      [PERMISSIONS_ENDPOINTS.vocabularyEditor]: false,
      [PERMISSIONS_ENDPOINTS.playbookManagement]: false,
    },
    canEdit: {
      [PERMISSIONS_ENDPOINTS.toolsUnlockExams]: true,
    },
  };

  private unsubscribe$$ = new Subject<void>();

  readonly permissions$: Observable<UserPermissions> = this.store.select(ProfileState.permissions);

  constructor(
    public adminToolsService: AdminToolsCheckingService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((permissions: UserPermissions) => {
        this.canReadBlockUpload = this.adminToolsService.canReadBlockUpload(permissions);
        this.canReadBlockRemove = this.adminToolsService.canReadBlockRemove(permissions);
        this.canReadBlockOther = this.adminToolsService.canReadBlockOther(permissions);

        this.adminToolsPermissions = PermissionsClass.updatePermissions(permissions, this.adminToolsPermissions);
      });

    this.permissions$
      .pipe(
        filter((permissions: UserPermissions) => !!permissions && !!permissions.userId),
        takeUntil(this.unsubscribe$$),
        take(1)
      )
      .subscribe((permissions: UserPermissions) => {
        const currentEndpoint = this.route.snapshot.data?.tab;

        if (!permissions.canRead(currentEndpoint)) {
          this.router.navigateByUrl('adminPanel/users');

          return;
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
