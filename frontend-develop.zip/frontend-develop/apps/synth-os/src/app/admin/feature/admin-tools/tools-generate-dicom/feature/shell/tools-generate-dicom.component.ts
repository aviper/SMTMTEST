import { Component, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, finalize, map, switchMap, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';

import { CustomValidators } from '../../../../../../core/helpers/custom-validators';
import { AdminService } from '../../../../../../core/http-services/admin.service';
import { PatientsService } from '../../../../../../core/http-services/patients.service';
import { ITabMenuItem } from '../../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../../core/models/types/dictionary';
import { TabMenuService } from '../../../../../../core/services/tab-menu.service';
import { CptPopupV2Component } from '../../../../../../shared/ui/modules/select-cpt/components/cpt-popup-v2/cpt-popup-v2.component';
import { AdminToolsClass } from '../../../../../utils/admin-tools.class';
import { DICOM_GENERATOR_SOURCE_TYPES } from '../../../../../utils/constants';
import { DcmParser } from '../../../../../utils/dcm-parser';
import { AddToOrderComponent } from '../../ui/add-to-order/add-to-order.component';
import {
  AdminCreateNewOrderComponent,
  NewOrderBucketData,
} from '../../ui/admin-create-new-order/admin-create-new-order.component';

@Component({
  selector: 'app-tools-generate-dicom-generator',
  templateUrl: './tools-generate-dicom.component.html',
  styleUrls: ['./tools-generate-dicom.component.scss'],
  standalone: false,
})
export class ToolsGenerateDicomComponent extends AdminToolsClass implements OnInit, OnDestroy {
  isWorkWithOwnDCM = false;
  isDCMGenerating = false;
  isDCMLoading = false;
  uploadedDCMFile: string;
  uploadedDCMTags = {};
  generationDCMForm: UntypedFormGroup;
  orderIdControl: UntypedFormControl;
  tabMenu: ITabMenuItem[] = [];
  useDicomFile: string;
  isPatientModalOpen = false;
  selectedCpt: ICTPCode;
  filesToUpload: File[] = [];

  readonly DICOM_GENERATOR_SOURCE_TYPES = DICOM_GENERATOR_SOURCE_TYPES;

  constructor(
    private modalsService: ModalsV2Service,
    private fb: UntypedFormBuilder,
    private tabMenuService: TabMenuService,
    private adminService: AdminService,
    private patientService: PatientsService,
    protected route: ActivatedRoute,
    protected router: Router
  ) {
    super(route, router);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.createForm();
    this.getTabMenu();
  }

  private getTabMenu(): void {
    this.tabMenu = this.tabMenuService.getGenerateDicomTabMenu();
    this.useDicomFile = this.tabMenu[0].value;
  }

  private createForm(): void {
    this.orderIdControl = new UntypedFormControl(null, CustomValidators.required);
    this.generationDCMForm = this.fb.group({
      dicomSource: null,
      seriesLength: [1, CustomValidators.required],
      facilityId: [null],
      physicianId: null,
      cptCodeId: null,
      modalityId: null,
      dosDate: [null, [CustomValidators.validDate]],
      dosTime: null,
      reason: null,
      patientId: null,
    });
  }

  private fileToString(file: File): Observable<string> {
    return new Observable((subscriber) => {
      const reader = new FileReader();

      reader.readAsBinaryString(file);

      reader.onload = () => {
        subscriber.next(reader.result.toString());
        subscriber.complete();
      };

      reader.onerror = (error) => {
        subscriber.error(error);
        subscriber.complete();
      };
    });
  }

  toggleModal(): void {
    this.isPatientModalOpen = !this.isPatientModalOpen;
  }

  openCptPopup(event: Event): void {
    event.stopPropagation();
    (event.target as HTMLInputElement).blur();

    this.modalsService
      .open(CptPopupV2Component, {
        data: {
          modalityId: this.generationDCMForm.value.modalityId,
        },
      })
      .subscribe((cpt: ICTPCode) => {
        if (cpt) {
          this.generationDCMForm.get('cptCodeId').setValue(cpt.id);
          this.selectedCpt = cpt;
        }
      });
  }

  resetPatientControlError(): void {
    this.generationDCMForm.get('patientId').setErrors({ notFound: null });
    this.generationDCMForm.get('patientId').updateValueAndValidity();
  }

  checkIfPatientExist(): void {
    const patientId = this.generationDCMForm.get('patientId').value;

    if (!patientId) {
      this.resetPatientControlError();

      return;
    }

    this.patientService.getPatientById(patientId).subscribe(
      () => this.resetPatientControlError(),
      () => {
        this.modalsService.error(`Patient with ID ${patientId} not found`);
        this.generationDCMForm.get('patientId').setErrors({ notFound: 'patient with this id not found' });
      }
    );
  }

  deleteDCMFile(fileForRemove: File): void {
    this.filesToUpload = this.filesToUpload.filter((file) => file !== fileForRemove);
  }

  addToOrder(event: Event, type: string): void {
    if (this.generationDCMForm.invalid) {
      this.modalsService.error('Fill up all required fields');

      return;
    }

    event.stopPropagation();
    (event.target as HTMLInputElement).blur();

    this.modalsService
      .open(AddToOrderComponent)
      .pipe(takeUntil(this.unsubscribe$$))
      .pipe(
        switchMap(({ orderId }: { orderId: string }) =>
          this.adminService.uploadDCMToOrder(
            orderId,
            type,
            {
              ...this.generationDCMForm.value,
            },
            { autoNotifyErrors: false }
          )
        )
      )
      .pipe(finalize(() => (this.isDCMGenerating = false)))
      .subscribe(
        () => this.modalsService.success('New resource added to exam'),
        (error) => this.modalsService.error(error.message)
      );
  }

  createNewOrder(event: Event): void {
    if (this.generationDCMForm.invalid) {
      this.modalsService.error('Fill up all required fields');

      return;
    }

    event.stopPropagation();
    (event.target as HTMLInputElement).blur();

    this.modalsService
      .open(AdminCreateNewOrderComponent)
      .pipe(
        switchMap((orderData: NewOrderBucketData) =>
          this.adminService.generateDCMWithOrder(
            {
              ...orderData,
              ...this.generationDCMForm.value,
            },
            { autoNotifyErrors: false }
          )
        ),
        finalize(() => (this.isDCMGenerating = false)),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(
        () => this.modalsService.success('New exam with DCM successfully created'),
        (error) => this.modalsService.error(error.message)
      );
  }

  generateDcm(event: Event): void {
    if (this.generationDCMForm.invalid) {
      this.modalsService.error('Fill up all required fields');

      return;
    }

    event.stopPropagation();
    (event.target as HTMLInputElement).blur();

    const values = this.generationDCMForm.value;

    this.isDCMGenerating = true;
    this.adminService
      .generateDCM(
        {
          dicomSource: this.isWorkWithOwnDCM ? this.uploadedDCMFile : null,
          ...values,
        },
        { autoNotifyErrors: false }
      )
      .pipe(finalize(() => (this.isDCMGenerating = false)))
      .subscribe(
        (res: string) => this.readerDownloadedFile(res),
        (error) => this.modalsService.error(error.message)
      );
  }

  private readerDownloadedFile(res: string): void {
    const reader = new FileReader();
    const blob = DcmParser.getBlobObjectFromBinaryString(res);

    reader.onloadend = () => this.downloadGeneratedDicom(reader.result as string);
    reader.readAsDataURL(blob);
  }

  setDicomSourceType(val: string): void {
    this.useDicomFile = val;
    const formField = this.generationDCMForm.get('dicomSource');

    formField.setValidators(val === this.DICOM_GENERATOR_SOURCE_TYPES.none ? null : CustomValidators.required);
    formField.patchValue(null);
  }

  private downloadGeneratedDicom(href: string): void {
    const link = document.createElement('a');

    link.href = href;
    link.download = 'generatedDicoms.zip';
    link.click();
  }

  addDCMFile(files: File[]): void {
    if (!files || !files.length) {
      this.modalsService.error('No file to upload');

      return;
    }

    this.filesToUpload = files;

    this.fileToString(files[0])
      .pipe(
        switchMap((file: string) =>
          this.adminService
            .parseDCM({ dicomSource: file })
            .pipe(filter((res) => !!res))
            .pipe(
              map((res) => ({
                dcmFile: file,
                tags: DcmParser.getDCMTagsForDisplaying(res.data.entries),
              }))
            )
        )
      )
      .subscribe((res) => {
        this.isWorkWithOwnDCM = true;
        this.uploadedDCMFile = res.dcmFile;
        this.uploadedDCMTags = res.tags;
        this.generationDCMForm.get('dicomSource').patchValue(this.uploadedDCMFile);
        this.generationDCMForm.get('dosDate').patchValue(this.uploadedDCMTags['dosDate']);
        this.generationDCMForm.get('dosTime').patchValue(this.uploadedDCMTags['dosTime']);
        this.generationDCMForm.get('reason').patchValue(this.uploadedDCMTags['reason']);
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
