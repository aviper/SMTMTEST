import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { filter, skip, takeUntil } from 'rxjs/operators';

import { ModalsV2Service } from '@synth/ui/modals';
import { IPagination, PAGINATION } from '@synth/utils/feature/pagination';

import { TABLE_TYPE } from '../../../../../core/constants/table-constants';
import { PageSavingFeatureClass } from '../../../../../core/helpers/page-saving-feature.class';
import { TableSettingsService } from '../../../../../core/http-services/table-settings.service';
import { IHistoryState, IListResponse, ISort } from '../../../../../core/models/types/common';
import { ICTPCode } from '../../../../../core/models/types/dictionary';
import { ITableSetting } from '../../../../../core/models/types/tables';
import { RoutingService } from '../../../../../core/services/routing.service';
import { EditCptCodeComponent } from '../../../../../shared/ui/modules/cpt-codes/cpt-code-modals/edit-cpt-code/edit-cpt-code';
import { AdminGlobalExamCodesListActions } from '../../../../data-access/state/global-exam-codes/admin-global-exam-codes-list/admin-global-exam-codes-list.actions';
import { AdminGlobalExamCodesListState } from '../../../../data-access/state/global-exam-codes/admin-global-exam-codes-list/admin-global-exam-codes-list.state';

@Component({
  selector: 'app-admin-global-exam-codes-list',
  templateUrl: './admin-global-exam-codes-list.component.html',
  styleUrls: ['./admin-global-exam-codes-list.component.scss'],
  standalone: false,
})
export class AdminGlobalExamCodesListComponent extends PageSavingFeatureClass implements OnInit, OnDestroy {
  readonly cptCodes$: Observable<{ cptCodes: ICTPCode[]; lastChunkSize: number; isLoading: boolean }> =
    this.store.select(AdminGlobalExamCodesListState.cptCodes);
  readonly isLoading$: Observable<boolean> = this.store.select(AdminGlobalExamCodesListState.isLoading);
  readonly showExpiredExamCode$: Observable<boolean> = this.store.select(
    AdminGlobalExamCodesListState.showExpiredExamCode
  );
  readonly sort$: Observable<ISort> = this.store.select(AdminGlobalExamCodesListState.sort);
  readonly reload$: Observable<boolean> = this.store.select(AdminGlobalExamCodesListState.reload);

  tableSettings: ITableSetting[] = [];
  showExpiredExamCode = false;
  readonly TABLE_TYPE = TABLE_TYPE.cptCodes;

  constructor(
    protected routingService: RoutingService,
    protected store: Store,
    private modalsService: ModalsV2Service,
    private tableSettingsService: TableSettingsService
  ) {
    super(routingService, store);
  }

  data: ICTPCode[] = [];
  pagination: IPagination = { ...PAGINATION };
  isLoading = true;

  protected historyStateForSaving: IHistoryState = {};
  private unsubscribe$$: Subject<void> = new Subject<void>();

  ngOnInit(): void {
    super.ngOnInit();

    this.cptCodes$
      .pipe(
        skip(1),
        filter((data) => !data.isLoading),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe((data) => {
        this.data = data.cptCodes;
        this.pagination.lastChunkSize = data.lastChunkSize;

        if (!this.wasLoadedDataFirstTime) {
          this.normalizePaginationAfterLoadData();
        }
        this.wasLoadedDataFirstTime = true;
      });

    this.showExpiredExamCode$
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((showExpiredExamCode) => (this.showExpiredExamCode = showExpiredExamCode));

    this.isLoading$
      .pipe(skip(1), takeUntil(this.unsubscribe$$))
      .subscribe((isLoading: boolean) => (this.isLoading = isLoading));

    this.sort$.pipe(takeUntil(this.unsubscribe$$)).subscribe((sort: ISort) => (this.sorting = sort));

    this.reload$
      .pipe(
        filter((shouldReload) => !!shouldReload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => {
        this.resetHistoryState();
        this.store.dispatch(
          new AdminGlobalExamCodesListActions.GetCptCodes({
            limit: this.limit,
            offset: 0,
          })
        );
      });
    this.loadTableSettings();
  }

  updateExpiredExamCodeStatus(status: boolean): void {
    this.store.dispatch(new AdminGlobalExamCodesListActions.UpdateShowExpiredExamCodeStatus(status));
  }

  sortCptCodes(sort: ISort): void {
    this.historyStateForSaving.sorting = sort;
    this.store.dispatch(new AdminGlobalExamCodesListActions.SortCptCodes(sort));
    this.resetHistoryState();
    this.store.dispatch(
      new AdminGlobalExamCodesListActions.GetCptCodes({
        limit: this.limit,
        offset: 0,
      })
    );
  }

  onInfinityScroll(offset: number): void {
    this.pagination.offset = offset;
    ++this.pagination.page;
    this.historyStateForSaving.page = this.pagination.page;
    this.store.dispatch(
      new AdminGlobalExamCodesListActions.GetCptCodes({
        offset,
        limit: this.limit,
      })
    );
  }

  onScroll(scroll: number): void {
    this.historyStateForSaving.scroll = scroll;
    this.scrolledDistance = 0;
  }

  changeCptModality(data: { modalityId: number; cptCode: ICTPCode }): void {
    this.store
      .dispatch(new AdminGlobalExamCodesListActions.UpdateCptModality(data))
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.store.dispatch(new AdminGlobalExamCodesListActions.RequestReload()));
  }

  editCptCode(cptCode: ICTPCode): void {
    this.modalsService
      .open(EditCptCodeComponent, { listenBackdrop: false, data: { cptCode: cptCode } })
      .pipe(
        filter((reload) => !!reload),
        takeUntil(this.unsubscribe$$)
      )
      .subscribe(() => this.store.dispatch(new AdminGlobalExamCodesListActions.RequestReload()));
  }

  deleteDefaultFindings(cptCode: ICTPCode): void {
    this.store.dispatch(new AdminGlobalExamCodesListActions.DeleteCptDefaultFindings(cptCode));
  }

  onSearch(query: string): void {
    this.historyStateForSaving.query = query;
    this.searchQuery = query;
    this.store.dispatch(new AdminGlobalExamCodesListActions.SearchCptCodes(query));
  }

  protected initPageMetaData(): void {
    super.initPageMetaData();
    this.store.dispatch(new AdminGlobalExamCodesListActions.SortCptCodes(this.sorting));
  }

  private resetHistoryState(): void {
    this.data = [];
    this.pagination = { ...PAGINATION };

    if (this.wasLoadedDataFirstTime) {
      this.scrolledDistance = 0;
      this.historyStateForSaving.scroll = 0;
      this.historyStateForSaving.page = 1;
    }
  }

  private loadTableSettings(): void {
    this.tableSettingsService.getSettings(this.TABLE_TYPE).subscribe((res: IListResponse) => {
      this.tableSettings = res.data;
    });
  }

  ngOnDestroy(): void {
    this.store.dispatch(new AdminGlobalExamCodesListActions.ClearData());
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
