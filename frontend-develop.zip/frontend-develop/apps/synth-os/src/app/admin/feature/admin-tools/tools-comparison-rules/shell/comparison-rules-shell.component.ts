import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { combineLatest, EMPTY, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { IFacilityWithDefaultPriorRelevancyRule } from '@synth/api';

import { PERMISSIONS_ENDPOINTS } from '../../../../../core/constants/endpoints';
import { IFacilityGroup } from '../../../../../core/models/types/facility';
import { ComparisonRulesActions } from '../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.actions';
import { ComparisonRulesState } from '../../../../data-access/state/tools/tools-comparison-rules/tools-comparison-rules.state';
import { AdminToolsClass } from '../../../../utils/admin-tools.class';

@Component({
  selector: 'synth-prior-relevancy-shell',
  templateUrl: './comparison-rules-shell.component.html',
  styleUrls: ['./comparison-rules-shell.component.scss'],
  standalone: false,
})
export class ComparisonRulesShellComponent extends AdminToolsClass implements OnDestroy, OnInit {
  readonly facility$: Observable<IFacilityWithDefaultPriorRelevancyRule> = this.store.select(
    ComparisonRulesState.facility
  );
  readonly group$: Observable<IFacilityGroup> = this.store.select(ComparisonRulesState.facilityGroup);

  view$: Observable<'empty' | 'facility' | 'default'> = EMPTY;

  constructor(
    protected route: ActivatedRoute,
    protected router: Router,
    private store: Store
  ) {
    super(route, router);
  }

  ngOnInit() {
    super.ngOnInit();

    this.view$ = combineLatest([this.permissions$, this.facility$, this.group$]).pipe(
      filter(([p]) => !!p),
      map(([permissions, facility, group]) => {
        const canSeeDefault = permissions.canRead(PERMISSIONS_ENDPOINTS.defaultComparisonRules);

        if (canSeeDefault) {
          if (facility && group) {
            return 'facility';
          }

          if (!facility && group) {
            return 'empty';
          }

          return 'default';
        }

        if (!facility && !group) {
          return 'empty';
        }

        if (group && !facility) {
          return 'empty';
        }

        return 'facility';
      })
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new ComparisonRulesActions.ClearState());
  }
}
