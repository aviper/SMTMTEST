import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterModule, Routes } from '@angular/router';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import {
  IconComponent,
  ButtonComponent,
  IconWithAreaComponent,
  IconButtonComponent,
  PlaceholderCheckboxComponent,
  PlaceholderRadioGroupComponent,
  SwitcherComponent,
} from '@synth/ui';
import { CheckboxComponent } from '@synth/ui';

import { ComparisonRulesShellComponent } from './comparison-rules-shell.component';
import { NumberInputComponent } from '../../../../../shared/ui/components/controls/number-input/number-input.component';
import { SearchFieldComponent } from '../../../../../shared/ui/components/controls/search-field/search-field.component';
import { FacilitySelectV2Component } from '../../../../../shared/ui/components/controls/selects/facility-select-v2/facility-select-v2.component';
import { SynthModalitySelectComponent } from '../../../../../shared/ui/components/controls/selects/modality-select/modality-select.component';
import { ModalitySelectV2Component } from '../../../../../shared/ui/components/controls/selects/modality-select-v2/modality-select-v2.component';
import { SynthRegionSelectComponent } from '../../../../../shared/ui/components/controls/selects/region-select/region-select.component';
import { RegionSelectV2Component } from '../../../../../shared/ui/components/controls/selects/region-select-v2/region-select-v2.component';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';
import { StaticMenuItemComponent } from '../../../../../shared/ui/components/static-menu/static-menu-item/static-menu-item.component';
import { StaticMenuComponent } from '../../../../../shared/ui/components/static-menu/static-menu.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ContextualMenuDirectiveModule } from '../../../../../shared/ui/directives/contextual-menu.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';
import { EllipsisTextModule } from '../../../../../shared/ui/modules/ellipsis-text/ellipsis-text.module';
import { LoaderModule } from '../../../../../shared/ui/modules/loader/loader.module';
import { TableModule } from '../../../../../shared/ui/modules/table/table.module';
import { ComparisonRulesAsideComponent } from '../ui/comparison-rules-aside/comparison-rules-aside.component';
import { ComparisonRuleSubRowComponent } from '../ui/comparison-rules-table/comparison-rule-sub-row/comparison-rule-sub-row.component';
import { ComparisonRulesTableRowComponent } from '../ui/comparison-rules-table/comparison-rules-table-row/comparison-rules-table-row.component';
import { ComparisonRulesTableComponent } from '../ui/comparison-rules-table/comparison-rules-table.component';
import { CreateRuleSubRowComponent } from '../ui/comparison-rules-table/create-rule-sub-row/create-rule-sub-row.component';
import { FacilityComparisonRulesComponent } from '../ui/facility-comparison-rules/facility-comparison-rules.component';
import { SynthesisDefaultComponent } from '../ui/synthesis-default/synthesis-default.component';

const routes: Routes = [
  {
    path: '',
    component: ComparisonRulesShellComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
class ComparisonRulesRoutingModule {}

@NgModule({
  declarations: [
    ComparisonRulesShellComponent,
    ComparisonRulesAsideComponent,
    SynthesisDefaultComponent,
    FacilityComparisonRulesComponent,
    ComparisonRulesTableComponent,
    ComparisonRulesTableRowComponent,
    ComparisonRuleSubRowComponent,
    CreateRuleSubRowComponent,
  ],
  imports: [
    CommonModule,
    TableModule,
    ButtonsModule,
    SwitcherComponent,
    OldIconComponentModule,
    SearchFieldComponent,
    EllipsisTextModule,
    CheckboxComponent,
    FacilitySelectV2Component,
    LoaderModule,
    ModalitySelectV2Component,
    RegionSelectV2Component,
    ReactiveFormsModule,
    ComparisonRulesRoutingModule,
    InfiniteScrollModule,
    MatTooltipModule,
    ContextualMenuDirectiveModule,
    CdkScrollableExtendedDirectiveModule,
    ControlErrorV2DirectiveModule,
    IconComponent,
    StaticMenuComponent,
    StaticMenuItemComponent,
    ButtonComponent,
    CheckboxComponent,
    NumberInputComponent,
    SynthModalitySelectComponent,
    SynthRegionSelectComponent,
    IconWithAreaComponent,
    PlaceholderRadioGroupComponent,
    PlaceholderCheckboxComponent,
    IconButtonComponent,
    SwitcherComponent,
  ],
})
export class ComparisonRulesModule {}
