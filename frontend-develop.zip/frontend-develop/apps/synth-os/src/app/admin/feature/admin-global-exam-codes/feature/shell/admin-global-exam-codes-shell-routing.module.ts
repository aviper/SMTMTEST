import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AdminGlobalExamCodesShellComponent } from './admin-global-exam-codes-shell.component';
import { AdminGlobalExamCodesListComponent } from '../admin-global-exam-codes-list/admin-global-exam-codes-list.component';
import { AdminGlobalModalitiesComponent } from '../admin-global-modalities/admin-global-modalities.component';
import { AdminGlobalRegionsComponent } from '../admin-global-regions/admin-global-regions.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: AdminGlobalExamCodesShellComponent,
        children: [
          {
            path: '',
            pathMatch: 'full',
            redirectTo: 'exams',
          },
          {
            path: 'exams',
            component: AdminGlobalExamCodesListComponent,
          },
          {
            path: 'modalities',
            component: AdminGlobalModalitiesComponent,
          },
          {
            path: 'regions',
            component: AdminGlobalRegionsComponent,
          },
        ],
      },
    ]),
  ],
  exports: [RouterModule],
})
export class AdminGlobalExamCodesShellRoutingModule {}
