import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { isEqual } from 'lodash-es';
import { Subject } from 'rxjs';
import { debounceTime, filter, takeUntil } from 'rxjs/operators';

import { ICONS } from '@synth/utils';

import { CustomValidators } from '../../../../../../../core/helpers/custom-validators';
import { IOption } from '../../../../../../../core/models/types/common';
import { ComparisonRule, ComparisonRuleGroup } from '../../../utils/model';

@Component({
  selector: 'synth-comparison-rule-sub-row',
  templateUrl: './comparison-rule-sub-row.component.html',
  styleUrls: ['./comparison-rule-sub-row.component.scss'],
  standalone: false,
})
export class ComparisonRuleSubRowComponent implements OnInit, OnDestroy, OnChanges {
  @Input() index: number;
  @Input() rulesGroup: ComparisonRuleGroup;
  @Input() rule: ComparisonRule;
  @Input() canEdit = true;
  @Input() canDelete = true;
  @Input() debounceValue = 1500;
  @Output() edit: EventEmitter<ComparisonRule> = new EventEmitter<ComparisonRule>();
  @Output() delete: EventEmitter<void> = new EventEmitter<void>();

  readonly ICONS = ICONS;

  modalitiesControl = new FormControl<string[]>([], CustomValidators.required);
  regionsControl = new FormControl<string[]>([], CustomValidators.required);
  numberOfExamsControl = new FormControl<number>(null, [
    CustomValidators.required,
    Validators.min(1),
    Validators.max(9),
  ]);
  includeOldest = false;

  additionalRegionsOptions: IOption[] = [
    { label: 'Any', value: 'Any regions' },
    { label: 'Same', value: 'Related regions' },
  ];
  preselectedRegions = '';
  preselectedModalities = '';
  excludeModalitiesOptions: string[] = [];
  regionsOpened = false;
  modalitiesOpened = false;

  private validateChanges$$: Subject<void> = new Subject<void>();
  private unsubscribe$$: Subject<void> = new Subject<void>();

  ngOnInit(): void {
    this.validateChanges$$
      .asObservable()
      .pipe(
        debounceTime(this.debounceValue),
        filter(() => !this.regionsOpened && !this.modalitiesOpened),
        filter(() => this.modalitiesControl.valid && this.regionsControl.valid && this.numberOfExamsControl.valid),
        filter(() => !this.isEqualToInitial())
      )
      .subscribe(() => {
        this.edit.emit({
          priorModality: this.rule.priorModality,
          priorModalityId: this.rule.priorModalityId,
          excludesModalities: this.rule.excludesModalities || [],
          excludesRegions: this.rule.excludesRegions || [],
          includesModalities: this.modalitiesControl.value,
          includesRegions: this.regionsControl.value,
          numberOfExams: this.numberOfExamsControl.value,
          includeOldest: this.includeOldest,
        });
      });

    this.numberOfExamsControl.valueChanges
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe(() => this.validateChanges$$.next());
  }

  ngOnChanges(): void {
    this.preselectedRegions = this.rule.includesRegions
      .map((r) => {
        if (r.toLowerCase() === 'related regions') {
          return 'Same';
        }

        if (r === 'Any regions') {
          return 'Any';
        }

        return r;
      })
      .join('; ');
    this.preselectedModalities = this.rule.includesModalities ? this.rule.includesModalities.join('; ') : '';
    this.excludeModalitiesOptions = this.rulesGroup.rules
      .filter((_, i) => i !== this.index)
      .map((rule) => rule.includesModalities)
      .filter((items) => items && items.length)
      .flat();

    this.regionsControl.setValue(this.rule.includesRegions);
    this.modalitiesControl.setValue(this.rule.includesModalities || []);
    this.numberOfExamsControl.setValue(this.rule.numberOfExams);
    this.modalitiesControl.updateValueAndValidity();
    this.regionsControl.updateValueAndValidity();
    this.numberOfExamsControl.updateValueAndValidity();
    this.includeOldest = this.rule.includeOldest || false;
  }

  onRegionsOpen(): void {
    this.regionsOpened = true;
  }

  onModalitiesOpen(): void {
    this.modalitiesOpened = true;
  }

  onModalitiesChange(selectedOptions: IOption[]): void {
    if (!selectedOptions.length) {
      return;
    }

    this.modalitiesOpened = false;
    this.validateChanges$$.next();
  }

  onRegionsChange(selectedOptions: IOption[]): void {
    const value = this.regionsControl.value;

    this.additionalRegionsOptions.forEach((option) => {
      if (value.length && value.includes(option.value)) {
        this.regionsControl.setValue([option.value]);
      }
    });

    this.regionsOpened = false;
    this.validateChanges$$.next();
  }

  onOptionClick(option: IOption): void {
    const currentValue = this.regionsControl.value;

    if (option.value.toLowerCase() === 'any regions' || option.value.toLowerCase() === 'related regions') {
      this.regionsControl.setValue([option.value]);
    } else {
      this.regionsControl.setValue(
        currentValue.filter(
          (value) => value.toLowerCase() !== 'any regions' && value.toLowerCase() !== 'related regions'
        )
      );
    }
  }

  onIncludeOldestChange(selected: boolean): void {
    this.includeOldest = selected;
    this.validateChanges$$.next();
  }

  deleteRule(): void {
    this.delete.emit();
  }

  private isEqualToInitial(): boolean {
    return (
      isEqual(this.modalitiesControl.value, this.rule.includesModalities || []) &&
      isEqual(this.regionsControl.value, this.rule.includesRegions || []) &&
      isEqual(this.numberOfExamsControl.value, this.rule.numberOfExams) &&
      isEqual(this.includeOldest, this.rule.includeOldest)
    );
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
