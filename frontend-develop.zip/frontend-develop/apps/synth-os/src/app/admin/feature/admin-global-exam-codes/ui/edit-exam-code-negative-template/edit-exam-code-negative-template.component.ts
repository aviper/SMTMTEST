import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormControl, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { asyncScheduler, Observable, Subject } from 'rxjs';
import { finalize, takeUntil } from 'rxjs/operators';

import {
  CONFIRM_POPUP_RESPONSE,
  DEFAULT_CONFIRM_DATA,
  MODAL_ACTION_COMPLETE,
  modalAnimation,
  ModalClass,
  ModalOverlayRef,
  ModalsV2Service,
} from '@synth/ui/modals';

import { DEFAULT_TEMPLATE_FONT } from '../../../../../core/constants/fonts';
import { ICONS } from '../../../../../core/constants/icon-list';
import {
  convertToField,
  DEFAULT_SECTION_OPTIONS,
  FINDINGS_SECTION,
  IMPRESSION_SECTION,
  PRE_FINDINGS_SECTION,
} from '../../../../../core/constants/template-sections';
import { CustomValidators } from '../../../../../core/helpers/custom-validators';
import { Helper } from '../../../../../core/helpers/helper';
import { DictionaryService } from '../../../../../core/http-services/dictionary.service';
import { ICTPCode } from '../../../../../core/models/types/dictionary';
import { IFormField, IOrderField, ITemplateField, OrderField } from '../../../../../core/models/types/orders';
import { OldIconComponentModule } from '../../../../../shared/ui/components/icon/icon.component';
import { CdkScrollableExtendedDirectiveModule } from '../../../../../shared/ui/directives/cdk-scrolling-extended.directive';
import { ControlErrorV2DirectiveModule } from '../../../../../shared/ui/directives/control-error-v2.directive';
import { ButtonsModule } from '../../../../../shared/ui/modules/buttons/buttons.module';
import { EditorModule } from '../../../../../shared/ui/modules/editor/editor.module';
import { TrueEditorComponent } from '../../../../../shared/ui/modules/editor/true-editor/true-editor.component';
import { LoaderModule } from '../../../../../shared/ui/modules/loader/loader.module';
import { InsertFieldModalComponent } from '../../../../../shared/ui/modules/template-sections-form/insert-field-modal/insert-field-modal.component';
import { TemplateSectionsFormModule } from '../../../../../shared/ui/modules/template-sections-form/template-sections-form.component';

@Component({
  imports: [
    CommonModule,
    OldIconComponentModule,
    EditorModule,
    ReactiveFormsModule,
    ButtonsModule,
    LoaderModule,
    ControlErrorV2DirectiveModule,
    CdkScrollableExtendedDirectiveModule,
    TemplateSectionsFormModule,
    MatTooltipModule,
  ],
  selector: 'app-edit-exam-code-negative-template',
  templateUrl: './edit-exam-code-negative-template.component.html',
  styleUrls: ['./edit-exam-code-negative-template.component.scss'],
  animations: [modalAnimation],
})
export class EditExamCodeNegativeTemplateComponent extends ModalClass implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('scrollContainer', { static: true }) scrollContainer: ElementRef<HTMLElement>;
  @ViewChild(TrueEditorComponent, { static: false }) editor: TrueEditorComponent;

  readonly unsubscribe$$ = new Subject<void>();
  readonly ICONS = ICONS;

  defaultFinding: string;
  isLoading = false;
  selectedFont = DEFAULT_TEMPLATE_FONT;
  hideTableGridLines = false;

  readonly cptCode: ICTPCode;
  readonly sectionOptions = DEFAULT_SECTION_OPTIONS;

  readonly form = this.fb.group(
    {
      hideTableGridLines: [],
      reportFields: [[], [CustomValidators.required]],
    },
    { validators: [CustomValidators.uniqueFieldsKeysForTemplate()] }
  );

  readonly hideTableGridLinesControl = this.form.get('hideTableGridLines') as FormControl;

  constructor(
    protected cdRef: ChangeDetectorRef,
    public modalOverlayRef: ModalOverlayRef,
    private modalsService: ModalsV2Service,
    private fb: UntypedFormBuilder,
    private dictionaryService: DictionaryService,
    @Inject(MODAL_ACTION_COMPLETE) actionComplete$: Observable<void>
  ) {
    super(cdRef, modalOverlayRef, actionComplete$);
    this.defaultFinding = this.modalOverlayRef.data.defaultFinding;
    this.cptCode = this.modalOverlayRef.data.cptCode;
  }

  ngAfterViewInit(): void {
    this.scrollContainer.nativeElement.scrollTop = 0;
  }

  ngOnInit(): void {
    this.modalOverlayRef.backdropClick
      .pipe(takeUntil(this.modalOverlayRef.beforeClosed()))
      .subscribe(() => this.closeAfterConfirm());

    this.initForm(this.modalOverlayRef.data.template);

    this.hideTableGridLinesControl.valueChanges
      .pipe(takeUntil(this.unsubscribe$$))
      .subscribe((value) => (this.hideTableGridLines = value));
  }

  editDefaultTemplate(): void {
    this.isLoading = true;
    const updatedCptCode = this.prepareCptCode(this.cptCode, this.form.value);

    this.dictionaryService
      .patchCptCode(this.cptCode.id, <ICTPCode>updatedCptCode, { autoNotifyErrors: false })
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe(
        () => {
          this.modalsService.success('Default template updated');
          this.closeModal(true);
        },
        (error) => this.modalsService.error(error.message)
      );
  }

  closeModal(reload: boolean = false): void {
    this.result.emit({ reload });
    this.modalOverlayRef.close();
  }

  onHideTableGridLinesChange(value: boolean): void {
    this.hideTableGridLinesControl.setValue(value);
  }

  private initForm(template?: { reportFields?: ITemplateField[]; hideTableGridLines: boolean }): void {
    const reportFields = template?.reportFields;

    this.hideTableGridLines = template?.hideTableGridLines ?? false;

    const initialReportFields =
      reportFields && reportFields.length > 0
        ? reportFields
        : [convertToField(PRE_FINDINGS_SECTION), convertToField(FINDINGS_SECTION), convertToField(IMPRESSION_SECTION)];

    this.form.patchValue({
      hideTableGridLines: this.hideTableGridLines,
      reportFields: initialReportFields,
    });
  }

  closeAfterConfirm(): void {
    if (this.form.dirty && this.form.invalid) {
      this.modalsService.confirm(DEFAULT_CONFIRM_DATA).subscribe((result) => {
        if (result === CONFIRM_POPUP_RESPONSE.cancel) {
          this.closeModal();
        }
      });
    } else {
      this.closeModal();
    }
  }

  openInsertFieldModal(): void {
    this.modalsService
      .open(InsertFieldModalComponent, {
        data: {
          tabs: {
            formFields: false,
            orderFields: true,
          },
        },
      })
      .subscribe((result) => this.insertField(result));
  }

  private insertField(field: { orderField?: IOrderField; formField?: IFormField }): void {
    const wrapper = this.editor;

    let fieldElement = '';
    let value = '';

    if (field.formField) {
      value = `[${field.formField.label?.trim()}]`;
      fieldElement = `<span class="form-field${field.formField.value ? '' : ' empty'}" data-fieldid="${field.formField.fieldId}" data-label="${field.formField.label?.trim()}">${value}</span>`;
    } else if (field.orderField) {
      value = `[${field.orderField.name}]`;

      if (field.orderField.name === OrderField.comparison) {
        fieldElement = `<span class="comparison-field">${value}</span>`;
      } else {
        fieldElement = `<span class="order-field">${value}</span>`;
      }
    }

    wrapper.pasteCustomField(fieldElement);
    wrapper.onTextChange();

    asyncScheduler.schedule(() => wrapper.quill.root.focus());
  }

  private prepareCptCode(
    cptCode: ICTPCode,
    data: { reportFields: ITemplateField[]; hideTableGridLines: boolean }
  ): Partial<ICTPCode> {
    // Should be remove after back fix their  part
    const integerField = ['xrViews', 'rvu'];
    const cptCodeClone = Helper.cloneDeep(cptCode);

    Object.keys(cptCodeClone).map((fieldName: string) => {
      if (cptCodeClone[fieldName] === null && !integerField.includes(fieldName)) {
        cptCodeClone[fieldName] = '';
      }

      if (cptCode[fieldName] === null && integerField.includes(fieldName)) {
        cptCodeClone[fieldName] = 0;
      }
    });

    return {
      modalityId: cptCodeClone.modalityId,
      code: cptCodeClone.code,
      codeWithModifier: cptCodeClone.codeWithModifier,
      laterality: cptCodeClone.laterality,
      contrast: cptCodeClone.contrast,
      xrViews: cptCodeClone.xrViews,
      shortName: cptCodeClone.shortName,
      medName: cptCodeClone.medName,
      isIr: cptCodeClone.isIr,
      reportFields: data.reportFields,
      bodyRegionIds: cptCodeClone.bodyRegions.map((br) => br.id),
      rvu: cptCodeClone.rvu,
      gridLines: data.hideTableGridLines,
    };
  }

  ngOnDestroy(): void {
    this.unsubscribe$$.next();
    this.unsubscribe$$.complete();
  }
}
