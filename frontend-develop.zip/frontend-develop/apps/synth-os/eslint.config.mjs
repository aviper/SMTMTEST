import angularConfig from '../../eslint-angular.config.mjs';

export default [
  ...angularConfig,
  {
    files: ['**/*.ts'],
    rules: {
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: ['synth', 'app', 'true'],
          style: 'kebab-case',
        },
      ],
      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: ['synth', 'app', 'true'],
          style: 'camelCase',
        },
      ],
    },
  },
];
