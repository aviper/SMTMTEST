import angularConfig from '../../eslint-angular.config.mjs';

export default [
  ...angularConfig,
  {
    files: ['**/*.ts'],
    rules: {
      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: 'synth',
          style: 'camelCase',
        },
      ],
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: 'synth',
          style: 'kebab-case',
        },
      ],
    },
  },
];
