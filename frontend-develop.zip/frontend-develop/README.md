# Synth OS

Gitlab: [Front-end repo link](https://development.idgital.com/idgital/frontend)

Gilab wiki : [Front-end guidelines doc](https://development.idgital.com/idgital/frontend/-/wikis/Front-end-guidlines)

Video: [Front-end video](https://drive.google.com/file/d/16zgNqE_zSPTuAEIgYsKUrGFAh9Wz6V_j/view?usp=share_link)

Before run:

    npm install

Generate certificate:

    cd apps/synth-os/src/ssl
    openssl genrsa -out key.pem 2048
    openssl req -new -key key.pem -out certrequest.csr
    openssl x509 -req -in certrequest.csr -signkey key.pem -out certificate.pem
    cd ../../../../

To run locally:

    npm run start

To run with https:

    ng serve --ssl

## Development server

Run `npm run start` for a dev server. Navigate to `http://localhost:4200/`.

The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `nx g component component-name` to generate a new component. You can also use
`nx generate directive|pipe|service|class|guard|interface|enum|module`.

### Creating a new library

Run `nx g @synth-plugin:library example/of/library/creation` to generate a new library. The output will be in
`libs/example/of/library/creation` folder the lib name will be example-of-library-creation. You can pass parameters in
the command in order to scaffold different types of libraries, for example if you want an ui type library, pass `--ui`
in the command like that `nx g @synth-plugin:library example/of/library/creation --ui`.

- `--utils` - will generate an empty library with no folders, it is the default library type.
- `--ui` - will generate a default ui library with three folders: components, directives and pipes.
- `--feature` - will generate a default feature library with two folders: feature and data-access.

### Testing an application

To test an application run `nx test <application-name>`. For example if you want to test the `synth-os` application run
`nx test synth-os`.

## Build

Run `npm run build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Build Remote

Run `npm run build-remote` to build the project. The build artifacts will be stored in the `dist/` directory.

### Important

When working in a library add the resources that you want to export in the index.ts of the library, do not import the
resources without using the absolute path `libs/example/of/library/my-resource`, use the following instead
`@example/of/library`.

If you are in a library or application scope and wants to import a resource of the same library or application, use the
relative path example `./my-resource`

