WITH MSFTTrades AS (
    SELECT
        ProfitDay6,
        IndicatorsJson
    FROM [History].StockTrades
    WHERE Symbol != '1qqq'
      AND ProfitDay6 IS NOT NULL
), Ranked AS (
    SELECT
        ProfitDay6,
        IndicatorsJson,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 DESC) AS TopRank,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 ASC) AS BottomRank
    FROM MSFTTrades
    where
     IndicatorsJson LIKE '%"StrategyIsBelowSmaShort"%' 
), Expanded AS (
    SELECT
        r.TopRank,
        r.BottomRank,
        j.[key] AS Indicator,
        TRY_CAST(j.[value] AS INT) AS IndicatorValue
    FROM Ranked r
    CROSS APPLY OPENJSON(r.IndicatorsJson) AS j
)
SELECT
    Indicator,
    SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInTop20,
    SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInBottom20,
    COUNT(*) AS TotalCount,
    CAST(SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS FLOAT) /
    NULLIF(SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END), 0) AS TopBottomRatio
FROM Expanded
GROUP BY Indicator
ORDER BY  TopBottomRatio DESC, AppearInTop20 DESC;
