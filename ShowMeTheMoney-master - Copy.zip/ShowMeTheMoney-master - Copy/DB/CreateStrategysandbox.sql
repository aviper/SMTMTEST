-- Declare the input parameters
--DECLARE @Symbols NVARCHAR(MAX) = 'NVDA';         -- Comma-separated list of stock symbols (e.g., 'AAPL,NVDA,MSFT')
--DECLARE @FromDate DATE = '2025-04-21';           -- Start date for filtering trade dates
--DECLARE @ToDate DATE = '2025-07-03';             -- End date for filtering trade dates

--SELECT 
--    i.[key] AS IndicatorName,
--    COUNT(*) AS IndicatorCount
--FROM History.StockTrades AS t
--CROSS APPLY OPENJSON(t.IndicatorsJson) AS i
--WHERE 
--    (@Symbols IS NULL OR EXISTS (
--        SELECT 1 
--        FROM STRING_SPLIT(@Symbols, ',') sym 
--        WHERE t.Symbol = TRIM(sym.value)
--    ))
--    AND (@FromDate IS NULL OR t.TradeDate >= @FromDate)
--    AND (@ToDate IS NULL OR t.TradeDate <= @ToDate)
--GROUP BY i.[key]
--ORDER BY IndicatorCount DESC;




SELECT  
    COUNT(*) AS TotalTrades,SUM(ProfitDay5) AS TotalProfitDay5,AVG(ProfitDay5) AS AvgProfitDay5,   
    -- Positive and Negative Day Counts
    COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS NumPositiveDays,COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END) AS NumNegativeDays,
    -- Win Rate (%)
    CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(*), 0) AS WinRate,
    -- Profit Factor (Total Gain / Absolute Loss)
    SUM(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) /    NULLIF(ABS(SUM(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END)), 0) AS ProfitFactor,
    -- Average Win / Loss
    AVG(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) AS AvgPositiveProfit,    AVG(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END) AS AvgNegativeLoss,
    -- Positive / Negative Ratio
    CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) /    NULLIF(COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END), 0) AS PositiveNegativeRatio

FROM [History].[StockTrades]
WHERE 
    Symbol != 'NVDA'
 -- AND TradeDate > '2020-01-01'
  AND IndicatorsJson LIKE '%"IsProfitAbove3PercentLast4Days"%' 
