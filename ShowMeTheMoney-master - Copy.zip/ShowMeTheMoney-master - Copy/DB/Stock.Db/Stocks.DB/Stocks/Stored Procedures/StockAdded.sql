﻿--exec [Stocks].[StockAdded] 'UNSS'
CREATE PROCEDURE [Stocks].[StockAdded]
	@Symbol nvarchar(50)
	
AS
BEGIN
	declare @StockInfoSymbol nvarchar(50)
	declare @StocksHistorySymbol nvarchar(50)
	SELECT @StockInfoSymbol=Symbol FROM StocksHistory where Symbol=@Symbol 
	IF(@StockInfoSymbol IS  NULL)
	BEGIN
		INSERT INTO [Stocks].[StocksHistory] (Symbol,Created,IsValid)VALUES (@Symbol,getdate()-400,1)
	END

	SET @StockInfoSymbol=null
	SELECT @StockInfoSymbol=Symbol FROM [Stocks].[StocksHistory] where Symbol=@Symbol and (CompanyName !='UNKNOWN' or Created>GETDATE()-1)
	IF(@StockInfoSymbol IS NOT NULL)
		BEGIN
			SELECT @StocksHistorySymbol=Symbol FROM [Stocks].StocksHistory where Symbol=@StockInfoSymbol 
			IF(@StocksHistorySymbol IS  NULL)
				BEGIN
					INSERT INTO [Stocks].StocksHistory (Symbol,Created,IsValid)VALUES (@Symbol,getdate()-400,1)
				END
			Update [Stocks].StocksHistory set Updated=getdate() where Symbol= @Symbol
	END
	  
			
END