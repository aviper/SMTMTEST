﻿CREATE PROCEDURE [Stocks].[RESET_DB]
	@Symbol nvarchar(50)
	
AS
BEGIN
print 1
--delete  from  [Stocks].Configuration
--delete  from  [Stocks].History
--delete  from  [Stocks].Logs
--delete  from  [Stocks].ProcessHistory
--delete  from  [Stocks].SectorsData

--delete from [Stocks].SimulationResults
--delete  from  [Stocks].SourceScrapperData
--delete  from  [Stocks].Stocks
--delete  from  [Stocks].StockInfo
--delete  from  [Stocks].StocksListSource
--delete  from  [Stocks].WatchList
--delete  from  Trading.AlertEmails
--delete  from  Trading.AlertStocks
--delete  from  Trading.AlertStocksEmails


--SELECT      distinct  Stocks.Stocks.Symbol 
--FROM            Stocks.Stocks EXCEPT SELECT Symbol 
--FROM            Stocks.StockInfo
	
	
	
	
--	/****** Script for SelectTopNRows command from SSMS  ******/
--SELECT count(1)
--  FROM [sgatecoi_Stargate].[Stocks].[StockInfo] where CompanyName is not null or CompanyName like 'unkn'

--  SELECT count(1)
--  FROM [sgatecoi_Stargate].[Stocks].[StockInfo] where CompanyName is  null


--  select * from  [sgatecoi_Stargate].[Stocks].[StockInfo]where CompanyName  like '%unkn%'  or sector  like '%unkn%'


-- select * from  [sgatecoi_Stargate].[Stocks].[StockInfo]where CompanyName  like '%Michigan%'  or  CompanyName  like '%elon musk%'
--   --update  [sgatecoi_Stargate].[Stocks].[StockInfo] set CompanyName='UNKNOWN' where CompanyName  like '%Michigan%'  or  CompanyName  like '%elon musk%'



--SELECT CompanyName ,COUNT(CompanyName)
--FROM [sgatecoi_Stargate].[Stocks].[StockInfo]
--GROUP BY CompanyName 
--HAVING (COUNT(CompanyName) >1 )








		
END