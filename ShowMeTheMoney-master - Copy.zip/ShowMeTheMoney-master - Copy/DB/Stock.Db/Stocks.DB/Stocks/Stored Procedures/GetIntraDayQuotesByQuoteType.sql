﻿CREATE PROCEDURE [Stocks].[GetIntraDayQuotesByQuoteType]
    @MarketState NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        [Id],
        [Symbol],
        [TradeDateTime],
        MarketState,
        [OpenPrice],
        [ClosePrice],
        [AdjustedClose],
        [HighPrice],
        [LowPrice],
        [Volume],
        [IndicatorsJson],
        [Data],
        [IsAfterHours],
        [IsValid],
        [ErrorMessage],
        [CreatedAt]
    FROM [Stocks].[IntraDayQuotes]
    WHERE @MarketState IS NULL OR MarketState = @MarketState
    ORDER BY [TradeDateTime] DESC;
END