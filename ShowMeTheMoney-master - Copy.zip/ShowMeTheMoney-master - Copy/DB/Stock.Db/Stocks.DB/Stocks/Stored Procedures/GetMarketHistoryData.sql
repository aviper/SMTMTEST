﻿
CREATE PROCEDURE [Stocks].[GetMarketHistoryData]
    @days_back FLOAT = 2,
    @min_score FLOAT = 20
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        h.* 
    FROM 
        [Stocks].[History] h
    JOIN (
        SELECT 
            Symbol, 
            MAX(Score) AS max_score 
        FROM 
            [Stocks].[History] 
        WHERE 
            Date > GETDATE() - @days_back
        GROUP BY 
            Symbol
    ) hs 
    ON 
        h.Symbol = hs.Symbol
    WHERE 
        h.Date > GETDATE() - @days_back
        AND hs.max_score >= @min_score
    ORDER BY 
        hs.max_score DESC, 
        h.Score DESC, 
        h.Date DESC;
END