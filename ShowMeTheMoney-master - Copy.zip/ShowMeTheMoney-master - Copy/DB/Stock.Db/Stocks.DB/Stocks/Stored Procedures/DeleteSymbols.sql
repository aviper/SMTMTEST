﻿CREATE PROCEDURE [Stocks].[DeleteSymbols]
    @Symbols NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    -- Convert comma-separated values into a table variable
    DECLARE @SymbolsTable TABLE (Symbol NVARCHAR(50));
    
    INSERT INTO @SymbolsTable (Symbol)
    SELECT value FROM SplitString(@Symbols, ',');

    -- Perform deletion on each table
    DELETE FROM [Stocks].[Stocks]
    WHERE Symbol IN (SELECT Symbol FROM @SymbolsTable);

    DELETE FROM [Stocks].[StocksHistory]
    WHERE Symbol IN (SELECT Symbol FROM @SymbolsTable);

    DELETE FROM [Stocks].[StockInfo]
    WHERE Symbol IN (SELECT Symbol FROM @SymbolsTable);

    DELETE FROM [Stocks].[History]
    WHERE Symbol IN (SELECT Symbol FROM @SymbolsTable);

    DELETE FROM [Strategies].[StrategiesStocks]
    WHERE Symbol IN (SELECT Symbol FROM @SymbolsTable);
END