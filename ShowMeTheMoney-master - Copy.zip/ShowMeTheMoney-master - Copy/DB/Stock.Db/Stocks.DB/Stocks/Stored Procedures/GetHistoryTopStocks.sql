﻿--exec [Stocks].[GetHistoryTopStocks] 2,null
--exec [Stocks].[GetHistoryTopStocks] 1
--exec [Stocks].[GetHistoryTopStocks] 5,1

--exec [Stocks].[GetHistoryTopStocks] 2,null
--exec [Stocks].[GetHistoryTopStocks] 2,0
--exec [Stocks].[GetHistoryTopStocks] 2,1

CREATE PROCEDURE [Stocks].[GetHistoryTopStocks]
	@numberOfDays int=1,
	@IsDuringTrade bit =null

	
AS
BEGIN
if(@numberOfDays<=1)	

begin
	select  Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-2 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>50
	INTERSECT
	select   Symbol  from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  DATEADD(MINUTE, -500, getdate())  and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>100
	--INTERSECT
	--select   Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  DATEADD(MINUTE, -200, getdate()) and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>2 and Score>110
end

if(@numberOfDays=2)	

begin
	select  Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  getdate()-2 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>100
	INTERSECT
	select  Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  getdate()-1 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>200
	
end




if(@numberOfDays=3)	
begin
		select  Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  getdate()-3 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>100
		INTERSECT
		select   Symbol from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  getdate()-2 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>2 and Score>200
		INTERSECT
		select   Symbol  from [Stocks].History where (IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and Date between  getdate()-1 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>3 and Score>300
		
end	 


if(@numberOfDays=4)	
begin
		select  Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-4 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>100
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-3 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>2 and Score>200
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-2 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>3 and Score>300
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-1 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>3 and Score>300
		
end	  

if(@numberOfDays>=5)	
begin
		select  Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-5 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>1 and Score>100
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-4 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>2 and Score>200
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-3 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>3 and Score>300
		INTERSECT
		select   Symbol from [Stocks].History where(IsDuringTrade =@IsDuringTrade or @IsDuringTrade is null) and  Date between  getdate()-2 and getdate() and LEN(Source) - LEN(REPLACE(Source, ',', ''))>3 and Score>400
end	  

		
END