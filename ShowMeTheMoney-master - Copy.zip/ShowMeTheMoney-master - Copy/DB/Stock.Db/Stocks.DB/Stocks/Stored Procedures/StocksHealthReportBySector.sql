﻿--exec  [Stocks].[StocksHealthReportBySector] '2025-05-06'

CREATE PROCEDURE [Stocks].[StocksHealthReportBySector]
    @LastTradeDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @LastTradeDate IS NULL
        SET @LastTradeDate = GETDATE();

    SELECT 
        sh.Sector,
        COUNT(*) AS TotalStocks,

        -- Existing Health Metrics
        SUM(CASE 
            WHEN DATEDIFF(DAY, ISNULL(sh.LastSync, @LastTradeDate), @LastTradeDate) >= 0 
                 AND sh.IsValid = 1 
            THEN 1 ELSE 0 
        END) AS OutdatedStocks,

        SUM(CASE WHEN sh.IsValid = 0 THEN 1 ELSE 0 END) AS InvalidStocks,

        SUM(CASE 
            WHEN sh.IsValid = 1 AND (sh.CompanyName IS NULL OR LTRIM(RTRIM(sh.CompanyName)) = '') 
            THEN 1 ELSE 0 
        END) AS MissingCompanyName,


        SUM(CASE WHEN DATEDIFF(YEAR, ISNULL(sh.FirstSample, @LastTradeDate), @LastTradeDate) < 1 THEN 1 ELSE 0 END) AS Stocks_Age_LessThan1Year,
        SUM(CASE WHEN DATEDIFF(YEAR, ISNULL(sh.FirstSample, @LastTradeDate), @LastTradeDate) BETWEEN 1 AND 5 THEN 1 ELSE 0 END) AS Stocks_Age_1To5Years,
        SUM(CASE WHEN DATEDIFF(YEAR, ISNULL(sh.FirstSample, @LastTradeDate), @LastTradeDate) > 5 THEN 1 ELSE 0 END) AS Stocks_Age_MoreThan5Years,

        SUM(CASE WHEN DATEDIFF(DAY, ISNULL(sh.Updated, @LastTradeDate), @LastTradeDate) < 30 THEN 1 ELSE 0 END) AS ActiveStocks,
        SUM(CASE WHEN sh.FirstSample IS NULL OR sh.LastSample IS NULL THEN 1 ELSE 0 END) AS MissingSampleData,
        SUM(CASE WHEN DATEDIFF(DAY, ISNULL(sh.LastSync, @LastTradeDate), @LastTradeDate) > 30 THEN 1 ELSE 0 END) AS SyncGapStocks,

        -- New: Market Cap Categories
        SUM(CASE WHEN sh.MarketCap IS NOT NULL AND sh.MarketCap < 2000000000 THEN 1 ELSE 0 END) AS SmallCap,
        SUM(CASE WHEN sh.MarketCap >= 2000000000 AND sh.MarketCap < 10000000000 THEN 1 ELSE 0 END) AS MidCap,
        SUM(CASE WHEN sh.MarketCap >= 10000000000 THEN 1 ELSE 0 END) AS LargeCap,

        -- New: Missing Financial Data
        SUM(CASE WHEN sh.MarketCap IS NULL OR sh.MarketCap = 0 THEN 1 ELSE 0 END) AS MissingMarketCap,
        SUM(CASE WHEN sh.AverageDailyVolume3Month IS NULL OR sh.AverageDailyVolume3Month = 0 THEN 1 ELSE 0 END) AS MissingVolume,
        SUM(CASE WHEN sh.LastPrice IS NULL OR sh.LastPrice = 0 THEN 1 ELSE 0 END) AS MissingLastPrice,
        SUM(CASE WHEN sh.FiftyTwoWeekLow IS NULL OR sh.FiftyTwoWeekHigh IS NULL THEN 1 ELSE 0 END) AS Missing52WeekRange

    FROM [Stocks].[StocksHistory] sh 
    GROUP BY sh.Sector
    ORDER BY OutdatedStocks DESC, TotalStocks DESC;
END