﻿
-- exec [Stocks].[StocksHealthReport] '2025-05-15'
CREATE PROCEDURE [Stocks].[StocksHealthReport]
    @LastTradeDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @MAX_DAYS_SYNC_GAP INT = 30;
    DECLARE @MAX_DAYS_STALE INT = 90;

    IF @LastTradeDate IS NULL
        SET @LastTradeDate = GETDATE();

    -- Count total stocks (including invalid)
    DECLARE @TotalStocks INT;
    SELECT @TotalStocks = COUNT(*) FROM [Stocks].[StocksHistory];

    -- Count invalid stocks
    DECLARE @InvalidStocks INT;
    SELECT @InvalidStocks = COUNT(*) FROM [Stocks].[StocksHistory] WHERE IsValid = 0;

    -- Count of intraday quotes for LastTradeDate
    DECLARE @IntraDayQuotesCount INT;
    SELECT @IntraDayQuotesCount = COUNT(*) 
    FROM [Stocks].[IntraDayQuotes]
    WHERE CAST([TradeDateTime] AS DATE) = @LastTradeDate;

    -- Count of stock trade summaries for LastTradeDate
    DECLARE @StockTradeSummaryCount INT;
    SELECT @StockTradeSummaryCount = COUNT(*)
    FROM [History].[StockTradeSummary]

    -- Count of stock trades for LastTradeDate
    DECLARE @StockTradesCount INT;
    SELECT @StockTradesCount = COUNT(*)
    FROM [History].[StockTrades]
    WHERE [TradeDate] = @LastTradeDate;

    -- Main summary
    SELECT 
        @TotalStocks AS TotalStocks,

        SUM(CASE 
            WHEN DATEDIFF(DAY, ISNULL(sh.LastSync, @LastTradeDate), @LastTradeDate) >= 0 
                 AND sh.IsValid = 1 
            THEN 1 ELSE 0 
        END) AS OutdatedStocks,

        (CAST(SUM(CASE 
            WHEN DATEDIFF(DAY, ISNULL(sh.LastSync, @LastTradeDate), @LastTradeDate) >= 1 
                 AND sh.IsValid = 1 
            THEN 1 ELSE 0 
        END) AS FLOAT) / NULLIF(@TotalStocks, 0)) * 100 AS OutdatedStockPercentage,

        @InvalidStocks AS InvalidStocks,

        (CAST(@InvalidStocks AS FLOAT) / NULLIF(@TotalStocks, 0)) * 100 AS InvalidStockPercentage,

        MIN(sh.FirstSample) AS OldestFirstSample,
        MAX(sh.LastSample) AS LatestLastSample,

        SUM(CASE WHEN sh.LastSync IS NULL THEN 1 ELSE 0 END) AS MissingSyncData,

        SUM(CASE WHEN DATEDIFF(DAY, ISNULL(sh.LastSync, @LastTradeDate), @LastTradeDate) > @MAX_DAYS_SYNC_GAP THEN 1 ELSE 0 END) AS SyncGapStocks,

        SUM(CASE WHEN DATEDIFF(DAY, ISNULL(sh.Updated, @LastTradeDate), @LastTradeDate) < @MAX_DAYS_SYNC_GAP THEN 1 ELSE 0 END) AS ActiveStocks,

        SUM(CASE WHEN DATEDIFF(DAY, ISNULL(sh.Updated, @LastTradeDate), @LastTradeDate) > @MAX_DAYS_STALE THEN 1 ELSE 0 END) AS StaleStocks,

        MAX(ISNULL(sh.Updated, @LastTradeDate)) AS LatestTradeDate,

        @IntraDayQuotesCount AS IntraDayQuotesCount,
        @StockTradeSummaryCount AS StockTradeSummaryCount,
        @StockTradesCount AS StockTradesCount

    FROM [Stocks].[StocksHistory] sh 
    WHERE sh.IsValid = 1;
END