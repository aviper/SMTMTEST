﻿--exec [Stocks].[GetMarketData] null,'2021-01-26 09:13:07.870','2021-01-26 09:13:07.870'
CREATE PROCEDURE [Stocks].[GetMarketData]
	@Symbol nvarchar(50),
	@fromDate datetime,
	@toDate datetime
	
AS
BEGIN
	

	SELECT        *
	FROM          [Stocks].MarketData
	 where (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null)
	
	  
			
END