﻿
CREATE PROCEDURE [Stocks].[GetStocksHistoriesSymbols]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT  
        si.Symbol, 
        si.LastSample,
        si.FirstSample,
        si.QuoteType
    FROM Stocks.StocksHistory si
    WHERE si.IsValid = 1
      
    ORDER BY 
        CASE 
            WHEN si.QuoteType = 'INDEX' THEN 1
            WHEN si.QuoteType = 'ETF' THEN 2
            ELSE 3
        END,
        si.QuoteType; -- optional secondary sorting

END