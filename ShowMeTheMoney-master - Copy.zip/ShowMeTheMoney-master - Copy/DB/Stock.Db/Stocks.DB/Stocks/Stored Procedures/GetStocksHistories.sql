﻿
-- EXEC [Stocks].[GetStocksHistories] '2025-05-11', 500

CREATE PROCEDURE [Stocks].[GetStocksHistories]
    @lastTradingDate DATETIME,
    @maxItems INT = 500
AS
BEGIN
    SET NOCOUNT ON;

    -- Ensure only the date part is considered
    DECLARE @dateOnly DATE = CAST(@lastTradingDate AS DATE);

    SELECT TOP (@maxItems)
        sh.*
    FROM Stocks.StocksHistory sh
    WHERE
        (sh.LastSync IS NULL OR CAST(sh.LastSync AS DATE) <= @dateOnly)
        AND sh.IsValid = 1
    ORDER BY
        sh.Updated DESC;
END;