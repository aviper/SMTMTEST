﻿CREATE VIEW [Stocks].[StockPositionsWithAlertsView] AS
WITH StockPositions AS (
    SELECT 
        Symbol,
        CompanyName,
        MarketCap,
        LastPrice,
        FiftyTwoWeekLow,
        FiftyTwoWeekHigh,
        ROUND(
            (LastPrice - FiftyTwoWeekLow) * 100.0 / NULLIF(FiftyTwoWeekHigh - FiftyTwoWeekLow, 0),
            2
        ) AS PricePositionPercent,
        EarningsDate,
        TrailingPE,
        ForwardPE,
        EpsTrailingTwelveMonths,
        EpsForward,
        PriceToBook,
        AverageDailyVolume3Month,
        AverageAnalystRating
    FROM [Stocks].[StocksHistory]
    WHERE IsValid = 1
)
SELECT 
    Symbol,
    CompanyName,
    MarketCap,
    LastPrice,
    FiftyTwoWeekLow,
    FiftyTwoWeekHigh,
    PricePositionPercent,
    EarningsDate,
    TrailingPE,
    ForwardPE,
    EpsTrailingTwelveMonths,
    EpsForward,
    PriceToBook,
    AverageDailyVolume3Month,
    AverageAnalystRating,
    CASE 
        WHEN TrailingPE > 50 THEN 'High P/E'
        WHEN TrailingPE BETWEEN 15 AND 50 THEN 'Moderate P/E'
        ELSE 'Low P/E'
    END AS ValuationCategory,
    CASE 
        WHEN PricePositionPercent < 25 THEN 'Near 52-Week Low'
        WHEN PricePositionPercent BETWEEN 25 AND 75 THEN 'Mid Range'
        ELSE 'Near 52-Week High'
    END AS PricePositionCategory,
    -- Alerts
    CASE 
        WHEN TrailingPE > 50 THEN 1 ELSE 0 
    END AS HighPEAlert,
    CASE 
        WHEN PricePositionPercent < 20 THEN 1 ELSE 0 
    END AS NearLowPriceAlert
FROM StockPositions;