﻿CREATE TABLE [Stocks].[IntraDayQuotes] (
    [Id]               UNIQUEIDENTIFIER NOT NULL,
    [Symbol]           VARCHAR (5)      NOT NULL,
    [TradeDateTime]    DATETIME         CONSTRAINT [DF_IntraDayQuotes_TradeDateTime] DEFAULT (getdate()) NOT NULL,
    [MarketState]      NVARCHAR (20)    CONSTRAINT [DF__IntraDayQ__Quote__2B4A5C8F] DEFAULT ('Regular') NOT NULL,
    [OpenPrice]        DECIMAL (18, 4)  NOT NULL,
    [ClosePrice]       DECIMAL (18, 4)  NOT NULL,
    [AdjustedClose]    DECIMAL (18, 4)  NOT NULL,
    [HighPrice]        DECIMAL (18, 4)  NOT NULL,
    [LowPrice]         DECIMAL (18, 4)  NOT NULL,
    [Volume]           BIGINT           NOT NULL,
    [IndicatorsJson]   NVARCHAR (MAX)   NOT NULL,
    [Data]             NVARCHAR (MAX)   NULL,
    [IsAfterHours]     BIT              NULL,
    [IsValid]          BIT              DEFAULT ((1)) NOT NULL,
    [ErrorMessage]     NVARCHAR (250)   NULL,
    [CreatedAt]        DATETIME2 (3)    DEFAULT (sysdatetime()) NOT NULL,
    [RawData]          NVARCHAR (MAX)   NULL,
    [PricePerformance] NVARCHAR (MAX)   NULL,
    [MarketCap]        BIGINT           NULL,
    [MomentumScore]    DECIMAL (10, 5)  NULL,
    CONSTRAINT [PK_IntraDayQuotes] PRIMARY KEY CLUSTERED ([Id] ASC)
);












GO



GO
CREATE NONCLUSTERED INDEX [IX_IntraDayQuotes_IsValid]
    ON [Stocks].[IntraDayQuotes]([IsValid] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_IntraDayQuotes_CreatedAt]
    ON [Stocks].[IntraDayQuotes]([CreatedAt] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_IntraDayQuotes_QuoteType]
    ON [Stocks].[IntraDayQuotes]([MarketState] ASC);




GO
CREATE NONCLUSTERED INDEX [IX_IntraDayQuotes_Symbol_TradeDateTime]
    ON [Stocks].[IntraDayQuotes]([Symbol] ASC, [TradeDateTime] ASC);

