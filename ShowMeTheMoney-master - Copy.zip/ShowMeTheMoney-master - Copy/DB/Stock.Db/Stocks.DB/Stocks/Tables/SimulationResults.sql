﻿CREATE TABLE [Stocks].[SimulationResults] (
    [Id]            UNIQUEIDENTIFIER CONSTRAINT [DF_SimulationResults_Id] DEFAULT (newid()) NOT NULL,
    [Date]          DATETIME         CONSTRAINT [DF_SimulationResults_Date] DEFAULT (getdate()) NOT NULL,
    [Symbol]        NCHAR (10)       NOT NULL,
    [Price]         FLOAT (53)       CONSTRAINT [DF_SimulationResults_Price] DEFAULT ((0)) NOT NULL,
    [Score]         FLOAT (53)       CONSTRAINT [DF_SimulationResults_Score] DEFAULT ((0)) NOT NULL,
    [Source]        NVARCHAR (MAX)   NOT NULL,
    [Data]          NVARCHAR (MAX)   NULL,
    [IsDuringTrade] BIT              NULL,
    [Rank]          INT              NULL,
    [RawScore]      FLOAT (53)       NULL,
    CONSTRAINT [PK_SimulationResults] PRIMARY KEY CLUSTERED ([Id] ASC)
);

