﻿CREATE TABLE [Stocks].[Stocks] (
    [Id]              UNIQUEIDENTIFIER CONSTRAINT [DF_Stocks_Id] DEFAULT (newid()) NOT NULL,
    [WatchListId]     UNIQUEIDENTIFIER NULL,
    [Symbol]          NVARCHAR (50)    NOT NULL,
    [Data]            NVARCHAR (MAX)   NULL,
    [Added]           DATETIME         CONSTRAINT [DF_Stocks_AddedDate] DEFAULT (getdate()) NULL,
    [Modified]        DATETIME         NULL,
    [InWatchList]     BIT              CONSTRAINT [DF_Stocks_InWatchList] DEFAULT ((1)) NOT NULL,
    [PlaceInList]     INT              NOT NULL,
    [lastPlaceInList] INT              NOT NULL,
    [Path]            NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_Stocks] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Stocks_WatchList] FOREIGN KEY ([WatchListId]) REFERENCES [Stocks].[WatchList] ([Id])
);




GO
CREATE NONCLUSTERED INDEX [IDX_Stocks_InWatchList]
    ON [Stocks].[Stocks]([InWatchList] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_Stocks_PlaceInList]
    ON [Stocks].[Stocks]([PlaceInList] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_Stocks_Symbol]
    ON [Stocks].[Stocks]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Stocks_Symbol]
    ON [Stocks].[Stocks]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Stocks_WatchListId]
    ON [Stocks].[Stocks]([WatchListId] ASC);


GO

CREATE TRIGGER [Stocks].[Stock_Change]
ON [Stocks].[Stocks]
AFTER INSERT,UPDATE
AS
BEGIN
	 DECLARE @Symbol nvarchar(50)

     DECLARE symbol_Cursor CURSOR FOR  SELECT Symbol FROM Inserted; 
     OPEN symbol_Cursor


     FETCH NEXT FROM symbol_Cursor INTO @Symbol;
     WHILE @@FETCH_STATUS = 0 
     BEGIN
          exec  [Stocks].[StockAdded]  @Symbol
         FETCH NEXT FROM symbol_Cursor INTO @Symbol;
     END;

    CLOSE symbol_Cursor;
    DEALLOCATE symbol_Cursor;



	
END