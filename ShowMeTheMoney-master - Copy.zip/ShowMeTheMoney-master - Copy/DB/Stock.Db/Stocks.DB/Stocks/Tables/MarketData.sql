﻿CREATE TABLE [Stocks].[MarketData] (
    [Id]                     UNIQUEIDENTIFIER CONSTRAINT [DF_MarketData_Id] DEFAULT (newid()) NOT NULL,
    [Symbol]                 NVARCHAR (50)    NOT NULL,
    [Date]                   DATETIME         NOT NULL,
    [Price]                  FLOAT (53)       NOT NULL,
    [PriceChangePercentage]  FLOAT (53)       NULL,
    [Volume]                 BIGINT           NULL,
    [VolumeChangePercentage] FLOAT (53)       NULL,
    CONSTRAINT [PK_MarketData] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IX_MarketData_Date]
    ON [Stocks].[MarketData]([Date] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_MarketDataSymbol]
    ON [Stocks].[MarketData]([Symbol] ASC);

