﻿CREATE TABLE [Stocks].[SourceScrapperData] (
    [Id]      UNIQUEIDENTIFIER CONSTRAINT [DF_SourceScrapperData_Id] DEFAULT (newid()) NOT NULL,
    [Code]    NVARCHAR (255)   NOT NULL,
    [Created] DATETIME         CONSTRAINT [DF_SourceScrapperData_Created] DEFAULT (getdate()) NOT NULL,
    [Data]    NVARCHAR (MAX)   NOT NULL,
    CONSTRAINT [PK_SourceScrapperData] PRIMARY KEY CLUSTERED ([Id] ASC)
);

