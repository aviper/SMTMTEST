﻿CREATE TABLE [Stocks].[StocksListSource] (
    [Id]                 UNIQUEIDENTIFIER CONSTRAINT [DF_WatchListConfig_Id] DEFAULT (newid()) NOT NULL,
    [Name]               NVARCHAR (255)   NOT NULL,
    [Url]                NVARCHAR (500)   NOT NULL,
    [Code]               NVARCHAR (100)   NOT NULL,
    [SourceType]         INT              NOT NULL,
    [Enable]             BIT              CONSTRAINT [DF_WatchListConfig_Enable] DEFAULT ((1)) NOT NULL,
    [Weight]             FLOAT (53)       NOT NULL,
    [LogChanges]         BIT              NOT NULL,
    [InvestmentDays]     INT              NULL,
    [EnableAnalysis]     BIT              CONSTRAINT [DF_StocksListSource_EnableAnalysis] DEFAULT ((0)) NOT NULL,
    [ScoreLimit]         INT              NULL,
    [ScoreForAppearance] BIT              NOT NULL,
    [PickScore]          INT              NULL,
    CONSTRAINT [PK_WatchListConfig] PRIMARY KEY CLUSTERED ([Id] ASC)
);

