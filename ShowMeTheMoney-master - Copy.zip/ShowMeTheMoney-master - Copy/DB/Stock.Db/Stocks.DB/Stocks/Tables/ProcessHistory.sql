﻿CREATE TABLE [Stocks].[ProcessHistory] (
    [Id]          UNIQUEIDENTIFIER CONSTRAINT [DF_ProcessHistory_Id] DEFAULT (newid()) NOT NULL,
    [Name]        NVARCHAR (255)   NOT NULL,
    [Info]        NVARCHAR (255)   NOT NULL,
    [Code]        NVARCHAR (255)   NOT NULL,
    [CreatedDate] DATETIME         CONSTRAINT [DF_ProcessHistory_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [LastRunDate] DATETIME         CONSTRAINT [DF_ProcessHistory_LastRunDate] DEFAULT (getdate()) NOT NULL,
    [Data]        NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_ProcessHistory] PRIMARY KEY CLUSTERED ([Id] ASC)
);

