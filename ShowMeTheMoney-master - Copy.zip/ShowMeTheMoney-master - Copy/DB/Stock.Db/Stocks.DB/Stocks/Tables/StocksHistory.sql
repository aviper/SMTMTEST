﻿CREATE TABLE [Stocks].[StocksHistory] (
    [Id]                            UNIQUEIDENTIFIER CONSTRAINT [DF_StocksHistory_Id] DEFAULT (newid()) NOT NULL,
    [Symbol]                        NVARCHAR (50)    NOT NULL,
    [EtfSymbol]                     NVARCHAR (50)    NULL,
    [IndexSymbol]                   NVARCHAR (50)    NULL,
    [SymbolGroup]                   NVARCHAR (50)    NULL,
    [IsValid]                       BIT              CONSTRAINT [DF_StocksHistory_IsValid] DEFAULT ((1)) NOT NULL,
    [InvalidReason]                 NVARCHAR (500)   NULL,
    [HistoryData]                   NVARCHAR (MAX)   NULL,
    [MetaData]                      NVARCHAR (MAX)   NULL,
    [Created]                       DATETIME         CONSTRAINT [DF_StocksHistory_Created] DEFAULT (getdate()) NOT NULL,
    [Updated]                       DATETIME         NULL,
    [FirstSample]                   DATETIME         NULL,
    [LastSample]                    DATETIME         NULL,
    [LastPrice]                     DECIMAL (18, 6)  NULL,
    [Sector]                        NVARCHAR (255)   NULL,
    [Industry]                      NVARCHAR (500)   NULL,
    [CompanyName]                   NVARCHAR (500)   NULL,
    [MarketCap]                     BIGINT           NULL,
    [AverageDailyVolume3Month]      BIGINT           NULL,
    [FiftyTwoWeekLow]               DECIMAL (18, 6)  NULL,
    [FiftyTwoWeekHigh]              DECIMAL (18, 6)  NULL,
    [EarningsDate]                  DATETIME         NULL,
    [LastSync]                      DATETIME         NULL,
    [LastInfoSync]                  DATETIME         NULL,
    [QuoteType]                     NVARCHAR (50)    NULL,
    [FiftyTwoWeekLowChangePercent]  DECIMAL (18, 6)  NULL,
    [FiftyTwoWeekHighChangePercent] DECIMAL (18, 6)  NULL,
    [EarningsDateStart]             DATETIME         NULL,
    [EarningsDateEnd]               DATETIME         NULL,
    [EpsTrailingTwelveMonths]       DECIMAL (18, 6)  NULL,
    [EpsForward]                    DECIMAL (18, 6)  NULL,
    [EpsCurrentYear]                DECIMAL (18, 6)  NULL,
    [PriceEpsCurrentYear]           DECIMAL (18, 6)  NULL,
    [TrailingPE]                    DECIMAL (18, 6)  NULL,
    [SharesOutstanding]             BIGINT           NULL,
    [BookValue]                     DECIMAL (18, 6)  NULL,
    [PriceToBook]                   DECIMAL (18, 6)  NULL,
    [ForwardPE]                     DECIMAL (18, 6)  NULL,
    [AverageAnalystRating]          NVARCHAR (50)    NULL,
    [AverageAnalystRatingVal]       AS               (TRY_CAST(left([AverageAnalystRating],charindex(' ',[AverageAnalystRating]+' ')-(1)) AS [decimal](3,1))),
    [AverageAnalystRatingStr]       AS               (ltrim(substring([AverageAnalystRating],charindex('-',[AverageAnalystRating]+'-')+(1),len([AverageAnalystRating])))),
    [SegmentStocks]                 NVARCHAR (500)   NULL,
    [InitialHoldDataJson]           NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_StocksHistory] PRIMARY KEY CLUSTERED ([Id] ASC)
);








































GO





























GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_StocksHistory_Symbol]
    ON [Stocks].[StocksHistory]([Symbol] ASC);


GO



GO
CREATE NONCLUSTERED INDEX [IX_StocksHistory_LastSync]
    ON [Stocks].[StocksHistory]([LastSync] ASC);






GO
CREATE NONCLUSTERED INDEX [IX_StocksHistory_Updated]
    ON [Stocks].[StocksHistory]([Updated] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StocksHistory_Symbol]
    ON [Stocks].[StocksHistory]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StocksHistory_LastSync]
    ON [Stocks].[StocksHistory]([LastSync] ASC);






GO


