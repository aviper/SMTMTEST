﻿CREATE TABLE [Stocks].[AlertHistory] (
    [Id]      UNIQUEIDENTIFIER CONSTRAINT [DF_AlertHistory_Id] DEFAULT (newid()) NOT NULL,
    [Scanner] NVARCHAR (50)    NOT NULL,
    [Code]    NVARCHAR (500)   NOT NULL,
    [Score]   FLOAT (53)       NOT NULL,
    [Symbol]  NVARCHAR (50)    NOT NULL,
    [Price]   FLOAT (53)       NOT NULL,
    [Data]    NVARCHAR (MAX)   NULL,
    [Date]    DATETIME         CONSTRAINT [DF_AlertHistory_Date] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_AlertHistory] PRIMARY KEY CLUSTERED ([Id] ASC)
);

