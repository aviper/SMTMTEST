﻿CREATE TABLE [Stocks].[SimulationResultsData] (
    [Id]            UNIQUEIDENTIFIER CONSTRAINT [DF_SimulationResultsRawData_Id] DEFAULT (newid()) NOT NULL,
    [Date]          DATETIME         CONSTRAINT [DF_SimulationResultsRawData_Date] DEFAULT (getdate()) NOT NULL,
    [Symbol]        NCHAR (10)       NOT NULL,
    [Price]         FLOAT (53)       CONSTRAINT [DF_SimulationResultsRawData_Price] DEFAULT ((0)) NOT NULL,
    [Score]         FLOAT (53)       CONSTRAINT [DF_SimulationResultsRawData_Score] DEFAULT ((0)) NOT NULL,
    [Source]        NVARCHAR (MAX)   NOT NULL,
    [Data]          NVARCHAR (MAX)   NULL,
    [IsDuringTrade] BIT              NULL,
    [Rank]          INT              NULL,
    [RawScore]      FLOAT (53)       NULL,
    CONSTRAINT [PK_SimulationResultsRawData] PRIMARY KEY CLUSTERED ([Id] ASC)
);

