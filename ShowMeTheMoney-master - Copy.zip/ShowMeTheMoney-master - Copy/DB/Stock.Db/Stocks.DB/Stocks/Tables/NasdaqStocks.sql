﻿CREATE TABLE [Stocks].[NasdaqStocks] (
    [Id]        UNIQUEIDENTIFIER CONSTRAINT [DF_NasdaqStocks_Id] DEFAULT (newid()) NOT NULL,
    [Symbol]    NVARCHAR (50)    NOT NULL,
    [Name]      NVARCHAR (150)   NOT NULL,
    [MarketCap] BIGINT           NOT NULL,
    [Sector]    NVARCHAR (150)   NOT NULL,
    [Industry]  NVARCHAR (150)   NOT NULL,
    [Exchange]  NVARCHAR (150)   NOT NULL,
    [Data]      NVARCHAR (MAX)   NULL,
    [Added]     DATETIME         CONSTRAINT [DF_NasdaqStocks_Added] DEFAULT (getdate()) NULL,
    [Modified]  DATETIME         CONSTRAINT [DF_NasdaqStocks_Modified] DEFAULT (getdate()) NULL,
    [Country]   NVARCHAR (150)   NULL,
    [IPOYear]   INT              NULL,
    [Volume]    BIGINT           NULL,
    CONSTRAINT [PK_NasdaqStocks] PRIMARY KEY CLUSTERED ([Id] ASC)
);

