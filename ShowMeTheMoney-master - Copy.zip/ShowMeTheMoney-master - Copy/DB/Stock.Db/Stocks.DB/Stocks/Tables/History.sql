﻿CREATE TABLE [Stocks].[History] (
    [Id]            UNIQUEIDENTIFIER CONSTRAINT [DF_History_Id] DEFAULT (newid()) NOT NULL,
    [Date]          DATETIME         CONSTRAINT [DF_History_Date] DEFAULT (getdate()) NOT NULL,
    [Symbol]        VARCHAR (10)     NOT NULL,
    [Price]         FLOAT (53)       CONSTRAINT [DF_History_Price] DEFAULT ((0)) NOT NULL,
    [Score]         FLOAT (53)       CONSTRAINT [DF_History_Score] DEFAULT ((0)) NOT NULL,
    [Source]        NVARCHAR (MAX)   NOT NULL,
    [Data]          NVARCHAR (MAX)   NULL,
    [IsDuringTrade] BIT              NULL,
    [Rank]          INT              NULL,
    [RawScore]      FLOAT (53)       NULL,
    CONSTRAINT [PK_History] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IX_History_Date_Score]
    ON [Stocks].[History]([Date] ASC, [Score] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_History_Date_Symbol_IsDuringTrade]
    ON [Stocks].[History]([Date] ASC, [Symbol] ASC, [IsDuringTrade] ASC);

