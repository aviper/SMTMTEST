﻿CREATE TABLE [Stocks].[SectorsData] (
    [Id]             UNIQUEIDENTIFIER CONSTRAINT [DF_SectorsData_Id] DEFAULT (newid()) NOT NULL,
    [SectorNames]    NVARCHAR (500)   NOT NULL,
    [HistoricalData] NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_SectorsData] PRIMARY KEY CLUSTERED ([Id] ASC)
);

