﻿CREATE TABLE [Stocks].[Logs] (
    [ID]          UNIQUEIDENTIFIER CONSTRAINT [DF_Logs_ID] DEFAULT (newid()) NOT NULL,
    [LogType]     INT              NOT NULL,
    [Application] NVARCHAR (50)    NULL,
    [Data]        NVARCHAR (1000)  NOT NULL,
    [Date]        DATETIME         NULL,
    CONSTRAINT [PK_Logs] PRIMARY KEY CLUSTERED ([ID] ASC)
);

