﻿CREATE TABLE [Stocks].[WatchList] (
    [Id]         UNIQUEIDENTIFIER CONSTRAINT [DF_WatchList_Id] DEFAULT (newid()) NOT NULL,
    [Name]       NVARCHAR (255)   NOT NULL,
    [SourceType] INT              NULL,
    [Weight]     FLOAT (53)       NULL,
    [logChanges] BIT              CONSTRAINT [DF_WatchList_logChanges] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_WatchList] PRIMARY KEY CLUSTERED ([Id] ASC)
);

