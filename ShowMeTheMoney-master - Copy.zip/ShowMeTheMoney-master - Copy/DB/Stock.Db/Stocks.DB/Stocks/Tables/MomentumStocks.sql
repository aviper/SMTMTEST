﻿CREATE TABLE [Stocks].[MomentumStocks] (
    [Id]       UNIQUEIDENTIFIER CONSTRAINT [DF_MomentumStocks_Id] DEFAULT (newid()) NOT NULL,
    [Symbol]   NVARCHAR (50)    NOT NULL,
    [Screener] NVARCHAR (255)   NOT NULL,
    [Data]     NVARCHAR (MAX)   NULL,
    [Added]    DATETIME         CONSTRAINT [DF_MomentumStocks_AddedDate] DEFAULT (getdate()) NULL,
    [Modified] DATETIME         NULL,
    CONSTRAINT [PK_MomentumStocks] PRIMARY KEY CLUSTERED ([Id] ASC)
);

