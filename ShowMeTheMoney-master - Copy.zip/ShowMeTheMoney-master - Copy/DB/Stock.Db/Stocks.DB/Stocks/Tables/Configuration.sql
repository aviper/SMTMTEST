﻿CREATE TABLE [Stocks].[Configuration] (
    [Id]   UNIQUEIDENTIFIER CONSTRAINT [DF_Configuration_Id] DEFAULT (newid()) NOT NULL,
    [Code] NVARCHAR (100)   NOT NULL,
    [Data] NVARCHAR (MAX)   NOT NULL,
    CONSTRAINT [PK_Configuration] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Configuration]
    ON [Stocks].[Configuration]([Code] ASC);

