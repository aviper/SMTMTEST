﻿
CREATE PROCEDURE Application.KillAllTransactions
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @killCommand NVARCHAR(MAX) = '';

    -- Generate KILL commands for all active transactions in the database
    SELECT @killCommand = @killCommand + 'KILL ' + CAST(session_id AS NVARCHAR) + '; '
    FROM sys.dm_exec_sessions
    WHERE database_id = DB_ID('sgatecoi_production') 
    AND session_id <> @@SPID;  -- Exclude the current session

    -- Execute the generated commands if any exist
    IF @killCommand <> ''
    BEGIN
        PRINT @killCommand;
        EXEC sp_executesql @killCommand;
    END
    ELSE
    BEGIN
        PRINT 'No active transactions found in sgatecoi_production.';
    END
END;