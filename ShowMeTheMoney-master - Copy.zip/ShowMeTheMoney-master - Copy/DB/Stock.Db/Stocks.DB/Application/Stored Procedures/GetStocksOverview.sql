﻿--exec [Application].[GetStocksOverview]
--exec [Application].[GetStocksOverview] null,null
CREATE   proc  [Application].[GetStocksOverview]
	@Symbol nvarchar(50)=null,
	@fromDate datetime=null,
	@toDate datetime=null		
AS

--create table #Temp
--(
--    count1 int, 
--    count2 int,
--	count3 int,
--	count4 int,
--)
declare @totalItems int
declare @CountUpTo500 int
declare @Count500To700 int
declare @Count700To1000 int
declare @CountAbove1000 int
declare @CountErrors int
declare @SectorsData int
declare @countUsers int
declare @alertHistory int
declare @stocks int
declare @StocksFilterd int
declare @StocksHistoryLastSync datetime


select @totalItems=count(1) from [Stocks].History  where (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null)
select @CountUpTo500=count(1) from [Stocks].History where (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null) and Score<=500
select @Count500To700=count(1) from [Stocks].History where  (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null) and Score>=500 and Score<=700
select @Count700To1000=count(1) from [Stocks].History where  (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null) and Score>=700 and Score <=1000
select @CountAbove1000=count(1) from [Stocks].History where  (Symbol=@Symbol or @Symbol is null or @Symbol='') and  (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null) and Score>=1000

select @SectorsData =count(1) from [Stocks].SectorsData 
select @alertHistory =count(1) from [Stocks].AlertHistory 
select @StocksFilterd =count(1) from [Stocks].Stocks  where (Added>=@fromDate or @fromDate is null) and ( Added<@toDate or @toDate is null) 
select @stocks =count(1) from [Stocks].Stocks 
SELECT TOP (1)@StocksHistoryLastSync=LastSync  FROM [Stocks].[StocksHistory] order by LastSync desc

if(@fromDate is null)
	SELECT  @CountErrors=COUNT(1)  FROM [Stocks].Logs where   (Date>=GETDATE()-1) and LogType=1 
else
	SELECT  @CountErrors=COUNT(1)  FROM [Stocks].Logs where   (Date>=@fromDate or @fromDate is null) and ( Date<@toDate or @toDate is null) and LogType=1 
select @countUsers=count(1) from Application.Users

select 
	  @totalItems as totalHistoryItems
	 ,@CountUpTo500  as CountHistoryUpTo500
	 ,@Count500To700 as CountHistory500To700
	 ,@Count700To1000 as CountHistory700To1000
	 ,@CountAbove1000  as CountHistoryAbove1000 
	 ,@CountErrors as CountErrors
	 ,@SectorsData as sSectorsData,
	  @countUsers as countUsers,
	  @alertHistory as alertHistory,
	  @stocks as stocks,
	  @StocksFilterd as StocksFilterd,
	  @StocksHistoryLastSync as StocksHistoryLastSync