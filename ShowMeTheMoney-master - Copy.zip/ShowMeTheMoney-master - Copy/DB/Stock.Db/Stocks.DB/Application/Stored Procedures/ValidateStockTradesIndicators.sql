﻿
CREATE PROCEDURE [Application].[ValidateStockTradesIndicators]
    @TradeThreshold INT = 200  -- Number of rows to skip per symbol
AS
BEGIN
    SET NOCOUNT ON;

WITH RankedTrades AS (
    SELECT 
        [Symbol],
        [IndicatorsJson],
        ROW_NUMBER() OVER (PARTITION BY [Symbol] ORDER BY TradeDate) AS rn
    FROM [History].[StockTrades]
)
SELECT DISTINCT [Symbol]
FROM RankedTrades
WHERE rn > @TradeThreshold
  AND ([IndicatorsJson] IS NULL OR [IndicatorsJson] = '{}')
END