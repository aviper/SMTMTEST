﻿-- exec [Application].[ShrinkDB] 1
CREATE  PROCEDURE [Application].[ShrinkDB]
@ForceSrink bit=0
AS
BEGIN
	declare @logSize int;

	SELECT @logSize=size FROM sys.database_files where type_desc='LOG' 
	print @logSize

	if(@logSize>50000 or @ForceSrink=1)
		begin 
			print 'ShrinkDB  Started'
			INSERT INTO [Stocks].[Logs]([ID],[LogType],[Application],[Data],[Date])VALUES(NEWID(),1,'Manager','WARN !!! ShrinkDB  Started Size WAS '+CONVERT(NVARCHAR(30), @logSize) ,GETDATE())
			--ALTER DATABASE sgatecoi_production SET RECOVERY SIMPLE
			DBCC SHRINKFILE (sgatecoi_production_log, 5)
			--ALTER DATABASE sgatecoi_production SET RECOVERY FULL
			SELECT @logSize=size FROM sys.database_files where type_desc='LOG' 
			INSERT INTO [Stocks].[Logs]([ID],[LogType],[Application],[Data],[Date])VALUES(NEWID(),1,'Manager','ShrinkDB  Completed Size shrink to '+CONVERT(NVARCHAR(30), @logSize),GETDATE())
			print 'ShrinkDB completed'
		END
		ELSE
		BEGIN
			print 'ShrinkDB not needed'
		END
END