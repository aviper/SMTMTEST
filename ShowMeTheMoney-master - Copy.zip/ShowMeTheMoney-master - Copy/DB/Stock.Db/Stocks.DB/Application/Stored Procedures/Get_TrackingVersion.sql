﻿

--exec [Application].[Get_TrackingVersion]'stocks.StocksHistory'

CREATE PROCEDURE [Application].[Get_TrackingVersion] 
    @table NVARCHAR(255) -- Expecting schema-qualified name, e.g., 'Application.GlobalSettings'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql NVARCHAR(1024);
    DECLARE @CurrentChangeTrackingVersion TABLE (current_change_tracking_version BIGINT);
    DECLARE @Version BIGINT = 0;

    -- Split schema and table name if provided in 'Schema.Table' format
    DECLARE @schemaName NVARCHAR(128);
    DECLARE @tableName NVARCHAR(128);

    IF CHARINDEX('.', @table) > 0
    BEGIN
        SET @schemaName = PARSENAME(@table, 2);
        SET @tableName = PARSENAME(@table, 1);
    END
    ELSE
    BEGIN
        SET @schemaName = 'dbo';
        SET @tableName = @table;
    END

    -- Validate that table exists and Change Tracking is enabled
    IF NOT EXISTS (
        SELECT 1
        FROM sys.change_tracking_tables ct
        JOIN sys.tables t ON t.object_id = ct.object_id
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE t.name = @tableName AND s.name = @schemaName
    )
    BEGIN
        RAISERROR('Change Tracking is not enabled for table %s.%s', 16, 1, @schemaName, @tableName);
        RETURN;
    END

    -- Build dynamic SQL safely using QUOTENAME
    SET @sql = 'SELECT MAX(SYS_CHANGE_VERSION) AS current_change_tracking_version FROM CHANGETABLE (CHANGES '
               + QUOTENAME(@schemaName) + '.' + QUOTENAME(@tableName) + ', 0) AS C';

    INSERT INTO @CurrentChangeTrackingVersion
    EXEC sp_executesql @sql;

    SELECT TOP 1 @Version = ISNULL(current_change_tracking_version, 0)
    FROM @CurrentChangeTrackingVersion;

    SELECT @Version AS DataVersion;
END;