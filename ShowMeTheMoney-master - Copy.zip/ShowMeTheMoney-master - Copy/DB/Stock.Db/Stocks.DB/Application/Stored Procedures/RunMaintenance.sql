﻿CREATE  PROCEDURE [Application].[RunMaintenance]
AS
BEGIN

-- delete old logs
delete from [Stocks].[Logs] 
WHERE [Date] <= DATEADD(d, -1, getdate()) 


-- delete stocks with no profile data (usually non-US stocks)
delete from [Stocks].Stocks 
where exists
   (select 1 from [Stocks].StocksHistory si
	where si.Symbol = [Stocks].[Stocks].Symbol
	and si.Sector like '%UNKNOWN%')


-- delete alerts for stocks with no profile data (usually non-US stocks)
delete from [Stocks].History
where exists
   (select 1 from [Stocks].StocksHistory si
	where si.Symbol = [Stocks].[History].Symbol
	and si.Sector like '%UNKNOWN%')



END