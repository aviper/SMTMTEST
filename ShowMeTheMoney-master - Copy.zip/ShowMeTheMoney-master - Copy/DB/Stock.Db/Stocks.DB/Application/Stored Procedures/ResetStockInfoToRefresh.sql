﻿
-- Drops and recreates the stored procedure
CREATE PROCEDURE [Application].[ResetStockInfoToRefresh]
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Stocks.StocksHistory
    SET 
        IsValid = 1,
        InvalidReason = NULL,
        LastInfoSync = DATEADD(DAY, -10, GETDATE()),
        LastSync = DATEADD(DAY, -10, GETDATE())
    WHERE IsValid = 0;
END;