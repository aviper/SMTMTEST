﻿--[Application].[GetDbSize]
CREATE  PROCEDURE [Application].[AVIP]
AS
BEGIN
------------------------------------------------------------
WITH RankedTrades AS (
    SELECT 
        [Symbol],
        [IndicatorsJson],
        ROW_NUMBER() OVER (PARTITION BY [Symbol] ORDER BY TradeDate) AS rn
    FROM [History].[StockTrades]
)
SELECT DISTINCT [Symbol]
FROM RankedTrades
WHERE rn > 350
  AND ([IndicatorsJson] IS NULL OR [IndicatorsJson] = '{}')

  ------------------------------------------------------------

  select count(1)  FROM [History].[StockTrades]
  SELECT TOP (10000) [Id]
      ,[TradeDate]
      
      ,[IndicatorsJson]
      ,[Symbol]
  FROM [History].[StockTrades] where  [Symbol]='COMM' and [IndicatorsJson]='{}' order by TradeDate --desc

 DELETE FROM [History].[StockTrades]
WHERE [Symbol] IN (
  'COMM'
);

SELECT [Symbol]
FROM [History].[StockTrades]
GROUP BY [Symbol]
HAVING COUNT(*) = SUM(CASE WHEN [IndicatorsJson] = '{}' THEN 1 ELSE 0 END)

--ARQQW
--FLUT
--delete from History.StockTrades where Symbol='ARQQW' order by TradeDate 

--SELECT DISTINCT st.Symbol
--FROM [History].[StockTrades] st
--INNER JOIN [Stocks].[StocksHistory] sh
--    ON st.Symbol = sh.Symbol
--WHERE sh.IsValid = 0
----update stocks.StocksHistory set IsValid=0 where Symbol in('FLUT','ARQQW')
DECLARE @IndicatorFilter NVARCHAR(100) = 'stra%';

SELECT 
   -- [Symbol],
    [IndicatorName],
    AVG(Day4_AvgProfit) AS Avg_Day4_AvgProfit,
    AVG(Day5_AvgProfit) AS Avg_Day5_AvgProfit,
    AVG(Day6_AvgProfit) AS Avg_Day6_AvgProfit,
    AVG(Day7_AvgProfit) AS Avg_Day7_AvgProfit,
    AVG(Day8_AvgProfit) AS Avg_Day8_AvgProfit,
    AVG(Day9_AvgProfit) AS Avg_Day9_AvgProfit,
    AVG(Day10_AvgProfit) AS Avg_Day10_AvgProfit,
    AVG(CompositeScore) AS Avg_CompositeScore,
    (
        AVG(Day4_AvgProfit) +
        AVG(Day5_AvgProfit) +
        AVG(Day6_AvgProfit) +
        AVG(Day7_AvgProfit) +
        AVG(Day8_AvgProfit) +
        AVG(Day9_AvgProfit) +
        AVG(Day10_AvgProfit)
    ) / 7 AS Avg_AllDays_Profit
FROM 
    [History].[StockTradeSummary]
WHERE 
    IndicatorName LIKE @IndicatorFilter --and Symbol='QQQ'
GROUP BY 
    [Symbol], [IndicatorName]
ORDER BY 
   Avg_AllDays_Profit DESC;

SELECT 
    
    [IndicatorName],
    AVG(Day4_AvgProfit) AS Avg_Day4_AvgProfit,
    AVG(Day5_AvgProfit) AS Avg_Day5_AvgProfit,
    AVG(Day6_AvgProfit) AS Avg_Day6_AvgProfit,
    AVG(Day7_AvgProfit) AS Avg_Day7_AvgProfit,
    AVG(Day8_AvgProfit) AS Avg_Day8_AvgProfit,
    AVG(Day9_AvgProfit) AS Avg_Day9_AvgProfit,
    AVG(Day10_AvgProfit) AS Avg_Day10_AvgProfit,
    AVG(CompositeScore) AS Avg_CompositeScore,
    (
        AVG(Day4_AvgProfit) +
        AVG(Day5_AvgProfit) +
        AVG(Day6_AvgProfit) +
        AVG(Day7_AvgProfit) +
        AVG(Day8_AvgProfit) +
        AVG(Day9_AvgProfit) +
        AVG(Day10_AvgProfit)
    ) / 7 AS Avg_AllDays_Profit
FROM 
    [History].[StockTradeSummary]
WHERE 
    IndicatorName LIKE @IndicatorFilter-- and Symbol='AMZN'
GROUP BY 
     [IndicatorName]
ORDER BY 
    Avg_AllDays_Profit DESC;




    ----------------------------
    WITH MSFTTrades AS (
    SELECT
        ProfitDay6,
        IndicatorsJson
    FROM [History].[StockTrades]
    WHERE Symbol in (SELECT Symbol
    FROM Stocks.StocksHistory
    WHERE MarketCap > 1000000000000 or MarketCap=-1 and IsValid=1)-- = 'MSFT'
      AND ProfitDay6 IS NOT NULL
), Ranked AS (
    SELECT
        ProfitDay6,
        IndicatorsJson,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 DESC) AS TopRank,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 ASC) AS BottomRank
    FROM MSFTTrades
), Expanded AS (
    SELECT
        r.TopRank,
        r.BottomRank,
        j.[key] AS Indicator,
        TRY_CAST(j.[value] AS INT) AS IndicatorValue
    FROM Ranked r
    CROSS APPLY OPENJSON(r.IndicatorsJson) AS j
)
SELECT
    Indicator,
    SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInTop20,
    SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInBottom20,
    COUNT(*) AS TotalCount,
    CAST(SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS FLOAT) /
    NULLIF(SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END), 0) AS TopBottomRatio
FROM Expanded
GROUP BY Indicator
ORDER BY TopBottomRatio DESC, AppearInTop20 DESC;


    ----------------------------

    WITH MSFTTrades AS (
    SELECT
        ProfitDay6,
        IndicatorsJson
    FROM [History].[StockTrades]
    WHERE Symbol = 'MSFT'
      AND ProfitDay6 IS NOT NULL
), Ranked AS (
    SELECT
        ProfitDay6,
        IndicatorsJson,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 DESC) AS TopRank,
        ROW_NUMBER() OVER (ORDER BY ProfitDay6 ASC) AS BottomRank
    FROM MSFTTrades
), Expanded AS (
    SELECT
        r.TopRank,
        r.BottomRank,
        j.[key] AS Indicator,
        TRY_CAST(j.[value] AS INT) AS IndicatorValue
    FROM Ranked r
    CROSS APPLY OPENJSON(r.IndicatorsJson) AS j
)
SELECT
    Indicator,
    SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInTop20,
    SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS AppearInBottom20,
    COUNT(*) AS TotalCount,
    CAST(SUM(CASE WHEN TopRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END) AS FLOAT) /
    NULLIF(SUM(CASE WHEN BottomRank <= 20 AND IndicatorValue > 0 THEN 1 ELSE 0 END), 0) AS TopBottomRatio
FROM Expanded
GROUP BY Indicator
ORDER BY TopBottomRatio DESC, AppearInTop20 DESC;
----------------------------------------

SELECT  
    COUNT(*) AS TotalTrades,
    SUM(ProfitDay6) AS TotalProfitDay6,
    
    -- Positive and Negative Day Counts
    COUNT(CASE WHEN ProfitDay6 > 0 THEN 1 END) AS NumPositiveDays,
    COUNT(CASE WHEN ProfitDay6 < 0 THEN 1 END) AS NumNegativeDays,
    
    -- Win Rate (%)
    CAST(COUNT(CASE WHEN ProfitDay6 > 0 THEN 1 END) AS FLOAT) / 
    NULLIF(COUNT(*), 0) AS WinRate,
    
    -- Profit Factor (Total Gain / Absolute Loss)
    SUM(CASE WHEN ProfitDay6 > 0 THEN ProfitDay6 END) /
    NULLIF(ABS(SUM(CASE WHEN ProfitDay6 < 0 THEN ProfitDay6 END)), 0) AS ProfitFactor,
    
    -- Average Win / Loss
    AVG(CASE WHEN ProfitDay6 > 0 THEN ProfitDay6 END) AS AvgPositiveProfit,
    AVG(CASE WHEN ProfitDay6 < 0 THEN ProfitDay6 END) AS AvgNegativeLoss,
    
    -- Positive / Negative Ratio
    CAST(COUNT(CASE WHEN ProfitDay6 > 0 THEN 1 END) AS FLOAT) / 
    NULLIF(COUNT(CASE WHEN ProfitDay6 < 0 THEN 1 END), 0) AS PositiveNegativeRatio

FROM [History].[StockTrades]
WHERE Symbol = 'tsla'
  AND TradeDate > '2020-01-01'
  AND IndicatorsJson LIKE '%isBetaBearish%'
  AND (
        IndicatorsJson LIKE '%TechnicalIsBullishCrossover%' OR
        IndicatorsJson LIKE '%TechnicalIsBullishMomentum%' OR 
        IndicatorsJson LIKE '%TechnicalIsBullishUptrend%'
      );



END