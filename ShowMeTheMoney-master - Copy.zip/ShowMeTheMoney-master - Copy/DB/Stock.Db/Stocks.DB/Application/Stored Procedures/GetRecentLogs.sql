﻿

--exec [Application].[GetRecentLogs] 1,1000,2

CREATE   proc  [Application].[GetRecentLogs]
				@logType            int,
				@count              int=30,
				@lastDays			int =30,
				@application		nvarchar(50)=null

AS
	select top (@count)*  from [Stocks].[Logs] 
	WHERE  [Date] >= DATEADD(d, -@lastDays, getdate()) and LogType<=@logType and ( Application= @application  or @application='' or @application is null) order by [Date] desc