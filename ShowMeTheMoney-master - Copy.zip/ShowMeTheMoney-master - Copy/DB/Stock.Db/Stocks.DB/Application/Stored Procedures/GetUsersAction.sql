﻿

--exec [Application].[GetUsersAction] 'SENDFINVIZ'

CREATE   proc  [Application].[GetUsersAction]
				@Actioncode            nvarchar(50)
AS
	select *  from Application.UsersActionView
	WHERE  Code=@Actioncode