﻿
-- Create the stored procedure to delete data from multiple tables in batches
CREATE PROCEDURE [Application].[sp_DeleteAllStrategiesStocksTables]
AS
BEGIN
    -- Declare the list of tables and schemas to delete data from
    DECLARE @TablesToDelete TABLE (SchemaName NVARCHAR(128), TableName NVARCHAR(128));
	truncate table History.StockTrades
    -- Insert the tables into the table variable
    INSERT INTO @TablesToDelete (SchemaName, TableName)
    VALUES
        ('Stocks', 'NasdaqStocks'),
        ('Strategies', 'StrategiesStocksHistory'),
        ('Strategies', 'StrategiesStocksModels'),
        ('Stocks', 'StocksHistory'),
        ('History', 'StockTrades'),
        ('Stocks', 'Stocks');

    -- Declare variables for the cursor
    DECLARE @SchemaName NVARCHAR(128);
    DECLARE @TableName NVARCHAR(128);

    -- Declare cursor to loop through the table list
    DECLARE table_cursor CURSOR FOR 
    SELECT SchemaName, TableName FROM @TablesToDelete;

    -- Open the cursor
    OPEN table_cursor;

    -- Fetch the first row
    FETCH NEXT FROM table_cursor INTO @SchemaName, @TableName;

    -- Loop through all tables in the list
    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Print the current operation (optional, can be removed in production)
        PRINT CONCAT('Deleting data from ', @SchemaName, '.', @TableName);

        -- Call the previously created stored procedure for each table
        EXEC [Application].[sp_DeleteTableInBatches] @SchemaName = @SchemaName, @TableName = @TableName;

        -- Fetch the next row
        FETCH NEXT FROM table_cursor INTO @SchemaName, @TableName;
    END

    -- Close and deallocate the cursor
    CLOSE table_cursor;
    DEALLOCATE table_cursor;

    -- Print a final message (optional, can be removed in production)
    PRINT 'All deletions completed.';
END;