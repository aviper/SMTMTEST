﻿
-- Create stored procedure to delete records in batches from a specified table and schema
CREATE PROCEDURE [Application].[sp_DeleteTableInBatches]
    @SchemaName NVARCHAR(128), -- Schema name of the table
    @TableName NVARCHAR(128)   -- Table name to delete records from
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @BatchSize INT = 50000;  -- Adjust batch size based on log space
    DECLARE @TotalDeleted INT = 0;   -- Variable to track total rows deleted
    DECLARE @RowsDeleted INT = 0;    -- Rows deleted in each batch
    DECLARE @Sql NVARCHAR(MAX);      -- Dynamic SQL query for deleting records

    -- Step 1: Check if the table exists in the given schema
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = @SchemaName AND TABLE_NAME = @TableName)
    BEGIN
        PRINT CONCAT('Table ', @SchemaName, '.', @TableName, ' does not exist.');
        RETURN;
    END

    -- Step 2: Begin the delete process
    PRINT 'Deletion process started at ' + CONVERT(VARCHAR, GETDATE());

    -- Dynamic SQL to delete rows from the specified table
    SET @Sql = N'SELECT TOP(1) 1 FROM [' + @SchemaName + N'].[' + @TableName + N']';

    -- Loop until no more rows are left
    WHILE (1=1)
    BEGIN
        -- Dynamic DELETE command for the given table
        SET @Sql = N'DELETE TOP (@BatchSize) FROM [' + @SchemaName + N'].[' + @TableName + N']';

        -- Execute the dynamic SQL
        EXEC sp_executesql @Sql, N'@BatchSize INT', @BatchSize;

        -- Get the number of rows deleted in this batch
        SET @RowsDeleted = @@ROWCOUNT;

        -- If rows are deleted, print progress
        IF @RowsDeleted > 0
        BEGIN
            -- Print progress for each batch
            PRINT CONCAT('Deleted ', @RowsDeleted, ' rows from ', @SchemaName, '.', @TableName, ' at ', GETDATE());

            -- Accumulate total deleted rows
            SET @TotalDeleted = @TotalDeleted + @RowsDeleted;

            -- Print the total rows deleted so far
            PRINT CONCAT('Total rows deleted so far: ', @TotalDeleted, ' at ', GETDATE());
        END
        ELSE
        BEGIN
            -- If no rows are deleted, break the loop
            PRINT CONCAT('No more rows to delete from ', @SchemaName, '.', @TableName, '. Exiting loop.');
            BREAK;
        END

        -- Ensure transaction log is flushed to disk and avoid excessive log growth
        CHECKPOINT;

        -- Small delay to reduce locking and system strain
        WAITFOR DELAY '00:00:01';  
    END

    -- Final log when all deletions are done
    PRINT CONCAT('Deletion process completed for table ', @SchemaName, '.', @TableName, '. Total rows deleted: ', @TotalDeleted, ' at ', GETDATE());
END;