﻿CREATE PROCEDURE [Application].[GetSqlServerStatus]
AS
BEGIN
    SET NOCOUNT ON;

    ------------------------------------------------------------
    -- 1. Active User Sessions
    ------------------------------------------------------------
    SELECT 
        s.session_id,
        s.login_name,
        s.host_name,
        s.program_name,
        s.client_interface_name,
        s.login_time,
        s.last_request_start_time,
        s.last_request_end_time,
        s.status
    FROM sys.dm_exec_sessions s
    WHERE s.is_user_process = 1;

    ------------------------------------------------------------
    -- 2. Active Requests (Currently Executing Queries)
    ------------------------------------------------------------
    SELECT 
        r.session_id,
        s.login_name,
        s.host_name,
        r.status,
        r.command,
        r.start_time,
        r.cpu_time,
        r.total_elapsed_time,
        t.text AS query_text
    FROM sys.dm_exec_requests r
    JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id
    CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t;

    ------------------------------------------------------------
    -- 3. Connection Count by Host
    ------------------------------------------------------------
    SELECT 
        s.host_name,
        COUNT(s.session_id) AS connection_count
    FROM sys.dm_exec_sessions s
    WHERE s.is_user_process = 1
    GROUP BY s.host_name
    ORDER BY connection_count DESC;

    ------------------------------------------------------------
    -- 4. Running Transactions
    ------------------------------------------------------------
    SELECT 
        at.transaction_id,
        at.name AS transaction_name,
        at.transaction_begin_time,
        at.transaction_type,
        at.transaction_state,
        s.session_id,
        s.login_name,
        s.host_name,
        r.status AS request_status,
        r.command,
        r.start_time AS request_start_time,
        t.text AS sql_text
    FROM sys.dm_tran_active_transactions at
    JOIN sys.dm_tran_session_transactions st ON at.transaction_id = st.transaction_id
    JOIN sys.dm_exec_sessions s ON st.session_id = s.session_id
    LEFT JOIN sys.dm_exec_requests r ON s.session_id = r.session_id
    OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) t
    WHERE at.transaction_state <> 0
    ORDER BY at.transaction_begin_time;

END