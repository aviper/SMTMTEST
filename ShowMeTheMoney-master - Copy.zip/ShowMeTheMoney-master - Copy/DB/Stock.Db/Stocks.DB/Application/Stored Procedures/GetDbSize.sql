﻿--[Application].[GetDbSize]
CREATE  PROCEDURE [Application].[GetDbSize]
AS
BEGIN


SELECT file_id, name, type_desc,  size, max_size  
FROM sys.database_files ;  
END