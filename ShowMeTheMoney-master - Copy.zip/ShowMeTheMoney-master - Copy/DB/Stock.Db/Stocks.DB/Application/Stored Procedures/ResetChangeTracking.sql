﻿
CREATE PROCEDURE [Application].[ResetChangeTracking]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @tableName NVARCHAR(512);
    DECLARE @schemaName NVARCHAR(128);
    DECLARE @sql NVARCHAR(MAX);
    DECLARE @trackColumns BIT;

    DECLARE cur CURSOR FOR
    SELECT 
        s.name AS SchemaName,
        t.name AS TableName,
        ct.is_track_columns_updated_on
    FROM sys.change_tracking_tables ct
    JOIN sys.tables t ON ct.object_id = t.object_id
    JOIN sys.schemas s ON t.schema_id = s.schema_id;

    OPEN cur;
    FETCH NEXT FROM cur INTO @schemaName, @tableName, @trackColumns;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT 'Resetting Change Tracking for: ' + QUOTENAME(@schemaName) + '.' + QUOTENAME(@tableName);

        -- Disable change tracking
        SET @sql = 'ALTER TABLE ' + QUOTENAME(@schemaName) + '.' + QUOTENAME(@tableName) + ' DISABLE CHANGE_TRACKING;';
        EXEC sp_executesql @sql;

        -- Re-enable change tracking with previous setting
        SET @sql = 'ALTER TABLE ' + QUOTENAME(@schemaName) + '.' + QUOTENAME(@tableName) + 
                   ' ENABLE CHANGE_TRACKING WITH (TRACK_COLUMNS_UPDATED = ' + 
                   CASE WHEN @trackColumns = 1 THEN 'ON' ELSE 'OFF' END + ');';
        EXEC sp_executesql @sql;

        FETCH NEXT FROM cur INTO @schemaName, @tableName, @trackColumns;
    END

    CLOSE cur;
    DEALLOCATE cur;

    PRINT 'Change Tracking reset completed for all tracked tables.';
END