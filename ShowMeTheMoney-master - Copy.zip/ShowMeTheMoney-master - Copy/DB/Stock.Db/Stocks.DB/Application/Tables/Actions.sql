﻿CREATE TABLE [Application].[Actions] (
    [Id]          UNIQUEIDENTIFIER CONSTRAINT [DF_Action_Id] DEFAULT (newid()) NOT NULL,
    [Name]        NVARCHAR (50)    NOT NULL,
    [Description] NVARCHAR (255)   NULL,
    [Code]        NVARCHAR (255)   NULL,
    [Deleted]     BIT              CONSTRAINT [DF_Action_Deleted] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_Roles_1] PRIMARY KEY CLUSTERED ([Id] ASC)
);

