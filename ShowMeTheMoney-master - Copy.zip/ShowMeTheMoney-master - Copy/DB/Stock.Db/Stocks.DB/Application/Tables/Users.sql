﻿CREATE TABLE [Application].[Users] (
    [Id]              UNIQUEIDENTIFIER CONSTRAINT [DF_users_Id] DEFAULT (newid()) NOT NULL,
    [UserName]        NVARCHAR (50)    NULL,
    [RealName]        NVARCHAR (50)    NULL,
    [Title]           NVARCHAR (10)    NULL,
    [Password]        NVARCHAR (255)   NULL,
    [Enable]          BIT              NOT NULL,
    [IsDeleted]       BIT              NOT NULL,
    [Email]           NVARCHAR (80)    NULL,
    [SendEmailEnable] BIT              CONSTRAINT [DF_Users_SendEmainEnable] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_users_1] PRIMARY KEY CLUSTERED ([Id] ASC)
);

