﻿CREATE TABLE [Application].[UserActions] (
    [UserId]   UNIQUEIDENTIFIER NOT NULL,
    [ActionId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_UserActions] PRIMARY KEY CLUSTERED ([UserId] ASC, [ActionId] ASC),
    CONSTRAINT [FK_UserActions_Actions] FOREIGN KEY ([ActionId]) REFERENCES [Application].[Actions] ([Id]),
    CONSTRAINT [FK_UserActions_Users] FOREIGN KEY ([UserId]) REFERENCES [Application].[Users] ([Id])
);

