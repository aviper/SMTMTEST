﻿CREATE TABLE [Application].[ApplicationData] (
    [Id]   UNIQUEIDENTIFIER CONSTRAINT [DF_ApplicationData_Id] DEFAULT (newid()) NOT NULL,
    [Name] NVARCHAR (50)    NOT NULL,
    [Type] NVARCHAR (50)    NOT NULL,
    [Data] NVARCHAR (MAX)   NOT NULL,
    CONSTRAINT [PK_ApplicationData] PRIMARY KEY CLUSTERED ([Id] ASC)
);

