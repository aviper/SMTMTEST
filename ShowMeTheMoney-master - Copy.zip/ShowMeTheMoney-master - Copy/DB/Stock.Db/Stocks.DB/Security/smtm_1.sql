﻿CREATE USER [smtm] FOR LOGIN [smtm];

