﻿CREATE LOGIN [smtm] WITH PASSWORD = 'YourStrongPasswordHere';
GO
