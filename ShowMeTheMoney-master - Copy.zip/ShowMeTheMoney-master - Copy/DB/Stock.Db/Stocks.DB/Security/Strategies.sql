﻿CREATE SCHEMA [Strategies]
    AUTHORIZATION [dbo];



