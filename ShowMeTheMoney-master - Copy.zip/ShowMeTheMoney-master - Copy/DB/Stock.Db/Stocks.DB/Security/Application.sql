﻿CREATE SCHEMA [Application]
    AUTHORIZATION [dbo];

