﻿
CREATE VIEW [Reports].[StockPerformanceSummaryView]
AS
SELECT TOP (100) PERCENT 
    st.Symbol, 
    si.CompanyName, 
    si.Sector, 
    si.Industry, 
    si.MarketCap, 
    si.LastPrice, 
    si.FiftyTwoWeekLow, 
    si.FiftyTwoWeekHigh, 
    si.EarningsDate, 
    si.AverageDailyVolume3Month, 
    COUNT(DISTINCT st.Id) AS TotalStockTrades, 
    COUNT(i.[value]) AS TotalStockTradeIndicators
FROM  [Stocks].StocksHistory AS si 
LEFT JOIN History.StockTrades AS st ON si.Symbol = st.Symbol
OUTER APPLY OPENJSON(st.IndicatorsJson) AS i
GROUP BY 
    st.Symbol, si.CompanyName, si.Sector, si.Industry, si.MarketCap, 
    si.LastPrice, si.FiftyTwoWeekLow, si.FiftyTwoWeekHigh, 
    si.EarningsDate, si.AverageDailyVolume3Month;