﻿CREATE VIEW Reports.[StocksHistoryMarketPerformanceView]
AS
SELECT        s.Symbol, si.CompanyName, si.Sector, si.Industry, si.MarketCap, si.LastPrice, si.FiftyTwoWeekLow, si.FiftyTwoWeekHigh, si.AverageDailyVolume3Month, si.EarningsDate, si.LastSync, si.IsValid, si.InvalidReason,
                         si.LastPrice - si.FiftyTwoWeekLow AS PriceAbove52WeekLow, si.FiftyTwoWeekHigh - si.LastPrice AS PriceBelow52WeekHigh
FROM            [Stocks].Stocks AS s INNER JOIN
                         [Stocks].StocksHistory AS si ON si.Symbol = s.Symbol
GO
