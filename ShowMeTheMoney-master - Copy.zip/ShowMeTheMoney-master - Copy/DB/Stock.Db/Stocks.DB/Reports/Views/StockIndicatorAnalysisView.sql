﻿CREATE VIEW Reports.[StockIndicatorAnalysisView]
AS
SELECT
    t.Symbol AS Symbol,
    CAST(j.[key] AS NVARCHAR(100)) AS IndicatorName,
   TRY_CAST(j.[value] AS INT) AS Value,
    t.TradeDate as LastUpdate
FROM
    History.StockTrades AS t
CROSS APPLY OPENJSON(t.IndicatorsJson) AS j
GO