﻿CREATE VIEW Reports.[StockIndicatorActivityView]
AS
SELECT 
    Symbol, 
    COUNT(TRY_CAST(j.[value] AS DECIMAL(18, 4))) AS TotalIndicators, 
    AVG(TRY_CAST(j.[value] AS DECIMAL(18, 4))) AS AvgIndicatorValue, 
    MAX(TRY_CAST(j.[value] AS DECIMAL(18, 4))) AS MaxIndicatorValue, 
    MIN(TRY_CAST(j.[value] AS DECIMAL(18, 4))) AS MinIndicatorValue
FROM  History.StockTrades
CROSS APPLY OPENJSON(IndicatorsJson) AS j

GROUP BY Symbol;
GO
