﻿CREATE TABLE [Reports].[TradeStatsResults] (
    [RunDate]               DATETIME       DEFAULT (getdate()) NULL,
    [IndicatorFilter]       NVARCHAR (200) NULL,
    [TotalTrades]           INT            NULL,
    [TotalProfitDay5]       FLOAT (53)     NULL,
    [AvgProfitDay5]         FLOAT (53)     NULL,
    [NumPositiveDays]       INT            NULL,
    [NumNegativeDays]       INT            NULL,
    [WinRate]               FLOAT (53)     NULL,
    [ProfitFactor]          FLOAT (53)     NULL,
    [AvgPositiveProfit]     FLOAT (53)     NULL,
    [AvgNegativeLoss]       FLOAT (53)     NULL,
    [PositiveNegativeRatio] FLOAT (53)     NULL,
    [TotalProfitDay6]       FLOAT (53)     NULL,
    [TotalProfitDay7]       FLOAT (53)     NULL,
    [TotalProfitDay8]       FLOAT (53)     NULL,
    [TotalProfitDay9]       FLOAT (53)     NULL,
    [TotalProfitDay10]      FLOAT (53)     NULL
);

