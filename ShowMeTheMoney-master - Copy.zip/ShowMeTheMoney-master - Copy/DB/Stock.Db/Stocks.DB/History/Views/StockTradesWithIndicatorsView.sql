﻿CREATE VIEW History.[StockTradesWithIndicatorsView]
AS
SELECT        
    t.Id AS TradeId, 
    T.Symbol AS Symbol, 
    t.TradeDate, 
    t.OpenPrice, 
    t.ClosePrice, 
    t.AdjustedClose,
    t.HighPrice, 
    t.LowPrice, 
    t.Volume, 
    t.ProfitDay1, 
    t.ProfitDay2, 
    t.ProfitDay3, 
    t.ProfitDay4, 
    t.ProfitDay5, 
    t.ProfitDay6, 
    t.ProfitDay7, 
    t.ProfitDay8, 
    t.ProfitDay9, 
    t.ProfitDay10, 
    t.ProfitDay20, 
    t.ProfitDay30, 
    t.Beta, 
    t.RawData, 
     CAST(j.[key] AS NVARCHAR(100)) AS IndicatorName,
        TRY_CAST(j.[value] AS INT) AS IndicatorValue
FROM History.StockTrades AS t
CROSS APPLY OPENJSON(t.IndicatorsJson) AS j  

GO