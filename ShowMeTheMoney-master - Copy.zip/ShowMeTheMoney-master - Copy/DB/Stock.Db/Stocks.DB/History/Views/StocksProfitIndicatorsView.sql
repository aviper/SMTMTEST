﻿CREATE VIEW History.StocksProfitIndicatorsView
AS

SELECT
    CAST(j.[key] AS NVARCHAR(100)) AS IndicatorName,

    -- Day 1
    SUM(CASE WHEN sst.ProfitDay1 > 0 THEN 1 ELSE 0 END) AS Day1_Positive,
    SUM(CASE WHEN sst.ProfitDay1 <= 0 THEN 1 ELSE 0 END) AS Day1_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay1 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay1), 0) AS DECIMAL(5, 2)) AS Day1_UpRatio,

    -- Day 2
    SUM(CASE WHEN sst.ProfitDay2 > 0 THEN 1 ELSE 0 END) AS Day2_Positive,
    SUM(CASE WHEN sst.ProfitDay2 <= 0 THEN 1 ELSE 0 END) AS Day2_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay2 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay2), 0) AS DECIMAL(5, 2)) AS Day2_UpRatio,

    -- Day 3
    SUM(CASE WHEN sst.ProfitDay3 > 0 THEN 1 ELSE 0 END) AS Day3_Positive,
    SUM(CASE WHEN sst.ProfitDay3 <= 0 THEN 1 ELSE 0 END) AS Day3_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay3 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay3), 0) AS DECIMAL(5, 2)) AS Day3_UpRatio,

    -- Day 4
    SUM(CASE WHEN sst.ProfitDay4 > 0 THEN 1 ELSE 0 END) AS Day4_Positive,
    SUM(CASE WHEN sst.ProfitDay4 <= 0 THEN 1 ELSE 0 END) AS Day4_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay4 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay4), 0) AS DECIMAL(5, 2)) AS Day4_UpRatio,

    -- Day 5
    SUM(CASE WHEN sst.ProfitDay5 > 0 THEN 1 ELSE 0 END) AS Day5_Positive,
    SUM(CASE WHEN sst.ProfitDay5 <= 0 THEN 1 ELSE 0 END) AS Day5_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay5 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay5), 0) AS DECIMAL(5, 2)) AS Day5_UpRatio,

    -- Day 6
    SUM(CASE WHEN sst.ProfitDay6 > 0 THEN 1 ELSE 0 END) AS Day6_Positive,
    SUM(CASE WHEN sst.ProfitDay6 <= 0 THEN 1 ELSE 0 END) AS Day6_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay6 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay6), 0) AS DECIMAL(5, 2)) AS Day6_UpRatio,

    -- Day 7
    SUM(CASE WHEN sst.ProfitDay7 > 0 THEN 1 ELSE 0 END) AS Day7_Positive,
    SUM(CASE WHEN sst.ProfitDay7 <= 0 THEN 1 ELSE 0 END) AS Day7_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay7 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay7), 0) AS DECIMAL(5, 2)) AS Day7_UpRatio,

    -- Day 8
    SUM(CASE WHEN sst.ProfitDay8 > 0 THEN 1 ELSE 0 END) AS Day8_Positive,
    SUM(CASE WHEN sst.ProfitDay8 <= 0 THEN 1 ELSE 0 END) AS Day8_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay8 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay8), 0) AS DECIMAL(5, 2)) AS Day8_UpRatio,

    -- Day 9
    SUM(CASE WHEN sst.ProfitDay9 > 0 THEN 1 ELSE 0 END) AS Day9_Positive,
    SUM(CASE WHEN sst.ProfitDay9 <= 0 THEN 1 ELSE 0 END) AS Day9_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay9 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay9), 0) AS DECIMAL(5, 2)) AS Day9_UpRatio,

    -- Day 10
    SUM(CASE WHEN sst.ProfitDay10 > 0 THEN 1 ELSE 0 END) AS Day10_Positive,
    SUM(CASE WHEN sst.ProfitDay10 <= 0 THEN 1 ELSE 0 END) AS Day10_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay10 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay10), 0) AS DECIMAL(5, 2)) AS Day10_UpRatio,

    -- Day 20
    SUM(CASE WHEN sst.ProfitDay20 > 0 THEN 1 ELSE 0 END) AS Day20_Positive,
    SUM(CASE WHEN sst.ProfitDay20 <= 0 THEN 1 ELSE 0 END) AS Day20_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay20 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay20), 0) AS DECIMAL(5, 2)) AS Day20_UpRatio,

    -- Day 30
    SUM(CASE WHEN sst.ProfitDay30 > 0 THEN 1 ELSE 0 END) AS Day30_Positive,
    SUM(CASE WHEN sst.ProfitDay30 <= 0 THEN 1 ELSE 0 END) AS Day30_Negative,
    CAST(SUM(CASE WHEN sst.ProfitDay30 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay30), 0) AS DECIMAL(5, 2)) AS Day30_UpRatio

FROM History.StockTrades AS sst
CROSS APPLY OPENJSON(sst.IndicatorsJson) AS j
GROUP BY j.[key];
GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPaneCount', @value = 1, @level0type = N'SCHEMA', @level0name = N'History', @level1type = N'VIEW', @level1name = N'StocksProfitIndicatorsView';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane1', @value = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', @level0type = N'SCHEMA', @level0name = N'History', @level1type = N'VIEW', @level1name = N'StocksProfitIndicatorsView';

