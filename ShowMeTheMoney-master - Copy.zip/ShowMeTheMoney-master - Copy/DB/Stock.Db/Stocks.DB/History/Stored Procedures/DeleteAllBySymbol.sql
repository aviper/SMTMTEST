﻿--exec [History].[DeleteAllBySymbol] 'MSFT'
CREATE PROCEDURE [History].[DeleteAllBySymbol]
    @Symbol varchar(5),
    @FromDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Delete data from StockTrades based on FromDate if provided
        DELETE FROM [History].StockTrades
        WHERE Symbol = @Symbol
          AND (@FromDate IS NULL OR TradeDate >= @FromDate);

        COMMIT TRANSACTION;

        PRINT 'Records deleted successfully for the specified StockId and optional FromDate.';
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        -- Handle errors
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END