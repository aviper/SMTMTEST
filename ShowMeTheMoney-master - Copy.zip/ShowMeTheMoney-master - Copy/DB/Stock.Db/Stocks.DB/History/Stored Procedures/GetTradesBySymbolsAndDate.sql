﻿
--EXEC [History].[GetTradesBySymbolsAndDate]    @Symbols ='BHP,EWBC,CRK,KMB,DEO,GTY,ELP,ARLP,AVT,CCEP,FCN,LCII,ATRO,MSI',    @EndDate = null,    @NumWeeks = 5;
--EXEC [History].[GetTradesBySymbolsAndDate]    @Symbols ='BHP',    @EndDate = null,    @NumWeeks = 5;
--EXEC [History].[GetTradesBySymbolsAndDate]    @Symbols =null,    @EndDate = null,    @NumWeeks = 5;

CREATE PROCEDURE [History].[GetTradesBySymbolsAndDate]
    @Symbols    NVARCHAR(MAX) = NULL,  -- Comma-separated list of symbols (optional)
    @EndDate    DATE         = NULL,   -- End date for filtering trades
    @NumWeeks    INT          = 5,      -- Number of rows to retrieve per Symbol
    @Weeks      INT          = 1       -- Number of weeks to look back for possible trades
WITH RECOMPILE
AS
BEGIN
    SET NOCOUNT ON;

    IF @EndDate IS NULL
        SET @EndDate = GETDATE();

    DECLARE @StartDate DATE = DATEADD(DAY, -7 * @Weeks * @NumWeeks, @EndDate);

    -- Step 1: Prepare symbol -> stockId mapping
    DECLARE @TargetStockIds TABLE (
        StockId UNIQUEIDENTIFIER PRIMARY KEY,
        Symbol  NVARCHAR(50) NOT NULL
    );

    IF @Symbols IS NULL
    BEGIN
        INSERT INTO @TargetStockIds (StockId, Symbol)
        SELECT s.Id, s.Symbol
        FROM [Stocks].Stocks s
        LEFT JOIN [Stocks].StocksHistory sh ON s.Symbol = sh.Symbol
        WHERE sh.IsValid = 1;
    END
    ELSE
    BEGIN
        INSERT INTO @TargetStockIds (StockId, Symbol)
        SELECT s.Id, s.Symbol
        FROM [Stocks].Stocks s
        JOIN (
            SELECT TRIM([value]) AS Symbol
            FROM STRING_SPLIT(@Symbols, ',')
        ) src ON s.Symbol = src.Symbol;
    END

    -- Step 2: Fetch latest N rows per stock using ROW_NUMBER
    ;WITH FilteredTrades AS (
        SELECT
            st.Symbol,
            st.Id,
            st.TradeDate,
            st.OpenPrice,
            st.ClosePrice,
            st.AdjustedClose,
            st.HighPrice,
            st.LowPrice,
            st.Volume,
            ROW_NUMBER() OVER (PARTITION BY st.Id ORDER BY st.TradeDate DESC) AS RowNum
        FROM [History].[StockTrades] st
        WHERE st.TradeDate BETWEEN @StartDate AND @EndDate
    )
    SELECT 
        Symbol,
        Id,
        TradeDate,
        OpenPrice,
        ClosePrice,
        AdjustedClose,
        HighPrice,
        LowPrice,
        Volume
    FROM FilteredTrades
    WHERE RowNum <= @NumWeeks
    ORDER BY Symbol, TradeDate DESC;
END




