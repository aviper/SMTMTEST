﻿--exec [History].[Populate_StockTradeSummary_Batch] 'Technology,index,etf',null,1
--exec [History].[Populate_StockTradeSummary_Batch] null,null,null,1,'_2022'
--exec [History].[Populate_StockTradeSummary_Batch] null,null,null,1,null
--exec [History].[Populate_StockTradeSummary_Batch] null,'2020-01-01',null,1,null



CREATE PROCEDURE [History].[Populate_StockTradeSummary_Batch]
    @Sectors NVARCHAR(MAX) = NULL,       -- NULL = all sectors; otherwise comma-separated list
    @FromDate DATE = '2020-01-01',               -- Only include data from this date forward
    @ToDate DATE = NULL,                 -- Only include data up to this date
    @Truncate BIT = 0,                   -- Whether to truncate target table before population (default: no)
    @TableSuffix NVARCHAR(50) = ''       -- Table name suffix, e.g., '', '_2020', '_2021', ...
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Sector NVARCHAR(100);
    DECLARE @SectorList TABLE (Sector NVARCHAR(100));
    DECLARE @TotalRowsInserted INT = 0;
    DECLARE @FinalStatus NVARCHAR(50) = 'Success';
    DECLARE @SchemaName NVARCHAR(50) = 'History';


DECLARE @TargetTable NVARCHAR(128);
SET @TargetTable = QUOTENAME(@SchemaName) + '.' + QUOTENAME('StockTradeSummary' + ISNULL(@TableSuffix, ''));
print @TargetTable
    -- Step 1: Truncate target table if requested
    IF @Truncate = 1
    BEGIN
        EXEC('TRUNCATE TABLE ' + @TargetTable);
truncate table History.StockTradeSummary_BatchLog;
    END

    -- Step 2: Populate SectorList table
    IF @Sectors IS NULL
    BEGIN
        INSERT INTO @SectorList(Sector)
        SELECT DISTINCT Sector
        FROM Stocks.StocksHistory
        WHERE Sector IS NOT NULL;
    END
    ELSE
    BEGIN
        INSERT INTO @SectorList(Sector)
        SELECT TRIM(value)
        FROM STRING_SPLIT(@Sectors, ',');
    END

    -- Step 3: Delete existing data if not truncating
    IF @Truncate = 0
    BEGIN
        -- Convert sector list to string for dynamic SQL
        DECLARE @SectorFilter NVARCHAR(MAX) = 
            (SELECT STRING_AGG(QUOTENAME(Sector, ''''), ',') FROM @SectorList);

        DECLARE @SQL NVARCHAR(MAX) = '
            DELETE FROM ' + @TargetTable + '
            WHERE Symbol IN (
                SELECT Symbol FROM Stocks.StocksHistory
                WHERE Sector IN (' + @SectorFilter + ')
            );';

        EXEC(@SQL);

        DELETE FROM [History].[StockTradeSummary_BatchLog]
        WHERE Sector IN (
            SELECT Sector FROM @SectorList
        );
    END

    -- Step 4: Cursor loop over sectors
    DECLARE cur CURSOR FOR SELECT Sector FROM @SectorList;
    OPEN cur;
    FETCH NEXT FROM cur INTO @Sector;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @StartTime DATETIME = GETDATE();
        DECLARE @EndTime DATETIME;
        DECLARE @ElapsedSeconds INT;
        DECLARE @RowsInserted INT = 0;
        DECLARE @Status NVARCHAR(50) = 'Success';
        DECLARE @ErrorMessage NVARCHAR(MAX) = NULL;


        BEGIN TRY
            DECLARE @Result TABLE (RowsInserted INT, Status VARCHAR(50));


             if(@TableSuffix is null OR @TableSuffix='')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
           if(@TableSuffix ='_2020')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2020]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
           if(@TableSuffix ='_2021')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2021]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end

            if(@TableSuffix ='_2022')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2022]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
            if(@TableSuffix ='_2023')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2023]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
            if(@TableSuffix ='_2024')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2024]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
            if(@TableSuffix ='_2025')
            begin
            INSERT INTO @Result
           
             EXEC [History].[Populate_StockTradeSummary_2025]
                @Sectors = @Sector,
                @FromDate = @FromDate,
                @ToDate = @ToDate
            end
            SELECT @RowsInserted = RowsInserted, @Status = Status FROM @Result;

            SET @TotalRowsInserted += ISNULL(@RowsInserted, 0);
        END TRY
        BEGIN CATCH
            SET @Status = 'Failure';
            SET @ErrorMessage = ERROR_MESSAGE();
            SET @FinalStatus = 'Failure';
        END CATCH;

        SET @EndTime = GETDATE();
        SET @ElapsedSeconds = DATEDIFF(SECOND, @StartTime, @EndTime);

        INSERT INTO [History].[StockTradeSummary_BatchLog] (
            Sector, StartTime, EndTime, RowsInserted, Status, ErrorMessage, ElapsedSeconds
        )
        VALUES (
            @Sector, @StartTime, @EndTime, @RowsInserted, @Status, @ErrorMessage, @ElapsedSeconds
        );

        FETCH NEXT FROM cur INTO @Sector;
    END

    CLOSE cur;
    DEALLOCATE cur;

    -- Step 5: Composite score update
    DECLARE @CompositeScoreSQL NVARCHAR(MAX) = '
        UPDATE ' + @TargetTable + '
        SET CompositeScore = 
            0.4 * (
                (ISNULL(Day1_UpRatio, 0) + ISNULL(Day2_UpRatio, 0) + ISNULL(Day3_UpRatio, 0) + 
                 ISNULL(Day4_UpRatio, 0) + ISNULL(Day5_UpRatio, 0) + ISNULL(Day6_UpRatio, 0) +
                 ISNULL(Day7_UpRatio, 0) + ISNULL(Day8_UpRatio, 0) + ISNULL(Day9_UpRatio, 0) +
                 ISNULL(Day10_UpRatio, 0)) / 10.0
            ) +
            0.4 * (
                (ISNULL(Day1_AvgProfit, 0) + ISNULL(Day2_AvgProfit, 0) + ISNULL(Day3_AvgProfit, 0) +
                 ISNULL(Day4_AvgProfit, 0) + ISNULL(Day5_AvgProfit, 0) + ISNULL(Day6_AvgProfit, 0) +
                 ISNULL(Day7_AvgProfit, 0) + ISNULL(Day8_AvgProfit, 0) + ISNULL(Day9_AvgProfit, 0) +
                 ISNULL(Day10_AvgProfit, 0)) / 10.0
            ) +
            0.2 * (
                (ISNULL(Day1_Positive, 0) + ISNULL(Day2_Positive, 0) + ISNULL(Day3_Positive, 0) +
                 ISNULL(Day4_Positive, 0) + ISNULL(Day5_Positive, 0) + ISNULL(Day6_Positive, 0) +
                 ISNULL(Day7_Positive, 0) + ISNULL(Day8_Positive, 0) + ISNULL(Day9_Positive, 0) +
                 ISNULL(Day10_Positive, 0)) * 1.0 /
                NULLIF(
                    (ISNULL(Day1_Negative, 0) + ISNULL(Day2_Negative, 0) + ISNULL(Day3_Negative, 0) +
                     ISNULL(Day4_Negative, 0) + ISNULL(Day5_Negative, 0) + ISNULL(Day6_Negative, 0) +
                     ISNULL(Day7_Negative, 0) + ISNULL(Day8_Negative, 0) + ISNULL(Day9_Negative, 0) +
                     ISNULL(Day10_Negative, 0)) + 1, 0)
            );';

    EXEC(@CompositeScoreSQL);

    SELECT @TotalRowsInserted AS RowsInserted, @FinalStatus AS Status;
END;