﻿--exec [History].[Populate_StockTradeSummaryByGroup_Batch] '2020-01-01',null,1
CREATE PROCEDURE [History].[Populate_StockTradeSummaryByGroup_Batch]
    @FromDate DATE = '2020-01-01',
    @ToDate DATE = NULL,
    @Truncate BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SymbolGroup NVARCHAR(100);
    DECLARE @TotalRowsInserted INT = 0;

    IF @Truncate = 1
    BEGIN
        TRUNCATE TABLE History.StockTradeSummaryByGroup;
        TRUNCATE TABLE History.StockTradeSummary_BatchLog;
    END

    DECLARE symbolGroupCursor CURSOR FOR
        SELECT DISTINCT SymbolGroup
        FROM Stocks.StocksHistory
        WHERE SymbolGroup IS NOT NULL;

    OPEN symbolGroupCursor;
    FETCH NEXT FROM symbolGroupCursor INTO @SymbolGroup;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @StartTime DATETIME = GETDATE();
        DECLARE @RowsInserted INT = 0;
        DECLARE @Status NVARCHAR(50) = 'Success';
        DECLARE @ErrorMessage NVARCHAR(MAX) = NULL;

        BEGIN TRY
            DECLARE @Result TABLE (RowsInserted INT, Status VARCHAR(50));

            INSERT INTO @Result
            EXEC [History].[Populate_StockTradeSummaryByGroup]
                @SymbolGroup = @SymbolGroup,
                @FromDate = @FromDate,
                @ToDate = @ToDate;

            SELECT @RowsInserted = RowsInserted FROM @Result;
            SET @TotalRowsInserted += ISNULL(@RowsInserted, 0);
        END TRY
        BEGIN CATCH
            SET @Status = 'Failure';
            SET @ErrorMessage = ERROR_MESSAGE();
        END CATCH

        INSERT INTO History.StockTradeSummary_BatchLog (
            SymbolGroup, StartTime, EndTime, RowsInserted, Status, ErrorMessage, ElapsedSeconds
        )
        VALUES (
            @SymbolGroup, @StartTime, GETDATE(), @RowsInserted, @Status, @ErrorMessage,
            DATEDIFF(SECOND, @StartTime, GETDATE())
        );

        FETCH NEXT FROM symbolGroupCursor INTO @SymbolGroup;
    END

    CLOSE symbolGroupCursor;
    DEALLOCATE symbolGroupCursor;

    -- Update composite score
    UPDATE History.StockTradeSummaryByGroup
    SET CompositeScore = 
        0.4 * (
            (ISNULL(Day1_UpRatio, 0) + ISNULL(Day2_UpRatio, 0) + ISNULL(Day3_UpRatio, 0) +
             ISNULL(Day4_UpRatio, 0) + ISNULL(Day5_UpRatio, 0) + ISNULL(Day6_UpRatio, 0) +
             ISNULL(Day7_UpRatio, 0) + ISNULL(Day8_UpRatio, 0) + ISNULL(Day9_UpRatio, 0) +
             ISNULL(Day10_UpRatio, 0)) / 10.0
        ) +
        0.4 * (
            (ISNULL(Day1_AvgProfit, 0) + ISNULL(Day2_AvgProfit, 0) + ISNULL(Day3_AvgProfit, 0) +
             ISNULL(Day4_AvgProfit, 0) + ISNULL(Day5_AvgProfit, 0) + ISNULL(Day6_AvgProfit, 0) +
             ISNULL(Day7_AvgProfit, 0) + ISNULL(Day8_AvgProfit, 0) + ISNULL(Day9_AvgProfit, 0) +
             ISNULL(Day10_AvgProfit, 0)) / 10.0
        ) +
        0.2 * (
            (ISNULL(Day1_Positive, 0) + ISNULL(Day2_Positive, 0) + ISNULL(Day3_Positive, 0) +
             ISNULL(Day4_Positive, 0) + ISNULL(Day5_Positive, 0) + ISNULL(Day6_Positive, 0) +
             ISNULL(Day7_Positive, 0) + ISNULL(Day8_Positive, 0) + ISNULL(Day9_Positive, 0) +
             ISNULL(Day10_Positive, 0)) * 1.0 /
            NULLIF(
                (ISNULL(Day1_Negative, 0) + ISNULL(Day2_Negative, 0) + ISNULL(Day3_Negative, 0) +
                 ISNULL(Day4_Negative, 0) + ISNULL(Day5_Negative, 0) + ISNULL(Day6_Negative, 0) +
                 ISNULL(Day7_Negative, 0) + ISNULL(Day8_Negative, 0) + ISNULL(Day9_Negative, 0) +
                 ISNULL(Day10_Negative, 0)) + 1, 0)
        );

    SELECT @TotalRowsInserted AS RowsInserted, 
           CASE WHEN EXISTS (SELECT 1 FROM History.StockTradeSummary_BatchLog WHERE Status = 'Failure') 
                THEN 'Failure' ELSE 'Success' END AS Status;
END;