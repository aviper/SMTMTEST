﻿
--EXEC History.[GetIndicatorsBySymbolsAndDateRange]'FICO','2024-01-05','2024-01-05'

--EXEC History.[GetIndicatorsBySymbolsAndDateRange]'','2024-01-05',NULL
--EXEC History.[GetIndicatorsBySymbolsAndDateRange]'FICO,MSFT','2024-01-05',NULL


CREATE PROCEDURE [History].[GetIndicatorsBySymbolsAndDateRange]
    @Symbols NVARCHAR(MAX), -- Comma-separated symbols
    @StartDate DATE,
    @EndDate DATE = NULL -- Default to NULL for optional parameter
AS
BEGIN
    SET NOCOUNT ON;

    -- Split symbols or select all if @Symbols is NULL
    ;WITH SymbolList AS
    (
        SELECT 
            TRIM(Value) AS Symbol
        FROM 
            [dbo].[SplitString](@Symbols, ',')
        WHERE 
            LEN(@Symbols) > 0 -- Ensure we process valid input
        UNION
        SELECT Symbol
        FROM [Stocks].[Stocks]
        WHERE @Symbols IS NULL OR LEN(@Symbols) = 0 -- Get all if @Symbols is empty or NULL
    )
    SELECT 
        t.Id AS TradeId,
        t.Symbol,
       CAST(j.[key] AS NVARCHAR(100)) AS IndicatorName,

        TRY_CAST(j.[value] AS INT) AS IndicatorValue,
        t.[TradeDate] AS TradeDate
    FROM 
        [History].[StockTrades] t
    INNER JOIN 
        SymbolList syms ON t.Symbol = syms.Symbol
    CROSS APPLY 
               OPENJSON(t.IndicatorsJson) AS j
    WHERE 
        t.TradeDate BETWEEN @StartDate AND ISNULL(@EndDate, @StartDate) -- Default EndDate to StartDate if NULL
    ORDER BY 
        t.Symbol, t.[TradeDate], j.[key];
END;