﻿--exec [History].[GetFirstAndLastTradeDate] 'BHP,EWBC,CRK,KMB,DEO,GTY,ELP,ARLP,AVT,CCEP,FCN,LCII,ATRO,MSI'
CREATE PROCEDURE [History].[GetFirstAndLastTradeDate]
    @Symbols NVARCHAR(MAX) = NULL  -- Comma-separated list of symbols (optional)
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Load relevant StockIds
    DECLARE @TargetStockIds TABLE
    (
        StockId UNIQUEIDENTIFIER PRIMARY KEY,
        Symbol  NVARCHAR(50) NOT NULL
    );

    IF @Symbols IS NULL
    BEGIN
        INSERT INTO @TargetStockIds (StockId, Symbol)
        SELECT sh.Id, sh.Symbol
        FROM  [Stocks].StocksHistory sh
        WHERE sh.IsValid = 1;
    END
    ELSE
    BEGIN
        INSERT INTO @TargetStockIds (StockId, Symbol)
        SELECT s.Id, s.Symbol
        FROM [Stocks].Stocks s
        INNER JOIN (
            SELECT TRIM(value) AS Symbol
            FROM STRING_SPLIT(@Symbols, ',')
        ) AS src ON s.Symbol = src.Symbol;
    END

    -- 2. Get first and last trade dates per symbol from the base table
    SELECT 
        t.Symbol,
        MIN(st.TradeDate) AS FirstTradeDate,
        MAX(st.TradeDate) AS LastTradeDate
    FROM @TargetStockIds t
    INNER JOIN History.StockTrades st ON t.Symbol = st.Symbol
    GROUP BY t.Symbol
    ORDER BY t.Symbol;
END;