﻿CREATE PROCEDURE [History].[sp_GetUpgradeDowngradeFirmPerformance]
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Normalize date range
    IF @FromDate IS NULL SET @FromDate = '2000-01-01';
    IF @ToDate IS NULL SET @ToDate = GETDATE();

    -- Main aggregation query
    SELECT 
        Firm,
        Action,
        COUNT(*) AS TotalCalls,

        -- Average price change %
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay1 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay1,
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay3 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay3,
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay5 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay5,
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay10 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay10,
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay20 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay20,
        AVG(CASE WHEN CurrentPrice > 0 THEN (PriceAfterDay30 - CurrentPrice) / CurrentPrice * 100 END) AS AvgReturnDay30,

        -- Hit ratio: how often the direction matched the action
        SUM(CASE 
                WHEN Action = 'up' AND PriceAfterDay3 > CurrentPrice THEN 1
                WHEN Action = 'down' AND PriceAfterDay3 < CurrentPrice THEN 1
                ELSE 0
            END) * 1.0 / COUNT(*) AS HitRatio3Day,

        SUM(CASE 
                WHEN Action = 'up' AND PriceAfterDay10 > CurrentPrice THEN 1
                WHEN Action = 'down' AND PriceAfterDay10 < CurrentPrice THEN 1
                ELSE 0
            END) * 1.0 / COUNT(*) AS HitRatio10Day

    FROM [History].[UpgradeDowngradeHistory]
    WHERE [Date] BETWEEN @FromDate AND @ToDate
      AND CurrentPrice IS NOT NULL
      AND PriceAfterDay3 IS NOT NULL and 
      [PriceTargetAction] in('Lowers','Raises')
--
    GROUP BY Firm, Action
    ORDER BY AvgReturnDay3 DESC;
END