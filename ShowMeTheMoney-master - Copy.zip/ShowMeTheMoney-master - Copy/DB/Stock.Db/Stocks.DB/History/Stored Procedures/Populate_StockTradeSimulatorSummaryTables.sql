﻿
-- =============================================
-- Procedure: Populate_StockTradeSimulatorSummaryTables
-- Purpose : Calls Populate_StockTradeSummary_Batch for multiple years
-- Logs each step of execution
-- =============================================

CREATE PROCEDURE [History].[Populate_StockTradeSimulatorSummaryTables]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @logPrefix NVARCHAR(100) = '[Populate_StockTradeSimulatorSummaryTables] ';

    BEGIN TRY
        PRINT @logPrefix + 'Starting population for _2020';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2020';
        PRINT @logPrefix + 'Completed population for _2020';

        PRINT @logPrefix + 'Starting population for _2021';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2021';
        PRINT @logPrefix + 'Completed population for _2021';

        PRINT @logPrefix + 'Starting population for _2022';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2022';
        PRINT @logPrefix + 'Completed population for _2022';

        PRINT @logPrefix + 'Starting population for _2023';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2023';
        PRINT @logPrefix + 'Completed population for _2023';

        PRINT @logPrefix + 'Starting population for _2024';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2024';
        PRINT @logPrefix + 'Completed population for _2024';

        PRINT @logPrefix + 'Starting population for _2025';
        EXEC [History].[Populate_StockTradeSummary_Batch] NULL, NULL, NULL, 1, '_2025';
        PRINT @logPrefix + 'Completed population for _2025';

        PRINT @logPrefix + 'All yearly batches completed successfully.';
    END TRY
    BEGIN CATCH
        PRINT @logPrefix + 'Error occurred!';
        PRINT @logPrefix + 'Message   : ' + ERROR_MESSAGE();
        PRINT @logPrefix + 'Procedure : ' + ISNULL(ERROR_PROCEDURE(), 'N/A');
        PRINT @logPrefix + 'Line      : ' + CAST(ERROR_LINE() AS NVARCHAR);
        PRINT @logPrefix + 'Severity  : ' + CAST(ERROR_SEVERITY() AS NVARCHAR);
        PRINT @logPrefix + 'State     : ' + CAST(ERROR_STATE() AS NVARCHAR);
    END CATCH
END;