﻿--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = 'MSFT', @MinRatio = 1, @MinPositiveResults = 2, @IndicatorPrefix = 'Strategy', @Days = 'Day5,Day6,Day7,Day8', @MinPercents = 0, @Prefix = '';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = 'AAPL,GOOG,AMZN', @MinRatio = 0.8, @MinPositiveResults = 3, @IndicatorPrefix = NULL, @Days = 'Day3,Day4,Day5', @MinPercents = 0, @Prefix = '';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = NULL, @MinRatio = 0.7, @MinPositiveResults = 1, @IndicatorPrefix = 'Momentum', @Days = NULL, @MinPercents = 0, @Prefix = '';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = 'TSLA', @MinRatio = 1.2, @MinPositiveResults = 4, @IndicatorPrefix = '', @Days = NULL, @MinPercents = 0, @Prefix = '';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = NULL, @MinRatio = 1.5, @MinPositiveResults = 5, @IndicatorPrefix = 'Alpha', @Days = 'Day1,Day2', @MinPercents = 0, @Prefix = '';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = NULL, @MinRatio = 95, @MinPositiveResults = 5, @IndicatorPrefix = '', @Days = 'Day5,Day6,Day7,Day8', @MinPercents = 0, @Prefix = '_2020';

--EXEC [History].[GetProfitIndicatorsBySymbols_common] @Symbols = NULL, @MinRatio = 95, @MinPositiveResults = 5, @IndicatorPrefix = '', @Days = 'Day5,Day6,Day7,Day8', @MinPercents = 0, @Prefix = '';
CREATE PROCEDURE [History].[GetProfitIndicatorsBySymbols_common]
    @Symbols NVARCHAR(MAX) = NULL,
    @MinRatio DECIMAL(18, 4),
    @MinPositiveResults INT,
    @IndicatorPrefix NVARCHAR(50) = NULL,
    @Days NVARCHAR(MAX) = NULL,
    @MinPercents DECIMAL(18, 4) = 0,
    @Prefix NVARCHAR(50)  -- New parameter to dynamically switch table (e.g., '2020')
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Symbols = '') SET @Symbols = NULL;

    DECLARE @Sql NVARCHAR(MAX);
    DECLARE @ParamDefinition NVARCHAR(MAX);

    SET @Sql = '
    DECLARE @SymbolsTable TABLE (Symbol NVARCHAR(50));
    DECLARE @DaysTable TABLE (Day NVARCHAR(10));

    IF @Symbols IS NOT NULL
    BEGIN
        INSERT INTO @SymbolsTable
        SELECT value FROM [dbo].[SplitString](@Symbols, '','');
    END

    IF @Days IS NOT NULL
    BEGIN
        INSERT INTO @DaysTable
        SELECT value FROM [dbo].[SplitString](@Days, '','');
    END

    SELECT 
        s.*
    FROM [History].[StockTradeSummary' + @Prefix + '] s
    WHERE 
        (@Symbols IS NULL OR s.Symbol IN (SELECT Symbol FROM @SymbolsTable))
        AND (@IndicatorPrefix IS NULL OR @IndicatorPrefix = '''' OR s.IndicatorName LIKE + @IndicatorPrefix + ''%'')
        AND (
            @Days IS NULL
            OR EXISTS (
                SELECT 1
                FROM @DaysTable d
                WHERE 
                    (d.Day = ''Day1'' AND s.Day1_UpRatio >= @MinRatio AND s.Day1_Positive >= @MinPositiveResults AND s.Day1_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day2'' AND s.Day2_UpRatio >= @MinRatio AND s.Day2_Positive >= @MinPositiveResults AND s.Day2_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day3'' AND s.Day3_UpRatio >= @MinRatio AND s.Day3_Positive >= @MinPositiveResults AND s.Day3_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day4'' AND s.Day4_UpRatio >= @MinRatio AND s.Day4_Positive >= @MinPositiveResults AND s.Day4_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day5'' AND s.Day5_UpRatio >= @MinRatio AND s.Day5_Positive >= @MinPositiveResults AND s.Day5_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day6'' AND s.Day6_UpRatio >= @MinRatio AND s.Day6_Positive >= @MinPositiveResults AND s.Day6_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day7'' AND s.Day7_UpRatio >= @MinRatio AND s.Day7_Positive >= @MinPositiveResults AND s.Day7_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day8'' AND s.Day8_UpRatio >= @MinRatio AND s.Day8_Positive >= @MinPositiveResults AND s.Day8_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day9'' AND s.Day9_UpRatio >= @MinRatio AND s.Day9_Positive >= @MinPositiveResults AND s.Day9_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day10'' AND s.Day10_UpRatio >= @MinRatio AND s.Day10_Positive >= @MinPositiveResults AND s.Day10_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day20'' AND s.Day20_UpRatio >= @MinRatio AND s.Day20_Positive >= @MinPositiveResults AND s.Day20_AvgProfit >= @MinPercents)
                    OR (d.Day = ''Day30'' AND s.Day30_UpRatio >= @MinRatio AND s.Day30_Positive >= @MinPositiveResults AND s.Day30_AvgProfit >= @MinPercents)
                )
            )
    ORDER BY s.Symbol, s.IndicatorName;
    ';

    SET @ParamDefinition = N'
        @Symbols NVARCHAR(MAX),
        @MinRatio DECIMAL(18, 4),
        @MinPositiveResults INT,
        @IndicatorPrefix NVARCHAR(50),
        @Days NVARCHAR(MAX),
        @MinPercents DECIMAL(18,4)
    ';

    EXEC sp_executesql 
        @Sql,
        @ParamDefinition,
        @Symbols = @Symbols,
        @MinRatio = @MinRatio,
        @MinPositiveResults = @MinPositiveResults,
        @IndicatorPrefix = @IndicatorPrefix,
        @Days = @Days,
        @MinPercents = @MinPercents;
END;