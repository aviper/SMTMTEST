﻿--exec  [History].GetMissingStockTradeData '2025-05-11'


CREATE PROCEDURE [History].[GetMissingStockTradeData]
    @TradeDate DATE -- Specific trade date to check
AS
BEGIN
    SET NOCOUNT ON;

    

SELECT DISTINCT s.Symbol AS MissingSymbols
    FROM [Stocks].StocksHistory s
    LEFT JOIN (
        SELECT Symbol, TradeDate
        FROM [History].[StockTrades]
        WHERE TradeDate = @TradeDate
    ) st ON s.Symbol = st.Symbol
    WHERE st.Symbol IS NULL and s.IsValid=1
    ORDER BY s.Symbol;
END;