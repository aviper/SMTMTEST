﻿CREATE PROCEDURE [History].[GetDay6StatsPerSymbol]
    @IndicatorName NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        [Symbol],

        SUM(CAST([Day6_Positive] AS INT)) AS Total_Day6_Positive,
        SUM(CAST([Day6_Negative] AS INT)) AS Total_Day6_Negative,

        AVG(CAST([Day6_UpRatio] AS FLOAT)) AS Avg_Day6_UpRatio,
        AVG(CAST([Day6_AvgProfit] AS FLOAT)) AS Avg_Day6_AvgProfit,
        SUM(CAST([Day6_TotalProfit] AS FLOAT)) AS Sum_Day6_TotalProfit,

        -- Win Rate
        CASE 
            WHEN SUM(CAST([Day6_Positive] AS INT)) + SUM(CAST([Day6_Negative] AS INT)) = 0 THEN NULL
            ELSE 
                100.0 * SUM(CAST([Day6_Positive] AS FLOAT)) / 
                       (SUM(CAST([Day6_Positive] AS FLOAT)) + SUM(CAST([Day6_Negative] AS FLOAT)))
        END AS WinRate_Day6_Percent,

        -- Profit Factor
        CASE 
            WHEN SUM(CASE WHEN [Day6_TotalProfit] < 0 THEN -[Day6_TotalProfit] ELSE 0 END) = 0 THEN NULL
            ELSE 
                SUM(CASE WHEN [Day6_TotalProfit] > 0 THEN [Day6_TotalProfit] ELSE 0 END) /
                SUM(CASE WHEN [Day6_TotalProfit] < 0 THEN -[Day6_TotalProfit] ELSE 0 END)
        END AS ProfitFactor_Day6,

        -- Profit per trade
        CASE 
            WHEN (SUM(CAST([Day6_Positive] AS INT)) + SUM(CAST([Day6_Negative] AS INT))) = 0 THEN NULL
            ELSE 
                SUM(CAST([Day6_TotalProfit] AS FLOAT)) / 
                (SUM(CAST([Day6_Positive] AS FLOAT)) + SUM(CAST([Day6_Negative] AS FLOAT)))
        END AS ProfitPerDay_Day6

    FROM 
        [History].[StockTradeSummary]
    WHERE 
        [IndicatorName] = @IndicatorName
        AND [Day6_TotalProfit] IS NOT NULL
    GROUP BY 
        [Symbol]
    ORDER BY 
        ProfitPerDay_Day6 DESC;
END