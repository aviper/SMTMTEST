﻿
--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = 'MSFT', @MinRatio = 1, @MinPositiveResults = 2, @IndicatorPrefix = 'Strategy', @Days = 'Day5,Day6,Day7,Day8';
--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = 'AAPL,GOOG,AMZN', @MinRatio = 0.8, @MinPositiveResults = 3, @IndicatorPrefix = NULL, @Days = 'Day3,Day4,Day5';
--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = NULL, @MinRatio = 0.7, @MinPositiveResults = 1, @IndicatorPrefix = 'Momentum', @Days = NULL;
--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = 'TSLA', @MinRatio = 1.2, @MinPositiveResults = 4, @IndicatorPrefix = '', @Days = NULL;
--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = NULL, @MinRatio = 1.5, @MinPositiveResults = 5, @IndicatorPrefix = 'Alpha', @Days = 'Day1,Day2';

--EXEC [History].[GetProfitIndicatorsBySymbols] @Symbols = null, @MinRatio = 95, @MinPositiveResults = 5, @IndicatorPrefix = '', @Days = 'Day5,Day6,Day7,Day8';


CREATE PROCEDURE [History].[GetProfitIndicatorsBySymbols]
    @Symbols NVARCHAR(MAX) = NULL,
    @MinRatio DECIMAL(18, 4),
    @MinPositiveResults INT,
    @IndicatorPrefix NVARCHAR(100) = NULL,
    @Days NVARCHAR(MAX) = NULL,
    @MinPercents DECIMAL(18, 4) = 0  -- New parameter
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Symbols = '')
        SET @Symbols = NULL;

    -- Symbols filter
    DECLARE @SymbolsTable TABLE (Symbol NVARCHAR(50));
    IF @Symbols IS NOT NULL
    BEGIN
        INSERT INTO @SymbolsTable
        SELECT Value  FROM [dbo].[SplitString](@Symbols, ',');
    END

    -- Days filter
    DECLARE @DaysTable TABLE (Day NVARCHAR(10));
    IF @Days IS NOT NULL
    BEGIN
        INSERT INTO @DaysTable
        SELECT Value  FROM [dbo].[SplitString](@Days, ',');
    END

    -- SELECT query
    SELECT 
        s.*
    FROM [History].[StockTradeSummary] s
    WHERE 
        (@Symbols IS NULL OR s.Symbol IN (SELECT Symbol FROM @SymbolsTable))
        AND (@IndicatorPrefix IS NULL OR @IndicatorPrefix = '' OR s.IndicatorName LIKE + @IndicatorPrefix + '%')
        AND (
            @Days IS NULL
            OR EXISTS (
                SELECT 1
                FROM @DaysTable d
                WHERE 
                    (
                        (d.Day = 'Day1' AND s.Day1_UpRatio >= @MinRatio AND s.Day1_Positive >= @MinPositiveResults AND s.Day1_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day2' AND s.Day2_UpRatio >= @MinRatio AND s.Day2_Positive >= @MinPositiveResults AND s.Day2_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day3' AND s.Day3_UpRatio >= @MinRatio AND s.Day3_Positive >= @MinPositiveResults AND s.Day3_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day4' AND s.Day4_UpRatio >= @MinRatio AND s.Day4_Positive >= @MinPositiveResults AND s.Day4_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day5' AND s.Day5_UpRatio >= @MinRatio AND s.Day5_Positive >= @MinPositiveResults AND s.Day5_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day6' AND s.Day6_UpRatio >= @MinRatio AND s.Day6_Positive >= @MinPositiveResults AND s.Day6_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day7' AND s.Day7_UpRatio >= @MinRatio AND s.Day7_Positive >= @MinPositiveResults AND s.Day7_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day8' AND s.Day8_UpRatio >= @MinRatio AND s.Day8_Positive >= @MinPositiveResults AND s.Day8_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day9' AND s.Day9_UpRatio >= @MinRatio AND s.Day9_Positive >= @MinPositiveResults AND s.Day9_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day10' AND s.Day10_UpRatio >= @MinRatio AND s.Day10_Positive >= @MinPositiveResults AND s.Day10_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day20' AND s.Day20_UpRatio >= @MinRatio AND s.Day20_Positive >= @MinPositiveResults AND s.Day20_AvgProfit >= @MinPercents) OR
                        (d.Day = 'Day30' AND s.Day30_UpRatio >= @MinRatio AND s.Day30_Positive >= @MinPositiveResults AND s.Day30_AvgProfit >= @MinPercents)
                    )
            )
        )
    ORDER BY s.Symbol, s.IndicatorName;
END;