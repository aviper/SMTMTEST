﻿--[History].[GetStockTradeIndicators] 'MSFT','2020-08-28','2021-08-28'
CREATE PROCEDURE [History].[GetStockTradeIndicators]
    @Symbols NVARCHAR(MAX) = NULL,   -- Filter by symbols (comma-separated)
    @FromDate DATE = NULL,           -- Filter by start date
    @ToDate DATE = NULL              -- Filter by end date
AS
BEGIN
    SET NOCOUNT ON;

    -- Fetch stock trade indicators with filtering
    SELECT 
        t.Symbol AS Symbol, 
        i.[key] AS IndicatorName,
        TRY_CAST(i.[value] AS INT) AS IndicatorValue,
        t.TradeDate
    FROM History.StockTrades AS t
    CROSS APPLY OPENJSON(t.IndicatorsJson) AS i -- Parse object properties
    WHERE 
        (@Symbols IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(@Symbols, ',') sym WHERE t.Symbol = TRIM(sym.value)
        ))
        AND (@FromDate IS NULL OR t.TradeDate >= @FromDate)
        AND (@ToDate IS NULL OR t.TradeDate <= @ToDate)
    ORDER BY t.Symbol, t.TradeDate DESC, i.[key];
END;
