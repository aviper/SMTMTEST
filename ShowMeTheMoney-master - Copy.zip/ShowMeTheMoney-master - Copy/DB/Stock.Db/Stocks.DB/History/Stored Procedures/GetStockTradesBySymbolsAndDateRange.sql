﻿CREATE PROCEDURE [History].[GetStockTradesBySymbolsAndDateRange]
    @Symbols NVARCHAR(MAX),               -- Comma-separated list of symbols
    @StartDate DATE = NULL,              -- Start date for the range (nullable)
    @EndDate DATE = NULL,                -- End date for the range (nullable)
    @IncludeEmptyIndicators BIT = 0,     -- If false, exclude rows with empty/null IndicatorsJson
    @Indicators NVARCHAR(MAX) = NULL     -- Comma-separated list of indicator names to filter by
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SQL NVARCHAR(MAX);
    DECLARE @SymbolList NVARCHAR(MAX);
    DECLARE @IndicatorsList NVARCHAR(MAX);

    -- Build quoted list for symbols: 'MSFT','NVDA'
    IF @Symbols IS NOT NULL
    BEGIN
        SET @SymbolList = '''' + REPLACE(@Symbols, ',', ''',''') + '''';
    END

    -- Build base query
    SET @SQL = '
    SELECT *
    FROM [History].StockTrades
    WHERE 1 = 1
    ';

    -- Filter symbols
    IF @Symbols IS NOT NULL
    BEGIN
        SET @SQL += ' AND Symbol IN (' + @SymbolList + ')';
    END

    -- Filter by dates
    IF @StartDate IS NOT NULL AND @EndDate IS NOT NULL
        SET @SQL += ' AND TradeDate BETWEEN @StartDate AND @EndDate';
    ELSE IF @StartDate IS NOT NULL
        SET @SQL += ' AND TradeDate >= @StartDate';
    ELSE IF @EndDate IS NOT NULL
        SET @SQL += ' AND TradeDate <= @EndDate';

    -- Filter out empty indicators
    IF @IncludeEmptyIndicators = 0
    BEGIN
        SET @SQL += ' AND IndicatorsJson IS NOT NULL AND IndicatorsJson <> ''{}''';
    END

    -- Filter by indicators using LIKE (simple match inside JSON text)
    IF @Indicators IS NOT NULL
    BEGIN
        DECLARE @IndicatorTable TABLE (Indicator NVARCHAR(100));
        INSERT INTO @IndicatorTable
        SELECT TRIM(value) FROM STRING_SPLIT(@Indicators, ',');

        DECLARE @LikeConditions NVARCHAR(MAX) = '';
        SELECT @LikeConditions = STRING_AGG('IndicatorsJson LIKE ''%"' + Indicator + '"%''', ' OR ')
        FROM @IndicatorTable;

        IF @LikeConditions IS NOT NULL AND LEN(@LikeConditions) > 0
        BEGIN
            SET @SQL += ' AND (' + @LikeConditions + ')';
        END
    END

    -- Final ordering
    SET @SQL += ' ORDER BY TradeDate';

    -- Execute
    EXEC sp_executesql @SQL,
        N'@StartDate DATE, @EndDate DATE, @IncludeEmptyIndicators BIT',
        @StartDate = @StartDate,
        @EndDate = @EndDate,
        @IncludeEmptyIndicators = @IncludeEmptyIndicators;
END