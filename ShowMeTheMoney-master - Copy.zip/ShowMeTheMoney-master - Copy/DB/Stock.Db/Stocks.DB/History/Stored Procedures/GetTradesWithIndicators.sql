﻿--exec  [History].[GetTradesWithIndicators] 'MSFT',null,null
CREATE PROCEDURE [History].[GetTradesWithIndicators]
    @Symbols NVARCHAR(MAX) = NULL,  -- Comma-separated list of symbols (optional)
    @EndDate DATE,                  -- End date for filtering trades
    @NumRows INT                    -- Number of rows to retrieve per Symbol
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare table variable to store split symbols
    DECLARE @SymbolTable TABLE (Symbol NVARCHAR(50));

    -- Insert split symbols into the table
    IF @Symbols IS NOT NULL
    BEGIN
        INSERT INTO @SymbolTable (Symbol)
        SELECT Value 
        FROM [dbo].[SplitString](@Symbols, ',');
    END

    -- CTE to rank trades for each Symbol and filter by @NumRows
    ;WITH RankedTrades AS (
        SELECT
            t.Symbol,
            t.Id,
            t.TradeDate,
            t.OpenPrice,
            t.ClosePrice,
            t.AdjustedClose,
            t.HighPrice,
            t.LowPrice,
            t.Volume,
            ROW_NUMBER() OVER (PARTITION BY t.Symbol ORDER BY t.TradeDate DESC) AS RowNum
        FROM [History].[StockTrades] t
        WHERE t.TradeDate <= @EndDate
            AND (@Symbols IS NULL OR EXISTS (SELECT 1 FROM @SymbolTable s WHERE s.Symbol = t.Symbol)) -- Optimized filter
    )

    -- Extracting data from JSON array using OPENJSON
    SELECT 
        rt.Symbol AS Symbol,
        rt.Id,
        rt.TradeDate,
        rt.OpenPrice,
        rt.ClosePrice,
        rt.AdjustedClose,
        rt.HighPrice,
        rt.LowPrice,
        rt.Volume,
       CAST(ind.[key] AS NVARCHAR(100)) AS IndicatorName,
        TRY_CAST(ind.[value] AS INT) AS IndicatorValue
    FROM RankedTrades rt
    INNER JOIN History.StockTrades t ON rt.id = t.Id
	  CROSS APPLY
	  OPENJSON(t.IndicatorsJson) AS ind

   
    WHERE rt.RowNum <= @NumRows
    ORDER BY rt.Symbol, rt.TradeDate DESC;
END;