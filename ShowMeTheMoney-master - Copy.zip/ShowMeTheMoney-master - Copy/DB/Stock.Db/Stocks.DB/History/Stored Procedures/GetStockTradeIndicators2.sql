﻿--[History].[GetStockTradeIndicators2] 'NVDA','2024-01-17','2025-01-04'
CREATE PROCEDURE [History].[GetStockTradeIndicators2]
    @Symbols NVARCHAR(MAX) = NULL,   -- Filter by symbols (comma-separated)
    @FromDate DATE = NULL,           -- Filter by start date
    @ToDate DATE = NULL              -- Filter by end date
AS
BEGIN
    SET NOCOUNT ON;

    -- Fetch unique stock trade indicators
    SELECT DISTINCT
        t.Symbol AS Symbol, 
        i.[key] AS IndicatorName,
        TradeDate,
        TRY_CAST(i.[value] AS INT) AS IndicatorValue
    FROM History.StockTrades AS t
    CROSS APPLY OPENJSON(t.IndicatorsJson) AS i
    WHERE 
        (@Symbols IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(@Symbols, ',') sym WHERE t.Symbol = TRIM(sym.value)
        ))
        AND (@FromDate IS NULL OR t.TradeDate >= @FromDate)
        AND (@ToDate IS NULL OR t.TradeDate <= @ToDate)
        And ProfitDay1>0 
    ORDER BY TradeDate DESC;
END