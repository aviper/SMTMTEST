﻿-- [History].[Populate_StockTradeSummary_2020] 'RealEstate','2010-05-27'
CREATE PROCEDURE [History].[Populate_StockTradeSummary_2023]
     @Sectors NVARCHAR(MAX) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsInserted INT = 0;
    DECLARE @Status VARCHAR(50) = 'Success';
    DECLARE @Sql NVARCHAR(MAX);
    DECLARE @Params NVARCHAR(MAX);
   

    BEGIN TRANSACTION;

    BEGIN TRY
       
        INSERT INTO History.StockTradeSummary_2023 (
            Symbol, IndicatorName,

             Day1_Positive, Day1_Negative, Day1_UpRatio, Day1_AvgProfit, Day1_TotalProfit,
            Day2_Positive, Day2_Negative, Day2_UpRatio, Day2_AvgProfit, Day2_TotalProfit,
            Day3_Positive, Day3_Negative, Day3_UpRatio, Day3_AvgProfit, Day3_TotalProfit,
            Day4_Positive, Day4_Negative, Day4_UpRatio, Day4_AvgProfit, Day4_TotalProfit,
            Day5_Positive, Day5_Negative, Day5_UpRatio, Day5_AvgProfit, Day5_TotalProfit,
            Day6_Positive, Day6_Negative, Day6_UpRatio, Day6_AvgProfit, Day6_TotalProfit,
            Day7_Positive, Day7_Negative, Day7_UpRatio, Day7_AvgProfit, Day7_TotalProfit,
            Day8_Positive, Day8_Negative, Day8_UpRatio, Day8_AvgProfit, Day8_TotalProfit,
            Day9_Positive, Day9_Negative, Day9_UpRatio, Day9_AvgProfit, Day9_TotalProfit,
            Day10_Positive, Day10_Negative, Day10_UpRatio, Day10_AvgProfit, Day10_TotalProfit,
            Day20_Positive, Day20_Negative, Day20_UpRatio, Day20_AvgProfit, Day20_TotalProfit,
            Day30_Positive, Day30_Negative, Day30_UpRatio, Day30_AvgProfit, Day30_TotalProfit,

            LastUpdated
        )
        SELECT 
            sst.Symbol AS Symbol,
            CAST(Indicator.[key] AS NVARCHAR(255)) AS IndicatorName,

            -- Day 1
            SUM(CASE WHEN sst.ProfitDay1 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay1 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay1 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay1), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay1) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay1),

            -- Day 2
            SUM(CASE WHEN sst.ProfitDay2 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay2 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay2 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay2), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay2) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay2),

            -- Day 3
            SUM(CASE WHEN sst.ProfitDay3 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay3 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay3 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay3), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay3) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay3),

            -- Day 4
            SUM(CASE WHEN sst.ProfitDay4 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay4 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay4 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay4), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay4) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay4),

            -- Day 5
            SUM(CASE WHEN sst.ProfitDay5 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay5 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay5 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay5), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay5) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay5),

            -- Day 6
            SUM(CASE WHEN sst.ProfitDay6 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay6 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay6 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay6), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay6) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay6),

            -- Day 7
            SUM(CASE WHEN sst.ProfitDay7 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay7 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay7 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay7), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay7) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay7),

            -- Day 8
            SUM(CASE WHEN sst.ProfitDay8 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay8 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay8 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay8), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay8) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay8),

            -- Day 9
            SUM(CASE WHEN sst.ProfitDay9 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay9 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay9 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay9), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay9) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay9),

            -- Day 10
            SUM(CASE WHEN sst.ProfitDay10 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay10 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay10 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay10), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay10) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay10),

            -- Day 20
            SUM(CASE WHEN sst.ProfitDay20 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay20 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay20 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay20), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay20) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay20),

            -- Day 30
            SUM(CASE WHEN sst.ProfitDay30 > 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN sst.ProfitDay30 <= 0 THEN 1 ELSE 0 END),
            CAST(SUM(CASE WHEN sst.ProfitDay30 > 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sst.ProfitDay30), 0) AS DECIMAL(5,2)),
            CAST(AVG(sst.ProfitDay30) AS DECIMAL(10,4)),
            SUM(sst.ProfitDay30),

            GETDATE()
        FROM 
            History.StockTrades AS sst
        CROSS APPLY 
            OPENJSON(sst.IndicatorsJson) AS Indicator
        WHERE 
            (@FromDate IS NULL OR sst.TradeDate >= @FromDate)
            AND (@ToDate IS NULL OR sst.TradeDate <= @ToDate)
            AND (
                @Sectors IS NULL OR sst.Symbol IN (
                    SELECT Symbol 
                    FROM Stocks.StocksHistory 
                    WHERE Sector IN (SELECT TRIM(value) FROM STRING_SPLIT(@Sectors, ','))
                )
            )
        GROUP BY 
            sst.Symbol, Indicator.[key];

        SET @RowsInserted = @@ROWCOUNT;

       
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
		-- Capture error details
       
        SET @Status = 'Failure';

		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    DECLARE @ErrorLine INT;
    DECLARE @ErrorProcedure NVARCHAR(200);

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE(),
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ERROR_PROCEDURE();

    -- Optional: Print to the message tab in SSMS
    PRINT 'Error Message: ' + ISNULL(@ErrorMessage, '');
    PRINT 'Error Severity: ' + CAST(ISNULL(@ErrorSeverity, 0) AS NVARCHAR);
    PRINT 'Error State: ' + CAST(ISNULL(@ErrorState, 0) AS NVARCHAR);
    PRINT 'Error Line: ' + CAST(ISNULL(@ErrorLine, 0) AS NVARCHAR);
    PRINT 'Error Procedure: ' + ISNULL(@ErrorProcedure, '');

        THROW;
    END CATCH;

     

    SELECT @RowsInserted AS RowsInserted, @Status AS Status;
END;