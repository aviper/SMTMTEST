﻿CREATE TABLE [History].[StockTradeSummary_BatchLog] (
    [Id]             INT            IDENTITY (1, 1) NOT NULL,
    [Sector]         NVARCHAR (100) NULL,
    [SymbolGroup]    NVARCHAR (100) NULL,
    [StartTime]      DATETIME       NULL,
    [EndTime]        DATETIME       NULL,
    [RowsInserted]   INT            NULL,
    [Status]         NVARCHAR (50)  NULL,
    [ErrorMessage]   NVARCHAR (MAX) NULL,
    [ElapsedSeconds] INT            NULL,
    CONSTRAINT [PK__StockTra__3214EC07ABE924D9] PRIMARY KEY CLUSTERED ([Id] ASC)
);

