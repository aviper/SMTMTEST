﻿CREATE TABLE [History].[StockTradeSummary] (
    [Id]                INT             IDENTITY (1, 1) NOT NULL,
    [Symbol]       NVARCHAR (50)   NOT NULL,
    [IndicatorName]     NVARCHAR (255)  NOT NULL,
    [Day1_Positive]     INT             CONSTRAINT [DF__StockTrad__Day1___54EB90A0] DEFAULT ((0)) NULL,
    [Day1_Negative]     INT             CONSTRAINT [DF__StockTrad__Day1___55DFB4D9] DEFAULT ((0)) NULL,
    [Day1_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day1___56D3D912] DEFAULT ((0.00)) NULL,
    [Day1_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day1_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day1_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day2_Positive]     INT             CONSTRAINT [DF__StockTrad__Day2___57C7FD4B] DEFAULT ((0)) NULL,
    [Day2_Negative]     INT             CONSTRAINT [DF__StockTrad__Day2___58BC2184] DEFAULT ((0)) NULL,
    [Day2_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day2___59B045BD] DEFAULT ((0.00)) NULL,
    [Day2_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day2_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day2_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day3_Positive]     INT             CONSTRAINT [DF__StockTrad__Day3___5AA469F6] DEFAULT ((0)) NULL,
    [Day3_Negative]     INT             CONSTRAINT [DF__StockTrad__Day3___5B988E2F] DEFAULT ((0)) NULL,
    [Day3_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day3___5C8CB268] DEFAULT ((0.00)) NULL,
    [Day3_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day3_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day3_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day4_Positive]     INT             CONSTRAINT [DF__StockTrad__Day4___5D80D6A1] DEFAULT ((0)) NULL,
    [Day4_Negative]     INT             CONSTRAINT [DF__StockTrad__Day4___5E74FADA] DEFAULT ((0)) NULL,
    [Day4_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day4___5F691F13] DEFAULT ((0.00)) NULL,
    [Day4_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day4_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day4_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day5_Positive]     INT             CONSTRAINT [DF__StockTrad__Day5___605D434C] DEFAULT ((0)) NULL,
    [Day5_Negative]     INT             CONSTRAINT [DF__StockTrad__Day5___61516785] DEFAULT ((0)) NULL,
    [Day5_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day5___62458BBE] DEFAULT ((0.00)) NULL,
    [Day5_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day5_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day5_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day6_Positive]     INT             CONSTRAINT [DF__StockTrad__Day6___6339AFF7] DEFAULT ((0)) NULL,
    [Day6_Negative]     INT             CONSTRAINT [DF__StockTrad__Day6___642DD430] DEFAULT ((0)) NULL,
    [Day6_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day6___6521F869] DEFAULT ((0.00)) NULL,
    [Day6_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day6_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day6_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day7_Positive]     INT             CONSTRAINT [DF__StockTrad__Day7___66161CA2] DEFAULT ((0)) NULL,
    [Day7_Negative]     INT             CONSTRAINT [DF__StockTrad__Day7___670A40DB] DEFAULT ((0)) NULL,
    [Day7_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day7___67FE6514] DEFAULT ((0.00)) NULL,
    [Day7_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day7_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day7_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day8_Positive]     INT             CONSTRAINT [DF__StockTrad__Day8___68F2894D] DEFAULT ((0)) NULL,
    [Day8_Negative]     INT             CONSTRAINT [DF__StockTrad__Day8___69E6AD86] DEFAULT ((0)) NULL,
    [Day8_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day8___6ADAD1BF] DEFAULT ((0.00)) NULL,
    [Day8_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day8_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day8_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day9_Positive]     INT             CONSTRAINT [DF__StockTrad__Day9___6BCEF5F8] DEFAULT ((0)) NULL,
    [Day9_Negative]     INT             CONSTRAINT [DF__StockTrad__Day9___6CC31A31] DEFAULT ((0)) NULL,
    [Day9_UpRatio]      DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day9___6DB73E6A] DEFAULT ((0.00)) NULL,
    [Day9_AvgProfit]    DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day9_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day9_TotalProfit]  DECIMAL (18, 2) NULL,
    [Day10_Positive]    INT             CONSTRAINT [DF__StockTrad__Day10__6EAB62A3] DEFAULT ((0)) NULL,
    [Day10_Negative]    INT             CONSTRAINT [DF__StockTrad__Day10__6F9F86DC] DEFAULT ((0)) NULL,
    [Day10_UpRatio]     DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day10__7093AB15] DEFAULT ((0.00)) NULL,
    [Day10_AvgProfit]   DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day10_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day10_TotalProfit] DECIMAL (18, 2) NULL,
    [Day20_Positive]    INT             CONSTRAINT [DF__StockTrad__Day20__7187CF4E] DEFAULT ((0)) NULL,
    [Day20_Negative]    INT             CONSTRAINT [DF__StockTrad__Day20__727BF387] DEFAULT ((0)) NULL,
    [Day20_UpRatio]     DECIMAL (5, 2)  CONSTRAINT [DF__StockTrad__Day20__737017C0] DEFAULT ((0.00)) NULL,
    [Day20_AvgProfit]   DECIMAL (10, 2) CONSTRAINT [DF__StockTrad__Day20_AvgProfit] DEFAULT ((0.00)) NULL,
    [Day20_TotalProfit] DECIMAL (18, 2) NULL,
    [Day30_Positive]    INT             NULL,
    [Day30_Negative]    INT             NULL,
    [Day30_UpRatio]     DECIMAL (5, 2)  NULL,
    [Day30_AvgProfit]   DECIMAL (10, 2) NULL,
    [Day30_TotalProfit] DECIMAL (18, 2) NULL,
    [LastUpdated]       DATETIME        NOT NULL,
    [CompositeScore]    DECIMAL (10, 4) NULL,
    CONSTRAINT [PK__StockTra__3214EC07BDDC9418] PRIMARY KEY CLUSTERED ([Id] ASC)
);










GO



GO



GO
