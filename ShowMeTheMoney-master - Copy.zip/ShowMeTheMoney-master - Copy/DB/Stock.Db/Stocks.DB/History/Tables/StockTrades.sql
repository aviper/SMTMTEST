﻿CREATE TABLE [History].[StockTrades] (
    [Id]               UNIQUEIDENTIFIER CONSTRAINT [DF_StockTrades_Id] DEFAULT (newid()) NOT NULL,
    [TradeDate]        DATE             NOT NULL,
    [Symbol]           VARCHAR (5)      NOT NULL,
    [OpenPrice]        DECIMAL (18, 4)  NOT NULL,
    [ClosePrice]       DECIMAL (18, 4)  NOT NULL,
    [AdjustedClose]    DECIMAL (18, 4)  NOT NULL,
    [HighPrice]        DECIMAL (18, 4)  NOT NULL,
    [LowPrice]         DECIMAL (18, 4)  NOT NULL,
    [Volume]           BIGINT           NULL,
    [ProfitDay1]       DECIMAL (18, 4)  NULL,
    [ProfitDay2]       DECIMAL (18, 4)  NULL,
    [ProfitDay3]       DECIMAL (18, 4)  NULL,
    [ProfitDay4]       DECIMAL (18, 4)  NULL,
    [ProfitDay5]       DECIMAL (18, 4)  NULL,
    [ProfitDay6]       DECIMAL (18, 4)  NULL,
    [ProfitDay7]       DECIMAL (18, 4)  NULL,
    [ProfitDay8]       DECIMAL (18, 4)  NULL,
    [ProfitDay9]       DECIMAL (18, 4)  NULL,
    [ProfitDay10]      DECIMAL (18, 4)  NULL,
    [ProfitDay20]      DECIMAL (18, 4)  NULL,
    [ProfitDay30]      DECIMAL (18, 4)  NULL,
    [IndicatorsJson]   NVARCHAR (MAX)   NULL,
    [Beta]             DECIMAL (10, 5)  NULL,
    [RawData]          NVARCHAR (MAX)   NULL,
    [PricePerformance] NVARCHAR (MAX)   NULL,
    [CurrentMarketCap] BIGINT           NULL,
    [AvgMarketCap10]   BIGINT           NULL,
    [AvgMarketCap20]   BIGINT           NULL,
    [AvgMarketCap50]   BIGINT           NULL,
    [MomentumScore]    DECIMAL (10, 5)  NULL,
    CONSTRAINT [PK_StockTrades] PRIMARY KEY CLUSTERED ([Id] ASC, [TradeDate] ASC) ON [ps_StockTrades_TradeDate] ([TradeDate]),
    CONSTRAINT [CK_StockTrades_ValidJson] CHECK (isjson([IndicatorsJson])>(0))
) ON [ps_StockTrades_TradeDate] ([TradeDate]);








































GO
CREATE NONCLUSTERED INDEX [IX_StockTrades_TradeDate]
    ON [History].[StockTrades]([TradeDate] ASC)
    ON [ps_StockTrades_TradeDate] ([TradeDate]);


GO
CREATE NONCLUSTERED INDEX [IX_StockTrades_Symbol_TradeDate]
    ON [History].[StockTrades]([Symbol] ASC, [TradeDate] ASC)
    ON [ps_StockTrades_TradeDate] ([TradeDate]);


GO
CREATE NONCLUSTERED INDEX [IX_StockTrades_Symbol]
    ON [History].[StockTrades]([Symbol] ASC)
    ON [ps_StockTrades_TradeDate] ([TradeDate]);

