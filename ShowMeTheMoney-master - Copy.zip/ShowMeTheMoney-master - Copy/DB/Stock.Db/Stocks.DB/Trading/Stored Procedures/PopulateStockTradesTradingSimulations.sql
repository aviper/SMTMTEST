﻿-- exec [Trading].[PopulateStockTradesTradingSimulations] 'MSFT,NVDA','2020-05-09', null, 0,'StrategyIsPullbackBuy,IsAboveAllSma'
CREATE PROCEDURE [Trading].[PopulateStockTradesTradingSimulations]
    @Symbols NVARCHAR(MAX),               -- Comma-separated list of symbols
    @StartDate DATE = NULL,              -- Start date for the range (nullable)
    @EndDate DATE = NULL,                -- End date for the range (nullable)
    @IncludeEmptyIndicators BIT = 0,     -- If false, exclude rows with empty/null IndicatorsJson
    @Indicators NVARCHAR(MAX) = NULL,    -- Comma-separated list of indicator names to filter by
    @Truncate BIT = 0                    -- If 1, truncate the result table before inserting
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SQL NVARCHAR(MAX) = '';
    DECLARE @SymbolList NVARCHAR(MAX);
    DECLARE @LikeConditions NVARCHAR(MAX) = '';
    DECLARE @ParamDefinition NVARCHAR(MAX);

    -- Convert symbol list to quoted strings
    IF @Symbols IS NOT NULL
    BEGIN
        SET @SymbolList = '''' + REPLACE(@Symbols, ',', ''',''') + '''';
    END

    -- Handle indicator LIKE conditions
    IF @Indicators IS NOT NULL
    BEGIN
        DECLARE @IndicatorTable TABLE (Indicator NVARCHAR(100));
        INSERT INTO @IndicatorTable
        SELECT TRIM(value) FROM STRING_SPLIT(@Indicators, ',');

        SELECT @LikeConditions = STRING_AGG('IndicatorsJson LIKE ''%"' + Indicator + '"%''', ' OR ')
        FROM @IndicatorTable;
    END

    -- Truncate result table if requested
    IF @Truncate = 1
    BEGIN
        TRUNCATE TABLE [Trading].[StockTradesTradingSimulations];
    END

    -- Count rows before insert
    DECLARE @BeforeCount INT, @AfterCount INT;
    SELECT @BeforeCount = COUNT(*) FROM [Trading].[StockTradesTradingSimulations];

    -- Build dynamic SQL for insert
    SET @SQL = @SQL + '
    INSERT INTO [Trading].[StockTradesTradingSimulations] (
        Id, TradeDate, Symbol, OpenPrice, ClosePrice, AdjustedClose,
        HighPrice, LowPrice, Volume,
        ProfitDay1, ProfitDay2, ProfitDay3, ProfitDay4, ProfitDay5,
        ProfitDay6, ProfitDay7, ProfitDay8, ProfitDay9, ProfitDay10,
        ProfitDay20, ProfitDay30, IndicatorsJson
    )
    SELECT
        NEWID(),
        TradeDate,
        Symbol,
        OpenPrice,
        ClosePrice,
        AdjustedClose,
        HighPrice,
        LowPrice,
        Volume,
        ProfitDay1, ProfitDay2, ProfitDay3, ProfitDay4, ProfitDay5,
        ProfitDay6, ProfitDay7, ProfitDay8, ProfitDay9, ProfitDay10,
        ProfitDay20, ProfitDay30,
        IndicatorsJson
    FROM [History].StockTrades
    WHERE 1 = 1
    ';

    -- Add filters to SQL
    IF @SymbolList IS NOT NULL
        SET @SQL = @SQL + ' AND Symbol IN (' + @SymbolList + ')';

    IF @StartDate IS NOT NULL
        SET @SQL = @SQL + ' AND TradeDate >= @StartDate';
    IF @EndDate IS NOT NULL
        SET @SQL = @SQL + ' AND TradeDate <= @EndDate';

    IF @IncludeEmptyIndicators = 0
        SET @SQL = @SQL + ' AND IndicatorsJson IS NOT NULL AND IndicatorsJson <> ''{}''';

    IF LEN(@LikeConditions) > 0
        SET @SQL = @SQL + ' AND (' + @LikeConditions + ')';

    -- Execute insert
    SET @ParamDefinition = N'@StartDate DATE, @EndDate DATE';
    EXEC sp_executesql @SQL, @ParamDefinition, @StartDate = @StartDate, @EndDate = @EndDate;

    -- Count rows after insert
    SELECT @AfterCount = COUNT(*) FROM [Trading].[StockTradesTradingSimulations];

    -- Return number of rows inserted
    SELECT @AfterCount - @BeforeCount AS RowsInserted;
END