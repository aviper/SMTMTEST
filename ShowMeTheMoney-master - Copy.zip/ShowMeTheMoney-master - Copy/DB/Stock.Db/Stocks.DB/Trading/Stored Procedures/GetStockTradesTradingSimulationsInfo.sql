﻿CREATE PROCEDURE [Trading].[GetStockTradesTradingSimulationsInfo]
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @Symbols NVARCHAR(MAX) = NULL  -- Comma-separated list
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Parse comma-separated symbols into a table
    DECLARE @SymbolsTable TABLE (Symbol VARCHAR(20));
    IF @Symbols IS NOT NULL
    BEGIN
        INSERT INTO @SymbolsTable (Symbol)
        SELECT TRIM(value)
        FROM STRING_SPLIT(@Symbols, ',')
        WHERE TRIM(value) <> '';
    END

    -- 2. Filtered data into temp table
    SELECT *
    INTO #Filtered
    FROM [Trading].[StockTradesTradingSimulations]
    WHERE 
        (@FromDate IS NULL OR TradeDate >= @FromDate)
        AND (@ToDate IS NULL OR TradeDate <= @ToDate)
        AND (
            @Symbols IS NULL 
            OR EXISTS (
                SELECT 1 FROM @SymbolsTable s WHERE s.Symbol = StockTradesTradingSimulations.Symbol
            )
        );

    -----------------------------
    -- 1. Summary Result Set
    -----------------------------
    SELECT 
        'Summary' AS ResultType,
        NULL AS Symbol,
        COUNT(*) AS TotalTrades,
        COUNT(DISTINCT Symbol) AS NumberOfStocks,
        MIN(TradeDate) AS TradeDateFrom,
        MAX(TradeDate) AS TradeDateTo,
        AVG(ProfitDay1) AS AvgProfitDay1,
        SUM(ProfitDay1) AS SumProfitDay1,
        AVG(ProfitDay2) AS AvgProfitDay2,
        SUM(ProfitDay2) AS SumProfitDay2,
        AVG(ProfitDay3) AS AvgProfitDay3,
        SUM(ProfitDay3) AS SumProfitDay3,
        AVG(ProfitDay4) AS AvgProfitDay4,
        SUM(ProfitDay4) AS SumProfitDay4,
        AVG(ProfitDay5) AS AvgProfitDay5,
        SUM(ProfitDay5) AS SumProfitDay5,
        AVG(ProfitDay6) AS AvgProfitDay6,
        SUM(ProfitDay6) AS SumProfitDay6,
        AVG(ProfitDay7) AS AvgProfitDay7,
        SUM(ProfitDay7) AS SumProfitDay7,
        AVG(ProfitDay8) AS AvgProfitDay8,
        SUM(ProfitDay8) AS SumProfitDay8,
        AVG(ProfitDay9) AS AvgProfitDay9,
        SUM(ProfitDay9) AS SumProfitDay9,
        AVG(ProfitDay10) AS AvgProfitDay10,
        SUM(ProfitDay10) AS SumProfitDay10,
        AVG(ProfitDay20) AS AvgProfitDay20,
        SUM(ProfitDay20) AS SumProfitDay20,
        AVG(ProfitDay30) AS AvgProfitDay30,
        SUM(ProfitDay30) AS SumProfitDay30
    FROM #Filtered

    UNION ALL

    -----------------------------
    -- 2. Per Symbol Result Set
    -----------------------------
    SELECT 
        'BySymbol' AS ResultType,
        Symbol,
        COUNT(*) AS TotalTrades,
        NULL AS NumberOfStocks,
        NULL AS TradeDateFrom,
        NULL AS TradeDateTo,
        AVG(ProfitDay1) AS AvgProfitDay1,
        SUM(ProfitDay1) AS SumProfitDay1,
        AVG(ProfitDay2), SUM(ProfitDay2),
        AVG(ProfitDay3), SUM(ProfitDay3),
        AVG(ProfitDay4), SUM(ProfitDay4),
        AVG(ProfitDay5), SUM(ProfitDay5),
        AVG(ProfitDay6), SUM(ProfitDay6),
        AVG(ProfitDay7), SUM(ProfitDay7),
        AVG(ProfitDay8), SUM(ProfitDay8),
        AVG(ProfitDay9), SUM(ProfitDay9),
        AVG(ProfitDay10), SUM(ProfitDay10),
        AVG(ProfitDay20), SUM(ProfitDay20),
        AVG(ProfitDay30), SUM(ProfitDay30)
    FROM #Filtered
    GROUP BY Symbol;

    -----------------------------
    -- 3. Profit Distribution (Day 5)
    -----------------------------
    SELECT 
        'ProfitDistribution' AS ResultType,
        Symbol,
        CASE 
            WHEN ProfitDay5 < -5 THEN '< -5%'
            WHEN ProfitDay5 BETWEEN -5 AND -2 THEN '-5% to -2%'
            WHEN ProfitDay5 BETWEEN -2 AND 0 THEN '-2% to 0%'
            WHEN ProfitDay5 BETWEEN 0 AND 2 THEN '0% to 2%'
            WHEN ProfitDay5 BETWEEN 2 AND 5 THEN '2% to 5%'
            ELSE '> 5%'
        END AS ProfitDay5Range,
        COUNT(*) AS TradeCount
    FROM #Filtered
    GROUP BY Symbol,
        CASE 
            WHEN ProfitDay5 < -5 THEN '< -5%'
            WHEN ProfitDay5 BETWEEN -5 AND -2 THEN '-5% to -2%'
            WHEN ProfitDay5 BETWEEN -2 AND 0 THEN '-2% to 0%'
            WHEN ProfitDay5 BETWEEN 0 AND 2 THEN '0% to 2%'
            WHEN ProfitDay5 BETWEEN 2 AND 5 THEN '2% to 5%'
            ELSE '> 5%'
        END;

    -- Cleanup
    DROP TABLE #Filtered;
END