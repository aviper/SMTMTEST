﻿CREATE TABLE [Trading].[TradesStrategies] (
    [TradeId]    UNIQUEIDENTIFIER NOT NULL,
    [StrategyId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_TradesStrategies] PRIMARY KEY CLUSTERED ([TradeId] ASC, [StrategyId] ASC)
);

