﻿CREATE TABLE [Trading].[WishLists] (
    [Id]               UNIQUEIDENTIFIER CONSTRAINT [DF_WishLists_Id] DEFAULT (newid()) NOT NULL,
    [UserId]           UNIQUEIDENTIFIER NOT NULL,
    [WatchListName]    NVARCHAR (50)    NOT NULL,
    [AlertBeforeTrade] BIT              CONSTRAINT [DF_WishLists_AlertBeforeTrade] DEFAULT ((0)) NOT NULL,
    [AlertAfterTrade]  BIT              CONSTRAINT [DF_WishLists_AlertAfterTrade] DEFAULT ((0)) NOT NULL,
    [AlertTime]        DATETIME         NULL,
    [Added]            DATETIME         CONSTRAINT [DF_WishLists_Added] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_WishLists] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_WishLists_Users] FOREIGN KEY ([UserId]) REFERENCES [Application].[Users] ([Id])
);

