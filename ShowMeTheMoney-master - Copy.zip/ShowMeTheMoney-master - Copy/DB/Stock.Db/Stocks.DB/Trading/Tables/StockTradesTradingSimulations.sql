﻿CREATE TABLE [Trading].[StockTradesTradingSimulations] (
    [Id]             UNIQUEIDENTIFIER CONSTRAINT [DF_StockTradesTradingSimulations_Id] DEFAULT (newid()) NOT NULL,
    [TradeDate]      DATE             NOT NULL,
    [Symbol]         VARCHAR (5)      NOT NULL,
    [OpenPrice]      DECIMAL (18, 4)  NOT NULL,
    [ClosePrice]     DECIMAL (18, 4)  NOT NULL,
    [AdjustedClose]  DECIMAL (18, 4)  NOT NULL,
    [HighPrice]      DECIMAL (18, 4)  NOT NULL,
    [LowPrice]       DECIMAL (18, 4)  NOT NULL,
    [Volume]         BIGINT           NULL,
    [ProfitDay1]     DECIMAL (18, 4)  NULL,
    [ProfitDay2]     DECIMAL (18, 4)  NULL,
    [ProfitDay3]     DECIMAL (18, 4)  NULL,
    [ProfitDay4]     DECIMAL (18, 4)  NULL,
    [ProfitDay5]     DECIMAL (18, 4)  NULL,
    [ProfitDay6]     DECIMAL (18, 4)  NULL,
    [ProfitDay7]     DECIMAL (18, 4)  NULL,
    [ProfitDay8]     DECIMAL (18, 4)  NULL,
    [ProfitDay9]     DECIMAL (18, 4)  NULL,
    [ProfitDay10]    DECIMAL (18, 4)  NULL,
    [ProfitDay20]    DECIMAL (18, 4)  NULL,
    [ProfitDay30]    DECIMAL (18, 4)  NULL,
    [IndicatorsJson] NVARCHAR (MAX)   NULL,
    [Beta]           DECIMAL (10, 5)  NULL,
    [RawData]        NVARCHAR (MAX)   NULL,


    CONSTRAINT [PK_StockTradesTradingSimulations] PRIMARY KEY CLUSTERED ([Id] ASC)
);

