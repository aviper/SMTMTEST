﻿CREATE TABLE [Trading].[Trades] (
    [Id]                UNIQUEIDENTIFIER CONSTRAINT [DF_Trades_Id] DEFAULT (newid()) NOT NULL,
    [HistoryData]       NVARCHAR (MAX)   NOT NULL,
    [HistoryId]         UNIQUEIDENTIFIER NULL,
    [Symbol]            NVARCHAR (50)    NOT NULL,
    [NumberOfShares]    INT              NULL,
    [BuyPrice]          FLOAT (53)       NOT NULL,
    [BuyDate]           DATETIME         CONSTRAINT [DF_Tradess_Date] DEFAULT (getdate()) NOT NULL,
    [SellPrice]         FLOAT (53)       NULL,
    [PlannedSellDate]   DATETIME         NULL,
    [SellDate]          DATETIME         NULL,
    [Data]              NVARCHAR (MAX)   NULL,
    [IndicatorSellDate] DATETIME         NULL,
    [TargetPrice]       FLOAT (53)       NULL,
    [BuyRules]          NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_Trades] PRIMARY KEY CLUSTERED ([Id] ASC)
);

