﻿CREATE TABLE [Trading].[Strategies] (
    [Id]           UNIQUEIDENTIFIER CONSTRAINT [DF_Strategies_Id] DEFAULT (newid()) NOT NULL,
    [Name]         NVARCHAR (50)    NOT NULL,
    [Description]  NVARCHAR (255)   NULL,
    [StrategyData] NVARCHAR (MAX)   NOT NULL,
    [Created]      DATETIME         CONSTRAINT [DF_Strategies_Date] DEFAULT (getdate()) NOT NULL,
    [Enable]       BIT              NOT NULL,
    [Deleted]      BIT              NULL,
    [Default]      BIT              NULL,
    CONSTRAINT [PK_Strategies] PRIMARY KEY CLUSTERED ([Id] ASC)
);




GO
CREATE NONCLUSTERED INDEX [IDX_Strategies_Name]
    ON [Trading].[Strategies]([Name] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_Strategies_Enable]
    ON [Trading].[Strategies]([Enable] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_Strategies_Deleted]
    ON [Trading].[Strategies]([Deleted] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_Strategies_Created]
    ON [Trading].[Strategies]([Created] ASC);

