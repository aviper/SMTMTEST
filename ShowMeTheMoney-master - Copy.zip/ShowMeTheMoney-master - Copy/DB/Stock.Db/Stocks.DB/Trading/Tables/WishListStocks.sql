﻿CREATE TABLE [Trading].[WishListStocks] (
    [WishListStockId] UNIQUEIDENTIFIER NOT NULL,
    [WishListId]      UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_WishListStocks] PRIMARY KEY CLUSTERED ([WishListId] ASC, [WishListStockId] ASC),
    CONSTRAINT [FK_WishListStocks_WishLists] FOREIGN KEY ([WishListId]) REFERENCES [Trading].[WishLists] ([Id]),
    CONSTRAINT [FK_WishListStocks_WishLists1] FOREIGN KEY ([WishListStockId]) REFERENCES [Trading].[WishListStock] ([Id])
);

