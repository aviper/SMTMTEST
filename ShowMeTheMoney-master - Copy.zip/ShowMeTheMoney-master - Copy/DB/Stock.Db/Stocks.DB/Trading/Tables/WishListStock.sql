﻿CREATE TABLE [Trading].[WishListStock] (
    [Id]     UNIQUEIDENTIFIER CONSTRAINT [DF_WishListStock_Id] DEFAULT (newid()) NOT NULL,
    [Symbol] NVARCHAR (50)    NOT NULL,
    [Data]   NVARCHAR (MAX)   NULL,
    [Added]  DATETIME         CONSTRAINT [DF_WishListStock_Added] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_WishListStock_1] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_WishListStock]
    ON [Trading].[WishListStock]([Symbol] ASC);


GO

CREATE TRIGGER [Trading].[WishListStock_Change]
ON [Trading].[WishListStock]
AFTER INSERT
AS
BEGIN



DECLARE @Symbol nvarchar(50)

SELECT     @Symbol = Symbol FROM inserted 
   exec  [Stocks].[StockAdded]  @Symbol

	
END