﻿CREATE TABLE [Trading].[TradesIndicatorsAlert] (
    [Id]                        UNIQUEIDENTIFIER CONSTRAINT [DF_TradesIndicatorsAlert_Id] DEFAULT (newid()) NOT NULL,
    [StrategiesStocksHistoryId] UNIQUEIDENTIFIER NOT NULL,
    [Symbol]                    NVARCHAR (50)    NOT NULL,
    [NumberOfShares]            INT              NULL,
    [BuyPrice]                  DECIMAL (18, 6)  NOT NULL,
    [BuyDate]                   DATETIME         CONSTRAINT [DF_TradesIndicatorsAlerts_Date] DEFAULT (getdate()) NOT NULL,
    [SellPrice]                 DECIMAL (18, 6)  NULL,
    [PlannedSellDate]           DATETIME         NULL,
    [SellDate]                  DATETIME         NULL,
    [Data]                      NVARCHAR (MAX)   NULL,
    [Created]                   DATETIME         CONSTRAINT [DF_TradesIndicatorsAlert_Created] DEFAULT (getdate()) NOT NULL,
    [TotalScore]                FLOAT (53)       NULL,
    CONSTRAINT [PK_TradesIndicatorsAlert] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IDX_TradesIndicatorsAlert_TotalScore]
    ON [Trading].[TradesIndicatorsAlert]([TotalScore] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_TradesIndicatorsAlert_Symbol]
    ON [Trading].[TradesIndicatorsAlert]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_TradesIndicatorsAlert_StrategiesStocksHistoryId]
    ON [Trading].[TradesIndicatorsAlert]([StrategiesStocksHistoryId] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_TradesIndicatorsAlert_SellDate]
    ON [Trading].[TradesIndicatorsAlert]([SellDate] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_TradesIndicatorsAlert_BuyDate]
    ON [Trading].[TradesIndicatorsAlert]([BuyDate] ASC);

