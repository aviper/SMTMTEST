﻿CREATE TABLE [Strategies].[StrategiesStocksHistory] (
    [Id]                                 UNIQUEIDENTIFIER CONSTRAINT [DF_StrategiesStocksHistory_Id] DEFAULT (newid()) NOT NULL,
    [StrategyId]                         UNIQUEIDENTIFIER NULL,
    [StrategiesStockId]                  UNIQUEIDENTIFIER NOT NULL,
    [Symbol]                             VARCHAR (10)     NOT NULL,
    [Message]                            NVARCHAR (255)   NOT NULL,
    [ScanCode]                           NVARCHAR (50)    NOT NULL,
    [PostMarketData]                     NVARCHAR (MAX)   NULL,
    [PostMarketScore]                    FLOAT (53)       NULL,
    [PostMarketScanDate]                 DATETIME         NULL,
    [PostMarketHistoryStatisticsData]    NVARCHAR (MAX)   NULL,
    [PostMarketValidateData]             NVARCHAR (MAX)   NULL,
    [PostMarketGeneratedStrategyData]    NVARCHAR (MAX)   NULL,
    [PreMarketDataUseOnlineData]         BIT              NULL,
    [PreMarketData]                      NVARCHAR (MAX)   NULL,
    [PreMarketScore]                     FLOAT (53)       NULL,
    [PreMarketScanDate]                  DATETIME         NULL,
    [PreMarketHistoryStatisticsData]     NVARCHAR (MAX)   NULL,
    [PreMarketGeneratedStrategyData]     NVARCHAR (MAX)   NULL,
    [PreMarketValidateData]              NVARCHAR (MAX)   NULL,
    [RegularMarketData]                  NVARCHAR (MAX)   NULL,
    [RegularMarketScore]                 FLOAT (53)       NULL,
    [RegularMarketScanDate]              DATETIME         NULL,
    [RegularMarketHistoryStatisticsData] NVARCHAR (MAX)   NULL,
    [RegularMarketGeneratedStrategyData] NVARCHAR (MAX)   NULL,
    [RegularMarketValidateData]          NVARCHAR (MAX)   NULL,
    [SentimentalData]                    NVARCHAR (MAX)   NULL,
    [SentimentalScore]                   FLOAT (53)       NULL,
    [TradeSimulationData]                NVARCHAR (MAX)   NULL,
    [TradeSimulationScore]               FLOAT (53)       NULL,
    [Added]                              DATETIME         CONSTRAINT [DF_StrategiesStocksHistory_Added] DEFAULT (getdate()) NOT NULL,
    [Updated]                            DATETIME         CONSTRAINT [DF_StrategiesStocksHistory_Updated] DEFAULT (getdate()) NOT NULL,
    [TotalScore]                         FLOAT (53)       NULL,
    [BuyStock]                           BIT              NULL,
    [BuyDate]                            DATETIME         NULL,
    [Data]                               NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_StrategiesStocksHistory] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_StrategiesStocksHistory_Strategies] FOREIGN KEY ([StrategyId]) REFERENCES [Trading].[Strategies] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_ScanCode]
    ON [Strategies].[StrategiesStocksHistory]([ScanCode] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_ScanDates]
    ON [Strategies].[StrategiesStocksHistory]([PostMarketScanDate] ASC, [PreMarketScanDate] ASC, [RegularMarketScanDate] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_SentimentalScore]
    ON [Strategies].[StrategiesStocksHistory]([SentimentalScore] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_Symbol]
    ON [Strategies].[StrategiesStocksHistory]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_TotalScore]
    ON [Strategies].[StrategiesStocksHistory]([TotalScore] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksHistory_Updated]
    ON [Strategies].[StrategiesStocksHistory]([Updated] ASC);

