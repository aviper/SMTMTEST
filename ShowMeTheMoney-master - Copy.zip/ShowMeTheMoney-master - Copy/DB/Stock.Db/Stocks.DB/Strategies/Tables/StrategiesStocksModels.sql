﻿CREATE TABLE [Strategies].[StrategiesStocksModels] (
    [Id]                       UNIQUEIDENTIFIER CONSTRAINT [DF_StrategiesStocksModels_Id] DEFAULT (newid()) NOT NULL,
    [StrategyId]               UNIQUEIDENTIFIER NULL,
    [Symbol]                   VARCHAR (10)     NOT NULL,
    [ModelData]                NVARCHAR (MAX)   NULL,
    [TopScoreSignalStatistics] NVARCHAR (MAX)   NULL,
    [AllDaySignalStatistics]   NVARCHAR (MAX)   NULL,
    [Score]                    FLOAT (53)       NULL,
    [Added]                    DATETIME         CONSTRAINT [DF_StrategiesStocksModels_Added] DEFAULT (getdate()) NOT NULL,
    [Updated]                  DATETIME         CONSTRAINT [DF_StrategiesStocksModels_Updated] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_StrategiesStocksModels] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksModels_Symbol]
    ON [Strategies].[StrategiesStocksModels]([Symbol] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksModels_StrategyId]
    ON [Strategies].[StrategiesStocksModels]([StrategyId] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksModels_Score]
    ON [Strategies].[StrategiesStocksModels]([Score] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_StrategiesStocksModels_Added]
    ON [Strategies].[StrategiesStocksModels]([Added] ASC);

