﻿--EXEC sp_TradeStatsByIndicators    @Symbol = NULL,    @StartDate = NULL,    @FilterIndicators = 'IsAboveSmaShortRisingStreak2';-- Single symbol, all dates, multiple indicators
--EXEC sp_TradeStatsByIndicators    @Symbol = 'NVDA',    @StartDate = NULL,    @FilterIndicators = 'IsAboveSmaShortRisingStreak2,IsBelowSmaLong';-- Single symbol, date filter, no indicator filter (all)
--EXEC sp_TradeStatsByIndicators    @Symbol = 'NVDA',    @StartDate = '2020-01-01',    @FilterIndicators = NULL;
CREATE PROCEDURE sp_TradeStatsByIndicators
    @Symbol NVARCHAR(20) = NULL,
    @StartDate DATE = NULL,
    @FilterIndicators NVARCHAR(MAX) = NULL  -- Optional comma-separated list
AS
BEGIN
    SET NOCOUNT ON;

    -- Drop temp table if exists
    IF OBJECT_ID('tempdb..#FilteredTrades') IS NOT NULL
        DROP TABLE #FilteredTrades;

    -- Build filter conditions dynamically inside the query
    SELECT *
    INTO #FilteredTrades
    FROM [History].[StockTrades]
    WHERE
        -- Symbol filter: apply only if @Symbol NOT NULL or empty
        (@Symbol IS NULL OR @Symbol = '' OR Symbol = @Symbol)
        AND
        -- Date filter: apply only if @StartDate is NOT NULL
        (@StartDate IS NULL OR TradeDate > @StartDate)
        AND
        ProfitDay5 IS NOT NULL
        AND
        (
            @FilterIndicators IS NULL 
            OR EXISTS (
                SELECT 1 FROM STRING_SPLIT(@FilterIndicators, ',') AS ind
                WHERE JSON_VALUE(IndicatorsJson, '$.' + LTRIM(RTRIM(ind.value))) IS NOT NULL
            )
        );

    -- Overall summary
    SELECT  
        COUNT(*) AS TotalTrades,
        SUM(ProfitDay5) AS TotalProfitDay5,
        AVG(ProfitDay5) AS AvgProfitDay5,

        COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS NumPositiveDays,
        COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END) AS NumNegativeDays,

        CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(*), 0) AS WinRate,

        SUM(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) / 
            NULLIF(ABS(SUM(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END)), 0) AS ProfitFactor,

        AVG(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) AS AvgPositiveProfit,
        AVG(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END) AS AvgNegativeLoss,

        CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / 
            NULLIF(COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END), 0) AS PositiveNegativeRatio

    FROM #FilteredTrades;

    -- Per-indicator breakdown
    SELECT 
        Indicator.[key] AS IndicatorName,
        COUNT(*) AS TotalTrades,
        SUM(F.ProfitDay5) AS TotalProfitDay5,
        AVG(F.ProfitDay5) AS AvgProfitDay5,

        COUNT(CASE WHEN F.ProfitDay5 > 0 THEN 1 END) AS NumPositiveDays,
        COUNT(CASE WHEN F.ProfitDay5 < 0 THEN 1 END) AS NumNegativeDays,

        CAST(COUNT(CASE WHEN F.ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(*), 0) AS WinRate,

        SUM(CASE WHEN F.ProfitDay5 > 0 THEN F.ProfitDay5 END) / 
            NULLIF(ABS(SUM(CASE WHEN F.ProfitDay5 < 0 THEN F.ProfitDay5 END)), 0) AS ProfitFactor,

        AVG(CASE WHEN F.ProfitDay5 > 0 THEN F.ProfitDay5 END) AS AvgPositiveProfit,
        AVG(CASE WHEN F.ProfitDay5 < 0 THEN F.ProfitDay5 END) AS AvgNegativeLoss,

        CAST(COUNT(CASE WHEN F.ProfitDay5 > 0 THEN 1 END) AS FLOAT) / 
            NULLIF(COUNT(CASE WHEN F.ProfitDay5 < 0 THEN 1 END), 0) AS PositiveNegativeRatio

    FROM #FilteredTrades F
    CROSS APPLY OPENJSON(F.IndicatorsJson) AS Indicator
    WHERE (
        @FilterIndicators IS NULL 
        OR Indicator.[key] IN (
            SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@FilterIndicators, ',')
        )
    )
    GROUP BY Indicator.[key];

    -- Clean up
    DROP TABLE #FilteredTrades;
END