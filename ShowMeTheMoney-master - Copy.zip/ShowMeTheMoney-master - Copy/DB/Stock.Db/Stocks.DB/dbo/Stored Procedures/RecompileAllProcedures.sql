﻿CREATE procedure [dbo].[RecompileAllProcedures]
as
begin
    declare cur cursor for 
    (
        select quotename(s.name) + '.' + quotename(o.name) as procname
        from 
           sys.objects o
           inner join sys.schemas s on o.schema_id = s.schema_id
        where  o.[type] in ('P', 'FN', 'IF')
    );

    declare @procname sysname;

    open cur;
    fetch next from cur into @procname;
    while @@fetch_status=0 
    begin
        exec sp_recompile @procname;
        fetch next from cur into @procname;
    end;
    close cur;
    deallocate cur;
end;

DECLARE @cmd varchar(1000)

DECLARE view_cursor CURSOR FOR
SELECT 'EXEC sp_recompile ''' +TABLE_SCHEMA+ '.'+ TABLE_NAME + ''';' FROM INFORMATION_SCHEMA.Views;

OPEN view_cursor

-- Perform the first fetch.
FETCH NEXT FROM view_cursor INTO @cmd

-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
WHILE @@FETCH_STATUS = 0
BEGIN
	-- Execute Command
	exec (@cmd)
	print @cmd
	-- This is executed as long as the previous fetch succeeds.
	FETCH NEXT FROM view_cursor INTO @cmd
END

CLOSE view_cursor
DEALLOCATE view_cursor