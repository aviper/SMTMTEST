﻿create PROCEDURE [dbo].[PrintStockCounts]
AS
BEGIN
    -- Declare variables to hold the count results
    DECLARE @StockInfoCount INT,
			@StockInfoSectorCount INT,
            @StocksCount INT,
            @StocksHistoryCount INT,
			 @StocksHistoryDataCount INT,
            @NasdaqStocksCount INT,
            @StockTradesCount INT,
            @TradeIndicatorsCount INT,
            @DistinctSymbolsCount INT;

    -- Get the count of records for each table
    SELECT @StockInfoCount = count(1) FROM [Stocks].[StocksHistory];
    SELECT @StockInfoSectorCount = count(1) FROM [Stocks].[StocksHistory] where Sector is not null;
    SELECT @StocksCount = count(1) FROM [Stocks].Stocks;
    SELECT @StocksHistoryCount = count(1) FROM [Stocks].StocksHistory;
    SELECT @StocksHistoryDataCount = count(1) FROM [Stocks].StocksHistory where LastPrice>0;
    SELECT @NasdaqStocksCount = count(1) FROM Stocks.NasdaqStocks;
    SELECT @StockTradesCount = count(1) FROM [History].StockTrades;

    -- Get the count of distinct stock symbols
    SELECT @DistinctSymbolsCount = count(DISTINCT Symbol) FROM [History].[StockTrades];

    -- Print the results
    PRINT 'StocksHistory Count: ' + CAST(@StockInfoCount AS VARCHAR(10));
    PRINT 'StocksHistory with Sector Count: ' + CAST(@StockInfoSectorCount AS VARCHAR(10));
    PRINT 'Stocks Count: ' + CAST(@StocksCount AS VARCHAR(10));
    PRINT 'StocksHistory Count: ' + CAST(@StocksHistoryCount AS VARCHAR(10));
    PRINT 'StocksHistory Data Count: ' + CAST(@StocksHistoryDataCount AS VARCHAR(10));

    PRINT 'NasdaqStocks Count: ' + CAST(@NasdaqStocksCount AS VARCHAR(10));
    PRINT 'StockTrades Count: ' + CAST(@StockTradesCount AS VARCHAR(10));
    PRINT 'Distinct StockTrades Count: ' + CAST(@DistinctSymbolsCount AS VARCHAR(10));
END