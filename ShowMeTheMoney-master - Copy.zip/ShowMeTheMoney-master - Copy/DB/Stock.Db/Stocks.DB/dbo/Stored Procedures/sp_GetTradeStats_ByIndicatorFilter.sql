﻿CREATE PROCEDURE [dbo].[sp_GetTradeStats_ByIndicatorFilter]
    @IndicatorFilter NVARCHAR(MAX),
    @TruncateTable BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    -- Truncate the results table if requested
    IF @TruncateTable = 1
    BEGIN
        TRUNCATE TABLE [Reports].[TradeStatsResults];
    END

    -- Check if the indicator already exists in the results table
    IF EXISTS (
        SELECT 1
        FROM [Reports].[TradeStatsResults]
        WHERE IndicatorFilter = @IndicatorFilter
    )
    BEGIN
        PRINT 'Skipping already processed indicator: ' + @IndicatorFilter;
        RETURN;
    END

    -- Insert results for the indicator
    INSERT INTO [Reports].[TradeStatsResults] (
        IndicatorFilter,
        TotalTrades,
        TotalProfitDay5,
        AvgProfitDay5,
        NumPositiveDays,
        NumNegativeDays,
        WinRate,
        ProfitFactor,
        AvgPositiveProfit,
        AvgNegativeLoss,
        PositiveNegativeRatio,
        TotalProfitDay6,
        TotalProfitDay7,
        TotalProfitDay8,
        TotalProfitDay9,
        TotalProfitDay10
    )
    SELECT  
        @IndicatorFilter,
        COUNT(*) AS TotalTrades,
        SUM(ProfitDay5),
        AVG(ProfitDay5),
        COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END),
        COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END),
        CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(*), 0),
        SUM(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) / NULLIF(ABS(SUM(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END)), 0),
        AVG(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END),
        AVG(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END),
        CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END), 0),
        SUM(ProfitDay6),
        SUM(ProfitDay7),
        SUM(ProfitDay8),
        SUM(ProfitDay9),
        SUM(ProfitDay10)
    FROM [History].[StockTrades]
    WHERE 
        --Symbol != 'q4qq'
         IndicatorsJson LIKE '%' + @IndicatorFilter + '%'
END