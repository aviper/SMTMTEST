﻿--EXEC sp_GetTradeStats_ByIndicatorFilter @IndicatorFilter = 'IsAboveSmaShort'


CREATE PROCEDURE [dbo].[sp_PopulateTradeStats]
AS
BEGIN
    SET NOCOUNT ON;
    --        TRUNCATE TABLE [Reports].[TradeStatsResults];


END