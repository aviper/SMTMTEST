-- Step 1: Drop temp table if it already exists
IF OBJECT_ID('tempdb..#FilteredTrades') IS NOT NULL 
    DROP TABLE #FilteredTrades;

    SELECT count(sh.Symbol)
FROM [Stocks].[StocksHistory] sh
WHERE  (sh.MarketCap > 100000000000 )  --OR sh.MarketCap = -1
  And IsValid=1
-- Step 2: Create #FilteredTrades with filters applied
SELECT ft.*
INTO #FilteredTrades
FROM [History].[StockTrades] ft
JOIN [Stocks].[StocksHistory] sh
    ON ft.Symbol = sh.Symbol
WHERE ft.TradeDate > '2010-01-01' --and ft.Symbol ='tsla'  
  AND (sh.MarketCap > 100000000000 ) --OR sh.MarketCap = -1
  AND ft.IndicatorsJson LIKE '%IsAboveSmaShortRisingStreak2%'
  --AND ft.IndicatorsJson LIKE '%StrategyIsVwapMacdBuy%'

  --ALL	7011	3844.6680	0.549395	3877	3109	0.552988161460562	1.424286	3.328903	-2.914600	1.24702476680605
    SELECT 
    ISNULL(Symbol, 'ALL') AS Symbol,
    COUNT(*) AS TotalTrades,
    SUM(ProfitDay5) AS TotalProfitDay5,
    AVG(ProfitDay5) AS AvgProfitDay5,
    COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS NumPositiveDays,
    COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END) AS NumNegativeDays,
    CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / NULLIF(COUNT(*), 0) AS WinRate,
    SUM(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) / 
        NULLIF(ABS(SUM(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END)), 0) AS ProfitFactor,
    AVG(CASE WHEN ProfitDay5 > 0 THEN ProfitDay5 END) AS AvgPositiveProfit,
    AVG(CASE WHEN ProfitDay5 < 0 THEN ProfitDay5 END) AS AvgNegativeLoss,
    CAST(COUNT(CASE WHEN ProfitDay5 > 0 THEN 1 END) AS FLOAT) / 
        NULLIF(COUNT(CASE WHEN ProfitDay5 < 0 THEN 1 END), 0) AS PositiveNegativeRatio
FROM #FilteredTrades
GROUP BY ROLLUP(Symbol)
ORDER BY Symbol;


-- Step 2: Parse indicators from JSON and keep only true indicators (bit=1)
IF OBJECT_ID('tempdb..#ParsedIndicators') IS NOT NULL DROP TABLE #ParsedIndicators;

SELECT
    t.ProfitDay5,
    j.[key] AS Indicator,
    TRY_CAST(j.[value] AS BIT) AS IndicatorValue
INTO #ParsedIndicators
FROM #FilteredTrades t
CROSS APPLY OPENJSON(t.IndicatorsJson) AS j
WHERE TRY_CAST(j.[value] AS BIT) = 1;

-- Step 3: Aggregate stats per indicator
SELECT
    Indicator,
    COUNT(*) AS TradeCount,
    SUM(CASE WHEN ProfitDay5 > 0 THEN 1 ELSE 0 END) AS UpDays,
    SUM(CASE WHEN ProfitDay5 < 0 THEN 1 ELSE 0 END) AS DownDays,
    CAST(SUM(CASE WHEN ProfitDay5 > 0 THEN 1 ELSE 0 END) AS FLOAT) / NULLIF(COUNT(*), 0) AS UpRatio,
    SUM(ProfitDay5) AS TotalProfit,
    AVG(ProfitDay5) AS AvgProfit
FROM #ParsedIndicators
GROUP BY Indicator
ORDER BY TradeCount DESC;



SELECT  
    SUM(Day5_Positive) AS TotalPositive,
    SUM(Day5_Negative) AS TotalNegative,
    CAST(SUM(Day5_Positive) AS FLOAT) / NULLIF(SUM(Day5_Positive + Day5_Negative), 0) AS WinRate,
    CAST(SUM(Day5_Positive) AS FLOAT) / NULLIF(SUM(Day5_Negative), 0) AS WinLossRatio,
    AVG(Day5_AvgProfit) AS AvgProfitDay5
FROM [History].[StockTradeSummary]
WHERE IndicatorName = 'IsAboveSmaShortRisingStreak4' --and StockSymbol='qqq';


