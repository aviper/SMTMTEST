SELECT 
    IndicatorName,
   -- symbol,
    -- Performance Metrics
   -- AVG(CAST(Day1_AvgProfit AS FLOAT)) AS AvgProfit_Day1,
  --  AVG(CAST(Day2_AvgProfit AS FLOAT)) AS AvgProfit_Day2,
  --  AVG(CAST(Day3_AvgProfit AS FLOAT)) AS AvgProfit_Day3,
 --   AVG(CAST(Day4_AvgProfit AS FLOAT)) AS AvgProfit_Day4,
    AVG(CAST(Day5_AvgProfit AS FLOAT)) AS AvgProfit_Day5,
    AVG(CAST(Day6_AvgProfit AS FLOAT)) AS AvgProfit_Day6,
    AVG(CAST(Day7_AvgProfit AS FLOAT)) AS AvgProfit_Day7,
--    AVG(CAST(Day8_AvgProfit AS FLOAT)) AS AvgProfit_Day8,
--    AVG(CAST(Day9_AvgProfit AS FLOAT)) AS AvgProfit_Day9,
 --   AVG(CAST(Day10_AvgProfit AS FLOAT)) AS AvgProfit_Day10,
    AVG(CAST(Day5_UpRatio AS FLOAT)) AS AvgUpRatio_Day5,
    SUM(ISNULL(Day5_Positive, 0)) AS TotalPositiveDay5,
    SUM(ISNULL(Day5_Negative, 0)) AS TotalNegativeDay5,
    SUM(ISNULL(Day5_Positive, 0) + ISNULL(Day5_Negative, 0)) AS TotalTradesDay5
FROM [History].[StockTradeSummary]
WHERE
--Symbol='NVDA' And
    indicatorName like 'IsProfitAbove3PercentLast%'
   -- And Day5_AvgProfit>=1.1
   -- and Day5_UpRatio>55

    -- Minimum sample size filter (avoid noise)
   -- (ISNULL(Day5_Positive, 0) + ISNULL(Day5_Negative, 0)) >= 1

    -- Only include indicators with a Day5 average profit > 0
   -- AND ISNULL(Day5_AvgProfit, 0) < 0

    -- Only include indicators with >50% win rate
    --AND ISNULL(Day5_UpRatio, 0) > 0.5

GROUP BY 
    IndicatorName--,symbol

ORDER BY 
    AvgProfit_Day5 desc
