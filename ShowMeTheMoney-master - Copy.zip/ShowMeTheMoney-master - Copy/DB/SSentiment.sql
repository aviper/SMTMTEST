--Strong Buy
SELECT TOP (1000) *
  FROM [History].[UpgradeDowngradeHistory] where toGrade='Strong Buy' and  Action IN ( 'up','init','reit')and CurrentPriceTarget>CurrentPrice;
  SELECT 
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
WHERE toGrade='Strong Buy' and  Action IN ( 'up','init','reit') and CurrentPriceTarget>CurrentPrice;
--Buy
SELECT TOP (1000) *
  FROM [History].[UpgradeDowngradeHistory] where toGrade='Buy' and   Action !='down' and CurrentPriceTarget>CurrentPrice
  and PriceTargetAction in ('Maintains','Lowers','Raises');

		SELECT
			--Action,
		  COUNT(*) AS TotalCount,
		  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
		  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
		  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
		  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
		  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
		  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
		FROM [History].[UpgradeDowngradeHistory]

		WHERE   toGrade='Buy' and   Action !='down' and CurrentPriceTarget>CurrentPrice
		  and PriceTargetAction in ('Maintains','Lowers','Raises')
  group by Action
--Hold
SELECT TOP (1000) *
  FROM [History].[UpgradeDowngradeHistory] where toGrade='Hold'
  SELECT 
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
   FROM [History].[UpgradeDowngradeHistory] where toGrade='Hold'
  --select distinct  symbol  FROM [History].[UpgradeDowngradeHistory]
  
  --select distinct  Action  FROM [History].[UpgradeDowngradeHistory]
SELECT 
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
-- where Symbol='tsla'


 SELECT 
 PriceTargetAction,
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
--WHERE Action !='down'
 GROUP BY PriceTargetAction
ORDER BY AvgReturn5Days DESC;



 SELECT 
  Action,
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
--WHERE Action IN ('main', 'up', 'init', 'reit')
GROUP BY Action
ORDER BY AvgReturn5Days DESC;

SELECT 
  COUNT(*) AS TotalCount,
  SUM(PriceAfterDay5 - CurrentPrice) AS TotalReturn5Days,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
WHERE Action IN ('main', 'up', 'init', 'reit')
  AND ToGrade IN (
    'Market Outperform',
    'Peer Perform',
    'Outperform',
    'Overweight',
    'Equal-Weight',
    'Strong Buy',
    'Positive',
    'Buy',
    'Sector Perform',
    'Sector Outperform'
  );


  --A. Average Return by Action
SELECT 
  Action,
  COUNT(*) AS Count,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgDay5Return,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100 AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
-- WHERE [Date] >= '2020-01-01'  -- Optional filter
GROUP BY Action
ORDER BY Count DESC;




--Grade Change Distribution
SELECT  
  ToGrade, 
  COUNT(*) AS Count,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100 AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
GROUP BY ToGrade
HAVING COUNT(*) > 100
ORDER BY AvgReturn5Days DESC;




--D. Firm Performance Over Time


SELECT   Firm,  COUNT(*) AS Count,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days
FROM [History].[UpgradeDowngradeHistory]
where Action in ('up')-- in('main','up','init','reit') 
GROUP BY Firm ORDER BY COUNT(*) DESC;



SELECT 
  --Firm,
  COUNT(*) AS TotalCount,
  AVG(CASE WHEN Action = 'main' THEN PriceAfterDay5 - CurrentPrice END) AS AvgReturn_Main,
  AVG(CASE WHEN Action = 'up' THEN PriceAfterDay5 - CurrentPrice END) AS AvgReturn_Up,
  AVG(CASE WHEN Action = 'init' THEN PriceAfterDay5 - CurrentPrice END) AS AvgReturn_Init,
  AVG(CASE WHEN Action = 'reit' THEN PriceAfterDay5 - CurrentPrice END) AS AvgReturn_Reit
FROM [History].[UpgradeDowngradeHistory]
WHERE Action IN ('main', 'up', 'init', 'reit')
--GROUP BY Firm
HAVING COUNT(*) > 10
ORDER BY AvgReturn_Up DESC;





SELECT 
  Firm,
  COUNT(*) AS Count,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100 AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
 WHERE [Date] >= '2020-01-01'  -- Optional filter for recent data
 And  Action in('main','up','init','reit') 
GROUP BY Firm
HAVING COUNT(*) >= 10  -- Optional: filter out small sample firms
ORDER BY Count DESC;


 --Query to Analyze PriceTargetAction:

 SELECT 
  PriceTargetAction,
  COUNT(*) AS Count,
  AVG(PriceAfterDay5 - CurrentPrice) AS AvgReturn5Days,
  AVG((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS AvgPercentReturn5Days,
  MIN((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MinPercentReturn5Days,
  MAX((PriceAfterDay5 - CurrentPrice) / NULLIF(CurrentPrice, 0)) * 100 AS MaxPercentReturn5Days,
  SUM(CASE WHEN PriceAfterDay5 >= CurrentPriceTarget THEN 1 ELSE 0 END) * 1.0 / COUNT(*) * 100 AS TargetHitRatePercent
FROM [History].[UpgradeDowngradeHistory]
WHERE PriceTargetAction IS NOT NULL
GROUP BY PriceTargetAction
ORDER BY Count DESC;

--query to select only bullish items
SELECT *
FROM [History].[UpgradeDowngradeHistory]
WHERE ToGrade IN (
    'Market Outperform',
    'Peer Perform',
    'Outperform',
    'Overweight',
    'Equal-Weight',
    'Strong Buy',
    'Positive',
    'Buy',
    'Sector Perform',
    'Sector Outperform'
);
