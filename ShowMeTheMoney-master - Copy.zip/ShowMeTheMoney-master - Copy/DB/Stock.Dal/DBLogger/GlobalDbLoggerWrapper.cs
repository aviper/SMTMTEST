﻿using Stock.Common.Dto;
using Stock.Common.Logger;
using Stock.Dal.Dal;
using System;
using System.Threading.Tasks;
using static Stock.Common.Enums.Enums;
using static Stock.Common.Logger.GlobalDbLogger;

namespace Stock.Dal.DBLogger
{
    public class GlobalDbLoggerWrapper : IGlobalDbLoggerWrapper
    {
        public event EventHandler<LogEventArgs> ErrorEvent;

        public event EventHandler<LogEventArgs> WarningEvent;

        public event EventHandler<LogEventArgs> InfoEvent;

        public event EventHandler<LogEventArgs> DebugEvent;

        private StockLogManager.ELoggerTypeEnum _application;
        public DbLogLevel Loglevel { get; set; }
        private DbDal _dbDal;

        public GlobalDbLoggerWrapper(StockLogManager.ELoggerTypeEnum application)
        {
            _application = application;
            _dbDal = new DbDal();

            Loglevel = DbLogLevel.Error; //Read from config or registry
        }

        protected virtual void OnError(string message)
        {
            ErrorEvent?.Invoke(this, new LogEventArgs(message));
        }

        protected virtual void OnInfo(string message)
        {
            InfoEvent?.Invoke(this, new LogEventArgs(message));
        }

        protected virtual void OnWarning(string message)
        {
            WarningEvent?.Invoke(this, new LogEventArgs(message));
        }

        protected virtual void OnDebug(string message)
        {
            DebugEvent?.Invoke(this, new LogEventArgs(message));
        }

        public void Debug(string message)
        {
            OnDebug(message);
            if (Loglevel >= DbLogLevel.Debug)
            {
                WriteToDb(DbLogLevel.Debug, message, _application.ToString());
            }
        }

        public void Error(string message)
        {
            OnError(message);
            if (Loglevel >= DbLogLevel.Error)
            {
                WriteToDb(DbLogLevel.Error, message, _application.ToString());
            }
        }

        private void WriteToDb(DbLogLevel level, string message, string application)
        {
            Task.Factory.StartNew(() => DoWriteToDb(new LogDto(level, message, application)));
        }

        private void DoWriteToDb(LogDto log)
        {
            //TODO return this after DEBUG
            //_dbDal.WriteLogMessage(log);
            //Console.WriteLine("DoWriteToDb Disable!!!");
        }

        public void Fatal(string message)
        {
            OnError(message);

            if (Loglevel >= DbLogLevel.Error)
            {
                WriteToDb(DbLogLevel.Error, message, _application.ToString());
            }
        }

        public void Info(string message)
        {
            OnInfo(message);
            if (Loglevel >= DbLogLevel.Info)
            {
                WriteToDb(DbLogLevel.Info, message, _application.ToString());
            }
        }

        public void Warn(string message)
        {
            OnWarning(message);

            if (Loglevel >= DbLogLevel.Warn)
            {
                WriteToDb(DbLogLevel.Warn, message, _application.ToString());
            }
        }
    }
}