﻿using Stock.Dal.DBModel;
using static Stock.Common.Dto.AnalysisHistoryDto;

namespace Stock.Dal.Helpers
{
    public class SimulationResultsConverter
    {
        internal static AnalysisHistoryItemDto ToDto(SimulationResult item)
        {
            var result = new AnalysisHistoryItemDto();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol.Trim();
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = (item.Rank.HasValue ? item.Rank.Value : 0);
            result.Source = item.Source;
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            result.Data = StocksHistoryItemDataDto.FromString(item.Data);

            return result;
        }

        internal static SimulationResult FromDto(AnalysisHistoryItemDto item)
        {
            var result = new SimulationResult();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol;
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = item.Rank;
            result.Source = item.Source;
            result.Data = item.Data.ToString();
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            return result;
        }

        internal static AnalysisHistoryItemDto ScreenerDataToDto(SimulationResultsData item)
        {
            var result = new AnalysisHistoryItemDto();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol.Trim();
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = (item.Rank.HasValue ? item.Rank.Value : 0);
            result.Source = item.Source;
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            result.Data = StocksHistoryItemDataDto.FromString(item.Data);

            return result;
        }

        internal static SimulationResultsData ScreenerDataFromDto(AnalysisHistoryItemDto item)
        {
            var result = new SimulationResultsData();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol;
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = item.Rank;
            result.Source = item.Source;
            result.Data = item.Data.ToString();
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            return result;
        }
    }
}