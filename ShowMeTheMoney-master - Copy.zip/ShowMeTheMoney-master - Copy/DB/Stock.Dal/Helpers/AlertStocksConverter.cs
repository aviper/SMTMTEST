﻿using Stock.Common.Dto;
using Stock.Dal.DBModel;

namespace Stock.Dal.Helpers
{
    public class AlertStocksConverter
    {
        internal static WishListStockDto ToDto(WishListStockView item)
        {
            var result = new Common.Dto.WishListStockDto();
            result.Data = WishListStockData.FromString(item.Data);
            result.Symbol = item.Symbol;
            if (item.Email != null)
            {
                result.AlertEmails.Add(new WishListDto(item.Name, item.Email, item.WatchListName, item.AlertAfterTrade, item.AlertBeforeTrade));
            }

            return result;
        }
    }
}