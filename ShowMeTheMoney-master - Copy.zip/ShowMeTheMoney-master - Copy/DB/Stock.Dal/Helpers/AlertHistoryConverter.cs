﻿using Stock.Common.Dto;
using Stock.Common.Enums;
using Stock.Dal.DBModel;
using static Stock.Common.Dto.AnalysisHistoryDto;

namespace Stock.Dal.Helpers
{
    public class AlertHistoryConverter
    {
        //internal static WatchListDto ToDto(WatchList item)
        //{
        //    var result = new WatchListDto();
        //    result.Id = item.Id;
        //    result.Name = item.Name;
        //    result.Weight = item.Weight.Value;
        //    result.SourceType = (SourceTypes)item.SourceType;

        //    if (item.logChanges.HasValue)
        //    {
        //        result.LogChanges = item.logChanges.Value;
        //    }

        //    return result;
        //}
        internal static AlertHistoryDataDto ToDto(AlertHistory obj)
        {
            var result = new AlertHistoryDataDto();
            result.Id = obj.Id;
            result.Code = obj.Code;
            result.Score = obj.Score;
            result.Symbol = obj.Symbol;
            result.Date = obj.Date;
            result.Price = obj.Price;
            result.Scanner = ProcessHistoryCodeEnum.Parse(obj.Scanner);
            result.DataItems = StocksHistoryItemDataDto.FromStringSafe(obj.Data);

            return result;
        }
    }
}