﻿using Stock.Common.Dto;

namespace Stock.Dal.Helpers
{
    public class SectorDataConverter
    {
        internal static SectorDataDto ToDto(DBModel.SectorsData item)
        {
            var result = new SectorDataDto();
            result.Id = item.Id;
            result.SectorNames = item.SectorNames;
            result.HistoricalData = SectorHistoricalData.FromString(item.HistoricalData);
            return result;
        }
    }
}