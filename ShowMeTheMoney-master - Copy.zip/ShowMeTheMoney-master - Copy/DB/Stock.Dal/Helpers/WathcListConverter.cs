﻿using Stock.Common;
using Stock.Common.Dto;
using Stock.Dal.DBModel;

namespace Stock.Dal.Helpers
{
    public class WathcListConverter
    {
        internal static WatchListDto ToDto(WatchList item)
        {
            var result = new WatchListDto();
            result.Id = item.Id;
            result.Name = item.Name;
            result.Weight = item.Weight.Value;
            result.SourceType = (SourceTypes)item.SourceType;

            if (item.logChanges.HasValue)
            {
                result.LogChanges = item.logChanges.Value;
            }

            return result;
        }
    }
}