﻿using Stock.Common.Dto;

namespace Stock.Dal.Helpers
{
    public class StocksConverter
    {
        internal static StocksDto.StockDto ToDto(DBModel.Stock item)
        {
            var result = new StocksDto.StockDto();
            result.Id = item.Id;
            result.WatchListId = item.WatchListId.GetValueOrDefault();
            result.WatchListName = item.WatchList.Name;
            result.Symbol = item.Symbol;
            result.Data = StocksDto.StockData.FromString(item.Data);
            result.Added = item.Added;
            result.Modified = item.Modified;
            result.InWatchList = item.InWatchList;
            result.PlaceInList = item.PlaceInList;
            if (!string.IsNullOrWhiteSpace(item.Path))
            {
                result.Links = LinksList.FromString(item.Path);
            }
            return result;
        }
    }
}