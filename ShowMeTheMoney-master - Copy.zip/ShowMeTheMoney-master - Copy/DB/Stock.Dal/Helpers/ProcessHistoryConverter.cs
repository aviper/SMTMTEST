﻿using Stock.Common.Enums;
using Stock.Dal.DBModel;
using static Stock.Common.Dto.ProcessHistoryDto;

namespace Stock.Dal.Helpers
{
    public class ProcessHistoryConverter
    {
        internal static ProcessHistory FromDto(ProcessHistoryItemDto item)
        {
            var result = new ProcessHistory();
            result.Id = item.Id;
            result.Name = item.Name;
            result.Info = item.Info;
            result.Code = item.Code.ToString();
            result.CreatedDate = item.CreatedDate;
            result.LastRunDate = item.LastRunDate;
            result.Id = item.Id;
            result.Data = item.Data.ToString();

            return result;
        }

        internal static ProcessHistoryItemDto ToDto(ProcessHistory item)
        {
            var result = new ProcessHistoryItemDto();
            result.Id = item.Id;
            result.Name = item.Name;
            result.Info = item.Info;
            result.Code = ProcessHistoryCodeEnum.Parse(item.Code);
            result.CreatedDate = item.CreatedDate;
            result.LastRunDate = item.LastRunDate;
            result.Id = item.Id;
            result.Data = ProcessHistoryItemDataDto.FromStringSafe(item.Data);

            return result;
        }
    }
}