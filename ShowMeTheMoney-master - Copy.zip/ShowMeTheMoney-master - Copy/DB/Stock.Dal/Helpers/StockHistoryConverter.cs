﻿using Stock.Common.Dto;
using Stock.Common.Helpers;
using Stock.Common.Settings;
using Stock.Dal.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Stock.Dal.Helpers
{
    public class StockHistoryConverter
    {
        internal static StocksHistoryItemDto ToStocksHistoryToRefreshDto(GetStocksHistories_Result stocksHistory)
        {
            var result = new StocksHistoryItemDto();

            result.Id = stocksHistory.Id;
            result.Symbol = stocksHistory.Symbol;

            if (Common.Settings.ShowMeTheMoneySettings.UseCompression)
            {
                if (!string.IsNullOrEmpty(stocksHistory.HistoryData))
                {
                    result.Data = StocksHistoryDataItemDataDto.FromStringSafe(GZip.DecompressString(stocksHistory.HistoryData));
                }
                else
                {
                    result.Data = new StocksHistoryDataItemDataDto();
                }
            }
            if (!string.IsNullOrEmpty(stocksHistory.MetaData))
            {
                result.StocksMetaData = StocksMetaDataDto.FromJson(stocksHistory.MetaData);

            }
            else
            {
                result.StocksMetaData = new StocksMetaDataDto();
            }

            result.Created = stocksHistory.Created;
            result.Updated = stocksHistory.Updated;
            if (result.Data.History.Count > 0)
            {
                result.FirstSample = result.Data.History.First().Key;
                result.LastSample = result.Data.History.Last().Key;
                result.LastPrice = result.Data.History.Last().Value.Close;

            }

            result.LastSync = stocksHistory.LastSync;
            result.IsValid = stocksHistory.IsValid;
            result.InvalidReason = stocksHistory.InvalidReason;
            result.SegmentStocks = stocksHistory.SegmentStocks;
            result.HoldAnalyticsData = HoldAnalyticsData.FromJson(stocksHistory.InitialHoldDataJson);

            return result;
        }


        internal static StocksHistoryItemDto ToStocksHistoryItemDtoDto(DBModel.StocksHistory stocksHistory)
        {
            if (stocksHistory == null)
                throw new ArgumentNullException(nameof(stocksHistory));

            var result = new StocksHistoryItemDto
            {
                Id = stocksHistory.Id,
                Symbol = stocksHistory.Symbol?.Trim(),
                EtfSymbol = stocksHistory.EtfSymbol?.Trim(),
                IndexSymbol = stocksHistory.IndexSymbol?.Trim(),
                SymbolGroup = stocksHistory.SymbolGroup?.Trim(),
                Created = stocksHistory.Created,
                Updated = stocksHistory.Updated,
                FirstSample = stocksHistory.FirstSample,
                LastSample = stocksHistory.LastSample,
                LastPrice = stocksHistory.LastPrice,
                LastSync = stocksHistory.LastSync,
                IsValid = stocksHistory.IsValid,
                InvalidReason = stocksHistory.InvalidReason,
                Sector = stocksHistory.Sector,
                Industry = stocksHistory.Industry,
                CompanyName = stocksHistory.CompanyName,
                LastMarketCap = stocksHistory.MarketCap,
                AverageDailyVolume3Month = stocksHistory.AverageDailyVolume3Month,
                FiftyTwoWeekLow = stocksHistory.FiftyTwoWeekLow,
                FiftyTwoWeekHigh = stocksHistory.FiftyTwoWeekHigh,
                EarningsDate = stocksHistory.EarningsDate,

                // Add missing properties
                QuoteType = stocksHistory.QuoteType,
                FiftyTwoWeekLowChangePercent = stocksHistory.FiftyTwoWeekLowChangePercent,
                FiftyTwoWeekHighChangePercent = stocksHistory.FiftyTwoWeekHighChangePercent,
                EarningsDateStart = stocksHistory.EarningsDateStart,
                EarningsDateEnd = stocksHistory.EarningsDateEnd,
                EpsTrailingTwelveMonths = stocksHistory.EpsTrailingTwelveMonths,
                EpsForward = stocksHistory.EpsForward,
                EpsCurrentYear = stocksHistory.EpsCurrentYear,
                PriceEpsCurrentYear = stocksHistory.PriceEpsCurrentYear,
                TrailingPE = stocksHistory.TrailingPE,
                SharesOutstanding = stocksHistory.SharesOutstanding,
                BookValue = stocksHistory.BookValue,
                PriceToBook = stocksHistory.PriceToBook,
                ForwardPE = stocksHistory.ForwardPE,
                AverageAnalystRating = stocksHistory.AverageAnalystRating,
                AverageAnalystRatingVal = stocksHistory.AverageAnalystRatingVal,
                AverageAnalystRatingStr = stocksHistory.AverageAnalystRatingStr,
                SegmentStocks = stocksHistory.SegmentStocks,
                HoldAnalyticsData = HoldAnalyticsData.FromJson(stocksHistory.InitialHoldDataJson)



            };

            if (Common.Settings.ShowMeTheMoneySettings.UseCompression)
            {
                result.Data = stocksHistory.HistoryData != null && stocksHistory.HistoryData != ""
                    ? StocksHistoryDataItemDataDto.FromStringSafe(GZip.DecompressString(stocksHistory.HistoryData))
                    : new StocksHistoryDataItemDataDto();
            }
            if (!string.IsNullOrEmpty(stocksHistory.MetaData))
            {
                result.StocksMetaData = StocksMetaDataDto.FromJson(stocksHistory.MetaData);

            }
            return result;
        }


        internal static void ApplyProfileToStockHistory(StockProfile profile, StocksHistory entity)
        {
            entity.Id = profile.Id;
            entity.EtfSymbol = profile.EtfSymbol;
            entity.IndexSymbol = profile.IndexSymbol;
            entity.SymbolGroup = profile.SymbolGroup;
            entity.Sector = profile.Sector;
            entity.Industry = profile.Industry;
            entity.MarketCap = profile.LastMarketCap;
            entity.AverageDailyVolume3Month = profile.AverageDailyVolume3Month;
            entity.FiftyTwoWeekLow = profile.FiftyTwoWeekLow;
            entity.FiftyTwoWeekHigh = profile.FiftyTwoWeekHigh;
            entity.EarningsDate = profile.EarningsDate;
            entity.LastPrice = profile.LastPrice;
            entity.CompanyName = profile.CompanyName;
            entity.IsValid = profile.IsValid;
            entity.InvalidReason = profile.InvalidReason;

            entity.QuoteType = profile.QuoteType;
            entity.FiftyTwoWeekLowChangePercent = profile.FiftyTwoWeekLowChangePercent;
            entity.FiftyTwoWeekHighChangePercent = profile.FiftyTwoWeekHighChangePercent;
            entity.EarningsDateStart = profile.EarningsDateStart;
            entity.EarningsDateEnd = profile.EarningsDateEnd;

            entity.EpsTrailingTwelveMonths = profile.EpsTrailingTwelveMonths;
            entity.EpsForward = profile.EpsForward;
            entity.EpsCurrentYear = profile.EpsCurrentYear;
            entity.PriceEpsCurrentYear = profile.PriceEpsCurrentYear;
            entity.TrailingPE = profile.TrailingPE;
            entity.SharesOutstanding = profile.SharesOutstanding;
            entity.BookValue = profile.BookValue;
            entity.PriceToBook = profile.PriceToBook;
            entity.ForwardPE = profile.ForwardPE;
            entity.AverageAnalystRating = profile.AverageAnalystRating;
            entity.LastInfoSync = DateTime.Now;
        }


        internal static StockProfile ToStockProfileDto(StockInfoView item)
        {
            return new StockProfile
            {
                Id = item.Id,
                Symbol = item.Symbol.ToUpper(),
                EtfSymbol = item.EtfSymbol?.ToUpper(),
                IndexSymbol = item.IndexSymbol?.ToUpper(),
                SymbolGroup = item.SymbolGroup?.ToUpper(),
                Industry = item.Industry,
                CompanyName = item.CompanyName,
                Sector = item.Sector,
                Created = item.Created,
                LastMarketCap = item.MarketCap,
                AverageDailyVolume3Month = item.AverageDailyVolume3Month,
                FiftyTwoWeekLow = item.FiftyTwoWeekLow,
                FiftyTwoWeekHigh = item.FiftyTwoWeekHigh,
                IsValid = item.IsValid,
                InvalidReason = item.InvalidReason,

                EarningsDate = item.EarningsDate,
                LastPrice = item.LastPrice,

                QuoteType = item.QuoteType,
                FiftyTwoWeekLowChangePercent = item.FiftyTwoWeekLowChangePercent,
                FiftyTwoWeekHighChangePercent = item.FiftyTwoWeekHighChangePercent,
                EarningsDateStart = item.EarningsDateStart,
                EarningsDateEnd = item.EarningsDateEnd,

                EpsTrailingTwelveMonths = item.EpsTrailingTwelveMonths,
                EpsForward = item.EpsForward,
                EpsCurrentYear = item.EpsCurrentYear,
                PriceEpsCurrentYear = item.PriceEpsCurrentYear,
                TrailingPE = item.TrailingPE,
                SharesOutstanding = item.SharesOutstanding,
                BookValue = item.BookValue,
                PriceToBook = item.PriceToBook,
                ForwardPE = item.ForwardPE,
                AverageAnalystRating = item.AverageAnalystRating,
                AverageAnalystRatingStr = item.AverageAnalystRatingStr,
                SegmentStocks = item.SegmentStocks,

                AverageAnalystRatingVal = item.AverageAnalystRatingVal,
                LastInfoSync = item.LastInfoSync,
                FirstSample = item.FirstSample,
                LastSample = item.LastSample,
                HoldAnalyticsData = HoldAnalyticsData.FromJson(item.InitialHoldDataJson),




            };
        }

        internal static StockProfileWithAlertsDto ToStockProfileWithAlertsViewsDto(StockProfileWithAlertsView item)
        {
            if (item == null) return null;

            return new StockProfileWithAlertsDto
            {
                Symbol = item.Symbol,
                FirstSample = item.FirstSample,
                LastSample = item.LastSample,
                LastPrice = item.LastPrice,
                Sector = item.Sector,
                Industry = item.Industry,
                CompanyName = item.CompanyName,
                LastMarketCap = item.MarketCap,
                AverageDailyVolume3Month = item.AverageDailyVolume3Month,
                FiftyTwoWeekLow = item.FiftyTwoWeekLow,
                FiftyTwoWeekHigh = item.FiftyTwoWeekHigh,
                EarningsDate = item.EarningsDate,
                QuoteType = item.QuoteType,
                FiftyTwoWeekLowChangePercent = item.FiftyTwoWeekLowChangePercent,
                FiftyTwoWeekHighChangePercent = item.FiftyTwoWeekHighChangePercent,
                EarningsDateStart = item.EarningsDateStart,
                EarningsDateEnd = item.EarningsDateEnd,
                EpsTrailingTwelveMonths = item.EpsTrailingTwelveMonths,
                EpsForward = item.EpsForward,
                EpsCurrentYear = item.EpsCurrentYear,
                PriceEpsCurrentYear = item.PriceEpsCurrentYear,
                TrailingPE = item.TrailingPE,
                SharesOutstanding = item.SharesOutstanding,
                BookValue = item.BookValue,
                PriceToBook = item.PriceToBook,
                ForwardPE = item.ForwardPE,
                AverageAnalystRating = item.AverageAnalystRating,
                AverageAnalystRatingVal = item.AverageAnalystRatingVal,
                AverageAnalystRatingStr = item.AverageAnalystRatingStr,

                PricePositionPercent = item.PricePositionPercent,
                ValuationCategory = item.ValuationCategory,
                PricePositionCategory = item.PricePositionCategory,
                HighPEAlert = item.HighPEAlert,
                NearLowPriceAlert = item.NearLowPriceAlert,
            };
        }

    }
}