﻿using Stock.Common.Dto;
using Stock.Common.Enums;
using Stock.Dal.DBModel;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Stock.Dal.Helpers
{
    internal class StockTradesDtoConverter
    {

        //     internal static Dictionary<string, StocksHistoryItemDto> ToStockHistoryTradeDictionaryDto(
        //List<string> symbols,
        //List<GetAllTradesBySymbols_Result> stocksHistory,
        //List<TradeIndicator> indicatorsResult)
        internal static Dictionary<string, StocksHistoryItemDto> ToStockHistoryTradeDictionaryDto(
            List<string> symbols, List<GetTradesBySymbolsAndDate_Result> stocksHistory,
            List<GetTradesWithIndicators_Result> indicatorsResult
            )

        {
            if (stocksHistory == null)
            {
                throw new ArgumentNullException(nameof(stocksHistory));
            }


            // Group indicators by Symbol and TradeDate for faster lookups
            var indicatorsGrouped = indicatorsResult?
                .GroupBy(i => new IndicatorKey { Symbol = i.Symbol, TradeDate = i.TradeDate })
                .ToDictionary(g => g.Key, g => g.ToList())
                ?? new Dictionary<IndicatorKey, List<GetTradesWithIndicators_Result>>();

            // Initialize the result dictionary
            var result = new Dictionary<string, StocksHistoryItemDto>();

            // Process stock history
            foreach (var item in stocksHistory)
            {
                if (!result.ContainsKey(item.Symbol))
                {
                    result[item.Symbol] = new StocksHistoryItemDto
                    {
                        Data = new StocksHistoryDataItemDataDto
                        {
                            History = new Dictionary<DateTime, HistoricalDataDto>()
                        }
                    };
                }

                // Get day signals efficiently
                var daySignals = GetDaySignalsFromGroupedIndicators(
                    item.Symbol,
                    item.TradeDate,
                    indicatorsGrouped
                );

                // Add historical data
                result[item.Symbol].Data.History[item.TradeDate] = new HistoricalDataDto(item.Symbol)
                {
                    Close = item.ClosePrice,
                    Open = item.OpenPrice,
                    High = item.HighPrice,
                    Low = item.LowPrice,
                    AdjustedClose = item.AdjustedClose,
                    Volume = item.Volume.GetValueOrDefault(),
                    DaySignals = daySignals
                };
            }

            // Ensure all provided symbols are included in the result
            if (symbols != null)
            {
                foreach (var symbol in symbols)
                {
                    if (!result.ContainsKey(symbol))
                    {
                        result[symbol] = new StocksHistoryItemDto
                        {
                            Data = new StocksHistoryDataItemDataDto
                            {
                                History = new Dictionary<DateTime, HistoricalDataDto>()
                            }
                        };
                    }
                }
            }

            return result;
        }

        private static List<TechnicalIndicatorsSignalsEnum.EIdentifier> GetDaySignalsFromGroupedIndicators(
    string symbol,
    DateTime tradeDate,
    Dictionary<IndicatorKey, List<GetTradesWithIndicators_Result>> groupedIndicators)
        {
            // Define the key type with Symbol and TradeDate
            var key = new IndicatorKey { Symbol = symbol, TradeDate = tradeDate };

            if (groupedIndicators.TryGetValue(key, out var indicators))
            {
                // Extract signals from the grouped indicators
                return indicators
                    .Where(indicator => !indicator.IndicatorValue.HasValue) // Ensure the IndicatorValue is not null or empty
                    .Select(indicator =>
                    {
                        // Try to safely convert the IndicatorName to the EIdentifier enum
                        Enum.TryParse<TechnicalIndicatorsSignalsEnum.EIdentifier>(indicator.IndicatorName, out var enumValue);

                        return enumValue;

                    })
                    .ToList();
            }

            return new List<TechnicalIndicatorsSignalsEnum.EIdentifier>();
        }


        // Custom class to act as a key for Dictionary
        public class IndicatorKey
        {
            public string Symbol { get; set; }
            public DateTime TradeDate { get; set; }

            // Override Equals and GetHashCode to ensure proper key comparison
            public override bool Equals(object obj)
            {
                if (obj is IndicatorKey other)
                {
                    return Symbol.ToLower() == other.Symbol.ToLower() && TradeDate == other.TradeDate;
                }
                return false;
            }

            public override int GetHashCode()
            {
                return (Symbol?.GetHashCode() ?? 0) ^ TradeDate.GetHashCode();
            }
        }



        internal static List<StocksProfitIndicatorDto> ToProfitIndicatorsDto(List<GetProfitIndicatorsBySymbols_Result> obj)
        {
            if (obj == null || !obj.Any())
            {
                return new List<StocksProfitIndicatorDto>();
            }

            return obj.Select(result => new StocksProfitIndicatorDto
            {
                Symbol = result.Symbol,
                IndicatorName = result.IndicatorName,

                Day1_Positive = result.Day1_Positive,
                Day1_Negative = result.Day1_Negative,
                Day1_UpRatio = result.Day1_UpRatio,
                Day1_AvgProfit = result.Day1_AvgProfit,
                Day1_TotalProfit = result.Day1_TotalProfit,

                Day2_Positive = result.Day2_Positive,
                Day2_Negative = result.Day2_Negative,
                Day2_UpRatio = result.Day2_UpRatio,
                Day2_AvgProfit = result.Day2_AvgProfit,
                Day2_TotalProfit = result.Day2_TotalProfit,

                Day3_Positive = result.Day3_Positive,
                Day3_Negative = result.Day3_Negative,
                Day3_UpRatio = result.Day3_UpRatio,
                Day3_AvgProfit = result.Day3_AvgProfit,
                Day3_TotalProfit = result.Day3_TotalProfit,

                Day4_Positive = result.Day4_Positive,
                Day4_Negative = result.Day4_Negative,
                Day4_UpRatio = result.Day4_UpRatio,
                Day4_AvgProfit = result.Day4_AvgProfit,
                Day4_TotalProfit = result.Day4_TotalProfit,

                Day5_Positive = result.Day5_Positive,
                Day5_Negative = result.Day5_Negative,
                Day5_UpRatio = result.Day5_UpRatio,
                Day5_AvgProfit = result.Day5_AvgProfit,
                Day5_TotalProfit = result.Day5_TotalProfit,

                Day6_Positive = result.Day6_Positive,
                Day6_Negative = result.Day6_Negative,
                Day6_UpRatio = result.Day6_UpRatio,
                Day6_AvgProfit = result.Day6_AvgProfit,
                Day6_TotalProfit = result.Day6_TotalProfit,

                Day7_Positive = result.Day7_Positive,
                Day7_Negative = result.Day7_Negative,
                Day7_UpRatio = result.Day7_UpRatio,
                Day7_AvgProfit = result.Day7_AvgProfit,
                Day7_TotalProfit = result.Day7_TotalProfit,

                Day8_Positive = result.Day8_Positive,
                Day8_Negative = result.Day8_Negative,
                Day8_UpRatio = result.Day8_UpRatio,
                Day8_AvgProfit = result.Day8_AvgProfit,
                Day8_TotalProfit = result.Day8_TotalProfit,

                Day9_Positive = result.Day9_Positive,
                Day9_Negative = result.Day9_Negative,
                Day9_UpRatio = result.Day9_UpRatio,
                Day9_AvgProfit = result.Day9_AvgProfit,
                Day9_TotalProfit = result.Day9_TotalProfit,

                Day10_Positive = result.Day10_Positive,
                Day10_Negative = result.Day10_Negative,
                Day10_UpRatio = result.Day10_UpRatio,
                Day10_AvgProfit = result.Day10_AvgProfit,
                Day10_TotalProfit = result.Day10_TotalProfit,

                Day20_Positive = result.Day20_Positive,
                Day20_Negative = result.Day20_Negative,
                Day20_UpRatio = result.Day20_UpRatio,
                Day20_AvgProfit = result.Day20_AvgProfit,
                Day20_TotalProfit = result.Day20_TotalProfit,

                Day30_Positive = result.Day30_Positive,
                Day30_Negative = result.Day30_Negative,
                Day30_UpRatio = result.Day30_UpRatio,
                Day30_AvgProfit = result.Day30_AvgProfit,
                Day30_TotalProfit = result.Day30_TotalProfit,

                CompositeScore = result.CompositeScore
            }).ToList();
        }

        internal static List<StockTradesIndicatorDto> ToIndicatorsDto(List<GetIndicatorsBySymbolsAndDateRange_Result> obj)
        {
            if (obj == null || !obj.Any())
            {
                return new List<StockTradesIndicatorDto>();
            }

            return obj.Select(result => new StockTradesIndicatorDto
            {
                //IndicatorId = result.IndicatorId,
                Symbol = result.Symbol,
                IndicatorName = result.IndicatorName,
                //IndicatorValue =(*) result.IndicatorValue,
                TradeDate = result.TradeDate
            }).ToList();
        }

        internal static List<StockHistoryTradeDto> ToStockHistoryTradeDto(List<GetTradesBySymbolsAndDate_Result> obj)
        {
            if (obj == null || !obj.Any())
            {
                return new List<StockHistoryTradeDto>();
            }

            return obj.Select(result => new StockHistoryTradeDto
            {
                Symbol = result.Symbol,
                TradeId = result.Id,
                TradeDate = result.TradeDate,
                Open = result.OpenPrice,
                Close = result.ClosePrice,
                AdjustedClose = result.AdjustedClose,
                High = result.HighPrice,
                Low = result.LowPrice,
                Volume = result.Volume.GetValueOrDefault()
            }).ToList();
        }



        internal static List<DailyStockQuotesDto> ToDto(List<StockTrade> obj)
        {
            if (obj == null || !obj.Any())
            {
                return new List<DailyStockQuotesDto>();
            }

            return obj.Select(result => new DailyStockQuotesDto(result.Symbol)
            {
                TradeId = result.Id,
                Symbol = result.Symbol,
                TradeDate = result.TradeDate,
                Open = result.OpenPrice,
                Close = result.ClosePrice,
                AdjustedClose = result.AdjustedClose,
                High = result.HighPrice,
                Low = result.LowPrice,
                Volume = result.Volume.GetValueOrDefault(0),
                ProfitDay1 = result.ProfitDay1,
                ProfitDay2 = result.ProfitDay2,
                ProfitDay3 = result.ProfitDay3,
                ProfitDay4 = result.ProfitDay4,
                ProfitDay5 = result.ProfitDay5,
                ProfitDay6 = result.ProfitDay6,
                ProfitDay7 = result.ProfitDay7,
                ProfitDay8 = result.ProfitDay8,
                ProfitDay9 = result.ProfitDay9,
                ProfitDay10 = result.ProfitDay10,
                ProfitDay20 = result.ProfitDay20,
                ProfitDay30 = result.ProfitDay30,
                Beta = result.Beta,
                IndicatorsJson = result.IndicatorsJson,
                PricePerformanceJson = result.PricePerformance,
                MomentumScore = result.MomentumScore,
                CurrentTradeMarketCap = result.CurrentMarketCap,
                AvgMarketCap10 = result.AvgMarketCap10,
                AvgMarketCap20 = result.AvgMarketCap20,
                AvgMarketCap50 = result.AvgMarketCap50,

                AvgVolume10 = result.AvgVolume10,
                AvgVolume20 = result.AvgVolume20,
                AvgVolume50 = result.AvgVolume50,

                RawDataStr = result.RawData
            }).ToList();
        }

        internal static List<DailyStockQuotesDto> ToDailyStockQuotesDto(List<StockTrade> data)
        {
            if (data == null || data.Count == 0)
                return new List<DailyStockQuotesDto>();

            return data.Select(x => new DailyStockQuotesDto(x.Symbol)
            {
                TradeId = x.Id,
                TradeDate = x.TradeDate,
                Open = x.OpenPrice,
                Close = x.ClosePrice,
                AdjustedClose = x.AdjustedClose,
                High = x.HighPrice,
                Low = x.LowPrice,
                Volume = x.Volume.GetValueOrDefault(),
                ProfitDay1 = x.ProfitDay1,
                ProfitDay2 = x.ProfitDay2,
                ProfitDay3 = x.ProfitDay3,
                ProfitDay4 = x.ProfitDay4,
                ProfitDay5 = x.ProfitDay5,
                ProfitDay6 = x.ProfitDay6,
                ProfitDay7 = x.ProfitDay7,
                ProfitDay8 = x.ProfitDay8,
                ProfitDay9 = x.ProfitDay9,
                ProfitDay10 = x.ProfitDay10,
                ProfitDay20 = x.ProfitDay20,
                ProfitDay30 = x.ProfitDay30,
                Beta = x.Beta,
                RawDataStr = x.RawData,
                IndicatorsJson = x.IndicatorsJson,
                PricePerformanceJson = x.PricePerformance,
                MomentumScore = x.MomentumScore,
                CurrentTradeMarketCap= x.CurrentMarketCap,
                AvgMarketCap10 = x.AvgMarketCap10,
                AvgMarketCap20 = x.AvgMarketCap20,
                AvgMarketCap50 = x.AvgMarketCap50,

                AvgVolume10 = x.AvgVolume10,
                AvgVolume20 = x.AvgVolume20,
                AvgVolume50 = x.AvgVolume50,

                Symbol = x.Symbol
            }).ToList();
        }

        internal static Dictionary<string, List<DailyStockQuotesDto>> ToStockTradesDictionay(List<StockTrade> queryResult)
        {
            if (queryResult == null || queryResult.Count == 0)
                return new Dictionary<string, List<DailyStockQuotesDto>>();

            var result = new Dictionary<string, List<DailyStockQuotesDto>>();

            foreach (var trade in queryResult)
            {
                if (!result.ContainsKey(trade.Symbol))
                {
                    result[trade.Symbol] = new List<DailyStockQuotesDto>();
                }

                var dto = new DailyStockQuotesDto(trade.Symbol)
                {
                    Symbol = trade.Symbol,
                    TradeDate = trade.TradeDate,
                    Open = trade.OpenPrice,
                    High = trade.HighPrice,
                    Low = trade.LowPrice,
                    Close = trade.ClosePrice,
                    AdjustedClose = trade.AdjustedClose,
                    Volume = trade.Volume ?? 0,
                    ProfitDay1 = trade.ProfitDay1,
                    ProfitDay2 = trade.ProfitDay2,
                    ProfitDay3 = trade.ProfitDay3,
                    ProfitDay4 = trade.ProfitDay4,
                    ProfitDay5 = trade.ProfitDay5,
                    ProfitDay6 = trade.ProfitDay6,
                    ProfitDay7 = trade.ProfitDay7,
                    ProfitDay8 = trade.ProfitDay8,
                    ProfitDay9 = trade.ProfitDay9,
                    ProfitDay10 = trade.ProfitDay10,
                    ProfitDay20 = trade.ProfitDay20,
                    ProfitDay30 = trade.ProfitDay30,
                    Beta = trade.Beta,
                    RawDataStr = trade.RawData,
                    PricePerformanceJson = trade.PricePerformance,
                    MomentumScore = trade.MomentumScore,
                    CurrentTradeMarketCap = trade.CurrentMarketCap,
                    AvgMarketCap10 = trade.AvgMarketCap10,
                    AvgMarketCap20 = trade.AvgMarketCap20,
                    AvgMarketCap50 = trade.AvgMarketCap50,

                    AvgVolume10 = trade.AvgVolume10,
                    AvgVolume20 = trade.AvgVolume20,
                    AvgVolume50 = trade.AvgVolume50,


                    IndicatorsJson = trade.IndicatorsJson
                };

                result[trade.Symbol].Add(dto);
            }

            return result;
        }

    }
}
