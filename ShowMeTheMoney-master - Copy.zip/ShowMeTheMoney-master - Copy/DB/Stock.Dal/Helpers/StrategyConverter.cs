﻿using Stock.Common.Strategy;
using Stock.Dal.DBModel;

namespace Stock.Dal.Helpers
{
    public class StrategyConverter
    {
        internal static StrategyItemDto ToDto(Strategy item)
        {
            var result = StrategyItemDto.FromString(item.StrategyData);
            result.Id = item.Id;
            result.Enable = item.Enable;
            result.Default = item.Default;
            result.Name = item.Name;
            result.Created = item.Created;

            result.Description = item.Description;
            return result;
        }

        internal static Strategy FromDto(StrategyItemDto strategyItemDto)
        {
            var st = StrategyItemDto.FromString(strategyItemDto.ToStringObject());
            Strategy item = new Strategy();
            item.Id = strategyItemDto.Id;
            item.Name = strategyItemDto.Name;
            item.Description = strategyItemDto.Description;
            item.StrategyData = st.ToStringObject();
            item.Created = strategyItemDto.Created;
            item.Enable = strategyItemDto.Enable;
            item.Default = strategyItemDto.Default;
            item.Deleted = false;
            return item;
        }
    }
}