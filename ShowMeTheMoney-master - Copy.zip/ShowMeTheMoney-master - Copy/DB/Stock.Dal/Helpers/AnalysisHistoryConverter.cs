﻿using Stock.Dal.DBModel;
using static Stock.Common.Dto.AnalysisHistoryDto;

namespace Stock.Dal.Helpers
{
    public class AnalysisHistoryConverter
    {
        internal static AnalysisHistoryItemDto ToDto(History item)
        {
            var result = new AnalysisHistoryItemDto();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol.Trim();
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = (item.Rank.HasValue ? item.Rank.Value : 0);
            result.Source = item.Source;
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            result.Data = StocksHistoryItemDataDto.FromString(item.Data);

            return result;
        }

        internal static History FromDto(AnalysisHistoryItemDto item)
        {
            var result = new History();
            result.Id = item.Id;
            result.Date = item.Date;
            result.Symbol = item.Symbol;
            result.Price = item.Price;
            result.Score = item.Score;
            result.Rank = item.Rank;
            result.Source = item.Source;
            result.Data = item.Data.ToString();
            result.IsDuringTrade = item.IsDuringTrade;
            result.RawScore = item.RawScore;

            return result;
        }
    }
}