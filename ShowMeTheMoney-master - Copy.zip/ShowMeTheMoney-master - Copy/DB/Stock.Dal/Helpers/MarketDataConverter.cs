﻿using Stock.Common.Dto.MarketsData;
using Stock.Dal.DBModel;

namespace Stock.Dal.Helpers
{
    public class MarketDataConverter
    {
        internal static MarketDataItemDto ToDto(GetMarketData_Result item)
        {
            var result = new MarketDataItemDto();

            result.Id = item.Id;
            result.Symbol = item.Symbol;
            result.Date = item.Date;
            result.Price = item.Price;
            result.Volume = item.Volume;
            result.PriceChangePercentage = item.PriceChangePercentage;
            result.VolumeChangePercentage = item.VolumeChangePercentage;

            return result;
        }
    }
}