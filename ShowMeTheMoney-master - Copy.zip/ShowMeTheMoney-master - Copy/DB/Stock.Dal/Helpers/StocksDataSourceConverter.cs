﻿using Stock.Common;
using Stock.Common.Enums;
using Stock.Dal.DBModel;

namespace Stock.Dal.Helpers
{
    public class StocksDataSourceConverter
    {
        internal static StocksDataSource ToDto(StocksListSource item)
        {
            var result = new StocksDataSource(item.Name, item.Url, (SourceTypes)item.SourceType, item.Enable,
                                            item.EnableAnalysis, StocksListSourceCodeEnum.Parse(item.Code), item.Weight,
                                            item.LogChanges, item.ScoreForAppearance);

            result.Id = item.Id;
            result.InvestmentDays = item.InvestmentDays;
            result.ScoreLimit = item.ScoreLimit;
            result.PeakScore = item.PickScore;

            return result;
        }
    }
}