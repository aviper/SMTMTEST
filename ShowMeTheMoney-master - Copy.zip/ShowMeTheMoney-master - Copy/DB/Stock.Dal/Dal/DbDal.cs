﻿using log4net.Repository.Hierarchy;
using Stock.Common;
using Stock.Common.Dto;
using Stock.Common.Dto.Login;
using Stock.Common.Dto.MarketsData;
using Stock.Common.Dto.Screener;
using Stock.Common.Dto.StartParamsItems;
using Stock.Common.Dto.Trading;
using Stock.Common.Enums;
using Stock.Common.Indicators;
using Stock.Common.Indicators.Params;
using Stock.Common.Strategy;
using Stock.Common.Utils;
using Stock.Dal.Dal.Repository.Wrappers;
using Stock.Dal.DBModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Stock.Common.Dto.AnalysisHistoryDto;
using static Stock.Common.Dto.ProcessHistoryDto;
using static Stock.Common.Dto.Trading.NasdaqStocksDto;

using static Stock.Common.Enums.Enums;
using static Stock.Common.Enums.ProcessHistoryCodeEnum;
using static System.Data.Entity.Migrations.Model.UpdateDatabaseOperation;

namespace Stock.Dal.Dal
{
    public class DbDal : ISitesDb
    {
        private readonly TradingWrapper _trading;
        private readonly SettingsWrapper _settings;
        private readonly StocksWrapper _stocks;
        private readonly HistoryWrapper _history;

        private readonly ProcessWrapper _process;
        private readonly LoggingWrapper _loggingWrapper;
        private readonly ScannersWrapper _scannersWrapper;
        private readonly ScrapperWrapper _scrapperWrapper;

        public DbDal()
        {
            _settings = new SettingsWrapper(this);
            _stocks = new StocksWrapper(this);
            _history = new HistoryWrapper(this);
            _process = new ProcessWrapper(this);
            _loggingWrapper = new LoggingWrapper(this);
            _scannersWrapper = new ScannersWrapper(this);
            _scrapperWrapper = new ScrapperWrapper(this);
            _trading = new TradingWrapper(this);
        }

        public Guid AddToAnalysisHistory(AnalysisHistoryDto.AnalysisHistoryItemDto item)
        {
            return _stocks.AddToAnalysisHistoryRowData(item);
        }

        public void SetProcessHistory(EIdentifier code, string name, string info)
        {
            _process.SetProcessHistoryRowData(code, name, info);
        }

        public void SetProcessHistory(ProcessHistoryItemDto item)
        {
            _process.SetProcessHistoryRowData(item);
        }

        public void SetProcessLastRunDate(ProcessHistoryCodeEnum.EIdentifier processCode, DateTime lastRunDate)
        {
            _process.SetProcessLastRunDate(processCode, lastRunDate);
        }

        public AnalysisHistoryDto GetAnalysisHistory()
        {
            return _stocks.GetAnalysisHistoryRowData();
        }

        public ProcessHistoryDto GetProcessHistory()
        {
            return _process.GetProcessHistoryRowData();
        }

        public ProcessHistoryItemDto GetProcessHistory(EIdentifier processCode)
        {
            return _process.GetProcessHistoryRowData(processCode.ToString());
        }

        public AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime fromDate, int maxItemsCount)
        {
            return _stocks.GetAnalysisHistoryRowData(symbol, fromDate, maxItemsCount);
        }

        public AnalysisHistoryDto GetAnalysisHistory(DateTime fromDate, DateTime toDate)
        {
            return _stocks.GetAnalysisHistoryRowData(fromDate, toDate);
        }

        public AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime fromDate, int maxItemsCount, bool onlyDuringTrade)
        {
            return _stocks.GetAnalysisHistoryRowData(symbol, fromDate, maxItemsCount, onlyDuringTrade);
        }

        public AnalysisHistoryDto GetStockAnalysisHistory(string symbol, DateTime fromDate, DateTime toDate)
        {
            return _stocks.GetStockAnalysisHistory(symbol, fromDate, toDate);
        }

        public void DeleteRedundantAnalysisHistoryRecords(DateTime fromDate)
        {
            _stocks.DeleteRedundantAnalysisHistoryRecords(fromDate);
        }

        public StocksDto GetStocks()
        {
            return _stocks.GetStocksRowData();
        }

        public WatchListsDto GetWatchLists(bool onlyEnabled, bool forAnalysis)
        {
            return _stocks.GetWatchListsRowData(onlyEnabled, forAnalysis);
        }

        public StocksDto GetWatchListStocks(Guid id)
        {
            return _stocks.GetWatchListStocksRowData(id);
        }

        public StocksDto GetStockData(string symbol)
        {
            return _stocks.GetStockData(symbol);
        }

        public ConfigurationDto LoadConfig()
        {
            return _settings.LoadConfigRowData();
        }

        public void SaveStockData(ParseResultData data, StocksDataSource source)
        {
            _stocks.SaveStockDataRowData(data, source);
        }

        public void DeleteOldStockData()
        {
            _stocks.DeleteOldStockDataRowData();
        }

        public void WriteLogMessage(LogDto log)
        {
            _settings.WriteLogMessageRowData(log);
        }

        public ProcessInfoDto GetProcessInfo()
        {
            return _settings.GetProcessInfoRowData();
        }

        public List<StockProfile> GetPendingStockInfo()
        {
            return _stocks.GetPendingStockInfoData();
        }

        public void SetPendingStockInfo(List<StockProfile> pendingStockInfo)
        {
            _stocks.SetPendingStockInfoRowData(pendingStockInfo);
        }

        public List<string> GetStocksSymbols(bool onlyRelevant = true)
        {
            return _stocks.GetStocksSymbols(onlyRelevant);
        }

        public List<StockProfile> GetStocksProfiles(bool onlyRelevant = true, bool OnlyValid = false)
        {
            return _stocks.GetStocksProfiles(onlyRelevant, OnlyValid);
        }

        public void AddGoogleTrendInfo(GoogleTrendDataDto googleTrendDataDto)
        {
            _scrapperWrapper.AddGoogleTrendInfoRowData(googleTrendDataDto);
        }

        public GoogleTrendDataDto GetGoogleTrendInfo()
        {
            return _scrapperWrapper.GetGoogleTrendInfoRowData();
        }

        public StockProfile GetStockProfile(string symbol)
        {
            return _stocks.GetStockProfile(symbol);
        }

        public string GetSymbolByCompanyName(string companyName)
        {
            return _stocks.GetSymbolByCompanyName(companyName);
        }

        public void UpdateLogLevel(Enums.DbLogLevel level)
        {
            _settings.UpdateLogLevelRowData(level);
        }

        public PredefinedStocksDto GetPredefinedStocks()
        {
            return _stocks.GetPredefinedStocksRowData();
        }

        public SystemHealthDataDto GetSystemHealthData()
        {
            return _process.GetSystemHealthDataRowData();
        }

        public void UpdateStockData(StocksDto.StockDto item)
        {
            _stocks.UpdateStockDataRowData(item);
        }

        public AnalysisHistoryDto GetSimulationResults(DateTime fromDate, DateTime toDate)
        {
            return _stocks.GetSimulationResults(fromDate, toDate);
        }

        public void AddSimulationResults(List<AnalysisHistoryItemDto> items, bool forScreener)
        {
            if (forScreener)
            {
                _stocks.AddSimulationResultsForScreener(items);
            }
            else
            {
                _stocks.AddSimulationResults(items);
            }
        }

        public void ClearSimulationResults(bool forScreener)
        {
            if (forScreener)
            {
                _stocks.ClearSimulationResultsForScreener();
            }
            else
            {
                _stocks.ClearSimulationResults();
            }
        }

        public List<SectorDataDto> GetSectorsData()
        {
            return _stocks.GetSectorsData();
        }

        public void SaveSectorsData(List<SectorDataDto> sectors)
        {
            _stocks.SaveSectorsData(sectors);
        }

        public LoginResult Login(LoginParamsDto loginParams)
        {
            return _loggingWrapper.LoginRowData(loginParams);
        }

        public void RunMaintenance()
        {
            _process.RunMaintenance();
        }

        public StocksOverviewDto GetStocksOverview(string symbol, DateTime? fromDate, DateTime? toDate)
        {
            return _stocks.GetStocksOverviewData(symbol, fromDate, toDate);
        }

        public WatchListMedaDataSto GetWatchListMedaData()
        {
            return _stocks.GetWatchListMedaData();
        }

        public CurrentStocksWatchListDto GetCurrentStocksWatchList()
        {
            return _stocks.GetCurrentStocksWatchListData();
        }

        public List<LogDto> GetRecentLogs(GetRecentLogsParamsDto param)
        {
            return _settings.GetRecentLogsData(param);
        }

        public void AddFinvizScannersData(string code, FinvizScannersDataDto finvizScannersDataDto)
        {
            _scrapperWrapper.AddFinvizScannersDataRowData(code, finvizScannersDataDto);
        }

        public FinvizScannersDataDto GetFinvizScannersData(string code)
        {
            return _scrapperWrapper.GetFinvizScannersDataRowData(code);
        }

        public AnalysisHistoryItemDto GetStockHistoryData(Guid historyId)
        {
            return _stocks.GetStockHistoryDataRowData(historyId);
        }

        public List<UsersActionDto> GetUsersByAction(UserActionEnum.EIdentifier action)
        {
            return _loggingWrapper.GetUsersActionRowData(action);
        }

        public void SaveFinvizAlerts(List<FinvizScannersDataItem> itemsToSend, string name)
        {
            _scannersWrapper.SaveFinvizAlertsRowData(itemsToSend, name);
        }

        public AlertHistoryDataDto GetAlertsHistoryData(Guid alertHistoryId)
        {
            return _scannersWrapper.GetAlertHistoryDataRowData(alertHistoryId);
        }

        public void ClearProcessHistory(bool clearAllHistory, EIdentifier processCodeToClear)
        {
            _process.ClearProcessHistoryRowData(clearAllHistory, processCodeToClear);
        }

        public MarketDataDto GetMarketData(MarketDataGetParams getParams)
        {
            return _stocks.GetMarketDataRowData(getParams);
        }

        public void DoCustomJob()
        {
            _stocks.DoCustomJob();
        }

        public StocsHistoryDto GetStocsHistory(DateTime fromDate, DateTime toDate, double minScore)
        {
            return _stocks.GetStocsHistoryRowData(fromDate, toDate, minScore);
        }

        public ParamBase GetStartParams(ConfigurationCodeEnum.EIdentifier process)
        {
            return _settings.GetStartParamsRowData(process);
        }

        public void SetStartParams(ConfigurationCodeEnum.EIdentifier process, ParamBase param)
        {
            _settings.SetStartParamsRowData(process, param);
        }

        public HistoryTopStocksDto GetHistoryTopStocks(bool? duringTrade, int numberOfDays)
        {
            return _stocks.GetHistoryTopStocksRowData(duringTrade, numberOfDays);
        }

        public List<StockProfile> GetStockInfoToRefresh()
        {
            return _stocks.GetStockInfoToRefreshRowData();
        }
        public bool ResetStockInfoToRefresh()
        {
            return _stocks.ResetStockInfoToRefreshRowData();
        }
        public void RefreshStockInfo(List<StockProfile> pendingStockInfo)
        {
            _stocks.RefreshStockInfoRowData(pendingStockInfo);
        }

        public List<StockProfileWithAlertsDto> GetStockProfileWithAlertsView(bool onlyRelevant = true)
        {
            return _stocks.GetStockProfileWithAlertsViewRowData(onlyRelevant);
        }

        public void SavePremarketScannerData(PremarketScannerDataDto premarketScannerData)
        {
            _scannersWrapper.SavePremarketScannerDataRowData(premarketScannerData);
        }

        public void SavePremarketScannerMetaData(HistoryTopStocksDto currentCandidateStocksToTrade)
        {
            _scrapperWrapper.SavePremarketScannerMetaDataRowData(currentCandidateStocksToTrade);
        }

        public HistoryTopStocksDto GetPremarketScannerMetaData()
        {
            return _scrapperWrapper.GetPremarketScannerMetaDataRowData();
        }

        public void RunFixData(EIdentifier process)
        {
            _scannersWrapper.RunFixDataRowData(process);
        }

        public List<AlertHistoryDataDto> GetAlertHistoriesData(EIdentifier scanner, DateTime fromDate, DateTime toDate)
        {
            return _scannersWrapper.GetAlertHistoriesDataRowData(scanner, fromDate, toDate);
        }

        public StocksHistoryToRefreshDto GetStocksHistoryToRefresh(DateTime lastTradingDate, int maxItems)
        {
            return _scannersWrapper.GetStocksHistoryToRefreshRowData(lastTradingDate, maxItems);
        }

        public List<StocksHistorySymbolsDto> GetStocksHistorySymbols()
        {
            return _scannersWrapper.GetStocksHistorySymbolsRowData();
        }

        public void UpdateStocksHistoryData(List<StocksHistoryItemDto> stocksHistories)
        {
            _scannersWrapper.UpdateStocksHistoryDataRowData(stocksHistories);
        }

        public void RunDatabaseMaintenance(bool forceShrink = false)
        {
            _settings.RunDatabaseMaintenance(forceShrink);
        }

        public async Task<Dictionary<string, StocksHistoryItemDto>> GetStocksHistoryAsync(List<string> symbols)
        {
            return await _scannersWrapper.GetStocksHistoryRowDataAsync(symbols);
        }

        public List<string> GetInvalidStocksFromHistory()
        {
            return _scannersWrapper.GetInvalidStocksFromHistory();
        }
        public List<(string Symbol, DateTime? LastSync)> GetOutdatedStocks(DateTime lastDate)
        {
            return _scannersWrapper.GetOutdatedStocksRowData(lastDate);
        }
        public List<GetDbSize_Result> GetDbSize()
        {
            return _settings.GetDbSizeRowData();
        }

        public void UpdateConfiguration(ConfigurationCodeEnum.EIdentifier configCode, string data)
        {
            _settings.UpdateConfiguration(configCode, data);
        }

        public string GetConfigurationData(ConfigurationCodeEnum.EIdentifier configCode)
        {
            return _settings.GetConfigurationData(configCode);
        }

        public AnalysisHistoryDto SimulationResultsData(DateTime fromDate, DateTime toDate)
        {
            return _stocks.GetSimulationResultsDataRowData(fromDate, toDate);
        }

        public void UpdateSimulationResultsRanks(int[] ranksMinValues)
        {
            _stocks.UpdateSimulationResultsRanks(ranksMinValues);
        }

        public bool AddStrategies(List<StrategyItemDto> strategyCollection)
        {
            return _trading.AddStrategiesRawData(strategyCollection);
        }

        public List<StrategyItemDto> GetCurrentStrategy()
        {
            return _trading.GetCurrentStrategyRawData();
        }

        public bool SaveBuyStockData(SaveStockDto data, bool simulation)
        {
            return _trading.SaveBuyStockDataRawData(data, simulation);
        }

        public List<InvestmentDto> GetHoldings(bool simulation)
        {
            return _trading.GetHoldingsRawData(simulation);
        }

        public List<StrategyItemDto> GetAllStrategy()
        {
            return _trading.GetAllStrategyRawData();
        }

        public void SaveStrategies(List<StrategyItemDto> strategyCollection)
        {
            _trading.SaveStrategies(strategyCollection);
        }

        public void UpdateHoldings(List<InvestmentDto> holdings)
        {
            _trading.UpdateHoldings(holdings);
        }

        public void SaveMomentumStocksData(MomentumStocksData momentumStocks, bool deleteFlag)
        {
            _scannersWrapper.SaveMomentumStocksDataRowData(momentumStocks, deleteFlag);
        }

        public MomentumStocksData GetMomentumStocksData()
        {
            return _scannersWrapper.GetMomentumStocksDataRowData();
        }

        public List<IndicatorsTraderDto> GetAllIndicatorsTraderAlerts()
        {
            return _trading.GetAllIndicatorsTraderAlertsRawData();
        }

        public List<MarketHistoryDataDto> GetMarketHistoryData(int days_back, int min_score)
        {
            return _trading.GetMarketHistoryDataRowData(days_back, min_score);
        }

        public void SetStocksHistory(List<StocksHistoryItemDto> data)
        {
            _scannersWrapper.SetStocksHistoryRowData(data);
        }

        public void InitNasdaqStocksData(NasdaqStocksDto nasdaqStocksData, bool delete)
        {
            _stocks.InitNasdaqStocksDataRowData(nasdaqStocksData, delete);
        }

        public List<NasdaqStockData> GetNasdaqStocksData(ExchangeEnum exchange, List<SectorEnum> sectors, int minMarketCap)
        {
            return _stocks.GetNasdaqStocksDataRowData(exchange, sectors, minMarketCap);
        }

        public async Task SaveStrategiesStocksHistoryDataAsync(StrategyScanModeEnum.EIdentifier code, string message, StrategiesStocksHistoryDataDto data, double? totalScore)
        {
            await _stocks.SaveStrategiesStocksHistoryDataRowDataAsync(code, message, data, totalScore);
        }

        public async Task<StrategiesStocksHistoryDataDto> GetStrategiesStocksHistoryDataAsync(List<string> symbols, DateTime date)
        {
            return await _stocks.GetStrategiesStocksHistoryDataRowDataAsync(symbols, date);
        }

        public void CleanTodayStrategiesStocksHistoryData()
        {
            _stocks.CleanTodayStrategiesStocksHistoryData();
        }

        public async Task<List<StrategiesStocksModelDto>> LoadStrategyModelDataAsync(List<string> symbols)
        {
            return await _stocks.LoadStrategyModelDataRowDataAsync(symbols);
        }

        public async Task<List<string>> LoadStrategyModelNamesAsync(List<string> symbols)
        {
            return await _stocks.LoadStrategyModelNamesDataRowAsync(symbols);
        }

        public async Task<StrategiesStocksModelDto> SaveStrategyModelDataAsync(StrategiesStocksModelDto data)
        {
            return await _stocks.SaveStrategyModelDataRowDataAsync(data);
        }

        public bool GetIndicatorsTraderHoldingData(string symbol, StrategyItemNewDto strategy)
        {
            return _trading.GetIndicatorsTraderHoldingDataRawData(symbol, strategy);
        }

        public async Task IndicatorsTraderCommitBuyAsync(IndicatorsTraderDto data)
        {
            await _trading.IndicatorsTraderCommitBuyRawDataAsync(data);
        }

        public void DeleteAllStrategiesHistoryData()
        {
            _stocks.DeleteAllStrategiesHistoryDataRowData();
        }

        public Dictionary<string, StocksHistoryItemDto> GetStocksHistory(List<string> symbols)
        {
            return _scannersWrapper.GetStocksHistoryRowData(symbols);
        }

        public void FixStockHistoryData()
        {
            _scannersWrapper.FixStockHistoryDataRowData();
        }


        public async Task<StocksHealthReport> GetStocksHealthReportAsync(DateTime lastTradeDate)
        {
            return await _stocks.GetStocksHealthReportRowDataAsync(lastTradeDate);
        }

        public async Task CollectStockTradeDataAsync(string symbol, List<KeyValuePair<DateTime, HistoricalDataDto>> history, bool onlyStrategy, bool partialUpdate, DateTime? startDate)
        {
            await _history.CollectStockTradeDataRowDataAsync(symbol, history, onlyStrategy, partialUpdate, startDate);
        }

        public void ResetStockSimulatorData()
        {
            _history.ResetStockSimulatorDataRowData();
        }

        public List<string> GetStockIndicatorDataToRefresh(DateTime lastTradingDate)
        {
            return _history.GetStockIndicatorDataToRefreshRowData(lastTradingDate);
        }

        public List<StockTradesIndicatorDto> GetIndicatorsBySymbolsAndDateRange(string symbols, DateTime from, DateTime to)
        {
            return _history.GetIndicatorsBySymbolsAndDateRangeRowData(symbols, from, to);
        }

        public List<StocksProfitIndicatorDto> GetProfitIndicatorsBySymbols(string symbols, decimal minRatio, int minPositiveResults, string indicatorPrefix, List<string> days, decimal minDayPercentsValue, string prefix)
        {
            return _history.GetProfitIndicatorsBySymbolsRowData(symbols, minRatio, minPositiveResults, indicatorPrefix, days, minDayPercentsValue, prefix);
        }

        public List<StockHistoryTradeDto> GetTradesBySymbolsAndDate(string symbols, DateTime endDate, int numOfWeeks)
        {
            return _history.GetTradesBySymbolsAndDateRowData(symbols, endDate, numOfWeeks);
        }

        public Dictionary<string, StocksHistoryItemDto> GetStocksHistoryNew(List<string> symbols, DateTime endDate, int NumOfRows)
        {
            return _history.GetStocksHistoryNewRowData(symbols, endDate, NumOfRows);
        }

        public void PopulateStockTradeSummaryTable(DateTime minDate)
        {
            _history.PopulateStockTradeSummaryTableRowData(minDate);
        }
        public void PopulateStockTradeSummaryBySymbolGroupTable(DateTime minDate)
        {
            _history.PopulateStockTradeSummaryBySymbolGroupTableRowData(minDate);
        }
        public List<CurrentStockTradesDatesDto> GetCurrentStockTradesDates(List<string> symbols)
        {
            return _history.GetCurrentStockTradesDatesRowData(symbols);
        }

        public DailyStocksQuotesDto GetDailyStocksQuotes(List<string> symbols, bool includeEmptyIndicators = true)
        {
            return _history.GetDailyStocksQuotesRowData(symbols, includeEmptyIndicators);
        }

        public List<DailyStockQuotesDto> GetDailyStockQuotes(string stock, DateTime? from, DateTime? to, bool includeEmptyIndicators = true)
        {
            if (string.IsNullOrWhiteSpace(stock))
            {
                return new List<DailyStockQuotesDto>();
            }

            try
            {
                var result = _history.GetDailyStocksQuotesRowData(new List<string> { stock }, from, to, includeEmptyIndicators);

                if (result?.DailyStockQuotes == null)
                {
                    return new List<DailyStockQuotesDto>();
                }

                if (!result.DailyStockQuotes.TryGetValue(stock, out var quotes) || quotes == null)
                {
                    return new List<DailyStockQuotesDto>();
                }

                return quotes;
            }
            catch (Exception ex)
            {
                return new List<DailyStockQuotesDto>();
            }
        }

        public DailyStocksQuotesDto GetDailyStocksQuotes(List<string> stocks, DateTime? from, DateTime? to, bool includeEmptyIndicators = true)
        {
            return _history.GetDailyStocksQuotesRowData(stocks, from, to, includeEmptyIndicators);
        }

        public List<StaticStockDataSto> GetCachedStockProfilesData()
        {
            return _stocks.GetStaticDataRowData();
        }





        private List<DailyStockQuotesDto> GetDailyStockQuotesWithCache(string symbol, DateTime from, DateTime to, bool includeEmptyIndicators = true)
        {
            if (string.IsNullOrWhiteSpace(symbol))
            {
                return new List<DailyStockQuotesDto>();
            }

            try
            {
                if (_dailyStocksQuotesCacheRange.ContainsKey(symbol)
                    && (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.AllData || (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.TimePeriod && _dailyStocksQuotesCacheRange[symbol].Item2.Value.Date <= from.Date && _dailyStocksQuotesCacheRange[symbol].Item3.Value.Date >= to.Date)))
                {
                    return _dailyStocksQuotesCache[symbol].Where(x => x.Key >= from.Date && x.Key <= to.Date).Select(x => x.Value).ToList();
                }
                else
                {
                    var data = _history.GetDailyStocksQuotesRowData(new List<string> { symbol }, from, to, includeEmptyIndicators);

                    if (data?.DailyStockQuotes == null)
                    {
                        return new List<DailyStockQuotesDto>();
                    }

                    if (!data.DailyStockQuotes.TryGetValue(symbol, out var quotes) || quotes == null)
                    {
                        return new List<DailyStockQuotesDto>();
                    }

                    _dailyStocksQuotesCache[symbol] = quotes.ToDictionary(x => x.TradeDate.Date, x => x);
                    _dailyStocksQuotesCacheRange[symbol] = new Tuple<eCacheRangeType, DateTime?, DateTime?>(eCacheRangeType.TimePeriod, from, to);

                    return quotes;
                }
            }
            catch (Exception ex)
            {
                return new List<DailyStockQuotesDto>();
            }
        }

        public Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> GetDailyStocksQuotesAsDictionary(List<string> symbols, bool includeEmptyIndicators = true)
        {
            var result = new Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>>();

            List<string> symbolsForLoading = new List<string>();
            foreach (var symbol in symbols)
            {
                if (_dailyStocksQuotesCacheRange.ContainsKey(symbol) && _dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.AllData)
                {
                    result.Add(symbol, _dailyStocksQuotesCache[symbol]);
                }
                else
                {
                    symbolsForLoading.Add(symbol);
                }
            }

            if (symbolsForLoading.Count > 0)
            {
                var data = _history.GetDailyStocksQuotesRowData(symbolsForLoading, includeEmptyIndicators);
                if (data != null && data.DailyStockQuotes != null)
                {
                    foreach (var item in data.DailyStockQuotes)
                    {
                        var stockData = item.Value.ToDictionary(x => x.TradeDate.Date, x => x);
                        result.Add(item.Key, stockData);

                        _dailyStocksQuotesCache[item.Key] = stockData;
                        _dailyStocksQuotesCacheRange[item.Key] = new Tuple<eCacheRangeType, DateTime?, DateTime?>(eCacheRangeType.AllData, null, null);
                    }
                }
            }

            return result;
        }

        public Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> GetDailyStocksQuotesAsDictionary(List<string> symbols, DateTime from, DateTime to, bool includeEmptyIndicators = true)
        {
            var result = new Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>>();

            List<string> symbolsForLoading = new List<string>();
            foreach (var symbol in symbols)
            {
                if (_dailyStocksQuotesCacheRange.ContainsKey(symbol)
                    && (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.AllData || (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.TimePeriod && _dailyStocksQuotesCacheRange[symbol].Item2.Value.Date <= from.Date && _dailyStocksQuotesCacheRange[symbol].Item3.Value.Date >= to.Date)))
                {
                    result.Add(symbol, _dailyStocksQuotesCache[symbol].Where(x => x.Key >= from.Date && x.Key <= to.Date).ToDictionary(x => x.Key, x => x.Value));
                }
                else
                {
                    symbolsForLoading.Add(symbol);
                }
            }

            if (symbolsForLoading.Count > 0)
            {
                var data = _history.GetDailyStocksQuotesRowData(symbolsForLoading, from, to, includeEmptyIndicators);
                if (data != null && data.DailyStockQuotes != null)
                {
                    foreach (var item in data.DailyStockQuotes)
                    {
                        var stockData = item.Value.ToDictionary(x => x.TradeDate.Date, x => x);
                        result.Add(item.Key, stockData);

                        _dailyStocksQuotesCache[item.Key] = stockData;
                        _dailyStocksQuotesCacheRange[item.Key] = new Tuple<eCacheRangeType, DateTime?, DateTime?>(eCacheRangeType.TimePeriod, from, to);
                    }
                }
            }

            return result;
        }

        public Dictionary<DateTime, DailyStockQuotesDto> GetDailyStockQuotesAsDictionary(string symbol, DateTime from, DateTime to, bool includeEmptyIndicators = true)
        {

            if (_dailyStocksQuotesCacheRange.ContainsKey(symbol)
                    && (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.AllData || (_dailyStocksQuotesCacheRange[symbol].Item1 == eCacheRangeType.TimePeriod && _dailyStocksQuotesCacheRange[symbol].Item2.Value.Date <= from.Date && _dailyStocksQuotesCacheRange[symbol].Item3.Value.Date >= to.Date)))
            {
                return _dailyStocksQuotesCache[symbol].Where(x => x.Key >= from.Date && x.Key <= to.Date).ToDictionary(x => x.Key, x => x.Value);
            }
            else
            {
                var result = new Dictionary<DateTime, DailyStockQuotesDto>();
                var data = GetDailyStockQuotesWithCache(symbol, from, to, includeEmptyIndicators);
                if (data != null && data.Count > 0)
                {
                    result = data.ToDictionary(x => x.TradeDate.Date, x => x);

                    _dailyStocksQuotesCache[symbol] = result;
                    _dailyStocksQuotesCacheRange[symbol] = new Tuple<eCacheRangeType, DateTime?, DateTime?>(eCacheRangeType.TimePeriod, from, to);
                }
                return result;
            }
        }

        public double? GetStockDailyClosePrice(string symbol, DateTime date)
        {
            //if (symbol == "^VIX") return 1;

            var quotes = GetDailyStockQuotesWithCache(symbol, date, date);
            if (quotes == null || quotes.Count == 0)
            {
                return null;
            }
            var quote = quotes.FirstOrDefault(q => q.TradeDate.Date == date.Date);
            if (quote == null)
            {
                return null;
            }
            return (double)quote.AdjustedClose;
        }

        public double GetStockVolumeAverageForPeriod(string symbol, DateTime from, DateTime to)
        {
            try
            {
                double result = -1;

                var data = GetDailyStockQuotesWithCache(symbol, from, to.AddDays(-1).Date);

                if (data != null && data.Where(x => x.Volume > 0).Count() > 0)
                {
                    result = data.Where(x => x.Volume > 0).Average(x => x.Volume);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public double GetStockStandardDeviationForPeriod(string symbol, DateTime from, DateTime to, decimal currentDateClosePrice = -1)
        {
            var dailyReturns = new List<double>();
            var closePrices = GetDailyStockQuotesWithCache(symbol, from, to.AddDays(-1).Date).Where(x => x.AdjustedClose > 0).OrderBy(x => x.TradeDate).Select(x => x.AdjustedClose).ToList();

            if (currentDateClosePrice > 0)
            {
                closePrices.Add(currentDateClosePrice);
            }

            if (closePrices.Count > 1)
            {
                for (int i = 1; i < closePrices.Count; i++)
                {
                    dailyReturns.Add(Convert.ToDouble(((closePrices[i] / closePrices[i - 1]) - 1) * 100));
                }
                return MathUtils.GetStandardDeviation(dailyReturns);
            }
            else
            {
                return -1;
            }
        }

        public double GetStockPriceChangeForPeriod(string symbol, DateTime fromDate, DateTime toDate)
        {
            double priceChange = 0;

            var price1 = GetStockDailyClosePrice(symbol, fromDate.Date);
            var price2 = GetStockDailyClosePrice(symbol, toDate.Date);

            if (price1 != null && price1 > 0 && price2 != null && price2 > 0)
            {
                priceChange = (price2.Value - price1.Value) * 100 / price1.Value;
            }

            return priceChange;
        }

        public double GetStockPriceMovementForPeriod(string symbol, DateTime fromDate, DateTime toDate, double additionalHigh = double.NaN, double additionalLow = double.NaN)
        {
            double priceMovement = 0;

            DateTime date = fromDate.Date;

            decimal highestPrice = Convert.ToDecimal(double.IsNaN(additionalHigh) ? -1 : additionalHigh);
            decimal lowestPrice = Convert.ToDecimal(double.IsNaN(additionalLow) ? -1 : additionalLow);

            var stockData = GetDailyStockQuotesAsDictionary(symbol, date.Date, toDate.Date);

            while (date.Date <= toDate.Date)
            {
                if (stockData.ContainsKey(date.Date))
                {

                    var dailyData = stockData[date.Date];
                    if (dailyData != null)
                    {
                        if (dailyData.High > 0 && dailyData.High > highestPrice)
                        {
                            highestPrice = dailyData.High;
                        }
                        if (dailyData.Low > 0 && (dailyData.Low < lowestPrice || lowestPrice == -1))
                        {
                            lowestPrice = dailyData.Low;
                        }
                    }
                }

                date = date.AddDays(1);
            }

            if (highestPrice > 0 && lowestPrice > 0)
            {
                priceMovement = (double)((highestPrice - lowestPrice) * 100 / lowestPrice);
            }

            return priceMovement;
        }

        public void LoadStocksDailyQuotesToCache(List<string> symbols, DateTime from, DateTime to, bool includeEmptyIndicators = true)
        {
            var data = _history.GetDailyStocksQuotesRowData(symbols, from, to, includeEmptyIndicators);
            if (data != null && data.DailyStockQuotes != null)
            {
                foreach (var item in data.DailyStockQuotes)
                {
                    var stockData = item.Value.ToDictionary(x => x.TradeDate.Date, x => x);
                    _dailyStocksQuotesCache[item.Key] = stockData;
                    _dailyStocksQuotesCacheRange[item.Key] = new Tuple<eCacheRangeType, DateTime?, DateTime?>(eCacheRangeType.TimePeriod, from, to);
                }
            }
        }

        public void ClearStocksDailyQuotesCache(List<string> symbolsToExclude = null)
        {
            bool exclude = symbolsToExclude != null && symbolsToExclude.Count > 0;

            Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> cacheToExclude = null;
            Dictionary<string, Tuple<eCacheRangeType, DateTime?, DateTime?>> cacheRangesToExclude = null;

            if (exclude)
            {
                cacheToExclude = _dailyStocksQuotesCache.Where(x => symbolsToExclude.Contains(x.Key)).ToDictionary(x => x.Key, x => x.Value);
                cacheRangesToExclude = _dailyStocksQuotesCacheRange.Where(x => symbolsToExclude.Contains(x.Key)).ToDictionary(x => x.Key, x => x.Value);
            }

            _dailyStocksQuotesCache.Clear();
            _dailyStocksQuotesCacheRange.Clear();

            if (exclude)
            {
                foreach (var symbol in cacheToExclude.Keys)
                {
                    _dailyStocksQuotesCache.Add(symbol, cacheToExclude[symbol]);
                    _dailyStocksQuotesCacheRange.Add(symbol, cacheRangesToExclude[symbol]);
                }
            }
        }


        #region "Cache"

        private Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> _dailyStocksQuotesCache = new Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>>();
        private Dictionary<string, Tuple<eCacheRangeType, DateTime?, DateTime?>> _dailyStocksQuotesCacheRange = new Dictionary<string, Tuple<eCacheRangeType, DateTime?, DateTime?>>();


        private enum eCacheRangeType
        {
            AllData,
            TimePeriod
        }

        #endregion



        public async Task SetIntraDayQuotesAsync(Dictionary<string, IntraDayQuotesSetDto> data)
        {
            await _stocks.SetIntraDayQuotesRowDataAsync(data);

        }

        public IntraDayQuotesCollectionDto GetIntraDayQuotes(MarketStateEnum.EIdentifier marketState, DateTime date)
        {
            return _stocks.GetIntraDayQuotesRowData(marketState, date);

        }

        public IntraDayQuotesSettingsContainer GetIntraDayQuotesSettings()
        {
            return _stocks.GetIntraDayQuotesSettingsRowData();
        }
        public void SetIntraDayQuotesSettings(IntraDayQuotesSettingsContainer newData)
        {
            _stocks.SetIntraDayQuotesSettingsRowData(newData);
        }

        public Dictionary<string, List<DailyStockQuotesDto>> GetStockTrades(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate)
        {
            return _history.GetStockTradesRowData(symbols, distinctIndicators, fromDate, toDate);
        }

        public int PopulateStockTradesTradingSimulations(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate)
        {
            return _history.PopulateStockTradesTradingSimulationsRowData(symbols, distinctIndicators, fromDate, toDate);

        }

        public void ReloadStockProfileData()
        {
            _stocks.ReloadStockProfileDataRowData();
        }

        public void SaveStockTradesMomentumSummaryDataDtoToDB(StockTradesMomentumSummaryDataDto dataToSaveToDB)
        {
            _stocks.SaveStockTradesMomentumSummaryDataDtoToDBRawData(dataToSaveToDB);
        }

        public void ResetStockTradesMomentumSummary()
        {
            _stocks.ResetStockTradesMomentumSummaryRowData();
        }
    }
}