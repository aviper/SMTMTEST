﻿using Stocks.Common.Log;
using Stock.Common.Dto;
using Stock.Common.Logger;
using Stock.Common.Settings;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal partial class HistoryWrapper : BaseWrapper
    {
        private class HistoryStats
        {
            protected static readonly IStocksLogger Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.Collector);

            public static int CollectCalls;
            public static int AddAllHistoryCalls;
            public static int BulkInsertCalls;

            public static long TotalRowsAdded;
            public static long TotalRowsInserted;

            public static TimeSpan TotalCollectTime = TimeSpan.Zero;
            public static TimeSpan TotalAddAllHistoryTime = TimeSpan.Zero;
            public static TimeSpan TotalBulkInsertTime = TimeSpan.Zero;

            public static void Print()
            {
                Logger.Info($"Stats Summary:");
                Logger.Info(
                    $"CollectStockTradeDataRowData calls: {CollectCalls}, " +
                    $"Total Time: {TotalCollectTime.TotalSeconds:F2}s, " +
                    $"Avg: {(CollectCalls > 0 ? TotalCollectTime.TotalSeconds / CollectCalls : 0):F2}s");

                Logger.Info(
                    $"AddAllHistoryDataParallel calls: {AddAllHistoryCalls}, " +
                    $"Rows Added: {TotalRowsAdded}, " +
                    $"Total Time: {TotalAddAllHistoryTime.TotalSeconds:F2}s, " +
                    $"Avg: {(AddAllHistoryCalls > 0 ? TotalAddAllHistoryTime.TotalSeconds / AddAllHistoryCalls : 0):F2}s");

                Logger.Info(
                    $"BulkInsertData calls: {BulkInsertCalls}, " +
                    $"Rows Inserted: {TotalRowsInserted}, " +
                    $"Total Time: {TotalBulkInsertTime.TotalSeconds:F2}s, " +
                    $"Avg: {(BulkInsertCalls > 0 ? TotalBulkInsertTime.TotalSeconds / BulkInsertCalls : 0):F2}s");
            }
        }

        /// <summary>
        /// High-performance in-memory representation of a row before converting to DataTable.
        /// </summary>
        private sealed class StockRow
        {
            public string Symbol;
            public DateTime TradeDate;
            public decimal OpenPrice;
            public decimal ClosePrice;
            public decimal AdjustedClose;
            public decimal HighPrice;
            public decimal LowPrice;
            public long Volume;
            public string IndicatorsJson;
            public decimal? Beta;
            public string RawData;
            public string PricePerformance;
            public decimal? MomentumScore;
            public long? CurrentMarketCap;
            public long? AvgMarketCap10;
            public long? AvgMarketCap20;
            public long? AvgMarketCap50;

            public long? AvgVolume10;
            public long? AvgVolume20;
            public long? AvgVolume50;

            // Index: 0..29 -> days 1..30
            public decimal[] ProfitDays = new decimal[30];
        }

        private DataTable CreateStockDataTable()
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add("Symbol", typeof(string));
            dataTable.Columns.Add("TradeDate", typeof(DateTime));
            dataTable.Columns.Add("OpenPrice", typeof(decimal));
            dataTable.Columns.Add("ClosePrice", typeof(decimal));
            dataTable.Columns.Add("AdjustedClose", typeof(decimal));

            dataTable.Columns.Add("HighPrice", typeof(decimal));
            dataTable.Columns.Add("LowPrice", typeof(decimal));
            dataTable.Columns.Add("Volume", typeof(long));
            dataTable.Columns.Add("IndicatorsJson", typeof(string));

            for (int i = 1; i <= 10; i++)
            {
                dataTable.Columns.Add("ProfitDay" + i, typeof(decimal));
            }

            dataTable.Columns.Add("ProfitDay20", typeof(decimal));
            dataTable.Columns.Add("ProfitDay30", typeof(decimal));
            dataTable.Columns.Add("Beta", typeof(decimal));
            dataTable.Columns.Add("RawData", typeof(string));
            dataTable.Columns.Add("PricePerformance", typeof(string));
            dataTable.Columns.Add("MomentumScore", typeof(decimal));
            dataTable.Columns.Add("CurrentMarketCap", typeof(long));
            dataTable.Columns.Add("AvgMarketCap10", typeof(long));
            dataTable.Columns.Add("AvgMarketCap20", typeof(long));
            dataTable.Columns.Add("AvgMarketCap50", typeof(long));


            dataTable.Columns.Add("AvgVolume10", typeof(long));
            dataTable.Columns.Add("AvgVolume20", typeof(long));
            dataTable.Columns.Add("AvgVolume50", typeof(long));


            return dataTable;
        }

        internal async Task CollectStockTradeDataRowDataAsync(
            string symbol,
            List<KeyValuePair<DateTime, HistoricalDataDto>> history,
            bool onlyStrategy,
            bool partialUpdate,
            DateTime? startDate)
        {
            if (string.IsNullOrEmpty(symbol))
                throw new ArgumentNullException(nameof(symbol));

            if (history == null || !history.Any())
                return;

            var sw = Stopwatch.StartNew();
            HistoryStats.CollectCalls++;

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var stockSymbol = symbol;

                    if (!partialUpdate)
                    {
                        context.DeleteAllBySymbol(stockSymbol, null);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                    }
                    else
                    {
                        var earlyDate = startDate;
                        context.DeleteAllBySymbol(stockSymbol, earlyDate);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                    }

                    Logger.Info($"AddAllHistoryData {symbol}");

                    var mergedDataTable = AddAllHistoryDataParallel(symbol, history, onlyStrategy, startDate);

                    Logger.Info($"BulkInsertData {symbol} {mergedDataTable.Rows.Count} Items");

                    await BulkInsertDataAsync(BulkUpdateConnectionString, mergedDataTable).ConfigureAwait(false);

                    Logger.Info("BulkInsertData Done");
                    PrintStatistics();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error processing symbol '{symbol}'", ex);
                throw;
            }
            finally
            {
                sw.Stop();
                HistoryStats.TotalCollectTime += sw.Elapsed;
            }
        }

        /// <summary>
        /// High-performance version of AddAllHistoryDataParallel:
        /// - Pre-filters and materializes history once.
        /// - Uses strongly-typed StockRow + ConcurrentBag instead of DataTable in parallel region.
        /// - Converts to DataTable only once at the end.
        /// </summary>
        private DataTable AddAllHistoryDataParallel(
            string symbol,
            List<KeyValuePair<DateTime, HistoricalDataDto>> history,
            bool onlyStrategy,
            DateTime? startDate)
        {
            var sw = Stopwatch.StartNew();
            HistoryStats.AddAllHistoryCalls++;

            // Pre-filter, sort, and materialize once
            var minDate = StockCommon.Instance.MinDateToSaveHistoryTradeData;

            var orderedHistory = history
                .Where(x => x.Key >= minDate)
                .OrderBy(x => x.Key)
                .ToArray();

            var count = orderedHistory.Length;
            if (count == 0)
            {
                sw.Stop();
                HistoryStats.TotalAddAllHistoryTime += sw.Elapsed;
                return CreateStockDataTable();
            }

            var filter = onlyStrategy ? "Strategy" : string.Empty;
            var bag = new ConcurrentBag<StockRow>();

            Parallel.For(0, count, i =>
            {
                var kvp = orderedHistory[i];
                var date = kvp.Key;
                var dto = kvp.Value;

                if (dto == null)
                    return;

                if (startDate.HasValue && date < startDate.Value)
                    return;

                try
                {
                    var daySignalsJson =
                        Stock.Common.Enums.TechnicalIndicatorsSignalsEnum.ConvertDaySignalsToJson(dto.DaySignals, filter);

                    var beta = dto.GetBeta()?.Beta;
                    var rawDataJson = dto.RawData?.ToJson();
                    var pricePerformanceJson = dto.RawData?.MomentumData?.PricePerformance?.ToJson();
                    var momentumScore = dto.RawData?.MomentumData?.MomentumScore;

                    var row = new StockRow
                    {
                        Symbol = dto.Symbol,
                        TradeDate = date,
                        OpenPrice = dto.Open,
                        ClosePrice = dto.Close,
                        AdjustedClose = dto.AdjustedClose,
                        HighPrice = dto.High,
                        LowPrice = dto.Low,
                        Volume = dto.Volume,
                        IndicatorsJson = daySignalsJson,
                        Beta = (decimal?)beta,
                        RawData = rawDataJson,
                        PricePerformance = pricePerformanceJson,
                        MomentumScore = momentumScore,
                        CurrentMarketCap = dto.CurrentMarketCap,
                        AvgMarketCap10 = dto.AvgMarketCap10,
                        AvgMarketCap20 = dto.AvgMarketCap20,
                        AvgMarketCap50 = dto.AvgMarketCap50,

                        AvgVolume10 = dto.AvgVolume10,
                        AvgVolume20 = dto.AvgVolume20,
                        AvgVolume50 = dto.AvgVolume50
                    };

                    // Profit calculation: look ahead up to 30 days or end of array
                    int profitLimit = Math.Min(30, count - i - 1);
                    if (profitLimit > 0)
                    {
                        var currentAdjClose = dto.AdjustedClose;
                        for (int j = 1; j <= profitLimit; j++)
                        {
                            var futureAdjClose = orderedHistory[i + j].Value.AdjustedClose;
                            var profit = (futureAdjClose - currentAdjClose) / currentAdjClose * 100m;
                            row.ProfitDays[j - 1] = profit;
                        }
                    }

                    bag.Add(row);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error processing record {date:dd/MM/yyyy}", ex);
                }
            });

            // Convert the in-memory rows to a DataTable once
            var masterTable = ConvertToDataTable(bag);

            sw.Stop();
            HistoryStats.TotalAddAllHistoryTime += sw.Elapsed;
            HistoryStats.TotalRowsAdded += masterTable.Rows.Count;

            return masterTable;
        }

        /// <summary>
        /// Converts a collection of StockRow objects into a DataTable matching the DB schema.
        /// </summary>
        private DataTable ConvertToDataTable(IEnumerable<StockRow> rows)
        {
            var dt = CreateStockDataTable();

            foreach (var r in rows)
            {
                var row = dt.NewRow();

                row["Symbol"] = r.Symbol;
                row["TradeDate"] = r.TradeDate;
                row["OpenPrice"] = r.OpenPrice;
                row["ClosePrice"] = r.ClosePrice;
                row["AdjustedClose"] = r.AdjustedClose;
                row["HighPrice"] = r.HighPrice;
                row["LowPrice"] = r.LowPrice;
                row["Volume"] = r.Volume;
                row["IndicatorsJson"] = r.IndicatorsJson;
                row["Beta"] = r.Beta ?? (object)DBNull.Value;
                row["RawData"] = r.RawData;
                row["PricePerformance"] = r.PricePerformance;
                row["MomentumScore"] = r.MomentumScore ?? (object)DBNull.Value;
                row["CurrentMarketCap"] = r.CurrentMarketCap ?? (object)DBNull.Value;
                row["AvgMarketCap10"] = r.AvgMarketCap10 ?? (object)DBNull.Value;
                row["AvgMarketCap20"] = r.AvgMarketCap20 ?? (object)DBNull.Value;
                row["AvgMarketCap50"] = r.AvgMarketCap50 ?? (object)DBNull.Value;

                row["AvgVolume10"] = r.AvgVolume10 ?? (object)DBNull.Value;
                row["AvgVolume20"] = r.AvgVolume20 ?? (object)DBNull.Value;
                row["AvgVolume50"] = r.AvgVolume50 ?? (object)DBNull.Value;


                // Map ProfitDays[0..29] → columns ProfitDay1..10, ProfitDay20, ProfitDay30
                for (int i = 0; i < 30; i++)
                {
                    var profit = r.ProfitDays[i];

                    // If zero by default and you want DBNull for "no value",
                    // you could check for a sentinel; left as-is to keep behavior deterministic.
                    if (i < 10)
                    {
                        row[$"ProfitDay{i + 1}"] = profit;
                    }
                    else if (i == 19) // day 20
                    {
                        row["ProfitDay20"] = profit;
                    }
                    else if (i == 29) // day 30
                    {
                        row["ProfitDay30"] = profit;
                    }
                }

                dt.Rows.Add(row);
            }

            return dt;
        }

        private void BulkInsertData(string connectionString, DataTable dataTable)
        {
            var sw = Stopwatch.StartNew();
            HistoryStats.BulkInsertCalls++;
            HistoryStats.TotalRowsInserted += dataTable.Rows.Count;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.DestinationTableName = "history.StockTrades";

                        // Performance tuning
                        bulkCopy.BatchSize = 50000;
                        bulkCopy.BulkCopyTimeout = 0; // No timeout
                        bulkCopy.EnableStreaming = true;
                        bulkCopy.NotifyAfter = 100000;

                        foreach (DataColumn column in dataTable.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                        }

                        bulkCopy.WriteToServer(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Bulk insert failed", ex);
            }
            finally
            {
                sw.Stop();
                HistoryStats.TotalBulkInsertTime += sw.Elapsed;
            }
        }

        private async Task BulkInsertDataAsync(string connectionString, DataTable dataTable)
        {
            var sw = Stopwatch.StartNew();
            HistoryStats.BulkInsertCalls++;
            HistoryStats.TotalRowsInserted += dataTable.Rows.Count;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync().ConfigureAwait(false);

                    using (var bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.DestinationTableName = "history.StockTrades";

                        // Performance tuning
                        bulkCopy.BatchSize = 50000;
                        bulkCopy.BulkCopyTimeout = 0; // No timeout
                        bulkCopy.EnableStreaming = true;
                        bulkCopy.NotifyAfter = 100000;

                        foreach (DataColumn column in dataTable.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                        }

                        using (var reader = dataTable.CreateDataReader())
                        {
                            await bulkCopy.WriteToServerAsync(reader).ConfigureAwait(false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Bulk insert failed", ex);
            }
            finally
            {
                sw.Stop();
                HistoryStats.TotalBulkInsertTime += sw.Elapsed;
            }
        }

        public void PrintStatistics()
        {
            HistoryStats.Print();
        }
    }
}
