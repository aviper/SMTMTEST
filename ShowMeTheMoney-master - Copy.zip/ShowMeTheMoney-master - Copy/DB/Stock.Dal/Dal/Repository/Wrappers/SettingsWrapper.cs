﻿using Stock.Common.Dto;
using Stock.Common.Dto.StartParamsItems;
using Stock.Common.Enums;
using Stock.Common.Logger;
using Stock.Common.Settings;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Stock.Common.Enums.Enums;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class SettingsWrapper : BaseWrapper
    {
        private DbDal _parent;

        public SettingsWrapper(DbDal parent)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            this._parent = parent;
        }

        internal ProcessInfoDto GetProcessInfoRowData()
        {
            var result = new ProcessInfoDto();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var AnalyzerProcessHistory = _parent.GetProcessHistory(ProcessHistoryCodeEnum.EIdentifier.Analyzer);
                    if (AnalyzerProcessHistory != null)
                    {
                        result.AnalyzeLastRun = AnalyzerProcessHistory.LastRunDate;
                    }
                    var CollectorLastRunHistory = _parent.GetProcessHistory(ProcessHistoryCodeEnum.EIdentifier.Collector);
                    if (CollectorLastRunHistory != null)
                    {
                        result.CollectorLastRun = CollectorLastRunHistory.LastRunDate;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetProcessInfoRowData {0}", ex);
                throw;
            }
            return result;
        }

        internal void UpdateLogLevelRowData(Enums.DbLogLevel level)
        {
            var configData = LoadConfigRowData();
            configData.StartParams.LogLevel = level;
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var StartParamsObj = context.Configurations.FirstOrDefault(x => x.Code == ConfigurationCodeEnum.EIdentifier.StartParams.ToString());
                    StartParamsObj.Data = configData.StartParams.ToString();
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateLogLevelRowData {0}", ex);
                throw ex;
            }
        }

        internal ConfigurationDto LoadConfigRowData()
        {
            var result = new ConfigurationDto();

            try
            {
                result.StartParams = new StartParamsDto();
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    //var StartParamsObj = context.Configurations.FirstOrDefault(x => x.Code == ConfigurationCodeEnum.EIdentifier.StartParams.ToString());
                    //if (StartParamsObj == null)
                    //{
                    //    var newConfigurations = new Configuration();
                    //    newConfigurations.Id = Guid.NewGuid();
                    //    newConfigurations.Code = ConfigurationCodeEnum.EIdentifier.StartParams.ToString();
                    //    newConfigurations.Data = new StartParamsDto().ToString();
                    //    context.Configurations.Add(newConfigurations);
                    //    context.SaveChanges();
                    //}
                    //else if (!string.IsNullOrEmpty(StartParamsObj.Data))
                    //{
                    //    result.StartParams = StartParamsDto.FromStringSafe(StartParamsObj.Data);
                    //    StartParamsObj.Data = result.StartParams.ToString();
                    //    context.SaveChanges();

                    //}

                    var objs = context.StocksListSources.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            try
                            {
                                result.StocksListSources.Add(StocksDataSourceConverter.ToDto(item));
                            }
                            catch (Exception ex)
                            {
                                Logger.FatalF("LoadConfigRowData StocksListSources not found", ex);
                                //throw;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("LoadConfigRowData {0}", ex);
                throw ex;
            }
            return result;
        }

        public readonly ConcurrentQueue<LogDto> PendingLogs = new ConcurrentQueue<LogDto>();
        private Task WriteLogsToDBTask = null;

        internal void WriteLogMessageRowData(LogDto log)
        {
            PendingLogs.Enqueue(log); //add to ConcurrentQueue log

            if (WriteLogsToDBTask == null || WriteLogsToDBTask.Status != TaskStatus.Running) //Start the task to write to DB
            {
                WriteLogsToDBTask = Task.Run(() => DoWriteLogsToDBTask());
            }
        }

        internal void UpdateConfiguration(ConfigurationCodeEnum.EIdentifier configCode, string data)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var config = context.Configurations.FirstOrDefault(x => x.Code == configCode.ToString());

                    if (config != null)
                    {
                        config.Data = data;
                    }
                    else
                    {
                        var newConfigurations = new Configuration();
                        newConfigurations.Id = Guid.NewGuid();
                        newConfigurations.Code = configCode.ToString();
                        newConfigurations.Data = data;
                        context.Configurations.Add(newConfigurations);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateConfiguration {0}", ex);
                throw ex;
            }
        }

        internal string GetConfigurationData(ConfigurationCodeEnum.EIdentifier configCode)
        {
            const int maxRetries = 2;
            const int commandTimeoutSeconds = 120;
            int retryCount = 0;

            while (retryCount < maxRetries)
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        // Increase command timeout
                        context.Database.CommandTimeout = commandTimeoutSeconds;

                        var config = context.Configurations
                            .FirstOrDefault(x => x.Code == configCode.ToString());

                        return config?.Data;
                    }
                }
                catch (Exception ex)
                {
                    retryCount++;
                     
                    Logger.ErrorF("GetConfigurationData failed on attempt {0}/{1}. Exception: {2}",
                        retryCount, maxRetries, ex);

                    if (retryCount >= maxRetries)
                    {
                        // Re-throw the last exception after all retries failed
                        throw;
                    }

                    // Optional: delay before retry (e.g., exponential backoff)
                    Task.Delay(TimeSpan.FromSeconds(2 * retryCount)).Wait();
                }
            }

            return null; // Should not reach here
        }


        private void DoWriteLogsToDBTask()
        {
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(10000);//Wait 10 sec between write to DB
                ProcessPendingLogs();
            }
        }

        internal List<LogDto> GetRecentLogsData(GetRecentLogsParamsDto param)
        {
            List<LogDto> result = new List<LogDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.GetRecentLogs((int)param.loglevel, param.count, param.lastDays, param.Application);

                    if (data != null)
                    {
                        var data2 = data.ToList();
                        foreach (var item in data2)
                        {
                            result.Add(new LogDto() { Application = item.Application, LogType = (DbLogLevel)item.LogType, Data = item.Data, Date = item.Date.GetValueOrDefault() });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetRecentLogsData {0}", ex);

                throw;
            }
            return result;
        }

        private void ProcessPendingLogs()
        {
            if (PendingLogs.Count > 0)
            {
                try
                {
                    using (var errors = GetRepository<Log>())
                    {
                        var numOfPendingLogs = PendingLogs.Count;
                        var added = false;
                        for (int i = 0; i < numOfPendingLogs; i++)
                        {
                            added = true;
                            LogDto currentLog = null;
                            PendingLogs.TryDequeue(out currentLog);
                            if (ShowMeTheMoneySettings.Instance.DisableLogsWrite)
                            {
                                return;
                            }

                            if (currentLog != null && !string.IsNullOrEmpty(currentLog.Data))
                            {
                                if (!string.IsNullOrEmpty(currentLog.Data))
                                {
                                    currentLog.Data = currentLog.Data.Substring(0, Math.Min(currentLog.Data.Length, 1000));
                                }

                                var err = new Log
                                {
                                    ID = Guid.NewGuid(),
                                    Date = DateTime.Now.NowOrDefault(),
                                    Data = currentLog.Data,
                                    LogType = (int)currentLog.LogType,
                                    Application = currentLog.Application
                                };
                                errors.Add(err);
                            }
                        }
                        if (added)
                        {
                            errors.Save();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("WriteLogMessageRowData {0}", ex);

                    throw;
                }
            }
        }

        private ParamBase GetParamOrDefault(ConfigurationCodeEnum.EIdentifier code, string Data = null)
        {
            ParamBase result = null;
            switch (code)
            {
                case ConfigurationCodeEnum.EIdentifier.StartParams:
                    break;

                case ConfigurationCodeEnum.EIdentifier.StartSitesParams:
                    result = StartSiteParamsDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.StartGoogleTrendParams:
                    result = StartGoogleTrendsParamsDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.FinvizScannerStartParams:
                    result = FinvizScannerStartParamsDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.ScheduledProcessStartParams:
                    result = ScheduledProcessStartParamsDto.FromStringSafe(Data);

                    break;

                case ConfigurationCodeEnum.EIdentifier.PremarketStockScannerParas:
                    result = PremarketStockScannerParamDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.Trader:
                    result = TraderParamDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.MomentumStocksParams:
                    result = MomentumStocksParamDto.FromStringSafe(Data);
                    break;

                case ConfigurationCodeEnum.EIdentifier.RunStrategyParams:
                    result = RunStrategyParamDto.FromStringSafe(Data);
                    break;

                default:
                    throw new NotImplementedException();
            }
            return result;
        }

        internal void SetStartParamsRowData(ConfigurationCodeEnum.EIdentifier code, ParamBase param)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var StartParamsObj = context.Configurations.FirstOrDefault(x => x.Code == code.ToString());
                    if (StartParamsObj != null)
                    {
                        StartParamsObj.Data = param.ToString();
                        context.SaveChanges();
                    }
                    else
                    {
                        var newConfigurations = new Configuration();
                        newConfigurations.Id = Guid.NewGuid();
                        newConfigurations.Code = code.ToString();
                        newConfigurations.Data = param.ToString();
                        context.Configurations.Add(newConfigurations);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SetStartParamsRowData {0}", ex);
                throw;
            }
        }

        internal ParamBase GetStartParamsRowData(ConfigurationCodeEnum.EIdentifier code)
        {
            ParamBase result = GetParamOrDefault(code);

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var StartParamsObj = context.Configurations.FirstOrDefault(x => x.Code == code.ToString());
                    if (StartParamsObj != null)
                    {
                        result = GetParamOrDefault(code, StartParamsObj.Data);

                        StartParamsObj.Data = result.ToString();
                        context.SaveChanges();
                    }
                    else
                    {
                        var newConfigurations = new Configuration();
                        newConfigurations.Id = Guid.NewGuid();
                        newConfigurations.Code = code.ToString();
                        newConfigurations.Data = result.ToString();
                        context.Configurations.Add(newConfigurations);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStartParamsRowData {0}", ex);
                throw;
            }
            return result;
        }

        internal List<GetDbSize_Result> GetDbSizeRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    return context.GetDbSize().ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetDbSize {0}", ex);
                throw;
            }
        }

        internal void RunDatabaseMaintenance(bool forchShrink = false)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var result = context.Database.ExecuteSqlCommand(System.Data.Entity.TransactionalBehavior.DoNotEnsureTransaction, @"exec Application.ShrinkDB");
                    //context.ShrinkDB(forchShrink);
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("shringDB {0}", ex);

                throw;
            }
        }
    }
}