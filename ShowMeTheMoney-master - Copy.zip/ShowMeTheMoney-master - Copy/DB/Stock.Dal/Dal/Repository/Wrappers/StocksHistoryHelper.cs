﻿using Stock.Common.Dto;
using Stock.Common.Helpers;
using Stock.Common.Settings;
using Stock.Dal.DBModel;
using System;
using System.Linq;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    public static class StocksHistoryHelper
    {
        public static StocksHistory CreateNewStocksHistory(StocksHistoryItemDto dto)
        {
            DateTime minDate = StockCommon.Instance.MinDateToLoadHistory;
            var history = dto.Data?.History;

            var created = minDate;
            var lastSample = minDate;
            decimal? lastPrice = -1;

            if (history != null && history.Any())
            {
                created = history.First().Key;
                lastSample = history.Last().Key;
                lastPrice = history.Last().Value.Close;
            }


            return new StocksHistory
            {
                Id = Guid.NewGuid(),
                Symbol = dto.Symbol,
                EtfSymbol = dto.EtfSymbol,
                IndexSymbol = dto.IndexSymbol,
                SymbolGroup = dto.SymbolGroup,
                Sector = dto.Sector,
                Industry = dto.Industry,
                MarketCap = dto.LastMarketCap,
                Created = created,
                FirstSample = created,
                LastSample = lastSample,
                LastSync = created,
                LastPrice = (lastPrice > 1_000_000) ? null : lastPrice,
                Updated = DateTime.Now.Date,
                HistoryData = CompressHistoryData(dto),
                MetaData = dto.StocksMetaData?.ToJson(),
                IsValid = true,
                InvalidReason = dto.InvalidReason,
                InitialHoldDataJson = dto.HoldAnalyticsData?.ToJson()
            };
        }

        public static void UpdateStocksHistory(StocksHistory entity, StocksHistoryItemDto dto)
        {
            DateTime minDate = StockCommon.Instance.MinDateToLoadHistory;
            var history = dto.Data?.History;

            var created = minDate;
            var lastSample = minDate;
            decimal? lastPrice = -1;

            if (history != null && history.Any())
            {
                created = history.First().Key;
                lastSample = history.Last().Key;
                lastPrice = history.Last().Value.Close;
            }
            if (!dto.UpdateFailedWithNoData)
            {
                entity.LastSync = DateTime.Now;
            }
            entity.IsValid = dto.IsValid;
            entity.InvalidReason = dto.InvalidReason;
            entity.Updated = DateTime.Now;
            entity.Created = created;
            entity.FirstSample = created;
            entity.LastSample = lastSample;
            entity.LastPrice =  lastPrice;
            entity.Sector = dto.Sector ?? entity.Sector;
            entity.Industry = dto.Industry ?? entity.Industry;
            entity.MarketCap = dto.LastMarketCap ?? entity.MarketCap;

            entity.EtfSymbol = dto.EtfSymbol ?? entity.EtfSymbol;
            entity.IndexSymbol = dto.IndexSymbol ?? entity.IndexSymbol;
            entity.SymbolGroup = dto.SymbolGroup ?? entity.SymbolGroup;

            if (dto.Data != null)
            {
                entity.HistoryData = CompressHistoryData(dto);
            }

            if (dto.StocksMetaData != null)
            {
                entity.MetaData = dto.StocksMetaData.ToJson();
            }

            entity.InitialHoldDataJson = dto.HoldAnalyticsData?.ToJson();
        }

        public static void EnsureStockExists(DBEntities context, string symbol)
        {
            if (!context.Stocks.Any(x => x.Symbol.ToLower() == symbol.ToLower()))
            {
                context.Stocks.Add(new DBModel.Stock
                {
                    Id = Guid.NewGuid(),
                    Symbol = symbol,
                    Added = DateTime.Now,
                    Modified = DateTime.Now,
                    InWatchList = false
                });
            }
        }

        private static string CompressHistoryData(StocksHistoryItemDto dto)
        {
            var json = dto.Data?.ToString();
            return Common.Settings.ShowMeTheMoneySettings.UseCompression
                ? GZip.CompressString(json)
                : json;
        }
    }

}
