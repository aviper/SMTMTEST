﻿using Stock.Common.Dto;
using Stock.Common.Dto.Screener;
using Stock.Common.Enums;
using Stock.Common.Helpers;
using Stock.Common.Logger;
using Stock.Common.Settings;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using static Stock.Common.Dto.Screener.MomentumStocksData;
using static System.Collections.Specialized.BitVector32;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class ScannersWrapper : BaseWrapper
    {
        private readonly DbDal _parent;

        public decimal LastPrice { get; private set; }

        public ScannersWrapper(DbDal parent)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            this._parent = parent;
        }

        internal void SavePremarketScannerDataRowData(PremarketScannerDataDto premarketScannerData)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (PremarketScannerDataItem item in premarketScannerData.ListItems)
                    {
                        var itemToAdd = new AlertHistory();
                        itemToAdd.Id = Guid.NewGuid();
                        itemToAdd.Scanner = ProcessHistoryCodeEnum.EIdentifier.PremarketStockScanner.ToString();
                        itemToAdd.Code = premarketScannerData.Code.ToString();
                        itemToAdd.Score = item.Score;
                        itemToAdd.Price = item.PremarketData.Price;
                        itemToAdd.Symbol = item.Item.Symbol;
                        itemToAdd.Date = DateTime.Now.NowOrDefault();
                        itemToAdd.Data = item.GetItemToSave().ToString(); ;
                        context.AlertHistories.Add(itemToAdd);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SavePremarketScannerData {0}", ex);
                throw;
            }
        }

        public List<AlertHistoryDataDto> GetAlertHistoriesDataRowData(ProcessHistoryCodeEnum.EIdentifier scanner, DateTime fromDate, DateTime toDate)
        {
            List<AlertHistoryDataDto> result = new List<AlertHistoryDataDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var alertHistories = context.AlertHistories.Where(x => x.Date >= fromDate && x.Date <= toDate && x.Scanner == scanner.ToString()).ToList();
                    if (alertHistories.Any())
                    {
                        foreach (var alertHistory in alertHistories)
                        {
                            var itemToAdd = AlertHistoryConverter.ToDto(alertHistory);

                            result.Add(itemToAdd);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAlertHistoriesDataRowData {0}", ex);

                throw;
            }
            return result;
        }

        public AlertHistoryDataDto GetAlertHistoryDataRowData(Guid alertHistoryId)
        {
            AlertHistoryDataDto result = new AlertHistoryDataDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var obj = context.AlertHistories.FirstOrDefault(x => x.Id == alertHistoryId);
                    if (obj != null)
                    {
                        result = AlertHistoryConverter.ToDto(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAlertsHistoryDataRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal void SaveFinvizAlertsRowData(List<FinvizScannersDataItem> items, string name)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (FinvizScannersDataItem item in items)
                    {
                        var itemToAdd = new AlertHistory
                        {
                            Id = Guid.NewGuid(),
                            Scanner = ProcessHistoryCodeEnum.EIdentifier.FinvizScanner.ToString(),
                            Code = name,
                            Score = item.Score,
                            Price = item.PremarketData.Price,
                            Symbol = item.Item.Symbol,
                            Date = DateTime.Now.NowOrDefault(),
                            Data = item.GetItemToSave().ToString()
                        };

                        context.AlertHistories.Add(itemToAdd);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveFinvizAlertsRowData {0}", ex);
                throw;
            }
        }

        internal void RunFixDataRowData(ProcessHistoryCodeEnum.EIdentifier process)
        {
            try
            {
                if (process == ProcessHistoryCodeEnum.EIdentifier.FinvizScanner)
                {
                    //FixFinvizeData();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

        internal StocksHistoryToRefreshDto GetStocksHistoryToRefreshRowData(DateTime lastTradingDate, int maxItems)
        {
            StocksHistoryToRefreshDto result = new StocksHistoryToRefreshDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var stocksHistories = context.GetStocksHistories(lastTradingDate, maxItems).ToList();
                    if (stocksHistories.Any())
                    {
                        foreach (var stocksHistory in stocksHistories)
                        {
                            result.StocksHistories.Add(StockHistoryConverter.ToStocksHistoryToRefreshDto(stocksHistory));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksHistoryToRefreshRowData {0}", ex);

                throw;
            }
            return result;
        }
        internal List<StocksHistorySymbolsDto> GetStocksHistorySymbolsRowData()
        {
            Logger.Info("Starting GetStocksHistorySymbolsRowData...");

            var res = new List<StocksHistorySymbolsDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Fetch stock history symbols from the database
                    var stocksHistoriesSymbols = context.GetStocksHistoriesSymbols().ToList();

                    if (stocksHistoriesSymbols.Any())
                    {
                        Logger.Info($"Fetched {stocksHistoriesSymbols.Count} stock symbol records from history.");

                        res = stocksHistoriesSymbols
                            .Select(item => new StocksHistorySymbolsDto
                            {
                                Symbol = item.Symbol,
                                LastSample = item.LastSample,
                                FirstSample = item.FirstSample
                            }).ToList();
                    }
                    else
                    {
                        Logger.Warn("No stock history symbols found.");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error in GetStocksHistorySymbolsRowData: {ex.Message}", ex);
                throw;  // Rethrow to preserve stack trace
            }

            return res;
        }



        internal List<string> GetInvalidStocksFromHistory()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    return context.StockInfoViews.Where(s2 => !s2.IsValid).Select(s => s.Symbol).ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksHistory {0}", ex);

                throw;
            }
        }

        internal List<(string Symbol, DateTime? LastSync)> GetOutdatedStocksRowData(DateTime lastDate)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var rawData = context.StockInfoViews
                        .Where(s => s.IsValid && s.LastSync != null)
                        .Select(s => new { s.Symbol, s.LastSync })
                        .ToList(); // Now materialize to memory

                    return rawData
                        .Where(x => x.LastSync.Value <= lastDate) // Safe to use .Value now
                        .Select(x => (x.Symbol, x.LastSync))
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetOutdatedStocksRowData {0}", ex);
                throw;
            }
        }



        /// <summary>
        /// Compresses the stock data string using GZip if enabled in settings.
        /// </summary>
        private string CompressHistoryData(StocksHistoryItemDto item)
        {
            if (item == null || item.Data == null)
                return null;

            var dataStr = item.Data.ToString();
            return Common.Settings.ShowMeTheMoneySettings.UseCompression
                ? GZip.CompressString(dataStr)
                : dataStr;
        }

        internal async Task<Dictionary<string, StocksHistoryItemDto>> GetStocksHistoryRowDataAsync(List<string> symbols)
        {
            Dictionary<string, StocksHistoryItemDto> result = new Dictionary<string, StocksHistoryItemDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    List<StocksHistory> stocksHistories = null;
                    if (symbols != null)
                    {
                        stocksHistories = await context.StocksHistories
                            .Where(x => symbols.Contains(x.Symbol))
                            .ToListAsync();
                    }
                    else
                    {
                        stocksHistories = await context.StocksHistories.ToListAsync();
                    }

                    if (stocksHistories.Any())
                    {
                        foreach (var stocksHistory in stocksHistories)
                        {
                            result.Add(stocksHistory.Symbol, StockHistoryConverter.ToStocksHistoryItemDtoDto(stocksHistory));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksHistory {0}", ex);

                throw;
            }
            return result;
        }

        internal Dictionary<string, StocksHistoryItemDto> GetStocksHistoryRowData(List<string> symbols)
        {
            var result = new Dictionary<string, StocksHistoryItemDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    IQueryable<StocksHistory> query = context.StocksHistories;


                    // Only filter if symbols are provided
                    if (symbols != null && symbols.Any())
                    {
                        query = query.Where(x => symbols.Contains(x.Symbol));

                    }

                    // Convert to dictionary directly
                    result = query.ToDictionary(
                        x => x.Symbol.Trim(),
                        x => StockHistoryConverter.ToStocksHistoryItemDtoDto(x));

                    //var result2 = StockHistoryConverter.ToStockTradesViewsDto(query2);
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksHistory {0}", ex);
                throw;
            }

            return result;
        }


        internal void FixStockHistoryDataRowData()
        {
            //try
            //{
            //    using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //    {
            //        List<StocksHistory> stocksHistories = context.StocksHistories.ToList();

            //        if (stocksHistories.Any())
            //        {
            //            foreach (var stocksHistory in stocksHistories)
            //            {
            //                var data = StockHistoryConverter.ToDto(stocksHistory);
            //                stocksHistory.LastSync = DateTime.Now;
            //                stocksHistory.Updated = DateTime.Now;
            //                if (Common.Settings.ShowMeTheMoneySettings.UseCompression)
            //                {
            //                    stocksHistory.Created = data.Data.History.First().Key;
            //                    stocksHistory.FirstSample = data.Data.History.First().Key;
            //                    stocksHistory.LastSample = data.Data.History.Last().Key;
            //                    stocksHistory.LastPrice = data.Data.History.Last().Value.Close;

            //                }
            //            }
            //            context.SaveChanges();
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Logger.ErrorF("GetStocksHistory {0}", ex);

            //    throw;
            //}
        }

        /// <summary>
        /// Updates or inserts stock history records in the database.
        /// </summary>
        /// <param name="stocksHistories">List of stock history DTOs to store in the database.</param>
        internal void SetStocksHistoryRowData(List<StocksHistoryItemDto> stocksHistories)
        {
            try
            {
                var context = new DBEntities(DbConnectionString.ConnectionString);

                int historyCounter = 0;
                int stockCounter = 0;

                Logger.Info(">>> Processing StocksHistories...");

                foreach (var dto in stocksHistories)
                {
                    if (dto == null || string.IsNullOrWhiteSpace(dto.Symbol))
                        continue;

                    var existing = context.StocksHistories.FirstOrDefault(x => x.Symbol.ToLower() == dto.Symbol.ToLower());
                    if (existing == null)
                    {
                        context.StocksHistories.Add(StocksHistoryHelper.CreateNewStocksHistory(dto));
                    }
                    else
                    {
                        StocksHistoryHelper.UpdateStocksHistory(existing, dto);
                    }

                    if (++historyCounter % 50 == 0)
                    {
                        context.SaveChanges();
                        Logger.InfoF("Saved {0} history records...", historyCounter);
                    }
                }

                context.SaveChanges();

                Logger.InfoF(">>> Total {0} StocksHistories saved.", historyCounter);

                Logger.Info(">>> Ensuring all stocks exist...");

                foreach (var dto in stocksHistories)
                {
                    if (string.IsNullOrWhiteSpace(dto?.Symbol)) continue;

                    StocksHistoryHelper.EnsureStockExists(context, dto.Symbol);
                    if (++stockCounter % 50 == 0)
                    {
                        context.SaveChanges();
                        Logger.InfoF("Saved {0} new stocks...", stockCounter);
                    }
                }

                context.SaveChanges();
                //UpdateUpgradeDowngradeHistories(stocksHistories);

                Logger.InfoF(">>> Total {0} new stocks saved.", stockCounter);
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SetStocksHistoryRowData error: {0}", ex);
                throw;
            }
        }



        internal void UpdateStocksHistoryDataRowData(List<StocksHistoryItemDto> stocksHistories)
        {
            try
            {
                 var context = new DBEntities(DbConnectionString.ConnectionString);

                var ids = stocksHistories.Select(s => s.Id).ToList();
                var symbols = stocksHistories.Select(s => s.Symbol).ToList();

                var existing = context.StocksHistories
                    .Where(x => ids.Contains(x.Id) || symbols.Contains(x.Symbol))
                    .ToList();

                foreach (var dto in stocksHistories)
                {
                    if (dto == null) continue;

                    var match = existing.FirstOrDefault(x => x.Id == dto.Id || x.Symbol.ToLower() == dto.Symbol.ToLower());
                    if (match != null)
                    {
                        StocksHistoryHelper.UpdateStocksHistory(match, dto);
                    }
                }

                context.SaveChanges();
                //UpdateUpgradeDowngradeHistories(stocksHistories);


            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateStocksHistoryDataRowData error: {0}", ex);
            }
        }

        private void UpdateUpgradeDowngradeHistories(List<StocksHistoryItemDto> stocksHistories)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Increase SQL command timeout to 2 minutes
                    context.Database.CommandTimeout = 120;

                    // Step 1: Extract symbols
                    var symbols = stocksHistories
                        .Select(s => s.Symbol)
                        .Where(s => !string.IsNullOrWhiteSpace(s))
                        .Distinct()
                        .ToHashSet();

                    if (symbols.Count == 0)
                        return;
                    const int batchSize = 100;

                    var symbolList = symbols.ToList();
                    for (int i = 0; i < symbolList.Count; i += batchSize)
                    {
                        var batch = symbolList.Skip(i).Take(batchSize).ToList();
                        string inClause = string.Join(",", batch.Select(s => $"'{s.Replace("'", "''")}'"));
                        string deleteSql = $"DELETE FROM History.UpgradeDowngradeHistory WHERE Symbol IN ({inClause})";

                        context.Database.ExecuteSqlCommand(deleteSql);
                    }

                    // Step 2: Delete existing records for these symbols
                    //var toDelete = context.UpgradeDowngradeHistories
                    //    .Where(x => symbols.Contains(x.Symbol));
                    //context.UpgradeDowngradeHistories.RemoveRange(toDelete);
                    //context.SaveChanges();

                    // Step 3: Prepare new records
                    var newRecords = new List<UpgradeDowngradeHistory>(10000);

                    foreach (var item in stocksHistories)
                    {
                        var splits = item.StocksMetaData.Splits;
                        if (string.IsNullOrWhiteSpace(item.Symbol) ||
                            item.StocksMetaData?.AnalystRating?.UpgradeDowngradeHistory == null ||
                            item.Data?.History == null)
                            continue;

                        var historyList = item.StocksMetaData.AnalystRating.UpgradeDowngradeHistory;
                        var historyMap = item.Data.History;

                        foreach (var udh in historyList)
                        {

                            var currentQuote = historyMap.TryGetValue(udh.Date, out var cq) ? cq : null;

                            decimal? GetPrice(int days)
                            {
                                var tradeDate = TradingDayHelper.Instance.GetDateAfterTradingDays(udh.Date, days);
                                return tradeDate != null && historyMap.TryGetValue(tradeDate, out var q)
                                    ? (decimal?)q.Close
                                    : null;
                            }

                            newRecords.Add(new UpgradeDowngradeHistory
                            {
                                Id = Guid.NewGuid(),
                                Symbol = item.Symbol,
                                Date = udh.Date,
                                Firm = udh.Firm,
                                FromGrade = udh.FromGrade,
                                ToGrade = udh.ToGrade,
                                Action = udh.Action,
                                ValidationError = udh.ValidationError,
                                PriceTargetAction = udh.PriceTargetAction,
                                CurrentPriceTarget = (decimal?)udh.CurrentPriceTarget,
                                Change = udh.Change,
                                CurrentPrice = currentQuote?.Close != null ? (decimal?)currentQuote.Close : null,
                                PriceAfterDay1 = GetPrice(1),
                                PriceAfterDay2 = GetPrice(2),
                                PriceAfterDay3 = GetPrice(3),
                                PriceAfterDay4 = GetPrice(4),
                                PriceAfterDay5 = GetPrice(5),
                                PriceAfterDay6 = GetPrice(6),
                                PriceAfterDay7 = GetPrice(7),
                                PriceAfterDay8 = GetPrice(8),
                                PriceAfterDay9 = GetPrice(9),
                                PriceAfterDay10 = GetPrice(10),
                                PriceAfterDay20 = GetPrice(20),
                                PriceAfterDay30 = GetPrice(30)
                            });
                        }
                    }

                    // Step 4: Bulk insert new records
                    if (newRecords.Count > 0)
                    {
                        //context.BulkInsert(newRecords); // <== this is fast!
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateUpgradeDowngradeHistories: {0}", ex);
            }
        }

        //private void UpdateUpgradeDowngradeHistories(List<StocksHistoryItemDto> stocksHistories)
        //{
        //    try
        //    {
        //        using (var context = new DBEntities(DbConnectionString.ConnectionString))
        //        {
        //            // Increase SQL command timeout to 2 minutes
        //            context.Database.CommandTimeout = 120;
        //            context.Configuration.AutoDetectChangesEnabled = false;

        //            // Step 1: Extract symbols
        //            var symbols = stocksHistories
        //                .Select(s => s.Symbol)
        //                .Where(s => !string.IsNullOrWhiteSpace(s))
        //                .Distinct()
        //                .ToHashSet();

        //            if (symbols.Count == 0)
        //                return;

        //            // Step 2: Delete existing records for these symbols
        //            var toDelete = context.UpgradeDowngradeHistories
        //                .Where(x => symbols.Contains(x.Symbol));
        //            context.UpgradeDowngradeHistories.RemoveRange(toDelete);
        //            context.SaveChanges();

        //            // Step 3: Prepare new records
        //            var newRecords = new List<UpgradeDowngradeHistory>(10000);

        //            foreach (var item in stocksHistories)
        //            {
        //                if (string.IsNullOrWhiteSpace(item.Symbol) ||
        //                    item.StocksMetaData?.AnalystRating?.UpgradeDowngradeHistory == null ||
        //                    item.Data?.History == null)
        //                    continue;

        //                var historyList = item.StocksMetaData.AnalystRating.UpgradeDowngradeHistory;
        //                var historyMap = item.Data.History;

        //                foreach (var udh in historyList)
        //                {
        //                    if (!DateTime.TryParse(udh.Date, out var parsedDate))
        //                        continue;

        //                    var currentQuote = historyMap.TryGetValue(parsedDate, out var cq) ? cq : null;

        //                    decimal? GetPrice(int days)
        //                    {
        //                        var tradeDate = TradingDayHelper.Instance.GetDateAfterTradingDays(parsedDate, days);
        //                        return tradeDate != null && historyMap.TryGetValue(tradeDate, out var q)
        //                            ? (decimal?)q.Close
        //                            : null;
        //                    }

        //                    newRecords.Add(new UpgradeDowngradeHistory
        //                    {
        //                        Id = Guid.NewGuid(),
        //                        Symbol = item.Symbol,
        //                        Date = parsedDate,
        //                        Firm = udh.Firm,
        //                        FromGrade = udh.FromGrade,
        //                        ToGrade = udh.ToGrade,
        //                        Action = udh.Action,
        //                        PriceTargetAction = udh.PriceTargetAction,
        //                        CurrentPriceTarget = (decimal?)udh.CurrentPriceTarget,
        //                        Change = udh.Change,
        //                        CurrentPrice = currentQuote?.Close != null ? (decimal?)currentQuote.Close : null,
        //                        PriceAfterDay1 = GetPrice(1),
        //                        PriceAfterDay2 = GetPrice(2),
        //                        PriceAfterDay3 = GetPrice(3),
        //                        PriceAfterDay4 = GetPrice(4),
        //                        PriceAfterDay5 = GetPrice(5),
        //                        PriceAfterDay6 = GetPrice(6),
        //                        PriceAfterDay7 = GetPrice(7),
        //                        PriceAfterDay8 = GetPrice(8),
        //                        PriceAfterDay9 = GetPrice(9),
        //                        PriceAfterDay10 = GetPrice(10),
        //                        PriceAfterDay20 = GetPrice(20),
        //                        PriceAfterDay30 = GetPrice(30)
        //                    });
        //                }
        //            }

        //            // Step 4: Insert records in batches
        //            const int batchSize = 1000;
        //            for (int i = 0; i < newRecords.Count; i += batchSize)
        //            {
        //                var batch = newRecords.Skip(i).Take(batchSize).ToList();
        //                context.UpgradeDowngradeHistories.AddRange(batch);
        //                context.SaveChanges();
        //                context.ChangeTracker.Entries().ToList().ForEach(e => e.State = EntityState.Detached);
        //            }

        //            context.Configuration.AutoDetectChangesEnabled = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.ErrorF("UpdateUpgradeDowngradeHistories: {0}", ex);
        //    }
        //}



        internal void SaveMomentumStocksDataRowData(MomentumStocksData momentumStocks, bool deleteFlag)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    if (deleteFlag)
                    {
                        //clear the context.MomentumStocks table
                        context.Database.ExecuteSqlCommand("TRUNCATE TABLE stocks.[MomentumStocks]");
                    }
                    foreach (var item in momentumStocks.ScreenersStocks)
                    {
                        foreach (var itemToAdd in item.Value.Stocks)
                        {
                            // Check if the item already exists
                            var exists = context.MomentumStocks
                                .Any(m => m.Symbol == itemToAdd.Symbol && m.Screener == item.Key.ToString());

                            // Only add if it doesn't exist
                            if (!exists)
                            {
                                var itemToAddToDb = new MomentumStock();
                                itemToAddToDb.Id = Guid.NewGuid();
                                itemToAddToDb.Symbol = itemToAdd.Symbol;
                                itemToAddToDb.Added = DateTime.Now.NowOrDefault();
                                itemToAddToDb.Screener = item.Key.ToString();
                                itemToAddToDb.Data = itemToAdd.ToString();
                                context.MomentumStocks.Add(itemToAddToDb);
                            }
                        }
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveMomentumStocksDataRowData {0}", ex);
                throw;
            }
        }

        internal MomentumStocksData GetMomentumStocksDataRowData()
        {
            MomentumStocksData momentumStocksData = new MomentumStocksData();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var momentumStocks = context.MomentumStocks.Where(x => x.Id != null).ToList();
                    momentumStocksData.ScreenersStocks = new Dictionary<MomentumStocksEnum, ScreenerStocksData>();

                    foreach (var stock in momentumStocks)
                    {
                        MomentumStocksEnum screenerEnum;
                        if (!Enum.TryParse(stock.Screener, out screenerEnum))
                        {
                            Logger.WarnF("Unknown screener type: {0}", stock.Screener);
                            continue;
                        }

                        if (!momentumStocksData.ScreenersStocks.ContainsKey(screenerEnum))
                        {
                            momentumStocksData.ScreenersStocks[screenerEnum] = new ScreenerStocksData()
                            {
                                ScreenerType = screenerEnum,
                                Stocks = new List<ScreenerStockData>()
                            };
                        }

                        var stockData = new ScreenerStockData
                        {
                            Symbol = stock.Symbol,
                            Name = stock.Screener
                        };

                        momentumStocksData.ScreenersStocks[screenerEnum].Stocks.Add(stockData);
                    }
                }
                return momentumStocksData;
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetMomentumStocksDataRowData {0}", ex);
                throw;
            }
        }

        //private void FixFinvizeData()
        //{
        //    try
        //    {
        //        using (var context = new DBEntities(DbConnectionString.ConnectionString))
        //        {
        //            var data = context.AlertHistories.Where(x => x.Scanner == ProcessHistoryCodeEnum.EIdentifier.FinvizScanner.ToString()).ToList();
        //            if (data.Any())
        //            {
        //                foreach (var item in data)
        //                {
        //                    var oldDataToFix = FinvizScannersDataItem.FromStringSafe(item.Data);
        //                    if(oldDataToFix!=null)
        //                    item.Data = oldDataToFix.GetItemToSave().ToString();
        //                }
        //            }
        //            context.SaveChanges();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.ErrorF("FixFinvizeData {0}", ex);
        //        throw;
        //    }
        //}
    }
}