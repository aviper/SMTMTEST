﻿using Stock.Common.Dto;
using Stock.Common.Dto.Trading;
using Stock.Common.Indicators;
using Stock.Common.Logger;
using Stock.Common.Strategy;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class TradingWrapper : BaseWrapper
    {
        private DbDal _parent;

        public TradingWrapper(DbDal parent)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            this._parent = parent;
        }

        internal bool AddStrategiesRawData(List<StrategyItemDto> strategyCollection)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    for (int i = 0; i < strategyCollection.Count; i++)
                    {
                        var st = StrategyItemDto.FromString(strategyCollection[i].ToStringObject());
                        Strategy item = new Strategy();
                        item.Id = Guid.NewGuid();
                        item.Name = strategyCollection[i].Name;
                        item.Description = strategyCollection[i].Description;
                        item.StrategyData = st.ToStringObject();
                        item.Created = DateTime.Now.NowOrDefault();
                        item.Enable = false;
                        item.Deleted = false;

                        context.Strategies.Add(item);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStrategyRawData {0}", ex);
                throw;
            }
            return true;
        }

        internal bool AddStrategiesRawDataold(List<StrategyItemDto> strategyCollection)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var items = context.Strategies.Where(x => x.Id != null).ToList();
                    if (items.Any())
                    {
                        foreach (var item in items)
                        {
                            item.Deleted = true;
                        }
                        context.SaveChanges();
                    }

                    for (int i = 0; i < strategyCollection.Count; i++)
                    {
                        Strategy item = StrategyConverter.FromDto(strategyCollection[i]);
                        if (string.IsNullOrEmpty(item.Name))
                        {
                            item.Name = "Strategy" + item.Id.ToString();
                        }
                        if (string.IsNullOrEmpty(item.Description))
                        {
                            item.Description = "Strategy" + item.Id.ToString();
                        }
                        item.Deleted = false;
                        item.Enable = false;
                        context.Strategies.Add(item);

                        //var st = StrategyItemDto.FromString(strategyCollection[i].ToStringObject());
                        //Strategy item = new Strategy();
                        //item.Id = Guid.NewGuid();

                        //item.StrategyData = st.ToStringObject();
                        //item.Created = DateTime.Now.NowOrDefault();
                        //item.Enable = true;
                        //item.Deleted = false;
                        //item.Priority = i + 1;

                        //context.Strategies.Add(item);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStrategyRawData {0}", ex);
                throw;
            }
            return true;
        }

        internal List<StrategyItemDto> GetCurrentStrategyRawData()
        {
            var result = new List<StrategyItemDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var items = context.Strategies.Where(x => x.Deleted == false && x.Enable == true).ToList();
                    if (items.Any())
                    {
                        foreach (var item in items)
                        {
                            result.Add(StrategyConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetCurrentStrategyRawData {0}", ex);
                throw;
            }
            return result;
        }

        internal bool SaveBuyStockDataRawData(SaveStockDto data, bool simulation)
        {
            try
            {
                Guid tradeId = Guid.NewGuid();

                if (simulation)
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        TradesSimulation t = new TradesSimulation();
                        t.Id = tradeId;
                        t.HistoryId = data.History.Id;
                        t.HistoryData = data.History.ToObjectString();
                        t.Symbol = data.History.Symbol;
                        t.NumberOfShares = data.NumberOfShares;
                        t.BuyPrice = data.BuyPrice;
                        t.BuyDate = data.BuyDate;
                        t.PlannedSellDate = data.PlannedSellDate;
                        t.IndicatorSellDate = data.IndicatorSellDate;
                        t.TargetPrice = data.TargetPrice;

                        context.TradesSimulations.Add(t);
                        context.SaveChanges();
                    }
                }
                else
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        Trade t = new Trade();
                        t.Id = tradeId;
                        t.HistoryId = data.History.Id;
                        t.HistoryData = data.History.ToObjectString();
                        t.Symbol = data.History.Symbol;
                        t.NumberOfShares = data.NumberOfShares;
                        t.BuyPrice = data.BuyPrice;
                        t.BuyDate = DateTime.Now.NowOrDefault();
                        t.PlannedSellDate = data.PlannedSellDate;
                        t.IndicatorSellDate = data.IndicatorSellDate;
                        t.TargetPrice = data.TargetPrice;
                       
                        context.Trades.Add(t);
                        context.SaveChanges();
                    }

                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        foreach (StrategyItemDto strategy in data.Strategies)
                        {
                            TradesStrategy ts = new TradesStrategy();
                            ts.TradeId = tradeId;
                            ts.StrategyId = strategy.Id;
                            context.TradesStrategies.Add(ts);
                            context.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveBuyStockDataRawData {0}", ex);
                throw;
            }
            return true;
        }

        internal List<InvestmentDto> GetHoldingsRawData(bool simulation)
        {
            var result = new List<InvestmentDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    if (!simulation)
                    {
                        var Trades = context.Trades.ToList();
                        foreach (var item in Trades)
                        {

                            result.Add(new InvestmentDto()
                            {
                                NumberOfShares = item.NumberOfShares.Value,
                                BuyDate = item.BuyDate,
                                BuyPrice = (decimal)item.BuyPrice,
                                Data = item.Data,
                                HistoryData = item.HistoryData,
                                HistoryId = item.HistoryId,
                                Id = item.Id,
                                PlannedSellDate = item.PlannedSellDate,
                                IndicatorSellDate = item.IndicatorSellDate,

                                SellDate = item.SellDate,
                                SellPrice = (decimal)item.SellPrice,
                                TargetPrice = (decimal)item.TargetPrice,
                                Symbol = item.Symbol
                            });
                        }
                    }
                    else
                    {
                        var Trades = context.TradesSimulations.ToList();
                        foreach (var item in Trades)
                        {

                            result.Add(new InvestmentDto()
                            {
                                NumberOfShares = item.NumberOfShares.Value,
                                BuyDate = item.BuyDate,
                                BuyPrice = (decimal)item.BuyPrice,
                                Data = item.Data,
                                HistoryData = item.HistoryData,
                                HistoryId = item.HistoryId,
                                Id = item.Id,
                                PlannedSellDate = item.PlannedSellDate,
                                IndicatorSellDate = item.IndicatorSellDate,
                                SellDate = item.SellDate,
                                SellPrice = (decimal)item.SellPrice,
                                TargetPrice = (decimal)item.TargetPrice,
                                Symbol = item.Symbol,
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetCurrentHoldingsRawData {0}", ex);
                throw;
            }

            return result;
        }

        internal void UpdateHoldings(List<InvestmentDto> holdings)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (var item in holdings)
                    {
                        var dbItem = context.Trades.FirstOrDefault(x => x.Id == item.Id);
                        if (dbItem != null)
                        {
                            dbItem.NumberOfShares = item.NumberOfShares;
                            dbItem.BuyDate = item.BuyDate;
                            dbItem.BuyPrice = (double)item.BuyPrice;
                            dbItem.Data = item.Data;
                            dbItem.HistoryData = item.HistoryData;
                            dbItem.HistoryId = item.HistoryId;
                            dbItem.PlannedSellDate = item.PlannedSellDate;
                            dbItem.IndicatorSellDate = item.IndicatorSellDate;

                            dbItem.SellDate = item.SellDate;
                            dbItem.SellPrice = (double)item.SellPrice;

                            context.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateHoldings {0}", ex);
                throw;
            }
        }

        internal List<StrategyItemDto> GetAllStrategyRawData()
        {
            var result = new List<StrategyItemDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var items = context.Strategies.Where(x => x.Deleted == false).ToList();
                    if (items.Any())
                    {
                        foreach (var item in items)
                        {
                            result.Add(StrategyConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAllStrategyRawData {0}", ex);
                throw;
            }
            return result;
        }

        internal void SaveStrategies(List<StrategyItemDto> strategyCollection)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var strategies = context.Strategies.Where(x => x.Id != null).ToList();
                    if (strategies.Any())
                    {
                        foreach (var strategy in strategies)
                        {
                            var existItem = strategyCollection.FirstOrDefault(x => x.Id == strategy.Id);
                            if (existItem == null)
                            {
                                strategy.Deleted = true;
                                strategy.Enable = false;
                            }
                            else
                            {
                                strategy.Name = existItem.Name;
                                strategy.Description = existItem.Description;
                                strategy.Enable = existItem.Enable;
                                strategy.StrategyData = existItem.ToStringObject();
                                strategy.Default = existItem.Default;
                                
                            }
                        }
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStrategies {0}", ex);
                throw;
            }
        }

        internal bool GetIndicatorsTraderHoldingDataRawData(string symbol, StrategyItemNewDto strategy)
        {
            using (var context = new DBEntities(DbConnectionString.ConnectionString))
            {
                try
                {
                    var today = DateTime.Today;
                    var tradesIndicatorsAlert = context.TradesIndicatorsAlerts
                                .FirstOrDefault(x => x.Symbol.ToLower() == symbol.ToLower() && DbFunctions.TruncateTime(x.Created) == today);

                    return tradesIndicatorsAlert != null;
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("GetIndicatorsTraderHoldingDataRawData {0}", ex);
                    throw;
                }
            }
        }

        internal async Task IndicatorsTraderCommitBuyRawDataAsync(Common.Indicators.IndicatorsTraderDto data)
        {
            using (var context = new DBEntities(DbConnectionString.ConnectionString))
            {
                try
                {
                    var strategiesStocksHistory = await context.StrategiesStocksHistories
                        .FirstOrDefaultAsync(x => x.Symbol.ToLower() == data.SymbolData.Symbol.ToLower() && DbFunctions.TruncateTime(x.Added) == DbFunctions.TruncateTime(data.BuyDate.Date));

                    var item = new TradesIndicatorsAlert
                    {
                        Id = Guid.NewGuid(),
                        StrategiesStocksHistoryId = strategiesStocksHistory.Id,
                        Symbol = data.SymbolData.Symbol,
                        BuyDate = data.BuyDate,
                        BuyPrice = data.BuyPrice,
                        NumberOfShares = data.NumberOfShares,
                        PlannedSellDate = data.PlannedSellDate,
                        Data = data.Data,
                        TotalScore = data.TotalScore,
                        Created = DateTime.Now.NowOrDefault()
                    };
                    context.TradesIndicatorsAlerts.Add(item);
                    await context.SaveChangesAsync();

                    var todaysRecord = await context.StrategiesStocksHistories
                        .FirstOrDefaultAsync(h => h.Id == strategiesStocksHistory.Id);

                    if (todaysRecord != null)
                    {
                        todaysRecord.BuyDate = data.BuyDate;
                        todaysRecord.BuyStock = true;
                        //todaysRecord.Updated = DateTime.Now.NowOrDefault();
                        await context.SaveChangesAsync();
                    }
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("SaveStrategies {0}", ex);
                    throw;
                }
            }
        }

        internal List<IndicatorsTraderDto> GetAllIndicatorsTraderAlertsRawData()
        {
            var result = new List<IndicatorsTraderDto>();
            using (var context = new DBEntities(DbConnectionString.ConnectionString))
            {
                try
                {
                    // Retrieve all TradesIndicatorsAlert records from the database
                    var allAlerts = context.TradesIndicatorsAlerts.ToList();
                    if (allAlerts.Any())
                    {
                        foreach (var item in allAlerts)
                        {
                            result.Add(new IndicatorsTraderDto()
                            {
                                Id = item.Id,
                                SymbolData = new StockProfile(item.Symbol),
                                BuyDate = item.BuyDate,
                                BuyPrice = (decimal)item.BuyPrice,
                                NumberOfShares = item.NumberOfShares.Value,
                                PlannedSellDate = item.PlannedSellDate.Value,
                                Data = item.Data,
                                Created = item.Created,
                                SellPrice = (decimal)item.SellPrice.GetValueOrDefault(0),
                                SellDate = item.SellDate,
                                TotalScore = item.TotalScore.GetValueOrDefault(),
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("GetAllIndicatorsTraderAlerts {0}", ex);
                    throw;
                }
            }
            return result;
        }

        internal List<MarketHistoryDataDto> GetMarketHistoryDataRowData(int days_back, int min_score)
        {
            var result = new List<MarketHistoryDataDto>();
            using (var context = new DBEntities(DbConnectionString.ConnectionString))
            {
                try
                {
                    // Retrieve all TradesIndicatorsAlert records from the database
                    var allData = context.GetMarketHistoryData(days_back, min_score).ToList();
                    if (allData.Any())
                    {
                        foreach (var item in allData)
                        {
                            result.Add(new MarketHistoryDataDto()
                            {
                                Id = item.Id,
                                Date = item.Date,
                                Symbol = item.Symbol,
                                Price = (decimal)item.Price,
                                Score = item.Score,
                                Source = item.Source,
                                Data = item.Data,
                                IsDuringTrade = item.IsDuringTrade,
                                Rank = item.Rank,
                                RawScore = item.RawScore
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("GetMarketHistoryDataRowData {0}", ex);
                    throw;
                }
            }
            return result;
        }
    }
}