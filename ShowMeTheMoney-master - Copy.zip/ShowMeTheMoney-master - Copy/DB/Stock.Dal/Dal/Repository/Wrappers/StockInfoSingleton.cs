﻿using Stock.Common.Dto;
using Stock.Common.Logger;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using Stocks.Common.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    public class StockInfoSingleton
    {
        protected static readonly IStocksLogger Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.Collector);


        // Lazy thread-safe singleton instance
        private static readonly Lazy<StockInfoSingleton> _instance =
            new Lazy<StockInfoSingleton>(() => new StockInfoSingleton());

        // Public accessor for the singleton instance
        public static StockInfoSingleton Instance => _instance.Value;

        // Property to hold stock profiles
        public List<StockProfile> StockInfo { get; set; }

        // Private constructor to prevent instantiation
        private StockInfoSingleton()
        {
            StockInfo = new List<StockProfile>();
            ReloadStockProfileData();
        }


        private List<StockProfile> LoadStockProfileData()
        {
            var stockProfiles = new List<StockProfile>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var stockEntities = context.StockInfoViews.Where(x => x.Id != null).ToList();
                    if (stockEntities.Any())
                    {
                        stockProfiles.AddRange(stockEntities.Select(StockHistoryConverter.ToStockProfileDto));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("Error in LoadStocksOrderData: {0}", ex);
                throw;
            }

            return stockProfiles;
        }
        public void ReloadStockProfileData()
        {
            StockInfo = LoadStockProfileData();
        }


    }

}
