﻿using Newtonsoft.Json;
using Stock.Common.Dto;
using Stock.Common.Enums;
using Stock.Common.Helpers;
using Stock.Common.Logger;
using Stock.Common.Utils;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Threading;
using System.Threading.Tasks;
using static Stock.Common.Enums.Enums;
using static System.Data.Entity.Infrastructure.Design.Executor;
using static System.Data.Entity.Migrations.Model.UpdateDatabaseOperation;
namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal partial class HistoryWrapper : BaseWrapper
    {
        private DbDal _parent;
        private string BulkUpdateConnectionString;

        public HistoryWrapper(DbDal parent)
        {
            // Set up logger
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);

            // Assign parent
            this._parent = parent;

            // Retrieve configuration values
            var dbServerConfigKey = MachineUtils.Machine == eMachine.Zion_Projects || MachineUtils.Machine == eMachine.Avi
                ? "DatabaseServerNameLocal"
                : "DatabaseServerName";
            var databaseServerName = ConfigurationManager.AppSettings[dbServerConfigKey];
            var databaseProductionName = ConfigurationManager.AppSettings["DatabaseProductionName"];
            var loginId = ConfigurationManager.AppSettings["LoginID"];
            var password = ConfigurationManager.AppSettings["Password"];

            // Build the connection string
            BulkUpdateConnectionString = $"Data Source={databaseServerName};" +
                                         $"Initial Catalog={databaseProductionName};" +
                                         $"User ID={loginId};" +
                                         $"Password={password}";
        }




        internal List<StockTradesIndicatorDto> GetIndicatorsBySymbolsAndDateRangeRowData(string symbols, DateTime from, DateTime to)
        {
            Logger.Info("GetIndicatorsBySymbolsAndDateRangeRowData: Starting process to retrieve stock trades by date range.");

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    Logger.Info($"GetIndicatorsBySymbolsAndDateRangeRowData: Retrieving stock trade data from {from:dd/MM/yyyy} to {to:dd/MM/yyyy}.");

                    // Retrieve stock trade data using the stored procedure
                    var queryResult = context.GetIndicatorsBySymbolsAndDateRange(symbols, from, to);
                    var data = queryResult.ToList();

                    if (data == null || !data.Any())
                    {
                        Logger.Warn("GetIndicatorsBySymbolsAndDateRangeRowData: No stock trade data found for the specified date range.");
                        return new List<StockTradesIndicatorDto>(); // Return an empty list
                    }

                    // Convert the result to DTOs
                    var dtoResult = StockTradesDtoConverter.ToIndicatorsDto(data.ToList());


                    Logger.Info($"GetIndicatorsBySymbolsAndDateRangeRowData: Retrieved {dtoResult.Count} records of stock trade data.");
                    return dtoResult;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"GetIndicatorsBySymbolsAndDateRangeRowData: An error occurred while retrieving data. Exception: {ex.Message}", ex);
            }
            return new List<StockTradesIndicatorDto>();
        }

        internal DailyStocksQuotesDto GetDailyStocksQuotesRowData(List<string> stocks, DateTime? from, DateTime? to, bool includeEmptyIndicators)
        {
            Logger.Info("GetDailyStocksQuotesRowData: Starting process to retrieve stock trades by date range.");
            var totalStopwatch = Stopwatch.StartNew();
            var symbolSummaries = new List<Common.Dto.DailyStocksQuotesSummaryDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.CommandTimeout = 600;

                    string stockCsv = (stocks != null && stocks.Any())
                        ? string.Join(",", stocks)
                        : null;

                    Logger.Info($"Executing stored procedure for stocks: [{stockCsv}] and range: {from:dd/MM/yyyy} - {to:dd/MM/yyyy}");

                    var dbCallStopwatch = Stopwatch.StartNew();

                    var parameters = new[]
                    {
                new SqlParameter("@Symbols", (object)stockCsv ?? DBNull.Value),
                new SqlParameter("@StartDate", (object)from ?? DBNull.Value),
                new SqlParameter("@EndDate", (object)to ?? DBNull.Value),
                new SqlParameter("@IncludeEmptyIndicators", includeEmptyIndicators)
            };

                    var result = context.Database.SqlQuery<StockTrade>(
                        "EXEC [History].[GetStockTradesBySymbolsAndDateRange] @Symbols, @StartDate, @EndDate, @IncludeEmptyIndicators",
                        parameters
                    ).ToList();

                    dbCallStopwatch.Stop();
                    Logger.Info($"Stored procedure execution time: {dbCallStopwatch.ElapsedMilliseconds} ms");

                    if (result == null || !result.Any())
                    {
                        Logger.Warn("No stock trade data found for the specified date range.");
                        return new DailyStocksQuotesDto(new Dictionary<string, List<DailyStockQuotesDto>>(), symbolSummaries);
                    }

                    Logger.Info($"Raw records returned: {result.Count}");

                    var dtoConversionStopwatch = Stopwatch.StartNew();
                    var dtoResult = StockTradesDtoConverter.ToDto(result);
                    dtoConversionStopwatch.Stop();
                    Logger.Info($"DTO conversion time: {dtoConversionStopwatch.ElapsedMilliseconds} ms");

                    var groupedResult = new Dictionary<string, List<DailyStockQuotesDto>>();

                    foreach (var group in dtoResult.GroupBy(x => x.Symbol))
                    {
                        var groupStopwatch = Stopwatch.StartNew();

                        var trades = group.ToList();
                        groupedResult[group.Key] = trades;

                        int tradesWithIndicators = trades.Count(t => !string.IsNullOrWhiteSpace(t.IndicatorsJson) && t.IndicatorsJson != "{}");
                        int tradesWithoutIndicators = trades.Count - tradesWithIndicators;

                        var summary = new Common.Dto.DailyStocksQuotesSummaryDto
                        {
                            Symbol = group.Key,
                            TradeCount = trades.Count,
                            EarliestTrade = trades.Min(t => t.TradeDate),
                            LatestTrade = trades.Max(t => t.TradeDate),
                            TradesWithIndicators = tradesWithIndicators,
                            TradesWithoutIndicators = tradesWithoutIndicators,
                            ProcessingTimeMs = groupStopwatch.ElapsedMilliseconds
                        };

                        groupStopwatch.Stop();
                        symbolSummaries.Add(summary);

                        Logger.Info(
                            $"Symbol {group.Key}: {summary.TradeCount} trades, Range: {summary.EarliestTrade:dd/MM/yyyy} - {summary.LatestTrade:dd/MM/yyyy}, " +
                            $"With Indicators: {summary.TradesWithIndicators}, Without Indicators: {summary.TradesWithoutIndicators}, " +
                            $"Processed in {summary.ProcessingTimeMs} ms");
                    }

                    totalStopwatch.Stop();
                    Logger.Info($"GetDailyStocksQuotesRowData: Completed. Total time: {totalStopwatch.ElapsedMilliseconds} ms");

                    return new DailyStocksQuotesDto(groupedResult, symbolSummaries);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error in GetDailyStocksQuotesRowData: {ex.Message}", ex);
                return new DailyStocksQuotesDto(new Dictionary<string, List<DailyStockQuotesDto>>(), symbolSummaries);
            }
        }




        internal List<string> GetStockIndicatorDataToRefreshRowData(DateTime lastTradingDate)
        {
            Logger.Info("GetStockIndicatorDataToRefreshRowData: Starting reset process for simulator data.");

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    Logger.Info($"GetStockIndicatorDataToRefreshRowData: Retrieving missing stock trade data for the date: {lastTradingDate:dd/MM/yyyy}.");

                    var result = context.GetMissingStockTradeData(lastTradingDate)?.ToList();

                    if (result == null || !result.Any())
                    {
                        Logger.Warn("GetStockIndicatorDataToRefreshRowData: No missing stock trade data found.");
                        return new List<string>();
                    }

                    Logger.Info($"GetStockIndicatorDataToRefreshRowData: Retrieved {result.Count} records of missing stock trade data.");
                    return result;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"GetStockIndicatorDataToRefreshRowData: An error occurred while processing data. Exception: {ex.Message}", ex);
                throw;
            }
        }


        internal void ResetStockSimulatorDataRowData()
        {
            try
            {
                Logger.Info("ResetStockSimulatorDataRowData: Starting reset process for simulator data.");

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Use a transaction for better performance and data consistency
                    using (var transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            Logger.Info("ResetStockSimulatorDataRowData: Truncating simulator-related tables.");

                            // Use TRUNCATE for faster deletion, if constraints allow
                            context.Database.ExecuteSqlCommand("TRUNCATE TABLE [Simulator].[SimulatorIndicators]");
                            context.Database.ExecuteSqlCommand("DELETE  FROM [Simulator].[SimulatorStockTrades]");

                            context.Database.ExecuteSqlCommand("TRUNCATE TABLE [Simulator].[SimulatorStocks]");

                            transaction.Commit();
                            Logger.Info("ResetStockSimulatorDataRowData: Successfully truncated simulator-related tables.");
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            Logger.Error($"ResetStockSimulatorDataRowData: An error occurred while resetting data. Transaction rolled back. Exception: {ex.Message}", ex);
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ResetStockSimulatorDataRowData: An error occurred while resetting data. Exception: {ex.Message}", ex);
                throw;
            }
        }

        internal Dictionary<string, List<DailyStockQuotesDto>> GetStockTradesRowData(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate)
        {
            var allResults = new List<StockTrade>();

            try
            {
                Logger.Info($"GetStockTradesRowData: Starting retrieval for {symbols.Count} symbols from {fromDate:yyyy-MM-dd} to {toDate:yyyy-MM-dd}.");

                var symbolBatches = symbols
                    .Select((s, i) => new { Symbol = s, Index = i })
                    .GroupBy(x => x.Index / 10)
                    .Select(g => g.Select(x => x.Symbol).ToList())
                    .ToList();

                Logger.Info($"GetStockTradesRowData: Total batches to process: {symbolBatches.Count}");

                for (int batchIndex = 0; batchIndex < symbolBatches.Count; batchIndex++)
                {
                    var batch = symbolBatches[batchIndex];
                    string symbolData = string.Join(",", batch);
                    string distinctIndicatorsData = distinctIndicators != null ? string.Join(",", distinctIndicators) : null;

                    Logger.Info($"GetStockTradesRowData: Processing batch {batchIndex + 1}/{symbolBatches.Count} with {batch.Count} symbols.");

                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        context.Database.CommandTimeout = 600; // 10 minutes

                        var queryResult = context.Database.SqlQuery<StockTrade>(
                            "EXEC [History].[GetStockTradesBySymbolsAndDateRange] @Symbols = {0}, @StartDate = {1}, @EndDate = {2}, @IncludeEmptyIndicators = {3}, @Indicators = {4}",
                            symbolData,
                            fromDate,
                            toDate,
                            false,
                            distinctIndicatorsData
                        ).ToList();

                        Logger.Info($"GetStockTradesRowData: Batch {batchIndex + 1} returned {queryResult.Count} records.");

                        allResults.AddRange(queryResult);
                    }
                }

                if (!allResults.Any())
                {
                    Logger.Warn("GetStockTradesRowData: No stock trades found for any batch.");
                    return new Dictionary<string, List<DailyStockQuotesDto>>();
                }

                var dtoResult = StockTradesDtoConverter.ToStockTradesDictionay(allResults);

                Logger.Info($"GetStockTradesRowData: Completed retrieval. Total records: {allResults.Count}.");
                return dtoResult;
            }
            catch (Exception ex)
            {
                Logger.Error($"GetStockTradesRowData: An error occurred while retrieving data. Exception: {ex.Message}", ex);
                return new Dictionary<string, List<DailyStockQuotesDto>>();
            }
        }


        internal int PopulateStockTradesTradingSimulationsRowData(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate)
        {
            int totalInsertedRows = 0;

            try
            {
                Logger.Info($"PopulateStockTradesTradingSimulationsRowData: Starting for {symbols.Count} symbols from {fromDate:yyyy-MM-dd} to {toDate:yyyy-MM-dd}.");

                var symbolBatches = symbols
                    .Select((s, i) => new { Symbol = s, Index = i })
                    .GroupBy(x => x.Index / 10)
                    .Select(g => g.Select(x => x.Symbol).ToList())
                    .ToList();

                Logger.Info($"PopulateStockTradesTradingSimulationsRowData: Total batches to process: {symbolBatches.Count}");

                for (int batchIndex = 0; batchIndex < symbolBatches.Count; batchIndex++)
                {
                    var batch = symbolBatches[batchIndex];
                    string symbolData = string.Join(",", batch);
                    string indicatorsData = distinctIndicators != null ? string.Join(",", distinctIndicators) : null;

                    bool truncate = (batchIndex == 0); // Truncate only on first batch

                    Logger.Info($"PopulateStockTradesTradingSimulationsRowData: Processing batch {batchIndex + 1}/{symbolBatches.Count} with {batch.Count} symbols. Truncate = {truncate}");

                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        context.Database.CommandTimeout = 600;
                        // This assumes PopulateStockTradesTradingSimulations returns a scalar result: number of rows inserted
                        var insertedCount = context.PopulateStockTradesTradingSimulations(
                            symbolData,
                            fromDate,
                            toDate,
                            false, // IncludeEmptyIndicators = false
                            indicatorsData,
                            truncate ? true : false // SQL expects INT not bool
                        ).FirstOrDefault();

                        Logger.Info($"PopulateStockTradesTradingSimulationsRowData: Batch {batchIndex + 1} inserted {insertedCount} rows.");
                        totalInsertedRows += insertedCount.GetValueOrDefault(0);
                    }
                }

                Logger.Info($"PopulateStockTradesTradingSimulationsRowData: Done. Total inserted: {totalInsertedRows} rows.");
                return totalInsertedRows;
            }
            catch (Exception ex)
            {
                Logger.Error($"PopulateStockTradesTradingSimulationsRowData: Error occurred - {ex.Message}", ex);
                return 0;
            }
        }
        internal async Task<TradingSimulationsResult> GetStockTradesTradingSimulationsInfo(string symbolsCsv,DateTime? fromDate,DateTime? toDate)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var conn = context.Database.Connection;

                    await conn.OpenAsync();

                    using (var command = conn.CreateCommand())
                    {
                        command.CommandText = "[Trading].[GetStockTradesTradingSimulationsInfo]";
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add(new SqlParameter("@FromDate", fromDate));
                        command.Parameters.Add(new SqlParameter("@ToDate", toDate));
                        command.Parameters.Add(new SqlParameter("@Symbols", symbolsCsv)); // comma-separated

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            // First result set (Summary)
                            var summary = new List<TradingSummaryDto>();
                            while (await reader.ReadAsync())
                            {
                                summary.Add(new TradingSummaryDto
                                {
                                    ResultType = reader.GetString(0),
                                    Symbol = reader.IsDBNull(1) ? null : reader.GetString(1),
                                    TotalTrades = reader.GetInt32(2),
                                    NumberOfStocks = reader.GetInt32(3),
                                    TradeDateFrom = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4),
                                    TradeDateTo = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5),
                                    AvgProfitDay1 = reader.GetDecimal(6)
                                    // ... continue mapping other columns
                                });
                            }

                            // Next result set (BySymbol)
                            await reader.NextResultAsync();
                            var bySymbol = new List<TradingSymbolDto>();
                            while (await reader.ReadAsync())
                            {
                                bySymbol.Add(new TradingSymbolDto
                                {
                                    Symbol = reader.GetString(1),
                                    TotalTrades = reader.GetInt32(2),
                                    AvgProfitDay1 = reader.GetDecimal(6)
                                    // ...
                                });
                            }

                            // Next result set (ProfitDistribution)
                            await reader.NextResultAsync();
                            var distribution = new List<TradingProfitDistributionDto>();
                            while (await reader.ReadAsync())
                            {
                                distribution.Add(new TradingProfitDistributionDto
                                {
                                    Symbol = reader.GetString(1),
                                    ProfitRange = reader.GetString(2),
                                    Count = reader.GetInt32(3)
                                });
                            }

                            return new TradingSimulationsResult
                            {
                                Summary = summary,
                                BySymbol = bySymbol,
                                Distribution = distribution
                            };
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"PopulateStockTradesTradingSimulationsRowData: Error occurred - {ex.Message}", ex);
            }
            return null;
        }


        internal List<StocksProfitIndicatorDto> GetProfitIndicatorsBySymbolsRowData(
    string symbols,
    decimal minRatio,
    int minPositiveResults,
    string indicatorPrefix,
    List<string> days,
    decimal minDayPercentsValue,
    string prefix)
        {
            Logger.Info($"GetProfitIndicatorsBySymbolsRowData: Starting process to retrieve profit indicators. Parameters: Symbols='{symbols}', MinRatio={minRatio}, MinPositiveResults={minPositiveResults}, IndicatorPrefix='{indicatorPrefix}', Days='{string.Join(",", days ?? new List<string>())}'.");
            //var data = GetStockTradesTradingSimulationsInfo(symbols, null, null);

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    Logger.Info("GetProfitIndicatorsBySymbolsRowData: Executing stored procedure to retrieve profit indicator data.");

                    string daysParam = days != null && days.Any() ? string.Join(",", days) : null;

                    // Manually execute stored procedure using SqlQuery
                    var queryResult = context.Database.SqlQuery<GetProfitIndicatorsBySymbols_Result>(
                        "EXEC [History].[GetProfitIndicatorsBySymbols_common] @p0, @p1, @p2, @p3, @p4, @p5, @p6",
                        symbols,
                        minRatio,
                        minPositiveResults,
                        indicatorPrefix,
                        daysParam,
                        minDayPercentsValue,
                        prefix
                    ).ToList();

                    if (queryResult == null || !queryResult.Any())
                    {
                        Logger.Warn("GetProfitIndicatorsBySymbolsRowData: No profit indicator data found for the specified parameters.");
                        return new List<StocksProfitIndicatorDto>();
                    }

                    var dtoResult = StockTradesDtoConverter.ToProfitIndicatorsDto(queryResult);

                    Logger.Info($"GetProfitIndicatorsBySymbolsRowData: Successfully retrieved {dtoResult.Count} records.");
                    return dtoResult;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"GetProfitIndicatorsBySymbolsRowData: An error occurred while retrieving data. Exception: {ex.Message}", ex);
                return new List<StocksProfitIndicatorDto>();
            }
        }


        internal List<StockHistoryTradeDto> GetTradesBySymbolsAndDateRowData(string symbols, DateTime endDate, int numOfWeeks)
        {
            Logger.Info($"GetTradesBySymbolsAndDateRowData: Starting process to retrieve trade data. Parameters: Symbols='{symbols ?? "ALL"}', EndDate='{endDate.ToString("dd/MM/yyyy")}', RowNum={numOfWeeks}.");
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    Logger.Info("GetTradesBySymbolsAndDateRowData: Executing stored procedure to retrieve trade data.");

                    // Prepare the symbols parameter (null if not specified)
                    string symbolsParam = string.IsNullOrEmpty(symbols) ? null : symbols;

                    // Execute the stored procedure
                    var queryResult = context.GetTradesBySymbolsAndDate(symbolsParam, endDate, numOfWeeks, 1).ToList();

                    if (queryResult == null || !queryResult.Any())
                    {
                        Logger.Warn("GetTradesBySymbolsAndDateRowData: No trade data found for the specified parameters.");
                        return new List<StockHistoryTradeDto>();
                    }

                    var dtoResult = StockTradesDtoConverter.ToStockHistoryTradeDto(queryResult);


                    Logger.Info($"GetTradesBySymbolsAndDateRowData: Successfully retrieved {dtoResult.Count} trade records.");
                    return dtoResult;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"GetTradesBySymbolsAndDateRowData: Error occurred while retrieving data. Exception: {ex.Message}", ex);
                return new List<StockHistoryTradeDto>();
            }
        }

        internal Dictionary<string, StocksHistoryItemDto> GetStocksHistoryNewRowData(List<string> symbols, DateTime endDate, int NumOfRows)
        {
            var result = new Dictionary<string, StocksHistoryItemDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    IQueryable<StocksHistory> query = context.StocksHistories;


                    string symbolsParam = symbols == null || symbols.Count == 0 ? null : string.Join(",", symbols);

                    // Execute the stored procedure
                    var tradeResult = context.GetTradesBySymbolsAndDate(symbolsParam, endDate, NumOfRows, 1).ToList();
                    var indicatorsResult = context.GetTradesWithIndicators(symbolsParam, endDate, NumOfRows).ToList();


                    if (tradeResult == null || !tradeResult.Any())
                    {
                        Logger.Warn("GetTradesBySymbolsAndDateRowData: No trade data found for the specified parameters.");
                        return new Dictionary<string, StocksHistoryItemDto>();
                    }

                    var dtoResult = StockTradesDtoConverter.ToStockHistoryTradeDictionaryDto(symbols, tradeResult, indicatorsResult);

                    return dtoResult;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksHistory {0}", ex);
                throw;
            }

        }

        private static string GetYahooScriptsPath()
        {
            var path = ConfigurationManager.AppSettings["YahooScriptsPath"];
            if (!Directory.Exists(path))
            {
                path = ConfigurationManager.AppSettings["YahooScriptsPath2"];
            }
            if (!Directory.Exists(path))
            {
                path = ConfigurationManager.AppSettings["YahooScriptsPath3"];
            }
            return path;
        }

        internal void PopulateStockTradeSummaryTableRowData(DateTime minDate)
        {
            Logger.Info("Starting the process to populate stock trade summary table...");
            Logger.Warn("Warning: This process may take a long time to complete depending on the data size.");

            var stopwatch = Stopwatch.StartNew();
            var cancellationTokenSource = new CancellationTokenSource();

            // Start the background task that performs the actual DB work
            var task = Task.Run(() =>
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        context.Database.CommandTimeout = 7200; // 2 hours

                        string sectors = null;

                        Logger.Info($"Calling stored procedure with minDate: {minDate:yyyy-MM-dd}");

                        var tradeResult = context.Populate_StockTradeSummary_Batch(sectors, minDate,null, true,"").ToList();

                        if (tradeResult != null && tradeResult.Count > 0)
                        {
                            var result = tradeResult.First();
                            Logger.Info($"Stored procedure executed successfully. Rows inserted: {result.RowsInserted}, Status: {result.Status}");
                        }
                        else
                        {
                            Logger.Warn("Stored procedure executed, but returned no result.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("Error while populating stock trade summary table.", ex);
                    throw;
                }
            }, cancellationTokenSource.Token);

            // Start a monitoring task to log every 1 minute
            Task.Run(async () =>
            {
                int minutesPassed = 0;
                while (!task.IsCompleted && !task.IsFaulted && !task.IsCanceled)
                {
                    await Task.Delay(TimeSpan.FromMinutes(1), cancellationTokenSource.Token);
                    minutesPassed++;
                    Logger.Info($"Still processing... {minutesPassed} minute(s) elapsed.");
                    CommonHelper.Instance.SetSystemProcessStatus(eSystemProcess.TradesSummaryUpdate, $"PopulateStockTradeSummaryTable is running for {minutesPassed} minutes");
                }
            }, cancellationTokenSource.Token);

            try
            {
                // Wait for the main task to complete
                task.Wait();
            }
            catch (AggregateException ex)
            {
                Logger.Error("Exception occurred during task execution.", ex.Flatten());
                throw;
            }
            finally
            {
                stopwatch.Stop();
                cancellationTokenSource.Cancel(); // Stop the monitor task if still running
                Logger.Info($"Stock trade summary table population completed in {stopwatch.Elapsed.TotalMinutes:F2} minutes.");
                CommonHelper.Instance.SetSystemProcessStatus(eSystemProcess.TradesSummaryUpdate, $"PopulateStockTradeSummaryTable finished");
            }
        }

        internal void PopulateStockTradeSummaryBySymbolGroupTableRowData(DateTime minDate)
        {
            Logger.Info("Starting the process to populate stock trade summary table by SymbolGroup...");
            Logger.Warn("Warning: This process may take a long time to complete depending on the data size.");

            var stopwatch = Stopwatch.StartNew();
            var cancellationTokenSource = new CancellationTokenSource();

            // Start the background task that performs the actual DB work
            var task = Task.Run(() =>
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        context.Database.CommandTimeout = 7200; // 2 hours

                        Logger.Info($"Calling stored procedure Populate_StockTradeSummaryByGroup_Batch with minDate: {minDate:yyyy-MM-dd}");

                        var tradeResult = context.Populate_StockTradeSummaryByGroup_Batch(
                            minDate,
                            null,
                            true // Truncate existing data before insert
                        ).ToList();

                        if (tradeResult != null && tradeResult.Count > 0)
                        {
                            var result = tradeResult.First();
                            Logger.Info($"Stored procedure executed successfully. Rows inserted: {result.RowsInserted}, Status: {result.Status}");
                        }
                        else
                        {
                            Logger.Warn("Stored procedure executed, but returned no result.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("Error while populating stock trade summary table.", ex);
                    throw;
                }
            }, cancellationTokenSource.Token);

            // Start a monitoring task to log every 1 minute
            Task.Run(async () =>
            {
                int minutesPassed = 0;
                while (!task.IsCompleted && !task.IsFaulted && !task.IsCanceled)
                {
                    await Task.Delay(TimeSpan.FromMinutes(1), cancellationTokenSource.Token);
                    minutesPassed++;
                    Logger.Info($"Still processing... {minutesPassed} minute(s) elapsed.");
                    CommonHelper.Instance.SetSystemProcessStatus(eSystemProcess.TradesSummaryUpdate, $"PopulateStockTradeSummaryBySymbolGroupTable is running for {minutesPassed} minutes");
                }
            }, cancellationTokenSource.Token);

            try
            {
                task.Wait(); // Wait for main task to complete
            }
            catch (AggregateException ex)
            {
                Logger.Error("Exception occurred during task execution.", ex.Flatten());
                throw;
            }
            finally
            {
                stopwatch.Stop();
                cancellationTokenSource.Cancel(); // Stop the monitor task if still running
                Logger.Info($"Stock trade summary table population completed in {stopwatch.Elapsed.TotalMinutes:F2} minutes.");
                CommonHelper.Instance.SetSystemProcessStatus(eSystemProcess.TradesSummaryUpdate, $"PopulateStockTradeSummaryBySymbolGroupTable finished");
            }
        }


        internal List<CurrentStockTradesDatesDto> GetCurrentStockTradesDatesRowData2(List<string> symbols)
        {
            var results = new List<CurrentStockTradesDatesDto>();
            const int chunkSize = 50;

            try
            {
                for (int i = 0; i < symbols.Count; i += chunkSize)
                {
                    var chunk = symbols.Skip(i).Take(chunkSize).ToList();
                    var symbolList = string.Join(",", chunk);

                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        // Set command timeout to 5 minutes
                        context.Database.CommandTimeout = 30;

                        // Execute the stored procedure for the current chunk
                        var tradeResult = context.GetFirstAndLastTradeDate(symbolList);

                        // Map and accumulate results
                        var chunkResult = tradeResult.Select(trade => new CurrentStockTradesDatesDto
                        {
                            Symbol = trade.Symbol,
                            FirstTradeDate = trade.FirstTradeDate,
                            LastTradeDate = trade.LastTradeDate
                        });

                        results.AddRange(chunkResult);

                        // Optional: log progress
                        // Logger.InfoF("Processed chunk {0}-{1}", i + 1, i + chunk.Count);
                    }
                }

                return results;
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetCurrentStockTradesDatesRowData error: {0}", ex);
                throw;
            }
        }

        internal List<CurrentStockTradesDatesDto> GetCurrentStockTradesDatesRowData(List<string> symbols)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Set command timeout to 5 minutes (300 seconds)
                    context.Database.CommandTimeout = 300;

                    // Create a comma-separated string of symbols
                    var symbolList = string.Join(",", symbols);

                    // Execute the stored procedure
                    var tradeResult = context.GetFirstAndLastTradeDate(symbolList);

                    // Map the result to a DTO
                    var result = tradeResult.Select(trade => new CurrentStockTradesDatesDto
                    {
                        Symbol = trade.Symbol,
                        FirstTradeDate = trade.FirstTradeDate,
                        LastTradeDate = trade.LastTradeDate
                    }).ToList();

                    return result;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetCurrentStockTradesDatesRowData {0}", ex);
                throw;
            }
        }
        internal DailyStocksQuotesDto GetDailyStocksQuotesRowData(List<string> symbols, bool includeEmptyIndicators)
        {
            Logger.Info("GetDailyStocksQuotesRowData: Starting process to retrieve stock trades.");
            var totalStopwatch = Stopwatch.StartNew();
            var symbolSummaries = new List<Common.Dto.DailyStocksQuotesSummaryDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.CommandTimeout = 600;

                    IQueryable<StockTrade> query = context.StockTrades.AsQueryable();

                    // Apply indicator filtering
                    if (!includeEmptyIndicators)
                    {
                        query = query.Where(x => x.IndicatorsJson != null && x.IndicatorsJson != "{}");
                    }

                    // Apply symbol filtering
                    if (symbols != null && symbols.Count > 0)
                    {
                        string stockCsv = string.Join(",", symbols);
                        Logger.Info($"Filtering for symbols: {stockCsv}");
                        query = query.Where(x => symbols.Contains(x.Symbol));
                    }

                    var dbCallStopwatch = Stopwatch.StartNew();
                    var data = query.ToList();
                    dbCallStopwatch.Stop();

                    Logger.Info($"Database query completed in {dbCallStopwatch.ElapsedMilliseconds} ms. Records returned: {data.Count}");

                    if (data == null || !data.Any())
                    {
                        Logger.Warn("GetDailyStocksQuotesRowData: No stock trade data found.");
                        return new DailyStocksQuotesDto(new Dictionary<string, List<DailyStockQuotesDto>>(), symbolSummaries);
                    }

                    var dtoConversionStopwatch = Stopwatch.StartNew();
                    var dtoResult = StockTradesDtoConverter.ToDailyStockQuotesDto(data);
                    dtoConversionStopwatch.Stop();

                    Logger.Info($"DTO conversion completed in {dtoConversionStopwatch.ElapsedMilliseconds} ms.");

                    var groupedResult = new Dictionary<string, List<DailyStockQuotesDto>>();

                    foreach (var group in dtoResult.GroupBy(dto => dto.Symbol))
                    {
                        var symbol = group.Key;
                        var groupStopwatch = Stopwatch.StartNew();

                        var trades = group.ToList();
                        groupedResult[symbol] = trades;
                        int tradesWithIndicators = trades.Count(x => !string.IsNullOrWhiteSpace(x.IndicatorsJson) && x.IndicatorsJson != "{}");
                        int tradesWithoutIndicators = trades.Count - tradesWithIndicators;

                        var summary = new Common.Dto.DailyStocksQuotesSummaryDto
                        {
                            Symbol = symbol,
                            TradeCount = trades.Count,
                            EarliestTrade = trades.Min(t => t.TradeDate),
                            LatestTrade = trades.Max(t => t.TradeDate),
                            TradesWithIndicators = tradesWithIndicators,
                            TradesWithoutIndicators = tradesWithoutIndicators,
                            ProcessingTimeMs = groupStopwatch.ElapsedMilliseconds
                        };

                        groupStopwatch.Stop();
                        symbolSummaries.Add(summary);

                        Logger.Info(
                            $"Symbol {symbol}: {summary.TradeCount} trades, Range: {summary.EarliestTrade:dd/MM/yyyy} - {summary.LatestTrade:dd/MM/yyyy}, " +
                            $"With Indicators: {summary.TradesWithIndicators}, Without Indicators: {summary.TradesWithoutIndicators}, " +
                            $"Processed in {summary.ProcessingTimeMs} ms");
                    }

                    totalStopwatch.Stop();
                    Logger.Info($"GetDailyStocksQuotesRowData: Completed. Total time: {totalStopwatch.ElapsedMilliseconds} ms");

                    return new DailyStocksQuotesDto(groupedResult, symbolSummaries);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"GetDailyStocksQuotesRowData: An error occurred while retrieving data. Exception: {ex.Message}", ex);
                return new DailyStocksQuotesDto(new Dictionary<string, List<DailyStockQuotesDto>>(), symbolSummaries);
            }
        }





    }

    internal class TradingSimulationsResult
    {
        public List<TradingSummaryDto> Summary { get; set; }
        public List<TradingSymbolDto> BySymbol { get; set; }
        public List<TradingProfitDistributionDto> Distribution { get; set; }
    }

    internal class TradingProfitDistributionDto
    {
        public string Symbol { get; internal set; }
        public string ProfitRange { get; internal set; }
        public int Count { get; internal set; }
    }

    internal class TradingSymbolDto
    {
        public decimal AvgProfitDay1 { get; internal set; }
        public int TotalTrades { get; internal set; }
        public string Symbol { get; internal set; }
    }

    internal class TradingSummaryDto
    {
        public string ResultType { get; internal set; }
        public string Symbol { get; internal set; }
        public object NumberOfStocks { get; internal set; }
        public DateTime? TradeDateFrom { get; internal set; }
        public int TotalTrades { get; internal set; }
        public DateTime? TradeDateTo { get; internal set; }
        public decimal AvgProfitDay1 { get; internal set; }
    }
}