﻿using Stocks.Common.Log;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    public abstract class BaseWrapper
    {
        protected IStocksLogger Logger = null;

        protected GenericRepository<TEntity> GetRepository<TEntity>() where TEntity : class
        {
            return new GenericRepository<TEntity>();
        }
    }
}