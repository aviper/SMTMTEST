﻿using Stock.Common.Dto;
using Stock.Common.Enums;
using Stock.Common.Logger;
using Stock.Dal.DBModel;
using System;
using System.Linq;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class ScrapperWrapper : BaseWrapper
    {
        private DbDal _parent;

        public ScrapperWrapper(DbDal parent)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            this._parent = parent;
        }

        internal void AddFinvizScannersDataRowData(string code, FinvizScannersDataDto finvizScannersDataDto)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Code == code);
                    if (data == null)
                    {
                        var newData = new SourceScrapperData();
                        newData.Id = Guid.NewGuid();
                        newData.Code = code;
                        newData.Data = finvizScannersDataDto.ToString();
                        newData.Created = DateTime.Now.NowOrDefault();

                        context.SourceScrapperDatas.Add(newData);
                    }
                    else
                    {
                        data.Data = finvizScannersDataDto.ToString();
                        data.Created = DateTime.Now.NowOrDefault();
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddFinvizScannersDataRowData {0}", ex);
                throw;
            }
        }

        internal void AddGoogleTrendInfoRowData(GoogleTrendDataDto googleTrendData)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Code == ProcessHistoryCodeEnum.EIdentifier.GoogleTrends.ToString());
                    if (data == null)
                    {
                        var newData = new SourceScrapperData();
                        newData.Id = Guid.NewGuid();
                        newData.Code = ProcessHistoryCodeEnum.EIdentifier.GoogleTrends.ToString();
                        newData.Data = googleTrendData.ToString();
                        newData.Created = DateTime.Now.NowOrDefault();

                        context.SourceScrapperDatas.Add(newData);
                    }
                    else
                    {
                        data.Data = googleTrendData.ToString();
                        data.Created = DateTime.Now.NowOrDefault();
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddGoogleTrendInfoRowData {0}", ex);
                throw;
            }
        }

        internal FinvizScannersDataDto GetFinvizScannersDataRowData(string code)
        {
            FinvizScannersDataDto result = new FinvizScannersDataDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Code == code);
                    if (data != null)
                    {
                        result = FinvizScannersDataDto.FromStringSafe(data.Data);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetFinvizScannersDataRowData {0}", ex);
                throw;
            }
            return result;
        }

        internal GoogleTrendDataDto GetGoogleTrendInfoRowData()
        {
            GoogleTrendDataDto result = new GoogleTrendDataDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Code == ProcessHistoryCodeEnum.EIdentifier.GoogleTrends.ToString());
                    if (data != null)
                    {
                        result = GoogleTrendDataDto.FromStringSafe(data.Data);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetGoogleTrendInfoRowData {0}", ex);
                throw;
            }
            return result;
        }

        internal void SavePremarketScannerMetaDataRowData(HistoryTopStocksDto currentCandidateStocksToTrade)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Code == ProcessHistoryCodeEnum.EIdentifier.PremarketStockScanner.ToString());
                    if (data == null)
                    {
                        var newData = new SourceScrapperData();
                        newData.Id = Guid.NewGuid();
                        newData.Code = ProcessHistoryCodeEnum.EIdentifier.PremarketStockScanner.ToString();
                        newData.Data = currentCandidateStocksToTrade.ToString();
                        newData.Created = DateTime.Now.NowOrDefault();

                        context.SourceScrapperDatas.Add(newData);
                    }
                    else
                    {
                        data.Data = currentCandidateStocksToTrade.ToString();
                        data.Created = DateTime.Now.NowOrDefault();
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SavePremarketScannerMetaDataRowData {0}", ex);
                throw;
            }
        }

        internal HistoryTopStocksDto GetPremarketScannerMetaDataRowData()
        {
            HistoryTopStocksDto result = new HistoryTopStocksDto();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var theDate = DateTime.Now.NowOrDefault().Date;
                    var data = context.SourceScrapperDatas.FirstOrDefault(x => x.Created > theDate && x.Code == ProcessHistoryCodeEnum.EIdentifier.PremarketStockScanner.ToString());
                    if (data != null)
                    {
                        result = HistoryTopStocksDto.FromStringSafe(data.Data);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetPremarketScannerMetaDataRowData {0}", ex);
                throw;
            }

            return result;
        }
    }
}