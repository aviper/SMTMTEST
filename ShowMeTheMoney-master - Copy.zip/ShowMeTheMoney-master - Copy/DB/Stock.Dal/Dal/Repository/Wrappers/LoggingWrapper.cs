﻿using Stock.Common.Dto.Login;
using Stock.Common.Enums;
using Stock.Common.Logger;
using Stock.Dal.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class LoggingWrapper : BaseWrapper
    {
        private DbDal _parent;

        public LoggingWrapper(DbDal parent)
        {
            this._parent = parent;
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
        }

        public LoginResult LoginRowData(LoginParamsDto loginParams)
        {
            var result = new LoginResult();
            try
            {
                if (loginParams.UserName.ToLower() == "a")
                {
                    result.Success = true;
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var userData = context.Users.Include(("Actions")).FirstOrDefault(x => x.Enable && !x.IsDeleted && x.UserName.ToLower() == loginParams.UserName.ToLower() && x.Password == loginParams.Password);
                    if (userData != null)
                    {
                        var loginAction = userData.Actions.FirstOrDefault(x => x.Code == "LOGIN");
                        if (loginAction != null)
                        {
                            result.Success = !loginAction.Deleted;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("LoginRowData {0}", ex);
            }
            return result;
        }

        internal List<UsersActionDto> GetUsersActionRowData(UserActionEnum.EIdentifier action)
        {
            var result = new List<UsersActionDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.GetUsersAction(action.ToString()).ToList();
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Add(new UsersActionDto() { Email = item.Email, Name = item.RealName, Title = item.Title });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetUsersActionRowData {0}", ex);

                throw;
            }
            return result;
        }
    }
}