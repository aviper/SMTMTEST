﻿using Newtonsoft.Json;
using Stock.Common;
using Stock.Common.Dto;
using Stock.Common.Dto.MarketsData;
using Stock.Common.Dto.Trading;
using Stock.Common.Enums;
using Stock.Common.Helpers;
using Stock.Common.Indicators;
using Stock.Common.Indicators.Params;
using Stock.Common.Logger;
using Stock.Common.Settings;
using Stock.Common.Strategy;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using static Stock.Common.Dto.AnalysisHistoryDto;
using static Stock.Common.Dto.StocksDto;
using static Stock.Common.Dto.Trading.NasdaqStocksDto;

//using static Stock.Common.Dto.Trading.StrategiesStocksDataDto;
using static Stock.Common.Dto.Trading.StrategiesStocksHistoryDataDto;
using static Stock.Common.Enums.Enums;
using static System.Data.Entity.Infrastructure.Design.Executor;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class StocksWrapper : BaseWrapper
    {
        //private readonly DbCachedDataContainer _cache;
        public List<StockProfile> StockInfo = StockInfoSingleton.Instance.StockInfo;



        public StocksWrapper(DbDal parent)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            this._parent = parent;
            //_cache = Singleton<DbCachedDataContainer>.Instance();
        }
        internal void ReloadStockProfileDataRowData()
        {
            StockInfoSingleton.Instance.ReloadStockProfileData();
        }


        private DbDal _parent;


        #region "Simulation"

        internal AnalysisHistoryDto GetSimulationResults(DateTime fromDate, DateTime toDate)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SimulationResults.Where(x => x.Id != null && x.Date > fromDate && x.Date < toDate);

                    if (data != null && data.Any())
                    {
                        foreach (var item in data)
                        {
                            result.History.Add(SimulationResultsConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetSimulationResults {0}", ex);
                throw;
            }
            return result;
        }

        internal void AddSimulationResults(List<AnalysisHistoryItemDto> items)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (AnalysisHistoryItemDto item in items)
                    {
                        var newItem = SimulationResultsConverter.FromDto(item);

                        if (item.Id != Guid.Empty)
                        {
                            newItem.Id = item.Id;
                        }
                        else
                        {
                            newItem.Id = Guid.NewGuid();
                        }

                        context.SimulationResults.Add(newItem);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddSimulationResults {0}", ex);
                throw;
            }
        }

        internal void ClearSimulationResults()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.ExecuteSqlCommand("TRUNCATE TABLE stocks.SimulationResults");
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.ExecuteSqlCommand("TRUNCATE TABLE Trading.TradesSimulation");
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("ClearSimulationResults {0}", ex);
                throw;
            }
        }

        internal void AddSimulationResultsForScreener(List<AnalysisHistoryItemDto> items)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (AnalysisHistoryItemDto item in items)
                    {
                        var newItem = SimulationResultsConverter.ScreenerDataFromDto(item);

                        if (item.Id != Guid.Empty)
                        {
                            newItem.Id = item.Id;
                        }
                        else
                        {
                            newItem.Id = Guid.NewGuid();
                        }

                        context.SimulationResultsDatas.Add(newItem);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddSimulationResultsForScreener {0}", ex);
                throw;
            }
        }

        internal void ClearSimulationResultsForScreener()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.ExecuteSqlCommand("TRUNCATE TABLE stocks.SimulationResultsData");
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.ExecuteSqlCommand("TRUNCATE TABLE Trading.TradesSimulation");
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("ClearSimulationResultsForScreener {0}", ex);
                throw;
            }
        }

        internal void UpdateSimulationResultsRanks(int[] ranksMinValues)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SimulationResults.ToList();

                    foreach (SimulationResult item in data)
                    {
                        int rank = 0;

                        for (int i = 0; i < ranksMinValues.Length; i++)
                        {
                            if (item.Score > ranksMinValues[i])
                            {
                                rank = i + 1;
                                break;
                            }
                        }

                        if (rank == 0)
                        {
                            rank = ranksMinValues.Length + 1;
                        }

                        if (item.Rank != rank)
                        {
                            item.Rank = rank;
                        }
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateSimulationResultsRanks {0}", ex);
                throw;
            }
        }

        #endregion "Simulation"

        #region "Sectors"

        internal List<SectorDataDto> GetSectorsData()
        {
            List<SectorDataDto> result = new List<SectorDataDto>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.SectorsDatas.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Add(SectorDataConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetSectorsData {0}", ex);

                throw;
            }
            return result;
        }

        internal void SaveSectorsData(List<SectorDataDto> sectors)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    foreach (SectorDataDto item in sectors)
                    {
                        var sector = context.SectorsDatas.FirstOrDefault(x => x.SectorNames.StartsWith(item.SectorNames));

                        if (sector == null)
                        {
                            sector = new SectorsData();
                            sector.Id = Guid.NewGuid();
                            sector.SectorNames = item.SectorNames;
                            context.SectorsDatas.Add(sector);
                        }

                        SectorHistoricalData data = null;
                        if (string.IsNullOrWhiteSpace(sector.HistoricalData))
                        {
                            data = new SectorHistoricalData();
                        }
                        else
                        {
                            data = SectorHistoricalData.FromString(sector.HistoricalData);
                        }

                        data.Items.AddRange(item.HistoricalData.Items);
                        sector.HistoricalData = data.ToString();
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddSimulationResults {0}", ex);
                throw;
            }
        }

        #endregion "Sectors"

        internal StockProfile GetStockProfile(string symbol)
        {
            return StockInfo.FirstOrDefault(x => x.Symbol.ToLower() == symbol.ToLower());
        }

        internal string GetSymbolByCompanyName(string companyName)
        {
            companyName = companyName.ToLower();
            var stockProfile = StockInfo.FirstOrDefault(
                x => x.CompanyName != null &&
                    (x.CompanyName.ToLower() == companyName ||
                     x.CompanyName.ToLower().Replace("inc", "").Trim(',', '.', ' ') == companyName ||
                     x.CompanyName.ToLower().Replace("limited", "").Trim(',', '.', ' ') == companyName
                     ));

            if (stockProfile != null)
            {
                return stockProfile.Symbol.ToUpper();
            }

            return string.Empty;
        }

        internal StocksDto GetStocksRowData()
        {
            StocksDto result = new StocksDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.Stocks.Include("WatchList").Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Stocks.Add(StocksConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal CurrentStocksWatchListDto GetCurrentStocksWatchListData()
        {
            CurrentStocksWatchListDto result = new CurrentStocksWatchListDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.CurrentStocksWatchLists.Where(x => x.Symbol != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Items.Add(new CurrentStocksWatchListItemDto() { Id = item.Id, Symbol = item.Symbol, Name = item.Name, PlaceInList = item.PlaceInList, SourceType = item.SourceType, Weight = item.Weight });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryItemDto GetStockHistoryDataRowData(Guid historyId)
        {
            AnalysisHistoryItemDto result = new AnalysisHistoryItemDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var obj = context.Histories.FirstOrDefault(x => x.Id == historyId);
                    if (obj != null)
                    {
                        result = AnalysisHistoryConverter.ToDto(obj);
                        if (!string.IsNullOrEmpty(obj.Source))
                        {
                            result.CurrentStocksListSources = obj.Source.Split(',');
                        }
                        result.StocksListSourcesCount = context.StocksListSources.Count(x => x.Id != null && x.Enable == true);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStockHistoryDataRowData {0}", ex);

                throw;
            }
            return result;
        }


        internal List<StockProfileWithAlertsDto> GetStockProfileWithAlertsViewRowData(bool onlyRelevant = true)
        {
            var result = new List<StockProfileWithAlertsDto>();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    IQueryable<StockProfileWithAlertsView> query = context.StockProfileWithAlertsViews;


                    var list = query.ToList();

                    if (!list.Any())
                    {
                        Logger.InfoF("GetStockProfileWithAlertsViewRowData completed: No records found.");
                        return result;
                    }

                    result = list.Select(StockHistoryConverter.ToStockProfileWithAlertsViewsDto).ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStockProfileWithAlertsViewRowData encountered an error: {0}", ex);
                throw;
            }

            return result;
        }


        /// <summary>
        /// Updates stock history records in the database using new stock profile information.
        /// Only updates entries where sector, industry, or company name are known (not UNKNOWN).
        /// </summary>
        /// <param name="pendingStockInfo">List of stock profiles to use for updating database records.</param>
        internal void RefreshStockInfoRowData(List<StockProfile> pendingStockInfo)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var fixItems = pendingStockInfo
                        .Where(x =>
                            x.Sector != ShowMeTheMoneySettings.UNKNOWN ||
                            x.Industry != ShowMeTheMoneySettings.UNKNOWN ||
                            x.CompanyName != ShowMeTheMoneySettings.UNKNOWN)
                        .ToList();

                    if (fixItems.Count == 0)
                    {
                        Logger.InfoF("RefreshStockInfoRowData completed: Nothing to update.");
                        return;
                    }

                    var symbolsToUpdate = fixItems.Select(x => x.Symbol).Distinct().ToList();

                    var dbItemsInfo = context.StocksHistories
                        .Where(x => symbolsToUpdate.Contains(x.Symbol))
                        .ToList();

                    foreach (var dbItem in dbItemsInfo)
                    {
                        var fixItem = fixItems.FirstOrDefault(x => x.Symbol.ToLower() == dbItem.Symbol.ToLower());
                        if (fixItem == null)
                            continue;

                        StockHistoryConverter.ApplyProfileToStockHistory(fixItem, dbItem);
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("RefreshStockInfoRowData encountered an error: {0}", ex);
                throw;
            }
        }



        //internal List<StockProfile> GetStockInfoToRefreshRowData()
        //{
        //    List<StockProfile> result = new List<StockProfile>();
        //    try
        //    {
        //        using (var context = new DBEntities(DbConnectionString.ConnectionString))
        //        {
        //            DateTime fromDate = DateTime.Now.NowOrDefault().AddDays(-1);
        //            var objs = context.StockInfoViews.Where(x => x.IsValid !=false);

        //            //var objs = context.StockInfoes.Where(x => x.Created >= fromDate && (x.Sector == ShowMeTheMoneySettings.UNKNOWN || x.Industry == ShowMeTheMoneySettings.UNKNOWN || x.CompanyName == ShowMeTheMoneySettings.UNKNOWN));//Ask 6 days
        //            if (objs.Any())
        //            {
        //                result.AddRange(objs.Select(item => StockHistoryConverter.ToStockProfileDto(item)));
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.ErrorF("GetStockInfoToRefreshRowData {0}", ex);

        //        throw;
        //    }
        //    return result;
        //}



        internal bool ResetStockInfoToRefreshRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Count affected rows beforehand
                    var count = context.StocksHistories.Count(x => x.IsValid == false);
                    Logger.InfoF("Before Reset %d invalid stock records", count);


                    if (count == 0)
                        return false;

                    // Execute stored procedure
                    context.ResetStockInfoToRefresh();
                    count = context.StocksHistories.Count(x => x.IsValid == false);
                    Logger.InfoF("After Reset %d invalid stock records", count);

                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("ResetStockInfoToRefreshRowData failed: {0}", ex);
                throw;
            }
        }


        internal List<StockProfile> GetStockInfoToRefreshRowData()
        {
            List<StockProfile> result = new List<StockProfile>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    DateTime fromDate = DateTime.Now.NowOrDefault().AddDays(-1);
                    var objs = context.StockInfoViews.Where(x => x.IsValid != false);

                    if (objs.Any())
                    {
                        var list = objs.ToList();  // <-- Materialize the query here
                        result.AddRange(list.Select(item => StockHistoryConverter.ToStockProfileDto(item)));  // now run conversion in memory
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStockInfoToRefreshRowData {0}", ex);
                throw;
            }
            return result;
        }


        internal StocsHistoryDto GetStocsHistoryRowData(DateTime fromDate, DateTime toDate, double minScore)
        {
            StocsHistoryDto result = new StocsHistoryDto();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.Histories.Where(x => x.Date >= fromDate && x.Date <= toDate && x.Score > minScore);

                    if (objs.Any())
                    {
                        result.History = new List<AnalysisHistoryItemDto>();
                        foreach (var item in objs)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocsHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryDto GetSimulationResultsDataRowData(DateTime fromDate, DateTime toDate)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.SimulationResultsDatas.Where(x => x.Id != null && x.Date > fromDate && x.Date < toDate);

                    if (data != null && data.Any())
                    {
                        foreach (var item in data)
                        {
                            result.History.Add(SimulationResultsConverter.ScreenerDataToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SimulationResultsDatas {0}", ex);
                throw;
            }
            return result;
        }

        internal WatchListMedaDataSto GetWatchListMedaData()
        {
            WatchListMedaDataSto result = new WatchListMedaDataSto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.WatchLists.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            try
                            {
                                WatchListDto list = WathcListConverter.ToDto(item);
                                result.WatchList.Add(list);
                            }
                            catch (Exception ex)
                            {
                                Logger.FatalF("GetWatchListMedaData StocksListSources not found", ex);
                                throw;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetWatchListMedaData {0}", ex);

                throw;
            }
            return result;
        }

        internal StocksOverviewDto GetStocksOverviewData(string symbol, DateTime? fromDate, DateTime? toDate)
        {
            StocksOverviewDto result = new StocksOverviewDto();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var obj = context.GetStocksOverview(symbol, fromDate, toDate).FirstOrDefault();

                    if (obj != null)
                    {
                        result.CountHistoryUpTo500 = obj.CountHistoryUpTo500;
                        result.CountHistory500To700 = obj.CountHistory500To700;
                        result.CountHistory700To1000 = obj.CountHistory700To1000;
                        result.CountHistoryAbove1000 = obj.CountHistoryAbove1000;
                        result.CountErrors = obj.CountErrors;
                        result.SectorsData = obj.sSectorsData;
                        result.AlertHistory = obj.alertHistory;
                        result.AlertHistory = obj.alertHistory;
                        result.Stocks = obj.stocks;
                        result.countUsers = obj.countUsers;
                        result.StocksFilterd = obj.StocksFilterd;
                        result.StocksHistoryLastSync = obj.StocksHistoryLastSync;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksOverviewData {0}", ex);

                throw;
            }
            return result;
        }
        internal async Task<StocksHealthReport> GetStocksHealthReportRowDataAsync(DateTime lastTradeDate)
        {
            const int maxRetries = 2;
            var result = new StocksHealthReport();

            for (int attempt = 1; attempt <= maxRetries + 1; attempt++)
            {
                try
                {
                    result = await Task.Run(() =>
                    {
                        using (var context = new DBEntities(DbConnectionString.ConnectionString))
                        {
                            context.Database.CommandTimeout = 30;

                            var report = new StocksHealthReport();

                            var stocksHealthReport = context.StocksHealthReport(lastTradeDate).FirstOrDefault();
                            var stocksHealthReportBySector = context.StocksHealthReportBySector(lastTradeDate).ToList();

                            if (stocksHealthReport != null)
                            {
                                report.TotalStocks = stocksHealthReport.TotalStocks;
                                report.OutdatedStocks = stocksHealthReport.OutdatedStocks;
                                report.OutdatedStockPercentage = stocksHealthReport.OutdatedStockPercentage;
                                report.InvalidStocks = stocksHealthReport.InvalidStocks;
                                report.InvalidStockPercentage = stocksHealthReport.InvalidStockPercentage;
                                report.OldestFirstSample = stocksHealthReport.OldestFirstSample;
                                report.LatestLastSample = stocksHealthReport.LatestLastSample;
                                report.MissingSyncData = stocksHealthReport.MissingSyncData;
                                report.SyncGapStocks = stocksHealthReport.SyncGapStocks;
                                report.ActiveStocks = stocksHealthReport.ActiveStocks;
                                report.StaleStocks = stocksHealthReport.StaleStocks;
                                report.IntraDayQuotesCount = stocksHealthReport.IntraDayQuotesCount;
                                report.StockTradeSummaryCount = stocksHealthReport.StockTradeSummaryCount;
                                report.StockTradesCount = stocksHealthReport.StockTradesCount;
                            }

                            if (stocksHealthReportBySector.Any())
                            {
                                report.StocksHealthReportBySector = stocksHealthReportBySector.Select(item => new StocksHealthReportBySector
                                {
                                    Sector = item.Sector,
                                    TotalStocks = item.TotalStocks,
                                    OutdatedStocks = item.OutdatedStocks,
                                    InvalidStocks = item.InvalidStocks,
                                    MissingCompanyName = item.MissingCompanyName,
                                    Stocks_Age_LessThan1Year = item.Stocks_Age_LessThan1Year,
                                    Stocks_Age_1To5Years = item.Stocks_Age_1To5Years,
                                    Stocks_Age_MoreThan5Years = item.Stocks_Age_MoreThan5Years,
                                    ActiveStocks = item.ActiveStocks,
                                    MissingSampleData = item.MissingSampleData,
                                    SyncGapStocks = item.SyncGapStocks,
                                    SmallCap = item.SmallCap,
                                    MidCap = item.MidCap,
                                    LargeCap = item.LargeCap,
                                    MissingMarketCap = item.MissingMarketCap,
                                    MissingVolume = item.MissingVolume,
                                    MissingLastPrice = item.MissingLastPrice,
                                    Missing52WeekRange = item.Missing52WeekRange
                                }).ToList();
                            }

                            return report;
                        }
                    });

                    return result;
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("GetStocksHealthReportRowData attempt {0} failed: {1}", attempt, ex);

                    if (attempt == maxRetries + 1)
                        return new StocksHealthReport(); // Final fallback

                    await Task.Delay(1000); // Wait before retry
                }
            }

            return result;
        }


        internal AnalysisHistoryDto GetAnalysisHistoryRowData()
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.Histories.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAnalysisHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryDto GetAnalysisHistoryRowData(string symbol, DateTime fromDate, int maxItemsCount)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    List<History> objs;
                    if (symbol != string.Empty)
                    {
                        objs = context.Histories.Where(x => x.Id != null && x.Symbol == symbol && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                    }
                    else
                    {
                        objs = context.Histories.Where(x => x.Id != null && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                    }

                    if (objs != null && objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAnalysisHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryDto GetAnalysisHistoryRowData(string symbol, DateTime fromDate, int maxItemsCount, bool onlyDuringTrade)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    List<History> objs;
                    if (symbol != string.Empty)
                    {
                        if (onlyDuringTrade)
                        {
                            objs = context.Histories.Where(x => x.IsDuringTrade == true && x.Id != null && x.Symbol == symbol && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                        }
                        else
                        {
                            objs = context.Histories.Where(x => x.Id != null && x.Symbol == symbol && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                        }
                    }
                    else
                    {
                        if (onlyDuringTrade)
                        {
                            objs = context.Histories.Where(x => x.IsDuringTrade == true && x.Id != null && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                        }
                        else
                        {
                            objs = context.Histories.Where(x => x.Id != null && x.Date > fromDate).OrderByDescending(x => x.Date).Take(maxItemsCount).ToList();
                        }
                    }

                    if (objs != null && objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAnalysisHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryDto GetAnalysisHistoryRowData(DateTime fromDate, DateTime toDate)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.Histories.Where(x => x.Id != null && x.Date > fromDate && x.Date < toDate);

                    if (data != null && data.Any())
                    {
                        foreach (var item in data)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetAnalysisHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal AnalysisHistoryDto GetStockAnalysisHistory(string symbol, DateTime fromDate, DateTime toDate)
        {
            AnalysisHistoryDto result = new AnalysisHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.Histories.Where(x => x.Id != null && x.Symbol == symbol && x.Date > fromDate && x.Date < toDate);

                    if (data != null && data.Any())
                    {
                        foreach (var item in data)
                        {
                            result.History.Add(AnalysisHistoryConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStockAnalysisHistory {0}", ex);

                throw;
            }
            return result;
        }

        internal void UpdateStockDataRowData(StockDto stock)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var dbStock = context.Stocks.FirstOrDefault(x => x.Id == stock.Id);
                    if (dbStock != null)
                    {
                        dbStock.Data = stock.Data.ToString();
                        context.SaveChanges();
                        //Logger.Info("UpdateStockDataRowData");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateStockDataRowData {0}", ex);

                throw;
            }
        }

        internal PredefinedStocksDto GetPredefinedStocksRowData()
        {
            PredefinedStocksDto result = new PredefinedStocksDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.WishListStockViews.Where(x => !string.IsNullOrEmpty(x.Email));
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            if (result.Stocks.ContainsKey(item.Symbol))
                            {
                                result.Stocks[item.Symbol].AlertEmails.Add(new WishListDto(item.Name, item.Email, item.WatchListName, item.AlertAfterTrade, item.AlertBeforeTrade));
                            }
                            else
                            {
                                result.Stocks.Add(item.Symbol, AlertStocksConverter.ToDto(item));
                            }
                        }
                    }

                    var Emails = result.Stocks.Values.SelectMany(x => x.AlertEmails.Select(d => d)).Distinct().ToList();
                    result.AlertEmails = Emails;
                }
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.WishListDataViews.Where(x => x.Symbol != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            if (result.Stocks.ContainsKey(item.Symbol))
                            {
                                if (result.Stocks[item.Symbol].Data == null)
                                {
                                    result.Stocks[item.Symbol].Data = new WishListStockData();
                                }
                                result.Stocks[item.Symbol].Data.Score = item.Score;
                                result.Stocks[item.Symbol].Data.ScoreDate = item.Date;
                            }
                        }
                    }

                    var Emails = result.Stocks.Values.SelectMany(x => x.AlertEmails.Select(d => d)).Distinct().ToList();
                    result.AlertEmails = Emails;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetPredefinedStocksRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal void SetPendingStockInfoRowData(List<StockProfile> pendingStockInfo)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Load only relevant records from the DB once
                    var symbols = pendingStockInfo.Select(p => p.Symbol).Distinct().ToList();
                    var currentItems = context.StocksHistories
                        .Where(x => symbols.Contains(x.Symbol) &&
                                    (x.Sector == null || x.CompanyName == null))
                        .ToList();

                    foreach (var item in pendingStockInfo)
                    {
                        if (!string.IsNullOrEmpty(item.Sector))
                        {
                            var currentItem = currentItems.FirstOrDefault(x => x.Symbol.ToLower() == item.Symbol.ToLower());
                            if (currentItem != null)
                            {
                                StockHistoryConverter.ApplyProfileToStockHistory(item, currentItem);
                            }
                        }
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SetPendingStockInfoRowData encountered an error: {0}", ex);
                throw;
            }
        }


        internal List<StockProfile> GetPendingStockInfoData()
        {
            List<StockProfile> result = new List<StockProfile>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.StockInfoViews.Where(x => x.Industry == null || x.CompanyName == null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Add(StockHistoryConverter.ToStockProfileDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetPendingStockInfoData {0}", ex);

                throw;
            }
            return result;
        }

        internal List<string> GetStocksSymbols(bool onlyRelevant = true)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    if (onlyRelevant)
                    {
                        return context.StockInfoViews.Select(x => x.Symbol).ToList();
                    }
                    else
                    {
                        return context.StockInfoViews.Select(x => x.Symbol).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksSymbols {0}", ex);

                throw;
            }
        }

        internal List<StockProfile> GetStocksProfiles(bool onlyRelevant = true, bool OnlyValid = false)
        {
            try
            {
                List<StockProfile> result = null;
                if (onlyRelevant)
                {
                    result = StockInfo.ToList();
                }
                else
                {
                    result = StockInfo;
                }
                if (OnlyValid)
                {
                    result = result.Where(x => x.IsValid).ToList();
                }
                return result;
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStocksProfiles {0}", ex);
                throw;
            }
        }

        internal Guid AddToAnalysisHistoryRowData(AnalysisHistoryDto.AnalysisHistoryItemDto item)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var historyItem = AnalysisHistoryConverter.FromDto(item);
                    historyItem.Id = Guid.NewGuid();
                    context.Histories.Add(historyItem);
                    context.SaveChanges();

                    if (item.IsDuringTrade.HasValue && item.IsDuringTrade.Value)
                    {
                        MarketData marketData = new MarketData
                        {
                            Id = Guid.NewGuid(),
                            Symbol = item.Symbol,
                            Date = item.Date,
                            Price = item.Price,
                            Volume = item.Volume
                        };

                        if (item.Data.DataItems.ContainsKey("PriceChangePercentage"))
                        {
                            marketData.PriceChangePercentage = double.Parse(item.Data.DataItems["PriceChangePercentage"]);
                        }

                        if (item.Data.DataItems.ContainsKey("VolumeChangePercentage"))
                        {
                            marketData.VolumeChangePercentage = double.Parse(item.Data.DataItems["VolumeChangePercentage"]);
                        }

                        context.MarketDatas.Add(marketData);
                        context.SaveChanges();
                    }

                    return historyItem.Id;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("AddToAnalysisHistoryRowData {0}", ex);
                throw;
            }
        }

        // leaves up to 1 record per stock for every 1.5 hours (the one with the highest score)
        internal void DeleteRedundantAnalysisHistoryRecords(DateTime fromDate)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    List<History> allItems = context.Histories.Where(x => x.Id != null && x.Date > fromDate).ToList();
                    var distinctStocks = allItems.GroupBy(x => x.Symbol).Select(g => g.FirstOrDefault());
                    foreach (History stock in distinctStocks)
                    {
                        string symbol = stock.Symbol.Trim();
                        DateTime timeFrame = DateTime.Now.NowOrDefault();

                        while (timeFrame > fromDate)
                        {
                            // get stock history per hour
                            var frameItems = allItems.Where(x => x.Symbol.Trim() == symbol && x.Date < timeFrame && x.Date > timeFrame.AddHours(-2));
                            History highestScoreItem = frameItems.OrderByDescending(x => x.Score).FirstOrDefault();
                            if (highestScoreItem != null)
                            {
                                foreach (History item in frameItems)
                                {
                                    if (item.Id != highestScoreItem.Id && (item.Data == null || !item.Data.Contains("AlertSent:True")))
                                    {
                                        context.Histories.Remove(item);
                                    }
                                }
                            }

                            timeFrame = timeFrame.AddMinutes(-60);
                        }
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("DeleteRedundantAnalysisHistoryRecords {0}", ex);

                throw;
            }
        }

        internal StocksDto GetWatchListStocksRowData(Guid id)
        {
            Exception hasException = null;
            StocksDto result = new StocksDto();
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        var objs = context.Stocks.Include("WatchList").Where(x => x.WatchList.Id == id);
                        if (objs.Any())
                        {
                            foreach (var item in objs)
                            {
                                result.Stocks.Add(StocksConverter.ToDto(item));
                            }
                        }
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    hasException = ex;
                    Random rnd = new Random();
                    Thread.Sleep(rnd.Next(200, 500));
                    Logger.ErrorF("GetWatchListStocksRowData Fail Retry Again {0} of 5", i + 1);
                }
            }
            if (hasException != null)
            {
                Logger.ErrorF("GetWatchListStocksRowData {0}", hasException);

                throw hasException;
            }
            return result;

            ////----------------
            //StocksDto result = new StocksDto();
            //try
            //{
            //    using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //    {
            //        var objs = context.Stocks.Include("WatchList").Where(x => x.WatchList.Id == id);
            //        if (objs.Any())
            //        {
            //            foreach (var item in objs)
            //            {
            //                result.Stocks.Add(StocksConverter.ToDto(item));
            //            }

            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Logger.ErrorF("GetWatchListStocksRowData {0}", ex);

            //    throw;
            //}
            //return result;
        }

        internal StocksDto GetStockData(string symbol)
        {
            StocksDto result = new StocksDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.Stocks.Include("WatchList").Where(x => x.Symbol.ToLower() == symbol.ToLower());
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Stocks.Add(StocksConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetWatchListStocksRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal WatchListsDto GetWatchListsRowData(bool onlyEnabled, bool forAnalysis)
        {
            WatchListsDto result = new WatchListsDto();
            try
            {
                Dictionary<string, StocksListSource> sources = new Dictionary<string, StocksListSource>();
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var enabledSources = context.StocksListSources.Where(x => x.Id != null).ToList();
                    foreach (var source in enabledSources)
                    {
                        if (source.Enable || !onlyEnabled)
                        {
                            sources.Add(source.Name, source);
                        }
                    }
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.WatchLists.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            if (sources.ContainsKey(item.Name) && (!forAnalysis || sources[item.Name].EnableAnalysis))
                            {
                                WatchListDto list = WathcListConverter.ToDto(item);
                                var source = sources[item.Name];
                                list.Url = source.Url;
                                list.Weight = source.Weight;
                                list.InvestmentDays = source.InvestmentDays;
                                list.ScoreLimit = source.ScoreLimit;
                                list.PeakScore = source.PickScore;
                                list.ScoreForAppearance = source.ScoreForAppearance;
                                list.EnableAnalysis = source.EnableAnalysis;
                                result.WatchLists.Add(list);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetWatchListsRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal void SaveStockDataRowData(ParseResultData data, StocksDataSource source)
        {
            try
            {
                List<ParseResultItem> items;
                if (source.SourceType == SourceTypes.StocksList)
                {
                    items = data.ListItems.Values.ToList();
                }
                else
                {
                    items = data.DataItems;
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var watchList = context.WatchLists.FirstOrDefault(x => x.Name == source.Name);
                    if (watchList == null)
                    {
                        context.WatchLists.Add(new WatchList() { Id = Guid.NewGuid(), Name = source.Name, SourceType = (int)source.SourceType, Weight = source.Weight, logChanges = source.LogChanges });
                        context.SaveChanges();
                        watchList = context.WatchLists.FirstOrDefault(x => x.Name == source.Name);
                    }
                    else
                    {
                        watchList.Name = source.Name;
                        watchList.SourceType = (int)source.SourceType;
                        watchList.Weight = source.Weight;
                        watchList.logChanges = source.LogChanges;
                        context.SaveChanges();
                    }

                    var dbItems = context.Stocks.Include("WatchList").Where(x => x.WatchList.Name == source.Name).ToList();

                    int lastPlaceInList = 0;

                    if (items.Count > 0)
                    {
                        lastPlaceInList = items.Last().PlaceInList;
                    }

                    foreach (var item in items)
                    {
                        //var added = string.Format("@Added by {0} on {1}", source.Name, DateTime.Now.NowOrDefault());
                        var tableItem = dbItems.FirstOrDefault(x => x.Symbol.ToLower() == item.Symbol.ToLower());
                        StocksDto.StockData stockData = new StocksDto.StockData();

                        if (tableItem != null)
                        {
                            stockData = StocksDto.StockData.FromString(tableItem.Data);
                        }

                        string title = string.Empty;
                        string path = string.Empty;
                        if (item.Links != null)
                        {
                            path = item.Links.ToString();
                            if (item.Links.Links.Count > 0)
                            {
                                title = item.Links.Links[0].Title;
                            }
                        }

                        if (tableItem == null)
                        {
                            if (!string.IsNullOrWhiteSpace(item.Symbol))
                            {
                                stockData.StockDataItems.Add(new StocksDto.StockDataItem() { Date = DateTime.Now.NowOrDefault(), PlaceInList = item.PlaceInList, LastPlaceInList = lastPlaceInList, Details = title });//, Comment = added
                                context.Stocks.Add(new DBModel.Stock() { Symbol = item.Symbol, Data = stockData.ToString(), Id = Guid.NewGuid(), Added = DateTime.Now.NowOrDefault(), Modified = DateTime.Now.NowOrDefault(), WatchListId = watchList.Id, PlaceInList = item.PlaceInList, InWatchList = true, Path = path });
                            }
                        }
                        else if (tableItem.InWatchList == false)
                        {
                            tableItem.InWatchList = true;
                            tableItem.Path = path;
                            tableItem.Modified = DateTime.Now.NowOrDefault();
                            stockData.StockDataItems.Add(new StocksDto.StockDataItem() { Date = DateTime.Now.NowOrDefault(), PlaceInList = item.PlaceInList, LastPlaceInList = lastPlaceInList, Details = title });//, Comment = added
                            tableItem.Data = stockData.ToString();// tableItem.Data + Environment.NewLine + added;
                            tableItem.PlaceInList = item.PlaceInList;
                        }
                        else if (tableItem.PlaceInList != item.PlaceInList)
                        {
                            //string change = string.Format("@place in list changed from {0} to {1}", tableItem.PlaceInList, item.PlaceInList);
                            stockData.StockDataItems.Add(new StocksDto.StockDataItem() { Date = DateTime.Now.NowOrDefault(), PlaceInList = item.PlaceInList, LastPlaceInList = lastPlaceInList, Details = title });//Comment = change,

                            tableItem.Data = stockData.ToString();// tableItem.Data + Environment.NewLine + added;
                            tableItem.PlaceInList = item.PlaceInList;
                            tableItem.Path = path;
                            tableItem.Modified = DateTime.Now.NowOrDefault();
                        }
                        else
                        {
                            tableItem.Modified = DateTime.Now.NowOrDefault();
                            tableItem.Path = path;
                        }
                    }
                    context.SaveChanges();

                    //update removed from each list
                    dbItems = context.Stocks.Include("WatchList").Where(x => x.WatchList.Name == source.Name).ToList();
                    foreach (var item in dbItems)
                    {
                        if (item.InWatchList)
                        {
                            var removedItem = items.FirstOrDefault(x => x.Symbol.ToLower() == item.Symbol.ToLower());
                            var removed = string.Format("@Removed by {0} on {1}", source.Name, DateTime.Now.NowOrDefault());
                            StocksDto.StockData stockData = StocksDto.StockData.FromString(item.Data);

                            if (removedItem == null) // db item not in current list
                            {
                                stockData.StockDataItems.Add(new StocksDto.StockDataItem() { Date = DateTime.Now.NowOrDefault(), PlaceInList = 0, LastPlaceInList = lastPlaceInList });//Comment = removed,

                                item.Data = stockData.ToString();// item.Data + Environment.NewLine + removed;
                                item.Modified = DateTime.Now.NowOrDefault();
                                item.InWatchList = false;
                                item.PlaceInList = 0;
                            }
                        }
                    }

                    context.SaveChanges();

                    //var objs = context.Stocks.Where(x => x.Id != null);
                    //if (objs.Any())
                    //{
                    //    var obj = objs.First();

                    //    result.Symbol = obj.Symbol;

                    //}
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStockDataRowData {0}", ex);

                throw;
            }
        }

        internal void DeleteOldStockDataRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    DateTime deleteBefore = DateTime.Now.NowOrDefault().AddDays(-100);

                    List<DBModel.Stock> dbStocks = context.Stocks.Where(x => x.Id != null).ToList();

                    foreach (DBModel.Stock dbStock in dbStocks)
                    {
                        StockDto stock = StocksConverter.ToDto(dbStock);

                        int originalDataItemsCount = stock.Data.StockDataItems.Count;
                        stock.Data.StockDataItems.RemoveAll(x => x.Date < deleteBefore);

                        if (stock.Data.StockDataItems.Count < originalDataItemsCount)
                        {
                            if (stock.Data.StockDataItems.Count > 0)
                            {
                                dbStock.Data = stock.Data.ToString();
                            }
                            else
                            {
                                context.Stocks.Remove(dbStock);
                            }

                            context.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("DeleteOldStockData {0}", ex);

                throw;
            }
        }

        internal MarketDataDto GetMarketDataRowData(MarketDataGetParams getParams)
        {
            MarketDataDto result = new MarketDataDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.GetMarketData(getParams.Symbol, getParams.FromDate, getParams.ToDate).ToList();
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            result.Items.Add(MarketDataConverter.ToDto(item));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetMarketDataRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal void DoCustomJob()
        {
            //try
            //{
            //    List<SectorDataDto> sectors = new List<SectorDataDto>();
            //    using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //    {
            //        var objs = context.SectorsDatas.Where(x => x.Id != null);
            //        if (objs.Any())
            //        {
            //            foreach (var dbSector in objs)
            //            {
            //                SectorDataDto sector = SectorDataConverter.ToDto(dbSector);
            //                SectorHistoricalData newData = new SectorHistoricalData();

            //                foreach (SectorHistoricalDataItem dataItem in sector.HistoricalData.Items)
            //                {
            //                    if (StockCommon.IsInRegularMarket(dataItem.Date))
            //                    {
            //                        newData.Items.Add(dataItem);
            //                    }
            //                }

            //                dbSector.HistoricalData = newData.ToString();
            //            }

            //            context.SaveChanges();
            //        }
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Logger.ErrorF("GetSectorsData {0}", ex);

            //    throw;
            //}

            //try
            //{
            //ClearSimulationResults();

            //Dictionary<string, int> sources = new Dictionary<string, int>();
            //using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //{
            //    var enabledSources = context.StocksListSources.Where(x => x.Id != null && x.Enable == true && x.EnableAnalysis == true).ToList();
            //    foreach (var source in enabledSources)
            //    {
            //        sources.Add(source.Name, 0);
            //    }
            //}

            //List<string> symbols = null;
            //using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //{
            //    symbols = context.Histories.GroupBy(x => x.Symbol).Select(x => x.Key).ToList();
            //}

            //using (var context = new DBEntities(DbConnectionString.ConnectionString))
            //{
            //    foreach (string symbol in symbols)
            //    {
            //        foreach (string source in sources.Keys.ToList())
            //        {
            //            sources[source] = 0;
            //        }

            //        DateTime fromDate = new DateTime(2021, 1, 10);
            //        DateTime toDate = new DateTime(2021, 2, 6);
            //        var alerts = context.Histories.Where(x => x.Symbol == symbol && x.Date > fromDate).OrderBy(x => x.Date);

            //        List<History> alertsRange = new List<History>();
            //        //double scoresSum = 0;
            //        //int scoresCount = 0;

            //        foreach (History alert in alerts)
            //        {
            //            bool valid = true;
            //            string[] alertSources = alert.Source.Split(',');
            //            foreach (string source in alertSources)
            //            {
            //                if (source != "Volume change" && source != "Price change" && source != "Sector performance" && !sources.ContainsKey(source))
            //                {
            //                    valid = false;
            //                }
            //            }

            //            if (valid)
            //            {
            //                alertsRange.Add(alert);

            //                foreach (string source in alertSources)
            //                {
            //                    if (sources.ContainsKey(source))
            //                    {
            //                        sources[source]++;
            //                    }
            //                }

            //                //scoresSum += alert.Score;
            //                //scoresCount++;

            //                if (alert.IsDuringTrade.HasValue && alert.IsDuringTrade.Value)
            //                {
            //                    while (alertsRange.First().Date.AddHours(72) < alert.Date)
            //                    {
            //                        //scoresSum -= alertsRange.First().Score;
            //                        //scoresCount--;

            //                        History alertToRemove = alertsRange[0];
            //                        alertSources = alertToRemove.Source.Split(',');
            //                        foreach (string source in alertSources)
            //                        {
            //                            if (sources.ContainsKey(source))
            //                            {
            //                                sources[source]--;
            //                            }
            //                        }

            //                        alertsRange.RemoveAt(0);
            //                    }

            //                    //double newScore = scoresSum / scoresCount;
            //                    //newScore = (newScore + alert.Score) / 2;

            //                    //scoresSum = 0;
            //                    //scoresCount = 0;
            //                    //foreach (History item in alertsRange)
            //                    //{
            //                    //    if (item.Date.AddHours(24) < alert.Date)
            //                    //    {
            //                    //        scoresSum += item.Score;
            //                    //        scoresCount += 1;
            //                    //    }
            //                    //    else if (item.Date < alert.Date)
            //                    //    {
            //                    //        scoresSum += item.Score * 2;
            //                    //        scoresCount += 2;
            //                    //    }
            //                    //}

            //                    //scoresSum += alert.Score * 5;
            //                    //scoresCount += 5;
            //                    //double newScore = scoresSum / scoresCount;

            //                    //int highAlertsCount = alertsRange.Count(x => x.Score > 200);
            //                    //double newScore = alert.Score + ((alert.Score * (highAlertsCount - 1)) / 10);

            //                    double newScore = alert.Score;

            //                    int sourcesCount = sources.Where(x => x.Value > 0).Count();
            //                    if (sourcesCount >= 4)
            //                    {
            //                        newScore += (alert.Score * Math.Pow((sourcesCount - 1), 2)) / 20;
            //                    }

            //                    newScore = Math.Round(newScore);

            //                    var newAlert = new SimulationResult();
            //                    newAlert.Id = Guid.NewGuid();
            //                    newAlert.Score = newScore;
            //                    newAlert.Date = alert.Date;
            //                    newAlert.Symbol = alert.Symbol.Trim();
            //                    newAlert.Price = alert.Price;
            //                    newAlert.Source = alert.Source;
            //                    newAlert.Data = "{DataItems:{}}";
            //                    newAlert.IsDuringTrade = alert.IsDuringTrade;
            //                    context.SimulationResults.Add(newAlert);
            //                }
            //            }
            //        }

            //        context.SaveChanges();
            //    }
            //}
            //}
            //catch (Exception ex)
            //{
            //    Logger.ErrorF("AddSimulationResults {0}", ex);
            //    throw;
            //}
        }

        internal HistoryTopStocksDto GetHistoryTopStocksRowData(bool? duringTrade, int numberOfDays)
        {
            HistoryTopStocksDto result = new HistoryTopStocksDto();

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var data = context.GetHistoryTopStocks(numberOfDays, duringTrade).ToList();

                    if (data.Any())
                    {
                        result.Stocks = data.Select(x => x.Trim()).ToList();
                        foreach (var item in result.Stocks)
                        {
                            var historyData = GetAnalysisHistoryRowData(item, DateTime.Now.NowOrDefault().Date.AddDays(-1), 1); //last history
                            if (historyData != null && historyData.History != null && historyData.History.Count > 0)
                                result.History.Add(historyData.History[0]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetHistoryTopStocks {0}", ex);

                throw;
            }
            return result;
        }

        internal void InitNasdaqStocksDataRowData(NasdaqStocksDto nasdaqStocksData, bool delete)
        {

            try
            {
                Logger.Info("InitStrategiesStocksDataRowData: Starting initialization.");

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    if (delete)
                    {
                        Logger.Info("InitStrategiesStocksDataRowData: Deleting existing data from Strategies and Stocks tables.");

                        // Delete existing data from strategies-related tables
                        context.Database.ExecuteSqlCommand("DELETE FROM [Stocks].[NasdaqStocks]");
                        context.SaveChanges();
                        Logger.Info("InitStrategiesStocksDataRowData: Existing data deleted.");
                    }

                    Logger.Info("InitStrategiesStocksDataRowData: Preparing to insert new stock data.");
                    nasdaqStocksData.StocksData = nasdaqStocksData.StocksData.OrderByDescending(x => x.MarketCap).ToList();
                    UpdateNasdaqStocksStocksTable(nasdaqStocksData);
                    var currentStocksSymbols = _parent.GetStocksProfiles(false, false).ToList();

                    var data = currentStocksSymbols.Select(x => x.Symbol.ToLower());
                    var dataCount = data.Count();
                    //var strategiesStocksDataSymbols = strategiesStocksData.StocksData.Select(x => x.Symbol.ToLower()).ToList();
                    var newSymbolsToAdd = nasdaqStocksData.StocksData.Where(x => !data.Contains(x.Symbol.ToLower())).ToList();
                    //var oldSymbolsToRemove = currentStocksSymbols.Except(strategiesStocksDataSymbols).ToList();


                    if (newSymbolsToAdd.Any())
                    {
                        var data2 = new ConcurrentBag<StocksHistoryItemDto>();

                        // Prepare stock history data
                        foreach (var stockData in newSymbolsToAdd)
                        {
                            if (stockData.MarketCap == 0)
                            {
                                stockData.MarketCap = -1;
                            }
                            var stockHistoryItem = new StocksHistoryItemDto
                            {
                                Symbol = stockData.Symbol,
                                IndexSymbol = stockData.IndexSymbol,
                                EtfSymbol = stockData.EtfSymbol,
                                SymbolGroup = stockData.SymbolGroup,
                                Data = new StocksHistoryDataItemDataDto
                                {
                                    History = null
                                },
                                Updated = DateTime.MinValue,
                                LastSync = DateTime.MinValue,
                                Created = DateTime.MinValue,
                                FirstSample = DateTime.MinValue,
                                LastSample = DateTime.MinValue,
                                Sector = stockData.Sector,
                                LastMarketCap = stockData.MarketCap,
                                CompanyName = stockData.Name,
                                LastPrice = -1
                            };

                            data2.Add(stockHistoryItem);
                        }

                        Logger.Info("InitStrategiesStocksDataRowData: Updating stocks history data.");
                        _parent.SetStocksHistory(data2.ToList());
                        Logger.Info("InitStrategiesStocksDataRowData: Stocks history data updated.");
                    }


                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("InitStrategiesStocksDataRowData: An error occurred. {0}", ex);
                //throw;
            }
        }

        private bool UpdateNasdaqStocksStocksTable(NasdaqStocksDto nasdaqStocksOrig)
        {
            try
            {
                var nasdaqStocks = nasdaqStocksOrig;
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Get all existing symbols in the database for quick lookup to avoid duplicates
                    var existingDbSymbols = new HashSet<string>(
                        context.NasdaqStocks.Select(s => s.Symbol),
                        StringComparer.OrdinalIgnoreCase);

                    // Get existing symbols already in the data object to avoid adding duplicates there as well
                    var existingSymbols = new HashSet<string>(
                        nasdaqStocks.StocksData.Select(x => x.Symbol),
                        StringComparer.OrdinalIgnoreCase);

                    // Helper local method to add new symbol only if not in existing symbols and DB
                    void TryAddSymbol(IEnumerable<string> symbols, string sector, string industry)
                    {
                        foreach (var symbol in symbols)
                        {
                            if (!existingSymbols.Contains(symbol) && !existingDbSymbols.Contains(symbol))
                            {
                                nasdaqStocks.StocksData.Add(new NasdaqStockData(symbol)
                                {
                                    Sector = sector,
                                    Industry = industry,
                                    MarketCap = -1
                                });
                                existingSymbols.Add(symbol); // add to avoid duplicates within this run
                            }
                        }
                    }
                    //nasdaqStocks.StocksData = nasdaqStocks.StocksData.Take(100).ToList();
                    // Add indexes and ETFs
                    TryAddSymbol(StockCommon.GetMarketIndexesSymbols(), "INDEX", "INDEX");
                    TryAddSymbol(ETFCommon.GetETFsSymbols(), "ETF", "ETF");
                    TryAddSymbol(ETFCommon.GetPopularEtfSymbols(), "ETF", "ETF");
                    TryAddSymbol(ETFCommon.GetCommonEtfSymbols(), "ETF", "ETF");

                    // Sort by MarketCap descending
                    nasdaqStocks.StocksData = nasdaqStocks.StocksData
                        .OrderByDescending(x => x.MarketCap)
                        .ToList();

                    var batchList = new List<NasdaqStock>();
                    const int batchSize = 100;

                    foreach (var stockData in nasdaqStocks.StocksData)
                    {
                        try
                        {
                            if (string.IsNullOrWhiteSpace(stockData.Symbol))
                            {
                                Logger.Warn("UpdateNasdaqStocksStocksTable: Skipping stock with empty symbol.");
                                continue;
                            }

                            // Double check symbol is not in DB (avoid race conditions)
                            if (existingDbSymbols.Contains(stockData.Symbol))
                            {
                                Logger.Info($"UpdateNasdaqStocksStocksTable: Symbol {stockData.Symbol} already exists in DB, skipping.");
                                continue;
                            }

                            var name = !string.IsNullOrWhiteSpace(stockData.Name) ? stockData.Name : stockData.Symbol;
                            if (stockData.MarketCap == 0)
                            {
                                stockData.MarketCap = -1;
                            }
                            var data = new NasdaqStock
                            {
                                Id = Guid.NewGuid(),
                                Symbol = stockData.Symbol,
                                Name = name.Length > 50 ? name.Substring(0, 50) : name,
                                MarketCap = stockData.MarketCap,
                                Sector = stockData.Sector,
                                Industry = stockData.Industry,
                                Exchange = stockData.Exchange?.ToString() ?? string.Empty,
                                Added = DateTime.Now.NowOrDefault().Date,
                                Modified = DateTime.Now.NowOrDefault().Date,
                                Country = stockData.Country,
                                IPOYear = stockData.IPOYear,
                                Data = GZip.CompressString(JsonConvert.SerializeObject(stockData))
                            };

                            batchList.Add(data);
                            existingDbSymbols.Add(stockData.Symbol); // mark as added to DB to avoid duplicates in same run

                            if (batchList.Count >= batchSize)
                            {
                                context.NasdaqStocks.AddRange(batchList);
                                context.SaveChanges();
                                Logger.Info($"UpdateNasdaqStocksStocksTable: Inserted batch of {batchList.Count} stocks.");
                                batchList.Clear();
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"UpdateNasdaqStocksStocksTable: Error processing symbol {stockData.Symbol} - {ex.Message}");
                        }
                    }

                    if (batchList.Count > 0)
                    {
                        context.NasdaqStocks.AddRange(batchList);
                        context.SaveChanges();
                        Logger.Info($"UpdateNasdaqStocksStocksTable: Inserted final batch of {batchList.Count} stocks.");
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("UpdateNasdaqStocksStocksTable: An error occurred. {0}", ex);
                return false;
            }
        }

        public List<StaticStockDataSto> GetStaticDataRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Base query
                    var query = context.NasdaqStocks;


                    // Convert EF DTO to StrategiesStockData DTO
                    var stockDataList = query.ToList()
                        .GroupBy(stock => stock.Symbol)
                        .Select(group => group.First())
                        .Select(stock => new StaticStockDataSto()
                        {
                            Id = stock.Id,
                            Symbol = stock.Symbol,
                            CompanyName = stock.Name,

                            Sector = stock.Sector,
                            Industry = stock.Industry,
                        });

                    return stockDataList.ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetSymbolsToScan {0}", ex);
                throw;
            }

        }


        public List<NasdaqStockData> GetNasdaqStocksDataRowData(ExchangeEnum exchange, List<SectorEnum> sectors, long minMarketCap)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Base query
                    var query = context.NasdaqStocks.AsQueryable();

                    // Filter by exchange
                    if (exchange != ExchangeEnum.All)
                    {
                        string exchangeString = exchange.ToString();
                        query = query.Where(stock => stock.Exchange.Equals(exchangeString, StringComparison.OrdinalIgnoreCase));
                    }

                    // Filter by sectors
                    if (sectors != null && sectors.Any())
                    {
                        var sectorStrings = sectors.Select(s => s.ToString()).ToList();
                        query = query.Where(stock => sectorStrings.Contains(stock.Sector));
                    }

                    // Filter by market cap
                    query = query.Where(stock => stock.MarketCap >= minMarketCap);

                    // Convert EF DTO to StrategiesStockData DTO
                    var stockDataList = query.ToList()
                        .GroupBy(stock => stock.Symbol)
                        .Select(group => group.First())
                        .Select(stock => new NasdaqStockData(stock.Symbol)
                        {
                            Id = stock.Id,
                            Name = stock.Name.Length > 50 ? stock.Name.Substring(0, 50) : stock.Name,
                            Volume = stock.Volume.GetValueOrDefault(0),
                            Country = stock.Country,
                            IPOYear = stock.IPOYear,
                            Sector = stock.Sector,
                            Industry = stock.Industry,
                            Exchange = stock.Exchange,
                            MarketCap = stock.MarketCap
                        });

                    return stockDataList.ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetSymbolsToScan {0}", ex);
                throw;
            }
        }

        private int SaveStrategiesStocksHistoryDataRowDataCount = 0;

        public async Task SaveStrategiesStocksHistoryDataRowDataAsync(StrategyScanModeEnum.EIdentifier code, string message, StrategiesStocksHistoryDataDto data, double? totalScore)
        {
            try
            {
                SaveStrategiesStocksHistoryDataRowDataCount++;
                var today = DateTime.Now.NowOrDefault().Date;

                var newHistories = new List<StrategiesStocksHistory>();

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var symbols = data.StocksHistoryData.Select(h => h.Value.SymbolData.Symbol.ToLower()).ToList();
                    var existingHistories = await context.StrategiesStocksHistories
                                                         .Where(h => symbols.Contains(h.Symbol.ToLower()) && DbFunctions.TruncateTime(h.Added) == today)
                                                         .ToDictionaryAsync(h => h.Symbol);

                    foreach (var history in data.StocksHistoryData)
                    {
                        if (existingHistories.TryGetValue(history.Value.SymbolData.Symbol, out var existingHistory))
                        {
                            existingHistory.ScanCode = history.Value.ScanCode;
                            existingHistory = UpdateHistory(existingHistory, history.Value, code);
                            existingHistory.Updated = DateTime.Now.NowOrDefault();
                            existingHistory.TotalScore = totalScore;
                            if (!string.IsNullOrEmpty(message))
                            {
                                existingHistory.Message = message;
                            }
                        }
                        else
                        {
                            var stockHistory = new StrategiesStocksHistory
                            {
                                Id = Guid.NewGuid(),
                                StrategyId = history.Value.StrategyId,
                                Symbol = history.Value.SymbolData.Symbol,
                                StrategiesStockId = history.Value.SymbolData.Id,
                                ScanCode = history.Value.ScanCode,
                                PostMarketScore = history.Value.PostMarketScore,
                                PreMarketScore = history.Value.PreMarketScore,
                                PostMarketValidateData = history.Value.PostMarketValidateData,

                                RegularMarketScore = history.Value.RegularMarketScore,
                                RegularMarketValidateData = history.Value.RegularMarketValidateData,

                                SentimentalData = history.Value.SentimentalData,
                                SentimentalScore = history.Value.SentimentalScore,
                                TradeSimulationData = history.Value.TradeSimulationData,
                                TradeSimulationScore = history.Value.TradeSimulationScore,
                                PostMarketScanDate = history.Value.PostMarketScanDate,
                                PreMarketScanDate = history.Value.PreMarketScanDate,
                                RegularMarketScanDate = history.Value.RegularMarketScanDate,
                                PreMarketValidateData = history.Value.PreMarketValidateData,

                                TotalScore = totalScore,
                                Message = message,
                                Added = DateTime.Now.NowOrDefault(),
                                Updated = DateTime.Now.NowOrDefault()
                            };
                            stockHistory = UpdateHistory(stockHistory, history.Value, code);
                            newHistories.Add(stockHistory);
                        }
                    }

                    if (newHistories.Any())
                    {
                        context.StrategiesStocksHistories.AddRange(newHistories);
                    }

                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStrategiesStocksHistoryData {0}", ex);
            }
        }

        //public void SaveStrategiesStocksHistoryDataRowData(StrategyScanModeEnum.EIdentifier code, StrategiesStocksHistoryDataDto data, double? totalScore)
        //{
        //    try
        //    {
        //        SaveStrategiesStocksHistoryDataRowDataCount++;
        //        using (var context = new DBEntities(DbConnectionString.ConnectionString))
        //        {
        //            foreach (var history in data.StocksHistoryData)
        //            {
        //                var today = DateTime.Now.NowOrDefault().Date;

        //                // Filter directly in the database query
        //                var existingHistory = context.StrategiesStocksHistories
        //                                   .FirstOrDefault(h => h.Symbol == history.Value.SymbolData.Symbol
        //                                                        && DbFunctions.TruncateTime(h.Added) == today);

        //                if (existingHistory != null)
        //                {
        //                    existingHistory.ScanCode = history.Value.ScanCode;
        //                    existingHistory = UpdateHistory(existingHistory, history.Value, code);
        //                    existingHistory.Updated = DateTime.Now.NowOrDefault();
        //                    existingHistory.TotalScore = totalScore;
        //                }
        //                else
        //                {
        //                    var stockHistory = new StrategiesStocksHistory
        //                    {
        //                        Id = Guid.NewGuid(),
        //                        StrategyId = history.Value.StrategyId,
        //                        Symbol = history.Value.SymbolData.Symbol,
        //                        StrategiesStockId = history.Value.SymbolData.Id,
        //                        ScanCode = history.Value.ScanCode,
        //                        PostMarketScore = history.Value.PostMarketScore,
        //                        PreMarketScore = history.Value.PreMarketScore,
        //                        RegularMarketScore = history.Value.RegularMarketScore,
        //                        SentimentalData = history.Value.SentimentalData,
        //                        SentimentalScore = history.Value.SentimentalScore,
        //                        TradeSimulationData = history.Value.TradeSimulationData,
        //                        TradeSimulationScore = history.Value.TradeSimulationScore,
        //                        PostMarketScanDate = history.Value.PostMarketScanDate,
        //                        PreMarketScanDate = history.Value.PreMarketScanDate,
        //                        RegularMarketScanDate = history.Value.RegularMarketScanDate,
        //                        TotalScore = totalScore,
        //                        Added = DateTime.Now.NowOrDefault(),
        //                        Updated = DateTime.Now.NowOrDefault()
        //                    };
        //                    stockHistory = UpdateHistory(stockHistory, history.Value, code);
        //                    context.StrategiesStocksHistories.Add(stockHistory);
        //                }
        //            }
        //            context.SaveChanges();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.ErrorF("SaveStrategiesStocksHistoryData {0}", ex);
        //    }
        //}

        private StrategiesStocksHistory UpdateHistory(StrategiesStocksHistory history, StrategiesStockHistoryDto value, StrategyScanModeEnum.EIdentifier code)
        {
            if (code == StrategyScanModeEnum.EIdentifier.PostMarket)
            {
                history.PostMarketScore = value.PostMarketScore;
                history.PostMarketData = value.PostMarket?.ToString();
                if (value.PostMarketHistoryStatistics != null)
                {
                    history.PostMarketHistoryStatisticsData = value.PostMarketHistoryStatistics.ToStringBase();
                }

                history.PostMarketGeneratedStrategyData = value.PostMarketGeneratedStrategy?.ToString();
                history.PostMarketValidateData = value.PostMarketValidateData;

                history.PostMarketScanDate = DateTime.Now.NowOrDefault();
            }
            else if (code == StrategyScanModeEnum.EIdentifier.PreMarket)
            {
                history.PreMarketScore = value.PreMarketScore;
                history.PreMarketData = value.PreMarket?.ToString();
                if (value.PreMarketHistoryStatistics != null)
                {
                    history.PreMarketHistoryStatisticsData = value.PreMarketHistoryStatistics.ToStringBase();
                }

                history.PreMarketGeneratedStrategyData = value.PreMarketGeneratedStrategy?.ToString();
                history.PreMarketDataUseOnlineData = value.PreMarketDataUseOnlineData;
                history.PreMarketValidateData = value.PreMarketValidateData;

                history.PreMarketScanDate = DateTime.Now.NowOrDefault();
            }
            else if (code == StrategyScanModeEnum.EIdentifier.RegularMarket)
            {
                history.RegularMarketScore = value.RegularMarketScore;
                history.RegularMarketData = value.RegularMarket?.ToString();
                if (value.RegularMarketHistoryStatistics != null)
                {
                    history.RegularMarketHistoryStatisticsData = value.RegularMarketHistoryStatistics.ToStringBase();
                }
                history.RegularMarketGeneratedStrategyData = value.RegularMarketGeneratedStrategy?.ToString();
                history.RegularMarketValidateData = value.RegularMarketValidateData;

                history.RegularMarketScanDate = DateTime.Now.NowOrDefault();
            }
            else if (code == StrategyScanModeEnum.EIdentifier.RegularMarketKeepBecausePreviousBestScore)
            {
                history.RegularMarketScore = value.RegularMarketScore;
                history.TotalScore = value.RegularMarketScore;
            }
            {
            }
            return history;
        }

        private int GetStrategiesStocksHistoryDataRowDataCount = 0;

        public async Task<StrategiesStocksHistoryDataDto> GetStrategiesStocksHistoryDataRowDataAsync(List<string> symbols, DateTime date)
        {
            try
            {
                GetStrategiesStocksHistoryDataRowDataCount++;
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Check if the symbols list is empty
                    List<StrategiesStocksHistory> histories;

                    // Check if the symbols list is empty
                    if (!symbols.Any())
                    {
                        histories = await context.StrategiesStocksHistories
                            .Where(x => DbFunctions.TruncateTime(x.Added) == DbFunctions.TruncateTime(date))
                            .ToListAsync();
                    }
                    else
                    {
                        histories = await context.StrategiesStocksHistories
                            .Where(x => symbols.Contains(x.Symbol) && DbFunctions.TruncateTime(x.Added) == DbFunctions.TruncateTime(date))
                            .ToListAsync();
                    }

                    return MapHistoriesToDto(histories);
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetStrategiesStocksHistoryData {0}", ex);
                throw;
            }
        }

        private StrategiesStocksHistoryDataDto MapHistoriesToDto(List<StrategiesStocksHistory> histories)
        {
            var result = new StrategiesStocksHistoryDataDto();

            foreach (var history in histories)
            {
                var symbolData = new StockProfile(history.Symbol)
                {
                    Id = history.StrategiesStockId
                };

                var data = new StrategiesStockHistoryDto
                {
                    // Basic Information
                    SymbolData = symbolData,
                    StrategyId = history.StrategyId,
                    ScanCode = history.ScanCode,

                    // Pre-Market Data
                    PreMarketScore = history.PreMarketScore,
                    PreMarketScanDate = history.PreMarketScanDate,
                    PreMarketHistoryStatistics = !string.IsNullOrEmpty(history.PreMarketHistoryStatisticsData)
                        ? TradesResultBase.FromString(history.PreMarketHistoryStatisticsData)
                        : null,
                    PreMarketGeneratedStrategy = !string.IsNullOrEmpty(history.PreMarketGeneratedStrategyData)
                        ? StrategyItemNewDto.FromString(history.PreMarketGeneratedStrategyData)
                        : null,
                    PreMarket = !string.IsNullOrEmpty(history.PreMarketData)
                        ? PremarketDataDto.FromString(history.PreMarketData)
                        : null,

                    // Regular Market Data
                    RegularMarketScore = history.RegularMarketScore,
                    RegularMarketScanDate = history.RegularMarketScanDate,
                    RegularMarketHistoryStatistics = !string.IsNullOrEmpty(history.RegularMarketHistoryStatisticsData)
                        ? TradesResultBase.FromString(history.RegularMarketHistoryStatisticsData)
                        : null,
                    RegularMarketGeneratedStrategy = !string.IsNullOrEmpty(history.RegularMarketGeneratedStrategyData)
                        ? StrategyItemNewDto.FromString(history.RegularMarketGeneratedStrategyData)
                        : null,
                    RegularMarket = !string.IsNullOrEmpty(history.RegularMarketData)
                        ? StockDataDtoBasic.FromString(history.RegularMarketData)
                        : null,

                    // Post-Market Data
                    PostMarketScore = history.PostMarketScore,
                    PostMarketScanDate = history.PostMarketScanDate,
                    PostMarketHistoryStatistics = !string.IsNullOrEmpty(history.PostMarketHistoryStatisticsData)
                        ? TradesResultBase.FromString(history.PostMarketHistoryStatisticsData)
                        : null,
                    PostMarketGeneratedStrategy = !string.IsNullOrEmpty(history.PostMarketGeneratedStrategyData)
                        ? StrategyItemNewDto.FromString(history.PostMarketGeneratedStrategyData)
                        : null,
                    PostMarket = !string.IsNullOrEmpty(history.PostMarketData)
                        ? StockDataDtoBasic.FromString(history.PostMarketData)
                        : null,

                    // Sentimental Data
                    SentimentalData = history.SentimentalData,
                    SentimentalScore = history.SentimentalScore,

                    // Trade Simulation Data
                    TradeSimulationResults = history.TradeSimulationData,
                    TradeSimulationScore = history.TradeSimulationScore,

                    TotalScore = history.TotalScore
                };

                if (!result.StocksHistoryData.ContainsKey(history.Symbol))
                {
                    result.StocksHistoryData.Add(history.Symbol, data);
                }
            }

            return result;
        }

        internal void CleanTodayStrategiesStocksHistoryData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var today = DateTime.Now.NowOrDefault().Date;
                    var histories = context.StrategiesStocksHistories
                                           .Where(x => DbFunctions.TruncateTime(x.Added) == today)
                                           .ToList();

                    if (histories != null && histories.Any())
                    {
                        context.StrategiesStocksHistories.RemoveRange(histories);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("CleanTodayStrategiesStocksHistoryData {0}", ex);
                throw;
            }
        }
        internal async Task<List<string>> LoadStrategyModelNamesDataRowAsync(List<string> symbols)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Perform asynchronous database query
                    var models = await context.StrategiesStocksModels
                        .Where(x => symbols.Contains(x.Symbol)).Select(y => y.Symbol)
                        .ToListAsync();
                    return models;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("LoadStrategyModelDataRowDataAsync {0}", ex);
                throw;
            }
        }

        internal async Task<List<StrategiesStocksModelDto>> LoadStrategyModelDataRowDataAsync(List<string> symbols)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Perform asynchronous database query
                    var models = await context.StrategiesStocksModels
                        .Where(x => symbols.Contains(x.Symbol))
                        .ToListAsync(); // Ensure you are using Entity Framework Core or similar that supports ToListAsync

                    // Map the results to DTOs
                    return models.Select(m => new StrategiesStocksModelDto
                    {
                        Symbol = m.Symbol,
                        ModelData = TradeSettings.FromString(m.ModelData),
                        TopScoreSignalStatistics = DaySignalStatisticList.FromString(m.TopScoreSignalStatistics),
                        AllDaySignalStatistics = DaySignalStatisticList.FromString(m.AllDaySignalStatistics),


                        StrategyId = m.StrategyId,
                        Score = m.Score,
                        Added = m.Added,
                        Updated = m.Updated,
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("LoadStrategyModelDataRowDataAsync {0}", ex);
                throw;
            }
        }

        internal async Task<StrategiesStocksModelDto> SaveStrategyModelDataRowDataAsync(StrategiesStocksModelDto data)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var existingModel = await context.StrategiesStocksModels
                        .FirstOrDefaultAsync(x => x.Symbol.ToLower() == data.Symbol.ToLower());

                    //var strategiesStockId = await context.NasdaqStocks
                    //    .Where(x => x.Symbol == data.Symbol)
                    //    .Select(x => x.Id)
                    //    .FirstOrDefaultAsync();

                    if (existingModel == null)
                    {
                        // If no existing model is found, create a new one
                        existingModel = new StrategiesStocksModel
                        {
                            Id = Guid.NewGuid(),
                            //StrategiesStockId = strategiesStockId,
                            Symbol = data.Symbol,
                            StrategyId = data.StrategyId,
                            ModelData = data.ModelData.ToString(),
                            TopScoreSignalStatistics = data.TopScoreSignalStatistics.ToString(),
                            AllDaySignalStatistics = data.AllDaySignalStatistics.ToString(),

                            Score = data.Score,
                            Added = DateTime.Now.NowOrDefault(),
                            Updated = DateTime.Now.NowOrDefault()
                        };

                        context.StrategiesStocksModels.Add(existingModel);
                    }
                    else
                    {
                        // If an existing model is found, update its properties
                        existingModel.Symbol = data.Symbol;
                        existingModel.StrategyId = data.StrategyId;
                        existingModel.ModelData = data.ModelData.ToString();
                        existingModel.Score = data.Score;
                        existingModel.Updated = DateTime.Now.NowOrDefault();
                    }

                    await context.SaveChangesAsync();
                }

                return data;
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SaveStrategyModelDataRowDataAsync {0}", ex);
                throw;
            }
        }

        internal void DeleteAllStrategiesHistoryDataRowData()
        {
            //delete from StrategiesStocksHistory and TradesIndicatorsAlert
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Bulk delete StrategiesStocksHistories
                    context.Database.ExecuteSqlCommand("DELETE FROM [Strategies].[StrategiesStocksHistory]");

                    // Bulk delete TradesIndicatorsAlerts
                    context.Database.ExecuteSqlCommand("DELETE FROM [Trading].[TradesIndicatorsAlert]");
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("DeleteAllStrategiesHistoryDataRowData {0}", ex);
                throw;
            }
        }


        internal async Task SetIntraDayQuotesRowDataAsync(Dictionary<string, IntraDayQuotesSetDto> data)
        {
            try
            {
                if (data == null || data.Count == 0)
                    return;

                var marketStateEnum = data.First().Value.MarketState;

                string marketState;
                switch (marketStateEnum)
                {
                    case MarketStateEnum.EIdentifier.PreMarket:
                        marketState = "PreMarket";
                        break;
                    case MarketStateEnum.EIdentifier.PostMarket:
                        marketState = "PostMarket";
                        break;
                    default:
                        marketState = "RegularMarket";
                        break;
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var symbols = data.Select(d => d.Key).ToList();

                    // Remove existing entries
                    var existingQuotes = context.IntraDayQuotes
                        .Where(x => symbols.Contains(x.Symbol.ToLower()) && x.MarketState == marketState)
                        .ToList();

                    if (existingQuotes.Any())
                    {
                        context.IntraDayQuotes.RemoveRange(existingQuotes);
                        await context.SaveChangesAsync();
                    }

                    var newItems = new List<IntraDayQuote>();

                    foreach (var kvp in data)
                    {
                        var dto = kvp.Value;
                        var profile = dto.Profile;
                        var virtualNextDay = dto.VirtualNextDay;
                        string currentMarketState;
                        switch (dto.MarketState)
                        {
                            case MarketStateEnum.EIdentifier.PreMarket:
                                currentMarketState = "PreMarket";
                                break;
                            case MarketStateEnum.EIdentifier.PostMarket:
                                currentMarketState = "PostMarket";
                                break;
                            default:
                                currentMarketState = "RegularMarket";
                                break;
                        }

                        var newItem = new IntraDayQuote
                        {
                            Id = Guid.NewGuid(),
                            Symbol = kvp.Key,
                            TradeDateTime = virtualNextDay.Date,
                            MarketState = currentMarketState,
                            OpenPrice = virtualNextDay.Open,
                            ClosePrice = virtualNextDay.Close,
                            AdjustedClose = virtualNextDay.AdjustedClose,
                            HighPrice = virtualNextDay.High,
                            LowPrice = virtualNextDay.Low,
                            Volume = virtualNextDay.Volume,
                            // Data = dto.StockData.ToString(),
                            IsAfterHours = dto.MarketState != MarketStateEnum.EIdentifier.RegularMarket,
                            IsValid = true,
                            ErrorMessage = null,
                            CreatedAt = DateTime.Now.NowOrDefault(),
                            IndicatorsJson = Stock.Common.Enums.TechnicalIndicatorsSignalsEnum.ConvertDaySignalsToJson(virtualNextDay.DaySignals, ""),
                            RawData = virtualNextDay.RawData.ToJson(),
                            PricePerformance = virtualNextDay.PricePerformance.ToJson(),
                            MomentumScore = virtualNextDay?.RawData?.MomentumData?.MomentumScore,
                            MarketCap = profile?.LastMarketCap
                        };

                        newItems.Add(newItem);
                    }

                    context.IntraDayQuotes.AddRange(newItems);
                    await context.SaveChangesAsync();

                    Logger.InfoF("SetIntraDayQuotesRowData: Inserted {0} new quotes.", newItems.Count);
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SetIntraDayQuotesRowData failed: {0}", ex);
                throw;
            }
        }


        internal IntraDayQuotesCollectionDto GetIntraDayQuotesRowData(MarketStateEnum.EIdentifier marketState, DateTime date)
        {
            try
            {
                // Map enum to string used in DB
                string marketStateStr = null;
                switch (marketState)
                {
                    case MarketStateEnum.EIdentifier.RegularMarket:
                        marketStateStr = "RegularMarket";
                        break;
                    case MarketStateEnum.EIdentifier.PreMarket:
                        marketStateStr = "PreMarket";
                        break;
                    case MarketStateEnum.EIdentifier.PostMarket:
                        marketStateStr = "PostMarket";
                        break;
                }

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Fetch all quotes matching market state
                    var quotes = context.IntraDayQuotes.AsQueryable();
                    if (!string.IsNullOrEmpty(marketStateStr))
                    {
                        quotes = quotes.Where(q => q.MarketState == marketStateStr);
                    }
                    if (date != null)
                    {
                        var dateOnly = date.Date;
                        quotes = quotes.Where(q =>
                            q.TradeDateTime.Year == dateOnly.Year &&
                            q.TradeDateTime.Month == dateOnly.Month &&
                            q.TradeDateTime.Day == dateOnly.Day);
                    }


                    var result = new IntraDayQuotesCollectionDto
                    {
                        IntraDayQuotes = new Dictionary<string, IntraDayQuotesDto>()
                    };

                    foreach (var quote in quotes.ToList())
                    {
                        var dto = new IntraDayQuotesDto
                        {
                            Symbol = quote.Symbol,
                            TradeDateTime = quote.TradeDateTime,
                            Open = quote.OpenPrice,
                            Close = quote.ClosePrice,
                            AdjustedClose = quote.AdjustedClose,
                            High = quote.HighPrice,
                            Low = quote.LowPrice,
                            Volume = quote.Volume,
                            MarketState = marketState,
                            DaySignals = Stock.Common.Enums.TechnicalIndicatorsSignalsEnum.ConvertFromJson(quote.IndicatorsJson),
                            StockData = quote.Data,
                            RawDataStr = quote.RawData,
                            PricePerformanceJson = quote.PricePerformance,
                            MomentumScore = quote.MomentumScore,
                            MarketCap = quote.MarketCap,


                        };

                        result.IntraDayQuotes[quote.Symbol] = dto;
                    }

                    return result;
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetIntraDayQuotesRowData failed: {0}", ex);
                throw;
            }
        }

        internal IntraDayQuotesSettingsContainer GetIntraDayQuotesSettingsRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Fetch all quotes matching market state
                    var data = context.ApplicationDatas.Where(x => x.Type == "IntraDayQuotesSettings");
                    if (data == null)
                    {
                        return new IntraDayQuotesSettingsContainer();
                    }
                    var selected = data.FirstOrDefault();
                    if (selected != null)
                    {
                        var item = IntraDayQuotesSettingsContainer.FromString(selected.Data);
                        if (item == null)
                        {
                            item = new IntraDayQuotesSettingsContainer();
                        }
                        return item;
                    }
                    return new IntraDayQuotesSettingsContainer();

                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetIntraDayQuotesSettingsRowData failed: {0}", ex);
                throw;
            }
        }

        internal void SetIntraDayQuotesSettingsRowData(IntraDayQuotesSettingsContainer newData)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Fetch existing setting entry
                    var existingEntry = context.ApplicationDatas
                                               .FirstOrDefault(x => x.Type == "IntraDayQuotesSettings");

                    if (existingEntry == null)
                    {
                        // Create new entry if not found
                        existingEntry = new ApplicationData
                        {
                            Id = Guid.NewGuid(),
                            Type = "IntraDayQuotesSettings",
                            Name = "IntraDayQuotesSettings",
                            Data = newData.ToString()
                        };
                        context.ApplicationDatas.Add(existingEntry);
                    }
                    else
                    {
                        // Update existing entry
                        existingEntry.Data = newData.ToString();
                    }

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("SetIntraDayQuotesSettingsRowData failed: {0}", ex);
                throw;
            }
        }

        internal void SaveStockTradesMomentumSummaryDataDtoToDBRawData(
            StockTradesMomentumSummaryDataDto dataToSaveToDB)
        {
            if (dataToSaveToDB == null)
                throw new ArgumentNullException(nameof(dataToSaveToDB));

            if (dataToSaveToDB.Data == null || dataToSaveToDB.Data.Count == 0)
                return; // Nothing to save

            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var entities = new List<StockTradesMomentumSummary>();

                    foreach (var item in dataToSaveToDB.Data)
                    {
                        var entity = new StockTradesMomentumSummary
                        {
                            Symbol = dataToSaveToDB.Symbol,
                            FromScore = dataToSaveToDB.FromScore,
                            ToScore = dataToSaveToDB.ToScore,
                            StrategyName = dataToSaveToDB.StrategyName,
                            CreatedDate = dataToSaveToDB.CreatedDate,

                            Day = item.Day,
                            AverageProfitPerTrade = item.AverageProfitPerTrade,
                            TradeCount = item.TradeCount,
                            UpCount = item.UpCount,
                            DownCount = item.DownCount,
                            WinRate = item.WinRate,
                            ConsistencyScore = item.ConsistencyScore,
                            WinRatePercents = item.WinRatePercents,
                            LossRatePercent = item.LossRatePercent,
                            CumulativeReturn = item.CumulativeReturn,
                            Score = item.Score,
                            Quality = item.Quality,
                            QualityEnum = item.QualityEnum.ToString()
                        };

                        entities.Add(entity);
                    }

                    context.StockTradesMomentumSummaries.AddRange(entities);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF(
                    "SaveStockTradesMomentumSummaryDataDtoToDBRawData failed. Symbol={0}, Strategy={1}. Exception: {2}",
                    dataToSaveToDB.Symbol,
                    dataToSaveToDB.StrategyName,
                    ex);

                throw;
            }
        }

        internal void ResetStockTradesMomentumSummaryRowData()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    // Bulk delete StockTradesMomentumSummaries
                    context.Database.ExecuteSqlCommand("DELETE FROM [History].[StockTradesMomentumSummary]");
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("ResetStockTradesMomentumSummaryRowData {0}", ex);
                throw;
            }
        }
    }
}