﻿using Stock.Common.Dto;
using Stock.Common.Enums;
using Stock.Common.Logger;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Linq;
using System.Threading;
using System.Transactions;
using static Stock.Common.Dto.ProcessHistoryDto;

namespace Stock.Dal.Dal.Repository.Wrappers
{
    internal class ProcessWrapper : BaseWrapper
    {
        private DbDal _parent;

        public ProcessWrapper(DbDal parent)
        {
            this._parent = parent;
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
        }

        internal void SetProcessHistoryRowData(ProcessHistoryCodeEnum.EIdentifier Code, string Name = null, string Info = null)
        {
            var item = new ProcessHistoryItemDto() { Code = Code, Info = Info, Name = Name };
            if (item.Name == null)
            {
                item.Name = item.Code.ToString();
            }
            if (item.Info == null)
            {
                item.Info = item.Code.ToString();
            }

            SetProcessHistoryRowData(item);
        }

        internal void SetProcessHistoryRowData(ProcessHistoryItemDto item)
        {
            Exception hasException = null;

            for (int i = 0; i < 3; i++)
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        var obj = context.ProcessHistories.FirstOrDefault(x => x.Code == item.Code.ToString());
                        if (obj != null)
                        {
                            if ((DateTime.Now.NowOrDefault() - obj.LastRunDate).TotalMinutes > 30) //More than 30 Minutes from last run
                            {
                                UpdateProcessRunHistory(obj);
                            }
                            obj.LastRunDate = DateTime.Now.NowOrDefault();
                        }
                        else
                        {
                            ProcessHistory historyItem = ProcessHistoryConverter.FromDto(item);
                            historyItem.Id = Guid.NewGuid();
                            historyItem.CreatedDate = DateTime.Now.NowOrDefault();
                            historyItem.LastRunDate = DateTime.Now.NowOrDefault();
                            context.ProcessHistories.Add(historyItem);
                        }
                        context.SaveChanges();
                        return;
                    }
                }
                catch (Exception ex)
                {
                    hasException = ex;
                    Random rnd = new Random();
                    Thread.Sleep(rnd.Next(200, 500));
                    Logger.ErrorF("SetProcessHistoryRowData Fail Retry Again {0} of 3", i + 1);
                }
            }
            if (hasException != null)
            {
                Logger.ErrorF("SetProcessHistoryRowData {0}", hasException);

                throw hasException;
            }
        }

        private void UpdateProcessRunHistory(ProcessHistory processHistory)
        {
            try
            {
                int totalMintuesFromLastTime = (int)(DateTime.Now.NowOrDefault() - processHistory.LastRunDate).TotalMinutes;

                var processHistoryData = ProcessHistoryItemDataDto.FromStringSafe(processHistory.Data);
                var historyToAdd = new ProcessRunHistoryItemDataDto();
                historyToAdd.FromDate = processHistory.LastRunDate;
                historyToAdd.ToDate = DateTime.Now.NowOrDefault();

                historyToAdd.TotalMinutsProcessNotRun = (int)(DateTime.Now.NowOrDefault() - processHistory.LastRunDate).TotalMinutes;

                processHistoryData.RunHistory.Add(historyToAdd);
                processHistoryData.RunningOnComputerName = Environment.MachineName;
                processHistory.Data = processHistoryData.ToString();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

        internal void SetProcessLastRunDate(ProcessHistoryCodeEnum.EIdentifier processCode, DateTime lastRunDate)
        {
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        var obj = context.ProcessHistories.FirstOrDefault(x => x.Code == processCode.ToString());
                        if (obj != null)
                        {
                            obj.LastRunDate = lastRunDate;
                        }

                        context.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    Logger.ErrorF("SetProcessLastRunDate {0}", ex);

                    throw;
                }
            }
        }

        internal ProcessHistoryItemDto GetProcessHistoryRowData(string code)
        {
            ProcessHistoryItemDto result = new ProcessHistoryItemDto();
            try
            {
                using (new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
                {
                    IsolationLevel = IsolationLevel.ReadUncommitted
                }))
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        var obj = context.ProcessHistories.FirstOrDefault(x => x.Code == code);
                        if (obj != null)
                        {
                            result = ProcessHistoryConverter.ToDto(obj);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetProcessHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal ProcessHistoryDto GetProcessHistoryRowData()
        {
            ProcessHistoryDto result = new ProcessHistoryDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.ProcessHistories.Where(x => x.Id != null);
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            try
                            {
                                result.History.Add(ProcessHistoryConverter.ToDto(item));
                            }
                            catch { }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("GetProcessHistoryRowData {0}", ex);

                throw;
            }
            return result;
        }

        internal SystemHealthDataDto GetSystemHealthDataRowData()
        {
            SystemHealthDataDto result = new SystemHealthDataDto();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var processHistories = context.ProcessHistories.Where(x => x.Id != null).ToList();
                    if (processHistories.Any())
                    {
                        foreach (var item in processHistories)
                        {
                            try
                            {
                                var code = ProcessHistoryCodeEnum.Parse(item.Code);
                                SystemHealthDataItemDto data = new SystemHealthDataItemDto();
                                data.LastRun = item.LastRunDate;
                                data.LastRunHistory = ProcessHistoryItemDataDto.FromStringSafe(item.Data);
                                result.ProcessHistory.Add(code, data);
                            }
                            catch
                            {
                            }
                        }
                        //result.CollectorLastRun = GetProcessLastRunTime(processHistories, ProcessHistoryCodeEnum.EIdentifier.Collector.ToString());
                        //result.CollectorLastRunHistory = GetProcessLastRunTimeHistory(processHistories, ProcessHistoryCodeEnum.EIdentifier.Collector.ToString());
                        //result.AnalayzerLastRun = GetProcessLastRunTime(processHistories, ProcessHistoryCodeEnum.EIdentifier.Analyzer.ToString());
                        //result.GoogleTrendLastRun = GetProcessLastRunTime(processHistories, ProcessHistoryCodeEnum.EIdentifier.GoogleTrends.ToString());
                        //result.StockPredefinedLastRun = GetProcessLastRunTime(processHistories, ProcessHistoryCodeEnum.EIdentifier.StockPredefined.ToString());
                        //result.FinvizScannerLastRun = GetProcessLastRunTime(processHistories, ProcessHistoryCodeEnum.EIdentifier.FinvizScanner.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return result;
        }

        internal void ClearProcessHistoryRowData(bool clearAllHistory, ProcessHistoryCodeEnum.EIdentifier processCodeToClear)
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var objs = context.ProcessHistories.Where(x => x.Id != null && (clearAllHistory || x.Code == processCodeToClear.ToString()));
                    if (objs.Any())
                    {
                        foreach (var item in objs)
                        {
                            item.Data = "{}";
                        }
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("ClearProcessHistoryRowData {0}", ex);

                throw;
            }
        }

        //private ProcessHistoryItemDataDto GetProcessLastRunTimeHistory(IQueryable<ProcessHistory> ProcessHistories, string processCode)
        //{
        //    var processHistory = ProcessHistories.FirstOrDefault(x => x.Code == processCode);
        //    if (processHistory != null)
        //    {
        //        return ProcessHistoryItemDataDto.FromStringSafe(processHistory.Data);
        //    }
        //    return null;

        //}

        //private DateTime GetProcessLastRunTime(IQueryable<ProcessHistory> ProcessHistories, string processCode)
        //{
        //    var processHistory = ProcessHistories.FirstOrDefault(x => x.Code == processCode);
        //    if (processHistory != null)
        //    {
        //        return processHistory.LastRunDate;
        //    }
        //    else
        //    {
        //        return DateTime.MinValue;
        //    }
        //}
        public void RunMaintenance()
        {
            try
            {
                Logger.Info("RunMaintenance start");

                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.RunMaintenance();
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }
    }
}