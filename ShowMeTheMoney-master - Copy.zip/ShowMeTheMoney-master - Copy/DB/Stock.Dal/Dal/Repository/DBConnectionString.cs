﻿using Stock.Common.Settings;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;

namespace Stock.Dal.Dal.Repository
{
    internal class DbConnectionString
    {
        private DbConnectionString()
        { }

        private static DbConnectionString _consString;
        private string _string;
        private static object lockObj = new object();

        internal static string ConnectionString
        {
            get
            {
                if (_consString == null)
                {
                    _consString = new DbConnectionString { _string = Connect() };
                    return _consString._string;
                }
                return _consString._string;
            }
        }

        private static string Connect()
        {
            //Build an SQL connection string
            lock (lockObj)
            {
                SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder()
                {
                    DataSource = ShowMeTheMoneySettings.Instance.DatabaseServerName,// "mssql182.joinweb.co.il",    // Server name
                    InitialCatalog = ShowMeTheMoneySettings.Instance.DatabaseName,//"sgatecoi_production",    //Database
                    UserID = ShowMeTheMoneySettings.Instance.DatabaseUserName,//"sgatecoi_avip",                //Username
                    Password = ShowMeTheMoneySettings.Instance.DatabasePassword// "McKesson8",              //Password
                };

                //Build an Entity Framework connection string
                EntityConnectionStringBuilder entityString = new EntityConnectionStringBuilder()
                {
                    Provider = "System.Data.SqlClient",
                    Metadata = "res://*/DBModel.DBModel.csdl|res://*/DBModel.DBModel.ssdl|res://*/DBModel.DBModel.msl",

                    ProviderConnectionString = sqlString.ToString()
                };
                return entityString.ConnectionString;
            }
        }
    }
}