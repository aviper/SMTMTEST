﻿using Stock.Common;
using Stock.Common.Dto;
using Stock.Common.Dto.Login;
using Stock.Common.Dto.MarketsData;
using Stock.Common.Dto.Screener;
using Stock.Common.Dto.StartParamsItems;
using Stock.Common.Dto.Trading;
using Stock.Common.Enums;
using Stock.Common.Indicators;
using Stock.Common.Indicators.Params;
using Stock.Common.Strategy;
using Stock.Common.Utils;
using Stock.Dal.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Stock.Common.Dto.AnalysisHistoryDto;
using static Stock.Common.Dto.ProcessHistoryDto;
using static Stock.Common.Dto.Trading.NasdaqStocksDto;
using static Stock.Common.Enums.Enums;
using static Stock.Common.Enums.ProcessHistoryCodeEnum;

namespace Stock.Dal
{
    /// <summary>
    /// Interface for stock market database operations, providing methods for managing stock data, 
    /// trading strategies, market analysis, and system operations.
    /// </summary>
    public interface ISitesDb
    {
        #region Stock Data Management

        /// <summary>
        /// Gets all stocks from the database.
        /// </summary>
        StocksDto GetStocks();

        /// <summary>
        /// Gets stock data for a specific symbol.
        /// </summary>
        StocksDto GetStockData(string symbol);

        /// <summary>
        /// Updates a stock data item.
        /// </summary>
        void UpdateStockData(StocksDto.StockDto item);

        /// <summary>
        /// Saves parsed stock data from a specified source.
        /// </summary>
        void SaveStockData(ParseResultData data, StocksDataSource source);

        /// <summary>
        /// Gets a list of stock symbols, optionally filtered to only relevant stocks.
        /// </summary>
        List<string> GetStocksSymbols(bool onlyRelevant = true);

        /// <summary>
        /// Deletes old stock data from the database.
        /// </summary>
        void DeleteOldStockData();

        /// <summary>
        /// Gets a list of invalid stocks from history.
        /// </summary>
        List<string> GetInvalidStocksFromHistory();
        List<(string Symbol, DateTime? LastSync)> GetOutdatedStocks(DateTime lastDate);

        /// <summary>
        /// Marks specified stocks as invalid.
        /// </summary>
        #endregion

        #region Stock History Operations

        /// <summary>
        /// Gets historical stock data for a list of symbols.
        /// </summary>
        Dictionary<string, StocksHistoryItemDto> GetStocksHistory(List<string> symbols);

        /// <summary>
        /// Asynchronously gets historical stock data for a list of symbols.
        /// </summary>
        Task<Dictionary<string, StocksHistoryItemDto>> GetStocksHistoryAsync(List<string> symbols);

        /// <summary>
        /// Gets new historical stock data for a list of symbols with date range and row limits.
        /// </summary>
        Dictionary<string, StocksHistoryItemDto> GetStocksHistoryNew(List<string> symbols, DateTime endDate, int NumOfRows);

        /// <summary>
        /// Sets historical stock data.
        /// </summary>
        void SetStocksHistory(List<StocksHistoryItemDto> data);

        /// <summary>
        /// Updates historical stock data.
        /// </summary>
        void UpdateStocksHistoryData(List<StocksHistoryItemDto> stocksHistories);

        /// <summary>
        /// Gets stock history data that needs to be refreshed.
        /// </summary>
        StocksHistoryToRefreshDto GetStocksHistoryToRefresh(DateTime lastTradingDate, int maxItems);

        /// <summary>
        /// Gets symbols with history data, optionally filtered to simulator symbols.
        /// </summary>
        List<StocksHistorySymbolsDto> GetStocksHistorySymbols();

        /// <summary>
        /// Fixes inconsistencies in stock history data.
        /// </summary>
        void FixStockHistoryData();

        #endregion

        #region Stock Profile Management

        /// <summary>
        /// Gets a stock profile for a specific symbol.
        /// </summary>
        StockProfile GetStockProfile(string symbol);

        /// <summary>
        /// Gets all stock profiles, optionally filtered to only relevant stocks.
        /// </summary>
        List<StockProfile> GetStocksProfiles(bool onlyRelevant = true, bool OnlyValid = false);

        /// <summary>
        /// Gets a symbol by company name.
        /// </summary>
        string GetSymbolByCompanyName(string companyName);

        /// <summary>
        /// Gets pending stock information that needs to be processed.
        /// </summary>
        List<StockProfile> GetPendingStockInfo();

        /// <summary>
        /// Gets stock information that needs to be refreshed.
        /// </summary>
        List<StockProfile> GetStockInfoToRefresh();

       bool ResetStockInfoToRefresh();

        /// <summary>
        /// Sets pending stock information.
        /// </summary>
        void SetPendingStockInfo(List<StockProfile> pendingStockInfo);

        /// <summary>
        /// Refreshes stock information.
        /// </summary>
        void RefreshStockInfo(List<StockProfile> pendingStockInfo);

        /// <summary>
        /// Gets stock profiles with alerts, optionally filtered to only relevant stocks.
        /// </summary>
        List<StockProfileWithAlertsDto> GetStockProfileWithAlertsView(bool onlyRelevant = true);

        /// <summary>
        /// Gets static stocks data.
        /// </summary>
        List<StaticStockDataSto> GetCachedStockProfilesData();

        #endregion

        #region Analysis & History

        /// <summary>
        /// Gets all analysis history.
        /// </summary>
        AnalysisHistoryDto GetAnalysisHistory();

        /// <summary>
        /// Gets analysis history for a specific symbol with filtering options.
        /// </summary>
        AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime minValue, int itemsToDisplay, bool onlyDuringTrade);

        /// <summary>
        /// Gets analysis history for a specific symbol from a specific date with item count limit.
        /// </summary>
        AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime fromDate, int maxItemsCount);

        /// <summary>
        /// Gets analysis history for a date range.
        /// </summary>
        AnalysisHistoryDto GetAnalysisHistory(DateTime fromDate, DateTime toDate);

        /// <summary>
        /// Gets stock analysis history for a specific symbol and date range.
        /// </summary>
        AnalysisHistoryDto GetStockAnalysisHistory(string symbol, DateTime fromDate, DateTime toDate);

        /// <summary>
        /// Adds an item to analysis history.
        /// </summary>
        Guid AddToAnalysisHistory(AnalysisHistoryItemDto item);

        /// <summary>
        /// Deletes redundant analysis history records.
        /// </summary>
        void DeleteRedundantAnalysisHistoryRecords(DateTime fromDate);

        /// <summary>
        /// Gets stock history data for a specific history ID.
        /// </summary>
        AnalysisHistoryItemDto GetStockHistoryData(Guid historyId);

        /// <summary>
        /// Gets stock history for a date range with minimum score filtering.
        /// </summary>
        StocsHistoryDto GetStocsHistory(DateTime fromDate, DateTime toDate, double minScore);

        #endregion

        #region WatchList Operations

        /// <summary>
        /// Gets all watch lists with filtering options.
        /// </summary>
        WatchListsDto GetWatchLists(bool onlyEnabled, bool forAnalysis);

        /// <summary>
        /// Gets stocks for a specific watch list.
        /// </summary>
        StocksDto GetWatchListStocks(Guid id);

        /// <summary>
        /// Gets watch list metadata.
        /// </summary>
        WatchListMedaDataSto GetWatchListMedaData();

        /// <summary>
        /// Gets the current stocks watch list.
        /// </summary>
        CurrentStocksWatchListDto GetCurrentStocksWatchList();

        #endregion

        #region Strategy Management

        /// <summary>
        /// Gets the current trading strategy.
        /// </summary>
        List<StrategyItemDto> GetCurrentStrategy();

        /// <summary>
        /// Gets all trading strategies.
        /// </summary>
        List<StrategyItemDto> GetAllStrategy();

        /// <summary>
        /// Adds trading strategies to the database.
        /// </summary>
        bool AddStrategies(List<StrategyItemDto> strategyCollection);

        /// <summary>
        /// Saves trading strategies to the database.
        /// </summary>
        void SaveStrategies(List<StrategyItemDto> strategyCollection);

        /// <summary>
        /// Initializes strategies stocks data.
        /// </summary>
        void InitNasdaqStocksData(NasdaqStocksDto strategiesStocksData, bool delete);

        /// <summary>
        /// Gets strategies stocks data with filters.
        /// </summary>
        List<NasdaqStockData> GetNasdaqStocksData(ExchangeEnum exchange, List<SectorEnum> sectors, int minMarketCap);

        /// <summary>
        /// Saves strategies stocks history data asynchronously.
        /// </summary>
        Task SaveStrategiesStocksHistoryDataAsync(StrategyScanModeEnum.EIdentifier code, string message, StrategiesStocksHistoryDataDto data, double? totalScore);

        /// <summary>
        /// Gets strategies stocks history data asynchronously.
        /// </summary>
        Task<StrategiesStocksHistoryDataDto> GetStrategiesStocksHistoryDataAsync(List<string> symbols, DateTime date);

        /// <summary>
        /// Cleans today's strategies stocks history data.
        /// </summary>
        void CleanTodayStrategiesStocksHistoryData();

        #endregion

        #region Strategy Models

        /// <summary>
        /// Loads strategy model data asynchronously.
        /// </summary>
        Task<List<StrategiesStocksModelDto>> LoadStrategyModelDataAsync(List<string> symbols);

        /// <summary>
        /// Loads strategy model names asynchronously.
        /// </summary>
        Task<List<string>> LoadStrategyModelNamesAsync(List<string> symbols);

        /// <summary>
        /// Saves strategy model data asynchronously.
        /// </summary>
        Task<StrategiesStocksModelDto> SaveStrategyModelDataAsync(StrategiesStocksModelDto data);

        #endregion

        #region Trading Operations

        /// <summary>
        /// Saves buy stock data with simulation option.
        /// </summary>
        bool SaveBuyStockData(SaveStockDto data, bool simulation);

        /// <summary>
        /// Gets holdings with simulation option.
        /// </summary>
        List<InvestmentDto> GetHoldings(bool simulation);

        /// <summary>
        /// Updates holdings data.
        /// </summary>
        void UpdateHoldings(List<InvestmentDto> holdings);

        /// <summary>
        /// Gets indicators trader holding data for a symbol and strategy.
        /// </summary>
        bool GetIndicatorsTraderHoldingData(string symbol, StrategyItemNewDto strategy);

        /// <summary>
        /// Commits an indicators trader buy asynchronously.
        /// </summary>
        Task IndicatorsTraderCommitBuyAsync(IndicatorsTraderDto data);

        /// <summary>
        /// Gets all indicators trader alerts.
        /// </summary>
        List<IndicatorsTraderDto> GetAllIndicatorsTraderAlerts();

        #endregion

        #region Trade Data Analysis

        /// <summary>
        /// Gets stock trades for specified stocks.
        /// </summary>
        DailyStocksQuotesDto GetDailyStocksQuotes(List<string> stocks, bool includeEmptyIndicators = true);

        /// <summary>
        /// Gets stock trades by symbols and date range.
        /// </summary>
        DailyStocksQuotesDto GetDailyStocksQuotes(List<string> stocks, DateTime? from, DateTime? to, bool includeEmptyIndicators = true);
        List<DailyStockQuotesDto> GetDailyStockQuotes(string stock, DateTime? from, DateTime? to, bool includeEmptyIndicators = true);


        /// <summary>
        /// Collects stock trade data asynchronously.
        /// </summary>
        Task CollectStockTradeDataAsync(string symbol, List<KeyValuePair<DateTime, HistoricalDataDto>> history, bool onlyStrategy, bool partialUpdate, DateTime? startDate);

        /// <summary>
        /// Gets trades by symbols and date.
        /// </summary>
        List<StockHistoryTradeDto> GetTradesBySymbolsAndDate(string symbols, DateTime endDate, int numOfWeeks);

        /// <summary>
        /// Gets current stock trade dates.
        /// </summary>
        List<CurrentStockTradesDatesDto> GetCurrentStockTradesDates(List<string> symbols);

        /// <summary>
        /// Populates the stock trade summary table.
        /// </summary>
        void PopulateStockTradeSummaryTable(DateTime minDate);
        void PopulateStockTradeSummaryBySymbolGroupTable(DateTime minDate);


        Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> GetDailyStocksQuotesAsDictionary(List<string> symbols, bool includeEmptyIndicators = true);

        Dictionary<string, Dictionary<DateTime, DailyStockQuotesDto>> GetDailyStocksQuotesAsDictionary(List<string> symbols, DateTime from, DateTime to, bool includeEmptyIndicators = true);

        Dictionary<DateTime, DailyStockQuotesDto> GetDailyStockQuotesAsDictionary(string symbol, DateTime from, DateTime to, bool includeEmptyIndicators = true);

        double? GetStockDailyClosePrice(string symbol, DateTime date);
   
        double GetStockVolumeAverageForPeriod(string symbol, DateTime from, DateTime to);

        double GetStockStandardDeviationForPeriod(string symbol, DateTime from, DateTime to, decimal currentDateClosePrice = -1);

        double GetStockPriceChangeForPeriod(string symbol, DateTime fromDate, DateTime toDate);

        double GetStockPriceMovementForPeriod(string symbol, DateTime fromDate, DateTime toDate, double additionalHigh = double.NaN, double additionalLow = double.NaN);

        void LoadStocksDailyQuotesToCache(List<string> symbols, DateTime from, DateTime to, bool includeEmptyIndicators = true);

        void ClearStocksDailyQuotesCache(List<string> symbolsToExclude = null);

        #endregion

        #region Indicators

        /// <summary>
        /// Gets stock indicator data that needs to be refreshed.
        /// </summary>
        List<string> GetStockIndicatorDataToRefresh(DateTime lastTradingDate);

        /// <summary>
        /// Gets indicators by symbols and date range.
        /// </summary>
        List<StockTradesIndicatorDto> GetIndicatorsBySymbolsAndDateRange(string symbols, DateTime from, DateTime to);

        /// <summary>
        /// Gets profit indicators by symbols with filtering options.
        /// </summary>
        List<StocksProfitIndicatorDto> GetProfitIndicatorsBySymbols(string symbols, decimal minRatio, int minPositiveResults, string indicatorPrefix, List<string> days, decimal minDayPercentsValue, string prefix);
        #endregion

        #region Simulation & Backtesting

        /// <summary>
        /// Gets simulation results for a date range.
        /// </summary>
        AnalysisHistoryDto GetSimulationResults(DateTime fromDate, DateTime toDate);

        /// <summary>
        /// Adds simulation results.
        /// </summary>
        void AddSimulationResults(List<AnalysisHistoryItemDto> items, bool forScreener);

        /// <summary>
        /// Clears simulation results.
        /// </summary>
        void ClearSimulationResults(bool forScreener);

        /// <summary>
        /// Gets simulation results data for a date range.
        /// </summary>
        AnalysisHistoryDto SimulationResultsData(DateTime fromDate, DateTime toDate);

        /// <summary>
        /// Updates simulation results ranks.
        /// </summary>
        void UpdateSimulationResultsRanks(int[] ranksMinValues);

        /// <summary>
        /// Resets stock simulator data.
        /// </summary>
        void ResetStockSimulatorData();

        #endregion

        #region Market Data

        /// <summary>
        /// Gets market data with specified parameters.
        /// </summary>
        MarketDataDto GetMarketData(MarketDataGetParams getParams);

        /// <summary>
        /// Gets market history data with filtering options.
        /// </summary>
        List<MarketHistoryDataDto> GetMarketHistoryData(int days_back, int min_score);

        /// <summary>
        /// Gets Google trend information.
        /// </summary>
        GoogleTrendDataDto GetGoogleTrendInfo();

        /// <summary>
        /// Adds Google trend information.
        /// </summary>
        void AddGoogleTrendInfo(GoogleTrendDataDto googleTrendDataDto);

        #endregion

        #region Sector & Industry Data

        /// <summary>
        /// Gets sectors data.
        /// </summary>
        List<SectorDataDto> GetSectorsData();

        /// <summary>
        /// Saves sectors data.
        /// </summary>
        void SaveSectorsData(List<SectorDataDto> sectors);

        #endregion

        #region Scanners & Alerts

        /// <summary>
        /// Adds Finviz scanners data.
        /// </summary>
        void AddFinvizScannersData(string code, FinvizScannersDataDto finvizScannersDataDto);

        /// <summary>
        /// Gets Finviz scanners data.
        /// </summary>
        FinvizScannersDataDto GetFinvizScannersData(string code);

        /// <summary>
        /// Saves Finviz alerts.
        /// </summary>
        void SaveFinvizAlerts(List<FinvizScannersDataItem> itemsToSend, string name);

        /// <summary>
        /// Gets alerts history data.
        /// </summary>
        AlertHistoryDataDto GetAlertsHistoryData(Guid alertHistoryId);

        /// <summary>
        /// Gets alerts histories data with filtering options.
        /// </summary>
        List<AlertHistoryDataDto> GetAlertHistoriesData(EIdentifier premarketStockScanner, DateTime fromDate, DateTime toDate);

        /// <summary>
        /// Saves premarket scanner data.
        /// </summary>
        void SavePremarketScannerData(PremarketScannerDataDto premarketScannerData);

        /// <summary>
        /// Saves premarket scanner metadata.
        /// </summary>
        void SavePremarketScannerMetaData(HistoryTopStocksDto currentCandidateStocksToTrade);

        /// <summary>
        /// Gets premarket scanner metadata.
        /// </summary>
        HistoryTopStocksDto GetPremarketScannerMetaData();

        /// <summary>
        /// Saves momentum stocks data.
        /// </summary>
        void SaveMomentumStocksData(MomentumStocksData momentumStocksScannerData, bool deleteFlag);

        /// <summary>
        /// Gets momentum stocks data.
        /// </summary>
        MomentumStocksData GetMomentumStocksData();

        #endregion

        #region Overview & Statistics

        /// <summary>
        /// Gets stocks overview with optional date range filtering.
        /// </summary>
        StocksOverviewDto GetStocksOverview(string symbol, DateTime? fromDate, DateTime? toDate);

        /// <summary>
        /// Gets history top stocks with filtering options.
        /// </summary>
        HistoryTopStocksDto GetHistoryTopStocks(bool? duringTrade, int numberOfDays);

        /// <summary>
        /// Gets stocks health report for a specific trading date.
        /// </summary>
        Task<StocksHealthReport> GetStocksHealthReportAsync(DateTime lastTradeDate);
        /// <summary>
        /// Gets predefined stocks.
        /// </summary>
        PredefinedStocksDto GetPredefinedStocks();

        #endregion

        #region System Operations

        /// <summary>
        /// Loads configuration settings.
        /// </summary>
        ConfigurationDto LoadConfig();

        /// <summary>
        /// Gets system health data.
        /// </summary>
        SystemHealthDataDto GetSystemHealthData();

        /// <summary>
        /// Gets process history.
        /// </summary>
        ProcessHistoryDto GetProcessHistory();

        /// <summary>
        /// Sets process history.
        /// </summary>
        void SetProcessHistory(ProcessHistoryItemDto item);

        /// <summary>
        /// Sets process history with optional name and info.
        /// </summary>
        void SetProcessHistory(EIdentifier Code, string Name = null, string Info = null);

        /// <summary>
        /// Gets process history for a specific process code.
        /// </summary>
        ProcessHistoryItemDto GetProcessHistory(EIdentifier processCode);

        /// <summary>
        /// Sets the last run date for a process.
        /// </summary>
        void SetProcessLastRunDate(EIdentifier processCode, DateTime lastRunDate);

        /// <summary>
        /// Clears process history.
        /// </summary>
        void ClearProcessHistory(bool clearAllHistory, EIdentifier processCodeToClear);

        /// <summary>
        /// Gets process information.
        /// </summary>
        ProcessInfoDto GetProcessInfo();

        #endregion

        #region Database Operations

        /// <summary>
        /// Gets database size information.
        /// </summary>
        List<GetDbSize_Result> GetDbSize();

        /// <summary>
        /// Runs database maintenance.
        /// </summary>
        void RunDatabaseMaintenance(bool forchShrink = false);

        /// <summary>
        /// Runs general maintenance.
        /// </summary>
        void RunMaintenance();

        /// <summary>
        /// Performs a custom job.
        /// </summary>
        void DoCustomJob();

        /// <summary>
        /// Runs fix data for a specific process.
        /// </summary>
        void RunFixData(EIdentifier process);

        #endregion

        #region Configuration & Parameters

        /// <summary>
        /// Gets start parameters for a specific process.
        /// </summary>
        ParamBase GetStartParams(ConfigurationCodeEnum.EIdentifier process);

        /// <summary>
        /// Sets start parameters for a specific process.
        /// </summary>
        void SetStartParams(ConfigurationCodeEnum.EIdentifier process, ParamBase param);

        /// <summary>
        /// Updates configuration.
        /// </summary>
        void UpdateConfiguration(ConfigurationCodeEnum.EIdentifier configCode, string data);

        /// <summary>
        /// Gets configuration data.
        /// </summary>
        string GetConfigurationData(ConfigurationCodeEnum.EIdentifier configCode);

        #endregion

        #region Logging & Monitoring

        /// <summary>
        /// Writes a log message.
        /// </summary>
        void WriteLogMessage(LogDto log);

        /// <summary>
        /// Gets recent logs.
        /// </summary>
        List<LogDto> GetRecentLogs(GetRecentLogsParamsDto param);

        /// <summary>
        /// Updates log level.
        /// </summary>
        void UpdateLogLevel(Enums.DbLogLevel level);

        #endregion

        #region User Management

        /// <summary>
        /// Authenticates a user.
        /// </summary>
        LoginResult Login(LoginParamsDto loginParams);

        /// <summary>
        /// Gets users by action.
        /// </summary>
        List<UsersActionDto> GetUsersByAction(UserActionEnum.EIdentifier action);
         Task SetIntraDayQuotesAsync(Dictionary<string, IntraDayQuotesSetDto> data);
        IntraDayQuotesCollectionDto GetIntraDayQuotes(MarketStateEnum.EIdentifier MarketState, DateTime date);
        IntraDayQuotesSettingsContainer GetIntraDayQuotesSettings();
        void SetIntraDayQuotesSettings(IntraDayQuotesSettingsContainer newData);
        Dictionary<string,List<DailyStockQuotesDto>> GetStockTrades(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate);
        int PopulateStockTradesTradingSimulations(List<string> symbols, List<string> distinctIndicators, DateTime fromDate, DateTime toDate);
        void ReloadStockProfileData();
        void SaveStockTradesMomentumSummaryDataDtoToDB(StockTradesMomentumSummaryDataDto dataToSaveToDB);
        void ResetStockTradesMomentumSummary();


        #endregion
    }
}