﻿namespace Stock.Dal.Bll.TrackChanges
{
    public class GenericVersionObject
    {
        public int Version { get; set; }

        public GenericVersionObject()
        {
            Version = int.MinValue;
        }

        public override bool Equals(object obj)
        {
            bool result = false;
            GenericVersionObject objF = obj as GenericVersionObject;
            if (objF != null)
            {
                if ((objF.Version == Version))
                {
                    result = true;
                }
            }

            return result;
        }

        public override int GetHashCode()
        {
            return Version.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}", this.Version);
        }
    }
}