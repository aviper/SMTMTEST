﻿using Stock.Common.Dto;
using Stock.Common.Logger;
using Stock.Dal.Dal.Repository;
using Stock.Dal.Dal.Repository.Wrappers;
using Stock.Dal.DBModel;
using Stock.Dal.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Stock.Dal.Bll.TrackChanges
{
    internal partial class DbCachedDataContainer : BaseWrapper
    {
        private readonly Initializer<List<StockProfile>> _stockInfos;
        private DateTime _lastStockScanTime;

        public List<StockProfile> StockInfos => _stockInfos.Get();

        private DbCachedDataContainer()
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            _stockInfos = new Initializer<List<StockProfile>>(
                "Stocks",
                (obj, previousData) => LoadStocks(obj, previousData),
                new GenericCheckerObject("StocksHistory", "Stocks.StocksHistory")
            );
            _lastStockScanTime = DateTime.Now.AddHours(-1);
        }

        private List<StockProfile> LoadStocks(RefreshNeededObject refreshObj, List<StockProfile> previousData)
        {
            try
            {
                // Return cached data if the last scan was within the past minute
                if (previousData != null && (DateTime.Now - _lastStockScanTime).TotalMinutes <= 1)
                {
                    return previousData;
                }

                _lastStockScanTime = DateTime.Now;

                if (refreshObj.IsRefreshNeeded)
                {
                    var stocks = LoadSStockProfileData();
                    Logger.InfoF("Cache: Successfully loaded stock data.");
                    return stocks;
                }

                return previousData;
            }
            catch (Exception ex)
            {
                Logger.ErrorF("Error in LoadStocks: {0}", ex);
                throw;
            }
        }

        private List<StockProfile> LoadSStockProfileData()
        {
            var stockProfiles = new List<StockProfile>();
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    var stockEntities = context.StockInfoViews.Where(x => x.Id != null).ToList();
                    if (stockEntities.Any())
                    {
                        stockProfiles.AddRange(stockEntities.Select(StockHistoryConverter.ToStockProfileDto));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorF("Error in LoadStocksOrderData: {0}", ex);
                throw;
            }

            return stockProfiles;
        }
    }
}