﻿using Stocks.Common.Log;
using Stock.Common.Logger;
using System;

namespace Stock.Dal.Bll.TrackChanges
{
    internal partial class DbCachedDataContainer
    {
        private class Initializer<T>
        {
            protected readonly IStocksLogger Logger = null;
            private readonly string _name;
            private readonly Func<T> _factory1;
            private readonly Func<RefreshNeededObject, T, T> _factory2;
            private readonly CachedCheckerObject _cachedObject;
            private readonly object _locker;//not static since DbCachedDataContainer is static
            private T _data;

            /// <param name="name">Name of data - For log purpose only</param>
            /// <param name="factory">Function that initialize data - called only once or on cache refresh</param>
            /// <param name="refreshConditionFunction">Function that performs a check if cache should be refreshed. if the value it returns changes comparing to the last check, cache will be refreshed</param>
            public Initializer(string name, Func<RefreshNeededObject, T, T> factory, CachedCheckerObject cachedObject) : this(name, cachedObject)
            {
                Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
                _factory2 = factory;
            }

            public Initializer(string name, Func<T> factory, CachedCheckerObject cachedObject) : this(name, cachedObject)
            {
                Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
                _factory1 = factory;
            }

            private Initializer(string name, CachedCheckerObject cachedObject)
            {
                Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
                _name = name;
                _cachedObject = cachedObject;
                _locker = new object();
            }

            public T Get()
            {
                RefreshNeededObject refreshNeededObj = IsRefreshNeeded();
                if (refreshNeededObj.IsRefreshNeeded)
                {
                    lock (_locker)
                    {
                        refreshNeededObj = IsRefreshNeeded();
                        if (refreshNeededObj.IsRefreshNeeded)
                        {
                            // Logger.InfoF("Cache: Load {0} ", _name);
                            _data = (_factory1 != null) ? _factory1() : _factory2(refreshNeededObj, _data);
                            if (_cachedObject != null)
                            {
                                _cachedObject.PostRefreshAction();
                            }
                        }
                    }
                }

                return _data;
            }

            private RefreshNeededObject IsRefreshNeeded()
            {
                RefreshNeededObject refreshObj = null;

                // refresh is needed only if refresh condition function has been provided and it returns true
                if (_data == null)
                {
                    if (_cachedObject != null && _cachedObject.GetRefreshCondition() != null)
                    {
                        // call this so the version of the cached object will be saved for the next time
                        refreshObj = _cachedObject.GetRefreshCondition().Invoke();
                        refreshObj.IsRefreshNeeded = true;
                    }
                    else
                    {
                        refreshObj = new RefreshNeededObject() { IsRefreshNeeded = true };
                    }
                }
                else if (_cachedObject != null && _cachedObject.GetRefreshCondition() != null)
                {
                    refreshObj = _cachedObject.GetRefreshCondition().Invoke();
                }
                else
                {
                    refreshObj = new RefreshNeededObject() { IsRefreshNeeded = false };
                }

                return refreshObj;
            }

            public void ClearCache()
            {
                _data = default(T);
            }
        }
    }
}