﻿namespace Stock.Dal.Bll.TrackChanges
{
    public class RefreshNeededObject
    {
        public bool IsRefreshNeeded { get; set; }
        //public object RefreshDataObj { get; set; }

        public override string ToString()
        {
            return string.Format("IsRefreshNeeded={0}", IsRefreshNeeded);
        }
    }
}