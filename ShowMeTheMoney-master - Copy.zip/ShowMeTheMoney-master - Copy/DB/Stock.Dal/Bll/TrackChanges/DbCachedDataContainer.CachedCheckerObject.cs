﻿using System;

namespace Stock.Dal.Bll.TrackChanges
{
    public abstract class CachedCheckerObject
    {
        public abstract Func<RefreshNeededObject> GetRefreshCondition();

        public virtual void PostRefreshAction()
        {
        }
    }
}