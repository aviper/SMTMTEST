﻿using Stocks.Common.Log;
using Stock.Common.Logger;
using Stock.Dal.Dal.Repository;
using Stock.Dal.DBModel;
using System;
using System.Linq;

namespace Stock.Dal.Bll.TrackChanges
{
    public class GenericCheckerObject : CachedCheckerObject
    {
        protected readonly IStocksLogger Logger = null;

        private string Name { get; }
        private string TableName { get; }

        private GenericVersionObject _prevVersion = new GenericVersionObject();
        private GenericVersionObject _nextVersion = new GenericVersionObject();

        public GenericCheckerObject(string name, string tableName)
        {
            Logger = StockLogManager.GetLogger(StockLogManager.ELoggerTypeEnum.DB);
            Name = name;
            TableName = tableName;
        }

        public override Func<RefreshNeededObject> GetRefreshCondition()
        {
            return IsRefreshNeeded;
        }

        public override void PostRefreshAction()
        {
            _prevVersion = _nextVersion;
        }

        public GenericVersionObject GetGenericFieldsVersion()
        {
            GenericVersionObject result = new GenericVersionObject();
            const int maxRetries = 3;
            int attempt = 0;

            while (attempt < maxRetries)
            {
                try
                {
                    using (var context = new DBEntities(DbConnectionString.ConnectionString))
                    {
                        context.Database.CommandTimeout = 5; // increased timeout for safety

                        var v = context.Get_TrackingVersion(TableName);
                        var vItems = v.ToList();
                        if (vItems.Any())
                        {
                            result.Version = (int)vItems[0].Value;
                        }
                        return result;  // success - return immediately
                    }
                }
                catch (Exception ex)
                {
                    attempt++;
                    Logger.Error($"GetCustomersFieldsVersion attempt {attempt} failed: {ex}");
                    ResetChangeTracking();

                    if (attempt >= maxRetries)
                    {
                        Logger.Error("GetCustomersFieldsVersion: max retries reached, returning empty result.");
                        return result;
                    }

                    // Wait before retrying (1 second)
                    System.Threading.Thread.Sleep(50);
                }
            }

            return result;
        }


        private void ResetChangeTracking()
        {
            try
            {
                using (var context = new DBEntities(DbConnectionString.ConnectionString))
                {
                    context.Database.CommandTimeout = 30; // increased timeout if needed

                    var result = context.ResetChangeTracking(); // Assuming this is a stored proc call or EF method

                    // Optionally process result or log success
                    Logger.Info("ResetChangeTracking executed successfully.");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ResetChangeTracking attempt failed: {ex}");
            }
        }


        private RefreshNeededObject IsRefreshNeeded()
        {
            _nextVersion = GetGenericFieldsVersion();
            RefreshNeededObject result = new RefreshNeededObject();
            if (!_prevVersion.Equals(_nextVersion))
            {
                result.IsRefreshNeeded = true;
                //if (_prevVersion.SessionsVersion != _nextVersion.SessionsVersion)
                //{
                //    result.RefreshDataObj = true;
                //}
            }
            else
            {
                result.IsRefreshNeeded = false;
            }

            return result;
        }
    }
}