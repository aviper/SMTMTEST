﻿using System;
using System.Collections.Generic;
using Stock.Common;
using Stock.Common.Dto;
using Stock.Common.Dto.Login;
using Stock.Common.Dto.MarketsData;
using Stock.Common.Dto.StartParamsItems;
using Stock.Common.Dto.Trading;
using Stock.Common.Enums;
using Stock.Common.Strategy;
using Stock.Dal.Dal;
using Stock.Dal.DBModel;
using static Stock.Common.Dto.AnalysisHistoryDto;
using static Stock.Common.Dto.ProcessHistoryDto;


namespace Stock.Dal.Bll
{
    public class DbBll : ISitesDb
    {
        private readonly ISitesDb _db = null;

        public DbBll()
        {
            _db = new DbDal();

        }

        public Guid AddToAnalysisHistory(AnalysisHistoryDto.AnalysisHistoryItemDto item)
        {
           return _db.AddToAnalysisHistory(item);
        }

        public void SetProcessHistory(ProcessHistoryDto.ProcessHistoryItemDto item)
        {
            _db.SetProcessHistory(item);
        }

        public void SetProcessHistory(ProcessHistoryCodeEnum.EIdentifier Code, string Name = null, string Info = null)
        {
            _db.SetProcessHistory(Code, Name, Info);
        }

        public void SetProcessLastRunDate(ProcessHistoryCodeEnum.EIdentifier processCode, DateTime lastRunDate)
        {
            _db.SetProcessLastRunDate(processCode, lastRunDate);
        }

        public AnalysisHistoryDto GetAnalysisHistory()
        {
            return _db.GetAnalysisHistory();
        }

        //public StartSiteParamsDto GetStartSiteParams()
        //{
        //    return _db.GetStartSiteParams();
        //}

        public AnalysisHistoryDto GetAnalysisHistory(DateTime fromDate, DateTime toDate)
        {
            return _db.GetAnalysisHistory(fromDate, toDate);
        }

        public AnalysisHistoryDto GetStockAnalysisHistory(string symbol, DateTime fromDate, DateTime toDate)
        {
            return _db.GetStockAnalysisHistory(symbol, fromDate, toDate);
        }

        public ProcessHistoryDto GetProcessHistory()
        {
            return _db.GetProcessHistory();
        }

        public ProcessHistoryItemDto GetProcessHistory(ProcessHistoryCodeEnum.EIdentifier processCode)
        {
            return _db.GetProcessHistory(processCode);
        }

        public AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime fromDate, int maxItemsCount)
        {
            return _db.GetAnalysisHistory(symbol, fromDate, maxItemsCount);
        }
        public AnalysisHistoryDto GetAnalysisHistory(string symbol, DateTime fromDate, int maxItemsCount, bool onlyDuringTrade)
        {
            return _db.GetAnalysisHistory(symbol, fromDate, maxItemsCount, onlyDuringTrade);
        }

        public void DeleteRedundantAnalysisHistoryRecords(DateTime fromDate)
        {
            _db.DeleteRedundantAnalysisHistoryRecords(fromDate);
        }


        public StocksDto GetStocks()
        {
            return _db.GetStocks();
        }

        public WatchListsDto GetWatchLists(bool onlyEnabled, bool forAnalysis)
        {
            return _db.GetWatchLists(onlyEnabled, forAnalysis);
        }

        public StocksDto GetWatchListStocks(Guid id)
        {
            return _db.GetWatchListStocks(id);
        }

        public StocksDto GetStockData(string symbol)
        {
            return _db.GetStockData(symbol);
        }

        public ConfigurationDto LoadConfig()
        {
            return _db.LoadConfig();
        }

        public void SaveStockData(ParseResultData data, StocksDataSource source)
        {
            _db.SaveStockData(data, source);
        }

        public ProcessInfoDto GetProcessInfo()
        {
            return _db.GetProcessInfo();
        }

        public void DeleteOldStockData()
        {
            _db.DeleteOldStockData();
        }
        public void WriteLogMessage(LogDto log)
        {
            _db.WriteLogMessage(log);
        }

        public List<StockProfile> GetPendingStockInfo()
        {
            return _db.GetPendingStockInfo();
        }

        public List<string> GetStocksSymbols(bool onlyRelevant = true)
        {
            return _db.GetStocksSymbols(onlyRelevant);
        }

        public List<StockProfile> GetStocksProfiles(bool onlyRelevant = true)
        {
            return _db.GetStocksProfiles(onlyRelevant);
        }

        //public StartGoogleTrendsParamsDto GetStartGoogleTrendsCollectorParams()
        //{
        //    return _db.GetStartGoogleTrendsCollectorParams();
        //}

        public void AddGoogleTrendInfo(GoogleTrendDataDto googleTrendData)
        {
            _db.AddGoogleTrendInfo(googleTrendData);
        }

        public GoogleTrendDataDto GetGoogleTrendInfo()
        {
            return _db.GetGoogleTrendInfo();
        }

        public StockProfile GetStockProfile(string symbol)
        {
            return _db.GetStockProfile(symbol);
        }

        public string GetSymbolByCompanyName(string companyName)
        {
            return _db.GetSymbolByCompanyName(companyName);
        }

        public void SetPendingStockInfo(List<StockProfile> pendingStockInfo)
        {
            _db.SetPendingStockInfo(pendingStockInfo);
        }

        public void UpdateLogLevel(Enums.DbLogLevel level)
        {
            _db.UpdateLogLevel(level);
        }

        public PredefinedStocksDto GetPredefinedStocks()
        {
            return _db.GetPredefinedStocks();
        }

        //public void AddStockToAlert(string symbol, List<string> emails)
        //{
        //    _db.AddStockToAlert(symbol, emails);
        //}

        //public StockPredefinedStocksParamsDto GetStartPredefinedStocksParamsDto()
        //{
        //    return _db.GetStartPredefinedStocksParams();
        //}

        public SystemHealthDataDto GetSystemHealthData()
        {
            return _db.GetSystemHealthData();
        }

        public void UpdateStockData(StocksDto.StockDto item)
        {
            _db.UpdateStockData(item);
        }

        public AnalysisHistoryDto GetSimulationResults(DateTime fromDate, DateTime toDate)
        {
            return _db.GetSimulationResults(fromDate, toDate);
        }

        public void AddSimulationResults(List<AnalysisHistoryItemDto> items, bool forScreener)
        {
            _db.AddSimulationResults(items, forScreener);
        }

        public void ClearSimulationResults(bool forScreener)
        {
            _db.ClearSimulationResults(forScreener);
        }

        public List<SectorDataDto> GetSectorsData()
        {
            return _db.GetSectorsData();
        }

        public void SaveSectorsData(List<SectorDataDto> sectors)
        {
            _db.SaveSectorsData(sectors);
        }

        public LoginResult Login(LoginParamsDto loginParams)
        {
            return _db.Login(loginParams);
        }

        public void RunMaintenance()
        {
             _db.RunMaintenance();
        }

        public StocksOverviewDto GetStocksOverview(string symbol, DateTime? fromDate, DateTime? toDate)
        {
            return _db.GetStocksOverview(symbol, fromDate, toDate);
        }

        public WatchListMedaDataSto GetWatchListMedaData()
        {
            return _db.GetWatchListMedaData();
        }

        public CurrentStocksWatchListDto GetCurrentStocksWatchList()
        {
            return _db.GetCurrentStocksWatchList();
        }

        public List<LogDto> GetRecentLogs( GetRecentLogsParamsDto param)
        {
            return _db.GetRecentLogs(param);
        }

        public void AddFinvizScannersData(string code, FinvizScannersDataDto finvizScannersDataDto)
        {
             _db.AddFinvizScannersData(code,finvizScannersDataDto);
        }

        public FinvizScannersDataDto GetFinvizScannersData(string code)
        {
            return _db.GetFinvizScannersData(code);
        }

        public AnalysisHistoryItemDto GetStockHistoryData(Guid historyId)
        {
            return _db.GetStockHistoryData(historyId);
        }

        //public FinvizScannerStartParamsDto GetFinvizScannerStartParams()
        //{
        //    return _db.GetFinvizScannerStartParams();
        //}

        public List<UsersActionDto> GetUsersByAction(UserActionEnum.EIdentifier action)
        {
            return _db.GetUsersByAction(action);
        }

        public void SaveFinvizAlerts(List<FinvizScannersDataItem> itemsToSend, string name)
        {
             _db.SaveFinvizAlerts(itemsToSend, name);
        }

        public AlertHistoryDataDto GetAlertsHistoryData(Guid alertHistoryId)
        {
            return _db.GetAlertsHistoryData(alertHistoryId);
        }

        public void ClearProcessHistory(bool clearAllHistory, ProcessHistoryCodeEnum.EIdentifier processCodeToClear)
        {
            _db.ClearProcessHistory(clearAllHistory, processCodeToClear);
        }

        public MarketDataDto GetMarketData(MarketDataGetParams getParams)
        {
            return _db.GetMarketData(getParams);
        }

   
        public void DoCustomJob()
        {
            _db.DoCustomJob();
        }

        public StocsHistoryDto GetStocsHistory(DateTime fromDate, DateTime toDate, double minScore)
        {
            return _db.GetStocsHistory(fromDate, toDate,minScore);
        }

        public ParamBase GetStartParams(ConfigurationCodeEnum.EIdentifier process)
        {
            return _db.GetStartParams(process);
        }
        public void SetStartParams(ConfigurationCodeEnum.EIdentifier process, ParamBase param)
        {
             _db.SetStartParams(process, param);
        }
        public HistoryTopStocksDto GetHistoryTopStocks(bool? duringTrade, int numberOfDays)
        {
            return _db.GetHistoryTopStocks(duringTrade, numberOfDays);
        }

        public List<StockProfile> GetStockInfoToRefresh()
        {
            return _db.GetStockInfoToRefresh();
        }

        public void RefreshStockInfo(List<StockProfile> pendingStockInfo)
        {
             _db.RefreshStockInfo(pendingStockInfo);
        }

        public void SavePremarketScannerData(PremarketScannerDataDto premarketScannerData)
        {
             _db.SavePremarketScannerData(premarketScannerData);
        }

       

        public void SavePremarketScannerMetaData(HistoryTopStocksDto currentCandidateStocksToTrade)
        {
            _db.SavePremarketScannerMetaData(currentCandidateStocksToTrade);
        }

        public HistoryTopStocksDto GetPremarketScannerMetaData()
        {
            return _db.GetPremarketScannerMetaData();
        }

        public void RunFixData(ProcessHistoryCodeEnum.EIdentifier process)
        {
            _db.RunFixData(process);
        }

        public List<AlertHistoryDataDto> GetAlertHistoriesData(ProcessHistoryCodeEnum.EIdentifier scanner, DateTime fromDate, DateTime toDate)
        {
            return _db.GetAlertHistoriesData(scanner, fromDate,toDate);
        }

        public StocksHistoryToRefreshDto GetStocksHistoryToRefresh(DateTime lastTradingDate, int maxItems)
        {
            return _db.GetStocksHistoryToRefresh( lastTradingDate, maxItems);
        }

        public void UpdateStocksHistoryData(List<StocksHistoryItemDto> stocksHistories)
        {
             _db.UpdateStocksHistoryData(stocksHistories);
        }

        public void RunDatabaseMaintenance(bool forchShrink = false)
        {
            _db.RunDatabaseMaintenance(forchShrink);
        }

        public Dictionary<string, StocksHistoryItemDto> GetStocksHistory(List<string> symbols, bool loadAdditionalData)
        {
            return _db.GetStocksHistory(symbols, loadAdditionalData);
        }

        public List<string> GetInvalidStocksFromHistory()
        {
            return _db.GetInvalidStocksFromHistory();
        }

        public List<GetDbSize_Result> GetDbSize()
        {
            return _db.GetDbSize();
        }

        public void UpdateConfiguration(ConfigurationCodeEnum.EIdentifier configCode, string data)
        {
            _db.UpdateConfiguration(configCode, data);
        }

        public string GetConfigurationData(ConfigurationCodeEnum.EIdentifier configCode)
        {
            return _db.GetConfigurationData(configCode);
        }

        public AnalysisHistoryDto SimulationResultsData(DateTime fromDate, DateTime toDate)
        {
            return _db.SimulationResultsData(fromDate, toDate);
        }

        public void UpdateSimulationResultsRanks(int[] ranksMinValues)
        {
            _db.UpdateSimulationResultsRanks(ranksMinValues);
        }

        public bool AddStrategies(List<StrategyItemDto> strategyCollection)
        {
            return _db.AddStrategies(strategyCollection);
        }

        public List<StrategyItemDto> GetCurrentStrategy()
        {
            return _db.GetCurrentStrategy();
        }

        public bool SaveBuyStockData(SaveStockDto data, bool simulation)
        {
            return _db.SaveBuyStockData(data, simulation);
        }

        public List<InvestmentDto> GetHoldings(bool simulation)
        {
            return _db.GetHoldings(simulation);
        }

        public List<StrategyItemDto> GetAllStrategy()
        {
            return _db.GetAllStrategy();
        }

        public void SaveStrategies(List<StrategyItemDto> strategyCollection)
        {
             _db.SaveStrategies(strategyCollection);
        }

        public void UpdateHoldings(List<InvestmentDto> holdings)
        {
             _db.UpdateHoldings(holdings);
        }

        public void SaveStockHistoryExtended(string symbol, DateTime fromDate, DateTime toDate, List<KeyValuePair<DateTime, HistoricalDataDto>> priceHistoryData)
        {
            _db.SaveStockHistoryExtended(symbol,fromDate,toDate,priceHistoryData);

        }
    }
}

