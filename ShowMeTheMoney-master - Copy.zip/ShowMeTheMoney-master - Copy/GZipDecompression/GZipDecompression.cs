﻿using System;
using System.IO;
using System.IO.Compression;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public class GZipDecompression
{
    [SqlFunction]
    public static SqlString DecompressGZip(SqlBinary compressedData)
    {
        if (compressedData.IsNull)
            return SqlString.Null;

        try
        {
            using (MemoryStream ms = new MemoryStream(compressedData.Value))
            using (GZipStream gzip = new GZipStream(ms, CompressionMode.Decompress))
            using (StreamReader reader = new StreamReader(gzip))
            {
                return new SqlString(reader.ReadToEnd());
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Error during decompression: " + ex.Message);
        }
    }
}
