﻿namespace Trady.Analysis.Backtest
{
    public enum TransactionType
    {
        Buy,
        Sell
    }
}