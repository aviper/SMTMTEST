﻿namespace IBSampleApp.ui
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.connectOptions_label_CT = new System.Windows.Forms.Label();
            this.connectOptions_CT = new System.Windows.Forms.TextBox();
            this.connectButton = new System.Windows.Forms.Button();
            this.clientid_CT = new System.Windows.Forms.TextBox();
            this.clientId_label_CT = new System.Windows.Forms.Label();
            this.host_CT = new System.Windows.Forms.TextBox();
            this.port_CT = new System.Windows.Forms.TextBox();
            this.host_label_CT = new System.Windows.Forms.Label();
            this.port_label_CT = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // connectOptions_label_CT
            // 
            this.connectOptions_label_CT.AutoSize = true;
            this.connectOptions_label_CT.Location = new System.Drawing.Point(543, 25);
            this.connectOptions_label_CT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.connectOptions_label_CT.Name = "connectOptions_label_CT";
            this.connectOptions_label_CT.Size = new System.Drawing.Size(103, 16);
            this.connectOptions_label_CT.TabIndex = 21;
            this.connectOptions_label_CT.Text = "Connect options";
            // 
            // connectOptions_CT
            // 
            this.connectOptions_CT.Location = new System.Drawing.Point(663, 16);
            this.connectOptions_CT.Margin = new System.Windows.Forms.Padding(4);
            this.connectOptions_CT.Name = "connectOptions_CT";
            this.connectOptions_CT.Size = new System.Drawing.Size(109, 22);
            this.connectOptions_CT.TabIndex = 20;
            this.connectOptions_CT.Text = "+PACEAPI";
            // 
            // connectButton
            // 
            this.connectButton.Location = new System.Drawing.Point(806, 13);
            this.connectButton.Margin = new System.Windows.Forms.Padding(4);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(100, 28);
            this.connectButton.TabIndex = 19;
            this.connectButton.Text = "Connect";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
            // 
            // clientid_CT
            // 
            this.clientid_CT.Location = new System.Drawing.Point(422, 16);
            this.clientid_CT.Margin = new System.Windows.Forms.Padding(4);
            this.clientid_CT.Name = "clientid_CT";
            this.clientid_CT.Size = new System.Drawing.Size(109, 22);
            this.clientid_CT.TabIndex = 18;
            this.clientid_CT.Text = "1";
            // 
            // clientId_label_CT
            // 
            this.clientId_label_CT.AutoSize = true;
            this.clientId_label_CT.Location = new System.Drawing.Point(354, 25);
            this.clientId_label_CT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.clientId_label_CT.Name = "clientId_label_CT";
            this.clientId_label_CT.Size = new System.Drawing.Size(54, 16);
            this.clientId_label_CT.TabIndex = 17;
            this.clientId_label_CT.Text = "Client Id";
            // 
            // host_CT
            // 
            this.host_CT.Location = new System.Drawing.Point(74, 18);
            this.host_CT.Margin = new System.Windows.Forms.Padding(4);
            this.host_CT.Name = "host_CT";
            this.host_CT.Size = new System.Drawing.Size(109, 22);
            this.host_CT.TabIndex = 14;
            // 
            // port_CT
            // 
            this.port_CT.Location = new System.Drawing.Point(235, 18);
            this.port_CT.Margin = new System.Windows.Forms.Padding(4);
            this.port_CT.Name = "port_CT";
            this.port_CT.Size = new System.Drawing.Size(109, 22);
            this.port_CT.TabIndex = 16;
            this.port_CT.Text = "7496";
            // 
            // host_label_CT
            // 
            this.host_label_CT.AutoSize = true;
            this.host_label_CT.Location = new System.Drawing.Point(27, 25);
            this.host_label_CT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.host_label_CT.Name = "host_label_CT";
            this.host_label_CT.Size = new System.Drawing.Size(35, 16);
            this.host_label_CT.TabIndex = 13;
            this.host_label_CT.Text = "Host";
            // 
            // port_label_CT
            // 
            this.port_label_CT.AutoSize = true;
            this.port_label_CT.Location = new System.Drawing.Point(192, 25);
            this.port_label_CT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.port_label_CT.Name = "port_label_CT";
            this.port_label_CT.Size = new System.Drawing.Size(31, 16);
            this.port_label_CT.TabIndex = 15;
            this.port_label_CT.Text = "Port";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1202, 450);
            this.Controls.Add(this.connectOptions_label_CT);
            this.Controls.Add(this.connectOptions_CT);
            this.Controls.Add(this.connectButton);
            this.Controls.Add(this.clientid_CT);
            this.Controls.Add(this.clientId_label_CT);
            this.Controls.Add(this.host_CT);
            this.Controls.Add(this.port_CT);
            this.Controls.Add(this.host_label_CT);
            this.Controls.Add(this.port_label_CT);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label connectOptions_label_CT;
        private System.Windows.Forms.TextBox connectOptions_CT;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.TextBox clientid_CT;
        private System.Windows.Forms.Label clientId_label_CT;
        private System.Windows.Forms.TextBox host_CT;
        private System.Windows.Forms.TextBox port_CT;
        private System.Windows.Forms.Label host_label_CT;
        private System.Windows.Forms.Label port_label_CT;
    }
}