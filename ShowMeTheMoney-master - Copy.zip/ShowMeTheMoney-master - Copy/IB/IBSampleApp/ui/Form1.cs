﻿using IBApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IBSampleApp.ui
{
    public partial class Form1 : Form
    {
        private IBClient ibClient;
        private EReaderMonitorSignal signal = new EReaderMonitorSignal();


        public Form1()
        {
            InitializeComponent();
            ibClient = new IBClient(signal);

        }
        public bool IsConnected { get; set; }

        private void connectButton_Click(object sender, EventArgs e)
        {
            if (!IsConnected)
            {
                int port;
                string host = host_CT.Text;
                string connectOptions = connectOptions_CT.Text;

                if (host == null || host.Equals(""))
                    host = "127.0.0.1";
                try
                {
                    port = int.Parse(port_CT.Text);
                    ibClient.ClientId = int.Parse(clientid_CT.Text);
                    ibClient.ClientSocket.SetConnectOptions(connectOptions);
                    ibClient.ClientSocket.eConnect(host, port, ibClient.ClientId);

                    var reader = new EReader(ibClient.ClientSocket, signal);

                    reader.Start();

                    new Thread(() => { while (ibClient.ClientSocket.IsConnected()) { signal.waitForSignal(); reader.processMsgs(); } }) { IsBackground = true }.Start();
                }
                catch (Exception)
                {
                    MessageBox.Show("Please check your connection attributes.");
                }
            }
            else
            {
                IsConnected = false;
                ibClient.ClientSocket.eDisconnect();
            }
        }
    }
}
