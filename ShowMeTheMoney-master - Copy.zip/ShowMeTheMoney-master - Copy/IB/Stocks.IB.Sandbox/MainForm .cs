﻿using IBApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stocks.IB.Sandbox
{
    public partial class MainForm : Form
    {
        private EWrapperImpl ibClient;

        public MainForm()
        {
            InitializeComponent();
            ibClient = new EWrapperImpl();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (!ibClient.ClientSocket.IsConnected())
            {
                ibClient.ClientSocket.eConnect("127.0.0.1", 7497, 0); // clientId = 0

                var reader = new EReader(ibClient.ClientSocket, ibClient.Signal);
                reader.Start();

                new System.Threading.Thread(() =>
                {
                    while (ibClient.ClientSocket.IsConnected())
                    {
                        ibClient.Signal.waitForSignal();
                        reader.processMsgs();
                    }
                }).Start();

                lblStatus.Text = "Connected!";
            }
            else
            {
                MessageBox.Show("Already connected.");
            }
        }
    }
}
